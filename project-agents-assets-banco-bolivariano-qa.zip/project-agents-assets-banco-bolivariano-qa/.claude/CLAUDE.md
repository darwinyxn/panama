# CLAUDE.md — project-agents-assets-banco-bolivariano-qa

## Qué es este repo

Fuente de verdad **única e inmutable** del motor QA (scripts, agentes, plantillas, catálogo de
errores) para la suite de equivalencia SP ↔ microservicio de Banco Bolivariano. Vigente desde
2026-09-22 — ver `PLAN_CAMBIOS_METODOLOGIA_TRABAJO.md` en
`.claude/docs-qa/inputs/documents/1. Internal Nyxn QA/PLAN SEPTIEMBRE NICO/` para el porqué completo
y el detalle de implementación.

## Regla central: INMUTABLE frente a los repos de SP

Cada repo de microservicio (`cpas-mso-*`, `ecu-mso-*`, etc.) obtiene su copia del motor QA desde aquí
al preparar el ambiente (`sync-harness.sh --pull`, ejecutado desde
`project-agents-assets-banco-bolivariano/claude-setupv3`). A partir de ahí, cada QA es libre de
**personalizar** esa copia dentro de su propio repo — scripts, agentes, documentos, lo que necesite
para su SP.

**Ninguna personalización hecha dentro de un repo de SP se propaga de vuelta a este repo.** No existe
mecanismo de "push" desde un SP hacia aquí — `sync-harness.sh` lo bloquea explícitamente (ni siquiera
con `--force`). Si algo aquí necesita cambiar, el cambio se hace **directamente en este repo**, nunca
copiando desde un repo de SP.

**Única excepción:** copiar `docs-qa/results/<sp>-<fecha>/` desde un repo de SP hacia aquí, para dejar
evidencia consolidada y analizable fuera de la EC2. Eso es extracción de evidencia, no propagación del
motor — no toca scripts, agentes, ni documentos de configuración.

## Por qué existe esta regla

Antes de 2026-09-22, la sincronización entre repos era manual e informal, sin ninguna protección. El
2026-09-22 (sesión `sp_tr_deposito_rc`), un intento de sincronizar un fix del motor hacia este repo
casi sobrescribió trabajo real sin commitear de otra persona — las 2 copias habían divergido de forma
independiente y no había ningún mecanismo que lo detectara. Ese incidente (revertido sin pérdida de
datos) es el motivador directo de este modelo.

## Qué SÍ modificar aquí directamente

- `.claude/docs-qa/inputs/scripts/` (motor: `auto/`, `qmetry/`, `sp_tc_gen/`)
- `.claude/docs-qa/inputs/templates/`
- `.claude/docs-qa/inputs/catalogos/` (ej. `cl_errores.json`)
- `.claude/agents/` (los 24 agentes QA — auto-00..05, qmetry-*, uml-*, doclogica-*, etc.)

## Qué NO vive aquí de forma permanente

- Resultados de corridas de un SP (`docs-qa/results/`) — se copian para análisis, no se integran al
  motor.
- Documentos/personalizaciones específicas de un SP (`docs-qa/inputs/documents/<sp>/`) — viven en el
  repo del SP; este repo mantiene copias de trabajo/análisis histórico pero NO son la fuente de verdad
  de ningún SP activo.

## Referencia cruzada

- Mecanismo de sincronización (script real): `project-agents-assets-banco-bolivariano/claude-setupv3/.claude/scripts/sync-harness.sh`
- Política completa: `project-agents-assets-banco-bolivariano/claude-setupv3/.claude/PROPAGATION.md`
- Plan de implementación de este modelo: `.claude/docs-qa/inputs/documents/1. Internal Nyxn QA/PLAN SEPTIEMBRE NICO/PLAN_CAMBIOS_METODOLOGIA_TRABAJO.md`
- Instructivo operativo del pipeline QA: `.claude/docs-qa/1.INSTRUCCIONES-USO-AGENTES-QA.md`

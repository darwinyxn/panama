# API y Contratos

## API-001: OpenAPI 3.1.x con jsonSchemaDialect
Bloque: MICRO. Regla: Nuevas APIs usan OpenAPI 3.1.x. Declarar `jsonSchemaDialect`. Prohibido Swagger 2.0/OAS 3.0.
Aplica a: micro-contratos
Verifica: micro-check-contratos
FAIL si: spec sin openapi: 3.1.x o sin jsonSchemaDialect

## API-002: Paridad REST/gRPC obligatoria (campos de DOMINIO)
Bloque: MICRO. Regla: REST y gRPC exponen mismos campos de DOMINIO (params del SP), mismos codigos, misma semantica. Paridad se refiere a los datos de negocio, NO a infraestructura de protocolo. Trazabilidad (headers HTTP vs metadata gRPC) y errores (RFC 7807 vs Status gRPC) se manejan con mecanismos nativos de cada protocolo — NO se replican cruzados (ver API-013).
Aplica a: micro-contratos
Verifica: micro-check-contratos
FAIL si: campo de DOMINIO presente en REST ausente en gRPC o viceversa sin justificacion

## API-003: Headers de trazabilidad
Bloque: MICRO. Regla: Operaciones protegidas documentan X-Request-Id y X-Correlation-Id. Respuestas devuelven X-Correlation-Id.
Aplica a: micro-contratos, micro-seguridad-resiliencia
Verifica: micro-check-contratos
FAIL si: operacion protegida sin headers de trazabilidad en spec/implementacion

## API-004: Idempotency-Key en POST financieros
Bloque: MICRO. Regla: POST con efecto financiero documenta header Idempotency-Key en OpenAPI (required=false en @RequestHeader, igual que cpas-mso-genera-nd-nc-automatica-aho).
Aplica a: micro-contratos
Verifica: micro-check-contratos
FAIL si: POST financiero sin Idempotency-Key en spec

## API-005: Errores RFC 7807
Bloque: MICRO. Regla: Errores en application/problem+json. Cubrir 400/401/403/404/409/422/429/500. 429 con Retry-After.
Aplica a: micro-contratos, micro-seguridad-resiliencia
Verifica: micro-check-contratos
FAIL si: error response sin content-type problem+json o 429 sin Retry-After

## API-006: Healthchecks obligatorios
Bloque: MICRO. Regla: Documentar GET /health, /health/live, /health/ready con security:[]. 200=saludable, 503=degradado.
Aplica a: micro-contratos, micro-seguridad-resiliencia
Verifica: micro-check-contratos
FAIL si: healthchecks faltantes o con seguridad que impida orquestacion K8s

## API-007: Tipos equivalentes SP -> API (y validaciones no mas estrictas que el SP)
Bloque: MICRO. Regla: Tipos SP/Sybase se reflejan en Java/DTO/OpenAPI/Proto. Numericos no se modelan como String. Ademas, las VALIDACIONES de entrada del contrato (`maxLength`, `required`, `pattern` en el OpenAPI; `@Size`/`@NotNull`/`@NotBlank` en el DTO) DEBEN derivarse del SP y NO ser MAS ESTRICTAS que el: el micro NO declara una restriccion que el SP no impone, porque eso rechaza con HTTP 400 entradas que el SP procesaria sin problema. La fuente de cada `maxLength`/`required`/`pattern` es el tipo/longitud real del parametro en el SP (paridad inversa — la regla maestra vive en SP-007). Caso real (QA DVP): `maxLength: 1` en `tipo_referencia` rechazaba 2 caracteres que el SP aceptaba.
Aplica a: micro-dominio, micro-contratos
Verifica: micro-check-contratos, lib-equivalencia
FAIL si: campo numerico del SP expuesto como String sin excepcion aprobada; o validacion de entrada (maxLength/required/pattern en OpenAPI o @Size/@NotNull/@NotBlank en DTO) mas estricta que el parametro real del SP, rechazando con 400 entradas que el SP aceptaria

## API-008: Monetarios externos 2 decimales
Bloque: MICRO. Regla: Respuestas monetarias al cliente usan 2 decimales cuando contrato/cliente lo espera. Precision interna mayor se preserva para calculo.
Aplica a: micro-contratos
Verifica: micro-check-contratos
FAIL si: payload monetario con 4 decimales cuando contrato espera 2

## API-009: Precision temporal preservada
Bloque: MICRO. Regla: Campos datetime del SP no se degradan a LocalDate sin plan aprobado. Preservar fecha+hora.
Aplica a: micro-dominio, micro-contratos
Verifica: micro-check-contratos
FAIL si: datetime del SP mapeado a LocalDate sin justificacion

## API-010: Endpoints con implementacion real
Bloque: MICRO. Regla: Todo endpoint publicado en spec tiene implementacion funcional. Prohibido stubs en release.
Aplica a: micro-contratos
Verifica: micro-check-contratos
FAIL si: endpoint en openapi.yaml sin controller/method que lo implemente

## API-011: Fuente unica de contrato
Bloque: MICRO. Regla: 1 sola fuente de verdad del contrato por servicio (archivo estatico o generacion gobernada).
Aplica a: micro-contratos
Verifica: micro-check-contratos
FAIL si: 2+ fuentes de contrato contradictorias

## API-012: Validacion de entrada
Bloque: MICRO. Regla: Parametros criticos REST/gRPC tienen validacion explicita. No confiar en input externo.
Aplica a: micro-contratos
Verifica: micro-check-contratos
FAIL si: parametro critico (cuenta, monto) sin validacion de presencia/formato

## API-013: Proto puro dominio — sin conceptos HTTP/REST
Bloque: MICRO. Regla: Los messages del .proto contienen EXCLUSIVAMENTE campos de dominio (params del SP). PROHIBIDO incluir en el proto:
- Headers de trazabilidad (request_id, correlation_id) — se manejan via gRPC metadata (interceptor)
- Idempotency-Key — se maneja via gRPC metadata (interceptor)
- ProblemDetail / RFC 7807 — es concepto REST; gRPC usa Status + StatusRuntimeException nativos
- Campos de infraestructura HTTP (content-type, status code, etc.)

La trazabilidad en gRPC se resuelve con un ServerInterceptor que lee metadata keys `x-request-id` y `x-correlation-id`, los pone en MDC/Context, y los devuelve como trailing metadata en la respuesta. El servicio gRPC NO necesita recibirlos como campos del message.

Los errores en gRPC se comunican asi:
- Error funcional (dominio): response normal con campos del SP (ej: `error`, `detalleError`, `mensaje` si el SP los tiene como OUTPUT)
- Error tecnico (infra): `responseObserver.onError(StatusRuntimeException)` con Status apropiado
- Si el SP solo devuelve return 0 o lanza error (sin params OUTPUT), la response gRPC tiene solo los campos funcionales minimos (codigo + mensaje), SIN ProblemDetail.

Referencia correcta: cpas-mso-genera-nd-nc-automatica-aho (proto puro, sin HTTP concepts).
Aplica a: micro-contratos
Verifica: micro-check-contratos
FAIL si: .proto contiene campos request_id, correlation_id, idempotency_key, o message ProblemDetail

## API-014: proto3 `optional` para distinguir cadena vacia ('') de ausente — SOLO en REQUEST (entrada)
Bloque: MICRO. Regla (hallazgo TC97, DVP 2026-07; ALCANCE ACOTADO a REQUEST por decision de Arquitectura del banco,
2026-07-08): en proto3 un `string` escalar NO distingue `''` (cadena vacia) de "campo ausente" — ambos llegan al servidor
como `""`, y el default de un campo no seteado tambien es `""`. Cuando el SP distingue funcionalmente `''` de NULL/ausente
en un campo de ENTRADA (ej. `frm_pagcob_deb`: `''` es un valor valido con semantica propia, distinta de omitir el campo),
ese campo de REQUEST DEBE declararse `optional` en el .proto (proto3 `optional` genera el `has_<campo>()` que permite
saber si vino seteado). Sin `optional`, el mapper gRPC colapsa `''`->null (o null->'') en la entrada y ROMPE la paridad
con REST (que si distingue `""` de `null` en el JSON de request). Aplica a TODO campo string de REQUEST cuyo `''` el SP
trata distinto de la ausencia/NULL. Los campos de request donde `''` y ausente son equivalentes NO necesitan `optional`.
> **RESPONSE (salida) — WRAPPERS (decision del banco 2026-07-09, verificado con protojson):** para PRESERVAR el NULL de
> un OUTPUT nullable del SP en la RESPONSE gRPC se usan los WRAPPERS `google.protobuf.Int32Value`/`StringValue`. Punto
> CLAVE verificado empiricamente contra `protojson` (el serializador gRPC-JSON que usa grpcurl): un wrapper SETEADO sale
> PLANO en el JSON (`oError: 0`, NO `{"value":0}` — el `{value}` que se ve en Postman es un artefacto del render del arbol
> crudo del mensaje, NO la serializacion gRPC-JSON real). Con la bandera **`-emit-defaults`** de grpcurl
> (`EmitUnpopulated` de protojson), un wrapper NO-seteado sale como el campo SIEMPRE presente con valor `null`
> (`oRegAProc: null`), distinguiendo null de 0. Asi la response tiene los 3 campos SIEMPRE presentes, planos, y con null
> preservado. El `optional` scalar proto3 tambien preserva null pero OMITE el campo cuando es null (no lo emite ni con
> `-emit-defaults` de la misma forma predecible) — por eso en RESPONSE se usan wrappers, no `optional`. El `optional`
> queda para REQUEST. Un campo que nunca es null (ej. `codigoRetorno`) queda escalar `int32` a secas.
Aplica a: micro-contratos
Verifica: micro-check-contratos
FAIL si: un campo string de REQUEST cuyo `''` el SP distingue de NULL/ausente NO se declara `optional` (colapsa ''<->null
y rompe la paridad REST/gRPC de la entrada); o un campo de RESPONSE gRPC nullable NO usa wrapper `Int32Value`/`StringValue`
(usa escalar-a-secas con coalescing null->0, o `optional` scalar que omite el campo) — ver API-015

## API-015: NULL en campos de SALIDA/response se PRESERVA en AMBOS protocolos (REST y gRPC) — null != 0 != ''
Bloque: MICRO. Regla (hallazgo TC25/26/27, DVP 2026-07; politica gRPC RESTAURADA por decision del banco 2026-07-09): un
campo OUTPUT del SP que el SP devuelve como NULL se emite como `null` en AMBOS canales — la semantica NULL de Sybase
(SP-013) se preserva en la salida tanto en REST como en gRPC. La forma de la response (wrapper `SpResponse`:
`{ codigoRetorno, mensajeDebug, data{...} }`) NO cambia; lo que se preserva es el NULL de los campos nullables:
- **REST (JSON):** el NULL se emite como `null`, NUNCA coaccionado a `0`/`""`/default. Exige modelar el campo de response
  con su TIPO WRAPPER Java (`Integer`/`Double`/...) y NO con primitivo (que forzaria 0); el mapper REST NO rellena un
  default cuando la lib-padre devuelve null. Caso que origino la regla: `error`/`reg_a_proc` salian `0` en REST cuando el
  SP los dejaba NULL, rompiendo la equivalencia.
- **gRPC:** el NULL se emite como `null` usando WRAPPERS `google.protobuf.Int32Value`/`StringValue`. El mapper setea el
  wrapper SOLO si el valor no es null (`if (x!=null) setOError(Int32Value.of(x))`); un `0`/`""` EXPLICITO (valor real) SI
  se emite. VERIFICADO con protojson (el serializador de grpcurl): un wrapper seteado sale PLANO (`oError: 0`, NO
  `{"value":0}` — el `{value}` de Postman es artefacto del render crudo, no del JSON real); con la bandera
  **`-emit-defaults`** de grpcurl un wrapper no-seteado sale como el campo SIEMPRE presente con valor `null`
  (`oRegAProc: null`). Resultado: los 3 campos SIEMPRE presentes, planos, y null preservado. NOTA: `-emit-defaults` es
  necesaria en la invocacion grpcurl para que los null salgan presentes (sin ella, protojson omite el wrapper no-seteado).
  Un campo que nunca es null (ej. `codigoRetorno` = return status) queda escalar `int32` a secas. Esta politica (wrappers +
  `-emit-defaults`) es la VIGENTE: sobre-escribe la version del 2026-07-08 (degradaba null a default por tipo) y la
  intermedia con `optional` scalar (que omitia el campo cuando era null). La paridad REST/gRPC es TOTAL — ambos canales
  emiten `null` para un OUTPUT nullable del SP, con el mismo shape de JSON.
Aplica a: micro-dominio, micro-contratos, micro-facade
Verifica: micro-check-contratos
FAIL si: un campo de response REST que el SP puede devolver NULL se emite como `0`/`""`/default en vez de `null` (campo
modelado como primitivo, o mapper REST que coacciona el null a un default); o un campo de response gRPC nullable NO usa
wrapper `Int32Value`/`StringValue` (usa escalar-a-secas con coalescing null->0, o `optional` scalar que omite el campo
cuando es null), o el mapper gRPC setea el wrapper con un default cuando el valor es null (debe dejarlo no-seteado)

## API-016: Campos SP-017 con prefijo (`oXxx`/`iXxx`/`tXxx`) NO deben serializarse DUPLICADOS — Jackson usa el field, no el getter Lombok (NCBE-1109)
Bloque: MICRO. Regla (bug real de contrato 2026-07-28, verificado en el JSON de respuesta desplegado): un DTO REST cuyos
campos siguen SP-017 (nombre = param del SP en camelCase CON prefijo de una letra: `oNombre`, `oError`, `iCta`, `tTrn`)
y usa Lombok `@Getter` produce un getter `getONombre()`/`getOError()` (doble mayuscula inicial). Jackson, por defecto,
DETECTA la propiedad TANTO del `@JsonProperty("oNombre")` puesto en el FIELD como del getter `getONombre()` — y como el
bean-naming del getter da `ONombre` (con la 1a mayuscula), **emite AMBAS**: `{"oNombre":null, ... ,"ONombre":null}`. El
JSON sale con cada campo OUTPUT DUPLICADO en dos capitalizaciones, rompiendo el contrato (el cliente ve `oNombre` y
`ONombre`). Afecta a TODO DTO/response con naming SP-017 de campos que empiezan por `<letra minuscula><Mayuscula>`.
**Fix canonico (local al DTO):** anotar la clase con
`@JsonAutoDetect(getterVisibility = JsonAutoDetect.Visibility.NONE, fieldVisibility = JsonAutoDetect.Visibility.ANY)`
(import `com.fasterxml.jackson.annotation.JsonAutoDetect`). Asi Jackson serializa SOLO por los FIELDS (con su
`@JsonProperty`) e IGNORA los getters Lombok -> una sola propiedad por campo, con el nombre exacto del `@JsonProperty`.
(El `@JsonProperty` en el field, por si solo, NO basta: no suprime la propiedad inferida del getter.) Poner el
`@JsonProperty` unicamente donde toca y desactivar la deteccion por getter es lo que garantiza el nombre 1:1 con el
param del SP en el JSON externo.
Aplica a: micro-contratos
Verifica: micro-check-contratos
FAIL si: un DTO/response del micro con campos SP-017 de prefijo (`oXxx`/`iXxx`/`tXxx`/`sXxx`) emite el campo DUPLICADO en
dos capitalizaciones (`oNombre` y `ONombre`) por dejar activa la deteccion por getter de Lombok; o se "arregla" renombrando
el campo/param (romperia SP-017). El fix correcto es `@JsonAutoDetect(getterVisibility=NONE, fieldVisibility=ANY)` +
`@JsonProperty` en el field.

## API-017: Nombre JSON EXTERNO del `@JsonProperty` derivado MECANICAMENTE del param del SP — REQUEST snake_case CON prefijo; RESPONSE-OUTPUT camelCase SP-017; columnas de resultset = dominio (unifica el naming entre micros)
Bloque: MICRO. Regla (hallazgo de inconsistencia entre micros de un mismo bosque, 2026-07-29): SP-017 fija el NOMBRE DEL
FIELD Java (camelCase con prefijo) pero dejaba LIBRE el nombre JSON EXTERNO del `@JsonProperty`. Resultado: micros del
mismo bosque expusieron contratos con capitalizaciones distintas (request `sSsn`/`iCta` en retiro-rc/depositosl-rc vs
`e_cta_banco` en consulta-firmante), sin regla que lo gobernara. Esta regla FIJA el nombre externo, derivado
MECANICAMENTE del parametro del SP (sin interpretar por significado):
- **REQUEST** (params de ENTRADA del SP): `@JsonProperty` = nombre EXACTO del param del SP en **snake_case CONSERVANDO su
  prefijo de direccion** (solo se quita el `@`): `@i_orden_empresa` -> `"i_orden_empresa"`, `@s_ssn` -> `"s_ssn"`,
  `@t_corr` -> `"t_corr"`. Se CONSERVA el prefijo (`i_`/`s_`/`t_`/`p_`/`e_`) para (a) evitar COLISIONES cuando el SP tiene
  el mismo nombre base con dos prefijos (`@s_ssn` + `@i_ssn` -> `s_ssn`/`i_ssn`, no ambos `ssn`) y (b) rastrear 1:1 al
  param. El field Java sigue SP-017 (`sSsn`, `iOrdenEmpresa`); SOLO el `@JsonProperty` externo va snake con prefijo.
- **RESPONSE — OUTPUT params del SP** (`@o_*`, return status escalar): `@JsonProperty` = **camelCase con prefijo (SP-017)**:
  `@o_error` -> `"oError"`, `@o_reg_a_proc` -> `"oRegAProc"`. Es el estandar que QA aprobo (bem-mso, `DebcredEmpresaDataDto`).
  El wrapper `SpResponse` conserva `codigoRetorno`/`mensajeDebug` (COB-008).
- **RESPONSE — COLUMNAS de un RESULTSET/cursor** (no OUTPUT escalares, ej. un `select col1, col2` que el SP devuelve como
  filas): conservan su **nombre de DOMINIO** (`registros`, `mensaje`, `firmantes`, `identificacion`), NO se les fuerza
  prefijo — igual que SP-017 excluye las columnas de tabla/resultset de su alcance. Caso `pa_fir_consulta_firmante`.
> **EXCEPCION HISTORICA APROBADA — bem-mso-debito-credito-empresa-pagos:** su REQUEST expone snake_case SIN prefijo
> (`orden_empresa`, no `i_orden_empresa`) porque su SP tiene solo params `@i_*` (sin colision) y QA ya lo aprobo en
> produccion. NO se re-alinea (contrato vivo aprobado). Es la UNICA excepcion; todo micro NUEVO usa snake CON prefijo.

**FORMA CANONICA OBLIGATORIA del request DTO (plantilla `.claude/templates/request-dto-canonico.md`):** para que NINGUN
micro vuelva a divergir (los 3 micros de un bosque salieron con formas distintas por no haber plantilla), el request DTO
es SIEMPRE un **`record`** con `@JsonProperty` en el field + `Presence<T>` SOLO en los obligatorios que el SP distingue
ausente/null (SP-019); el resto tipo directo. Referencia viva: bem-mso (`DebcredPagosEmpresaRequestDto`). PROHIBIDO
`class` con Lombok `@Getter/@Setter`.

**UBICACION del `@JsonProperty` — SIEMPRE en el FIELD, NUNCA en el setter (hallazgo QA 2026-07-29):** el `@JsonProperty`
del REQUEST va anotado sobre el CAMPO del DTO, no sobre un setter. **Por que (bug real de deposito):** la herramienta de
la suite QA automatizada LEE LOS CAMPOS del DTO para mapear cada uno a su param del SP y armar los payloads de prueba; si
el `@JsonProperty` esta en un setter (patron Lombok con flag `xEnviado` para presencia), la herramienta lee el nombre
CRUDO del field en camelCase (`iCta`) en vez del `"i_cta"` del setter, NO encuentra correspondencia con el SP y genera
**0 payloads** -> el micro NO se puede probar en QA (ni REST ni gRPC). El DTO REST del micro es un `record` con
`@JsonProperty` en el componente/field (patron consulta-firmante/bem).
> **Compatibilidad con la deteccion de presencia (SP-019):** el mecanismo de presencia del MICRO NO es el flag `xEnviado`
> marcado por setter (ese es el patron de la LIBRERIA/Builder, ver SP-019). En el micro la presencia se modela con
> **`Presence<T>`** (wrapper Jackson 3) como TIPO del componente del record + `PresenceModule` en `JacksonConfig`, con el
> `@JsonProperty` en el field. Asi se cumple "field, no setter" Y se conserva la distincion ausente/enviado-en-null
> (SP-019) sin romper la suite QA. NUNCA mover el `@JsonProperty` a un field pelado dejando el setter-flag: Jackson
> escribiria el field directo sin llamar al setter y el flag nunca se marcaria (regresion NCBE-840).
Aplica a: micro-contratos, micro-facade
Verifica: micro-check-contratos
FAIL si: el `@JsonProperty` de un campo de REQUEST no es el nombre del param del SP en snake_case con su prefijo de
direccion (se le quito el prefijo fuera de la excepcion bem, o se puso camelCase, o se renombro por significado); o el
`@JsonProperty` de un OUTPUT escalar del SP en la RESPONSE no es camelCase-con-prefijo SP-017 (`oError`); o a una columna
de resultset se le fuerza prefijo en vez de su nombre de dominio; o dos params con distinto prefijo colisionan al mismo
nombre externo por haber quitado el prefijo (`@s_ssn` y `@i_ssn` ambos a `ssn`); o el `@JsonProperty` de un DTO de REQUEST
esta anotado en un SETTER en vez del FIELD (la suite QA lee el field crudo camelCase y genera 0 payloads); o el micro usa
el flag `xEnviado`-por-setter en vez de `Presence<T>` para la deteccion de presencia (patron de libreria, no de micro); o
el request DTO es una `class` con Lombok `@Getter/@Setter` en vez del `record` canonico
(`.claude/templates/request-dto-canonico.md`)

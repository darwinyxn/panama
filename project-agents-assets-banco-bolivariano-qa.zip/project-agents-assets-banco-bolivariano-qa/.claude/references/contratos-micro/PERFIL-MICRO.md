# Perfil de Reglas — MICRO (Bloque B)

> **Que es:** define que reglas aplican al **microservicio** y con que rigor. El micro es un **facade hexagonal ESTRICTO**
> que CONSUME la libreria-padre. NO contiene logica de SP ni acceso a datos de las librerias (LBF-002).
>
> **Principio rector:** hexagonal estricto + Sonar estricto + no reimplementar SP. A diferencia de la libreria, aqui NO se
> relaja nada: el micro es codigo de aplicacion limpio y arquitectonicamente puro.
>
> Reglas base: `rules/INDEX.md`. Reglas library-first: `rules/library-first.md`.

---

## HEXAGONAL ESTRICTO — todas las ARQ aplican sin relajar
`ARQ-001` (domain del micro sin infraestructura — es la regla del MICRO: el dominio del micro es PURO. La faceta de la
libreria —nucleo puro / bordes con infra— es `ARQ-011`, auditada por `lib-check`, y NO es asunto del micro),
`ARQ-002` (application no depende de infrastructure), `ARQ-003` (UseCase orquesta / Domain Service define reglas — SIN
relajar: el dominio delgado del micro respeta esta separacion), `ARQ-004..010` (domain service sin Spring, persistencia
real, no hardcode, adapters cohesivos, estructura canonica, sin duplicados, ADR para desviaciones). El micro mantiene las
capas domain/application/infrastructure/bootstrap completas.

## SONAR ESTRICTO — todas las CLN aplican sin relajar
`CLN-001..013` (incl. `CLN-011` narrativos, `CLN-012` ramas identicas->`||` S1871, `CLN-013` `Boolean` nullable->`Boolean.TRUE.equals` S5411) se aplican con TODO el rigor, incluida `CLN-009` (complejidad cognitiva max 15), `CLN-004` (no
magic numbers) y `CLN-011` (NO comentarios narrativos del agente: solo los heredados del SP + `// Vault`/`// DML`; los
comentarios propios disparan Sonar de bloques duplicados). El micro NO tiene la excepcion de fidelidad de la libreria: su
codigo es de aplicacion y debe pasar Sonar manual limpio. (La complejidad del SP vive en la libreria, no aqui.)

## CONTRATOS Y SEGURIDAD — aplican todas
- `API-001..015`: OpenAPI 3.1, paridad REST/gRPC, headers de trazabilidad, idempotency, RFC 7807, healthchecks, tipos
  equivalentes, proto puro de dominio, `optional` string para ''≠ausente SOLO en REQUEST (API-014), NULL en la response
  PRESERVADO en AMBOS canales —REST wrapper Java, gRPC via wrappers `Int32Value`/`StringValue` + grpcurl `-emit-defaults`
  (valor plano, siempre presente, preserva null) (API-015, banco 2026-07-09). Es el micro quien expone la API.
- **Forma de la response (patron `SpResponse<T>` — `cpas-mso-genera-nd-nc-automatica-aho`):** la salida del micro se
  estructura como wrapper `{ codigoRetorno (int), mensajeDebug (String), data (T) }` — `codigoRetorno` es el return status
  del SP, `mensajeDebug` es el texto del error (COB-008), y `data` es el DTO con los params OUTPUT del SP (ej. `oError`,
  `oRegAProc`). Los campos nullables se emiten `null` en AMBOS canales: en REST via tipo wrapper Java; en gRPC via
  wrappers `google.protobuf.Int32Value`/`StringValue` — el mapper setea el wrapper SOLO si el valor no es null
  (`if (x!=null) setOError(Int32Value.of(x))`); un wrapper seteado sale PLANO en gRPC-JSON real (`oError: 0`, NO
  `{"value":0}` — el `{value}` que se veia en Postman es artefacto del render crudo, no de protojson), y un wrapper
  no-seteado sale como el campo SIEMPRE presente con valor `null` (`oRegAProc: null`) cuando grpcurl usa la bandera
  `-emit-defaults`. `codigoRetorno` (nunca null) es escalar `int32` a secas. Verifica `micro-check-contratos`.
- `COB-008`: campo de salida con el texto del error (Msg 201 / `cl_errores` literal), expuesto como `mensajeDebug` a nivel
  wrapper de la response — unica excepcion aprobada a SP-007; `null` en exito en AMBOS canales (REST wrapper Java; gRPC
  `mensajeDebug` es `StringValue` no-seteado -> sale `null` con grpcurl `-emit-defaults`, API-015). Verifica
  `micro-check-contratos`.
- `SP-017` (Bloque AMBOS): los campos de los DTO/proto que espejan params del SP derivan mecanicamente del nombre del
  param con prefijo (`@t_trn`->`tTrn`); el nombre JSON externo se fija con `@JsonProperty` para no romper el contrato del
  cliente. Verifica `micro-check-contratos`.
- `SP-018` (Bloque AMBOS): los montos en DTO/dominio del micro son `double`/`Double`, NUNCA `BigDecimal` (API-008 —2
  decimales externos— se resuelve en el formateo de salida, no obliga a BigDecimal interno). Verifica
  `micro-check-codigo-limpio`.
- `SEC-001..009`: CRLF en logs/headers, no secrets, TLS, auth financiera, no DEBUG SQL, SSRF, Host header, actuator solo
  health. Aplican todas (el micro es la cara web).

## RESILIENCIA — solo la de la cara web del micro
`RES-003` (no retry en escrituras) y la resiliencia de la cara gRPC entrante aplican al micro. El resto de RES
(`RES-001/002/004/006/007`: `@CircuitBreaker`/`@TimeLimiter`, unchained tx `NOT_SUPPORTED`, patron exec cross-db, sp_cerror
fail-safe) NO aplica al micro: el exec a SP legacy y toda su resiliencia viven DENTRO de la **librería** (proyecto Spring
autonomo) y se auditan en el Bloque A (`lib-check`). El micro NO inyecta un DataSource como dependencia hacia las libs ni
implementa lógica/exec/adapters hacia ellas. **EXCEPCION NCBE-1002 (RES-010 lado micro):** cuando la lib-padre controla
una transacción (`begin tran`), el micro SÍ gestiona el CICLO DE VIDA de la conexión física — obtiene la conexión del
DataSource único, la liga al hilo (`bindResource`) antes de invocar la lib y la libera/descarta en el `finally`. La lib
RECIBE esa conexión (no la crea ni la cierra). Lo audita `micro-check-resiliencia`.

## PLATAFORMA — aplican todas
`PLT-001..010`: stack inmutable (Java 25 / Spring Boot 4.0.6), build con settings-local.xml, JaCoCo 100% (cerrado por
`micro-tests`), dependencias resolubles, no skip tests, bolivariano-commons (para el micro), RestClient, versiones
minimas CVE, librerias via Maven. PLT-010: el micro NO implementa LOGICA hacia las libs (ni exec legacy, ni adapters de
datos, ni inyeccion de un DataSource como dependencia de la lib). Excepcion NCBE-1002: el micro SI gestiona el ciclo de
vida de la conexion fisica de la transaccion de la lib-padre (bindResource/release), ver seccion RESILIENCIA.

## LIBRARY-FIRST que aplican al micro
`LBF-002` (el micro NO reimplementa logica de SP — FALLA si lo hace), `LBF-004` (libreria antes que micro: arranca con la
lib-padre `local_installed`), `LBF-008` (el micro no aporta LÓGICA de runtime a las libs: solo importa la lib-padre por
Maven y la invoca; excepción NCBE-1002: gestiona el ciclo de vida de la conexión física de la transacción del padre).

## NO aplica al micro
- **Equivalencia SP<->Java** (`lib-equivalencia`, gate `equivalence`): eso se audita ENTERAMENTE en el Bloque A
  (libreria). El micro NO tiene logica de SP que auditar; su verificacion es arquitectura/contratos/codigo-limpio/
  resiliencia (`micro-check-*`), no equivalencia.
- La relajacion del nucleo 1:1 del `PERFIL-LIBRERIA.md` (ARQ-003/CLN-009/CLN-004 relajadas): NO aplica aqui; en el micro
  esas reglas son estrictas.

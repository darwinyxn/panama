---
name: micro-contratos
description: Crea contratos REST + gRPC + OpenAPI con paridad entre canales.
tools: [Read, Write, Edit, Bash, Grep, Glob]
---

# micro-contratos: REST + gRPC + OpenAPI del micro

## Bitacora y TODO

### Protocolo de TODO (OBLIGATORIO)

1. **AL INICIAR**: Leer inputs (interfaces.json, path-details, manifest, SQL extraido). Abrir `.claude/todo/<agent-id>.md` y:
   - Mantener la **Checklist base** intacta
   - Construir la seccion **Items especificos** con tareas concretas derivadas de los inputs (nombres de params, tablas, SPs, archivos a crear)
   - Si necesitas agregar items que no estaban en la checklist base: agregalos. El TODO es tuyo.

2. **DURANTE EJECUCION**: Cada vez que completes un item:
   - Marcarlo `[x]`
   - En **Archivos producidos**: anotar ruta del archivo creado
   - En **Validaciones realizadas**: anotar que confirmaste y contra que fuente

3. **AL FINALIZAR**: Verificar que no queden items `[ ]` sin marcar ni justificar.

### Reglas de edicion
- Si el TODO ya existe, usar `Edit` — NO `Write` para sobrescribirlo completo
- Usar `Write` solo si `.claude/todo/<agent-id>.md` no existe
- NO editar `.claude/history/<agent-id>.md` directamente
- Para history: `bash .claude/scripts/log-history.sh "<agent-id>" "<PASS|FAIL|BLOCKED>" "<resumen>"`

## Responsabilidad

Exponer los use cases via REST y gRPC con paridad. El micro tiene tantos endpoints como puntos de entrada tenga el SP. Si el SP recibe parametros y por ellos decide el camino (ND, NC, reverso), el endpoint tambien — no crear endpoints separados por camino.

## Input

- `analysis/<sp_name>/interfaces.json` (params de entrada/salida del SP)
- `analysis/<sp_name>/use-cases.json` (CUs a exponer)
- Use case consumidor creado por micro-facade

## Output

- `src/main/java/.../infrastructure/inbound/rest/controller/` — controllers REST
- `src/main/java/.../infrastructure/inbound/rest/dto/` — DTOs request/response
- `src/main/java/.../infrastructure/inbound/grpc/` — servicios gRPC
- `src/main/proto/` — proto files
- `src/main/resources/openapi.yaml` — spec OpenAPI
- `src/main/java/.../application/dto/` — DTOs compartidos

## Reglas

- `.claude/rules/api-contratos.md` — cumplir API-001 a API-017 (incl. la forma wrapper `SpResponse<T>` de la response, API-014 `optional` SOLO en REQUEST, API-015 NULL preservado en AMBOS canales —REST wrapper Java, gRPC wrappers `Int32Value`/`StringValue` + grpcurl `-emit-defaults`—, **API-016** anti-serializacion-duplicada de los DTOs REST con campos SP-017 de prefijo, y **API-017** naming mecanico del `@JsonProperty` externo: REQUEST snake_case CON prefijo, RESPONSE-OUTPUT camelCase SP-017, columnas resultset = dominio —ver secciones "Nombre JSON externo" y "Serializacion de los DTOs REST" abajo)
- `.claude/rules/seguridad.md` — cumplir SEC-001, SEC-002, SEC-005
- `.claude/rules/fidelidad-sp-core.md` — cumplir SP-007
- `.claude/rules/cobis.md` — cumplir COB-007 (parametros de debug/logging COBIS no se exponen en request DTO, OpenAPI ni proto) y **COB-008** (exponer el TEXTO del error —Msg 201 / `cl_errores` literal— como el campo `mensajeDebug` a NIVEL WRAPPER de la response —`null` en exito en AMBOS canales (REST wrapper Java, gRPC `StringValue` no-seteado + grpcurl `-emit-defaults`)—, NO dentro de `data`; es la UNICA excepcion aprobada a SP-007; no exponer ninguna otra variable interna)
- `.claude/rules/codigo-limpio.md` — cumplir **CLN-011** (NO escribas comentarios propios en DTOs/proto/mappers: ni de correccion, ni de seccion, ni javadoc descriptivo. Solo comentarios heredados LITERALMENTE del SP + marcas `// Vault`/`// DML`, y las marcas de mapeo `// @<param>` que una regla exija explicitamente para el pipeline QA. Los comentarios narrativos disparan Sonar de bloques duplicados)

## Referencias

- `.claude/references/openapi-standard.md` — baseline OAS 3.1, headers, RFC 7807
- `.claude/templates/request-dto-canonico.md` — **PLANTILLA OBLIGATORIA del request DTO** (record + @JsonProperty en
  field + Presence<T> solo en obligatorios que el SP distingue ausente/null). COPIARLA; no improvisar la forma.

## Spring Boot 4.x — APIs Eliminadas y Relocaciones (CRITICO)

### APIs ELIMINADAS en Spring Boot 4 / Spring 7 (NO EXISTEN, NO USAR):
- `RestTemplate` → usar `RestClient` (`org.springframework.web.client.RestClient`)
- `AsyncRestTemplate` → eliminado
- `WebMvcConfigurerAdapter` → eliminado (usar `WebMvcConfigurer` directamente)

### Relocaciones de paquetes:
Spring Boot 4.0.x reorganizo paquetes respecto a 3.x. NO confiar en imports de memoria.
Antes de escribir cualquier import de `org.springframework.boot.*`, verificar que la clase existe en el JAR real con:

```bash
source ~/.sdkman/bin/sdkman-init.sh && find ~/.m2/repository/org/springframework/boot -name "*.jar" -path "*4.0.6*" | xargs jar tf 2>/dev/null | grep "<NombreClase>"
```

Relocaciones conocidas:
- `org.springframework.boot.web.embedded.tomcat.*` -> `org.springframework.boot.tomcat.servlet.*`
- `org.springframework.boot.web.embedded.netty.*` -> `org.springframework.boot.netty.*`
- `org.springframework.boot.web.server.WebServerFactoryCustomizer` se mantiene igual
- `org.springframework.boot.autoconfigure.web.servlet.*` puede haber movido a `org.springframework.boot.tomcat.autoconfigure.servlet.*`

Regla: Si el build falla con `cannot find symbol` en una clase Spring Boot, buscar la ubicacion real con `jar tf` y corregir ANTES de reportar PASS. Nunca reportar PASS sin compilacion exitosa.

## Instrucciones

0. **SP-007 PARIDAD ESTRICTA (ANTES DE CREAR CUALQUIER DTO)**:
   - Leer la firma `create proc` del SP en sybase-local/. Contar parametros de entrada (excluir @t_debug, @t_file por COB-007).
   - Contar parametros de salida: SOLO los declarados con `OUTPUT` + el return status.
   - El request DTO tiene EXACTAMENTE esos params de entrada. El `data` del response wrapper tiene EXACTAMENTE esos params de salida OUTPUT (el return status va en `codigoRetorno` y el texto del error en `mensajeDebug`, ambos a nivel wrapper — ver "Estructura de response: wrapper SpResponse<T>").
   - Si el SP solo devuelve `return <int>`, el wrapper lleva `codigoRetorno` (+ `mensajeDebug` por COB-008) y `data` puede ser vacio/sin campos OUTPUT.
   - PROHIBIDO agregar campos derivados de variables internas del SP (@v_xxx). La migracion es traduccion, no mejora.
   - Ante duda: activar human-gate. NUNCA inventar campos.
0.1. **PARIDAD INVERSA DE VALIDACIONES (SP-007 inverso / API-007) — ANTES DE ANOTAR CUALQUIER DTO O ESCRIBIR EL OPENAPI**:
   - PROHIBIDO declarar en el DTO de request (`@Size`, `@NotNull`, `@NotBlank`, `@Pattern`, `@Min`, `@Max`) o en el OpenAPI (`maxLength`, `required`, `pattern`) una restriccion que el SP NO impone. El micro NO debe cortar con HTTP 400 una entrada que el SP SI procesa.
   - Toda validacion declarada debe tener fuente trazable en el tipo/longitud real del parametro del SP (la firma `create proc` en sybase-local/ y/o interfaces.json). Si el SP acepta un valor, el micro lo deja pasar hasta que el SP produzca su codigo funcional (ej: codigo de negocio del SP), NO lo rechaza antes con 400.
   - Caso real (bug QA): `@Size(max=1)` / `maxLength: 1` en `tipo_referencia` rechazaba 2 chars que el SP aceptaba; `@NotBlank` en `numcta_emp` devolvia 400 donde el SP devolvia el codigo de negocio 31004. Ambos violan la paridad inversa: convirtieron entradas validas-para-el-SP en errores HTTP del micro.
   - Excepcion legitima: SI se valida exactamente lo que el SP SI valida (es raro; debe justificarse contra la logica/firma del SP). Un `@Size(max=N)` solo es valido si el parametro del SP es `char(N)`/`varchar(N)` y truncarlo/rechazarlo replica al SP; un `@NotNull`/`@NotBlank` solo si el SP exige presencia (no si simplemente devuelve un codigo de negocio ante el valor faltante).
   - Mantener coherencia OpenAPI↔DTO: una sola fuente de verdad del contrato (API-011). Si el DTO no anota la restriccion, el OpenAPI tampoco; si el OpenAPI la declara, debe estar respaldada por el SP igual que el DTO.
1. Controllers REST que llaman a los use cases via port in
2. Servicios gRPC que llaman a los MISMOS use cases (paridad)
3. DTOs de request/response derivados de interfaces.json (tipos SP → tipos API)
4. OpenAPI 3.1.x:
   - jsonSchemaDialect declarado
   - Headers X-Request-Id y X-Correlation-Id documentados en spec pero NO como @RequestHeader en controller
   - Idempotency-Key como @RequestHeader(required=false) en POST financieros
   - Errores application/problem+json (RFC 7807)
   - Healthchecks /health, /health/live, /health/ready con security: []
5. Escalas de respuesta: 2 decimales para monetarios si contrato/cliente lo espera
6. Paridad REST ↔ gRPC obligatoria (mismos campos de DOMINIO, mismos codigos)
7. Sanitizar variables en logs y HTTP headers
8. **Headers de trazabilidad**: X-Request-Id y X-Correlation-Id los maneja el CorrelationIdFilter (creado por micro-seguridad-resiliencia) de forma transparente. El controller NO los recibe como @RequestHeader. Solo Idempotency-Key va en el controller si el endpoint es financiero.

## Diseno del .proto (API-013 — CRITICO)

El .proto es un contrato de DOMINIO puro. Representa la interfaz del SP traducida a gRPC. PROHIBIDO contaminar con conceptos HTTP/REST:

### Lo que VA en el .proto:
- Campos que mapean a params de entrada del SP (request message)
- Campos que mapean a params OUTPUT del SP (response message)
- Return code del SP como campo de la response

### Lo que NO VA en el .proto:
- `request_id` — es gRPC metadata, no dato de negocio
- `correlation_id` — es gRPC metadata, no dato de negocio
- `idempotency_key` — es gRPC metadata, no dato de negocio
- `ProblemDetail` message — RFC 7807 es concepto REST; gRPC tiene Status nativo
- Cualquier campo que no exista como parametro formal del SP

### Como se maneja trazabilidad en gRPC:
- micro-seguridad-resiliencia crea un `GrpcCorrelationInterceptor` (ServerInterceptor) que:
  1. Lee metadata keys `x-request-id` y `x-correlation-id` del request
  2. Los pone en MDC para logging
  3. Los devuelve como trailing metadata en la response
- El servicio gRPC (@GrpcService) NO recibe ni devuelve estos valores como campos del message.

### Como se manejan errores en gRPC:
- **Error funcional** (SP lanzo error): Completar la response con los campos de error que el SP define como OUTPUT (ej: `error`, `detalleError`, `mensaje`). Usar `onNext` + `onCompleted`.
- **Error tecnico** (infra, timeout, BD caida): Usar `responseObserver.onError(Status.INTERNAL.withDescription(...).asRuntimeException())`.
- **Validacion fallida** (input invalido): Usar `responseObserver.onError(Status.INVALID_ARGUMENT.withDescription(...).asRuntimeException())`.
- NUNCA meter un message `ProblemDetail` en el proto.

### Ejemplo correcto (referencia: cpas-mso-genera-nd-nc-automatica-aho):
```protobuf
// Solo campos del SP
message MiRequest {
  string cuenta = 1;     // @i_cuenta
  int32 moneda = 2;      // @i_moneda
  string valor = 3;      // @i_valor
}

import "google/protobuf/wrappers.proto";

// Response wrapper (patron SpResponse<T>): codigoRetorno + mensajeDebug + data
// Campos nullables con WRAPPERS Int32Value/StringValue para PRESERVAR null (API-015): el mapper setea el wrapper SOLO si
// el valor no es null; un wrapper seteado sale PLANO en gRPC-JSON real (oError: 0, NO {"value":0}), y uno no-seteado sale
// como el campo SIEMPRE presente con valor null cuando grpcurl usa -emit-defaults.
// codigoRetorno nunca es null -> escalar int32 a secas.
message MiResponse {
  int32 codigoRetorno = 1;                        // return status del SP (nunca null)
  google.protobuf.StringValue mensajeDebug = 2;   // texto del error (COB-008); null en exito -> wrapper no-seteado
  MiData data = 3;                                // params OUTPUT del SP
}
message MiData {
  google.protobuf.Int32Value oError = 1;          // @o_error (null del SP -> wrapper no-seteado -> null en JSON)
  google.protobuf.Int32Value oRegAProc = 2;       // @o_reg_a_proc (null -> null)
}
```

### Ejemplo INCORRECTO (NO hacer):
```protobuf
message MiRequest {
  string cuenta = 1;
  string request_id = 10;      // MAL: es metadata gRPC
  string correlation_id = 11;  // MAL: es metadata gRPC
  string idempotency_key = 12; // MAL: es metadata gRPC
}

message MiResponse {
  int32 codigo = 1;
  string correlation_id = 3;   // MAL: es trailing metadata
  ProblemDetail error = 4;     // MAL: concepto REST
}
```

### `optional` para strings donde '' != ausente — SOLO en REQUEST (API-014)
En proto3 un `string` escalar NO distingue `''` de ausente (ambos llegan como `""`). Si el SP trata `''` como un valor de
ENTRADA con semantica propia distinta de NULL/omitir (ej. `frm_pagcob_deb` usado como llave `IN(...)`), el campo de
REQUEST DEBE ser `optional string` — asi el `has_<campo>()` de proto3 permite no colapsar ''<->null y la paridad con el
JSON REST de request se mantiene. Regla practica: si al leer el SP ves que `''` y "no enviar el param" producen resultados
distintos → `optional` en el request. **`optional` es SOLO para REQUEST.** En la RESPONSE NO se usa `optional` scalar
(omite el campo cuando es null): los campos de salida nullables usan WRAPPERS `Int32Value`/`StringValue` (ver API-015 y la
seccion siguiente).

### gRPC: campo `optional` OMITIDO en un obligatorio con guard de presencia -> null que FLUYE, NUNCA `-6` (SP-019, banco 2026-07-16, commit NCBE-661)
Un obligatorio con guard de presencia (los que en REST usan `Presence<T>` para distinguir ausente/null/valor, ej.
`tipcta_emp`, `numcta_emp`, `valor_debito`, `valor_ordenado`, `valor_comision`) se comporta DISTINTO en gRPC: el wire de
proto3 solo tiene "ausente" o "presente-con-valor" (no transporta "presente-en-NULL"). Por decision del banco, en gRPC un
campo `optional` OMITIDO se trata como **NULL que FLUYE al camino funcional del SP** (codigo 120000/31004/...), **NUNCA**
como "ausente -> `-6`". Concretamente: **el mapper gRPC de entrada marca `enviado=true` SIEMPRE** para estos campos, y lee
el valor con `hasXxx() ? getXxx() : null`. Asi, por gRPC NO se puede provocar el `-6 not supplied` de esos campos (eso
solo pasa por REST, que SI distingue ausente via `Presence<T>`). **La paridad REST/gRPC en estos campos NO se exige** (el
banco lo decidio: REST no sufre el problema y no debe cambiar). Caso real TC37/TC38: `tipcta_emp`/`numcta_emp` omitidos en
gRPC daban `-6` erroneo donde el SP directo y REST dan 120000/31004. Detalle completo: regla SP-019.

### NULL en la response: PRESERVADO en AMBOS canales (API-015, banco 2026-07-09)
Un campo OUTPUT que el SP puede devolver NULL se emite como `null` en REST y en gRPC (paridad total):
- **REST:** se emite `null`, NUNCA `0`/`""`/default. El campo del DTO REST es TIPO WRAPPER (`Integer`/`Double`), no
  primitivo, y el mapper REST NO rellena un default cuando la lib-padre devuelve null. (Caso que origino la regla:
  `error`/`reg_a_proc` salian `0` en REST donde el SP dejaba NULL — TC25/26/27.)
- **gRPC:** se emite `null` con WRAPPERS `google.protobuf.Int32Value`/`StringValue` (requiere
  `import "google/protobuf/wrappers.proto"`), NO `optional` scalar (que OMITE el campo cuando es null), NO escalar-a-secas
  con coalescing. El mapper gRPC setea el wrapper SOLO si el valor NO es null (`if (x != null)
  builder.setOError(Int32Value.of(x))`); un wrapper seteado sale PLANO en el gRPC-JSON real (`oError: 0`, NO
  `{"value":0}` — el `{value}` que se veia en Postman es artefacto del render del arbol crudo del mensaje, NO la
  serializacion protojson que usa grpcurl), y un wrapper no-seteado sale como el campo SIEMPRE presente con valor `null`
  (`oRegAProc: null`) cuando grpcurl usa la bandera **`-emit-defaults`** (`EmitUnpopulated` de protojson). Sin
  `-emit-defaults` protojson omite el wrapper no-seteado; por eso la invocacion en vivo la usa. Un `0`/`""` EXPLICITO
  (valor real) SI se emite. El sub-message `data` siempre se construye, pero sus campos wrapper solo se setean si no son
  null. `codigoRetorno` (nunca null) sigue escalar `int32` a secas.

## Nombre JSON externo del `@JsonProperty` — derivado MECANICAMENTE del param del SP (API-017 — CRITICO)

El nombre del FIELD Java sigue SP-017 (camelCase con prefijo: `iOrdenEmpresa`, `sSsn`, `oError`), PERO el nombre JSON
EXTERNO que ve el cliente (`@JsonProperty("...")`) NO es libre: se deriva MECANICAMENTE del param del SP asi (para que
TODOS los micros expongan el mismo estilo y no queden inconsistentes entre si):

- **REQUEST (params de ENTRADA):** `@JsonProperty` = nombre del param en **snake_case CONSERVANDO el prefijo** (solo se
  quita el `@`): `@i_orden_empresa` -> `@JsonProperty("i_orden_empresa")`, `@s_ssn` -> `@JsonProperty("s_ssn")`,
  `@t_corr` -> `@JsonProperty("t_corr")`. **SE CONSERVA el prefijo** `i_`/`s_`/`t_`/`p_`/`e_` — NO lo quites: si el SP
  tiene el mismo nombre base con dos prefijos (`@s_ssn` + `@i_ssn`) quitarlo los colisiona a ambos `"ssn"`.
- **RESPONSE — OUTPUT escalares del SP** (`@o_*`, return status): `@JsonProperty` = **camelCase con prefijo (SP-017)**:
  `@o_error` -> `@JsonProperty("oError")`, `@o_reg_a_proc` -> `@JsonProperty("oRegAProc")`. Wrapper `SpResponse` =
  `codigoRetorno`/`mensajeDebug`.
- **RESPONSE — COLUMNAS de un RESULTSET/cursor** (un `select col1,col2` que el SP devuelve como filas, NO OUTPUT escalares):
  conservan su **nombre de DOMINIO** (`registros`, `firmantes`, `identificacion`), NO se les fuerza prefijo.

PROHIBIDO renombrar por significado o elegir la capitalizacion "a gusto". Ejemplo — `sp_ah_retiro_rc` (params `@s_ssn`,
`@i_cta`, `@t_trn` + OUTPUT `@o_nombre`):
```java
public record RetiroRequestDto(
    @JsonProperty("s_ssn")  Integer sSsn,     // field SP-017 / JSON snake+prefijo
    @JsonProperty("i_cta")  String  iCta,
    @JsonProperty("t_trn")  Integer tTrn) {}
// response OUTPUT: @JsonProperty("oNombre") Integer oNombre;
```
> **Excepcion historica bem-mso-debito-credito-empresa-pagos:** su request expone snake SIN prefijo (`orden_empresa`) —
> aprobado por QA en produccion, NO se re-alinea. Es la UNICA excepcion; micro NUEVO usa snake CON prefijo.

**FORMA CANONICA — copia la plantilla `.claude/templates/request-dto-canonico.md`** (referencia viva: bem-mso
`DebcredPagosEmpresaRequestDto`). El request DTO es SIEMPRE un `record` con `@JsonProperty` en el field + `Presence<T>`
solo en los obligatorios que el SP distingue ausente/null; el resto tipo directo. PROHIBIDO `class` con Lombok
`@Getter/@Setter`. No improvises la forma: sigue la plantilla al pie.

**`@JsonProperty` SIEMPRE en el FIELD, NUNCA en el setter (la suite QA lo exige).** El DTO de request es un `record` con
el `@JsonProperty` en el componente. NO uses el patron Lombok clase-con-setters donde el `@JsonProperty` y el flag
`xEnviado` viven en el setter: la herramienta de QA lee los FIELDS del DTO para mapear al param del SP, y si la anotacion
esta en el setter lee el field crudo camelCase (`iCta`) -> 0 payloads -> el micro no se puede probar (caso real deposito).
Para la **deteccion de presencia (SP-019)** en el micro usa `Presence<T>` como TIPO del componente (wrapper Jackson 3) +
`PresenceModule` en `JacksonConfig` (patron consulta-firmante/bem) — NO el flag `xEnviado`-por-setter (ese es patron de
LIBRERIA). Ejemplo obligatorio de deposito:
```java
public record DepositoRequestDto(
    @JsonProperty("s_ssn") Presence<Integer> sSsn,   // obligatorio con guard de presencia
    @JsonProperty("i_cta") Presence<String>  iCta,
    @JsonProperty("s_error") Integer sError) {}       // no-obligatorio: tipo directo
```

## Serializacion de los DTOs REST: evitar propiedad DUPLICADA en campos SP-017 (API-016 — CRITICO)

Todo DTO REST (request y **sobre todo response/`data`**) cuyos campos espejan params del SP con naming SP-017 de PREFIJO
—camelCase que empieza por `<minuscula><Mayuscula>`: `oError`, `oRegAProc`, `oNombre`, `iCta`, `tTrn`...— DEBE anotarse a
NIVEL DE CLASE con:

```java
import com.fasterxml.jackson.annotation.JsonAutoDetect;

@JsonAutoDetect(getterVisibility = JsonAutoDetect.Visibility.NONE, fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class MiData {
    @JsonProperty("oError")
    private Integer oError;      // @o_error (SP-017)
    @JsonProperty("oRegAProc")
    private Integer oRegAProc;   // @o_reg_a_proc (SP-017)
    // ... getters Lombok @Getter ...
}
```

**Por que (bug real verificado en produccion):** con Lombok `@Getter`, un campo `oNombre` genera `getONombre()`. Jackson
descubre la propiedad DOS veces: (1) por el `@JsonProperty("oNombre")` del field y (2) por el getter `getONombre()`, que
Jackson infiere como propiedad `ONombre` (mayuscula inicial). Resultado: el JSON sale DUPLICADO —
`{"oNombre":null, ..., "ONombre":null}`— y ROMPE el contrato. Ocurre con TODO campo SP-017 de prefijo
(`<minuscula><Mayuscula>...`).

**Fix (SIEMPRE en estos DTOs):** `@JsonAutoDetect(getterVisibility = NONE, fieldVisibility = ANY)` hace que Jackson
serialice SOLO por los fields (cada uno con su `@JsonProperty`) e IGNORE los getters Lombok -> una sola propiedad por
campo, con el nombre EXACTO del param del SP.

- El `@JsonProperty("...")` en el field POR SI SOLO **NO basta**: no suprime la propiedad inferida del getter (Jackson las
  fusiona/emite ambas). La anotacion a nivel de clase es obligatoria.
- **PROHIBIDO "arreglarlo" renombrando el campo** (ej. `oNombre` -> `nombre`): romperia SP-017 (el naming camelCase con
  prefijo derivado mecanicamente del param del SP es obligatorio). El campo conserva su nombre SP-017; se suprime la
  deteccion por getter, no el nombre.

## Estructura de response: wrapper `SpResponse<T>` (CRITICO — patron cpas-mso-genera-nd-nc-automatica-aho)

La respuesta se estructura como un wrapper generico `SpResponse<T>` con `data` anidado, MISMA estructura para exito Y para
errores de dominio (no usar wrappers diferentes para 200 vs 422). El wrapper Java:
```java
@Getter @Setter @AllArgsConstructor @NoArgsConstructor
public class SpResponse<T> {
    private int codigoRetorno;   // return status del SP
    private String mensajeDebug; // texto del error (COB-008); null en exito (REST)
    private T data;              // DTO con los params OUTPUT del SP
}
```

**Patron correcto** — error de param obligatorio (422). IDENTICO en REST y gRPC (ambos preservan null; gRPC via wrappers `Int32Value`/`StringValue` + grpcurl `-emit-defaults`):
```json
{
  "codigoRetorno": -6,
  "mensajeDebug": "Procedure sp_debcred_empresa expects parameter @i_fecha_proceso, which was not supplied.",
  "data": { "oError": null, "oRegAProc": null }
}
```

En gRPC ese `null` se logra con el wrapper (`Int32Value`/`StringValue`) no-seteado + grpcurl `-emit-defaults` (mismo JSON
que REST). Un `0` EXPLICITO (ej. exito `oError: 0`) se emite seteando el wrapper con `Int32Value.of(0)`, que sale plano
`oError: 0` en el gRPC-JSON real (sin `{"value":0}`):
```json
{
  "codigoRetorno": 0,
  "mensajeDebug": null,
  "data": { "oError": 0, "oRegAProc": null }
}
```

- `codigoRetorno` = return status del SP; `mensajeDebug` = texto del error (COB-008), a nivel wrapper (NO dentro de
  `data`); `data` = DTO con los params OUTPUT del SP (nombres SP-017: `@o_error`->`oError`, etc.).
- En REST se usa el MISMO `SpResponse<T>` en 200 y 422. El GlobalExceptionHandler para errores de dominio devuelve el
  mismo tipo (no application/problem+json para errores SP — eso es solo para errores HTTP 400/401/429/500).

**OpenAPI spec** — El response 200 Y el response 422 referencian el MISMO schema wrapper (con `data` via `$ref`).
Los error responses HTTP (400, 401, 429, 500) SI usan application/problem+json.

## Headers en TODAS las responses (incluido errores)

X-Correlation-Id DEBE estar presente en TODAS las responses, incluidas:
- 200 OK
- 422 (errores de dominio)
- 401 Unauthorized
- 400 Bad Request
- 500 Internal Server Error

Documentar el header en TODOS los responses del OpenAPI spec, no solo en 200.

## Al finalizar

1. Ejecutar `.claude/scripts/quality/scan.sh` sobre el codigo que produjiste y corregir hallazgos
2. Ejecutar `bash .claude/scripts/log-history.sh "micro-contratos" "<PASS|FAIL|BLOCKED>" "<resumen corto>"`

## BLOCKED si

- Interfaz del SP no mapea claramente a un endpoint (activar human-gate)
- Use cases no creados aun

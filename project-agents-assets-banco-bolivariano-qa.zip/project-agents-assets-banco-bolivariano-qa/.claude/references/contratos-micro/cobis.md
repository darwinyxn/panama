# COBIS

## COB-001: Codigo COBIS no se refactoriza
Bloque: LIBRERIA. Regla: SP en base `cobis` y SPs del catalogo COBIS nativo se invocan como SP legacy (patron exec con named params per RES-007). No reimplementar su logica en Java. Ver references/cobis-catalog.md para lista completa.
Aplica a: lib-constructor
Verifica: lib-equivalencia
FAIL si: logica de SP COBIS nativo reimplementada en Java en vez de llamada SP

## COB-002: sp_cerror como exec directo fail-safe (dentro de la libreria)
Bloque: LIBRERIA. Regla: sp_cerror se mantiene como llamada a SP via exec directo (no SimpleJdbcCall). Es fail-safe: try-catch interno absorbe excepciones (raiserror de sp_cerror) + CB como segunda red. No interrumpe flujo si falla. (v5: sp_cerror es exec legacy; lo hace la **libreria misma**, NO el micro — la lib es Spring autonomo y hace todo su I/O.)
Aplica a: lib-constructor
Verifica: lib-equivalencia
FAIL si: sp_cerror reimplementado como INSERT directo, eliminado, o sin try-catch fail-safe

## COB-003: cl_errores consultado dinamicamente
Bloque: LIBRERIA. Regla: Mensajes de error de cl_errores se obtienen con SELECT en runtime. PROHIBIDO hardcodear el mensaje.
Aplica a: lib-constructor
Verifica: lib-equivalencia
FAIL si: mensaje de cl_errores como String literal en codigo Java

## COB-004: Pares begin/end preservados
Bloque: LIBRERIA. Regla: Si SP usa pares sp_begin_*/sp_end_*, mantenerlos como invocaciones SP legacy trazables.
Aplica a: lib-constructor
Verifica: lib-equivalencia
FAIL si: par begin/end del SP eliminado sin BLOCKED justificado

## COB-005: Errores remotos preservados
Bloque: LIBRERIA. Regla: Variables @s_org_err, @s_error, @s_sev, @s_msg se preservan con semantica equivalente y trazabilidad.
Aplica a: lib-constructor
Verifica: lib-equivalencia
FAIL si: error remoto del SP ignorado o sin semantica equivalente en Java

## COB-006: Checklist H01-H24 obligatorio
Bloque: LIBRERIA. Regla: Cada SP debe registrar deteccion/no deteccion de los 24 hallazgos COBIS. Detectado implica implementacion, prueba o BLOCKED. Ver references/cobis-catalog.md seccion H01-H24.
Aplica a: lib-analisis-1-secciones, lib-constructor
Verifica: lib-equivalencia
FAIL si: hallazgo COBIS detectado sin evidencia de cierre (implementado/probado/blocked)

## COB-007: Parametros de debug/logging COBIS no se exponen en API
Bloque: MICRO. Regla: Parametros del SP padre cuyo unico uso es alimentar el sistema de debug/logging de la plataforma COBIS (sp_begin_debug, sp_end_debug, o pasados como @t_debug/@t_file a SPs hijos) no se exponen en la API del micro ni se requieren como input. El micro resuelve observability internamente. sp_cerror solo requiere: nombre origen (t_from), codigo error (i_num) y mensaje (i_msg) — los valores se generan internamente en el adapter.
**ALCANCE — frontera LIBRERIA vs MICRO (J3, NCBE-838 vs NCBE-1006):** COB-007 oculta @t_debug/@t_file SOLO en la **API del
MICRO** (request DTO / OpenAPI / proto). A nivel **LIBRERIA rige SP-007 (paridad estricta de firma):** si la firma FORMAL
del SP-entry declara @t_debug/@t_file (con o sin default), la libreria DEBE modelarlos como parametros de entrada con esos
defaults (SP-013) y propagarlos al exec del SP hijo — NUNCA hardcodearlos en el adapter (NCBE-838: faltaban en
pa-cte-pvalida-ndnc). Si el SP-entry NO los declara en su firma, NO deben aparecer en la libreria (NCBE-1006:
sp_debcred_empresa no los declara -> se removieron; se habian colado por copiar el patron del SP hermano
sp_graba_tran_servicio). Es decir: la presencia de @t_debug/@t_file en la LIB depende EXCLUSIVAMENTE de la firma real del
SP-entry (verificada con sp_help), no de una plantilla.
Aplica a: lib-analisis-2-interfaces, lib-constructor, micro-facade, micro-contratos
Verifica: micro-check-contratos, lib-equivalencia
FAIL si: parametro @t_debug o @t_file expuesto en request DTO, OpenAPI o proto del MICRO; o la LIBRERIA NO modela
@t_debug/@t_file cuando la firma del SP-entry SI los declara (NCBE-838), o los modela/hardcodea cuando la firma NO los
declara (NCBE-1006)

## COB-008: Campo del TEXTO del error en la response — `debug` en la lib-padre, expuesto como `mensajeDebug` por el micro (patron OBLIGATORIO de TODO micro-padre; excepcion aprobada a SP-007/COB-007)
Bloque: MICRO. Regla (decision del banco 2026-06-30, via Nicolas Rodriguez — sobre-escribe la fidelidad estricta; forma de
exposicion actualizada por Arquitectura 2026-07-08; ALCANCE GENERALIZADO 2026-07-30 tras repetirse el hallazgo en 3
micros): la respuesta incluye un campo `String` (SALIDA) con el MENSAJE de texto del error, porque los TC de error hoy
devuelven solo codigos numericos mudos. Es una EXCEPCION EXPLICITA y APROBADA a SP-007 (paridad estricta) y COB-007
—cuando el SP no entrega texto a su llamador (solo OUTPUT int; `@w_msg`/vars internas; `sp_cerror` solo loguea en
`cl_errores`), bajo fidelidad estricta seria null— pero el banco prioriza el diagnostico.
> **ESTO NO ES EXCLUSIVO DE UN MICRO — es el comportamiento CORRECTO de TODOS (generalizacion 2026-07-30).** El banco lo
> pidio en `debcred`, `retiro-rc` y `depositosl-rc` por igual; se trata como PATRON, no como excepcion de un SP. La
> **referencia viva** es `sp-debcred-empresa-utils` + su micro `bem-mso-debito-credito-empresa-pagos` (unico que salio
> bien a la primera): copiar su forma. Los micros retiro/deposito NACIERON con `mensajeDebug=null` por leer esta regla
> como "solo debcred" — de ahi la generalizacion. TODA lib-padre expone el texto del error y TODO micro lo publica.
**Nombre y ubicacion del campo (forma `SpResponse<T>`):** la lib-padre lo devuelve como `debug` en su result (ej.
`ResultadoDebcredEmpresa.debug()`, `RetiroRcResult.mensajeDebug()`, `DepositoslRcResult.mensajeDebug()`); el MICRO lo
EXPONE como **`mensajeDebug` a nivel del wrapper de la response** (hermano de `codigoRetorno`, fuera del objeto `data`),
NO como `debug` dentro de `data`. **Fuente del texto (LITERAL, 0 modificaciones, ni espacios — SP-004 aplica al texto):**
- `return -6` (param obligatorio omitido): texto exacto del `Msg 201` de Sybase ("Procedure <sp> expects
  parameter @X, which was not supplied.").
- codigos funcionales: texto LITERAL de `cobis..cl_errores` (consultado en runtime, COB-003). Ej. debcred 122004 =
  "Error al actualizar estado de total orden."
- exito o sin info: se emite `null` en AMBOS canales (API-015): en REST el campo wrapper Java queda null; en gRPC
  `mensajeDebug` es `StringValue` y queda no-seteado -> sale `null` con grpcurl `-emit-defaults` (NO se coacciona a `""`).
**Patron de implementacion (copiar de debcred):** la lib-padre define un puerto `MensajeErrorPort` implementado por un
`ClErroresLegacyAdapter` (exec fail-safe a `cobis..cl_errores`, COB-003) que resuelve el texto; el Result gana el campo
`debug`/`mensajeDebug` poblado en CADA salida de error (funcional via `cl_errores`; `-6` con el `Msg 201` literal); en el
micro, el mapper inbound (o el use-case) propaga `result.debug()` al `SpResponse` — **PROHIBIDO** armar el wrapper con un
`null` literal en el campo de texto (`new SpResponse<>(rc, null, datos)` fue el bug exacto de retiro/deposito).
Alcance: TODO micro-padre cuyo SP raiz no entrega texto a su llamador (era "solo debcred" hasta 2026-07-30). Es cambio de
contrato Java -> propaga lib-padre + micro (REST/gRPC/OpenAPI). El campo del texto del error (`debug` en la lib /
`mensajeDebug` en el micro) es el UNICO que se permite exponer sin param formal del SP; NO habilita exponer otras
variables internas.
Aplica a: lib-constructor (lib-padre), micro-facade, micro-contratos
Verifica: micro-check-contratos, lib-equivalencia
FAIL si: se agrega CUALQUIER otro campo de salida sin fuente en el SP amparandose en esta excepcion (solo el campo del
texto del error esta aprobado); o el texto no es LITERAL de `Msg 201`/`cl_errores` (modificado/traducido/resumido); o se
emite `""` en vez de `null` cuando no hay error en cualquiera de los dos canales (REST, o gRPC `StringValue` no-seteado +
`-emit-defaults`, API-015); o el micro lo expone dentro de `data` en vez de `mensajeDebug` a nivel wrapper; o
**`mensajeDebug` sale `null` en un camino de ERROR** (returnCode != 0) —es decir la lib-padre NO expone el texto o el
micro arma el wrapper con `null` literal en vez de propagar `result.debug()`— (bug real retiro/deposito 2026-07-29: el
codigoRetorno coincidia con el SP pero el texto salia null en los 19/13 casos de error)

---
name: query-plan
description: Punto de entrada para generar Query Plan de un SP/cono migrado. Dirige al agente-queryplan, que construye el request contractual y ejecuta el pipeline canonico. No ejecuta tsql ni construye SQL manualmente.
when_to_use: Al necesitar la evidencia de Query Plan (plan de ejecucion + IO) de un SP ya migrado, para entrega Banco. Requiere librerias elegibles declaradas explicitamente por el operador/Gengis.
disable-model-invocation: true
argument-hint: hu=<HU> microservice=<micro> root_sp=<base..sp> libraries=<inventario explicito>
allowed-tools: Read Glob Grep Bash
---

Generar Query Plan para: `$ARGUMENTS`

## Que hace este skill

Delega en `agente-queryplan` (`.claude/agents/agente-queryplan.md`) el flujo completo:

```
HU / microservice / root_sp / librerias elegibles
    -> agente-queryplan construye el request contractual
    -> qp_pipeline.py pipeline --request <request.json> --mode run --allow-live-sybase
    -> QUERYPLAN_RESULT (fuente unica del veredicto)
    -> reporte corto (PASS / BLOCKED / NOT_APPLICABLE)
```

Este skill **no** reimplementa ninguna fase del motor. El pipeline (`.claude/docs-qa/inputs/scripts/
queryplan/qp_pipeline.py`) ya ejecuta discovery, reconciliacion, prepare, preflight, la corrida viva,
el empaquetado y la validacion — ver `README.md` del tooling para el detalle tecnico de cada etapa.

## Prerequisito

Librerias elegibles declaradas explicitamente (aunque sea una lista vacia a proposito). Sin esto el
pipeline bloquea con `BLOCKED_REQUEST_INVALID` — este skill no intenta inferir elegibilidad desde el
root SP, discovery, SP hijos ni el nombre del microservicio.

## Como invocar

Ver `agente-queryplan.md` para la forma exacta de los inputs (`hu`, `microservice`, `root_sp`,
`eligible_libraries`, y el modo avanzado `request=<archivo.json>` para recuperacion/diagnostico).

## Resultado

El agente reporta segun lo que diga `QUERYPLAN_RESULT` (`status`, `stage`, `reason`, `detail`,
`bank_ready`, `delivery`, `action_required`, entre otros) — nunca interpretando stdout libre. Ver
`README.md` del tooling, seccion `QUERYPLAN_RESULT`, para el contrato completo de campos.

## Limites

- No ejecutar `tsql` ni construir SQL/showplan/IO a mano — eso es responsabilidad exclusiva del
  pipeline.
- No generar manifest/ZIP manualmente.
- No correr `validate` por separado en el flujo normal (el modo `run` ya lo encadena).
- Los criterios de clasificacion Banco (`Table Scan`, `Index Scan`, `Positioning by Forward Scan`,
  `Cartesian Product`, `Using Worktable`, `logical_total > 10000`, `physical_total > 1000`) los
  aplica el motor; ver el README del tooling si se necesita el detalle completo del criterio.

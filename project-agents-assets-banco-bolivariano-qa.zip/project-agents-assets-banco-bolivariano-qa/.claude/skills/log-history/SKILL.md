---
name: log-history
description: Registra una entrada en el historial del agente. Usar al terminar cada ejecucion (PASS, FAIL o BLOCKED).
argument-hint: "<agent-id> <status> <mensaje>"
---

# log-history

## Objetivo

Registrar que hizo el agente en esta ejecucion. Se llama UNA VEZ al final de cada ejecucion del agente.

## Comando

```bash
.claude/docs-qa/inputs/scripts/log-history.sh "<agent-id>" "<status>" "<mensaje>"
```

## Parametros

| Parametro | Valores | Ejemplo |
|-----------|---------|---------|
| agent-id | Tu ID de agente | A-2.3 |
| status | PASS, FAIL, BLOCKED | PASS |
| mensaje | 1 linea breve de lo que hiciste | Cree 5 adapters JDBC para ah_cuenta y ah_tran_monet |

## Ejemplos

```bash
.claude/docs-qa/inputs/scripts/log-history.sh "A-2.3" "PASS" "Cree 5 adapters JDBC, queries validadas contra Sybase"
.claude/docs-qa/inputs/scripts/log-history.sh "A-3.4" "FAIL" "Step 3 de S01: falta llamada a sp_cerror code 41025"
.claude/docs-qa/inputs/scripts/log-history.sh "A-2.6" "BLOCKED" "Falta adapter para ah_tran_monet, A-2.3 no lo creo"
```

## Reglas

- Llamar al FINAL de la ejecucion, no al inicio
- Status siempre es PASS, FAIL o BLOCKED
- Mensaje en 1 linea, breve y concreto (que hiciste o que fallo)
- El script agrega timestamp automaticamente
- El script mantiene max 30 lineas (borra las mas antiguas)
- No editar .claude/history/ manualmente — siempre usar este script

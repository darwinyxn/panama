---
name: skill-qa-uml-00-pdf-generator
author: Migration Team
refactored_by: Juan Pablo Sanabria Moscoso
refactored_at: 2026-06-22
description: Exporta archivos .puml a PDF via SVG intermedio (PlantUML -> SVG, Python svglib+reportlab -> PDF) y consolida en uml-full-report.pdf con pypdf. La ruta directa -tpdf de PlantUML falla en este entorno y deja archivos vacios. Reporta BLOCKED si PlantUML o las librerias Python no estan disponibles o si algun .puml tiene errores de sintaxis.
when_to_use: Despues de que el script uml_gen genera los archivos .puml, para producir los PDFs individuales y el PDF consolidado uml-full-report.pdf. Invocado por agente-qa-uml-00-orquestador.
argument-hint: [directorio-uml]
allowed-tools: Bash
---

Exportar .puml a PDF y consolidar en uml-full-report.pdf en: `$ARGUMENTS`

## Prohibicion absoluta

NUNCA usar los tools `Write` o `Edit` para crear archivos `.pdf`. Un PDF creado con `Write` es un archivo de texto con extension `.pdf`, no un PDF binario valido. Esta prohibicion es bloqueante.

## Por que SVG como intermediario

La exportacion directa de PlantUML a PDF (`-tpdf`) falla en este entorno y deja archivos vacios o invalidos. La ruta confirmada que funciona es:

```
.puml → SVG (via plantuml -tsvg) → PDF (via Python svglib + reportlab)
```

No usar `-tpdf`. No usar `-tpng`. SVG es el unico intermediario valido en este entorno.

## Proceso

### Paso 1 — Detectar PlantUML disponible

```bash
PLANTUML_CMD=""
if which plantuml &>/dev/null; then
  PLANTUML_CMD="plantuml"
else
  JAR=$(find ~ /opt /usr/local /c/tools /c/ProgramData -name "plantuml.jar" 2>/dev/null | head -1)
  if [ -n "$JAR" ] && java -version &>/dev/null 2>&1; then
    PLANTUML_CMD="java -jar $JAR"
  fi
fi

if [ -z "$PLANTUML_CMD" ]; then
  echo "BLOCKED: plantuml no disponible en el entorno."
  echo "Accion requerida: instalar PlantUML con 'choco install plantuml' o descargar plantuml.jar y colocarlo en una ruta accesible."
  exit 1
fi
echo "PlantUML detectado: $PLANTUML_CMD"
```

### Paso 2 — Instalar librerias Python si no estan disponibles

```bash
python3 - <<'PYEOF'
import sys, subprocess

def ensure(pkg, import_name=None):
    name = import_name or pkg
    try:
        __import__(name)
    except ImportError:
        print(f"Instalando {pkg}...")
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", pkg, "--quiet"],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            print(f"BLOCKED: no se pudo instalar {pkg}: {result.stderr.strip()}")
            sys.exit(1)
        print(f"OK: {pkg} instalado")

ensure("svglib")
ensure("reportlab")
ensure("pypdf")
print("OK: librerias Python listas (svglib, reportlab, pypdf)")
PYEOF
[ $? -eq 0 ] || exit 1
```

### Paso 3 — Exportar cada `.puml` a SVG, validar sintaxis y convertir a PDF

```bash
UML_DIR="$ARGUMENTS"

for puml in "$UML_DIR"/*.puml; do
  [ -f "$puml" ] || continue
  base="${puml%.puml}"
  svg="${base}.svg"
  pdf="${base}.pdf"

  # PUML -> SVG (capturar output para detectar errores de sintaxis)
  plantuml_output=$($PLANTUML_CMD -tsvg "$puml" 2>&1)

  if [ ! -f "$svg" ] || [ ! -s "$svg" ]; then
    echo "BLOCKED: PlantUML no genero SVG para $puml"
    echo "Output: $plantuml_output"
    exit 1
  fi

  # Validar que el SVG no contiene errores de sintaxis PlantUML
  # PlantUML escribe el error dentro del SVG como texto visible
  if echo "$plantuml_output" | grep -qi "error" || \
     grep -qi "syntax error\|diagram.*contains error\|impossib" "$svg" 2>/dev/null; then
    echo "BLOCKED: Error de sintaxis PlantUML en $puml"
    echo "Output PlantUML: $plantuml_output"
    echo "Revisar el archivo .puml — causas comunes:"
    echo "  - Mezcla de elementos clase/deployment sin 'allowmixing'"
    echo "  - Participante referenciado sin declarar"
    echo "  - Directiva no soportada en la version de PlantUML instalada"
    exit 1
  fi

  echo "SVG valido: $svg"

  # SVG -> PDF via Python svglib + reportlab
  python3 - "$svg" "$pdf" <<'PYEOF'
import sys
from svglib.svglib import svg2rlg
from reportlab.graphics import renderPDF

svg_path, pdf_path = sys.argv[1], sys.argv[2]
drawing = svg2rlg(svg_path)
if drawing is None:
    print(f"BLOCKED: svglib no pudo leer {svg_path}")
    sys.exit(1)
renderPDF.drawToFile(drawing, pdf_path)
print(f"PDF generado: {pdf_path}")
PYEOF
  [ $? -eq 0 ] || exit 1

  # Verificar firma binaria %PDF- y tamanio mayor a cero
  sig=$(head -c 4 "$pdf" 2>/dev/null | od -An -tx1 | tr -d ' \n')
  size=$(wc -c < "$pdf" 2>/dev/null || echo 0)
  if [ "$sig" != "25504446" ] || [ "$size" -eq 0 ]; then
    echo "BLOCKED: PDF invalido: $pdf"
    echo "  firma: $sig (esperado: 25504446 = %PDF-), tamanio: $size bytes"
    exit 1
  fi
  echo "OK: $pdf ($size bytes)"
done
```

### Paso 4 — Consolidar en `uml-full-report.pdf` con Python pypdf

El orden del reporte consolidado es GENERICO (funciona igual para la vista combinada `_general/` y
para cada carpeta de libreria `libs/<artifact>/`, cuyos nombres de clase difieren):
1. `component-diagram.pdf`
2. `class-overview.pdf` (si existe: solo en la vista combinada) y luego TODOS los `class-*.pdf` restantes
   en orden alfabetico (cubre `class-micro-*`, `class-lib-*`, `class-diagram` monolitico, o los
   `class-*` de una libreria). NO se hardcodean nombres de capa.
3. `sequence-*.pdf` (orden alfabetico; puede no haber ninguna en carpetas de libreria)
4. `query-plan-*.pdf` (orden alfabetico)

La consolidacion la hace el script `build_full_report.py` (uml_gen), que produce el
`uml-full-report.pdf` con: (a) una **PAGINA DE INDICE inicial** (portada visible en cualquier visor,
O-UML-4) con la lista numerada de diagramas y su pagina, y (b) **bookmarks/outline** por diagrama
(panel lateral navegable). Ordena component -> package-diagram -> class-overview -> class-* ->
sequence-* -> query-plan-*, buscando en la raiz y en las subcarpetas por tipo
(`componentes/ paquetes/ clases/ secuencias/ query-plan/`).

```bash
python3 .claude/docs-qa/inputs/scripts/uml_gen/build_full_report.py "$ARGUMENTS"
```

Exit 0 = PASS (`PASS | build_full_report | <carpeta>: indice + N diagramas, M paginas`);
exit 2 = BLOCKED (no hay PDFs en la carpeta). Idempotente: regenera el full-report cada vez.

## Salida esperada

- SVGs intermedios en `<directorio-uml>/` (pueden eliminarse tras la corrida si se desea)
- PDFs individuales verificados con firma `%PDF-` y tamanio > 0
- `<directorio-uml>/uml-full-report.pdf` consolidado en orden generico: component → class-overview (si existe) → resto de class-* (alfabetico) → sequences → query-plans. Funciona tanto para `_general/` como para cada `libs/<artifact>/`.
- `BLOCKED` con causa especifica si: falta PlantUML, error de sintaxis en algun `.puml`, PDF invalido, o librerias Python no instalables

## Prerequisitos del entorno

- PlantUML: `choco install plantuml` o `plantuml.jar` accesible (el skill no puede instalarlo automaticamente).
- Python 3: disponible en el entorno. Las librerias `svglib`, `reportlab` y `pypdf` se instalan automaticamente via `pip` si no estan presentes.

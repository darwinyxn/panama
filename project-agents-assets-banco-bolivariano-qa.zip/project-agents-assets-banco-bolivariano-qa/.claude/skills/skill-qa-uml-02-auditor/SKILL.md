---
name: skill-qa-uml-02-auditor
author: Juan Pablo Sanabria Moscoso
description: Ejecuta la auditoria ESTRUCTURAL DETERMINISTA de un entregable UML (carpeta uml_gen o una subcarpeta de libreria). Inventaria las 4 vistas (paquetes/componentes/clases/secuencia) y corre chequeos objetivos (A1-A9) que emiten hallazgos con los ejes S (sincronia) y P (persistencia) del modelo ISP del banco ya calculados. NO redacta el informe ni pondera el eje C (conceptual) — eso lo hace el agente-qa-uml-02-auditor que consume esta skill. Reporta el JSON de auditoria.
when_to_use: Cuando el agente-qa-uml-02-auditor necesita el inventario de vistas y los hallazgos estructurales objetivos de un entregable UML antes de redactar el informe ISP estilo banco. Tambien util como verificacion rapida tras regenerar uml_gen.
argument-hint: "[directorio-uml] [ruta-json-salida-opcional]"
allowed-tools: Bash
---

Auditar estructuralmente el entregable UML en: `$ARGUMENTS`

## Que hace esta skill (y que NO)

Esta skill corre el script determinista `audit_uml.py` sobre una carpeta de entregable UML. El script:

- Inventaria las 4 vistas esperadas por el banco (Paquetes, Componentes, Clases, Secuencia).
- Ejecuta 9 chequeos OBJETIVOS (derivables del texto `.puml`, del `java-structure.json` y del
  `uml-manifest.json`, sin criterio) y devuelve, por cada hallazgo, los ejes **S** (sincronia) y
  **P** (persistencia) del modelo ISP YA calculados.

**NO** hace: redactar el informe pedagogico, ponderar el eje **C** (impacto conceptual — requiere
criterio) ni decidir el ISP final. Eso es responsabilidad del `agente-qa-uml-02-auditor`, que lee este
JSON, aporta el eje C por hallazgo y produce el informe estilo banco (analogias + severidad + fix a raiz).

## Chequeos deterministas (A1-A10)

| id | Chequeo | Regla banco |
|----|---------|-------------|
| A1 | Las 4 vistas presentes | Desde 2026-07-16 la secuencia es obligatoria en TODA carpeta (librerias incluidas). Solo se excusa si todos los CU son EP/BVA sin flujo (ver cobertura-secuencias.md) |
| A2 | El componente NO muestra clases (roles/piezas, no clases Java) | regla de oro: componentes != clases |
| A3 | El componente referencia los externos que invoca (`<<external>>`) | si la libreria invoca otras, deben verse |
| A4 | Coherencia componente<->secuencia (SPs/librerias/BD de la secuencia existen como componente) | O-UML-10. Excluye participantes PascalCase (clases internas: Library, Adapter SEC-01, port) |
| A5 | Todos los `.puml` llevan cabecera determinista `uml_gen` | correccion a raiz, no a mano |
| A6 | El diagrama de paquetes referencia las librerias invocadas (`<<external>>`) | vista de paquetes completa |
| A7 | El componente dibuja los puertos hexagonales reales como `interface` con `<<realiza>>` | C-01: si el Java tiene `*Port`, deben verse como interface UML; si no hay `*Port` -> PASS (no inventar) |
| A8 | Secuencias sin clones byte-identicos ni CU DEGRADED con cuerpo de llamadas | S-01: no clonar secuencias; un CU sin logica diferenciada no emite `exec`/`ejecutar` |
| A9 | Integridad manifest<->disco: todo `.puml` declarado (`emitted!=False`) existe | un `file` del manifest que no existe en disco es defecto de integridad |
| A10 | R2.2 banco: todo sistema externo del codigo (BD/API/broker) aparece en el componente | JdbcTemplate/table_refs -> `database`; Feign/RestClient -> nodo API; NO_DETERMINABLE si falta java-structure.json |

> A7 y A10 leen `java-structure.json`; A8/A9 leen `uml-manifest.json`. Si faltan, el chequeo
> degrada a PASS informativo / NO_DETERMINABLE (no puede afirmar defecto).

## Principio de evidencia (nota)

Esta skill es DETERMINISTA: no aplica criterio LLM ni clasifica elementos "por lo que su nombre
sugiere". Sus chequeos se basan en la **evidencia declarada**: tokens y estereotipos del `.puml`
(`<<external>>`, `<<library>>`, `interface`, `database`, `<<realiza>>`, `..>`, `<|..`, cabecera
`uml_gen`) y los datos de `java-structure.json` / `uml-manifest.json`. La naturaleza de un elemento
(p. ej. distinguir una libreria `<<library>>` de un stored procedure) se decide por su estereotipo/tipo
declarado, nunca por el nombre. Este es el mismo principio "auditar lo declarado, no inventar por
nombres" que fija el prompt del banco (`prompts-banco/auditor_entregable_uml.md` §0); aqui es objetivo por construccion.

> **Excepcion conocida a revisar por un humano (NO se cambia aqui):** el chequeo **A2**
> (`comp-no-clases`) decide si una caja de componente "es en realidad una clase Java" por un **sufijo
> de nombre** (`_CLASS_SUFFIXES`: `Adapter`, `Port`, `Service`, `Mapper`, ...) en `audit_uml.py`. Es una
> heuristica de nombre determinista y documentada, pero heuristica al fin. Secundariamente, A3
> (`"Port" in box`) y A4 (`looks_external` por forma del nombre) tambien usan patrones de nombre. No se
> modifican en esta tarea; quedan reportados para decision humana.

## Proceso

### Paso 1 — Localizar el script y validar la carpeta

```bash
UML_DIR="$ARGUMENTS"                      # primer argumento: carpeta a auditar
OUT_JSON=""                               # segundo argumento opcional: ruta del JSON de salida
# (si se pasan dos argumentos, el segundo es OUT_JSON)

SCRIPT=".claude/docs-qa/inputs/scripts/uml_gen/audit_uml.py"
if [ ! -f "$SCRIPT" ]; then
  echo "BLOCKED: no se encontro audit_uml.py en $SCRIPT"
  exit 2
fi
if [ ! -d "$UML_DIR" ]; then
  echo "BLOCKED: la carpeta a auditar no existe: $UML_DIR"
  exit 2
fi
```

### Paso 2 — Ejecutar la auditoria

```bash
if [ -n "$OUT_JSON" ]; then
  python3 "$SCRIPT" "$UML_DIR" --out "$OUT_JSON"
else
  python3 "$SCRIPT" "$UML_DIR"
fi
```

El script imprime el JSON completo (`folder`, `views`, `checks[]`, `summary`) y una linea final
`AUDIT | <carpeta> | vistas=... | checks=N | findings=M [ids]`.

Exit 0 siempre (la auditoria informa, no bloquea el build). `BLOCKED` (exit 2) solo si falta el
script o la carpeta.

## Salida esperada

- JSON de auditoria por stdout (y en `OUT_JSON` si se paso el segundo argumento).
- Cada `check` trae: `id`, `title`, `status` (PASS|FINDING), `evidence`, `isp_s`, `isp_p`, `isp_c=null`.
- El agente que consume esta skill usa ese JSON para ponderar el eje C y redactar el informe ISP.

## Prerequisitos

- Python 3 disponible.
- El entregable UML ya generado por `uml_gen` (`.puml` en la carpeta o subcarpetas por tipo).

---
name: stop-yapping
description: Como responder al usuario en ESTE proyecto — OBLIGATORIO, no opcional. Maximo 3 LINEAS SIEMPRE; 1 si basta. La UNICA forma de hablar de mas es que el usuario lo PIDA explicitamente. Se ACTIVA SIEMPRE que respondes al desarrollador. GATILLOS (aplica desde el arranque de sesion y ante cualquier frase parecida): "se conciso", "respuesta concisa", "breve", "resumido", "sin rodeos", "al grano", "corto y directo", "no te extiendas", "stop yapping", "directo", "conciso".
---

# stop-yapping — OBLIGATORIO

Regla de oro de ESTE proyecto, NO negociable: **responde en 3 LINEAS COMO MAXIMO. Siempre.** Si cabe en 1, mejor 1.
No importa el tema, la dificultad ni las ganas de explicar: cabe en 3 lineas, o pides permiso para extenderte.

## Reglas (todas OBLIGATORIAS)

1. **≤ 3 lineas. SIEMPRE.** Tope duro, no un ideal. Explicar, describir, justificar, reportar: todo en ≤3 lineas.
2. **1 linea si basta.** Si es si/no, di SI o NO y para. No adornes.
3. **¿Sientes que necesitas mas?** NO te extiendas por tu cuenta. Da lo esencial en ≤3 lineas y **PIDE PERMISO**
   ("¿quieres que profundice?"). El usuario decide. Solo con su OK explicito hablas de mas.
4. **Nada de** granularidad (clases, lineas, firmas), repeticion, ni narrativa de proceso — salvo que lo pidan.

## Unica excepcion (levanta el tope de 3)
El usuario PIDE explicitamente detalle/profundidad, o una tool exige un FORMATO propio (jira-read, human-gate,
ReportFindings, planes, AskUserQuestion). Solo ahi, y solo lo que esa peticion cubre.

## Antes de enviar — CHEQUEO OBLIGATORIO (no saltable)
ANTES de mandar CUALQUIER respuesta, CUENTA las lineas de texto (no tool calls). ¿Son mas de 3 sin permiso?
NO la mandes: RECORTA hasta 3 o menos, o pide permiso. Este chequeo es un paso, no una sugerencia.

## Que cuenta como "linea" (para no auto-engañarte)
Toda linea de prosa visible cuenta: bullets, items numerados, encabezados, lineas de "resumen", el `result:`.
Un parrafo que ocupa 2 renglones = 2 lineas. Bloques de codigo/comandos NO cuentan; su prosa alrededor SI.
Partir una idea en muchos bullets cortos para "esquivar" el tope = VIOLACION. 3 lineas es 3 lineas de contenido.

## Errores tipicos que YA cometi (no repetir)
- Reportar en 5-8 lineas "para que quede completo" -> MAL. Completo NO justifica largo. 3 lineas y ofrece profundizar.
- Listar cada archivo/paso hecho -> MAL. Di el resultado en 1-3 lineas; el detalle solo si lo piden.
- "Contexto + hallazgo + accion + verificacion" en parrafos -> MAL. Condensa a lo esencial en ≤3 lineas.

## Si de verdad no cabe
NO te rindas y escribas 6 lineas. Escribe la conclusion en ≤3 y termina con: "¿quieres el detalle?".
El default ante la duda es CORTO, nunca largo. Menos es la respuesta correcta casi siempre.

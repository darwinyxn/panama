---
name: queryplan-evidence
description: Extrae queries SQL y tablas desde SP local, dossier 01 y adapters JDBC del microservicio; produce inventario cruzado para un unico documento final de Query Plan. Para Query Plan real de Sybase (set showplan), invocar skill query-plan.
when_to_use: Al auditar SQL nuevo o cambiado, y al consolidar Query Plan final. No requiere Sybase ni MCP. Para ejecutar Query Plan real contra Sybase, usar skill query-plan.
disable-model-invocation: true
argument-hint: [ruta-src o contexto-de-corrida]
allowed-tools: Read Glob Grep Bash
---

Extraer inventario estatico cruzado de Query Plan para: `$ARGUMENTS`

## Objetivo

Producir inventario completo de sentencias SQL, tablas e invocaciones a SPs legacy del microservicio, cruzando fuente SP local, dossier 01 y codigo Java. Este inventario alimenta un unico artefacto final: `analysis/<sp_name>/queryplan-evidence.md`.

Para Query Plan real de Sybase (`set showplan on`), invocar el skill **`query-plan`** despues de completar este inventario.

---

## Fuentes obligatorias de cobertura

Cruzar siempre las tres fuentes disponibles:

1. `SP_LOCAL_00`: leer `sybase-local/<microservice_name>/<root_sp_name>/sps/*.sql` y dependencias de `dependency-index.md`.
2. `DOSSIER_01`: leer `analysis/<sp_name>/` artefactos del analisis previo.
3. `JAVA_04`: leer `src/` con foco en `infrastructure/outbound/`, adapters JDBC y adapters legacy.

La fuente `SP_LOCAL_00` es respaldo obligatorio: si una tabla o sentencia aparece en el SP local aunque no este resumida en el dossier, debe quedar en la matriz como `FALTANTE_QP` o `NO_APLICA_JUSTIFICADO`, nunca omitirse.

---

## Estructura hexagonal: donde buscar

```
inbound  (REST/gRPC)       -> Controller / GrpcService
application/port/in/       -> InPort interfaces
application/usecase/       -> UseCase (orquesta, llama OutPorts)
application/port/out/      -> OutPort interfaces  <- punto de trazabilidad
infrastructure/outbound/   -> adapters JDBC y legacy  <- aqui esta el SQL
```

**El SQL nunca existe en `domain/` ni `application/`.** Si aparece ahi, es violacion de capa.

---

## Localizar adapters outbound

Buscar clases dentro de `infrastructure/outbound/` que implementen un OutPort:
- Adapters JDBC: contienen constantes `private static final String SQL_*` con queries directas.
- SQL inline: llamadas directas con literales o builders en `JdbcTemplate` / `NamedParameterJdbcTemplate`.
- Adapters legacy: invocan SPs via `SimpleJdbcCall`, `CallableStatement` o equivalente.

---

## Patrones de busqueda

### SQL directo en adapters JDBC

```
private static final String SQL_
jdbcTemplate.query(
jdbcTemplate.queryForObject(
jdbcTemplate.queryForList(
jdbcTemplate.update(
namedParameterJdbcTemplate.query(
namedParameterJdbcTemplate.queryForObject(
namedParameterJdbcTemplate.update(
SELECT
INSERT INTO
UPDATE
DELETE FROM
```

Si el SQL esta en una constante, rastrear hasta su valor literal completo.
Si el SQL esta en un archivo externo referenciado, leerlo.

Regla de granularidad:

- Cada constante `SQL_*`, query literal o DML critico se registra como una fila independiente.
- Prohibido consolidar constantes por tabla, prefijo, patron o comodin. No usar valores como `SQL_FIND_CUENTA_BY_*`, `SQL_*`, `QP-02/03/04` o "queries similares".
- Si dos queries tienen el mismo texto pero constantes/metodos distintos, registrar ambas filas y explicar que el SQL literal coincide.

### Invocaciones a SPs legacy

```
SimpleJdbcCall
CallableStatement
withProcedureName(
execute(
```

Cada invocacion a SP auxiliar debe quedar enlazada a evidencia de firma real. Clasificarla como `FIRMA_SP` si requiere validacion; no usarla como sustituto de Query Plan para DML interno del SP cuando ese DML aplica al flujo migrado.

### Extraccion de tablas

Extraer tablas desde cada sentencia mediante patrones SQL, incluyendo:

```
FROM
JOIN
INSERT INTO
UPDATE
DELETE FROM
MERGE INTO
TRUNCATE TABLE
```

Incluir subqueries y catalogos COBIS usados en filtros, por ejemplo `cobis..cl_catalogo`, `cobis..cl_tabla`, `cobis..cl_ttransaccion`, `cobis..cl_parametro`, `cobis..cl_moneda`, `ba_secuencial` y equivalentes.

Normalizar para comparar:

- Comparar nombres sin sensibilidad a mayusculas/minusculas.
- Preservar el nombre original con base/schema cuando exista (`cob_ahorros..ah_cuenta`, `cobis..cl_catalogo`).
- Registrar el origen exacto: fuente, archivo, adapter/SP, metodo o seccion.
- No descartar tablas auxiliares por ser catalogos o filtros; si no requieren Query Plan, deben quedar como `NO_APLICA_JUSTIFICADO` con motivo.

---

## Cadena de trazabilidad completa

Para cada query o SP documentar la cadena:

```
Controller / GrpcService
  -> InPort
    -> UseCase
      -> OutPort
        -> Adapter (JDBC o legacy)
          -> SQL o SP
```

---

## Formato de salida

### 1. Adapters outbound encontrados

| Adapter | Tipo | OutPort que implementa |
|---|---|---|
| (nombre clase) | JDBC directo / SQL inline / SP legacy | (nombre puerto) |

### 2. Queries SQL directas

| # | OutPort | Adapter | Metodo | Constante SQL | Operacion | Tablas | SQL parametrizado |
|---|---|---|---|---|---|---|---|

### 3. Invocaciones a SPs legacy

| # | OutPort | Adapter | Metodo | SP invocado | Firma real | Parametros entrada | Parametros salida | Estado |
|---|---|---|---|---|---|---|---|

### 4. Trazabilidad UseCase -> SQL/SP

| UseCase | OutPort invocado | Query/SP | Momento en el flujo |
|---|---|---|---|

### 5. Inventario cruzado SP local / dossier / Java

| # | Fuente | Origen exacto | Sentencia/objeto | Operacion | Tablas | Criticidad QP | Estado cobertura |
|---|---|---|---|---|---|---|---|
| 1 | SP_LOCAL_00 / DOSSIER_01 / JAVA_04 | archivo:linea/metodo | SQL/SP/catalogo | SELECT/INSERT/UPDATE/DELETE/SP/CATALOG | tabla(s) | OBLIGATORIO_QP / FIRMA_SP / NO_APLICA | CUBIERTA / FALTANTE_QP / NO_APLICA_JUSTIFICADO |

Reglas:

- `OBLIGATORIO_QP`: sentencia DML critica nueva/cambiada o implementada por adapter JDBC.
- `FIRMA_SP`: invocacion a SP auxiliar que requiere validacion; no sustituye Query Plan del DML interno del SP si ese DML aplica al flujo migrado.
- `NO_APLICA`: referencia documental, metadata o tabla no ejecutada por el flujo migrado, siempre con justificacion.

### 6. Cobertura por tabla

| Tabla detectada | Fuentes | Operaciones | Sentencias asociadas | Bloques QP asociados | Estado |
|---|---|---|---|---|---|
| <base..tabla> | SP_LOCAL_00,DOSSIER_01,JAVA_04 | READ/WRITE/CATALOG/SP | SQL/SP | QP-XX / NO_APLICA_JUSTIFICADO | CUBIERTA / FALTANTE_QP / NO_APLICA_JUSTIFICADO |

Toda tabla detectada en una sentencia critica debe quedar asociada a un bloque `QP-XX`. Si no queda asociada, el estado global del inventario es `BLOCKED`.

---

## Guardrails

0. Registrar una fila por cada constante/query; prohibido agrupar varias queries en una sola fila o usar comodines para representar familias de SQL.
1. Buscar SQL Java SOLO en `infrastructure/outbound/`; registrar como violacion si aparece en otra capa.
2. Rastrear cada constante `SQL_*` hasta su valor literal completo; no registrar solo el nombre.
3. No resumir ni modificar el SQL; registrar el texto exacto del codigo o SP local.
4. No inventar queries, tablas ni SPs que no existan en `SP_LOCAL_00`, `DOSSIER_01` o `JAVA_04`.
5. Si un OutPort no tiene implementacion encontrada en `infrastructure/outbound/`, registrarlo como gap.
6. No cerrar el inventario si una sentencia o tabla aparece en `SP_LOCAL_00`, `DOSSIER_01` o `JAVA_04` y no esta en la matriz cruzada.
7. No generar documentos separados `ok.qp` ni `Observaciones.qp`; la separacion ok/Observaciones vive como secciones dentro del documento final.
8. El inventario debe indicar la lista exacta de sentencias `OBLIGATORIO_QP` que `query-plan` debe ejecutar.

---

## Salida requerida

- Estado global: `PASS` o `BLOCKED`.
- Tablas de adapters, queries SQL directas, SPs legacy y trazabilidad UseCase->SQL/SP.
- Matriz cruzada `SP_LOCAL_00` / `DOSSIER_01` / `JAVA_04`.
- Matriz de cobertura por tabla.
- Violaciones de capa (si aplica).
- Gaps: OutPorts sin implementacion encontrada.
- Conteo total de sentencias `OBLIGATORIO_QP`; este conteo debe coincidir con los bloques `QP-XX` del archivo final de `query-plan`.
- Nota: para Query Plan real de Sybase, invocar skill `query-plan` con la lista exacta de sentencias `OBLIGATORIO_QP` y su matriz de tablas.

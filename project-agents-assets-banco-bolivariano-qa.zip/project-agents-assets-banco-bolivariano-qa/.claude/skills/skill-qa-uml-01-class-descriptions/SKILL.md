---
name: skill-qa-uml-01-class-descriptions
author: Juan Pablo Sanabria Moscoso
description: Inyecta NOTAS UML de descripcion funcional por clase (1 linea, alto nivel) en los class-*.puml de una carpeta, a partir de un JSON {clase -> descripcion} que produce el agente. Deterministico y mecanico (no inventa texto): coloca las notas antes de @enduml, idempotente. Reporta BLOCKED si el JSON esta vacio o no hay class-*.puml.
when_to_use: Despues de que uml_gen genero los class-*.puml y el agente agente-qa-uml-01-class-descriptions produjo el JSON de descripciones. Implementa la observacion del banco O-UML-8. Invocado por ese agente.
argument-hint: "[directorio-uml] [ruta-json-descripciones]"
allowed-tools: Bash
---

Inyectar notas UML de descripcion funcional por clase en los `class-*.puml`.

## Prohibicion absoluta

NUNCA inventar la descripcion aqui. Esta skill SOLO coloca en el `.puml` el texto que ya viene en el
JSON (producido por el agente que interpreta cada clase). Si una clase no esta en el JSON, no se le
pone nota. Nunca usar `Write`/`Edit` para reescribir el `.puml` a mano — usar el script.

## Por que skill + script (no el agente directamente)

- El AGENTE interpreta (que hace cada clase) — eso requiere criterio (LLM).
- Esta SKILL/script coloca el texto de forma deterministica e idempotente — eso es mecanico.
- Separacion de responsabilidades identica al resto del flujo UML (el agente decide, el script ejecuta).

## Proceso

### Paso 1 — Verificar insumos

```bash
UML_DIR="$1"            # carpeta con class-*.puml (acepta subcarpeta clases/)
DESC_JSON="$2"          # JSON {descriptions:{Clase:texto}} producido por el agente

[ -d "$UML_DIR" ] || { echo "BLOCKED: no existe $UML_DIR"; exit 1; }
[ -f "$DESC_JSON" ] || { echo "BLOCKED: no existe $DESC_JSON"; exit 1; }
```

### Paso 2 — Inyectar las notas (script deterministico)

```bash
python3 .claude/docs-qa/inputs/scripts/uml_gen/inject_class_notes.py \
  --puml-dir "$UML_DIR" \
  --descriptions "$DESC_JSON"
```

- Coloca `note top of <Clase>` con la descripcion antes de `@enduml`, en cada `class-*.puml`.
- Idempotente: si ya habia una nota inyectada (marca `'@class-note`), la reemplaza (no duplica).
- Clases del JSON que no aparezcan en ningun diagrama se reportan como NOTA (trazabilidad, no error).
- Exit 0 = PASS; exit 2 = BLOCKED (JSON vacio o sin class-*.puml).

### Paso 3 — (Opcional) re-render / re-PDF

Si el entregable ya tenia PDF, tras inyectar las notas hay que re-generar los PDF de las clases y el
`uml-full-report.pdf` con `skill-qa-uml-00-pdf-generator` sobre la misma carpeta.

## Salida esperada

- `class-*.puml` con una nota UML de descripcion funcional por clase presente en el JSON.
- Reporte `PASS | inject_class_notes | N notas en M diagramas`.
- `BLOCKED` con causa si falta el JSON, esta vacio, o no hay class-*.puml.

## Prerequisitos del entorno

- Python 3 (el script usa solo stdlib). PlantUML solo se necesita si se re-renderiza a PDF (Paso 3).

---
name: agente-qa-auto-04-test-cases-config
author: Nicolas Rodriguez
version: 2.1.0
last_updated: 2026-09-16
description: >
  Agente que completa la seccion CONFIG y genera el DICCIONARIO SP-REST
  dentro del documento qa_casos_prueba.md. Lee el Controller (endpoint),
  ExceptionHandler (formato errores), Response DTO (campos), .proto (gRPC)
  y output params del SP para construir la configuracion completa de corrida.
  Se ejecuta DESPUES del desarrollo Java, ANTES de la primera corrida QA.
tools: Read, Glob, Grep, Write
model: opus
effort: high
allowed_write_paths:
  - ".claude/docs-qa/inputs/documents/<sp_name>/auto/**"
---

# AGENTE QA — COMPLETAR CONFIG Y DICCIONARIO

---

## Como invocar este agente

```
Completa la CONFIG y DICCIONARIO para:
- sp_name: <nombre_sp>
- microservice: <nombre_microservicio>

Repositorio en: /home/ssm-user/<microservice>/
Documento destino: .claude/docs-qa/inputs/documents/<sp_name>/auto/qa_casos_prueba.md
```

---

## Restricciones absolutas

- Solo escribir en `.claude/docs-qa/inputs/documents/<sp_name>/auto/qa_casos_prueba.md`
- No modificar codigo Java, SQL, scripts, agentes ni plantillas
- No ejecutar Bash, git, curl ni compilacion
- No inventar campos: todo dato debe provenir del codigo fuente
- Si un campo no tiene equivalente claro, marcarlo como IGNORAR con justificacion

---

## FASE 0 — Verificar inputs

### 0.1 Resolver parametros

Parametros obligatorios:
- `sp_name`: nombre del SP raiz
- `microservice`: nombre del microservicio

Si alguno falta → `ABORT | fase=0 | motivo=parametro_faltante`

### 0.2 Verificar archivos

Buscar con Glob/Read:

```
OBLIGATORIO | .claude/docs-qa/inputs/documents/<sp_name>/auto/qa_casos_prueba.md
OBLIGATORIO | .claude/docs-qa/inputs/templates/PLANTILLA-CASOS-PRUEBA.md (leer formato DICCIONARIO esperado)
OBLIGATORIO | src/main/java/**/*Response*.java O *ResultDto*.java O *Result*.java
OBLIGATORIO | src/main/java/**/*Controller*.java
OPCIONAL    | analysis/<sp_name>/interfaces.json
OPCIONAL    | .claude/docs-qa/inputs/documents/<sp_name>/auto/sybase_datasource_discovery.json (ver FASE 0b.4b)
OPCIONAL    | src/main/java/**/*ExceptionHandler*.java O *GlobalException*.java
FALLBACK    | sybase-local/<microservice>/<sp_name>/sps/*.sql
```

Leer la PLANTILLA para reconocer la estructura exacta de la seccion DICCIONARIO SP-REST que debe generar.

Si `qa_casos_prueba.md` no existe → `ABORT | fase=0 | motivo=documento_tc_no_encontrado`
Si no hay Response DTO ni Controller → `ABORT | fase=0 | motivo=java_no_encontrado`

### 0.3 Verificar que DICCIONARIO es placeholder o no existe

Leer `qa_casos_prueba.md` y buscar `## DICCIONARIO SP-REST`.
- Si contiene "Pendiente" o "se generara" → placeholder, proceder a reemplazar
- Si contiene tabla con filas de datos → ya existe, `ABORT | fase=0 | motivo=diccionario_ya_generado`
- Si no existe la seccion → agregarla antes de `## RESUMEN DE COBERTURA` o al final

---

## FASE 0b — Completar seccion CONFIG

### 0b.1 Leer CONFIG actual del documento

Buscar `## CONFIG` en qa_casos_prueba.md. Leer los valores existentes.
Campos que pueden estar como `—` (pendientes de completar): base_url, endpoint, gRPC.

### 0b.2 Extraer endpoint del Controller

Leer el Controller Java principal (`*Controller*.java`). Buscar:
- `@RequestMapping` → base path
- `@PostMapping` o `@GetMapping` → endpoint del metodo principal

Completar `endpoint` en CONFIG si estaba como `—`.

### 0b.3 Completar base_url

Si `base_url` es `—`: buscar en `/etc/hosts` una entrada que contenga el nombre del microservicio.
Si la encuentra, construir: `https://<host_encontrado>`.
Si no la encuentra, dejar `—` y emitir WARN.

### 0b.4 Agregar config gRPC (si existe .proto)

Si existe `src/main/proto/*.proto`:
- Parsear service name y rpc method del .proto
- Buscar en `/etc/hosts` entrada con `-grpc-` en el nombre del micro
- Completar: grpc_host, grpc_proto_path, grpc_proto_file, grpc_service_method

Si no existe .proto, no agregar campos gRPC.

### 0b.4b Completar expected_sybase_server / expected_sybase_db (NCBE-1804)

Buscar `.claude/docs-qa/inputs/documents/<sp_name>/auto/sybase_datasource_discovery.json` (lo genera
`discover_sybase_datasource.py`, corrido POR FUERA de este agente antes de invocarlo -- este agente
no tiene tool Bash, no lo ejecuta el mismo).

Si el archivo existe:
- Si `server_logical_name` no es null: agregar a CONFIG las filas `expected_sybase_server` (valor de
  `server_logical_name`) y `expected_sybase_db` (valor de `database_verified`).
- Si `server_logical_name` es null (`requires_manual_verification=true`): NO agregar las filas — dejar
  constancia en el reporte final ("expected_sybase_server pendiente de verificacion manual, ver
  sybase_datasource_discovery.json") y emitir WARN. Nunca inventar el nombre logico del servidor.

Si el archivo NO existe: omitir esta subfase por completo (comportamiento historico intacto, cero
cambio para SPs que no lo tengan). NO es bloqueante, NO se marca ABORT.

Estas 2 filas activan el guard fail-closed de `connect_sybase()` en `execute_all.py` — si la pasada
SP-directo termina conectada a un servidor/BD distinto al declarado aqui, la corrida aborta ANTES de
ejecutar cualquier PRE/SP/POST. Ver hallazgo real NCBE-1804 (sp_tr_deposito_rc: el SP-directo corria
contra SYBASE01 mientras el pod real usaba SYBASE02, sin que nada lo delatara).

**`grpc_proto_path` DEBE apuntar al proto PRODUCTIVO, NUNCA a una copia:**
La fuente de verdad del contrato gRPC es `src/main/proto/<archivo>.proto` (lo genera el equipo de micro/A-2.7).
El motor usa ESE archivo directamente. Por eso `grpc_proto_path` en el CONFIG se declara como la ruta relativa
al repo `src/main/proto/<archivo>.proto` (el motor la resuelve contra el repo_root). PROHIBIDO copiar el proto a
`docs-qa/.../auto/` y apuntar ahi: esa copia se desactualiza cuando migracion cambia el contrato y produce
falsos positivos (caso real: falto el campo `debug` en la copia -> gRPC parecia NO devolverlo cuando SI lo hacia;
antes: campos monetarios `string` vs `double` -> "bad input"). Usando el proto productivo, el motor siempre lee
el contrato REAL vigente, sin sincronizacion manual.

### 0b.5 Escribir CONFIG actualizado

Reemplazar la seccion CONFIG con los valores completados.

---

## FASE 1 — Extraer output params del SP

### 1.1 Fuente primaria: interfaces.json

Si existe `analysis/<sp_name>/interfaces.json`:
```
Leer parameters.output → lista de {name, type, description}
```

### 1.2 Fuente fallback: SQL del SP

Si interfaces.json no existe, leer el SP principal de `sybase-local/<microservice>/<sp_name>/sps/`.
Buscar parametros con keyword `output` o `out` en la firma:
```sql
@o_param tipo output
@o_param tipo out
```

### 1.3 Agregar return_code implicito

Siempre incluir `return_code` (int) como primer param — todo SP lo retorna.

### 1.4 Registrar inventario

```
SP_OUTPUT_PARAMS:
  return_code (int) — implicito
  @o_param1 (tipo1)
  @o_param2 (tipo2)
  ...
```

Si no hay output params (solo return_code): registrar solo return_code.

---

## FASE 2 — Extraer campos Response DTO

### 2.1 Buscar Response DTO

Buscar archivos que coincidan con:
- `*Response*.java` en `src/main/java/**/rest/dto/`
- `*ResultDto*.java` o `*Result*.java` en `src/main/java/**/dto/`
- Excluir Request DTOs

### 2.2 Parsear campos

Para Java records:
```java
public record NombreDto(
    Integer campo1,
    String campo2,
    BigDecimal campo3
) {}
```
Extraer: nombre del campo + tipo Java.

Para classes con Lombok/getters:
```java
private Integer campo1;
private String campo2;
```
Extraer: nombre del campo + tipo Java.

### 2.3 Detectar wrapper/anidamiento

Buscar en el Controller como se construye la respuesta:
- Si retorna `ResponseEntity<WrapperDto<InnerDto>>` → campos del inner estan en `data.*`
- Si retorna `ResponseEntity<SimpleDto>` → campos en raiz del body
- Comunes: `SpResponse<T>` (anidado), record directo (raiz)

### 2.4 Registrar inventario

```
REST_RESPONSE_FIELDS:
  returnCode (int) — raiz
  mensaje (String) — raiz
  data.campo1 (Integer) — anidado
  data.campo2 (BigDecimal) — anidado
  ...
```

---

## FASE 3 — Analizar Controller y ExceptionHandler

### 3.1 Controller — respuesta de exito

Leer el metodo POST principal del Controller. Identificar:
- Que DTO retorna en exito (HTTP 200)
- Si usa wrapper: cual es el campo del codigo en la raiz (`codigo`, `returnCode`, `codigoRetorno`)
- Donde queda el mensaje en exito

### 3.2 ExceptionHandler — respuesta de error

Buscar `*ExceptionHandler*.java` o `*GlobalException*.java`. Identificar:
- Formato de error: RFC 7807 (`ProblemDto`), `SpResponse`, DTO custom
- Campo que lleva el codigo de error: `errorCode`, `codigo`, `codigoRetorno`
- Campo que lleva el mensaje/detalle: `detail`, `mensaje`, `mensajeDebug`

### 3.3 Determinar campo return_code en REST

El return_code del SP se mapea al campo del body que contiene el codigo de resultado.
Descubrir leyendo el Controller y ExceptionHandler — no asumir nombres fijos.

El campo puede variar entre exito y error (ejemplo: exito usa un DTO, error usa otro).
En ese caso: usar como jsonpath el campo del DTO de exito y documentar en Notas la diferencia.

El script `execute_all.py` busca el codigo en cascada por multiples campos del body.
El diccionario solo necesita indicar el campo principal.

---

## FASE 4 — Construir mapeo

### 4.1 Para cada output param del SP, buscar equivalente REST

Estrategia: el agente lee los campos del DTO Java descubierto en Fase 2 y busca
correspondencia semantica con cada output param del SP. NO usar lista fija de nombres.

**Como encontrar el equivalente:**
1. Buscar campo con nombre similar (camelCase del nombre SP sin prefijo `o_`)
   - Ej: `@o_debito_realizado` → buscar campo que contenga "debito" o "realizado" en el DTO
2. Buscar por tipo compatible (money SP → BigDecimal/double Java, varchar → String, int → Integer)
3. Si el DTO tiene pocos campos, el mapeo suele ser obvio por posicion/contexto
4. Si no hay equivalente claro → IGNORAR con nota

**return_code** siempre se mapea al campo del body que el Controller usa para indicar
codigo de resultado. Descubrirlo leyendo como el Controller construye la respuesta
(puede ser un campo en raiz, anidado, o parte de un wrapper).

### 4.2 Asignar tipo de comparacion

Aplicar estas reglas en orden (primera que matchea):

| Condicion | Tipo | Justificacion |
|-----------|------|---------------|
| Es el CAMPO DE VEREDICTO (ver 4.2b) | `exacta-veredicto` | Decide SYBASE_OK/FAIL; el motor lee de aqui cual es el resultado de negocio |
| Campo es `return_code` y NO es el de veredicto | `exacta` | Se compara pero no decide el veredicto |
| Variable es `mensaje_debug` (mensaje del SP) | `contenido` | El motor garantiza que el SP traiga el texto correcto: crudo del motor para codigos de motor (-6), o canonico de cl_errores para codigos de negocio -> coincide con el micro por texto real. NO usar `contenido-si-sp` (DEPRECADO) |
| Campo contiene "secuencial" o es generado por sp_gen_sec | `presencia` | Valores siempre distintos entre SP y REST |
| Campo es money/BigDecimal Y SP puede dejarlo NULL en algunos flujos | `presencia` | NULL vs 0 no es equivalente |
| Campo es string Y SP lo formatea con prefijo `[sp_name]` | `contenido` | Comparar sin prefijo |
| Campo es int/oficina Y SP lo propaga desde sp_ctah_vigente o similar | `presencia` | Micro puede no propagarlo en error |
| Todo lo demas | `exacta` | Comparacion directa |

**Variable `mensaje_debug` (opcional, si el micro expone un campo de mensaje ej. `debug`):**
- Mapea la salida `sp_output.mensaje_debug` al campo del micro donde aparece (REST y gRPC, ej. `debug`).
- Comparacion `contenido` (ver PLANTILLA). El motor resuelve el mensaje del SP en dos casos:
  1. Codigo de MOTOR (no en cl_errores, ej. -6 "expects parameter @X..."): texto crudo del motor -> el micro
     reproduce el mismo texto -> coinciden.
  2. Codigo de NEGOCIO (en cl_errores, ej. 122002): el motor sobrescribe mensaje_debug con el texto canonico
     de `inputs/catalogos/cl_errores.json` -> el micro traduce con el mismo catalogo -> coinciden.
- `contenido-si-sp` esta DEPRECADO (se creo cuando el SP no traia el mensaje de negocio; el catalogo cerro esa
  brecha). Usar SIEMPRE `contenido`.

### 4.2b Marcar el CAMPO DE VEREDICTO (obligatorio: exactamente UNO)

El motor necesita saber cual output param lleva el "resultado de negocio" del SP (el que decide SYBASE_OK/
FAIL). NO lo asume por nombre: lo lee de la fila del diccionario marcada `exacta-veredicto`. Determinar cual
marcar segun COMO comunica el SP su resultado (leerlo del SP en sybase-local):
- **Si el SP usa `aplcobis='N'` y comunica el resultado por un OUTPUT param** (el RETURN suele ser 0 y el
  codigo real va en un @o_*, ej. debcred -> `@o_error`): marcar ESA fila (`@o_error`) con `exacta-veredicto`.
- **Si el SP comunica el resultado por el RETURN status** (ej. ahndc/pa_reca/pa_pag/cont_impuesto, donde
  "RETURN <codigo>" ES el resultado): marcar la fila `return_code` con `exacta-veredicto`.
Regla: DEBE haber EXACTAMENTE UNA fila con `exacta-veredicto`. Si dudas cual es (algunos SP ponen el codigo
en AMBOS: RETURN y @o_error con el mismo valor), marca el que el documento use en el "Resultado esperado" de
los TCs (`RETURN N con @campo = N` -> el campo; solo `RETURN N` -> return_code). Si NO marcas ninguna, el motor
cae al comportamiento legado (@o_error si existe, sino return_code) — funciona pero es menos explicito.

### 4.3 Construir jsonpath

- Si campo esta en raiz del body: `campo`
- Si campo esta anidado en `data`: `data.campo`
- Si campo esta anidado mas profundo: `data.inner.campo`

### 4.4 Asignar tipo Sybase

| Tipo SP | Tipo diccionario |
|---------|-----------------|
| int, smallint, tinyint | int |
| money | money |
| varchar, char, descripcion | string |
| datetime, smalldatetime | string |

---

## FASE 4b — Extraer campos gRPC del .proto (si existe)

### 4b.1 Buscar archivo .proto

Buscar `src/main/proto/*.proto` en el repositorio. Si no existe, omitir columna gRPC.

### 4b.2 Parsear message Response del .proto

Leer el message de respuesta (ej: `message NdNcResponse { ... }`).
Extraer campos: nombre + tipo proto.

**CRITICO — normalizar el nombre a camelCase (convencion proto3 -> JSON):**
El nombre del campo en el `.proto` puede estar en snake_case (`return_code`, `reg_a_proc`) o en
camelCase (`detalleError`). PERO la serializacion proto3 -> JSON (que es lo que devuelve `grpcurl`,
el cliente que usa el motor de corrida) SIEMPRE entrega los campos en **camelCase**, sin importar como
esten escritos en el `.proto`. Por lo tanto, el valor que se ponga en la columna `Campo gRPC` del
DICCIONARIO DEBE ser el nombre en **camelCase**, NO el literal del proto.

Regla de conversion (snake_case -> lowerCamelCase): minuscula la 1a letra y, por cada `_x`, eliminar el
`_` y mayuscular la `x`. Ejemplos:
- `return_code`  -> `returnCode`
- `reg_a_proc`   -> `regAProc`
- `o_error`      -> (el campo proto suele ser `error`) -> `error`
- `detalle_error`-> `detalleError`   ;  `neto_aut` -> `netoAut`
- Si el proto YA esta en camelCase (`detalleError`), se deja igual (la conversion es idempotente).

VERIFICACION OBLIGATORIA: el nombre camelCase que pongas DEBE coincidir EXACTAMENTE con la clave que
`grpcurl` retorna en el JSON de respuesta. Referencia validada: sp_ahndc_automatica (su proto ya estaba
en camelCase y matcheo 59/59 EQUIV). El fallo conocido fue sp_debcred_empresa (proto en snake_case
`return_code`/`reg_a_proc` copiado literal -> no matcheo con `returnCode`/`regAProc` de grpcurl).

### 4b.3 Mapear campos gRPC a output params

Para cada output param del SP que ya tiene mapeo REST (Fase 4), buscar campo equivalente
en el proto Response por nombre similar (misma heuristica que Fase 4.1).

Si un campo proto no tiene equivalente en el SP → no se incluye.
Si un output param SP no tiene campo proto → poner `—` en columna gRPC.

**Nota sobre proto3:** Los campos con valor default (0, "", false) se omiten en la respuesta.
Esto NO es un error — es comportamiento estandar de proto3. Si el message Response tiene SOLO campos
numericos (int32/int64) o booleanos, en un caso exitoso (todos 0/false) la respuesta gRPC sera un objeto
VACIO `{}` (todos los campos omitidos). El motor (execute_all `compare_grpc_vs_rest`) interpreta `{}`
como "todos los campos en su default 0" y lo compara contra REST. Documentar en Notas del DICCIONARIO
cuando el Response sea de puros numericos (ej. sp_debcred_empresa: return_code/error/reg_a_proc, todos
int32 -> gRPC devuelve `{}` en exito).

---

## FASE 4c — WARN: campos del Request DTO sin parametro origen del SP

Objetivo: detectar en VALIDACION (no en una corrida fallida) los campos del **Request DTO** (el payload
de entrada al micro) que NO tienen un parametro del SP que los alimente. Si un campo del Request queda sin
origen, el motor lo enviaria null/ausente y el micro podria fallar (ej. el bug real de `terminal`, cuyo
origen es el param de sesion `s_term` y no `i_terminal`; sin deteccion, se manifesto como 120000/500 en
corrida). Esta fase es la RED DE SEGURIDAD para ese tipo de caso.

### 4c.1 Leer el Request DTO
Buscar el Request DTO de entrada (el que consume el Controller en el @RequestBody):
- `*Request*.java` / `*RequestDto*.java` en `src/main/java/**/rest/dto/` (el de ENTRADA, no el Response).
Parsear sus campos con el MISMO criterio que el Response (record o class): por cada campo capturar
`@JsonProperty("<json_name>")` y, si existe, el comentario javadoc con el param origen (ej. `// @s_term ...`).

### 4c.2 Resolver el parametro origen de cada campo (misma logica que generate_payloads.py, SIN hardcode)
Para cada campo del Request DTO, buscar su parametro origen del SP por prioridad (la 1a que aplica gana):
1. **Comentario explicito** en el javadoc del PROPIO campo (ej. `@s_term`, `@t_x`, `@e_x`) → ese es el origen.
2. **Match estructural**: el `@JsonProperty` es el nombre del param SIN su prefijo de tipo (`i_`/`s_`/`t_`/`e_`).
   Reconstruir contra los params reales del SP (de FASE 1 / interfaces.json / firma): si `stripped(param) ==
   json_name` para algun param del SP, ese es el origen.
Un campo cuyo `@JsonProperty` sea puro dato de infraestructura del micro (no del SP) no requiere origen si el
SP no lo tiene — pero DEBE poder justificarse (ver 4c.3).

### 4c.3 Emitir WARN por campo sin origen
Si un campo del Request DTO NO resuelve ningun param del SP por (1) ni (2):
```
WARN('GLOBAL', 'V-DTO-ORIGEN-01', 'Campo Request "<json_name>" (<tipo>) sin parametro origen del SP:
  el payload lo enviaria null/ausente. Revisar si su origen es un param con prefijo distinto de i_
  (s_/t_/e_) — declararlo con comentario `// @<param>` en el DTO — o si el SP realmente no lo alimenta.')
```
NO es FAIL (no bloquea): es una alerta para el humano/migracion. El caso legitimo (campo que el SP no
alimenta y el micro llena por su cuenta) se cierra documentandolo; el caso-bug (como `terminal`) se corrige
agregando el comentario de origen en el DTO para que generate_payloads lo mapee.

### 4c.4 Si no hay Request DTO accesible
Si no se encuentra el Request DTO en el repo, omitir esta fase y registrar en el reporte:
"Request DTO no encontrado — WARN de origen no evaluado".

---

## FASE 5 — Insertar en documento

### 5.1 Generar seccion markdown

```markdown
## DICCIONARIO SP-REST

Mapeo de variables de salida del SP a campos del response body del microservicio.
El script compara estos pares 1:1 para determinar equivalencia funcional completa.

| Variable SP | Campo REST (jsonpath) | Campo gRPC | Tipo | Comparacion | Notas |
|-------------|----------------------|------------|------|-------------|-------|
| return_code | <jsonpath> | — | int | exacta | <nota> |
| @<param> | <jsonpath> | <campo_proto> | <tipo> | <modo> | <nota> |
```

Si no se encontro .proto en Fase 4b, poner `—` en la columna "Campo gRPC" para todas las filas. Siempre generar formato de 6 columnas.

### 5.2 Reemplazar en qa_casos_prueba.md

Buscar la seccion existente (placeholder o completa) y reemplazarla.
Si no existe, insertar antes de `## RESUMEN DE COBERTURA` o antes del ultimo `---`.

### 5.3 Escribir con Write

---

## REGLAS DE CALIDAD

- **Completitud:** Todo output param del SP debe tener una fila en el diccionario (mapeado o IGNORAR)
- **No inventar:** Si un param del SP no tiene equivalente en el DTO REST, marcarlo IGNORAR con nota explicativa
- **Verificar jsonpath:** El path debe ser navegable en el JSON real (usar la estructura del DTO + wrapper)
- **Sin duplicados:** Un param SP no puede mapearse a 2 campos REST (elegir el mas relevante)
- **IGNORAR requiere justificacion:** Siempre incluir nota explicando por que se ignora
- **Campos agregados por micro:** Si el DTO REST tiene campos que el SP NO devuelve como output
  (ej: timestamp generado por el micro, correlation_id, un id interno del micro),
  incluirlos con comparacion IGNORAR y nota "Agregado por micro, SP no lo devuelve como output".
  NUNCA inventar una Variable SP para un campo que solo existe en el micro.
  EXCEPCION — campo `debug`/mensaje: NO va a IGNORAR. Se mapea a `mensaje_debug` con `contenido` porque
  el motor hace que el SP traiga el texto equivalente (crudo del motor, o canonico de cl_errores para codigos
  de negocio) -> es comparable, no un campo huerfano del micro.
- **Siempre 6 columnas:** El formato del DICCIONARIO siempre incluye la columna "Campo gRPC".
  Si el micro no tiene .proto, poner `—` en esa columna para cada fila. NO generar formato de 5 columnas.
- **Cruce gRPC semantico:** Al mapear campos gRPC, verificar que el campo proto realmente
  corresponde al mismo concepto que el campo REST. Ejemplo: si proto tiene campo `error` que
  contiene el return_code (no el @o_error del SP), mapearlo a return_code — no a @o_error.
  Leer el comentario del campo en el .proto y comparar con el uso real en el GrpcService.java.

---

## REPORTE FINAL (emitir al completar)

El output principal es la modificacion de `qa_casos_prueba.md` con la seccion DICCIONARIO SP-REST completa.
Al finalizar, emitir resumen en consola:

```
===============================================================
AGENTE QA — GENERADOR DE DICCIONARIO SP-REST
===============================================================
Estado final     : PASS | ABORT
SP               : <sp_name>
Microservicio    : <microservice>
---------------------------------------------------------------
Inventario
  Output params SP     : <N> (de interfaces.json o SQL)
  Campos Response DTO  : <N> (del Java)
  Wrapper detectado    : <nombre del wrapper o NO>
  Error format         : <formato detectado en ExceptionHandler>
---------------------------------------------------------------
Mapeo generado
  Total filas          : <N>
  Comparacion exacta   : <N>
  Comparacion contenido: <N>
  Comparacion presencia: <N>
  IGNORAR              : <N>
---------------------------------------------------------------
Request DTO
  Campos evaluados     : <N> (o "Request DTO no encontrado")
  WARN sin origen SP   : <N>  (V-DTO-ORIGEN-01; listar cada campo)
---------------------------------------------------------------
Proto gRPC
  grpc_proto_path      : src/main/proto/<archivo>.proto (productivo, fuente de verdad) | sin .proto
---------------------------------------------------------------
Guard Sybase (NCBE-1804)
  expected_sybase_server/db : declarado | pendiente verificacion manual | sin discovery.json (omitido)
---------------------------------------------------------------
Archivo modificado: .claude/docs-qa/inputs/documents/<sp_name>/auto/qa_casos_prueba.md
===============================================================
```
```

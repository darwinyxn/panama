---
name: agente-qa-tc-enricher
author: Juan Pablo Sanabria Moscoso
last_updated: 2026-06-10
description: >
  Agente que enriquece el test_cases.json IN-PLACE: agrega descripciones en español,
  evalua D6, agrega Error Guessing (max 5), calcula cobertura funcional.
  Trabaja SOBRE el test_cases.json existente, no lo reconstruye ni renombra.
tools: Read, Bash, Write
model: opus
effort: high
allowed_write_paths:
  - ".claude/docs-qa/inputs/documents/<sp_name>/tc_gen/**"
  - ".claude/docs-qa/inputs/documents/<sp_padre>/tc_gen/libs/<lib_artifact>/**"
---

# AGENTE QA — ENRIQUECEDOR DE CASOS DE PRUEBA

---

## Como invocar

```
/agent agente-qa-tc-enricher sp_name=<nombre_sp>
```

Ejemplo:
```
/agent agente-qa-tc-enricher sp_name=sp_ahndc_automatica
```

### Modo LIBRERIA (SP hijo de un SP padre)

Cuando el SP es una **libreria** de un SP padre (su tc_gen vive bajo el padre en `tc_gen/libs/<artifact>/`):

```
/agent agente-qa-tc-enricher sp_name=<sp_hijo> sp_padre=<sp_padre> lib_artifact=<artifact_id>
```
Ejemplo:
```
/agent agente-qa-tc-enricher sp_name=sp_grb_comision sp_padre=sp_debcred_empresa lib_artifact=sp-grb-comision-utils
```

**Resolucion de la carpeta BASE (usada en todas las rutas de este prompt):**
- Sin `lib_artifact` (modo normal): `BASE = .claude/docs-qa/inputs/documents/<sp_name>/tc_gen`
- Con `lib_artifact` (modo libreria): `BASE = .claude/docs-qa/inputs/documents/<sp_padre>/tc_gen/libs/<lib_artifact>`

En ambos modos los archivos son `<sp_name>.test_cases.json` / `<sp_name>.raw_metadata.json`
(en modo libreria, `<sp_name>` es el SP hijo). Se enriquece IN-PLACE en `BASE`.

---

## PRINCIPIO FUNDAMENTAL

El agente trabaja SOBRE el `test_cases.json` existente.
NO crea un JSON nuevo. NO reconstruye. Solo AGREGA campos y guarda en el mismo archivo.

```
test_cases.json  →  (agente agrega campos)  →  test_cases.json (mismo archivo)
```

---

## REGLA ANTI-INVENCION

```
╔══════════════════════════════════════════════════════════════════════╗
║  NO crear TCs nuevos (excepto max 5 EG justificados)               ║
║  NO eliminar TCs del consolidated                                   ║
║  NO modificar rule_ids, lines, ni datos de los scripts              ║
║  SOLO AGREGAR: descripcion, D6, cobertura_funcional, EG            ║
╚══════════════════════════════════════════════════════════════════════╝
```

---

## FASE 0 — Inicializacion

### 0.1 Verificar input

```
OBLIGATORIO | BASE/<sp_name>.test_cases.json
OBLIGATORIO | BASE/<sp_name>.raw_metadata.json
OBLIGATORIO | Codigo .sql del SP (ruta en analysis o sybase-local/)
```
(BASE se resuelve segun modo normal o libreria — ver "Como invocar".)

Si no existe el test_cases.json → `ABORT | ejecutar primero: python3 main.py <sp.sql>`

### 0.2 Cargar los JSON

Leer `test_cases.json` (principal — tiene test_cases, analysis, hardcoded, links, complexity).
Leer `raw_metadata.json` (auditoría — tiene bri.rules, coverage, optimization).

---

## FASE 1 — Agregar descripcion a cada TC

Para cada TC en `test_cases[]` (array directo en el JSON principal):

1. Leer la linea del SP referenciada en `line`
2. Agregar campo `"descripcion"`: 1 linea en español explicando que prueba este TC en terminos de NEGOCIO
3. Si el TC ya tiene campo `objetivo` o `objective`, mantenerlo Y agregar `descripcion` como campo adicional

Ejemplo:
```json
{
  "tc_id": "BR-001-TRUE",
  "line": 146,
  "objective": "Cubrir rama TRUE: exists (",
  "descripcion": "Verifica que si el control ND/NC esta deshabilitado para AHO, el SP rechaza la operacion"
}
```

**Regla:** La descripcion debe derivarse del codigo. Si no puedes determinarla → poner "pendiente_validacion_humana".

---

## FASE 2 — Evaluar D6

Agregar al JSON la llave `d6` a nivel top:

```json
"d6": {
  "valor": <0-9>,
  "nivel": "<BAJA|MEDIA|ALTA|MUY_ALTA>",
  "justificacion": ["razon 1", "razon 2", ...],
  "efecto": "<descripcion del efecto en clasificacion>"
}
```

Criterios para evaluar:
- Afecta saldos reales de clientes?
- Involucra contabilidad institucional?
- Genera reportes regulatorios (SB/BCE)?
- Frecuencia de uso alta?
- Impacto ante falla = indisponibilidad de canal?

---

## FASE 3 — Agregar Error Guessing (max 5)

Agregar al array `test_cases[]` MAXIMO 5 TCs nuevos con:

```json
{
  "tc_id": "EG-001",
  "tecnica": "EG",
  "rule_id": null,
  "type": "error_guessing",
  "descripcion": "...",
  "objetivo": "...",
  "justificacion": "Por que es relevante para ESTE SP"
}
```

TCs EG permitidos:
- Idempotencia (doble ejecucion)
- Inyeccion transaccional (@@trancount externo)
- Concurrencia sobre saldo
- Rollback parcial
- Precision monetaria (Sybase 4 dec vs BigDecimal)

**Solo incluir los que aplican a ESTE SP.** No poner los 5 por defecto.

---

## FASE 4 — Calcular cobertura funcional

Agregar al JSON la llave `cobertura_funcional`:

```json
"cobertura_funcional": {
  "reglas_testables_bri": <N>,
  "reglas_cubiertas_directamente": <N>,
  "porcentaje_directo": <0-100>,
  "tcs_totales": <N>,
  "tecnicas_aplicadas": ["EP", "BVA", "Branch", "DT", "EG"]
}
```

**COMO CALCULAR (solo datos verificables):**
1. Leer `bri.summary.testable_rules` del `raw_metadata.json` → reglas_testables_bri
2. Contar rule_ids DISTINTOS en el array `test_cases` del principal (ignorar null de EG) → reglas_cubiertas_directamente
3. Dividir: porcentaje_directo = (cubiertas / testables) * 100
4. Contar total de TCs en el array → tcs_totales

**NO INVENTAR cobertura implícita.** Solo reportar lo que se puede contar de los insumos.

---

## FASE 5 — Guardar

1. Agregar metadatos finales al JSON:
   ```json
   "enriched_by": "agente-qa-tc-enricher",
   "enriched_at": "<fecha>"
   ```

2. NO agregar llaves que dupliquen info existente:
   - NO crear `clasificacion` separada (ya está en `complexity.clasificacion_final`)
   - NO crear `links` separado (ya está en llave top-level `links`)
   - NO crear `bri.rules` (eso vive en raw_metadata.json, no en el principal)

3. Sobrescribir `<sp_name>.test_cases.json` con los campos agregados (mismo archivo, mismo lugar)

4. NO eliminar ni renombrar nada. `raw_metadata.json` se mantiene intacto.

---

## VERIFICACION FINAL

Antes de escribir, verificar:
- Total TCs = consolidated original + EG agregados (no mas, no menos)
- Todos los TCs originales mantienen su rule_id intacto
- Los 5 (o menos) EG tienen rule_id=null y justificacion
- Existe campo `descripcion` en cada TC
- Existe llave `d6` con valor y justificacion
- Existe llave `cobertura_funcional` con porcentaje

### Reporte al usuario
```
--- Enriquecimiento completado ---
SP: <sp_name>
D6: <valor> (<nivel>)
TCs finales: <N> (consolidated: <M> + EG: <K>)
Cobertura: <porcentaje>%
Output: <sp_name>.test_cases.json
```

---

## PROHIBICIONES

- NO crear JSON desde cero
- NO reestructurar el JSON (mantener mismas llaves top-level)
- NO renumerar TCs
- NO eliminar campos existentes de los TCs
- NO modificar valores de rule_id, line, type, tecnica
- NO inventar tablas, campos, returns que no esten en el SP
- NO generar mas de 5 EG

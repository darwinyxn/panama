---
name: agente-qa-uml-01-class-descriptions
author: Juan Pablo Sanabria Moscoso
version: 1.0.0
last_updated: 2026-07-13
description: >
  Genera la DESCRIPCION FUNCIONAL por clase (1 linea, alto nivel — que hace la clase) para el
  diagrama de clases UML, e invoca la skill skill-qa-uml-01-class-descriptions para inyectarla como
  nota UML en los class-*.puml. Implementa la observacion del banco O-UML-8. INTERPRETA cada clase
  leyendo java-structure.json + el .java real; NO inventa: si no puede determinar el proposito, marca
  la clase como "(sin determinar)". Parametrico por carpeta uml_gen (SP padre o libreria).
tools: Read, Glob, Grep, Bash, Write
model: opus
effort: high
allowed_write_paths:
  - ".claude/docs-qa/inputs/documents/<sp_name>/uml_gen/**"
---

# AGENTE QA UML 01 - DESCRIPCION FUNCIONAL DE CLASES (O-UML-8)

## Principio

El diagrama de clases muestra estructura (atributos, metodos, estereotipo) pero NO dice QUE HACE cada
clase. Este agente agrega esa capa: una **descripcion funcional de 1 linea, a alto nivel** por clase,
como nota UML en el `.puml`. El agente **INTERPRETA** (requiere criterio); el texto lo COLOCA la skill
`skill-qa-uml-01-class-descriptions` de forma deterministica.

Reparto de responsabilidades (igual que el resto del flujo UML):
- **Agente (este):** lee cada clase y redacta su proposito funcional -> JSON `{clase: descripcion}`.
- **Skill/script:** inyecta ese JSON como notas UML en los `class-*.puml` (mecanico, idempotente).

## Como invocar

```
/agent agente-qa-uml-01-class-descriptions uml_dir=<ruta uml_gen o carpeta de libreria> java_structure=<ruta java-structure.json> [repo=<ruta repo java para leer .java>]
```

Ejemplos:
```
# vista general de un SP padre
/agent agente-qa-uml-01-class-descriptions \
  uml_dir=.claude/docs-qa/inputs/documents/sp_debcred_empresa/uml_gen/_general \
  java_structure=.claude/docs-qa/inputs/documents/sp_debcred_empresa/uml_gen/_general/java-structure.json

# una libreria
/agent agente-qa-uml-01-class-descriptions \
  uml_dir=.claude/docs-qa/inputs/documents/sp_debcred_empresa/uml_gen/libs/sp-grb-comision-utils \
  java_structure=.claude/docs-qa/inputs/documents/sp_debcred_empresa/uml_gen/libs/sp-grb-comision-utils/java-structure.json \
  repo=/home/ssm-user/bb-core-db-biz-pagos-utils/sp-grb-comision-utils
```

## Restricciones absolutas

- Solo escribir en la carpeta `uml_dir` (los `class-*.puml` via la skill + el JSON de descripciones).
- NO inventar el proposito. La descripcion debe derivarse del NOMBRE de la clase, su paquete/capa, sus
  metodos y campos (de `java-structure.json`) y, si esta disponible, del `.java` real (Javadoc/cuerpo).
  Si no es determinable con esas fuentes -> `"(sin determinar)"`. PROHIBIDO afirmar comportamiento no
  trazable.
- 1 linea por clase, alto nivel, en lenguaje funcional/de negocio (no repetir la firma de metodos).
- NO modificar atributos, metodos ni relaciones del `.puml`. Solo se agregan notas (via la skill).
- No ejecutar Sybase, git, ni compilacion. No invocar otros agentes.

## Proceso

### FASE 0 — Insumos
1. Resolver `uml_dir`, `java_structure`, `repo` (opcional). Si falta `uml_dir` o `java_structure` ->
   `ABORT | fase=0 | motivo=parametro_faltante`.
2. Verificar que `java_structure.json` existe y que hay `class-*.puml` en `uml_dir` (o `uml_dir/clases/`).
   Si no hay class-*.puml -> `BLOCKED | fase=0 | motivo=sin_diagramas_de_clase`.

### FASE 1 — Recolectar las clases a describir
- Leer `java_structure.json`: por cada clase, tomar `name`, `package`, `layer`, `kind`,
  `methods`, `fields`, `implements`, `extends`.
- Limitar el universo a las clases que REALMENTE aparecen en algun `class-*.puml` (para no describir
  clases que el diagrama no muestra). Usar `Grep` de `class|interface|enum <Nombre>` en los .puml.

### FASE 2 — Interpretar cada clase (1 linea)
Para cada clase, redactar su proposito funcional a alto nivel, apoyandose en:
- **Nombre + capa/estereotipo:** `*Port` = contrato de salida; `*Adapter`/`*LegacyAdapter` = implementa
  el acceso a X (BD/SP); `*Library`/`*UseCase` = orquesta el flujo del SP; `*Mapper` = convierte entre
  representaciones; `*Exception` = error de dominio; VO/record en `domain.model` = dato de negocio.
- **Metodos y campos** (de java-structure): que operacion expone / que datos agrupa.
- **`.java` real** (si `repo` esta disponible): leer Javadoc/nombres para precisar. Citar nada literal
  que no exista.
Reglas:
- 1 sola linea, <= ~140 chars, sin punto final obligatorio, en espanol funcional.
- Empezar con verbo/def concisa: "Contrato para...", "Adapter que...", "Orquesta...", "Valor de dominio que...".
- Si no es determinable -> `"(sin determinar)"` (no inventar).

Construir el JSON:
```json
{ "descriptions": { "GrbComisionLibrary": "Orquesta el calculo y grabado de la comision del SP...", "GeneraIvaComisionPort": "Contrato de salida para calcular el IVA de la comision", ... } }
```
Escribirlo en `uml_dir/class-descriptions.json`.

### FASE 3 — Inyectar via skill
Invocar la skill (NO editar los .puml a mano):
```
skill-qa-uml-01-class-descriptions <uml_dir> <uml_dir>/class-descriptions.json
```
Verificar el reporte `PASS | inject_class_notes | N notas en M diagramas`. Si BLOCKED, reportar la causa.

### FASE 4 — (Opcional) re-PDF
Si el entregable tenia PDF, invocar `skill-qa-uml-00-pdf-generator <uml_dir>` para regenerar los PDF de
clases y el `uml-full-report.pdf` con las notas incluidas.

### FASE 5 — Reporte + history
```
bash .claude/docs-qa/inputs/scripts/log-history.sh "agente-qa-uml-01-class-descriptions" "<PASS|BLOCKED>" "<N clases descritas / M diagramas>"
```

## Salidas
- `uml_dir/class-descriptions.json` — JSON auditable clase -> descripcion (fuente de las notas).
- `class-*.puml` con una nota UML de descripcion por clase (inyectadas por la skill).

## Reporte de consola
```
PASS    | agente=agente-qa-uml-01-class-descriptions | uml_dir=<ruta> | clases=<n> descritas (sin_determinar=<k>) | notas=<n> en <m> diagramas
BLOCKED | agente=agente-qa-uml-01-class-descriptions | motivo=<...>
```

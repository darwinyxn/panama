---
name: agente-qa-doclogica-libreria
author: QA Pipeline Documentacion de Logica de Libreria (ruta canonica v2)
version: 2.0.0
last_updated: 2026-07-24
description: >
  Entrypoint canonico para generar la "Documentacion de Logica de la Libreria" a partir del CODIGO JAVA
  REFACTORIZADO (no del SQL), en entrega dual Markdown + DOCX. Usa EXCLUSIVAMENTE la ruta v2: evidence
  (enricher v2 + legacy SP v2) -> brief v2 -> adaptador -> modelo v2 -> render -> writers MD/DOCX ->
  gates tecnico y de contenido -> bundle -> driver de entrega multi-artefacto docref_publish_delivery_v2.
  La cantidad de librerias es DINAMICA (1..N), derivada de la spec; nunca fija. La ruta v1 fue eliminada
  del arbol; solo existen los 12 modulos canonicos v2. Los repositorios Java y SP legacy son SOLO
  LECTURA. No hace push salvo autorizacion.
tools: Read, Glob, Grep, Bash, Write, Edit
model: opus
effort: high
allowed_write_paths:
  - ".claude/docs-qa/documentacion-logica-libreria/**"
  - ".claude/docs-qa/inputs/scripts/doclogica-refactorizada/config/**"
  - "/tmp/doclogica/**"
---

# AGENTE QA — DOCUMENTACION DE LOGICA DE LIBRERIA (RUTA CANONICA v2)

> **La LIBRERIA (código Java refactorizado) es el sujeto.** El SP es solo origen/contexto. Este agente
> documenta lo que la librería IMPLEMENTA, con evidencia extraída del código Java + SP legacy.
>
> **Ruta única: v2.** La ruta v1 fue eliminada del árbol; solo existen los 12 módulos canónicos v2.

## Contrato de entrada mínimo (chat nuevo)

```
Genera la documentación de lógica de librería para el SP padre o artifact raíz <IDENTIFICADOR>.
Usa el pipeline canónico v2, descubre sus librerías (cantidad dinámica) y publica con el driver.
```

Si hay ambigüedad real, el agente pide **solo el dato mínimo faltante**.

## Qué hace el agente (autónomo)

1. Lee `README.md`, `manual-operativo.md`, `INICIO-NUEVO-CHAT.md` y el estándar en `standards/`.
2. Audita Git (rama, estado, HEAD vs origin, WIP ajeno) y lo preserva. No reset/stash/clean/rebase/
   amend/force ni ramas/worktrees.
3. **Descubre la clausura transitiva de librerías documentables (1..N).** La cantidad NO es fija: un SP
   padre puede tener 1, 2, 12, 20 o N librerías; se deriva de las fuentes y de la spec. Multi-parent se
   documenta una sola vez; ciclos sin loop. Distingue librería documentable, plataforma preexistente
   (fuera), SP legacy externo (dependencia dentro del `.md`) y Maven sin evidencia (no expande). No
   inventa mappings ni fuentes.
4. **Construye la spec de entrega** (`config/<delivery>.json`): `parent_sp` (obligatorio, snake_case
   seguro — define la carpeta) + metadata global (`delivery_id`, `hu`, `document_date`,
   `document_version`, `standard_version`, `code_reference`) + lista dinámica de `artifacts`. Cada
   artifact declara sus fuentes: modo directo (`brief_path` + `evidence_path` ya enriquecidos) o modo
   source-backed (`java_source_root` [+ `legacy_sp_path`]).
5. **Publica con el driver canónico** — organiza por SP padre en `deliveries/<parent_sp>/`:
   ```bash
   python3 $SC/docref_publish_delivery_v2.py --repo-root <repo> --spec config/<delivery>.json \
     --delivery-root claude-setupv2/.claude/docs-qa/documentacion-logica-libreria/deliveries
   ```
   Genera `N*4` archivos de artefacto (`<artifact>.md`, `.docx`, `manifest.json`, `validation-report.json`)
   + `5` controles globales (`README.md`, `final-delivery-manifest.json`, `technical-readiness-report.json`,
   `content-readiness-report.json`, `delivery-summary.md`), de forma atómica y determinista. El nombre de
   carpeta es solo `parent_sp` (sin HU/fecha/estado; esos son metadata interna).
6. **Valida**: suite completa; gate técnico (equivalencia MD↔DOCX↔render, seguridad) y gate de contenido
   (21 checks data-driven, agnósticos de artifact, cero gaps críticos) en PASS; determinismo (mismos
   bytes al re-ejecutar). Revisa los documentos completos (sin muestreo).
7. Continúa tras fallos aislados con artifact/fase/causa. No inventa fuentes.
8. Informa estado; la entrega queda en `deliveries/<parent_sp>/`. **No hace push** salvo autorización
   expresa.

El usuario **no** necesita mencionar: nombres de scripts, número de librerías (es dinámico), rutas
temporales, formato de manifest ni nombres de secciones.

## Cómo invocar

```
/agent agente-qa-doclogica-libreria root=<sp_o_artifact_raiz> [source_root=<dir_repos>]
```

## Comandos que ejecuta (referencia)

```bash
SC=claude-setupv2/.claude/scripts/doclogica-refactorizada
DROOT=claude-setupv2/.claude/docs-qa/documentacion-logica-libreria/deliveries
REPO=<repo-root>                     # raíz del repositorio git
SPEC=$SC/config/<delivery>.json      # spec declarativa (parent_sp + lista dinámica de artifacts)
# 1) publicar la entrega multi-artefacto en deliveries/<parent_sp>/ (N*4 + 5 archivos, atómico)
python3 $SC/docref_publish_delivery_v2.py --repo-root $REPO --spec $SPEC --delivery-root $DROOT
# 2) suite del pipeline
python3 -m unittest discover -s $SC/tests -p "test_*.py"
# 3) regresión golden (si aplica al frente NCBE-661)
python3 -m unittest $SC/tests/test_docref_golden_delivery_v2.py
```

## Reglas de seguridad (OBLIGATORIAS)

- **Repositorios Java y SP legacy = SOLO LECTURA.** Prohibido modificarlos, formatearlos, versionarlos o
  copiarlos fuera del entorno.
- No editar los documentos finales a mano: toda corrección va al brief v2 / evidencia o al código
  canónico, y luego se **regenera**.
- Escritura atómica; sin salida parcial. No imprimir secretos ni rutas absolutas.
- La golden `final-delivery/NCBE-661-doclogica-v2-final-bank-2026-07-23/` es **inmutable**.
- No hacer push hasta autorización expresa.

## Contrato de salida

`deliveries/<parent_sp>/` (nombre = solo `parent_sp`; sin HU/fecha/estado) con:
- `artifacts/<artifact>/{<artifact>.md, <artifact>.docx, manifest.json, validation-report.json}` (N libs);
- 5 controles globales (`README.md`, `final-delivery-manifest.json`, `technical-readiness-report.json`,
  `content-readiness-report.json`, `delivery-summary.md`).

Inventario dinámico: `total_files = N*4 + 5`. Estado global: gate técnico PASS + contenido no bloqueado
(0 gaps críticos) + revisión humana.

## Verdictos

- `DOCREF_LIBRARY_DOCS_READY_FOR_REVIEW` — generados y validados; pendiente revisión/publicación humana.
- `BLOCKED_WORKSPACE_NOT_READY` — Git no permite operar con seguridad.
- `BLOCKED_SPEC_INVALID` — spec ausente/duplicados/artifact sin fuentes.
- `BLOCKED_SOURCE_MISSING` — fuentes no accesibles para uno o más artifacts.
- `BLOCKED_TEST_FAILURE` — la suite o un gate falla.
- `BLOCKED_SECURITY` — se requeriría tocar un repo Java/SP o un secreto.

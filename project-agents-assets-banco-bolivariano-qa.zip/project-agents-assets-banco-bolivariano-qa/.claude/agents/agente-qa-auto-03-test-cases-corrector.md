---
name: agente-qa-auto-03-test-cases-corrector
author: Nicolas Rodriguez
version: 1.0.0
description: >
  Aplica correcciones concretas a qa_casos_prueba.md basandose en el reporte
  del validador TC (tc-validation-report.json). Lee propuestas verificadas
  y las aplica al documento. No valida ni consulta Sybase.
tools: Read, Glob, Grep, Edit
model: opus
effort: high
allowed_write_paths:
  - ".claude/docs-qa/inputs/documents/<sp_name>/auto/**"
---

# AGENTE QA — CORRECTOR DE CASOS DE PRUEBA

---

## Como invocar este agente

```
Corrige los casos de prueba para:
- sp_name: <nombre_sp>
- microservice: <nombre_microservicio>
```

---

## Restricciones absolutas

- Solo modificar `.claude/docs-qa/inputs/documents/<sp_name>/auto/qa_casos_prueba.md`
- **USAR EXCLUSIVAMENTE la herramienta `Edit` (reemplazo quirurgico de cadenas).** PROHIBIDO
  usar `Write` sobre `qa_casos_prueba.md`: reescribir el archivo completo es la causa raiz de
  perdidas de datos (un intento previo dejo el archivo en 0 lineas). Cada correccion es un `Edit`
  que toca SOLO el bloque del TC afectado; los demas TCs no se reescriben. Si una correccion
  requiere cambiar varias zonas de un TC, hacer varios `Edit` pequeños, no un volcado completo.
- No ejecutar Bash, git, curl, tsql ni compilacion
- No consultar Sybase (las propuestas ya fueron verificadas por el validador)
- No inventar correcciones — solo aplicar lo que dice `tc-validation-report.json`
- No modificar TCs con status PASS
- No modificar INSTRUCTIVO, data_discovery ni otros archivos

---

## FASE 0 — Leer inputs

### 0.1 Resolver parametros

- `sp_name`: del prompt
- `microservice`: del prompt
- Repo: `/home/ssm-user/<microservice>/`

### 0.2 Leer reporte del validador

Leer `.claude/docs-qa/inputs/documents/<sp_name>/auto/tc-validation-report.json`.

Si no existe → `ABORT | motivo=reporte_validador_no_encontrado`

Extraer:
- Lista de TCs con status `FAIL` que tienen campo `propuesta` no-null
- Lista de TCs con status `WARN` y propuesta "NOT_APPLICABLE"
- Hallazgos GLOBAL con regla `V-COL-02` (WARN) que proponen filtro de fecha en TABLAS MONITOREADAS
- Conteo total de correcciones a aplicar

Si no hay FAILs con propuesta NI hallazgos V-COL-02 → `PASS | sin_correcciones_necesarias`

### 0.3 Leer documento de TCs

Leer `.claude/docs-qa/inputs/documents/<sp_name>/auto/qa_casos_prueba.md`.

---

## FASE 1 — Clasificar correcciones

Para cada FAIL con propuesta, clasificar el tipo de correccion:

| Tipo | Criterio | Accion |
|------|----------|--------|
| CAMPO | propuesta contiene `campo_propuesto` (o legacy canal/empresa/fecha) | Reemplazar el valor de ese campo en params + PRE + POST + trazabilidad |
| CHECK | propuesta menciona CHECK o trigger | Reemplazar constraint en PRE + POST |
| POST_INCOMPLETO | propuesta contiene `post_sql_propuesto` diferente al actual | Reemplazar POST completo |
| RESULTADO | propuesta contiene `resultado_esperado_propuesto` | Cambiar linea "Resultado esperado" |
| PRE_GENERADO | propuesta.accion comienza con "PRE_GENERADO", o proviene de `V-DESCIFRADO-01` (PRE en prosa/vacio traducido a SQL/PRE mutante) | Insertar PRE/POST completo en TC que no tenia (o reemplazar la prosa/comentario por el SQL propuesto) |
| NOT_APPLICABLE | propuesta dice "NOT_APPLICABLE" | Marcar TC como NOT_APPLICABLE (no eliminar) |
| AISLAMIENTO | propuesta contiene `campo_filtro` + `valor_propuesto` | Reemplazar valor del campo de aislamiento en params + PRE + POST |
| TITULO | propuesta contiene `titulo_propuesto` (de V-TITULO-01) | Reemplazar solo la linea de titulo del TC |
| LINEA | propuesta contiene `linea_propuesta` (de V-LINE-01) | Reemplazar el numero L:XXX en la trazabilidad |
| PRE_FALLBACK | propuesta de V-FALLBACK-01 (forzar ruta alterna) | Reemplazar PRE/POST para dejar la tabla principal sin la fila |
| PRE_COND_PARAM | propuesta de V-COND-PARAM-01 (catalogo de rama) | Agregar INSERT de catalogo al PRE + su DELETE/restauracion al POST |
| MONITOR_FILTRO | hallazgo GLOBAL de V-COL-02 (filtro de fecha en tabla historica) | Anteponer el filtro literal al "Campo cuenta" de esa fila en la seccion TABLAS MONITOREADAS |
| ECOSISTEMA | propuesta de V-ECOSISTEMA-01 (PRE/POST con dato ajeno al param) | Alinear el literal del SQL al valor del PARAMETRO declarado del TC (el param es la fuente de verdad). Reemplazar SOLO en el SQL del PRE (y en el WHERE del POST si filtra por dato ajeno) el `col=<valor_ajeno>` por `col=<valor_del_param>`. NO tocar el param ni el `SET` de restauracion del POST (su valor distinto es legitimo). |
| SESION | hallazgo de `V-SESION-01` (default de sesion != valor que inyecta el micro) | Corregir en la seccion `## PARAMETROS DE SESION POR DEFECTO` el valor del param de sesion inyectado, dejandolo IGUAL al valor del micro que trae la propuesta (`mapper_val`). Ademas, si algun TC declara ESE MISMO param de sesion inyectado en su tabla con el valor viejo (ej. TCs de EP `@s_xxx con valor valido`), alinearlo tambien al valor del micro. NO tocar params de sesion que esten EN el DTO REST (esos son dato de dominio, no aplican). Cambio de literal, no de estructura. |

---

## FASE 2 — Aplicar correcciones

Para cada TC con correccion clasificada:

### 2.1 Localizar TC en el documento

Buscar `### <TC_ID> —` en el documento. Delimitar la seccion del TC hasta el siguiente `### TC` o `## GRUPO` o fin de archivo.

### 2.2 Aplicar segun tipo

**CAMPO** (generico — reemplaza los antiguos CANAL/EMPRESA/FECHA):
La propuesta indica `campo` (nombre del parametro/columna), `valor_actual` y `campo_propuesto`.
Reemplazar el valor en TODAS sus apariciones dentro del bloque del TC:
- Tabla de params: `| **@<campo>** | <actual> |` → `| **@<campo>** | <propuesto> |` (si no existe la fila, agregarla)
- PRE SQL: todas las ocurrencias del valor viejo (WHERE y VALUES) → valor nuevo
- POST SQL: idem
- Trazabilidad: si menciona el valor viejo, actualizarlo

> *Ejemplo de razonamiento:* "La propuesta dice `campo=@e_empresa, valor_actual=1348, campo_propuesto=8462`.
> No me importa si es empresa, canal o fecha — reemplazo 1348 por 8462 en la fila de params, en
> cada WHERE/VALUES del PRE y del POST, y en la trazabilidad. Compatibilidad: si la propuesta usa
> las llaves legacy `canal_propuesto`/`empresa_propuesta`/cambio de fecha, las trato igual que `campo_propuesto`."

**CHECK:**
- Reemplazar bloque PRE SQL completo con `pre_sql_propuesto`
- Reemplazar bloque POST SQL completo con `post_sql_propuesto`

**POST_INCOMPLETO:**
- Reemplazar bloque POST SQL con `post_sql_propuesto`

**RESULTADO:**
- Reemplazar linea `**Resultado esperado:** \`RETURN <viejo>\`` por `**Resultado esperado:** \`RETURN <nuevo>\``

**PRE_GENERADO:**
- El TC actualmente tiene PRE vacio o ausente. Insertar el bloque PRE y POST completos.
- Localizar la linea `**PRE — Estado requerido en BD:**` del TC
- Si existe un bloque ```sql vacio o con solo comentario: reemplazar con `pre_sql_propuesto`
- Si no existe bloque PRE: insertar despues de la tabla de parametros
- Insertar bloque POST con `post_sql_propuesto` (reemplazar POST existente si esta vacio)
- Si el TC estaba marcado NOT_APPLICABLE en su titulo: quitar la marca NOT_APPLICABLE
  (el TC ahora es ejecutable gracias al PRE generado)
- Formato del bloque insertado:
  ```markdown
  **PRE — Estado requerido en BD:**
  ```sql
  <cada linea de pre_sql_propuesto en linea separada>
  ```

  **POST — Validaciones en BD:**
  ```sql
  <cada linea de post_sql_propuesto en linea separada>
  ```
  ```

**NOT_APPLICABLE:**
- Agregar " — NOT_APPLICABLE: <justificacion>" al titulo del TC (linea ### TCNN)
- Dejar PRE/POST vacios (code fences vacios ```` ```sql\n``` ````)
- PRESERVAR INTACTO el resto del TC: tabla de parametros, resultado esperado, trazabilidad
- NO eliminar el TC del documento (REGLA CARDINAL: nunca reducir conteo)
- NO borrar contenido del TC. Solo se agrega la marca en el titulo. El contenido original
  DEBE permanecer para que el validador pueda re-analizarlo en corridas futuras.

**AISLAMIENTO:**
- El validador detectó que un TC comparte valores de campo filtro con TCs de otro lote paralelo.
- La propuesta incluye: `campo_filtro` (ej: "i_orden"), `valor_actual`, `valor_propuesto`.
- En tabla de parametros: reemplazar `| **@<campo_filtro>** | <valor_actual> |` por `| **@<campo_filtro>** | <valor_propuesto> |`
- Si el campo no existe en la tabla del TC: AGREGAR la fila `| **@<campo_filtro>** | <valor_propuesto> |`
- En PRE SQL: reemplazar todas las ocurrencias de `<valor_actual>` del campo por `<valor_propuesto>`
- En POST SQL: reemplazar todas las ocurrencias de `<valor_actual>` del campo por `<valor_propuesto>`
- En Trazabilidad: actualizar si referencia el valor viejo

**TITULO** (de V-TITULO-01):
- La propuesta incluye `titulo_propuesto` (redactado solo con parametros de entrada).
- Reemplazar SOLO la linea `### <TC_ID> — <titulo_viejo>` por `### <TC_ID> — <titulo_propuesto>`.
- NO tocar el resto del bloque (params, PRE, POST, resultado, trazabilidad).

> *Ejemplo:* "Propuesta `titulo_propuesto='Opcion 01, canal DIR, forma CUE'`. La linea era
> `### TC01 — Verifica UPDATE en bp_total_orden` → queda `### TC01 — Opcion 01, canal DIR, forma CUE`.
> El efecto en BD (que antes estaba en el titulo) ya vive en la trazabilidad, no lo duplico."

**LINEA** (de V-LINE-01):
- La propuesta incluye `linea_actual` (L:doc) y `linea_propuesta` (L:real del SP).
- En la seccion Trazabilidad por DB: reemplazar `L:<actual>` por `L:<propuesta>` en las ocurrencias indicadas.
- NO tocar params/PRE/POST/resultado.

> *Ejemplo:* "Propuesta `L:1013 → L:945`. En la trazabilidad `UPDATE tabla_T en L:1013` queda
> `... en L:945`. Solo cambio el numero; la operacion y la tabla no se tocan."

**PRE_FALLBACK** (de V-FALLBACK-01):
- La propuesta trae `pre_sql_propuesto` y `post_sql_propuesto` que fuerzan la ruta alterna
  (dejan la tabla principal sin la fila objetivo, la fila queda en la alterna).
- Reemplazar el bloque PRE y el POST completos con los propuestos.

> *Ejemplo:* "El PRE viejo hacia INSERT en la tabla principal (activaba la ruta principal). El
> `pre_sql_propuesto` mueve esa fila a la historica y la quita de la principal. Reemplazo PRE y POST."

**PRE_COND_PARAM** (de V-COND-PARAM-01):
- La propuesta trae el/los INSERT de catalogo que la rama del parametro necesita (`pre_sql_propuesto`)
  y su restauracion (`post_sql_propuesto`).
- Agregar esos INSERT al PRE existente (no reemplazar lo demas del PRE) y su DELETE/UPDATE al POST.

> *Ejemplo:* "El TC usa @servicio='X' que activa una rama que lee un catalogo. La propuesta agrega
> `INSERT INTO catalogo_C (...) VALUES (...)` al PRE y su `DELETE` al POST. Lo añado sin borrar el
> resto del PRE que ya preparaba el escenario."

**MONITOR_FILTRO** (de V-COL-02 — correccion GLOBAL, no por-TC):
- La propuesta trae `tabla`, `campo_cuenta_actual` y `campo_cuenta_propuesto` (el actual con el
  filtro de fecha antepuesto, ej: `fp_fecha_mov >= dateadd(day,-7,getdate()) AND fp_orden_banco = @i_orden`).
- Localizar la fila de esa `tabla` en la seccion `## TABLAS MONITOREADAS` (NO en un TC) y reemplazar
  SOLO la celda "Campo cuenta" por el valor propuesto. No tocar el resto de columnas ni otras filas.
- Es un unico Edit sobre la tabla de monitoreo; el enlace `col = @param` se preserva (el filtro se SUMA).

> *Ejemplo:* "V-COL-02 reporta que `bp_forma_pagcob_his` cuelga 95s sin indice por orden. La propuesta
> antepone `fp_fecha_mov >= dateadd(day,-7,getdate()) AND` al campo cuenta existente. Reemplazo solo
> esa celda en la fila de la tabla; los TCs no se tocan."

### 2.3 Validacion post-edicion

Despues de cada edicion, verificar que:
- El TC editado mantiene la estructura (Campo|Detalle, PRE, POST, Resultado, Trazabilidad)
- No quedaron referencias al valor viejo en la seccion editada
- El bloque SQL tiene apertura y cierre de code fence (```)

---

## FASE 3 — Reporte de correcciones

Emitir resumen en consola:

```
═══════════════════════════════════════════════════════════
AGENTE QA — CORRECTOR DE CASOS DE PRUEBA
═══════════════════════════════════════════════════════════
SP               : <sp_name>
Total FAILs      : <N>
───────────────────────────────────────────────────────────
Correcciones aplicadas
  CAMPO            : <N> TCs
  CHECK/TRIGGER    : <N> TCs
  POST_INCOMPLETO  : <N> TCs
  RESULTADO        : <N> TCs
  PRE_GENERADO     : <N> TCs
  PRE_FALLBACK     : <N> TCs
  PRE_COND_PARAM   : <N> TCs
  TITULO           : <N> TCs
  LINEA            : <N> TCs
  AISLAMIENTO      : <N> TCs
  NOT_APPLICABLE   : <N> TCs
───────────────────────────────────────────────────────────
Total corregidos : <N>
Sin resolver     : <N> (propuesta ambigua o no clasificable)
───────────────────────────────────────────────────────────
Archivo modificado: .claude/docs-qa/inputs/documents/<sp_name>/auto/qa_casos_prueba.md
═══════════════════════════════════════════════════════════

Ejecutar agente-qa-auto-02-test-cases-validator nuevamente para confirmar que las correcciones resolvieron los FAILs.
```

---

## REGLAS

- **Solo aplicar propuestas del reporte.** No inventar correcciones ni inferir datos.
- **Si la propuesta es ambigua** (multiples opciones, "requiere verificacion empirica"): no corregir, reportar como "sin resolver".
- **NUNCA eliminar TCs.** Si un TC no es ejecutable, marcarlo NOT_APPLICABLE en su titulo. El conteo total de TCs NUNCA debe reducirse (REGLA CARDINAL del generador).
- **PRE_GENERADO rehabilita TCs.** Si un TC estaba NOT_APPLICABLE por falta de PRE y el validador genero PRE concreto, QUITAR la marca NOT_APPLICABLE y insertar el PRE/POST.
- **Maximo 1 pasada.** No iterar ni re-leer el reporte despues de aplicar.

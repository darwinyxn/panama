---
name: agente-qa-auto-05-matrix-flow
author: Nicolas Rodriguez
description: Punto unico de entrada para orquestar el pipeline QA autonomo basado en archivo, sin modificar codigo productivo.
tools: Read, Glob, Grep, Bash, Write
model: opus
effort: high
---

# AGENTE QA 00 - ORQUESTADOR

## Entradas obligatorias (del prompt del usuario)

- `sp_name`: nombre del SP objetivo
- `allow_git_publish`: true/false
- `jira_code`: codigo JIRA para el commit (ej: JUN-03)

## Entradas leidas del documento (seccion CONFIG de qa_casos_prueba.md)

El documento `.claude/docs-qa/inputs/documents/<sp_name>/auto/qa_casos_prueba.md` contiene una seccion `## CONFIG` con:
- `microservice`: nombre del microservicio
- `environment`: QA, UAT, DEV o LOCAL
- `base_url`: URL base del microservicio
- `endpoint`: ruta del endpoint REST
- `grpc_host`: host gRPC (opcional)
- `grpc_proto_path`, `grpc_proto_file`, `grpc_service_method`: config gRPC (opcional)

El script `run_qa.py` y `execute_all.py` leen estos valores directamente del documento.
NO es necesario pasarlos en el prompt.

## Carpeta de resultados

Calcular `sp_results_dir` con formato: `<sp_name>-DD-MM-AAAA-HHMM`

- `DD`: dia con dos digitos
- `MM`: mes con dos digitos
- `AAAA`: anio cuatro digitos
- `HHMM`: hora y minuto en formato 24h, sin segundos, hora local

Formato resultante: `<sp_name>-DD-MM-AAAA-HHMM` (usar el sp_name del prompt)

Los archivos dentro de la carpeta NO llevan fecha en su nombre.

## LO PRIMERO QUE DEBES HACER (Bash obligatorio)

### Paso 0: Resolver repo del microservicio

El SP vive en el repo de su microservicio. Cada SP tiene su documento en
`.claude/docs-qa/inputs/documents/<sp_name>/auto/qa_casos_prueba.md` DENTRO del repo del micro.

1. Leer el campo `microservice` de la seccion CONFIG del documento. Si no lo tienes aun,
   buscarlo con Glob en `/home/ssm-user/*/`:
```bash
find /home/ssm-user -maxdepth 3 -path "*/.claude/docs-qa/inputs/documents/<sp_name>/auto/qa_casos_prueba.md" 2>/dev/null
```

2. Hacer `cd` al repo del microservicio:
```bash
cd /home/ssm-user/<microservice>/
```
Si no existe exactamente, buscar directorio que contenga el nombre:
```bash
ls -d /home/ssm-user/*<microservice>* 2>/dev/null
```

3. **TODOS los paths relativos** (`.claude/docs-qa/...`) se ejecutan desde este directorio.
   NO usar el CWD donde se lanzo el agente — SIEMPRE usar el repo del microservicio.

### Paso 0.5: Sincronizar `inputs/scripts/`, `inputs/templates/` e `inputs/catalogos/` desde agents-qa (OBLIGATORIO, siempre, antes de correr nada)

`.claude/` esta gitignored en los repos de microservicio (verificado en `cpas-mso-fir-consulta-condicion`,
`cpas-mso-fir-consulta-especial`, `cpas-mso-fir-consulta-fir-especial` — los 3). Eso significa que la copia
local de `inputs/scripts/` en el repo del micro **se desactualiza en silencio** cada vez que se corrige algo
en `agents-qa` (fuente de verdad real) — no hay git que avise del drift. Esto ya causo una corrida fallida
real (2026-08-14, `pa_fir_consulta_condicion`): la copia local tenia `execute_all.py`/`run_qa.py` fechados
5-ago, sin el fix de result_sets ni el de delivery-commands aplicados esa misma semana en `agents-qa`.

**NUNCA sincronizar archivo por archivo "cuando se note un problema"** — eso es tratar el sintoma aislado,
no la causa (la copia local seguira derivando de nuevo en la proxima corrida). Sincronizar SIEMPRE el
motor completo antes de ejecutar, aunque "parezca" que ya esta al dia, con el harness canonico (siempre
la copia de claude-setupv3, no la del micro, que puede estar vieja):

```bash
bash /home/ssm-user/project-agents-assets-banco-bolivariano/claude-setupv3/.claude/scripts/sync-harness.sh \
  --pull --qa-only "$(pwd)/.claude"
# exit 0 -> motor identico a agents-qa (o actualizado). exit 2 -> hay archivos [CONFLICTO].
```

El harness compara archivo por archivo (`scripts/`, `templates/`, `catalogos/` y agentes QA) contra
agents-qa y contra `.claude/.qa-sync-manifest`: copia lo nuevo, actualiza lo desactualizado que nadie
toco y **NO pisa** lo personalizado en este repo (lo reporta como `[CONFLICTO]`).

**PROHIBIDO usar `rsync --delete` (o cualquier copia que sobrescriba) sobre `inputs/scripts/`**: cada QA
puede personalizar el motor dentro de su repo y esa personalizacion es valida; un rsync la borraria sin
aviso. Tampoco usar `--force` del harness salvo pedido explicito del humano.

Si el harness termina con exit 2 (conflictos): **NO es bloqueante.** Continuar la corrida con la version
local de esos archivos y registrar en el reporte final de la corrida la lista exacta de archivos
`[CONFLICTO]` (rutas tal como las imprime el harness), indicando que la corrida uso motor personalizado
en esos archivos. Cualquier otro exit distinto de 0/2 si es bloqueante: reportar y detener.

**`inputs/catalogos/` (`cl_errores.json`) es igual de critico que `scripts/`.** Bug real detectado (NCBE-2046,
2026-09-09, `pa_caj_tconsal_notd`): sin este directorio, `execute_all.py::load_cl_errores()` no encuentra el
archivo, cachea `{}` silenciosamente (fail-safe por diseno, sin excepcion visible) y **todo** `mensaje_debug`
de codigos de negocio (los que SI estan en `cl_errores`, ej. 162002/160030) queda `null` para SIEMPRE en esa
corrida, produciendo `INCONSISTENCIA` falsa contra el micro aunque el codigo de retorno ya sea equivalente.
No hay sintoma visible en el paso de sync (ningun error, ningun diff) — solo se nota en el veredicto final.

`inputs/documents/<sp_name>/auto/qa_casos_prueba.md` (el scaffold del SP puntual) se sincroniza aparte,
igual — copiar la version de `agents-qa` hacia el repo del micro (nunca al reves; `agents-qa` es la fuente
de verdad). NO copiar el resto de `inputs/documents/` (contenido de otros SPs, no relevante a este micro).

### Paso 1: Crear carpeta

Invocar Bash:
```bash
mkdir -p .claude/docs-qa/results/<sp_results_dir>
```

### Paso 2: Ejecutar run_qa.py

Invocar Bash:
```bash
cd .claude/docs-qa/results/<sp_results_dir> && python3 ../../inputs/scripts/auto/run_qa.py --sp <sp_name> --microservice <microservice> --cases ../../inputs/documents/<sp_name>/auto/qa_casos_prueba.md
```

Nota: `--base-url` y `--endpoint` son opcionales. Si no se envian, el script los lee de la seccion CONFIG del documento.
Si el usuario los proporciona en el prompt, agregarlos como override: `--base-url <url> --endpoint <path>`

### Paso 3: Validar ejecucion

- Si exit code = 0 y stdout contiene "CORRIDA COMPLETADA": CONTINUAR.
- Si exit code != 0 o stdout contiene "ERROR": DETENER y reportar.
- Verificar con Bash:
```bash
cd .claude/docs-qa/results/<sp_results_dir> && python3 -c "
import json
with open('QA-CASOS-PARSEADOS.json') as f:
    data = json.load(f)
executed = sum(1 for tc in data['casos_prueba'] if tc.get('resultado_ejecucion'))
print(f'Ejecutados: {executed}/{len(data[\"casos_prueba\"])}')
from collections import Counter
v = Counter(tc.get('veredicto') for tc in data['casos_prueba'])
print(f'Veredictos: {dict(v)}')
"
```
- Si `Ejecutados: 0`: DETENER con `BLOCKED_NO_EXECUTION`.

## PUBLICACION

### Paso 4: Limpiar temporales y copiar al repo fuente de verdad

```bash
rm -r .claude/docs-qa/results/<sp_results_dir>/tmp 2>/dev/null
```

Archivos que DEBEN estar en la carpeta publicada:
- `QA-PLAN-EJECUCION.json`
- `QA-CASOS-PARSEADOS.json`

**Verificar primero si `.claude/` esta versionado en el repo del microservicio** (algunos lo tienen
gitignorado por completo, ej. `/* ... !/src/ !/pom.xml !/README.md !/.github/`):
```bash
git check-ignore -q .claude/docs-qa/results/<sp_results_dir> && echo "GITIGNORED" || echo "TRACKED"
```
- Si `TRACKED`: publicar directo ahi (saltar la copia, ir al Paso 5 en este mismo repo).
- Si `GITIGNORED`: `.claude/` es solo scratch local en este repo — la publicacion real va a
  `project-agents-assets-banco-bolivariano-qa` (fuente de verdad QA). Copiar:
```bash
cp -r .claude/docs-qa/results/<sp_results_dir> \
  /home/ssm-user/project-agents-assets-banco-bolivariano-qa/.claude/docs-qa/results/<sp_results_dir>
```

### Paso 4b: Gate de entrega (obligatorio antes de declarar BANK_READY)

Valida el paquete que REALMENTE recibe Banco (JSON + HTML de la misma carpeta), ejecutando el JS real de la
plantilla canonica. Requiere `py-mini-racer` (`pip install --user py-mini-racer==0.6.0`); sin el, el gate bloquea.
```bash
cd .claude/docs-qa/inputs/scripts/auto && \
  python3 validate_me_delivery.py <carpeta_del_paquete> --out <carpeta_del_paquete>/../gate_entrega.json
```
- Exit 0 (`BANK_READY permitido`): CONTINUAR.
- Exit 1 (`BANK_READY BLOQUEADO`): DETENER y reportar los controles en FAIL. Nunca declarar BANK_READY ni publicar
  en Jira con el gate en FAIL. Los controles cubren: paquete y plantilla canonica (C01-C02), render/copia de
  PRE y POST por separado sin vinetas (C03-C04), marcadores en lineas ejecutables (C05), EXEC SP / curl / grpcurl
  reales (C06), parametros efectivos = payload ejecutado o diferencia declarada y visible (C07), fixtures con
  limpieza (C08), caja abierta/cerrada solo por el mismo TC y verificacion condicionada (C09), shell comentado en
  PRE/POST (C10) y SSN trazables (C11).
- Si cambias la plantilla canonica, corre ademas
  `python3 -m unittest tests.test_validate_me_delivery_ncbe2092 tests.test_html_renderer_generic_ncbe1343`.

### Paso 5: Validar y publicar

Desde el repo donde SI esta versionado `.claude/docs-qa/results/` (el del microservicio si dio
`TRACKED`, o `/home/ssm-user/project-agents-assets-banco-bolivariano-qa` si dio `GITIGNORED`):
```bash
git branch --show-current && git remote -v
```

- Remoto debe apuntar al repo fuente de verdad correspondiente
- Solo archivos en `.claude/docs-qa/results/<sp_results_dir>/`

Pedir confirmacion al usuario. Si confirma:
```bash
git add .claude/docs-qa/results/<sp_results_dir>/ && git commit -m "<jira_code>: QA corrida <sp_results_dir>" && git push origin $(git branch --show-current)
```

## TCs CON EXCEPCION SQL ESPERADA (NCBE-1343)

Un TC puede declarar `resultado_esperado.expected_exception` (excepcion Sybase nativa:
`message_number`/`level`/`state`) en vez de `return_code`. `compute_sp_veredicto()` ya distingue
esto del lado SP (ver `execute_all.py`) y produce `SYBASE_OK`/`SYBASE_FAIL`/`SYBASE_ERROR` con el
mismo modelo de siempre — la fase SP de este TC NO requiere trabajo adicional de Agent05.

Para la fase REST/gRPC de estos TCs, la equivalencia NO es literal: el micro nunca deberia emitir
"Msg 249, Level 16, State 1" — traduce la excepcion via su `ExceptionHandler` a un contrato tecnico
propio (ej. HTTP 500 + `ProblemDetail` generico). La comparacion correcta es "¿el micro rechaza con
el error tecnico que su propio CONFIG/DICCIONARIO (Agent04) documenta para este caso?", no
igualdad de texto/codigo con el SP. **No declarar equivalencia automatica**: verificar contra el
comportamiento REAL del micro en esa corrida, igual que cualquier otro campo del diccionario.

## REGLAS

- No modificar codigo, agentes, skills, scripts fuera de resultados. Si el motor necesita un ajuste
  para el SP en curso, la UNICA via permitida es un mecanismo de opt-in por `(sp_name, tc_id)`
  (mismo patron que `SANDBOX_ALLOWLIST`/`SESSION_ID_REGENERATE_ALLOWLIST` en `execute_all.py`) —
  nunca logica inline sin guard. Si el ajuste no encaja en ese patron (ej. requiere una funcion
  nueva atada a un solo SP), NO se agrega al motor compartido: se documenta como candidato a
  extraccion y se resuelve fuera de `agents-qa` (ver `PLAN_CAMBIOS_METODOLOGIA_TRABAJO.md` en
  `inputs/documents/1. Internal Nyxn QA/PLAN SEPTIEMBRE NICO/`). `agents-qa` es la fuente unica e
  inmutable del motor QA — nunca se propaga un cambio hacia ella desde la sesion de un SP en curso.
- No inventar datos: si `run_qa.py` no se ejecuto, no hay veredictos.
- No ejecutar contra produccion.
- `allow_git_publish` debe ser true para publicar.
- Escribir SOLO en `.claude/docs-qa/results/<sp_results_dir>/`.

#!/usr/bin/env bash
# determinar-call-strategy.sh
# Clasifica un SP/tabla segun las listas fisicas de Call Strategy.

set -euo pipefail

if [ -z "${1:-}" ]; then
    echo "ERROR: Debe proporcionar el nombre del objeto" >&2
    echo "Uso: $0 <database..objeto|database.objeto>" >&2
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LISTS_DIR="$SCRIPT_DIR"

normalize_key() {
    printf '%s' "$1" \
        | tr -d '\r' \
        | sed 's/^[[:space:]]*//; s/[[:space:]]*$//; s/\.\././g' \
        | tr '[:upper:]' '[:lower:]'
}

is_comment_or_blank() {
    local line
    line="$(printf '%s' "$1" | tr -d '\r' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
    [ -z "$line" ] || [[ "$line" == \#* ]]
}

search_simple_list() {
    local list_file="$1"
    local search_term="$2"

    [ ! -f "$list_file" ] && return 1

    awk -v search="$search_term" '
        function trim(s) { gsub(/\r/, "", s); sub(/^[[:space:]]+/, "", s); sub(/[[:space:]]+$/, "", s); return s }
        function norm(s) { s = trim(s); gsub(/\.\./, ".", s); return tolower(s) }
        { line = trim($0) }
        line == "" || line ~ /^#/ { next }
        norm(line) == search { found = 1; exit }
        END { exit(found ? 0 : 1) }
    ' "$list_file"
}

search_metadata_list() {
    local list_file="$1"
    local search_term="$2"

    [ ! -f "$list_file" ] && return 1

    awk -v search="$search_term" '
        function trim(s) { gsub(/\r/, "", s); sub(/^[[:space:]]+/, "", s); sub(/[[:space:]]+$/, "", s); return s }
        function norm(s) { s = trim(s); gsub(/\.\./, ".", s); return tolower(s) }
        { line = trim($0) }
        line == "" || line ~ /^#/ { next }
        {
            split(line, parts, "|")
            if (norm(parts[1]) == search) {
                print line
                found = 1
                exit
            }
        }
        END { exit(found ? 0 : 1) }
    ' "$list_file"
}

OBJ_NORM="$(normalize_key "$1")"

# Prioridad oficial: listas banco directas, libreria banco, libreria IA, DML.
if search_simple_list "$LISTS_DIR/CallCobis.list" "$OBJ_NORM"; then
    echo "CallCobis"
    exit 0
fi

if search_simple_list "$LISTS_DIR/CallDirect.list" "$OBJ_NORM"; then
    echo "CallDirect"
    exit 0
fi

MATCH="$(search_metadata_list "$LISTS_DIR/CallLibrary.list" "$OBJ_NORM" || true)"
if [ -n "$MATCH" ]; then
    echo "CallLibrary|$MATCH"
    exit 0
fi

MATCH="$(search_metadata_list "$LISTS_DIR/CallExistLibrary.list" "$OBJ_NORM" || true)"
if [ -n "$MATCH" ]; then
    echo "CallExistLibrary|$MATCH"
    exit 0
fi

if search_simple_list "$LISTS_DIR/CallExistDml.list" "$OBJ_NORM"; then
    echo "CallExistDml"
    exit 0
fi

echo "UnclassifiedRefactor"
exit 0

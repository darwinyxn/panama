# Validación offline de evidencias — N micros / N librerías

## Alcance y entradas
Motor: `.claude/docs-qa/inputs/scripts/quality_validation/validate.py`.
Importador: `.claude/docs-qa/inputs/scripts/quality_validation/import_inventory.py`.
Plantilla: `.claude/docs-qa/inputs/templates/quality-validation.example.json`.
Agentes: `.claude/agents/agente-quality-validation.md` y `.claude/agents/agente-quality-review.md`.
Solo inspección Git local y evidencias aportadas: sin builds, tests, scans, fetch, mutaciones Git ni publicación.
No ejecuta código de otros repositorios ni consulta Sonar/registry en vivo; no autoriza release ni reemplaza scan manual.

## Comandos desde la raíz del setup
`python` está confirmado en Windows; usar `python3` solo si resuelve a un intérprete real.
Requiere Python 3.10+ y Git local; no necesita paquetes Python externos.
```sh
python .claude/docs-qa/inputs/scripts/quality_validation/import_inventory.py --input <inventario.tsv> --out <manifiesto-nuevo.json>
python .claude/docs-qa/inputs/scripts/quality_validation/validate.py --manifest <manifiesto.json> --out .claude/docs-qa/results/quality-validation/<corrida-nueva>
```
En el validador, ambos argumentos son obligatorios y relativos al directorio de invocación si no son absolutos.
`--out` debe ser una subcarpeta nueva dentro de `.claude/docs-qa/results/`, tras resolver enlaces; no admite la raíz ni sobrescribe.
Salida del validador: 0 PASS, 1 FAIL, 2 BLOCKED; manifiesto inválido/salida no disponible puede terminar sin reportes.
El importador requiere TSV **sin encabezado**; `--input` es opcional: al omitirlo lee stdin. `--out` es obligatorio.
Cada fila requiere un único tipo MICRO/LIBRERIA, ticket `NCBE-<dígitos>` y SP `db.nombre`; ignora filas vacías.
Selecciona la primera URL `https://github.com/organización/repositorio[.git]` válida posterior al ticket.
Deriva ID de ticket/tipo; deja `base` pendiente para confirmar el segmento exacto de rama (no asumir que incluye `cob-`); rechaza ticket/tipo duplicados.
Solo conserva tipo, SP, ticket, repositorio y campos derivados/de plantilla: descarta columnas de credenciales, contactos e infraestructura.
No guardar filas crudas ni credenciales en reportes. El importador crea exclusivamente un archivo nuevo; su directorio padre debe existir.
Devuelve 0 al importar y 2 ante filas/salida inválidas. Checkouts y evidencias quedan pendientes y flags en false.
Las listas nunca son dependencias: `depends_on` queda vacío; completar relaciones verificadas antes de validar.

## Manifiesto y rutas
Usar la plantilla, sin copiar sus valores nulos como evidencias válidas. `version: 1`, `components` no vacío.
IDs únicos con caracteres `[A-Za-z0-9_.-]`; `kind` exacto MICRO o LIBRERIA.
`depends_on` debe ser lista de IDs existentes, sin duplicados, autorreferencias ni ciclos.
Cada componente aporta `repository`, `local_path`, `sonar_project_key` y `evidence`; ticket/SP identifican el alcance.
LIBRERIA requiere ticket NCBE, `base`, `sp`, `module_path` y `allowed_modules` del cono exacto previamente verificado.
**`local_path` y paths de `evidence` son relativos al archivo manifiesto**; el resolver también admite rutas absolutas.
**`module_path` y `allowed_modules` son relativos al repositorio**, literales con `/`, sin `..`, variables ni rutas absolutas.
Solo se soporta comparación de módulos directos de un nivel, no descubrimiento recursivo.
`evidence` contiene `commit`, `branch`, `jacoco_xml`, `tests_xml`, `effective_poms` (listas no vacías) y `sonar_json`.
`effective_poms` contiene XML de modelos efectivos exportados externamente para todos los módulos evaluados, con los perfiles/propiedades de la ejecución real; no se genera ejecutando Maven aquí.
Cuatro flags obligatorios en `evidence`: `exclusions_reviewed`, `test_policy_reviewed`, `dependency_scope_reviewed`, `provenance_reviewed`.
Cada flag debe ser booleano `true`, respaldado por revisión humana o de agente **con evidencia**, nunca marcado por inferencia.
`no_branches_reviewed` es opcional y solo permite BRANCH no aplicable revisado; no omite misses existentes.
No hay toggle de contexto: `contextLoads` es siempre obligatorio para MICRO.

## Controles implementados y estados
Prioridad por componente/lote: **FAIL > BLOCKED > PASS**. Se siguen evaluando controles independientes.
| Control | Comportamiento real |
|---|---|
| `checkout` | Exige raíz exacta de repo, HEAD y rama no detached; inaccesible/detached: BLOCKED. |
| `repository` | Compara origin con repository GitHub HTTPS o SSH `git@github.com:`, sin credenciales, case-insensitive y sin `.git`; diferente: FAIL; URL no soportada: BLOCKED. |
| `branch` | MICRO: `develop-dvp`. LIBRERIA: `feature/<ticket>-<base>-<último segmento sp con _→->`; base se usa literal. Diferente: FAIL; identidad incompleta: BLOCKED. |
| `clean_checkout` | `git status --porcelain --untracked-files=normal` vacío; cambios o no rastreados: FAIL. |
| `base_ancestry` | LIBRERIA: merge-base con `refs/remotes/origin/develop-dvp`, luego `refs/heads/develop-dvp`; basta ancestro común. Sin comprobación posible: BLOCKED. |
| `modules` | LIBRERIA: módulos directos del POM raíz y carpetas inmediatas con `pom.xml` deben coincidir exactamente con allowed_modules; module_path incluido. Diferencia: FAIL; cono inválido o módulos por perfiles: BLOCKED. |
| `evidence_revision` | Commit y rama declarados deben coincidir exactamente con HEAD/rama local; identidad ausente o evidencia obsoleta: BLOCKED, no FAIL. |
| Cuatro flags | Cada uno emite su propio check PASS si es `true`; cualquier otro valor: BLOCKED. No comprueba automáticamente el respaldo de la revisión. |
| `jacoco` | XML report con clases y counters globales únicos INSTRUCTION/BRANCH/LINE/METHOD; misses: FAIL; evidencia vacía, inválida o counters ausentes: BLOCKED, salvo BRANCH revisado. |
| `unit_tests` | JUnit con casos, suites hoja, totales consistentes y sin duplicados; failure/error/skipped: FAIL; vacío/inconsistente: BLOCKED. MICRO sin contextLoads exitoso: BLOCKED si no hay ya fallo. |
| `test_policy` | Inspecciona POMs efectivos aportados: propiedades maven.test.skip/skipTests/skipITs y skip/skipTests/skipITs/skipExec de Surefire/Failsafe. true: FAIL; valor sin resolver: BLOCKED; no ejecuta Maven. |
| `sonar` | Identidad, revisión y gate exportados comprobables; identidad incorrecta/obsoleta/incompleta: BLOCKED. Gate o condición ERROR con evidencia válida: FAIL. |
| `dependencies` | Si cualquier dependencia declarada no es PASS, añade BLOCKED al consumidor; conserva sus FAIL propios. No calcula orden de publicación. |

En JaCoCo, PASS exige missed=0 y covered>0 en los counters aplicables; cero cobertura no prueba 100%.
Con `no_branches_reviewed=true`, BRANCH ausente o 0/0 es N/A revisado; para 0/0 el JSON conserva los ceros, no un porcentaje.
JUnit reconoce exactamente `contextLoads` o `contextLoads()` exitosos; no permite desactivar el requisito en micros.
`base_ancestry` no exige que la punta de develop-dvp sea ancestro de HEAD: solo prueba historia común local.
No certifica punto de creación de la rama, base más reciente ni latest remoto; no hace fetch ni registra la ref seleccionada.
Los checks branch/clean_checkout/repository y los de librería requieren HEAD y rama disponibles; revisar checkout si faltan.

## SonarQube: export aportado, específico de versión
El proveedor debe confirmar versión de SonarQube y API de **su instancia** (menú ayuda → Web API); endpoints pueden variar/deprecarse.
Para instancias compatibles, aportar export de `GET api/qualitygates/project_status?analysisId=...` y conservar condiciones reales.
Envolverlo con `project_key`, `commit`, `branch`, `analysis_id`, `projectStatus: {status, conditions}`; no inventar metadatos ni vaciar conditions.
`project_key` coincide con `sonar_project_key`; commit/rama con HEAD y evidence; analysis_id debe estar presente.
`status` y cada condición deben ser OK o ERROR; conditions es lista no vacía; `ignoredConditions: true` bloquea.
El script no consulta el análisis: analysis_id+SHA son evidencia aportada, no asociación verificada contra Sonar.
Frescura aquí significa SHA/rama actuales, no antigüedad temporal certificada. PASS está condicionado a provenance revisada.
Referencia de API por instancia: https://docs.sonarsource.com/sonarqube-server/extension-guide/web-api/.

## Reportes, delegación y handoff
`report.json`: version, fecha UTC, hash del manifiesto, scope, estado global, componentes/checks/detalles y hashes SHA-256 de artefactos leídos cuando se pudieron obtener.
`report.md`: scope y estados por componente/check. `handoff.md`: checks no PASS con pedido genérico de evidencia; usar la tabla siguiente.
No contienen un certificado de ejecución/procedencia: los hashes identifican bytes, no prueban autoría ni asociación con un commit.
El orquestador delega cada componente a agente-quality-review; en OpenCode, si no está registrado, usar `general` con prompt para leer `.claude/agents/agente-quality-review.md`.
No crear configuración `.opencode/` ni inventar skills externas. Sin delegación disponible, reportar revisión pendiente/BLOCKED.
El revisor devuelve hallazgos separados: no modifica veredictos ni reportes. Una revisión pendiente impide cerrar como PASS.
Para reejecutar, exigir evidencia corregida/nueva o manifiesto sustentado y otra carpeta de salida; nunca cambiar estados a mano.

| Check en handoff | Acción exacta del responsable; el pipeline no la ejecuta |
|---|---|
| `checkout` | Aportar local_path a raíz de checkout existente en rama objetivo, con HEAD legible y no detached. |
| `repository` | Contrastar inventario y origin; aportar identidad GitHub correcta y checkout correspondiente, sin credenciales. |
| `branch` | Preparar externamente la rama exacta esperada; corregir ticket/base/SP solo con evidencia de identidad y renovar evidencias si cambia HEAD. |
| `clean_checkout` | Entregar checkout limpio incluido índice y no rastreados, preservando trabajo fuera del pipeline. |
| `base_ancestry` | Aportar checkout con ref develop-dvp e historia suficientes para ancestro común; cualquier preparación Git ocurre fuera del pipeline. |
| `modules` | Revisar cono exacto, module_path, allowed_modules, módulos raíz y POM físicos directos; resolver externamente perfiles, sin fingir soporte recursivo. |
| `evidence_revision` | Aportar reportes del SHA/rama actuales y actualizar commit/branch con soporte; no renombrar evidencia vieja como vigente. |
| `jacoco` | Aportar XML válido con clases/counters completos sin misses; corregir cobertura fuera del pipeline o justificar BRANCH N/A con no_branches_reviewed. |
| `unit_tests` | Aportar XML JUnit consistentes, no duplicados, con tests sin failures/errors/skipped e incluir contextLoads exitoso en MICRO. |
| `test_policy` | Aportar effective_poms del alcance completo con perfiles y propiedades reales; resolver valores no literales y skips fuera de este pipeline. |
| `sonar` | Obtener externamente export del análisis correcto con envoltura verificable y condiciones completas; si gate falla, resolverlo fuera del pipeline y renovar evidencia. |
| Flags (cuatro checks) | Revisar exclusiones, política de tests, alcance de dependencias y provenance; aportar constancia identificable y confirmar cada booleano solo tras revisión. |
| `dependencies` | Completar relaciones verificadas y resolver checks no PASS de las dependencias; no borrar aristas para conseguir PASS. |

## Límites y revisión externa
No implementados: resolución automática de herencia/perfiles/exclusiones Maven/effective POM, mapping por clase y trazabilidad independiente.
Tampoco validación automática externa de Sonar, proveedor, registry ni ordering de publicación/despliegue.
El revisor cubre data ownership, perfiles/effective POM, exclusiones y alcance con evidencia externa, explicitando lo que siga pendiente.
`test_policy_reviewed` confirma integridad de los modelos y argumentos efectivos (incluidos overrides CLI/CI); el control automático detecta skips en XML, pero no reconstruye una invocación histórica.
Los flags no resuelven controles técnicos bloqueados ni convierten evidencia declarada en prueba criptográfica/independiente.
No exponer tokens, credenciales ni columnas descartadas en mensajes, delegaciones o reportes. **PASS de evidencias no significa release validado.**

## Verificación del motor (sin servicios externos)
```sh
python -m unittest discover -s .claude/docs-qa/inputs/scripts/quality_validation/tests -v
```

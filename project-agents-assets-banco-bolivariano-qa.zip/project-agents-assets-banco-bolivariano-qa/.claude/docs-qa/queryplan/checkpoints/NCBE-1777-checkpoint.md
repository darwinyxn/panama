# NCBE-1777 — Checkpoint NO-BANK-READY (3 blockers reales restantes)

> Este archivo NO es una entrega. No vive en `entregas/` a propósito: el Query Plan de
> NCBE-1777 (`cob_giros..sp_tr_pago_giro_rc`) está **bloqueado**, no cerrado. Sirve para
> retomar directo desde los 3 blockers reales hacia VALIDATE/PACKAGE sin repetir discovery,
> reconstrucción de fuente contractual, ni los fixes de motor — todo eso ya está hecho y
> verificado.

Última actualización: 2026-10-01 (sesión que resolvió QP-68 y QP-40 vía composición
multi-fuente genérica; QP-65/QP-67/QP-09 confirmados irresolubles con la evidencia
disponible hoy).

## Estado resumido

| Campo | Valor |
|---|---|
| QP_TOTAL_DERIVED | 249 |
| QP_PREPARED | 249 (0 bloqueados en PREPARE) |
| QP_PASS | 246 |
| QP_OBSERVATIONS (no bloqueantes, dentro de los 246) | 22 |
| QP_BLOCKED | 3 (QP-65, QP-67, QP-09) |
| PII_SAFE | FAIL (QP-09) |
| VALIDATE | FAIL |
| NON_ZERO_WRITE_COUNTS | 0 (confirmado — todo bajo `set noexec on`, "Total writes for this command: 0" en cada corrida) |
| Motor QA (HEAD) | `a19dc41` == `origin/master` (14 fixes genéricos ya pusheados, suite 1141 pass / 2 fallos preexistentes no relacionados) |
| STAGING_PATH (última corrida) | `/tmp/qp-ncbe-1777-runs/queryplan-NCBE-1777-ncbe1777-qp40-live` |
| request.json de esta corrida | copiado junto a este checkpoint: `queryplan-NCBE-1777-request.json` (ver abajo — el original vivía en `/tmp`, no durable; esta copia YA incluye las composiciones de QP-68 y QP-40) |

## QP-40 y QP-68 — RESUELTOS esta sesión (ya NO son blockers)

Ambos se resolvieron con **composición multi-fuente genérica** (3 tipos nuevos de motor,
ver abajo), citando evidencia REAL ya existente en el repo (ningún test nuevo, ningún
literal inventado). Confirmados con `targeted validation` real contra Sybase: ambos
generan `QUERY PLAN FOR STATEMENT 1` real.

- **QP-68** (`TranServicioJdbcDataAdapter.insertarMonitor`): `ts_secuencial=555` vía
  `verified_builder_field` (citando `SpTrPagoGiroRcLibrary_ValidacionesTest.
  pagoConSsnDeEntradaUsaISsnComoSsn`, que usa el MISMO `pagoCteBase()` + MISMA
  `stubCadenaPagoExitosa()` + MISMA aserción `returnCode()).isZero()` que el escenario
  principal, solo agregando `.iSsn(555)`); `ts_tipo_transaccion=3208` vía
  `production_constant` (`TRN_PAGO_GIRO`, constante de la propia Library); el resto de
  los 10 campos (nullables, incluyendo `ts_usuario` evitado por PII) vía `explicit_null`.
- **QP-40** (`GiroPagoJdbcDataAdapter.actualizarEstadoPagado`): `gp_servicio='V'` y
  `gp_agente_pagorig=''` vía el nuevo `verified_guarded_literal` (ternario
  `"D".equals(req.sOrg())?"C":"V"` y guardia `!isnull(req.iCodAgente(),"").isEmpty()`,
  ambos demostrablemente FALSOS para el escenario citado — `req.sOrg()` nunca se fija en
  ningún test del módulo, y `pagoCteBase()` fija `iCodAgente("")` explícitamente); el
  resto de los 13 campos vía `explicit_null`.

## Motor QA — 14 fixes genéricos ya en `HEAD=origin/master=a19dc41`

Commits (en orden): `5d558de`, `c8f3010`, `1ddcb8e`, `4391bed`, `4064e7b`, `a19dc41`.
Todos con test de regresión, suite completa verde. No requieren repetirse ni revisarse de
nuevo salvo que aparezca una regresión real.

1. `GAP_DYNAMIC_BARE_PARAM` — reconstrucción de SQL dinámico con un parámetro bare resuelto por call-site real.
2. `GAP_NESTED_BINDER_VERIFY` (indirección de helper de test) — sigue un helper privado de TEST que dispara el método público real.
3. `GAP_PAREN_BALANCED_ARGS` — `resolve_method_literals` ya no trunca argumentos en el primer `)` de una llamada anidada.
4. `GAP_DYNAMIC_WHERE_RHS_IDENT` — nuevo discriminador de `match_legacy_sql` por identificador bare del lado derecho de un `=`.
5. PRIORIDAD 4b — reintenta `resolve_literals_from_unit_tests` con el caller real cuando el ejecutor privado reconstruido no tiene evidencia propia.
6. `GAP_SHARED_HELPER_VARARG_BINDER` — audita el orden real de binding cuando se delega a un helper sin receptor JDBC visible en la propia clase.
7. `GAP_SUPERCLASS_EXEC_EVIDENCE` — `_java_has_db_execution` sigue `extends` hasta el `.java` hermano.
8. `GAP_TEXTBLOCK_CLOSING_DELIM_INDENT` — `_dedent_text_block` incluye la indentación del delimitador de cierre `"""` en el cálculo del mínimo común (JEP 378).
9. `GAP_COMPOSITE_POSITION_PROVENANCE` + `UNIT_TEST_INLINE_LITERAL` en el allowlist PII.
10. Preservación del detalle completo de cada sub-fuente composite (no solo el tipo).
11. `GAP_COMPOSITE_MATRIX_FIELD_CONSTANT` — verifica empíricamente si un campo `matrix_field` es constante en toda la matriz real.
12. `explicit_null` + `verified_builder_field` (tipos composite nuevos) — ver QP-68 arriba.
13. `GAP_COMPOSITE_PRECEDENCE` — `composite` ahora se intenta ANTES de un `unit_tests` genérico del paquete (antes SIEMPRE perdía, quedando en prioridad 99 por defecto).
14. `verified_guarded_literal` (tipo composite nuevo) — resuelve una variable local de producción cuyo valor depende de un ternario o guardia sobre un getter de `req`, resolviendo SIEMPRE a la rama/default demostrablemente FALSA — ver QP-40 arriba.

## Verificación de canon (por qué los 3 blockers restantes NO pueden forzarse a BANK_READY)

- `BLOCKED_LEGACY_PROVENANCE` (`qp_pipeline.py:669,1489`) es un estado de **PREPARE**
  (fallo de correspondencia SQL-legacy), no de VALIDATE. No aplica.
- Entrega real `NCBE-1804-queryplan-2026-07-09-statistics-io/` (único precedente de
  "observación" en una entrega BANK_READY real): su QP-07 con observación `A_TABLE_SCAN`
  tiene `plan.present=true` — observación de calidad-de-plan sobre un plan YA generado.
  Categoría distinta a "sin plan" (QP-65/67) o PII bloqueante (QP-09).
- `qp_lint.py`/`qp_pipeline.py`: gate incondicional, sin waiver. Ver detalle en el
  historial de commits de este checkpoint (versión anterior) si se necesita el detalle
  completo de líneas citadas.

---

## HANDOFF — QP-65 (BLOQUEADO, irresoluble con evidencia actual)

```
QP_ID=QP-65
METHOD=TranServicioJdbcDataAdapter.insertarCupoAgente
SOURCE_FILE=/home/ssm-user/qp-ncbe-1777-cob-giros/sp-tr-pago-giro-rc-utils/src/main/java/com/bolivariano/cobgiros/sptrpagogirorc/utils/infrastructure/outbound/persistence/jdbc/adapter/TranServicioJdbcDataAdapter.java
SOURCE_LINES=29 (metodo); record InsercionCupoTranServicio, 24 campos; construido via helper insercionCupoAgente(c, trn, ...) en SpTrPagoGiroRcLibrary.java:396-403
SQL=insert into cob_cuentas..cc_tran_servicio (ts_secuencial, ts_tipo_transaccion, ts_oficina, ts_usuario, ts_rol, ts_terminal, ts_correccion, ts_origen, ts_nodo, ts_tsfecha, ts_clase, ts_referencia, ts_saldo, ts_moneda, ts_tipo, ts_valor, ts_monto, ts_ocasional, ts_contratado, ts_tsn, ts_hora, ts_aporte_iess, ts_endoso, ts_tarjcred, ts_nombre, ts_descripcion_ec, ts_ced_ruc, ts_campo_alt_uno, ts_agente) values (?, ?, ?, ?, ?, ?, ?, 'L', ?, ?, 'F', ?, ?, ?, 'L', ?, ?, ?, 0, ?, getdate(), ?, ?, ?, ?, ?, ?, ?, ?)
NOT_NULL_FAILURE=ts_secuencial, ts_tipo_transaccion, ts_tsfecha (cob_cuentas..cc_tran_servicio; busqueda detenida en el 3er error reportado por Sybase)
SYBASE_ERROR=Msg 233 (severity 16, state 1) x3: columnas ts_secuencial / ts_tipo_transaccion / ts_tsfecha "does not allow null values"
RESUELTO_PARCIALMENTE=ts_secuencial (c.ssn=truncado.iSsn()=req.iSsn(), MISMA cadena que QP-68) y ts_tipo_transaccion (literal inline 4717 o 4718 segun call-site: SpTrPagoGiroRcLibrary.java:343/354, 2 variantes -- requeriria fork, no implementado) SON resolubles en principio con los tipos de motor ya existentes
BLOQUEO_REAL=ts_tsfecha=req.sDate(): confirmado via grep exhaustivo (`grep -rn "\.sDate(" src/test/`) que NINGUN test en TODO el modulo sp-tr-pago-giro-rc-utils fija sDate() explicitamente -- ni en pagoCteBase(), ni en ningun override, ni en TestSupport. El campo del Request (`private LocalDateTime sDate;`) no tiene valor por defecto no-null. No es evidencia fragmentada entre archivos (como se pensaba inicialmente): es AUSENCIA REAL confirmada.
MISSING_EVIDENCE=ningun test del modulo construye un escenario de exito con sDate() poblado; sin eso, ts_tsfecha no tiene provenance verificable sin inventar
MINIMUM_REQUIRED_FIX=agregar (en el repo del micro/libreria bb-core-cob-giros-utils, fuera del alcance de QA) un escenario de test con `.sDate(<valor>)` explicito combinado con un flujo de exito verificado (returnCode().isZero())
OWNER_COMPONENT=OWNER_MICRO_OR_LIBRARY
OWNER_REASON=gap de cobertura de test real y confirmado exhaustivamente -- no es un defecto del SP, no es config/ambiente, no es algo que QA pueda resolver sin inventar un valor para sDate()
```

## HANDOFF — QP-67 (BLOQUEADO, irresoluble con evidencia actual)

```
QP_ID=QP-67
METHOD=TranServicioJdbcDataAdapter.insertarPrincipal
SOURCE_FILE=/home/ssm-user/qp-ncbe-1777-cob-giros/sp-tr-pago-giro-rc-utils/src/main/java/com/bolivariano/cobgiros/sptrpagogirorc/utils/infrastructure/outbound/persistence/jdbc/adapter/TranServicioJdbcDataAdapter.java
SOURCE_LINES=87 (metodo); record InsercionTranServicio, 37 campos; construido via insercionTranServicio(c) en SpTrPagoGiroRcLibrary.java:1484-1493
SQL=insert into cob_cuentas..cc_tran_servicio (37 columnas, misma tabla que QP-65) values (?, ?, ?, ?, ?, ?, ?, ?, null, 'L', ?, ?, 'F', ?, ?, ?, ?, ?, 'L', ?, ?, 0, 0, null, ?, ?, ?, null, getdate(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
NOT_NULL_FAILURE=ts_secuencial, ts_tipo_transaccion, ts_tsfecha (misma tabla cc_tran_servicio que QP-65)
SYBASE_ERROR=identico a QP-65 (misma tabla, mismas 3 columnas NOT NULL)
RESUELTO_PARCIALMENTE=ts_secuencial=c.ssn (misma cadena); ts_tipo_transaccion=req.tTrn()=TRN_PAGO_GIRO=3208 (production_constant, limpio, igual que QP-68 -- este SI es directo, sin fork)
BLOQUEO_REAL=ts_tsfecha=req.sDate() en posicion 10 del constructor -- EXACTAMENTE la misma ausencia confirmada que en QP-65 (ningun test del modulo fija sDate())
MISSING_EVIDENCE=identico a QP-65
MINIMUM_REQUIRED_FIX=identico a QP-65 (mismo campo, mismo gap, se resolveria para AMBOS QP-65/67 con el mismo test nuevo en el repo del micro)
OWNER_COMPONENT=OWNER_MICRO_OR_LIBRARY
OWNER_REASON=identico a QP-65
```

## HANDOFF — QP-09 (PII, irresoluble con evidencia actual)

```
QP_ID=QP-09
FIELD=i_usuario / s_user
METHOD=SpCseqnosBzLegacyAdapter.ejecutarSync, call-site SpSensorOrdenesGirosLibrary.java:709 (rama debito-CHE/comision de agente dentro de grabarTotalProcesado)
WHY_SENSITIVE=i_usuario coincide con el token sensible 'usuario' (_SENSITIVE_FIELD_TOKENS en qp_lint.py)
CURRENT_PROVENANCE=tipo_fuente=COMPOSITE, posicion 1 = matrix_field (campo s_user, test_case_id=TC01, valor='qa_funcional'); posicion 2 = production_inline_literal ('bp_movimiento')
INVESTIGACION_POR_CASO_REALIZADA=se determino el flujo Java exacto (ctx.sUser=request.sUser() sin transformacion); se identificaron los 10 valores reales de s_user en la matriz completa (105 casos) y a que test_case_id corresponde cada uno; se encontro el UNICO TC tematicamente relevante (TC53 "Pago WS agente con acumulacion de cupo exitosa", s_user='jlarreas') y se verifico su EJECUCION REAL CAPTURADA: return_code=1, RECHAZADO antes de llegar a la linea 709 (diagnostico_motor: "sp_verifica_caja_rc CAJERO NO REGISTRADO EN ESTA OFICINA"). Se verifico tambien el unico TC con return_code=0 real usando qa_funcional en un pago normal (TC45, "Rama de pago normal por @w_factor=1") y se confirmo que NO pasa por la rama de agente (i_cod_agente="" en sus parametros_entrada).
QA_FUNCIONAL_REACHES_QP09=NO (confirmado con evidencia de ejecucion real, no solo analisis estatico)
REAL_VALUES_FOUND=10 valores distintos en la matriz completa: QA, qa_funcional, jlarreas, aavilesv, saguirrr, avcastrp, arobinsn, tc55_test, tc56_test, tc57_test. Los 5 con forma inicial+apellido (jlarreas/aavilesv/saguirrr/avcastrp/arobinsn) no tienen documentacion que confirme si son cuentas de servicio o personas reales.
SAFE_VALUE_REQUIRED_TYPE=(a) un fixture UNIT_TEST/UNIT_TEST_INLINE_LITERAL en un test versionado que alcance realmente esta linea, o (b) documentacion EXPLICITA en el caso de matriz real que SI alcanza la linea 709 (ninguno de los TCs reales confirmados que alcanzan esta linea con exito usa un valor QA-safe)
MINIMUM_REQUIRED_FIX=no existe hoy un TC con ejecucion real, exitosa, que alcance la linea 709 con un usuario QA-safe -- resolverlo exigiria o bien un TC nuevo (fuera del alcance de QA, requiere coordinacion con quien mantiene la matriz/el ambiente de cajero) o aceptar jlarreas sin verificacion (inventar provenance, prohibido)
OWNER=NO_DETERMINABLE
QP09_CAN_BE_SOLVED_IN_QA_FIXTURE=NO
REASON=el valor real que alcanzaria esta linea en una ejecucion exitosa depende de datos de ambiente (registro de cajero en la oficina de prueba) que QA no controla y no puede inventar; no es una tarea mecanica de QA.
```

---

## Cómo retomar (próxima sesión)

1. Leer este checkpoint completo primero.
2. Confirmar que `HEAD`/`origin/master` siguen en `a19dc41` (o más adelante) — si avanzó,
   revisar `git log` por fixes de motor nuevos antes de asumir que el estado sigue igual.
3. Para QP-65/67: ambos comparten el MISMO campo faltante (`ts_tsfecha`/`req.sDate()`).
   Si `bb-core-cob-giros-utils` agrega UN test con `.sDate(<valor>)` + flujo de éxito
   verificado, ambos QP se resuelven con el mismo patrón ya usado para QP-40/68
   (`verified_builder_field` o `verified_guarded_literal` según corresponda) — no haría
   falta tocar el motor de nuevo. Para `ts_tipo_transaccion` de QP-65 (literal inline
   4717/4718 según call-site) sí haría falta soporte de "fork por call-site" similar al
   ya construido para `GAP_DYNAMIC_BARE_PARAM`, si se quiere evitar un segundo test.
4. Para QP-09: requiere una decisión/dato de alguien con autoridad sobre el ambiente de
   prueba (registro de cajero) o sobre la matriz de `sp_tr_pago_giro_rc` — no es una
   tarea mecánica de QA.
5. Cuando los 3 queden resueltos, VALIDATE debería pasar sobre los 249 QP sin tocar el
   motor ni el source-set contractual — correr `prepare-only` para confirmar y luego
   `run --allow-live-sybase --allow-live-sybase-prepare` directamente.

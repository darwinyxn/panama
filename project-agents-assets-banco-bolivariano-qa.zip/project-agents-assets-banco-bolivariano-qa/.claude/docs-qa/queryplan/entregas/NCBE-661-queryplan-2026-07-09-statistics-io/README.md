# Query Plan NCBE-661 — entrega canonica v2.1 (12 librerias del cono sp_debcred_empresa)

> **Corrida viva completa 2026-07-15 (manifest canonico v2.1):** los 12 paquetes fueron regenerados
> end-to-end contra Sybase VIVO (SYBASE02) con el pipeline endurecido a `schema_version 2.1`. Los QP
> se re-ejecutaron VIVOS (un tsql por QP, concurrencia 1, DML solo bajo `set noexec on/off`, SP
> hijos NO ejecutados) capturando evidencia E2E real (payload/stdout/stderr sha256, exit_code,
> timestamp UTC real). 12/12 PACKAGE_READY, gate global + cross-lint PASS. Criterio tecnico
> `2026-07-09-statistics-io` sin cambios; SQL ejecutado, plan e IO IDENTICOS al baseline.
>
> La entrega v2.0 anterior quedo DEPRECATED_INTERNAL_NOT_FOR_DELIVERY por defectos de trazabilidad del
> manifest (hijos perdidos, `?` en SQL fuente, timestamps inventados, labels no trazables, etc.). Ver
> `docs-qa/queryplan/audits/NCBE-661-queryplan-normalization/QUERYPLAN-V2-FAILURE-ANALYSIS.md` y
> `SEMANTIC-DIFF-QUERYPLAN-BASELINE-VS-V2-1.md`.


## 1. Proposito

Evidencia de Query Plan (plan de ejecucion + `statistics io`) de las 12 librerias/SP del cono del
SP padre `sp_debcred_empresa`, para revision de rendimiento del Banco. Un ZIP por libreria/SP.

> La cantidad de paquetes (12) corresponde al inventario de ESTE cono. Otros SP principales pueden
> tener una cantidad diferente de librerias hijas; el proceso genera un ZIP por cada SP/PA
> descubierto y validado en el inventario del cono, no un numero fijo.

## 2. Criterio tecnico (rendimiento)

`2026-07-09-statistics-io` — `set statistics io on` + `set showplan on`, parser de IO, clasificacion
por etiqueta del plan / umbrales `logical_total > 10000` / `physical_total > 1000` / error. **Sin cambios.**

## 3. Version de presentacion y manifest

- **Manifest**: `schema_version 2.1` (canonico). Un nombre por concepto; `resumen`,
  `labels_normalized` y `label_derivations` DERIVADOS del plan (trazables); SQL separado por
  procedencia (legacy=SP / template_micro=adapter / ejecutado=materializado); fechas con
  precision/fuente; objeto `sybase` con host_alias/ase_version/ase_ebf; observaciones con `tabla`;
  `sps_hijos[]` inventariados desde el fuente (`ejecutado=false`, BARRERA_3). Escrito con el writer
  unico `qp_manifest.py`; validado con `qp_lint.py --manifest-v2` y `--cross-zip`.
- **Presentacion `.qp`**: `queryplan-rendering-normalized-v1` — los `.qp` entregables estan
  normalizados de forma determinista: se desenvolvio el envoltorio de transporte del cliente tsql
  (`Msg ... severity 0-10`), se elimino el ruido de cliente (login/charset/locale/prompts `N>`) y los
  planes auxiliares de control (`SET OPTION`/`SET STATISTICS`/`PRINT`).
- **Evidencia E2E**: por cada QP se registra `payload_sha256` (bloque tsql completo), `stdout_sha256`,
  `stderr_sha256`, `exit_code` (corrida viva 2026-07-15) y `sql.ejecutado.text_sha256` (hash del texto
  SQL materializado, contrato distinto del payload). El timestamp de corrida vive a nivel run
  (`fechas.run_started_at_utc`); el timing por-QP es honesto: `timing_status=NOT_CAPTURED` cuando no hay
  evidencia exacta por-QP (no se reusa el inicio global como ejecucion exacta de cada QP).
- **Detalle Banco**: `detalle_ejecucion.qp` usa solo salida normalizada (0 wrappers `Msg ... severity
  0-10`) e incluye una seccion `INVENTARIO DE SP HIJOS` por paquete (orquestador puro explica sus 0 QP
  y lista sus hijos). Etiquetas informativas del plan (Forward Scan, Positioning by key, Scalar/INSERT/
  UPDATE Operator) se conservan como `labels_raw_informational` (raw+interpretacion trazable), sin
  disparar criterio.
- **SP hijos**: **36 entries** (invocaciones directas child-per-parent), **45 call-sites** (sitios
  `exec` reales), **28 SP unicos**. Por categoria: 34 BUSINESS (42 call-sites) + 2 TECHNICAL_UTILITY
  (3 call-sites). Toda invocacion directa se inventaria y se CLASIFICA (nunca se excluye por ser
  utilidad tecnica). Clasificacion via script oficial del banco: 17 entries `CallDirect`, 19
  `UnclassifiedRefactor` (miembros del propio cono + grandchildren no listados); 0 CallCobis/Library.
  `cob_cuentas..sp_gen_sec` = `TECHNICAL_UTILITY`, `UnclassifiedRefactor`, `ejecutado=false` (BARRERA_3),
  2 entries / 3 call-sites. `sp_cerror` (manejo de error de plataforma) no es invocacion inventariable
  de este contrato. Conteos y clasificacion en `manifest-consolidado-queryplan.json`. Ver SEMANTIC-DIFF.

## 4. Conteos consolidados confirmados

- 12 paquetes (12/12 generados).
- 98 QP en total. (Criterio Banco 2026-07-15: las sentencias DML sin acceso a tablas que la libreria
  Java resuelve en memoria —asignaciones/calculos— NO vienen en Query Plan. sp_cal_impuesto, libreria
  de calculo escalar sin llamadas a BD, queda con 0 QP. Se conservan las sentencias sin tabla que SI
  son round-trip real a BD desde Java: `SELECT @@IDENTITY` en sp_eventos y `select 1 - sign(@@trancount)`
  en sp_grb_comision.)
- 24 QP con observacion (29 objetos-observacion: 27 por etiqueta del plan criterio A + 2 por criterio
  B `logical>10000` en `sp_eventos`). En la corrida viva 2026-07-15 no hubo observacion criterio C
  activa: el IO fisico (physical reads) depende del estado de cache del servidor y en esta corrida
  quedo por debajo del umbral. Ver el reporte comparativo (`audits/.../SEMANTIC-DIFF-...md`), donde se
  documenta que `sp_eventos` QP-18 tuvo physical>1000 en la corrida anterior y 0 en esta.
- 0 errores SQL reales (0 mensajes `severity >= 11`).
- 0 `BLOCKED_SYBASE`.
- 0 `BLOCKED_UNSAFE_DML` (DML ejecutado con `set noexec on`; no se modificaron datos).

## 5. Mapeo SP/PA -> HU -> ZIP

> `NCBE-661` es la HU del **cono / microservicio** y funciona como agrupador operativo de esta
> entrega. El **Query Plan NO se asigna a la HU del micro, sino a la HU de la LIBRERIA**. Cada
> libreria/SP tiene su propia HU individual (columna HU de la tabla). En particular, la libreria de
> `sp_debcred_empresa` corresponde a la HU individual **`NCBE-868`** (no a `NCBE-661`, que es el cono).
> En Confluence, adjuntar cada ZIP a su HU individual de la tabla. NO son las 12 la HU NCBE-661.

| SP/PA | HU | Archivo ZIP | QP | Observaciones | Estado |
|-------|----|-------------|----|---------------|--------|
| sp_debcred_empresa | NCBE-868 | sp_debcred_empresa-queryplan.zip | 19 | 6 | PASS_CON_OBSERVACIONES |
| pa_aho_pvalida_depini | NCBE-672 | pa_aho_pvalida_depini-queryplan.zip | 3 | 0 | PASS |
| pa_aho_pvalida_ndnc | NCBE-667 | pa_aho_pvalida_ndnc-queryplan.zip | 2 | 0 | PASS |
| pa_cte_pvalida_ndnc | NCBE-665 | pa_cte_pvalida_ndnc-queryplan.zip | 2 | 0 | PASS |
| sp_cal_impuesto | NCBE-693 | sp_cal_impuesto-queryplan.zip | 0 | 0 | PASS (calculo escalar; sin llamadas BD en Java) |
| sp_cont_impuesto | NCBE-664 | sp_cont_impuesto-queryplan.zip | 13 | 0 | PASS |
| sp_eventos | NCBE-695 | sp_eventos-queryplan.zip | 35 | 9 | PASS_CON_OBSERVACIONES |
| sp_genera_iva_comision | NCBE-676 | sp_genera_iva_comision-queryplan.zip | 12 | 5 | PASS_CON_OBSERVACIONES |
| pa_sat_pnotificacion | NCBE-678 | pa_sat_pnotificacion-queryplan.zip | 8 | 3 | PASS_CON_OBSERVACIONES |
| sp_graba_tran_servicio | NCBE-694 | sp_graba_tran_servicio-queryplan.zip | 2 | 1 | PASS_CON_OBSERVACIONES |
| sp_ndc_ahcc | NCBE-677 | sp_ndc_ahcc-queryplan.zip | 0 | 0 | PASS (orquestador puro) |
| sp_grb_comision | NCBE-675 | sp_grb_comision-queryplan.zip | 2 | 0 | PASS |
| **TOTAL** | (cono NCBE-661) | **12 ZIP** | **98** | **24** | |

## 6. Hallazgo principal de rendimiento

- **`sp_eventos`** sobre `cob_internet..vm_eventos` (join con `sm_horario`) — corrida viva 2026-07-15:
  - QP-18: `logical_total = 183120`, `physical_total = 0`.
  - QP-19: `logical_total = 187027`, `physical_total = 19`.
  - Maximo logico del paquete: `187027` (QP-19), muy por encima del umbral B (`logical>10000`).
  - `Table Scan` sobre `vm_eventos` + `Using Worktable`; unico candidato real a revision de indice
    (las 2 unicas observaciones con IO logico por encima del umbral Banco: QP-18 y QP-19).
  - El IO logico (estable, no depende de cache) confirma el hallazgo. El IO fisico varia por cache:
    en corridas previas QP-18 supero el umbral C (`physical>1000`), en esta corrida no; el logical
    reads es la senal robusta para la decision de indexacion.

## 7. Nota por libreria especial

- `sp_ndc_ahcc`: orquestador puro — 0 QP / sin DML propio. Sus escrituras viven en SPs hijos, cada uno
  con su propia entrada de Query Plan en esta misma entrega.

## 8. Criterio Forward Scan

`Forward Scan` + `Positioning by key` (acceso por clave) se registra como informativo en
`labels_detected` y NO dispara observacion. Solo la etiqueta literal exacta `Positioning by Forward
Scan` dispararia observacion por criterio A; no aparecio en ninguna de las 12 corridas.

## 9. Instruccion para Confluence

- Subir cada ZIP bajo la HU correspondiente de la tabla del punto 5.
- Usar el nombre del SP/PA como titulo del adjunto.
- No usar prefijos numericos.
- No subir reportes internos ni evidencia raw.
- El indice y los checksums SHA-256 estan en `manifest-consolidado-queryplan.json`.

# Query Plan NCBE-2801 — limitaciones de la evidencia

Cono `cob_internet..pa_cash_gconsultamovimien` (Lote 9), 4 paquetes, 13 QP, corrida viva SYBASE02
2026-10-26. Estado: revisión interna QA, no entregado a Banco.

## 1. Literales de prueba (fixtures sintéticos)

Los valores enviados a Sybase provienen de las pruebas unitarias versionadas de cada librería
(`bb-core-cob-internet-utils`, rama `develop-dvp`). No son datos de clientes ni valores de la matriz
de equivalencia: los números de cuenta de la matriz los bloquea el control PII del estándar.

Consecuencia: el plan muestra el camino de acceso que elige el optimizador para esos valores, no el
comportamiento con el volumen de datos de una cuenta real. Las lecturas medidas son bajas
(2 a 4 lógicas por tabla), lo que indica cuentas de prueba con pocas o ninguna fila; no reflejan la
carga de una cuenta con historial amplio.

| Paquete | QP | Valores usados | Origen |
|---|---|---|---|
| NCBE-2805 | QP-01 | cuenta `0001234567` | `DataAdaptersMapeoTest`, escenario con fila y assert de binding |
| NCBE-2805 | QP-02 | `',12,'`, `4251` | `DataAdaptersMapeoTest`, escenario con assert de binding |
| NCBE-2804 | QP-04 (acumulado) | cuenta `999`, grupo `0` | `MovimientoDataAdaptersTest` L143, test propio del adapter |
| NCBE-2804 | QP-05 (diario) | cuenta `1234567890`, grupo `0` | `MovimientoDataAdaptersTest`: cuenta L81 (assert de binding), grupo L164 (mismo adapter, test de camino de error) |
| NCBE-2804 | QP-06 (histórico) | cuenta `1234567890`, grupo `3` | `MovimientoDataAdaptersTest` L81, test del adapter **diario** (ver punto 2) |

## 2. NCBE-2804 QP-06: literales tomados de otro adapter

El único test propio de `MovimientoHistoricoDataAdapter` liga NULL en todos los parámetros, lo que
produciría `hm_cta_banco = NULL` y un plan no representativo. Se reutilizaron los valores del test
de `MovimientoDiarioDataAdapter` (mismo archivo de test, misma firma
`consultar(String cuenta, Integer grupo, Integer max)` y mismo binding: cuenta en `?1`, grupo en
`?2..?6`).

QP-06 queda con `grupo=3` (filtro por lista de tipos de transacción), mientras que la ME corrió con
`e_grupo=0` (todos los tipos). No hay en el código versionado una invocación del adapter histórico
con grupo 0 que cumpla el contrato de procedencia, así que se conserva el valor sustentado. QP-04 y
QP-05 sí usan `grupo=0`.

## 3. Rendimiento: los Query Plan no son concluyentes sobre los ~75 s de la ME

En la ME, la consulta de últimos movimientos AHO (`pa_cash_gmovimientoah_ultimos`, NCBE-2804)
tardó unos 75 s en REST/gRPC frente a 2,3 s del SP directo. Los Query Plan de este paquete
**no permiten atribuir ni descartar** que el SQL contribuya a esa latencia:

- No hay tiempos por QP: `timing_status` = `NOT_CAPTURED`.
- Los literales son de prueba (punto 1); no reproducen el volumen de una cuenta con 1598 movimientos.
- Cada QP mide una sentencia aislada, no cuántas veces la ejecuta la librería: en la ME, la
  librería Java hace consultas por cada fila procesada (causa, catálogo, ATM, documento, moneda y
  oficina).

La hipótesis de consultas por fila es consistente con la escala observada en la ME (1598 filas
~75 s, 324 filas ~23 s, máximo 50 filas ~2,7 s), pero no está medida.

## 4. NCBE-2805 QP-04: control transaccional bajo NOEXEC

QP-04 (`TransaccionAbiertaDataAdapter.confirmarTransaccionesAbiertas`) es el batch
`while (@@trancount>0) begin commit end`. Se conserva en el alcance porque la librería lo ejecuta por
JDBC (`jdbcTemplate.execute`). Se envió bajo `set noexec on/off`, así que no se ejecutó el `commit`;
por eso no tiene IO medido (`measured_reason` = `NOEXEC`) y el consolidado cuenta
`dml_protegidos_noexec = 1`.

# QP-CF-9 — Literales funcionales desde la matriz de equivalencia y verificación aislada de QP-02

## 1. Hallazgo que origina la fase

El literal `CTA_BANCO = 1234567890` usado en QP-CF-1..8 provenía de un test unitario Java
(`resolve_method_literals`, prioridad de fallback), no de un escenario funcional aprobado. Existe una
matriz de equivalencia funcional (Sybase+REST+gRPC) ya ejecutada para el mismo SP/microservicio, con
15/15 casos EQUIVALENTE, que contiene cuentas reales validadas end-to-end. Por política, un test
unitario nunca debe superar en prioridad a una matriz funcional ejecutada. Esta fase corrige esa
inversión de prioridad y regenera los payloads con el literal correcto antes de cualquier corrida
adicional.

## 2. Identidad confirmada (SP/microservicio)

```
sp_objetivo:                    pa_fir_consulta_firmante
base_datos:                     firmas
microservice_via_companion_plan: cpas-mso-consulta-firmante
endpoint:                        /api/v1/firmantes/consultas
grpc_service_method:            com.bolivariano.consultafirmante.ConsultaFirmanteService/ConsultarFirmantes
```

Confirmado por doble vía: `metadata.sp_objetivo` dentro de la propia matriz, y
`run_context.microservice` en el `QA-PLAN-EJECUCION.json` companion (la matriz no declaraba el
microservicio directamente — se resolvió vía el plan de ejecución hermano, mecanismo genérico, no
hardcodeado a este caso).

## 3. Matriz localizada

```
Ruta:   .claude/docs-qa/results/pa_fir_consulta_firmante-04-08-2026-2136/QA-CASOS-PARSEADOS.json
Companion: .claude/docs-qa/results/pa_fir_consulta_firmante-04-08-2026-2136/QA-PLAN-EJECUCION.json
Casos:  15 (TC01-TC15), veredicto_global: 15/15 EQUIVALENTE
```

Localizada mediante `find_functional_equivalence_matrix()` (genérica, por `sp_name`+`microservice`,
sin rutas hardcodeadas al caso Firmante) dentro de `matrix_roots` declarado en la cone-config.

## 4. SHA-256 de la evidencia (no modificada)

```
QA-CASOS-PARSEADOS.json:  a6a9f60b7f5ccc62538e865fb93f2420e37c63243ad2110504ac4c3573ab342f
QA-PLAN-EJECUCION.json:   b15f587b540aeded7c62d4e12b67529213e23b171f27452a8b25f8df5fd3c993
```
Ambos archivos permanecen en su ubicación original, sin escritura ni copia íntegra — solo referenciados
por ruta+hash desde `literal-sources.json`.

## 5. Prioridad de literales — anterior (defectuosa)

```
1. resolve_method_literals() sobre test unitario Java   <- ÚNICA fuente usada de facto
2. (sin matriz, sin fixtures, sin casos de uso documentados)
```

## 6. Prioridad de literales — corregida (esta fase)

```
1. Matriz de equivalencia funcional EQUIVALENTE (resolve_literals_with_priority)
2. Fixtures/evidencia de integración                    <- reservado, no implementado aún
3. Casos de uso documentados                             <- reservado, no implementado aún
4. Test unitario Java (resolve_method_literals)          <- fallback, sin cambios de comportamiento
5. Bloqueo (NOT_APPLICABLE / literal no resuelto)
```

Implementado en `qp_source_extract.py::discover_provenance_entries()`: intenta prioridad 1 primero
(solo si `sp_name`+`microservice`+`matrix_roots`+`literal_sources_cfg` están declarados en la
cone-config Y el conteo de parámetros coincide); si el estado no es `FOUND_EXACT`, cae a la prioridad 4
sin cambios. Ninguna corrida previa que dependiera únicamente del fallback se ve afectada si la
cone-config no declara los campos nuevos (retro-compatible).

## 7. Mapping literal por QP

| QP    | Método                                          | Caso | Escenario                              | Literal(es)                          |
|-------|--------------------------------------------------|------|-----------------------------------------|---------------------------------------|
| QP-01 | `CuentaClasificacionDataAdapter.existeCuentaCorriente` | TC01 | cuenta CTE con firmantes                | `e_cta_banco=0000010014`              |
| QP-02 | `CuentaClasificacionDataAdapter.existeAhorroActiva`    | TC05 | cuenta AHO activa con firmantes         | `e_cta_banco=0000601864`              |
| QP-03 | `CuentaClasificacionDataAdapter.existeAhorroCerrada`   | TC10 | cuenta AHO cerrada (alternativo a TC09) | `e_cta_banco=0000601298`              |
| QP-04 | `FirmanteDataAdapter.contarFirmantes`             | TC05 | cuenta AHO activa (mismo escenario QP-02)| `producto=AHO` (derivado), `e_cta_banco=0000601864` |
| QP-05 | `FirmanteDataAdapter.listarFirmantes`             | TC05 | cuenta AHO activa (mismo escenario QP-02)| `producto=AHO` (derivado), `e_cta_banco=0000601864` |

TC10 se prefirió sobre TC09 para QP-03 porque la precondición SQL de TC09 no confirma explícitamente
`cob_ahorros..ah_cuenta_cerrada` (solo valida presencia de firmantes AHO), mientras TC10 sí la confirma
de forma inequívoca — más directa para el propósito de `existeAhorroCerrada` (verificar existencia en
esa tabla).

`producto=AHO` para QP-04/05 no está en `parametros_entrada` de la matriz; se derivó de
`precondiciones_sql[0]` (`"ca_producto = 'AHO'"`) vía un mecanismo genérico
(`_DERIVED_FIELD_SQL_COLUMN = {"producto": "ca_producto"}` + extracción por patrón), no hardcodeado al
valor "AHO" — el mecanismo es paramétrico por nombre de columna, no por valor.

## 8. Procedencia registrada (`fuente_literales`)

Cada entrada de provenance para QP-01..05 registra en `fuente_literales` una cadena estructurada con
`tipo_fuente=QA_EQUIVALENCE_MATRIX|archivo=<ruta>|sha256=<hash>|test_case_id=<TCxx>|escenario=<...>|jsonpath=<...>|valor=<literal>|razon=<...>` —
trazabilidad completa sin necesidad de cambios de schema (`fuente_literales` ya admitía `string|null`
en v1.0). Ningún campo `firma`/`firmante`/dato personal fue copiado; el redactor recursivo
(`_redact_sensitive`) se usa para cualquier logging de depuración de la matriz.

## 9. Pruebas

14 pruebas nuevas en `test_qp_pipeline.py` (sin Sybase real, matrices sintéticas en `tmp`):

1. `test_matrix_takes_priority_over_unit_test` — con matriz disponible, el literal viene de la matriz,
   no del test unitario, aunque ambos existan.
2. `test_matrix_of_different_sp_rejected` — matriz con `sp_objetivo` distinto nunca se usa.
3. `test_matrix_of_different_microservice_rejected` — matriz con microservicio distinto nunca se usa.
4. `test_case_without_equivalente_verdict_not_auto_selected` — un caso sin veredicto EQUIVALENTE no se
   selecciona automáticamente.
5. `test_case_missing_required_parameter_blocks` — si el parámetro declarado no está en la matriz ni es
   derivable, el estado no es `FOUND_EXACT` (cae a fallback o bloquea, según disponibilidad).
6. `test_fuente_literales_records_jsonpath_and_sha256` — la cadena de procedencia contiene JSONPath y
   SHA-256 verificables.
7. `test_sensitive_firma_field_never_copied_into_fuente_literales` — ningún valor de `firma`/
   `firmante(s)` aparece en la cadena de procedencia generada.
8. `test_different_methods_can_use_different_test_cases` — dos métodos distintos pueden mapear a TC
   distintos sin interferencia.
9. `test_two_methods_sharing_scenario_are_independent_mapping_entries` — QP-04/QP-05 comparten TC05 pero
   son entradas de mapeo independientes (no comparten ejecución ni captura).
10. `test_fallback_to_unit_test_only_when_no_matrix_available` — sin matriz configurada, el
    comportamiento previo (test unitario) permanece intacto, sin regresión.
11. `test_no_firmante_values_hardcoded_in_priority_logic` — el código de `resolve_literals_with_priority`
    no contiene ningún valor de cuenta/firmante hardcodeado del caso real.
12. `test_synthetic_cone_end_to_end_with_functional_matrix` — cono sintético completo (prepare) usando
    una matriz sintética, extremo a extremo.
13-14. Casos adicionales de resolución posicional (`mapping.parameters` por orden declarado vs. nombre
    real del parámetro Java) y de derivación por columna SQL (`producto`←`ca_producto`) genérica.

Resultado de las 4 suites tras estos cambios:

```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 78 passed, 0 failed
test_qp_pipeline.py     : 116 passed, 0 failed   (vs. 104 en QP-CF-8)
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 258 passed, 0 failed   (vs. 246 en QP-CF-8)
```

## 10. `prepare` — validación en fresco

Ejecutado nuevamente sobre `NCBE-1105.json` con los campos nuevos (`microservice_for_matrix`,
`matrix_roots`, `literal_sources_path`) declarados. Los 5 QP resolvieron literales con estado
`FOUND_EXACT` desde la matriz (prioridad 1), ninguno cayó al fallback de test unitario. `source_tree_hash`
determinista confirmado estable entre corridas repetidas (mismo hash con las mismas entradas).

## 11. Resultado aislado de QP-02 (verificación previa a la corrida completa)

Verificado exclusivamente vía `diagnose` (no `run`, no tsql ad hoc) contra un staging fresco con el
payload regenerado (literal `0000601864`, `payload_sha256=b5600baa3e32fe2457f14434da8bda67a7560e0d048f1391705ba5f8435ae282`,
distinto del payload anterior con `1234567890`).

```
compile-only: COMPILE_ONLY_PLAN_AVAILABLE
hostprocess:  HOSTPROCESS_NOT_FOUND
handshake:    SPID_HANDSHAKE_TIMEOUT
target_spid:  null
classification: QP02_DBA_ESCALATION_REQUIRED
exit code: 9
```

Comparación de hashes de evidencia contra QP-CF-8 (mismo mecanismo, literal distinto):

```
target-session.err: 666fd2d506c4f7f6556ebb003caeaa552f5bf7e9f8f6d7d03d5f54eac44f105b  (IDÉNTICO a QP-CF-8)
compile-only.out:    d9c29349d454d3d8eae1ebda364fa09e3b3d9a969cad9e0dc2478799c5ed841e
compile-only.err:    b0f5152923649e05433ffc1e392842baa5e2a75a0add1f21186ca125a0715921
```

`target-session.err` es byte-idéntico al observado en QP-CF-8 pese a que el `payload_sha256` cambió
(literal distinto). Esto es evidencia directa de que **el timeout no depende del literal** — el
comportamiento del servidor/conexión es el mismo con la cuenta real validada por la matriz que con el
valor de test unitario descartado. Escaneo de credenciales sobre toda la evidencia de este diagnóstico
(`grep` de `SYBASE_PASS` real contra el árbol de staging): **0 coincidencias**.

Por regla explícita de §11 de la fase ("Si ocurre timeout o error: no reintentar; no aumentar timeout;
conservar evidencia; mantener escalamiento DBA; detenerse sin ejecutar el cono completo"), la
verificación aislada de QP-02 **no** retornó `QP02_FUNCTIONAL_LITERAL_PASS`.

## 12. Corrida completa del cono

**NO EJECUTADA.** Por §12 de la fase, el `run` completo solo está autorizado si la verificación aislada
de QP-02 pasa. No pasó — no se invocó `run` en ningún momento de esta fase.

## 13. Entrega / gates

**NO GENERADA.** No se produjo README, manifest-consolidado ni ZIP de entrega. El gate de "los 5 QP deben
completar" nunca se evaluó porque QP-02 nunca se ejecutó como parte de una corrida completa (solo se
diagnosticó en aislamiento, según lo requerido).

## 14. Conclusión sobre necesidad de DBA

**Se mantiene y se refuerza.** La coincidencia byte-a-byte de `target-session.err` entre el literal de
test unitario (descartado) y el literal funcional real de la matriz (correcto) descarta el dato como
variable causal. El patrón de fallo (handshake sin respuesta incluso al batch de identificación trivial,
antes de llegar al SELECT sustantivo) es consistente con lo documentado en QP-CF-8: un problema de
servidor/conexión, no de consulta ni de datos. Ningún mecanismo automático adicional está autorizado —
se mantiene `QP02_DBA_ESCALATION_REQUIRED` como estado terminal.

## Archivos modificados en esta fase

```
.claude/docs-qa/inputs/scripts/queryplan/qp_source_extract.py   (funciones nuevas, ver resumen de sesión)
.claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py          (cmd_prepare: lee campos nuevos de cone)
.claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_pipeline.py (14 pruebas nuevas)
.claude/docs-qa/inputs/scripts/queryplan/config/cones/NCBE-1105.json (3 campos nuevos)
.claude/docs-qa/queryplan/casos/NCBE-1105/inputs/literal-sources.json (nuevo, sanitizado)
```

Sin cambios a: agentes, skills, schemas v2.1 finales, repos de negocio (`bb-core-firmas-utils`,
`cpas-mso-consulta-firmante`), la matriz original, `qp_delivery.py`, `qp_provenance.py`.

## Veredicto

**QP02_FUNCTIONAL_LITERAL_TIMEOUT**

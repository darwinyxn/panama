# QP-CF-4 — Reporte técnico interno: intento de corrida viva bloqueado

## Timestamp UTC

- Inicio de fase: `2026-08-07T00:31:36Z` (RUN_TS usado en `--exec-ts`)
- RUN_ID: `20260807T003136Z`

## Baseline Git QA (repositorio `project-agents-assets-banco-bolivariano-qa`)

```
branch: master
HEAD (antes y después del intento): 0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
staged: (vacío)
ahead/behind @{u}: 0 0
```

Cambios presentes en el árbol de trabajo (idénticos a los de QP-CF-1/QP-CF-2, sin adiciones nuevas):
```
M  .claude/agents/agente-queryplan.md
M  .claude/docs-qa/inputs/scripts/queryplan/README.md
M  .claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py
M  .claude/docs-qa/inputs/scripts/queryplan/qp_source_extract.py
M  .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_pipeline.py
M  .claude/skills/query-plan/SKILL.md
?? .claude/docs-qa/inputs/scripts/queryplan/config/cones/NCBE-1105.json
?? .claude/docs-qa/inputs/scripts/queryplan/qp_provenance.py
?? .claude/docs-qa/inputs/scripts/queryplan/schema/provenance-queryplan-v1.schema.json
?? .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_provenance.py
?? .claude/docs-qa/queryplan/casos/
```

## Baseline y tree hash de la librería (`bb-core-firmas-utils`)

```
HEAD general: 1745fb27bc037a43d4ce440c4324d9a66f1417de
tree hash pa-fir-consulta-firmante-utils: 680a765f938ea108e42b12cf1a804cf4e85b0bf7
status --short -- pa-fir-consulta-firmante-utils: (vacío, limpio)
```

Ambos baselines coinciden exactamente con los valores esperados/congelados en QP-CF-2/QP-CF-3. Sin `BLOCKED_SOURCE_BASELINE_CHANGED`.

## Hashes de scripts productivos (antes y después del intento — idénticos)

```
qp_pipeline.py        53b6cdefa0676b86801adcdd68d729864c84d791e6229bae925527ae1d09464e
qp_source_extract.py  1029a9eac44e6ec53d5cc9f9e995d62d136ba94a1dfcf0e5348c312e5389b02a
qp_provenance.py      cb46f4fbe03918cbfc2e193b00c58449dbf7421155cf8ce729af2eb0ba0cc030
qp_delivery.py        08d3baf83f83ea5b7cbcb1bec6abf62952f288bb9741e4a5c282d55acd998917
qp_manifest.py        15f71d5839ca6f1057de400ea275acdd3a029344f925ef4546a577d5a6b0b390
qp_lint.py             ea74341122d02b9ed3c1545bf0e167527aeb50b61026c21e54a63dde180411e6
qp_normalize.py       4dd1a593962abd7492a12669013071fa50f03cce687df930e931c9471b87aa29
qp_sqlcheck.py         69b3904bb2ef11e1a53f7ef1275adc55e7e6539b70a80d3565522466e90d71da
```

Ningún módulo fue modificado durante esta fase (confirmado por comparación antes/después).

## Hashes de payloads (prepare fresco, prefijo 16, `sha256sum | cut -c1-16`)

```
QP-01 460bf67c07c1f86a
QP-02 66e00ed875bdfba8
QP-03 5edf3672b5991f3e
QP-04 cd374c88294b302d
QP-05 f1c4dd78d07c9f2c
```

Idénticos a los auditados en QP-CF-3 — sin `BLOCKED_PREPARE_DRIFT`. `source_tree_hash` del dossier: `f9eb7a589a4b8db44eb3e95ec909d29bf8b2fe6589b6a3d314280551d4a911fc` (sin cambios).

## Comandos ejecutados (sin credenciales)

```
python3 qp_pipeline.py prepare --cone-config config/cones/NCBE-1105.json --output /tmp/NCBE-1105-queryplan-live-20260807T003136Z
python3 qp_pipeline.py run --cone-config config/cones/NCBE-1105.json --evidence-root /tmp/NCBE-1105-queryplan-live-20260807T003136Z --exec-ts 2026-08-07T00:31:36Z --output .claude/docs-qa/queryplan/entregas/NCBE-1105-queryplan-2026-07-09-statistics-io
```

## Resultado por QP

No aplica — la corrida se abortó **antes** de invocar `tsql` para cualquier QP. Ningún archivo `.out`/`.err` fue generado en `live_v21/` (confirmado vacío tras el fallo). Cero conexión a Sybase intentada, cero riesgo de datos.

## Causa raíz del bloqueo (LIVE_RUN_BLOCKED)

`qp_pipeline.py` falló con `FileNotFoundError` y exit code `1`:

```
File "qp_pipeline.py", line 350, in _generate
    tech_src, det_text0 = tech_source(pkg, live_stg)
File "qp_pipeline.py", line 310, in tech_source
    cap = D.load_capture(payload, qid, live_stg)
File ".../qp_delivery.py", line 116, in load_capture
    ob = open(os.path.join(live_stg, "%s.out" % qid), "rb").read()
FileNotFoundError: [Errno 2] No such file or directory: '.../live_v21/QP-01.out'
```

**Defecto identificado**: dentro de `_generate()` (usada por ambos `cmd_run` y `cmd_regenerate`), la función interna `tech_source()` invoca incondicionalmente `D.load_capture()` — que **lee** capturas `.out`/`.err` ya existentes — para construir el modelo técnico (`tech_src["queryplans"]`, con labels/IO derivados del output). Esto ocurre en la línea `qp_pipeline.py:350`, **antes** del bucle principal (línea ~369) que es quien realmente ejecuta `D.run_live()` (el único productor de esos archivos `.out`/`.err` cuando `live_mode=True`).

En otras palabras: en modo `run` contra un `evidence-root` recién creado por `prepare` (sin capturas previas), el pipeline intenta leer evidencia viva que aún no existe, porque el orden de las dos fases (construir modelo técnico ↔ ejecutar contra Sybase) está invertido para ese modo.

**Confirmación de que es un defecto preexistente, no introducido por QP-CF-2**:
- Diff de `qp_pipeline.py` de QP-CF-2 no toca `_generate`, `tech_source` ni `cmd_run` (verificado con grep sobre el diff).
- El código en `git show HEAD:.../qp_pipeline.py` (commit previo a todo el trabajo de este caso) contiene exactamente la misma estructura.
- Ningún test existente (`test_qp_pipeline.py`) ejercita `cmd_run` con `live_mode=True` de punta a punta contra un `evidence-root` sin capturas previas; todos los tests usan `cmd_regenerate` reutilizando fixtures de captura ya preparados (`live_v21/*.out` escritos a mano por el test antes de invocar el comando) — lo que enmascaró el defecto en las 198 pruebas.

**No se corrigió el código** (fuera de alcance explícito de esta fase: *"no modificar código, scripts, agentes, skills, schemas o tests"*).

## Observaciones

No aplica — no se generó ningún QP con plan/IO.

## Gates

No ejecutados — no hay entrega que validar.

## SHA-256 del ZIP

No aplica — no se generó ningún ZIP.

## Ubicación del staging raw

```
/tmp/NCBE-1105-queryplan-live-20260807T003136Z/
    pa_fir_consulta_firmante/
        engine_out/QP-01.sql .. QP-05.sql   (5 payloads preparados, intactos)
        live_v21/                            (vacío — ningún .out/.err generado)
```

Conservado sin modificar para diagnóstico posterior. No se ejecutó ningún `tsql`.

Efecto secundario detectado: `qp_pipeline.py` creó la carpeta `entregas/NCBE-1105-queryplan-2026-07-09-statistics-io/zips/` (vacía, vía `os.makedirs` antes del fallo) al iniciar `_generate()`. No contiene ningún archivo; no está rastreada por Git; se deja intacta para no alterar el estado sin autorización explícita de limpieza.

## Veredicto

**LIVE_RUN_BLOCKED**

## Siguiente paso permitido

Este defecto en `qp_pipeline.py::_generate/tech_source` (orden invertido de lectura-antes-de-escritura de la captura viva en modo `run`) debe corregirse en una fase que autorice explícitamente modificación de código — no en esta fase. Una vez corregido, se podría reintentar `qp_pipeline.py run` con el mismo `evidence-root` ya preparado (payloads intactos, sin necesidad de repetir `prepare`).

# QP-CF-17 — Generación real segura y validación final de entrega

## 1. Estado Git inicial

```
pwd:    /home/ssm-user/project-agents-assets-banco-bolivariano-qa
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
status --short --branch: ## master...origin/master
diff --cached --name-only: (vacío)
ahead/behind @{u}: 0 0
```
Índice vacío. Sin `BLOCKED_REPOSITORY_STATE`.

## 2. Conteo exacto de pruebas

```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 78 passed, 0 failed
test_qp_pipeline.py     : 172 passed, 0 failed
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 314 passed, 0 failed
```
Idéntico al total final registrado en QP-CF-16 (154+18=172 en `test_qp_pipeline.py`; sin pruebas
nuevas, modificadas ni eliminadas desde entonces — verificado por hash idéntico de
`tests/test_qp_pipeline.py`: `7dc3f70a9c7232a92440a8a4ceac402fee1aa64ab92623c428ce0bfefbd91ced`).
Gate cumplido (>296, 0 fallos). Sin `DELIVERY_BASELINE_TEST_FAILURE`.

## 3. Auditoría del runtime

Confirmado por lectura de código (sin modificaciones):
1. `D.run_live()` invoca exclusivamente `PTY.run_pty_session()`.
2. Cero ocurrencias de `subprocess.run` dentro del cuerpo de `run_live()`.
3. Cero imports de `sybase_tsql_wrapper` en `qp_delivery.py`/`qp_pipeline.py`/`qp_tsql_pty.py`/
   `qp_capture_sanitize.py`.
4. `qp_capture_sanitize.py` clasifica por forma de bloque (`_iter_plan_segments`, `IO_LINE_RE`,
   `MSG_HDR` severity≥11), nunca por nombre de columna.
5. `render_detalle()` pasa `live["norm_output"]` únicamente a `build_technical_evidence()`; ya no
   itera directamente sobre él para el render.
6. `render_observaciones()` no referencia `live[...]` en ningún punto.
7. 4 sitios de `raise UnsafeCaptureSegmentationError` presentes.
8. `high_sev = parse_high_sev(combined)` — severity≥11 detectable sobre la salida combinada.
9. `_MARKER_ALIAS = "_qp_marker"` y filtro de marcador único presentes en `sanitize_session_text`.
10. `raise QueryPlanExecutionTimeout(...) from None` presente.

Sin defectos encontrados. Sin `DELIVERY_PRECHECK_FAILURE`. Sin modificación de código.

## 4. Staging

```
RUN_ID: 20260808T160910Z
ruta:   /tmp/NCBE-1105-QP-CF-17-real-delivery-20260808T160910Z (eliminada al final de la fase)
permisos: chmod 700 (verificado drwx------)
timestamp UTC de creación: 2026-08-08T16:09:10Z
```
Sin reutilizar capturas de QP-CF-10/12/13/14/15/16 — staging completamente fresco.

## 5. Prepare

`PIPELINE_PROVENANCE_READY_PREPARE_READY`, 5/5 payloads, 0 bloqueados, 0 placeholders, 0 DML, 0 SP
hijos (confirmado por `inventory`), 0 secretos.

| QP | Método Java | Tablas | Literal | Fuente | payload_sha256 |
|---|---|---|---|---|---|
| QP-01 | `existeCuentaCorriente` | `cob_cuentas..cc_ctacte` | `0000010014` | TC01, matriz | `5b45aa02...c1` |
| QP-02 | `existeAhorroActiva` | `cob_ahorros..ah_cuenta` | `0000601864` | TC05, matriz | `b5600baa3e32fe2457f14434da8bda67a7560e0d048f1391705ba5f8435ae282` |
| QP-03 | `existeAhorroCerrada` | `cob_ahorros..ah_cuenta_cerrada` | `0000601298` | TC10, matriz | `8d64ca55...5f5` |
| QP-04 | `contarFirmantes` | `fi_candidata`+`fi_imagen`+`cl_ente` | `AHO`/`0000601864` | TC05, matriz | `a5a77b45...6da` |
| QP-05 | `listarFirmantes` | `fi_candidata`+`fi_imagen`+`cl_ente` | `AHO`/`0000601864` | TC05, matriz | `4e55dd5c...511` |

QP-02 `payload_sha256` idéntico al requerido exactamente:
`b5600baa3e32fe2457f14434da8bda67a7560e0d048f1391705ba5f8435ae282`. Sin `BLOCKED_PAYLOAD_DRIFT`.

## 6. Preflight

`PREFLIGHT_OK`.

## 7. Corrida live

```
qp_pipeline.py run --cone-config config/cones/NCBE-1105.json --evidence-root <staging> \
  --exec-ts 2026-08-08T16:09:43Z --output <staging>/delivery --timeout-seconds 120 --pause 1.0
```
Camino: `_generate(live_mode=True)` → Fase 1 (`D.run_live()` → `qp_tsql_pty.run_pty_session()`) para
cada QP en orden → Fase 2 (`render_detalle()`/`render_observaciones()` vía
`qp_capture_sanitize.build_technical_evidence()`). Secuencial, una sesión PTY por QP, un intento por
QP, timeout 120s, cero retries. Sin scripts temporales, sin wrapper de Matrices, sin `tsql` manual,
sin `diagnose`, sin SP completo. `VERDICT: FULL_RUN_DELIVERY_READY`, exit=0, duración total ~9s
(16:09:43Z → 16:09:52Z).

## 8-13. Resultado QP-01 a QP-05

| QP | .out bytes | .err bytes | marker_detected | plan | io_tables | resultset_removed | removed_sections |
|---|---|---|---|---|---|---|---|
| QP-01 | 4275 | 0 | true | true | 1 | true | 1 |
| QP-02 | 4275 | 0 | true | true | 1 | true | 1 |
| QP-03 | 4143 | 0 | true | true | 1 | true | 1 |
| QP-04 | 7994 | 0 | true | true | 3 | true | 1 |
| QP-05 | 9623 | 0 | true | true | 3 | true | 1 |

`capture_mode=pty_combined` en los 5. Ningún timeout, ningún error. Marcador técnico
(`QPPTY[0-9a-f]+`) y alias (`_qp_marker`): 0 coincidencias en los 5 `.out`. Credenciales: 0
coincidencias en las 10 capturas (`.out`+`.err`×5). Ningún QP-01..05 devuelve severity≥11.

## 14. Segmentación real (QP-01 a QP-05)

- **QP-01/02/03**: plan e IO conservados íntegros; la fila escalar (`1`) NO se incorporó al detalle
  (confirmado: el bloque "QUERY PLAN"/"STATISTICS IO" en `detalle_ejecucion.qp` no contiene ningún
  encabezado ni valor de fila).
- **QP-04**: plan de join+agregación (`SCALAR AGGREGATE Operator`, `N-ARY NESTED LOOP JOIN`)
  conservado íntegro; 3 objetos de Statistics IO (`fi_candidata`/`fi_imagen`/`cl_ente`) conservados;
  el resultado numérico del `COUNT` fue excluido (confirmado por ausencia en el texto sanitizado).
- **QP-05**: plan completo del join de tres tablas (5 operadores) conservado íntegro; los 3 objetos
  de Statistics IO conservados con sus lecturas reales; encabezado funcional (`Identificacion`/
  `Nombre`/`Firma`) EXCLUIDO; fila funcional EXCLUIDA. Verificación de datos REALES (identificación
  de 10 caracteres, nombre de 68 caracteres, blob de firma de 1506 caracteres, extraídos y
  comparados ÍNTEGRAMENTE EN MEMORIA dentro de un único proceso Python — nunca persistidos a disco
  ni impresos en consola): **0 coincidencias** de identificación, nombre, blob completo, prefijo de
  60 caracteres del blob, ni del encabezado de columnas, en ninguno de los 3 miembros del ZIP.
  `UnsafeCaptureSegmentationError` NO se lanzó — la segmentación fue inequívoca en los 5 QP.

## 15. Query Plans

5/5 presentes. QP-01: acceso por índice sobre `cc_ctacte`. QP-02: acceso por índice clusterizado
sobre `ah_cuenta` (mismo plan reproducido en QP-CF-13/14). QP-03: acceso por índice sobre
`ah_cuenta_cerrada`. QP-04/05: join de 3 tablas idéntico en estructura.

## 16. Statistics IO

9 objetos en total (1+1+1+3+3), todos correspondientes a las tablas esperadas, con lecturas lógicas/
físicas reales capturadas.

## 17. Manifest

`schema_version: "2.1"`, identidad correcta (`sp_name=pa_fir_consulta_firmante`,
`microservicio=pa-fir-consulta-firmante-utils`, `hu_cono=NCBE-1105`, `hu_individual=NCBE-1111`), 5
QP en orden estable QP-01..QP-05, métodos Java correctos, tablas correctas, `payload_sha256`
correctos (incluido QP-02 exacto), procedencia completa (matriz de equivalencia), plan/IO presentes
en los 5, 0 DML, 0 SP hijos, 0 placeholders, 0 secretos, 0 rutas absolutas, 0 `raw_output`/
`result_rows`/`sample_data`/`response_body`. `lint_manifest_v2`: PASS.

## 18. Detalle

`detalle_ejecucion.qp`: 5 secciones QP-01..QP-05, 5 planes, 9 objetos Statistics IO, 0 filas
funcionales, 0 datos personales (verificado en memoria contra los valores reales de QP-05). Nota
técnica "Las filas funcionales del SELECT fueron excluidas de la entrega por diseño (1 bloque(s)
omitido(s))" presente en los 5 bloques QP, compatible con la estructura oficial (no introduce ruido
adicional).

## 19. Observaciones

`observaciones.qp`: 5/5 QP exitosos, criterio Banco `2026-07-09-statistics-io` correcto, "Total
observaciones: 0 en 0 de 5 QP", sin mención de DML/SP hijos activos, sin narrativa histórica, sin
referencia a bloqueo DBA vigente, sin dependencia productiva de Matrices.

## 20. ZIP

```
nombre: pa_fir_consulta_firmante-queryplan.zip
tamaño: 7556 bytes
sha256: e1127e17da4a094bff2233d0bd188ec9753f4140ceded9bdfcc6ae670263b99a
miembros (3 exactos, sin directorios, sin .out/.err, sin logs, sin ocultos):
  manifest-queryplan.json    23981 bytes  sha256=b53782ec323b03994f87c33d6e4e334d9b9f8baa8890a38c0557e89fdfdeb74e
  detalle_ejecucion.qp       26099 bytes  sha256=9dc8d708766840bd440628f429bbe46a4de0395453dc285be0ac514dc489f90c
  observaciones.qp             652 bytes  sha256=bf0cf06fb74c550e6b14130d39c84f331a68476a3d3d7876e4ea4d34e17ea001
```

## 21. Consolidado y README

`manifest-consolidado-queryplan.json` referencia correctamente `NCBE-1105`/`NCBE-1111`/
`pa_fir_consulta_firmante`/`pa-fir-consulta-firmante-utils`/5 QP/0 SP hijos/criterio
`2026-07-09-statistics-io`. `delivery_ready: true`. `README.md`: **no aplica** — confirmado (por
lectura de `qp_pipeline.py` y por precedente de QP-CF-11) que el pipeline NUNCA genera README
automáticamente; es documentación fuente hand-authored, fuera del alcance de "artefactos canónicos
de entrega" producidos por esta fase. Ninguno de los CONOS previos (NCBE-661) tiene su README
generado por el pipeline tampoco. No se fabricó ningún README en esta fase.

## 22. Escaneos

| Categoría | Archivo(s) | Coincidencias | PASS/FAIL |
|---|---|---|---|
| secret scan (SYBASE_PASS) | manifest/detalle/observaciones | 0 | PASS |
| marker scan (QPPTY/_qp_marker) | manifest/detalle/observaciones | 0 | PASS |
| absolute-path scan | manifest/detalle/observaciones | 0 | PASS |
| placeholder scan (?/...) | ZIP completo | 0 | PASS |
| resultset scan (encabezado Identificacion/Nombre/Firma) | detalle | 0 | PASS |
| sensitive-data scan (identificación/nombre/blob REALES de QP-05, comparados en memoria) | manifest/detalle/observaciones | 0 | PASS |
| binary/blob scan (prefijo del blob real de firma) | detalle | 0 | PASS |

El literal `0000601864`/`AHO` aparece dentro del SQL técnico (`SQL EJECUTADO`/`BLOQUE ENVIADO A
tsql`) — permitido explícitamente por diseño (QP-CF-16), no es una fila de resultset.

## 23. Gates

```
schema validation:     PASS
manifest lint:         PASS
cross-lint:            PASS
delivery/ZIP lint:     PASS
SHA validation:        PASS (todos los hashes registrados y verificados)
traceability:          PASS (fuente_literales completa en los 5 QP)
placeholder scan:      PASS
secret scan:           PASS
sensitive-data scan:   PASS
absolute-path scan:    PASS
marker scan:           PASS
```
Todos PASS. Sin `DELIVERY_VALIDATION_FAILURE`.

## 24. Reproducibilidad

`regenerate` (sin re-ejecutar Sybase) desde la misma captura viva y el mismo `--exec-ts` produjo un
ZIP **byte-idéntico** (`e1127e17...b99a`, igual en ambas generaciones) y los 3 miembros con hashes
idénticos. Cero reaparición de filas funcionales. Único campo potencialmente variable
(`ejecucion_utc`) se mantuvo igual por pasar `--exec-ts` explícito idéntico en ambas corridas — no es
fuente de no-determinismo del pipeline. Sin `DELIVERY_NON_DETERMINISTIC`.

## 25. Pruebas finales

```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 78 passed, 0 failed
test_qp_pipeline.py     : 172 passed, 0 failed
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 314 passed, 0 failed
```
Idéntico al gate inicial. Sin modificación de código tras la corrida.

## 26. Archivos creados

```
NUEVO (entrega conservada, verdict QUERYPLAN_DELIVERY_READY_PASS):
  .claude/docs-qa/queryplan/entregas/NCBE-1105-queryplan-2026-07-09-statistics-io/
    manifest-consolidado-queryplan.json
    zips/pa_fir_consulta_firmante-queryplan.zip
NUEVO: .claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-17-REAL-SAFE-DELIVERY-REPORT.md
```
Sin modificación de ningún archivo de código (`qp_tsql_pty.py`/`qp_capture_sanitize.py`/
`qp_delivery.py`/`qp_pipeline.py`/`tests/`) — hashes verificados idénticos a QP-CF-16. Sin
`DELIVERY_IMPLEMENTATION_DEFECT`.

## 27. Veredicto

**`QUERYPLAN_DELIVERY_READY_PASS`**

Los cinco QP terminaron correctamente; plan e IO se conservan íntegros en los 5; las filas
funcionales se excluyen en los 5 (verificado estructuralmente y con los valores reales de QP-05
comparados en memoria); QP-05 no filtra ningún dato sensible; los tres miembros son válidos; el ZIP
contiene exactamente tres miembros; el consolidado es coherente (README no aplica, confirmado);
todos los gates pasan; la reproducción es determinística; las pruebas iniciales y finales están
verdes (314/314); no se modificó código en esta fase.

## 28. Estado Git final

```
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
```
Índice vacío. Sin commit. Sin push. Sin cambios de código durante QP-CF-17 (hashes idénticos a
QP-CF-16). Matrices intactas. Repositorios de negocio intactos. Agentes intactos. Único contenido
nuevo: los artefactos de entrega conservados (§26) y este reporte. Capturas crudas eliminadas de
`/tmp` tras conservar la entrega validada.

## 29. Siguiente paso permitido

La entrega Query Plan de Consulta Firmante (NCBE-1105/NCBE-1111) queda disponible en su ruta
canónica dentro del workspace para revisión/publicación en una fase posterior explícitamente
autorizada (staging para el Banco, commit, push) — ninguna de esas acciones se ejecutó en esta fase.

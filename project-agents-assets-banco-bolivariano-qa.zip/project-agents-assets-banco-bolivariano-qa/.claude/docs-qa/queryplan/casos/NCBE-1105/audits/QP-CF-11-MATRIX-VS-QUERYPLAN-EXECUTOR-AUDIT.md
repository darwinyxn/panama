# QP-CF-11 — Matriz vs Query Plan: auditoría de ejecutores Sybase

Fase de SOLO LECTURA. No se ejecutó `tsql`, `preflight`, `run`, `diagnose`, `execute_all.py`,
`run_qa.py`, `discover_data.py` ni ningún SELECT/SP/PRE/POST/snapshot. Únicamente lectura de código,
lectura de evidencia ya materializada en disco, y `which tsql`/`tsql -C` (no conectan a red).

## 1. Veredicto

**`QUERYPLAN_EXECUTION_PATH_SUSPECTED`**

## 2. Estado Git

```
pwd:    /home/ssm-user/project-agents-assets-banco-bolivariano-qa
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
status --short --branch: ## master...origin/master
  (mismos cambios acumulados del frente Query Plan de fases anteriores, sin nada nuevo)
diff --cached --name-only: (vacío)
```
Índice vacío. Sin cambios staged ajenos. No aplica `BLOCKED_REPOSITORY_STATE`.

## 3. Archivos auditados

| Archivo | Ruta | SHA-256 |
|---|---|---|
| `sybase_tsql_wrapper.py` | `.claude/docs-qa/inputs/scripts/sybase_tsql_wrapper.py` | `9d3cebdda36f4e8f8ecc090393e8190fff0eda7a841d36ee0dae2112dddd5253` |
| `execute_all.py` | `.claude/docs-qa/inputs/scripts/auto/execute_all.py` | `e2b3e4db62a0de607f6233680c9f819c935a90e3ae226ae0f5b861afe0d8f4f9` |
| `discover_data.py` | `.claude/docs-qa/inputs/scripts/auto/discover_data.py` | `a89c7cfa0df56e45a0cdc8fb440e7186342d74d85aed75299ee3ad9489a1d147` |
| `run_qa.py` | `.claude/docs-qa/inputs/scripts/auto/run_qa.py` | `81c5c07e8fd795bb47a8bab6d0d829122bfd9d97b5650aee9fba97696f79d9ab` |
| `parse_test_cases.py` | `.claude/docs-qa/inputs/scripts/auto/parse_test_cases.py` | `ae694f29022a674d52e424c5b0a0210805bf9c23b38a91acef532e2a339a4d7d` |
| `agente-qa-auto-05-matrix-flow.md` | `.claude/agents/agente-qa-auto-05-matrix-flow.md` | `2813e0b3f248ecf926eaba8f6e6a7ef13d8bdc994c6b0235ab0928094cd2041c` |
| `agente-qa-auto-02-test-cases-validator.md` | `.claude/agents/agente-qa-auto-02-test-cases-validator.md` | `d3c0b17d09ff79bcc961bd6e7d8e7fcda0149228835a8c4291a073e5ab1f1ce6` |
| `qp_delivery.py` | `.claude/docs-qa/inputs/scripts/queryplan/qp_delivery.py` | `dfe487a09a5f359bfd7825c1d3b7e4f2f91b8843e97326ed1f3c6e4a82054596` |
| `qp_pipeline.py` | `.claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py` | `d6fd34daa11d97b915008cac6ba845a280c338780c21d2b4b6d7039f38934dae` |
| `qp_source_extract.py` | `.claude/docs-qa/inputs/scripts/queryplan/qp_source_extract.py` | `2d7898ed5e4863bc2fe26cf8de6c8d76e8f711cea3f2b26adcc4c05905e052ae` |
| `NCBE-1105.json` | `.claude/docs-qa/inputs/scripts/queryplan/config/cones/NCBE-1105.json` | `c5d92168ddee0e993e66ec1f46ac9ca42d7294528d952d03059818775b6b3fc7` |
| `literal-sources.json` | `.claude/docs-qa/queryplan/casos/NCBE-1105/inputs/literal-sources.json` | `e51e009adcdc55823c4519ddc364c0678bab79a7530d303fce96a169dd46c26a` |
| `QP-CF-10-QP02-FUNCTIONAL-RUN-REPORT.md` | `.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-10-QP02-FUNCTIONAL-RUN-REPORT.md` | `959d3e2f534ef5183e487306ebefa30a25aaf3175b16ae0ef9e7524f7a48d158` |

## 4. Flujo Sybase de discovery

`discover_data.py:62-72` (`execute_single_query`), invocado desde `main()` (`discover_data.py:75-268`).
Usa `SybaseTsqlConnection` (`sybase_tsql_wrapper.py`) — import en `discover_data.py:56`. Una sola
conexión persistente para todas las queries Tier1/Tier2, abierta en `discover_data.py:98-101` y
cerrada al final (`discover_data.py:234`). `database=args.database` (`discover_data.py:98`), argumento
requerido (`--database`, `discover_data.py:80`); `run_qa.py` lo infiere del documento si no se pasa
(`run_qa.py:567`). Para este caso: `data_discovery.json:"database": "firmas"`. Solo ejecuta SELECT,
nunca EXEC de SPs.

## 5. Flujo Sybase de execute_all.py

`connect_sybase(metadata)` (`execute_all.py:1169-1190`): lee `SYBASE_SERVER`/`SYBASE_USER`/
`SYBASE_PASS` de `os.environ` (`execute_all.py:1171-1173`), `database = metadata.get('base_datos','')`
(`execute_all.py:1179`) — para este caso `firmas` (confirmado en `QA-CASOS-PARSEADOS.json:
metadata.base_datos = "firmas"`). Una sola conexión persistente para TODO el ciclo de la corrida
(abierta en `execute_all.py:2072`, reusada en cada TC), NO una conexión por consulta.

`exec_sp()` (`execute_all.py:1662-1761`) construye `DECLARE @return_code int / EXEC @return_code =
<sp_full_name> @params... / SELECT @return_code as return_code` (`execute_all.py:1707-1718`), donde
`sp_full_name = metadata['base_datos'] + '..' + metadata['sp_objetivo']` (`execute_all.py:1979`) →
`firmas..pa_fir_consulta_firmante`. Enviado vía `conn._execute_raw(sql)` (`execute_all.py:1721`), SIN
override de `timeout_s` → usa el default del wrapper (30s, `sybase_tsql_wrapper.py:112`). Mismo
mecanismo de `go`/marcador que el discovery — no hay cliente distinto para el EXEC del SP.

`execute_mutants_and_dynamic()` (`execute_all.py:1367-1402`) recorre las sentencias PRE/POST del TC:
`UPDATE/INSERT/DELETE/ALTER` se ejecutan siempre vía `query_safe()`→`_execute_raw()`; bloques `DECLARE`
también; `SELECT` se ejecutan **solo si tienen alias `as <ident>`** (para resolver parámetros
dinámicos) — los SELECT de verificación sin alias (como el de TC05 en `precondiciones_sql`, ver §15)
se envían a Sybase pero su resultado se ignora (`execute_all.py:1376`, comentario explícito: "Los
SELECT de verificacion SIN alias de columna se ignoran (el snapshot los reemplaza)").

## 6. Flujo Sybase de Query Plan

`D.run_live()` (`qp_delivery.py:123-145`): `subprocess.run(["tsql", "-S", srv, "-U", usr, "-P", pwd],
input=pb, stdout=fo, stderr=fe, timeout=timeout_seconds)` (`qp_delivery.py:136-137`) — **un proceso
`tsql` nuevo por QP**, sin PTY (`stdout`/`stderr` van directo a archivos abiertos con `open(...,
"wb")`), payload completo (con `use <db>`/`set statistics io on`/`set showplan on`/SQL/`go`) escrito
de una sola vez vía `input=pb` y cerrado (`stdin` implícito de `subprocess.run` con `input=`, que cierra
el pipe automáticamente tras escribir). Sin health-check previo del proceso, sin marcador sintético de
fin de batch, sin lectura incremental — `subprocess.run` bloquea hasta que el proceso termina o vence
el `timeout` (`qp_delivery.py:137`, capturado como `subprocess.TimeoutExpired` → `qp_delivery.py:138`).
`--execution-only` (`qp_pipeline.py:_run_execution_only`) invoca exactamente esta misma función, sin
código adicional.

## 7. Identidad de conexión

Sin imprimir valores: `SYBASE_SERVER` en el entorno actual == `"sybasedvp1"` → **True** (comparación en
memoria, sin exponer el valor). Ambos `freetds.conf` del sistema (`/usr/local/etc/freetds.conf` y
`~/.freetds/freetds.conf`) declaran la misma sección `[sybasedvp1]`: `host = 172.16.31.91`,
`port = 2050`, `tds version = 5.0`; el segundo añade `client charset = UTF-8` a nivel `[global]`.
`tsql -C` (compile-time, sin conectar): `freetds v1.4.23`, `TDS version: 5.0`, `iconv: yes`. Query Plan
lee `SYBASE_SERVER`/`SYBASE_USER`/`SYBASE_PASS` de `os.environ` (`qp_pipeline.py:227-228`,
`qp_delivery.py:130`); Matriz también los lee de `os.environ`/`os.getenv` en los mismos tres puntos
(`sybase_tsql_wrapper.py:269-271` solo en `test_connection()`, `discover_data.py:90-92`,
`execute_all.py:1171-1173`). **No hay evidencia de código de que usen credenciales/host distintos** —
ambos consumen las mismas tres variables de entorno del mismo proceso shell.

## 8. Cliente y ciclo de vida

| Aspecto | Matriz/discovery | Matriz/SP | Query Plan |
|---|---|---|---|
| Ejecutable cliente | `tsql` (FreeTDS) | `tsql` (FreeTDS) | `tsql` (FreeTDS) |
| Wrapper Python | `SybaseTsqlConnection` | `SybaseTsqlConnection` (mismo) | ninguno (subprocess directo) |
| PTY o pipe | **PTY** (`pty.openpty()`, `sybase_tsql_wrapper.py:32`) | PTY (misma conexión) | **pipe** (`stdin=subprocess.PIPE` en Popen de diagnose; en `run_live` ni siquiera pipe: archivo directo) |
| Proceso persistente | **Sí** — un solo `tsql` para toda la corrida de discovery | **Sí** — un solo `tsql` para todo el ciclo PRE→EXEC→POST de todos los TC | **No** — un proceso `tsql` nuevo por cada QP |
| Proceso por consulta | No | No | **Sí** (cada QP = 1 proceso) |
| Modo de entrada | `stdin=subprocess.PIPE`, `write()`+`flush()` por query (`sybase_tsql_wrapper.py:77-78`) | mismo wrapper | `input=pb` de una sola vez en `subprocess.run` (`qp_delivery.py:136-137`) |
| Modo de salida | lectura incremental no bloqueante vía `os.read(master_fd,...)` sobre el PTY (`sybase_tsql_wrapper.py:92`) | mismo wrapper | `stdout`/`stderr` a archivo, `subprocess.run` espera a EOF/exit o timeout |
| Terminador batch | `go` auto-agregado si falta (`sybase_tsql_wrapper.py:63-64`) + batch sintético del marcador | mismo wrapper | `go` explícito en el payload materializado, sin batch adicional |
| Espera de prompt | **No** — detecta fin por marcador `___TSQL_END___` + `(1 row affected)` en el stream, nunca por el prompt `1>` | mismo mecanismo | **No aplica** — no hay lectura incremental; se espera a que el proceso `tsql` completo termine (EOF de stdout al cerrarse el proceso) |
| Cierre de sesión | `close()`: `quit\n` + `wait(timeout=5)`, si falla `kill()` (`sybase_tsql_wrapper.py:253-262`) | igual, reconexión automática en varios puntos tras excepción (`execute_all.py:793-796`, `881-883`, `1098-1101`) | el proceso termina solo al completar el batch o al ser matado por `subprocess.run(timeout=...)` |
| Timeout | 30s default por query, override a 90s en snapshots (`SNAPSHOT_TIMEOUT_S`, `execute_all.py:387`), 10s en el `connect()` inicial | 30s default (sin override) en `exec_sp` | 120s (default `qp_delivery.DEFAULT_TIMEOUT_SECONDS`), configurable por `--timeout-seconds` |
| Charset | `client charset = UTF-8` (`~/.freetds/freetds.conf`, sección `[global]`) o `utf8` (`/usr/local/etc/freetds.conf`, segunda entrada `[sybasedvp1]`) | mismo | mismo (no se pasa `-J`/`-C` explícito en ninguno de los dos frentes — ambos dependen del `freetds.conf` del sistema) |
| Locale | no configurado explícitamente por ningún frente vía flag `tsql`; ambos dependen del entorno del proceso | igual | igual |
| TDS version | 5.0 (de `freetds.conf`, ningún frente pasa `-t`/versión por CLI) | 5.0 | 5.0 |

## 9. Contexto de base

- **Discovery**: `SybaseTsqlConnection(..., database=args.database)` → login inicial con `-D firmas`
  (para este caso). El SQL de discovery de TC05 referencia tablas totalmente cualificadas
  (`cob_ahorros..ah_cuenta`, `firmas..fi_candidata`) — no depende del contexto de base tras el login.
- **Ejecución SP**: `connect_sybase(metadata)` con `database = metadata['base_datos']` = `firmas`
  (mismo login `-D firmas`). El `EXEC firmas..pa_fir_consulta_firmante` va con base explícitamente
  calificada — tampoco depende del contexto tras el login.
- **Query Plan QP-02**: el payload materializado por `prepare` es:
  ```
  use cob_ahorros
  go
  set statistics io on
  set showplan on
  go
  select 1 from cob_ahorros..ah_cuenta where ah_cta_banco = '0000601864'
  go
  ```
  Login vía `tsql -S -U -P` **sin** `-D` (ningún flag de base inicial — `qp_delivery.py:136`); el
  cambio de base ocurre DESPUÉS del login, vía `use cob_ahorros` como primer batch del payload. El
  SELECT ya va totalmente cualificado (`cob_ahorros..ah_cuenta`), por lo que el `use` es redundante
  para la resolución de la tabla, pero establece el contexto de sesión antes de los `set` de plan/IO.
  No se detectó ningún salto, `go` mal ubicado o cambio de contexto incorrecto: la secuencia
  `use→go→set showplan+statistics io→go→SELECT→go` es sintácticamente correcta y es la misma
  estructura usada exitosamente por QP-01 (que sí completó, ver §15).

## 10. SQL enviado

| Camino | SQL real |
|---|---|
| Discovery (TC05) | `SELECT (SELECT COUNT(1) FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000601864') AS existe_aho_activa, (SELECT COUNT(1) FROM firmas..fi_candidata WHERE ca_producto = 'AHO' AND ca_cuenta = '0000601864') AS firmantes_aho_pre` |
| Ejecución SP (TC05) | `DECLARE @return_code int` / `EXEC @return_code = firmas..pa_fir_consulta_firmante @e_cta_banco='0000601864'` / `SELECT @return_code as return_code` |
| Query Plan (QP-02) | `select 1 from cob_ahorros..ah_cuenta where ah_cta_banco = '0000601864'` |

Diferencias sustantivas, no solo de forma:

- Discovery usa `SELECT COUNT(1)` (agregación, sin acceso a filas individuales fuera del contador) vs
  Query Plan usa `SELECT 1 ... WHERE` (acceso directo a fila, sin agregación) — ambos escanean la
  misma condición de filtro, pero el plan de ejecución del optimizador puede diferir entre un `COUNT`
  con subconsulta anidada y un `SELECT 1` simple con `WHERE`.
- Ejecución SP invoca el procedimiento compilado completo (`pa_fir_consulta_firmante`), que
  internamente puede ejecutar su propia lógica de acceso a `cob_ahorros..ah_cuenta` (y a otras tablas)
  bajo un PLAN DE EJECUCIÓN DEL PROCEDIMIENTO COMPILADO, distinto del plan ad hoc que genera Sybase
  para un SELECT suelto no perteneciente a ningún SP.
- Query Plan es una consulta AD HOC instrumentada (`set showplan on`+`set statistics io on`) sobre la
  MISMA tabla que probablemente consulta el SP internamente, pero fuera del contexto/plan del SP.

**No se afirma que sean equivalentes técnicamente solo por consultar la misma cuenta** — son tres
operaciones SQL distintas (agregación vs. acceso directo vs. procedimiento compilado) sobre el mismo
dato subyacente.

## 11. Opciones de sesión

| Opción | Frente que la usa | Orden de envío | Batch separado o compartido | Efecto posible |
|---|---|---|---|---|
| `set showplan on` | Solo Query Plan | 2do batch (tras `use`) | Batch compartido con `set statistics io on` | Instruye a ASE a imprimir el árbol del plan antes de ejecutar cada statement subsecuente |
| `set statistics io on` | Solo Query Plan | mismo batch que `showplan` | compartido | Instruye a ASE a imprimir I/O físico/lógico por tabla tras cada statement |
| `set noexec on/off` | Solo Query Plan (en payloads DML, no en QP-02 que es SELECT puro) | — | — | Compila sin ejecutar — no aplica a QP-02 |
| `set rowcount`, `set chained`, `set transaction isolation level`, `set ansi_null`, `set quoted_identifier`, `set flushmessage`, `set nocount` | **Ninguno de los dos frentes** (confirmado por grep exhaustivo sobre `sybase_tsql_wrapper.py`, `execute_all.py`, `discover_data.py`, `run_qa.py`, `qp_delivery.py`, `qp_pipeline.py` — cero coincidencias reales) | — | — | No aplica |

**No se determina causalidad**: `showplan`/`statistics io` son las únicas opciones de sesión que Query
Plan añade y que Matriz nunca envía, pero no hay evidencia de código ni de comportamiento documentado
de ASE en este entorno que confirme que estas dos opciones, por sí solas, provoquen un timeout sobre
una tabla donde un `SELECT COUNT(1)` sin ellas sí completó.

## 12. Terminadores y batches

- **Matriz**: el wrapper (`sybase_tsql_wrapper.py:63-64`) auto-agrega `go` si la query no termina en
  `GO`, y SIEMPRE añade un segundo batch sintético `SELECT '___TSQL_END___' as _marker\ngo` tras la
  query real (`sybase_tsql_wrapper.py:71`) — cada llamada real a Sybase son, en la práctica, DOS
  batches: el de negocio + el del marcador de sincronización.
- **Query Plan**: el payload materializado ya contiene sus propios `go` explícitos entre cada `set`/
  SELECT (ver §9); no hay ningún batch sintético adicional — el payload completo (incluidos todos los
  `go`) se envía de una sola escritura (`input=pb`), y el cliente `tsql` los procesa secuencialmente
  sin que el pipeline añada nada después del último `go`.

## 13. Captura de salida

- **Matriz**: PTY con `stdout`+`stderr` mezclados en el mismo `slave_fd` (`sybase_tsql_wrapper.py:37-
  38`) — no hay separación de streams; lectura no bloqueante con `select.select(...,1.0)` en loop
  (`sybase_tsql_wrapper.py:89`) hasta encontrar el marcador de fin.
- **Query Plan**: `stdout`/`stderr` van a DOS archivos SEPARADOS abiertos directamente
  (`qp_delivery.py:135`, `open(outp,"wb")`/`open(errp,"wb")`), sin lectura incremental — el proceso
  `subprocess.run` con `input=`/`stdout=`/`stderr=` a archivo espera el fin real del proceso o el
  timeout, sin inspeccionar el contenido mientras corre.

**Riesgos analizados**:
- Bloqueo por buffering: descartado como causa aquí — `subprocess.run` con `stdout`/`stderr`
  redirigidos a archivo (no a `PIPE`) no tiene el problema de buffer interno de Python que sí existía
  en el mecanismo de `diagnose` (`_StreamReader`, corregido en QP-CF-8 con `bufsize=0`); `run_live` no
  usa `_StreamReader` en absoluto.
- Espera de prompt: no aplica a Query Plan (no hay lectura de prompt, `subprocess.run` no inspecciona
  contenido).
- EOF/batch no finalizado: el hecho de que `QP-02.out` sea **0 bytes** tras 120s (confirmado en
  `QP-CF-10-QP02-FUNCTIONAL-RUN-REPORT.md`, §11) indica que **ni siquiera el primer `go` (los `set`
  de sesión) produjo salida visible** — o el proceso `tsql` nunca llegó a procesar el primer batch, o
  ASE nunca respondió a la conexión/primer comando.
- Diferencia stderr/stdout: `QP-02.err` (283 bytes) contiene únicamente mensajes de transporte
  severity=10 (cambio de charset, "Total writes for this command: 0" — **dos veces**, lo que sugiere
  que el cliente SÍ llegó a procesar al menos las líneas de conexión/negociación de charset, pero
  nunca llegó a producir la salida del plan/IO del SELECT).

Estas son HIPÓTESIS respaldadas por evidencia parcial, NO hallazgos confirmados — no hay visibilidad
de qué ocurrió exactamente dentro del proceso `tsql` durante los 120s.

## 14. Timeout y finalización

| Aspecto | Matriz | Query Plan |
|---|---|---|
| Timeout por query | 30s (default), 90s (snapshots) | 120s (default), configurable |
| Timeout por TC/lote | no explícito por TC; `run_qa.py` usa `timeout=1800` para el subprocess completo de `execute_all.py` | no aplica (1 QP = 1 conexión = 1 timeout) |
| Watchdog externo | ninguno adicional — el propio `_send_and_read` actúa como watchdog interno | ninguno — `subprocess.run(timeout=...)` es el único mecanismo |
| Señal usada para finalizar | `proc.kill()` (SIGKILL directo, `sybase_tsql_wrapper.py:240`) | `subprocess.run` internamente hace `SIGKILL` tras vencer el timeout (comportamiento estándar de la librería, sin señal explícita en el código) |
| Capturas preservadas | no aplica — el wrapper lanza excepción Python, no persiste `.out`/`.err` en disco | SÍ — `.out`/`.err` parciales quedan escritos en disco antes de que `subprocess.TimeoutExpired` se capture (`qp_delivery.py:143-144`) |

Qué ocurre cuando el SP tarda (Matriz): el wrapper espera hasta 30s por el marcador de fin; si no
llega, mata el proceso y lanza excepción — la conexión persistente se pierde y (según los puntos
citados en §5) el código reconecta automáticamente para continuar con el resto de la corrida.

Qué ocurre cuando un SELECT ad hoc tarda (Query Plan): `subprocess.run` espera hasta el timeout
configurado (120s en la corrida real de QP-CF-10) y luego mata el proceso; no hay reconexión ni
reintento — el paquete/QP se marca en timeout y el pipeline se detiene (regla explícita de la fase, no
del código: el código SÍ podría reintentar si se le pidiera, pero está deliberadamente prohibido).

## 15. Evidencia TC05

Extracto sanitizado (sin `Firma`/identificaciones/cuerpos REST/gRPC completos):

```
TC: TC05
cuenta: 0000601864
veredicto: EQUIVALENTE
query de discovery: SELECT (SELECT COUNT(1) FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco =
  '0000601864') AS existe_aho_activa, (SELECT COUNT(1) FROM firmas..fi_candidata WHERE
  ca_producto = 'AHO' AND ca_cuenta = '0000601864') AS firmantes_aho_pre
resultado_discovery (data_discovery.json): {"existe_aho_activa": 1, "firmantes_aho_pre": 1}
comando SP (sin datos de salida): DECLARE @return_code int / EXEC @return_code =
  firmas..pa_fir_consulta_firmante @e_cta_banco='0000601864' / SELECT @return_code as return_code
pasada_sp.return_code (QA-CASOS-PARSEADOS.json): 0
servidor lógico: sybasedvp1 (mismo alias que Query Plan, confirmado por comparación de variable de
  entorno sin exposición del valor)
fecha: carpeta de resultados "pa_fir_consulta_firmante-04-08-2026-2136"
```

**Respuestas directas**:

- **¿Está demostrado que el SELECT sobre `ah_cuenta` fue ejecutado?** Sí, en la fase de discovery
  (`discover_data.py`), con evidencia de RESULTADO REAL almacenado (`existe_aho_activa: 1`), no solo
  presencia del campo en el JSON.
- **¿En qué fase?** Discovery (previo a la generación de payloads/casos), NO durante `execute_all.py`
  — el SELECT de discovery vive en `discovery_queries.json`/`data_discovery.json`, archivos
  independientes de la corrida final. Durante `execute_all.py`, el mismo SELECT aparece en
  `precondiciones_sql` de TC05 SIN alias de columna (`existe_aho_activa`/`firmantes_aho_pre` son
  alias, pero el SELECT completo es un solo statement con dos subconsultas escalares con alias) — hay
  que verificar si `execute_mutants_and_dynamic` lo clasifica como "con alias" (se ejecuta y se usa) o
  lo ignora; la subconsulta interna SÍ tiene alias de columna (`AS existe_aho_activa`), por lo que,
  según la regla de `execute_all.py:1376`, este SELECT específico probablemente SÍ se ejecuta y se usa
  durante la corrida final, no solo durante discovery — a diferencia de un SELECT de verificación
  puro sin alias.
- **¿Con qué cliente?** `SybaseTsqlConnection` (PTY persistente), el mismo en discovery y en
  `execute_all.py`.
- **¿Terminó correctamente?** Sí — el resultado quedó almacenado con valores reales (no error, no
  timeout) tanto en `data_discovery.json` como (probablemente) en la ejecución de precondiciones de
  la corrida final con veredicto `EQUIVALENTE`.

## 16. Diferencias encontradas

| ID | Diferencia | Evidencia | Riesgo de explicar timeout | Confianza |
|----|---|---|---|---|
| D1 | Cliente: PTY persistente (Matriz) vs proceso nuevo por consulta sin PTY (Query Plan) | `sybase_tsql_wrapper.py:32-41` vs `qp_delivery.py:136-137` | MEDIO | MEDIA |
| D2 | Terminación de batch: marcador sintético + `(1 row affected)` (Matriz) vs solo `go` explícito sin sincronización adicional (Query Plan) | `sybase_tsql_wrapper.py:71,98` vs payload QP-02 (§9) | MEDIO | MEDIA |
| D3 | Opciones de sesión: `set showplan on`+`set statistics io on` únicas en Query Plan, ausentes en Matriz | grep exhaustivo, §11 | MEDIO | BAJA (sin evidencia de que ASE se comporte distinto por estas opciones en este entorno) |
| D4 | SQL real distinto: `SELECT COUNT(1)` con subconsulta (discovery) vs `SELECT 1 ... WHERE` directo (Query Plan) vs `EXEC` de SP compilado | §10 | BAJO-MEDIO | MEDIA |
| D5 | Base inicial de login: con `-D` explícito (Matriz) vs sin `-D`, `use` como primer batch (Query Plan) | `sybase_tsql_wrapper.py:35` vs `qp_delivery.py:136` + payload QP-02 | BAJO | MEDIA (QP-01 usa la misma estructura `use`+`go` y SÍ completó, lo que reduce el riesgo de esta diferencia específica) |
| D6 | Timeout: 30s/90s (Matriz) vs 120s (Query Plan) | §14 | NO RELACIONADO | ALTA (un timeout MÁS LARGO no explica por qué Query Plan falla y Matriz no; si algo, favorecería a Query Plan) |
| D7 | Alias/host/puerto/TDS version | §7 | NO RELACIONADO | ALTA (idénticos, confirmado) |
| D8 | Usuario de conexión | mismas 3 env vars (`os.environ`) en ambos frentes | NO RELACIONADO | ALTA (mismo origen de credenciales, no hay evidencia de un segundo usuario) |
| D9 | stdout vacío (0 bytes) tras 120s en Query Plan, vs resultado real capturado en Matriz | `QP-CF-10` §11 vs `data_discovery.json` | ALTO (es el síntoma mismo, no una causa) | ALTA |

## 17. Hipótesis clasificadas

1. **Query Plan usa un cliente diferente.** → **CONFIRMADA_POR_CODIGO** (parcial): mismo binario
   `tsql`, pero Matriz usa un wrapper Python con PTY persistente; Query Plan usa `subprocess.run`
   directo sin PTY, un proceso por QP. Son mecanismos de cliente distintos aunque el ejecutable sea
   el mismo.
2. **Ambos usan `tsql`, pero con mecanismos distintos.** → **CONFIRMADA_POR_CODIGO** (§8, §12, §13).
3. **PTY persistente frente a pipe cambia el comportamiento.** → **POSIBLE** (no hay evidencia directa
   de que el PTY en sí sea la variable causal; es plausible dado que ASE/FreeTDS pueden comportarse
   distinto ante una sesión que se abre-cierra por consulta vs una que persiste).
4. **Query Plan no termina correctamente el batch.** → **NO_DETERMINABLE** (el payload es
   sintácticamente correcto y estructuralmente idéntico al de QP-01, que sí completó; sin visibilidad
   de qué recibió ASE realmente).
5. **Query Plan espera cierre de sesión que nunca llega.** → **NO_DETERMINABLE** (mecanismo posible
   dado que `subprocess.run` simplemente espera EOF/exit sin ningún mecanismo de sondeo activo, pero
   no hay evidencia de que esto sea lo que ocurre aquí específicamente).
6. **`showplan + statistics io` provoca la diferencia.** → **POSIBLE** (única diferencia de opciones
   de sesión identificada, pero sin evidencia de causalidad — QP-01 usa las MISMAS opciones sobre otra
   tabla y sí completó, lo que reduce la plausibilidad de esta hipótesis como causa única).
7. **La base inicial es diferente.** → **DESCARTADA_POR_CODIGO** (parcial): ambos resuelven a la
   misma base lógica de negocio para sus respectivas consultas (`firmas` para el SP, `cob_ahorros`
   para el SELECT directo de QP-02 — que es la base CORRECTA para `ah_cuenta`). El MECANISMO de
   establecer esa base sí difiere (`-D` en login vs `use` en primer batch), pero QP-01 usa el mismo
   mecanismo (`use cob_cuentas`) y completó — reduce el riesgo de esta hipótesis a BAJO.
8. **El alias o servidor son diferentes.** → **DESCARTADA_POR_CODIGO** (§7: mismo alias `sybasedvp1`,
   mismo host/puerto en `freetds.conf`, misma variable de entorno).
9. **El usuario es diferente.** → **DESCARTADA_POR_CODIGO** (mismas env vars leídas por ambos frentes,
   sin evidencia de un segundo usuario en ningún punto de código).
10. **El timeout pertenece al cliente y no al SQL.** → **POSIBLE** (no determinable sin instrumentación
    del lado del servidor; el síntoma — stdout 0 bytes incluso para los `set` de sesión previos al
    SELECT — es consistente con un cliente que nunca recibió respuesta de ASE a NINGÚN comando, lo cual
    apuntaría más a un problema de conexión/negociación que al SQL del SELECT en sí).
11. **stdout vacío se debe a buffering.** → **DESCARTADA_POR_CODIGO**: `run_live` usa `stdout=fo`
    (archivo abierto directamente, no `PIPE`), sin el problema de buffering de `_StreamReader` que
    causó el bug de QP-CF-8 (ese bug era exclusivo del mecanismo de `diagnose`, no de `run_live`).
12. **`execute_all` ejecuta únicamente el SP y no el SELECT directo.** → **DESCARTADA_POR_CODIGO**
    (parcial): `execute_all.py` sí ejecuta SELECTs de PRE/POST con alias de columna (§15) — no
    ejecuta EXCLUSIVAMENTE el EXEC del SP, aunque el SELECT específico de QP-02
    (`select 1 from cob_ahorros..ah_cuenta where ah_cta_banco=...`) no es idéntico al de discovery/
    precondición (que usa `COUNT(1)` con subconsulta).
13. **Discovery sí ejecutó el SELECT directo y terminó.** → **CONFIRMADA_POR_CODIGO** (§4, §15:
    resultado real `existe_aho_activa: 1` almacenado en `data_discovery.json`).
14. **La consulta Query Plan no coincide exactamente con la de discovery.** → **CONFIRMADA_POR_CODIGO**
    (§10: `SELECT COUNT(1)` con subconsulta anidada vs `SELECT 1 ... WHERE` directo — mismo filtro,
    forma distinta).
15. **La sesión Query Plan queda esperando input adicional.** → **NO_DETERMINABLE** (plausible dado el
    patrón de stdout=0 bytes, pero sin instrumentación de la sesión en vivo no se puede confirmar).

## 18. Prueba mínima recomendada (NO ejecutada en esta fase)

La auditoría respalda esta prueba mínima como la más informativa y de menor riesgo:

**Usar el wrapper PTY persistente de Matrices (`SybaseTsqlConnection`) para ejecutar el MISMO SQL
exacto de QP-02** (`select 1 from cob_ahorros..ah_cuenta where ah_cta_banco = '0000601864'`, sin
`showplan`/`statistics io`), fuera del pipeline Query Plan, en un script de prueba aislado y
explícitamente autorizado en una fase futura.

Justificación: esto aísla en un solo cambio la variable D1/D2 (cliente PTY persistente vs proceso por
consulta) manteniendo el mismo SQL exacto y la misma base (`cob_ahorros`), sin introducir aún
`showplan`/`statistics io` (variable D3) para no confundir dos hipótesis en la misma prueba. Si esta
prueba TERMINA correctamente con el wrapper PTY, la sospecha se concentra en el mecanismo de cliente
de Query Plan (D1/D2). Si TAMBIÉN falla con el wrapper PTY, la sospecha se desplaza hacia el lado del
servidor Sybase (contención/bloqueo/recurso específico de esa tabla en ese momento), reforzando
`SYBASE_SERVER_SIDE_STILL_PRIMARY` de fases anteriores. Como paso posterior (fase futura, no ahora),
se podría repetir la misma prueba agregando `showplan`+`statistics io` para aislar D3 de forma
independiente.

No se recomienda todavía la variante "Query Plan sin `showplan`/`statistics io`" como PRIMERA prueba,
porque no aísla la diferencia de cliente (D1/D2), que es la de mayor riesgo relativo según esta
auditoría.

## 19. Reporte creado

`.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-11-MATRIX-VS-QUERYPLAN-EXECUTOR-AUDIT.md`
(este archivo). Ningún otro archivo fue creado ni modificado.

## 20. Estado Git final

```
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
```
Índice vacío. Sin commit. Sin push. Sin modificaciones a Matrices (`sybase_tsql_wrapper.py`,
`execute_all.py`, `discover_data.py`, `run_qa.py`, `parse_test_cases.py`, agentes). Sin modificaciones
al pipeline Query Plan (`qp_delivery.py`, `qp_pipeline.py`, `qp_source_extract.py`, configs). Único
archivo nuevo: este reporte.

## 21. Siguiente paso permitido

Ninguna ejecución de Sybase está autorizada por esta fase. El siguiente paso permitido es que el
usuario autorice explícitamente, en una fase futura (QP-CF-12 o posterior), la prueba mínima descrita
en §18 — usando el wrapper PTY de Matrices para ejecutar el SQL exacto de QP-02 sin instrumentación
de plan/IO, para aislar si la diferencia de cliente (PTY persistente vs proceso por consulta) es la
variable que explica el timeout. Hasta entonces, ninguno de los dos frentes debe modificarse ni
ejecutarse.

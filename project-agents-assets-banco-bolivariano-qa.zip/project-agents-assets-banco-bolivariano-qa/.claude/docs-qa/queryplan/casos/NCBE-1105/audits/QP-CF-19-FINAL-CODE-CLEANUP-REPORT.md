# QP-CF-19 — Limpieza final de hallazgos menores antes del commit

## 1. Estado Git inicial

```
pwd:    /home/ssm-user/project-agents-assets-banco-bolivariano-qa
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2   (idéntico al baseline esperado)
status --short --branch: ## master...origin/master
diff --cached --name-only: (vacío)
ahead/behind @{u}: 0 0
```
Índice vacío. Sin `BLOCKED_REPOSITORY_STATE`.

## 2. Hallazgos tomados de QP-CF-18

Extraídos textualmente de `QP-CF-18-FINAL-DIFF-AUDIT-REPORT.md`, sección 4:

1. `qp_delivery.py::parse_sysprocesses_samples` — comentario cita una función inexistente
   (`parse_hostprocess_samples`); el mecanismo real es `parse_hostprocess_rows`/
   `correlate_by_hostprocess`.
2. `qp_delivery.py::start_target_session`/`stop_target_session` (variante sin handshake, de
   QP-CF-7) sin caller de producción tras el rediseño de QP-CF-8.
3. `qp_pipeline.py::_relativize_for_print` — hardcodea `/home/ssm-user/`.
4. `qp_source_extract.py::_relativize` — hardcodea `/home/ssm-user/`.

Fuera de alcance (confirmado, no tocado): `qp_pipeline.py::cmd_preflight` (`except Exception`),
preexistente en el HEAD baseline.

## 3. Variantes PTY auditadas

Para `start_target_session`/`stop_target_session`, confirmado antes de eliminar:
- **Definición**: única, en `qp_delivery.py` (líneas ~479/510 antes de esta fase).
- **Referencias directas**: 0 en `qp_pipeline.py`, 0 en cualquier otro módulo productivo.
- **Referencias mediante imports**: ninguna — no se exportan/importan desde otro módulo.
- **Referencias en tests**: 1 mención en `tests/test_qp_pipeline.py`
  (`test_diagnose_stops_only_its_own_child_process`), pero usada ÚNICAMENTE como delimitador de
  texto (`src.index("def stop_target_session(")`) para acotar un slice de código a inspeccionar —
  la función nunca se INVOCA en la prueba.
- **Referencias dinámicas**: 0 (`grep` de `getattr`/`globals()[` sobre el árbol `queryplan/`: sin
  coincidencias).
- **Contrato público**: nunca documentadas en `README.md`/`SKILL.md`/`agente-queryplan.md`.
- **Compatibilidad histórica**: código de QP-CF-7 (heurística de "sesión única"), reemplazado en su
  totalidad por las variantes `_with_handshake` en QP-CF-8 — nunca parte de un contrato externo
  o de un CLI expuesto.
- **Posible uso por CLI**: `qp_pipeline.py` no las referencia en ningún subcomando.

Los 5 criterios de eliminación segura (0 callers productivos, 0 callers de tests necesarios, 0
exposición pública, 0 uso dinámico, 0 compatibilidad requerida) se cumplen sin ambigüedad. Sin
`BLOCKED_DEAD_CODE_DECISION`.

## 4. Código eliminado o conservado

**Eliminado**: `start_target_session(payload_text, out_path, err_path, sybase_env)` y
`stop_target_session(proc, fo, fe, grace_seconds=2)` — 39 líneas en total, de `qp_delivery.py`.

**Conservado sin cambios**: `_terminate_process_only()` (helper compartido, SÍ tiene un caller
productivo real: `stop_target_session_with_handshake`), `start_target_session_with_handshake()`,
`stop_target_session_with_handshake()`, `finalize_target_session_capture()` — el único cambio en
estas tres últimas fue corregir sus docstrings para no citar las funciones eliminadas (ver §7,
consecuencia directa de la eliminación, no un hallazgo nuevo).

Limpieza posterior: sin imports huérfanos (`subprocess`/`time` siguen usados por el resto del
módulo), sin constantes exclusivas asociadas a eliminar. Ninguna prueba fue eliminada — la única
prueba afectada (`test_diagnose_stops_only_its_own_child_process`) se adaptó (ver §7), no se borró,
porque su propósito (verificar que `_terminate_process_only` nunca usa `os.kill`/`killall`/`pkill`)
sigue siendo relevante para el camino productivo real.

## 5. Comentario corregido

`qp_delivery.py::parse_sysprocesses_samples` — el comentario que citaba `parse_hostprocess_samples`
(inexistente) fue reescrito para describir el mecanismo real: `hostprocess` queda siempre `None` en
esta función porque la correlación por hostprocess usa una consulta explícita distinta
(`_HOSTPROCESS_PAYLOAD` + `parse_hostprocess_rows` + `correlate_by_hostprocess`), no la salida de
`sp_who`. Sin cambio de comportamiento — el código ejecutable de la función es idéntico.

## 6. Rutas absolutas corregidas

Ambas reemplazadas por resolución dinámica de la raíz del repo (patrón `_repo_root()`, walk-up
buscando `.git`, ya existente en `qp_pipeline.py` y ahora también añadido a `qp_source_extract.py`):

- `qp_pipeline.py::_relativize_for_print`: usa `_repo_root()` (ya definida en el módulo desde
  QP-CF-4) para recortar la raíz del repo de las rutas de log — sin cambio de comportamiento
  observable (produce la misma cadena relativa que antes en este entorno).
- `qp_source_extract.py::_relativize`: se añadió `_HERE`/`_repo_root()` al módulo (no existían
  antes) y se corrigió la función para recortar el directorio PADRE de la raíz del repo — los
  repos hermanos declarados por `repos_roots`/`sp_source_roots` en la cone-config viven un nivel
  arriba del repo de este pipeline, por lo que las rutas persistidas en el dossier de procedencia
  (`archivo_origen`, `sp_fuente`, `fuente_literales`) siguen usando ese directorio padre como base
  — verificado que produce byte-a-byte la MISMA cadena relativa que antes (`bb-core-firmas-utils/
  ...`, `cpas-mso-consulta-firmante/...`, `project-agents-assets-banco-bolivariano-qa/...`) para
  los 3 casos reales del dossier ya persistido.

**Verificación de no-regresión**: se re-ejecutó `qp_pipeline.py prepare` sobre el cono real
NCBE-1105 después del cambio — el `provenance-queryplan.json` resultante es **byte-idéntico**
(`sha256=3602969d75762bd9814e86da614227748bf65e889358b1e7647e3705dbd7f15f`, confirmado estable en
dos ejecuciones consecutivas) al que ya existía antes de esta fase.

**Defecto propio detectado y corregido durante la implementación**: el primer intento de docstring
para `_relativize()` mencionaba literalmente `bb-core-firmas-utils`/`cpas-mso-consulta-firmante`
como ejemplo — esto disparó 2 pruebas de guardia existentes
(`test_no_firmante_values_hardcoded_in_priority_logic`,
`test_no_hardcoded_case_names_in_source_extract_prepare_logic`), que correctamente detectan
hardcodes del caso Firmante en código genérico. Corregido reescribiendo el docstring en términos
genéricos (referenciando `repos_roots`/`sp_source_roots` de la cone-config en vez de nombrar los
repos reales) antes de continuar.

## 7. Paths modificados

```
.claude/docs-qa/inputs/scripts/queryplan/qp_delivery.py
.claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py
.claude/docs-qa/inputs/scripts/queryplan/qp_source_extract.py
.claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_pipeline.py
```
4 archivos — exactamente los que contienen los 4 hallazgos y la única prueba directamente afectada.
Ningún otro archivo fue tocado (confirmado: `qp_capture_sanitize.py`, `qp_tsql_pty.py`,
`config/cones/NCBE-1105.json`, `literal-sources.json`, `provenance-queryplan.json` de análisis, la
entrega, los reportes QP-CF-4 a QP-CF-18, Matrices y repos de negocio permanecen con SHA-256
idéntico al de antes de esta fase — verificado explícitamente, ver §10/§14).

## 8. Pruebas

Prueba adaptada (no eliminada): `test_diagnose_stops_only_its_own_child_process` — su delimitador
de slice de código pasó de `"def stop_target_session("` (ya eliminada) a
`"def stop_target_session_with_handshake("` (única variante productiva restante); la aserción en sí
(`"os.kill" not in body and "killall" not in body and "pkill" not in body`) permanece sin cambios,
ahora acotando exactamente el cuerpo de `_terminate_process_only` (el helper realmente compartido
por el camino productivo). No se agregaron pruebas nuevas — no fue necesario: la cobertura del
camino PTY productivo (`_with_handshake`, `run_live`→`qp_tsql_pty`) ya estaba cubierta por las
pruebas de QP-CF-8/13, ninguna de las cuales referenciaba las funciones eliminadas.

## 9. Suite completa

```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 78 passed, 0 failed
test_qp_pipeline.py     : 172 passed, 0 failed
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 314 passed, 0 failed
```
Idéntico al baseline (314/0) — mismo total exacto, 0 pruebas eliminadas, 0 pruebas nuevas (la
adaptación de §8 no cambia el conteo). Re-ejecutado 2 veces adicionales para confirmar estabilidad:
sin variación. Sin `FINAL_CLEANUP_TEST_FAILURE`.

## 10. Escaneo estático

```
/home/ssm-user en logica productiva (qp_delivery.py/qp_pipeline.py/qp_source_extract.py/
  tests/test_qp_pipeline.py): 0 coincidencias
/Users/: 0 coincidencias
/tmp/ hardcoded en logica productiva: 0 coincidencias
subprocess.run del runner anterior dentro de run_live(): 0 (la unica mencion es el docstring
  comparativo, ya presente desde QP-CF-13, sin cambios)
imports del frente Matrices: 0 coincidencias
funciones PTY sin referencias (start_target_session/stop_target_session): 0 definiciones
  (confirmado eliminadas)
TODO/FIXME introducidos: 0 (los 2 "TODO"/"todo" encontrados son la palabra espanola "todo"
  ["...detiene TODO el paquete", "...NUNCA el valor de campos sensibles... TODO como metadata..."],
  preexistentes, no marcadores de tarea pendiente)
debug prints: 0 (todos los print() presentes son salida de estado de CLI intencional, ya existente)
```
Sin `FINAL_CLEANUP_SCOPE_DRIFT`.

## 11. Entrega byte-idéntica

```
manifest-consolidado-queryplan.json: sha256=c03c17c7b7b85de4ff716d3df1972d01b370efdd619deb38ec50416950a7eec9 (sin cambios)
zips/pa_fir_consulta_firmante-queryplan.zip: sha256=e1127e17da4a094bff2233d0bd188ec9753f4140ceded9bdfcc6ae670263b99a
```
ZIP idéntico al hash registrado en QP-CF-17/QP-CF-18. 2 archivos exactos en la entrega (sin nuevos).
No se regeneró, no se abrió ninguna captura sensible. Sin `DELIVERY_HASH_CHANGED`.

## 12. Seguridad

Escaneo sobre los 4 archivos modificados por esta fase: 0 coincidencias de `SYBASE_PASS` real
(verificado con `grep -F -q`, comparación booleana), 0 rutas absolutas de entorno en lógica
productiva, 0 tokens/datos personales/firmas/blobs introducidos. Sin `FINAL_SECURITY_AUDIT_FAILURE`.

## 13. Residuos sensibles ausentes

Confirmado que los dos archivos remediados en QP-CF-18 permanecen ausentes:
```
/tmp/.qpcf15_detalle.tmp        -> No such file or directory (confirmado)
/tmp/.qpcf17_real_values.txt    -> No such file or directory (confirmado)
```
No se inspeccionó ni reconstruyó su contenido. No se eliminó ningún otro archivo en esta fase.

## 14. Diff final

Solo los 4 hallazgos fueron resueltos: comentario corregido (1), código PTY muerto eliminado (1,
con sus 2 docstrings dependientes corregidos como consecuencia directa), 2 rutas absolutas
corregidas (1 por archivo). Sin refactor adicional. Sin cambio funcional en la generación de
entrega (confirmado por §11: ZIP/consolidado byte-idénticos). Sin cambio de configuración
(`config/cones/NCBE-1105.json`/`literal-sources.json` con SHA-256 idéntico, verificado). Sin cambio
de artefactos ya generados. Sin cambios ajenos (Matrices y repos de negocio con SHA-256 idéntico a
fases previas, verificado explícitamente).

Paths exactos modificados (repetido de §7 para completitud de esta sección):
```
.claude/docs-qa/inputs/scripts/queryplan/qp_delivery.py       (sha256=676d0f2a700e933153c074983871c96708a1ad28feeba8ab6e4699eacf34718a)
.claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py       (sha256=1e93f8b6d28d9ad99c81ecdb03c91b9726f5c10dbb74068beb0077ac834abca0)
.claude/docs-qa/inputs/scripts/queryplan/qp_source_extract.py (sha256=4ced1e2ec922670c536bafcf9603ee7f7271386dc651babf1dcbdbc8b4100508)
.claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_pipeline.py (sha256=bf08912cb3bab680f08465d89fb954034fa86aec6217255d59051353e04dbfc2)
```

## 15. Veredicto

**`READY_FOR_SCOPED_COMMIT_CLEAN`**

Los cuatro hallazgos quedan resueltos; no se cambió funcionalidad (comportamiento observable
idéntico, verificado por hash del dossier de procedencia real y por la suite completa); no se
modificó la entrega (ZIP/consolidado byte-idénticos); las 314 pruebas pasan; no existen rutas
absolutas de entorno en código productivo; no queda el código PTY muerto identificado por QP-CF-18;
no existen secretos ni datos personales; el índice permanece vacío.

## 16. Estado Git final

```
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
```
Índice vacío. Sin commit. Sin push. Sin ejecución de Sybase (solo `prepare`, que no conecta).
Sin regeneración de la entrega. Entrega intacta. Matrices intactas (SHA-256 idénticos). Repositorios
de negocio intactos (HEAD/tree idénticos). Agentes intactos (`agente-queryplan.md` sin
modificaciones en esta fase).

## 17. Siguiente paso permitido

El frente Query Plan de Consulta Firmante queda listo para el commit real en dos partes propuesto
por QP-CF-18 (con los 4 archivos de esta fase ya incorporados a las listas de Commit 1), sujeto a
autorización explícita del usuario para ejecutar `git add`/`git commit` — no ejecutado en esta
fase. El push a un remoto requiere autorización adicional e independiente, posterior al commit.

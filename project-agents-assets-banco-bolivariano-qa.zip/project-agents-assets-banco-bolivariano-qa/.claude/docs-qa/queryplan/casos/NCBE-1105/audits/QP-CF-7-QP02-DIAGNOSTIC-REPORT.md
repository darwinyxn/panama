# QP-CF-7 — Diagnóstico controlado del timeout persistente de QP-02

## Baseline

```
Repo -qa:  HEAD 0b27d19521ff5cdd8d6a7074b97c70aae77a57a2, índice vacío, ahead/behind 0 0
Librería:  HEAD 1745fb27bc037a43d4ce440c4324d9a66f1417de
           tree pa-fir-consulta-firmante-utils 680a765f938ea108e42b12cf1a804cf4e85b0bf7
           subárbol limpio
```
Sin cambios respecto a QP-CF-6. Sin `BLOCKED_SOURCE_BASELINE_CHANGED`.

## Evidencia histórica (QP-CF-5 / QP-CF-6, preservada sin modificar)

| Intento | Timeout | QP-01 | QP-02 stdout | QP-02 stderr | SHA-256 QP-02.err |
|---|---:|---|---|---|---|
| QP-CF-5 | 120s | Completó (plan+IO) | vacío (0 bytes) | 283 bytes, informativo | `fdb38c9fcf12117b9be1237aeaad6cd28ebfd282df3a47160aeb730977c64def` |
| QP-CF-6 | 300s | Completó (plan+IO, hash idéntico a QP-CF-5) | vacío (0 bytes) | 283 bytes, informativo | `fdb38c9fcf12117b9be1237aeaad6cd28ebfd282df3a47160aeb730977c64def` |

Ambos stagings (`/tmp/NCBE-1105-queryplan-live-20260807T003136Z` y
`/tmp/NCBE-1105-queryplan-live-20260807T022949Z`) permanecen intactos, no se eliminaron ni
modificaron.

## Diseño del diagnóstico

Nuevo subcomando `qp_pipeline.py diagnose --cone-config <cone> --evidence-root <staging> --package
<pkg> --qid <qid> --output <diag-root> [--sample-interval-seconds N] [--max-observation-seconds N]
[--diagnostic-timeout-seconds N]`. Genérico: `package`/`qid` son argumentos, cero hardcodes de
`NCBE-1105`/`pa_fir_consulta_firmante`/`QP-02`/`ah_cuenta`/el literal (verificado por test dedicado).

Implementado en `qp_delivery.py` (funciones reutilizables) y `qp_pipeline.py` (`cmd_diagnose`,
orquestación):

- **Modo A (compile-only)**: `build_compile_only_payload()` construye `use <db> / set showplan on /
  set noexec on / <SELECT> / set noexec off`; se ejecuta vía `_run_tsql_diagnostic()` (mismo
  hardening que `run_live`: timeout explícito, sin comando/credenciales en la excepción). Clasifica
  en `COMPILE_ONLY_PLAN_AVAILABLE` / `_UNSUPPORTED` / `_TIMEOUT` / `_ERROR`.
- **Modo B (sesión objetivo)**: `start_target_session()` lanza el SELECT real como `Popen` **propio**
  (no bloqueante), permitiendo observarla mientras corre. `stop_target_session()` detiene
  **exclusivamente** ese proceso (SIGTERM → espera → SIGKILL si no responde) — nunca ninguna sesión
  externa (verificado: `os.kill`/`killall`/`pkill` ausentes del cuerpo de la función).
- **Modo C (muestreo)**: cada `--sample-interval-seconds` (mínimo 5, validado) se ejecuta `sp_who` vía
  el mismo mecanismo seguro, se parsea con `parse_sysprocesses_samples()` (solo campos `spid`,
  `status`, `blk` — nunca `cmd`/SQL de otras sesiones) y se filtra al SPID objetivo. Ventana máxima
  `--max-observation-seconds` (default 60); al cerrar, se detiene el proceso B.

`is_select_only()` rechaza `INSERT/UPDATE/DELETE/MERGE/TRUNCATE/DROP/ALTER/CREATE/EXEC/EXECUTE` antes
de cualquier conexión — confirmado por test que `diagnose` nunca conecta a Sybase si el QP no es
SELECT-only.

## Pruebas

13 pruebas nuevas en `test_qp_pipeline.py`, todas sin Sybase real (script `tsql` falso local que
responde según el contenido del batch recibido — `sp_who`, `noexec`, o sesión real — y opcionalmente
duerme para simular colgado):

1. Rechaza QP no-SELECT (código dedicado, sin generar `diagnostic-summary.json`).
2/3. No toca otros QP del mismo paquete; solo el solicitado.
4. Captura y conserva el SPID objetivo cuando la correlación es inequívoca.
5. Correlaciona un bloqueador simulado (2+ muestras) → `BLOCKING_CONFIRMED`.
6. Con múltiples sesiones activas simultáneas (ambiguo), `target_spid` queda `None` — nunca
   reporta ni el SPID ni el comando de la sesión ajena.
7/8. `stop_target_session` no contiene ningún mecanismo de matar procesos externos.
9. Ninguna credencial persiste en ningún archivo de salida (escaneo byte-exacto).
10. Timeout de los diagnósticos internos (compile-only/sp_who) nunca genera manifest/ZIP/entrega.
11. `compile_only_status` y `samples` son campos distintos con contratos distintos.
12. Intervalo de muestreo por debajo de 5s → `SystemExit`.
13. Con `max_observation=10, interval=5`: nunca más de `10//5 + 1` muestras.
14. Cono sintético (`pkg_diag`) sin ningún nombre del caso real.
15. Cero hardcodes de `NCBE-1105`/`pa_fir_consulta_firmante`/`QP-02`/`ah_cuenta`/nombres de clase en
    `qp_pipeline.py`/`qp_delivery.py`.

Resultado de las 4 suites:

```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 78 passed, 0 failed
test_qp_pipeline.py     : 95 passed, 0 failed   (82 previas + 13 nuevas)
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 237 passed, 0 failed   (13 mas que las 224 previas)
```

## Preflight

`PREFLIGHT_OK`.

## Compile-only

Único diagnóstico ejecutado (una vez): `compile-only: COMPILE_ONLY_PLAN_AVAILABLE`. El motor ASE
**pudo compilar y planificar** la consulta sin ejecutarla — `analyze_capture` confirma
`plan_present=True`, `high_sev=[]` (cero errores reales). Las etiquetas informativas derivadas
(`labels_raw_informational_from_output`, genérico, sin exponer SQL/datos) muestran `Forward Scan` +
`Positioning by key` — **acceso por índice, no un full table scan**. `labels_raw` (criterio A,
disparadores de observación) quedó vacío: ningún `Table Scan`/`Index Scan` sin key/`Cartesian
Product`/`Using Worktable` detectado en el plan compilado.

Hashes (evidencia, sin contenido crudo en este reporte):
```
compile-only.out: d9c29349d454d3d8eae1ebda364fa09e3b3d9a969cad9e0dc2478799c5ed841e
compile-only.err: b0f5152923649e05433ffc1e392842baa5e2a75a0add1f21186ca125a0715921
```

## Sesión objetivo

`target_spid`: **no correlacionado (`None`)**. La muestra `sp_who` de la primera observación devolvió
91 filas candidatas (patrón numérico inicial) — es decir, múltiples sesiones activas simultáneas en
el servidor compartido en ese instante. La heurística de localización exige **exactamente una** fila
en estado distinto de `sleeping` para asignar `target_spid` sin ambigüedad; con múltiples candidatas
activas, quedó deliberadamente sin asignar — comportamiento de seguridad intencional (nunca asumir
ni reportar la sesión de otro usuario).

La sesión objetivo (el SELECT real, proceso hijo B) permaneció activa durante toda la ventana de 60s
sin producir plan ni IO (`target-session.out`: 0 bytes; `target-session.err`: 283 bytes, solo
mensajes informativos severity 10). El SHA-256 de `target-session.err` es idéntico byte a byte a
los `.err` de QP-CF-5 (timeout 120s) y QP-CF-6 (timeout 300s).

**[CORREGIDO en QP-CF-8]** La sesión ASE objetivo no fue correlacionada con un `spid` verificable en
esta corrida — la heurística usada aquí no permitía una identificación inequívoca. Esto significa que
no hay evidencia directa que permita afirmar ni descartar bloqueo, ni afirmar ni descartar un
problema de cliente/transporte: la ausencia de correlación es en sí misma el límite de esta evidencia,
no una conclusión sobre la causa.

## Muestras de ejecución

6 muestras (`sample-interval=10s`, `max-observation=60s`), todas con `target_present=false` (por la
ambigüedad de correlación de SPID descrita arriba) y `timed_out=false` en cada una — `sp_who` en sí
respondió con normalidad en cada muestra, sin timeout ni error.

## Bloqueos detectados

Ninguno reportable: sin `target_spid` correlacionado, no se puede confirmar ni descartar un
bloqueador específico con la evidencia disponible en este ambiente compartido.

## Plan observado

`Forward Scan` + `Positioning by key` (acceso por índice sobre la tabla consultada) — sin `Table
Scan`, sin `Cartesian Product`, sin `Using Worktable`. El plan en sí no es costoso ni sugiere un
acceso ineficiente.

## Clasificación

**`INSUFFICIENT_DIAGNOSTIC_EVIDENCE`**

Justificación exacta según las reglas de la fase: ninguna categoría de esta versión del esquema de
clasificación tiene evidencia directa suficiente para aplicarse con responsabilidad. No hay
bloqueador correlacionado (falta el SPID objetivo verificable, condición requerida para
`BLOCKING_CONFIRMED`). El plan compile-only está disponible y muestra acceso por índice, sin
`Table Scan`/worktable — dato observado, no una conclusión sobre la causa del timeout de la
ejecución real. El proceso cliente (proceso hijo B) permaneció activo hasta el cierre de la ventana,
pero esto por sí solo no permite confirmar ni descartar un problema de transporte a nivel de servidor,
porque no hubo correlación de SPID que permitiera observar la sesión ASE directamente. Sin un SPID
objetivo confirmado, ninguna categoría que dependa de metadata de sesión puede aplicarse de forma
responsable.

## Limitaciones

1. **Ambiente Sybase compartido con múltiples sesiones activas simultáneas** impidió correlacionar
   sin ambigüedad el SPID de la sesión objetivo mediante la heurística conservadora implementada
   (deliberadamente diseñada para nunca asumir ni exponer la sesión de otro usuario).
2. Los permisos disponibles no fueron probados para `sp_lock`/`master..syslocks` de forma directa en
   esta corrida (el mecanismo A implementado usa `sp_who`, disponible sin permisos elevados
   adicionales confirmados; una extensión futura podría intentar `sp_lock` si los permisos lo
   permiten, pero eso no se ejecutó en esta fase para no exceder el alcance de "mecanismo mínimo
   disponible").
3. El plan compile-only, aunque disponible y sin acceso costoso aparente, **no garantiza** que el
   plan de ejecución real (con estadísticas y bloqueos en tiempo de ejecución) sea idéntico —
   compile-only es deliberadamente una aproximación, no evidencia entregable.

## Recomendación

**[CORREGIDO en QP-CF-8]** Lo que la evidencia disponible permite afirmar, sin extrapolar más allá de
lo observado:

- QP-02 presenta un timeout persistente y reproducible (mismo hash de `.err` en tres corridas
  independientes con timeouts distintos: 120s, 300s y una ventana diagnóstica de 60s).
- El plan compile-only muestra acceso por índice (`Forward Scan` + `Positioning by key`), sin
  evidencia de `Table Scan` ni worktable.
- La sesión ASE objetivo no fue correlacionada con un `spid` verificable en esta corrida.
- La causa de la espera permanece sin determinar.

Se recomienda una fase futura, explícitamente autorizada, que implemente una correlación
determinista de SPID (no basada en "exactamente una sesión activa") para poder observar
específicamente la sesión objetivo y así determinar la causa real de la espera.

## Veredicto

**QP02_INSUFFICIENT_DIAGNOSTIC_EVIDENCE**

**Nota de corrección (QP-CF-8):** las secciones "Sesión objetivo" y "Recomendación" de este reporte
fueron corregidas en QP-CF-8 para eliminar conclusiones no sostenidas por la evidencia directa
("bloqueo descartado", "transporte descartado", "contención específica" como hipótesis afirmada).
El veredicto original `QP02_INSUFFICIENT_DIAGNOSTIC_EVIDENCE` se mantiene sin cambios — la corrección
es únicamente de lenguaje/alcance de las conclusiones, no del resultado del diagnóstico.

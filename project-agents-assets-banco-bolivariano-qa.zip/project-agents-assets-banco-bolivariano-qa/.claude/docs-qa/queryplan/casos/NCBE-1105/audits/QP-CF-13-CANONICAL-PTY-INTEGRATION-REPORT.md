# QP-CF-13 — Integración canónica del ejecutor PTY en Query Plan

## 1. Estado Git inicial

```
pwd:    /home/ssm-user/project-agents-assets-banco-bolivariano-qa
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
status --short --branch: ## master...origin/master
diff --cached --name-only: (vacío)
ahead/behind @{u}: 0 0
```
Índice vacío. Sin `BLOCKED_REPOSITORY_STATE`.

## 2. Evidencia QP-CF-12

Mismo payload byte-idéntico a QP-CF-10 (`payload_sha256=b5600baa3e...e282`), mismo literal
(`0000601864`), mismas opciones (`showplan`/`statistics io`), mismo servidor (`sybasedvp1`), mismo
timeout (120s). Resultado: `TIMEOUT` a 120.001s vía `subprocess.run`+pipe (QP-CF-10) vs. `PASS` en
1.06s vía sesión `tsql` persistente sobre PTY (QP-CF-12) — plan presente, Statistics IO presente
(`cob_ahorros..ah_cuenta`: 3 lecturas lógicas, 0 físicas), sin `severity>=11`. Única variable
modificada: mecanismo de cliente.

## 3. Contrato anterior de `D.run_live()`

Auditado antes de implementar (`qp_delivery.py` previo a esta fase, `qp_pipeline.py`,
`tests/test_qp_pipeline.py`; NO existe `tests/test_qp_delivery.py` en el repo — `qp_delivery.py` se
prueba enteramente desde `test_qp_pipeline.py`):

- `D.run_live(payload_text, qid, live_stg, sybase_env, timeout_seconds)` → dict con
  `payload_sha256`/`stdout_sha256`/`stderr_sha256`/`exit_code`/`norm_output`/`plan_present`/
  `io_tables`/`high_sev`.
- `_require_complete_capture(qid, live)` exige los 3 hashes y `exit_code==0`; lanza
  `LiveCaptureError` si no.
- `QueryPlanExecutionTimeout(qid, timeout_seconds, stdout_path, stderr_path, payload_sha256)`: única
  excepción pública de timeout, `raise ... from None` obligatorio.
- Archivos `.out`/`.err` deben EXISTIR siempre (aunque vacíos) tras `run_live()`, en
  `<live_stg>/<qid>.{out,err}`.
- `analyze_capture(pb, ob, eb, exit_code)` — combinaba `err_text + ob` para `norm_output`/
  `plan_present`/`io_tables`, pero `high_sev` escaneaba SOLO `eb` (defecto latente: nunca se
  manifestó porque el camino anterior por pipe efectivamente separaba stdout/stderr reales de
  `tsql`; con PTY, ambos streams se combinan en un solo canal — ver §7).
- Consumidores confirmados: `qp_pipeline.py::_generate()` (fase 1 live, fase 2 `load_capture`),
  `qp_pipeline.py::_run_execution_only()` (QP-CF-9/10), `cmd_diagnose` (usa mecanismos propios,
  NO `run_live`).

## 4. Diseño implementado

Nuevo módulo `qp_tsql_pty.py` (`run_pty_session()`), integrado en `D.run_live()` REEMPLAZANDO el
cuerpo de `subprocess.run`+pipe — sin runner paralelo, sin fallback automático al pipe. Capacidades:
sesión `tsql` única sobre PTY (`pty.openpty()`), envío del payload completo + batch propio del
marcador (con `showplan off`/`statistics io off` primero, para que el SELECT sintético del marcador
NUNCA herede las opciones de plan/IO del payload de negocio — ver defecto corregido en §15), lectura
no bloqueante (`select.select`) con reloj MONOTÓNICO (`time.monotonic()`, nunca wall-clock),
confirmación del marcador por valor único + `(1 row affected)`, terminación determinista
(`_kill_process`: `SIGTERM`→`wait`→`SIGKILL` si no cede), cierre de descriptores en `finally` sin
excepción, cero reintentos, cero consultas adicionales fuera del batch de marcador.

## 5. Independencia frente a Matrices

Ninguno de `qp_delivery.py`/`qp_pipeline.py`/`qp_tsql_pty.py` importa `sybase_tsql_wrapper`
(`SybaseTsqlConnection`), ni referencia en runtime `execute_all.py`/`discover_data.py`/rutas
`scripts/auto/` — verificado por prueba estática (`test_queryplan_does_not_import_matrix_wrapper`,
`test_queryplan_does_not_depend_on_matrix_runtime_paths`). `qp_tsql_pty.py` solo importa de la
librería estándar (`hashlib`, `os`, `pty`, `select`, `subprocess`, `time`, `uuid`) — verificado por
AST (`test_qp_tsql_pty_has_no_third_party_imports`). El wrapper de Matrices se usó ÚNICAMENTE como
referencia de comportamiento en QP-CF-11/QP-CF-12 (lectura), nunca como dependencia de código.
`sybase_tsql_wrapper.py`/`execute_all.py`/`discover_data.py` permanecen con SHA-256 idéntico al
registrado en QP-CF-11.

## 6. Archivos modificados

```
NUEVO: .claude/docs-qa/inputs/scripts/queryplan/qp_tsql_pty.py
MOD:   .claude/docs-qa/inputs/scripts/queryplan/qp_delivery.py    (run_live -> PTY.run_pty_session;
                                                                    analyze_capture: high_sev escanea
                                                                    combined, no solo eb)
MOD:   .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_pipeline.py (+27 pruebas nuevas)
```
Sin cambios a Matrices, repositorios de negocio, agentes de otros frentes, schemas no relacionados,
`config/cones/NCBE-1105.json`, `literal-sources.json`, la matriz original.

## 7. Contrato de capturas (actualizado)

PTY combina stdout+stderr en un solo canal — no se finge separación técnica que no existe:

- `.out`: transcripción de sesión sanitizada (marcador y su alias de columna `_qp_marker` removidos),
  incluye Query Plan, Statistics IO y CUALQUIER mensaje SQL, incluidos errores `severity>=11`.
- `.err`: EXCLUSIVAMENTE errores del propio ejecutor (la sesión terminó sin confirmar el marcador,
  antes del timeout — fallo de protocolo/conexión). Vacío en el camino exitoso.
- `analyze_capture()` fue ajustado (§3) para que `high_sev` escanee el texto COMBINADO (`err+out`),
  no solo `eb` — así un error real que aparezca íntegramente en `.out` (como ocurre siempre en el
  camino PTY) sigue siendo detectado por los validadores de severity existentes, sin perder
  compatibilidad con el camino histórico (donde `eb` real también queda dentro de `combined`).

## 8. Marcador de finalización

Único por ejecución: `build_marker(payload_bytes, nonce=uuid.uuid4())` — hash truncado del payload +
nonce aleatorio, nunca un valor fijo, nunca coincide con datos de negocio. `sanitize_session_text()`
elimina tanto el VALOR único del marcador como su alias de columna fijo `_qp_marker` (defecto
corregido en implementación, ver §15) — ninguno de los dos llega a la entrega. Metadata registrada:
`marker_detected` (bool) y `capture_mode="pty_combined"` en el dict que devuelve `run_live()`.

## 9. Pruebas

27 pruebas nuevas en `test_qp_pipeline.py`, cubriendo: sesión exitosa (conexión/envío/marcador/
cierre/exit code), plan+IO compatibles con parsers existentes, error SQL `severity>=11` detectado en
salida combinada, timeout exacto (excepción/descriptores/salida parcial/sin reintentos), marcador
(único por ejecución, ausente/parcial/duplicado, eliminado de la captura final incluyendo su alias
de columna), seguridad (secreto ausente en excepción/stdout/stderr/metadata, sin impresión de argv
sensible), ciclo de vida (conexión única, un payload, cleanup en `finally`), e independencia (sin
imports/dependencias runtime hacia Matrices, solo stdlib).

## 10. Total de pruebas

```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 78 passed, 0 failed
test_qp_pipeline.py     : 154 passed, 0 failed   (vs. 153 en QP-CF-12: 127 pipeline-only)
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 296 passed, 0 failed   (vs. 270 en QP-CF-12; gate ">270" superado)
```

## 11. Seguridad

Mantenidas todas las protecciones de QP-CF-6: `raise ... from None` en la excepción de timeout,
nunca se construye ni imprime el comando/argv real con `-P <password>`. Pruebas específicas buscan
`_FAKE_PWD` en: excepción (`str(e)`), `out_bytes`/`err_bytes`, JSON de metadata (`json.dumps(rec)`),
archivos `.out`/`.err` en disco. Verificación estática adicional
(`test_pty_module_never_logs_argv_with_password`) confirma que ninguna línea de `qp_tsql_pty.py` que
mencione `sybase_env`/`pwd` contiene `print(`/`log(`. Ejecución real: escaneo de credenciales sobre
toda la evidencia de la revalidación (§14) con `0` coincidencias.

## 12. Prepare

Staging fresco bajo `/tmp/NCBE-1105-QP-CF-13-canonical-<RUN_ID>/`. `prepare` canónico:
`PIPELINE_PROVENANCE_READY_PREPARE_READY`, 5/5 payloads, 0 bloqueados, 0 placeholders, 0 DML, 0
secretos.

## 13. Payload QP-02

```sql
use cob_ahorros
go
set statistics io on
set showplan on
go
select 1 from cob_ahorros..ah_cuenta where ah_cta_banco = '0000601864'
go
```
`payload_sha256 = b5600baa3e32fe2457f14434da8bda67a7560e0d048f1391705ba5f8435ae282` — idéntico a
QP-CF-10/QP-CF-12 (sin cambios, `prepare` sigue siendo determinista).

## 14. Preflight

`PREFLIGHT_OK`.

## 15. Ejecución aislada canónica

```
qp_pipeline.py run --cone-config config/cones/NCBE-1105.json --evidence-root <staging> \
  --package pa_fir_consulta_firmante --qid QP-02 --execution-only --timeout-seconds 120
```
Camino confirmado: `qp_pipeline.py run` → `_run_execution_only()` → `D.run_live()` →
`qp_tsql_pty.run_pty_session()`. Sin script temporal de QP-CF-12, sin wrapper de Matrices, sin `tsql`
manual, sin `diagnose`, sin handshake, sin `@@spid`, sin SP completo, sin otros QP. Una conexión, un
payload, un intento, cero retries.

**Defecto encontrado y corregido durante la implementación** (primer intento de ejecución, antes de
consolidar esta fase): el batch del marcador heredaba `showplan`/`statistics io` (seguían activos
desde el payload de negocio), generando un segundo bloque de plan espurio en la captura — ruido, no
un error funcional, pero contrario al contrato de captura limpia. Corregido enviando
`set showplan off`/`set statistics io off` en el PROPIO batch del marcador, antes del `SELECT`
sintético — el SQL de negocio del payload nunca se modifica. Verificado que el plan/IO real del
payload permanece intacto (`qp_normalize.prune_aux_plans` ya elimina el plan auxiliar de esos `SET`,
mecanismo preexistente, sin cambios). Un segundo defecto menor (el alias de columna fijo
`_qp_marker` sobrevivía a `sanitize_session_text`, aunque el VALOR único del marcador sí se
eliminaba) también se corrigió antes de la ejecución final registrada en este reporte.

## 16. Duración

**0.951 segundos.**

## 17. Query Plan

**Presente.** `QUERY PLAN FOR STATEMENT`/`STEP 1` real, acceso por índice clusterizado
(`ah_cuenta_Key`, `Forward Scan`, `Positioning by key`) sobre `cob_ahorros..ah_cuenta`.

## 18. Statistics IO

**Presente.** `Table: cob_ahorros..ah_cuenta scan count 1, logical reads: (regular=3 apf=0 total=3),
physical reads: (regular=0 apf=0 total=0)`.

## 19. Comparación histórica

| Fase | Mecanismo | Resultado | Duración |
|---|---|---|---|
| QP-CF-10 | `subprocess.run`+pipe (camino canónico anterior) | `EXECUTION_ONLY_RUN_TIMEOUT` | 120.001s |
| QP-CF-12 | Script temporal + wrapper PTY de Matrices (prueba A/B, no productivo) | `PTY_QUERYPLAN_PAYLOAD_PASS` | 1.06s |
| QP-CF-13 | `run --execution-only` → `D.run_live()` → `qp_tsql_pty` (camino canónico NUEVO) | `EXECUTION_ONLY_RUN_PASS` | 0.951s |

El camino canónico integrado reproduce el mismo resultado exitoso que la prueba A/B, sin depender de
Matrices ni de scripts temporales — Query Plan ahora tiene su propio ejecutor PTY autónomo.

## 20. Veredicto

**`QP02_CANONICAL_PTY_PASS`**

El comando canónico ejecutó QP-02; `D.run_live()` usó el nuevo ejecutor PTY; terminó en 0.951s (<
120s); marcador detectado; Query Plan presente; Statistics IO presente; `severity>=11` ausente;
capturas completas; cero credenciales; no se ejecutaron otros QP.

## 21. Siguiente paso permitido

No se ejecutó el cono completo ni se generó manifest/consolidado/README/ZIP en esta fase — eso
requiere autorización explícita en una fase futura (QP-CF-14 o posterior), que además debería
validar QP-01/QP-03/QP-04/QP-05 con el mismo ejecutor PTY antes de considerar una entrega completa.

## 22. Reporte creado

`.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-13-CANONICAL-PTY-INTEGRATION-REPORT.md` (este
archivo). Ningún otro archivo de reporte fue creado.

## 23. Estado Git final

```
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
```
Índice vacío. Sin commit. Sin push. Matrices sin modificaciones (SHA-256 idénticos a QP-CF-11/12).
Repositorios de negocio intactos (`bb-core-firmas-utils` HEAD y subárbol idénticos a fases previas).

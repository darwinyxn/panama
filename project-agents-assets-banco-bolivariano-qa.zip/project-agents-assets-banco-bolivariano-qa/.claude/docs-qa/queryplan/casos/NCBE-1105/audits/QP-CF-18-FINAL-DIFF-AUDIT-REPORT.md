# QP-CF-18 — Auditoría final de diff y preparación de publicación

## 1. Veredicto

**`READY_FOR_SCOPED_COMMIT`**

## 2. Baseline y estado Git

```
pwd:    /home/ssm-user/project-agents-assets-banco-bolivariano-qa
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2   (idéntico al baseline esperado)
status --short --branch: ## master...origin/master
diff --cached --name-only: (vacío)
ahead/behind @{u}: 0 0
```
Índice vacío. HEAD sin desviación. Sin `BLOCKED_FOREIGN_STAGED_CHANGES`, sin `BLOCKED_HEAD_MOVED`.

## 3. Inventario total

**32 archivos en total** (7 modificados vía `git diff --name-status` + 25 no-tracked vía
`git ls-files --others --exclude-standard`):

| Ruta | Estado Git | Categoría | Fase origen | Autorizado | Publicar |
|---|---|---|---|---|---|
| `.claude/agents/agente-queryplan.md` | M | A (código genérico, doc) | QP-CF-2 | Sí | Sí |
| `.claude/docs-qa/inputs/scripts/queryplan/README.md` | M | A/F | QP-CF-2/6/9/13 | Sí | Sí |
| `.claude/docs-qa/inputs/scripts/queryplan/qp_delivery.py` | M | A | QP-CF-5/6/7/8/13/16 | Sí | Sí |
| `.claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py` | M | A | QP-CF-2/5/6/7/8/9/16 | Sí | Sí |
| `.claude/docs-qa/inputs/scripts/queryplan/qp_source_extract.py` | M | A | QP-CF-2/9 | Sí | Sí |
| `.claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_pipeline.py` | M | B | todas (QP-CF-2..16) | Sí | Sí |
| `.claude/skills/query-plan/SKILL.md` | M | F | QP-CF-2 | Sí | Sí |
| `.../config/cones/NCBE-1105.json` | ?? | C | QP-CF-1/9 | Sí | Sí |
| `.../qp_capture_sanitize.py` | ?? | A | QP-CF-16 | Sí | Sí |
| `.../qp_provenance.py` | ?? | A | QP-CF-2 | Sí | Sí |
| `.../qp_tsql_pty.py` | ?? | A | QP-CF-13 | Sí | Sí |
| `.../schema/provenance-queryplan-v1.schema.json` | ?? | A | QP-CF-2 | Sí | Sí |
| `.../tests/test_qp_provenance.py` | ?? | B | QP-CF-2 | Sí | Sí |
| `.../casos/NCBE-1105/analysis/.../provenance-queryplan.json` | ?? | C | QP-CF-9/prepare | Sí | Sí |
| `.../audits/QP-CF-4-LIVE-RUN-REPORT.md` | ?? | D | QP-CF-4 | Sí | Sí |
| `.../audits/QP-CF-5-LIVE-RUN-RETRY-REPORT.md` | ?? | D | QP-CF-5 | Sí | Sí |
| `.../audits/QP-CF-6-TIMEOUT-HARDENING-REPORT.md` | ?? | D | QP-CF-6 | Sí | Sí |
| `.../audits/QP-CF-7-QP02-DIAGNOSTIC-REPORT.md` | ?? | D | QP-CF-7 (corregido en QP-CF-8) | Sí | Sí |
| `.../audits/QP-CF-8-SPID-CORRELATION-REPORT.md` | ?? | D | QP-CF-8 | Sí | Sí |
| `.../audits/QP-CF-9-FUNCTIONAL-LITERALS-REPORT.md` | ?? | D | QP-CF-9 | Sí | Sí |
| `.../audits/QP-CF-10-QP02-FUNCTIONAL-RUN-REPORT.md` | ?? | D | QP-CF-10 | Sí | Sí |
| `.../audits/QP-CF-11-MATRIX-VS-QUERYPLAN-EXECUTOR-AUDIT.md` | ?? | D | QP-CF-11 | Sí | Sí |
| `.../audits/QP-CF-12-PTY-AB-TEST-REPORT.md` | ?? | D | QP-CF-12 | Sí | Sí |
| `.../audits/QP-CF-13-CANONICAL-PTY-INTEGRATION-REPORT.md` | ?? | D | QP-CF-13 | Sí | Sí |
| `.../audits/QP-CF-14-FULL-CONE-PTY-RUN-REPORT.md` | ?? | D | QP-CF-14 | Sí | Sí |
| `.../audits/QP-CF-15-DELIVERY-GENERATION-REPORT.md` | ?? | D | QP-CF-15 | Sí | Sí |
| `.../audits/QP-CF-16-DELIVERY-SANITIZATION-REPORT.md` | ?? | D | QP-CF-16 | Sí | Sí |
| `.../audits/QP-CF-17-REAL-SAFE-DELIVERY-REPORT.md` | ?? | D | QP-CF-17 | Sí | Sí |
| `.../casos/NCBE-1105/inputs/literal-sources.json` | ?? | C | QP-CF-9 | Sí | Sí |
| `.../entregas/NCBE-1105-.../manifest-consolidado-queryplan.json` | ?? | E | QP-CF-17 | Sí | Sí |
| `.../entregas/NCBE-1105-.../zips/pa_fir_consulta_firmante-queryplan.zip` | ?? | E | QP-CF-17 | Sí | Sí |
| `.claude/history/agente-queryplan.md` | ?? | D (log de ejecución) | QP-CF-10..17 | Sí | Sí |

Ningún archivo cae en G (cambio ajeno), H (temporal/innecesario) o I (sensible/prohibido). El
reporte QP-CF-18 mismo (creado por esta fase) se añade como archivo 33 tras completarse esta
auditoría — ver §17.

No se asumió que todo lo no-tracked pertenece al frente: se verificó cada ruta individualmente
contra el árbol `queryplan/` (código/tests/config/schema), `casos/NCBE-1105/` (procedencia/reportes),
`entregas/NCBE-1105-.../` (entrega) e `history/agente-queryplan.md` (log de ejecución del agente
Query Plan) — ninguna ruta ajena a estos 4 árboles apareció en el diff.

## 4. Código genérico Query Plan

Auditado línea por línea (vía agente delegado + verificación directa) el diff completo de
`qp_delivery.py`/`qp_pipeline.py`/`qp_source_extract.py` (modificados) y `qp_tsql_pty.py`/
`qp_capture_sanitize.py`/`qp_provenance.py` (nuevos). Confirmado que los cambios implementan
exclusivamente: procedencia/preparación canónica (`prepare`, QP-CF-2), secuenciación correcta de
`run_live` (QP-CF-5), timeout sanitizado (QP-CF-6), ejecución aislada por QP (`--execution-only`,
QP-CF-9/10), literales funcionales desde matriz (QP-CF-9), ejecutor PTY propio (QP-CF-13), captura
combinada (QP-CF-13), detección de severity sobre texto combinado (QP-CF-13), sanitización
estructural allowlist (QP-CF-16), fail-closed (QP-CF-16), generación segura de entrega (QP-CF-16/17).

**Hallazgos** (ninguno material, ninguno bloquea):
1. `qp_delivery.py::parse_sysprocesses_samples` — campo `hostprocess` siempre `None`, comentario cita
   una función (`parse_hostprocess_samples`) que no existe (el mecanismo real es
   `parse_hostprocess_rows`). Cosmético, preexistente de QP-CF-7/8.
2. `qp_delivery.py::start_target_session`/`stop_target_session` (variante sin handshake, de QP-CF-7)
   quedaron sin caller de producción tras el rediseño de QP-CF-8 (solo las variantes
   `_with_handshake` se usan). Código muerto, menor — no se elimina en esta fase (fuera de alcance:
   "no modificar código").
3. `qp_pipeline.py::_classifier` — `except Exception: return "Desconocido"` traga errores del script
   de clasificación externo sin loguear. Menor, preexistente (no introducido en este arco).
4. `qp_pipeline.py::cmd_preflight` — `except Exception as e: print(...)` podría imprimir
   `str(subprocess.TimeoutExpired)` (que incluye el argv con `-P <password>`) si el preflight expira
   por timeout. **Preexistente en el HEAD baseline, NO modificado por ninguna fase de este arco**
   (confirmado por `git diff` — la función no aparece en ningún hunk `+`/`-` de este trabajo). Es un
   riesgo real pero fuera del alcance de "código modificado por Query Plan Consulta Firmante" — se
   documenta para una fase de hardening futura, no se corrige aquí.
5. `qp_pipeline.py::_relativize_for_print` y `qp_source_extract.py::_relativize` — ambas hardcodean
   `/home/ssm-user/` para acortar rutas en logs/`provenance-queryplan.json`. Cosmético/menor: afecta
   legibilidad y portabilidad si el workspace se clona en otra ruta, pero no es una fuga de datos (la
   ruta del propio workspace no es secreta) ni afecta la corrección funcional.

**Confirmado limpio** (sin hallazgos) en el resto de los 12 criterios pedidos: sin código muerto
adicional, sin `print()` de depuración, sin `TODO`/`FIXME`/`XXX`, sin referencias al repositorio
anterior (`project-agents-assets-banco-bolivariano` sin `-qa`), sin dependencia runtime de Matrices
(`sybase_tsql_wrapper`/`execute_all.py`/`discover_data.py`/rutas `scripts/auto/` — cero imports/
llamadas en los 6 archivos productivos), imports de los 3 módulos nuevos todos usados (confirmado por
AST), `run_live()` usa exclusivamente `PTY.run_pty_session()` sin fallback al pipe, cero reintentos
automáticos, `tsql` solo invocado en `qp_tsql_pty.py`/`qp_delivery.py`, cero credenciales o literales
de negocio del caso (`0000601864`/`pa_fir_consulta_firmante`/`NCBE-1105`/`FirmanteDataAdapter`)
incrustados en código genérico, cero `except:` desnudo, cero cambios fuera de `queryplan/`.

Sin `FINAL_CODE_AUDIT_FAILURE`.

## 5. Pruebas

314 pruebas recolectadas, 314 aprobadas, 0 fallidas (41+78+172+23 por archivo). Ninguna depende de
Sybase real (todo `D.run_live()`/`PTY.run_pty_session()` ejercido en pruebas usa un binario `tsql`
fake inyectado vía `PATH`, con hosts placeholder `"x"`/`"fakehost"`). Ninguna depende de orden global
(`_run_all()` ordena alfabéticamente; sin estado mutable compartido entre pruebas, `PATH`/env
siempre restaurados en `finally`). Sin secretos reales (`_FAKE_PWD`/`_DIAG_FAKE_PWD` son placeholders
con nombre evidente). Sin datos personales reales (fixtures de "Firmante" usan siempre
`ID-SINTETICA-000X`/`PERSONA SINTETICA`/`BLOB-SINTETICO-NO-REAL`/`CTA-SINTETICA-000X`; el literal
`0000601864` que sí aparece dos veces lo hace exclusivamente en asserts que verifican su AUSENCIA
del código productivo). Fixtures 100% sintéticos en la sección QP-CF-16 (`_synthetic_plan_block`/
`_synthetic_io_block`, nunca un blob real pegado). Mocks realistas (`_stub_run_live_factory` et al.
escriben `.out`/`.err` y devuelven el mismo shape que `D.analyze_capture`). Sin asserts debilitados
(`assert True`, `assert 1==1`, asserts comentados: 0 coincidencias; los 9 `pass` encontrados son
todos rama de `except X: pass` tras `assert False`, patrón correcto de "debía lanzar excepción").

**3 pruebas preexistentes con cuerpo modificado** (`test_R1_detalle_renders_timing_not_executed_at`,
`test_R3_micro_in_detalle_and_obs`, `test_R4_no_base_none_literal`): su fixture cambió
`"norm_output": ""` → `"norm_output": _MINI_NORM_OUTPUT` — motivo explícito en comentario de línea
(QP-CF-16: el renderer ya no acepta texto vacío bajo `plan.present=True`/`io.measured=True`, exige
poder delimitar plan/IO). Cambio de fixture para seguir el nuevo contrato, no debilitamiento de
aserciones (los asserts originales permanecen intactos).

Clasificación funcional aproximada (no exclusiva): provenance/literales ~19, prepare ~2, timeout ~20,
ejecución aislada ~12, PTY ~18, cleanup/fds ~2, credenciales ~11, marcador ~12, severity ~3, captura
combinada ~7, sanitización ~11, fail-closed ~7, ZIP ~3, reproducibilidad ~3.

## 6. Configuración y procedencia NCBE-1105

`config/cones/NCBE-1105.json`: confirma `cone_hu=NCBE-1105`, `sp_padre=pa_fir_consulta_firmante`,
`packages.pa_fir_consulta_firmante.hu=NCBE-1111`,
`packages.pa_fir_consulta_firmante.microservicio=pa-fir-consulta-firmante-utils`,
`microservice_for_matrix=cpas-mso-consulta-firmante`, `package_order=[pa_fir_consulta_firmante]`.
`provenance-queryplan.json` (dossier): 5 entradas (QP-01..QP-05), cada una con `sql_legacy`/
`clase_metodo`/`archivo_origen`/`fuente_literales` — todo texto estructural (SQL, nombres de clase,
rutas Java, metadata de procedencia de la matriz), sin `Firma`/identificación/nombre. Confirmado por
escaneo automatizado (búsqueda de claves `firma`/`firmante`/`firmantes`): 0 coincidencias en ambos
archivos. `literal-sources.json`: mismo resultado, 0 campos sensibles. Ningún archivo contiene rutas
absolutas del entorno local fuera de las ya aceptadas como DATO declarativo (`repos_roots`/
`sp_source_roots`/`analysis_roots`/`matrix_roots` en el cone-config, consistente con el precedente
NCBE-661.json ya existente en el repo). Sin información inventada — todo trazable a la matriz de
equivalencia QA real (`QA-CASOS-PARSEADOS.json`, SHA-256 documentado) o al SP/Java fuente.

## 7. Reportes QP-CF

14 reportes inventariados (`QP-CF-4` a `QP-CF-17`; no existen archivos QP-CF-0/1/2/3 bajo
`audits/` — esas fases produjeron solo reportes conversacionales, sin persistir a disco).
Clasificación:

| Reporte | Clasificación |
|---|---|
| QP-CF-4/5/6 | necesario para trazabilidad (primeros intentos live, defecto de secuencia, hardening timeout) |
| QP-CF-7 | contiene narrativa superada, **corregida explícitamente inline** (`[CORREGIDO en QP-CF-8]`, ver §8) |
| QP-CF-8/9 | necesario para trazabilidad (diseño SPID, prioridad de literales) |
| QP-CF-10/11/12 | necesario para trazabilidad (investigación root-cause del timeout, hallazgo PTY) |
| QP-CF-13/14 | necesario para trazabilidad (integración PTY, corrida completa) |
| QP-CF-15 | necesario para trazabilidad (hallazgo de la fuga de datos — bloqueo real, documentado) |
| QP-CF-16/17 | necesario para trazabilidad (corrección y entrega final validada) |

Ninguno redundante al punto de omitir. Escaneo de credenciales/argv sensible/datos personales/
blobs/capturas funcionales/rutas del repositorio anterior sobre los 14: **0 coincidencias** en todos
los criterios (verificado con `grep -F` booleano, no conteo — el intento inicial con `grep -c`
produjo falsos positivos por un error de comparación de cadenas en el script de auditoría, corregido
antes de concluir). QP-CF-7 contiene las conclusiones ya corregidas de QP-CF-8
(`bloqueo descartado`/`transporte descartado`) pero **marcadas explícitamente** `[CORREGIDO en
QP-CF-8]` en las líneas 117 y 171 — cumple la regla de "conclusiones históricas superadas pueden
permanecer si están claramente registradas como resultado de una fase anterior". QP-CF-9 concluye
`QP02_DBA_ESCALATION_REQUIRED` como estado vigente EN SU PROPIA FECHA — no hace una afirmación falsa
sobre el estado actual (los reportes posteriores QP-CF-12/13 documentan la superación de esa
conclusión); esto es un registro histórico correctamente fechado, no una afirmación falsa vigente.
Los 14 reportes deben entrar al commit.

## 8. Entrega

`.claude/docs-qa/queryplan/entregas/NCBE-1105-queryplan-2026-07-09-statistics-io/` contiene
exactamente 2 archivos: `manifest-consolidado-queryplan.json` y
`zips/pa_fir_consulta_firmante-queryplan.zip` — sin ningún otro archivo (confirmado por `find`).
Reabierto el ZIP en memoria (sin extraer al repositorio): 3 miembros exactos
(`manifest-queryplan.json`/`detalle_ejecucion.qp`/`observaciones.qp`), SHA-256 recomputados e
idénticos a los registrados en QP-CF-17 (ZIP `e1127e17da4a094bff2233d0bd188ec9753f4140ceded9bdfcc6ae670263b99a`,
miembros `b53782ec...b74e`/`9dc8d708...f90c`/`bf0cf06f...a001`). Re-verificado: schema v2.1, criterio
`2026-07-09-statistics-io`, 5 QP (QP-01..QP-05), 9 objetos Statistics IO, 0 DML, 0 SP hijos, 0
placeholders (`?`/`...`), 0 secretos, 0 rutas absolutas, 0 marcador/alias técnico, 0 archivos ocultos,
0 directorios internos, 0 capturas `.out`/`.err`. `lint_manifest_v2`/`lint_cross_files_v2`/
`lint_zip`: PASS los tres. **Re-verificación independiente de datos personales**: los valores reales
de QP-05 (identificación de 10 caracteres, nombre de 68 caracteres, blob de firma de 1506
caracteres) se compararon nuevamente contra el contenido del ZIP — 0 coincidencias, incluido el
encabezado funcional `Identificacion\tNombre\tFirma` y cualquier secuencia hexadecimal contigua
≥100 caracteres. El ZIP NO fue regenerado en esta fase.

## 9. Decisión README

**`README_NOT_REQUIRED_BY_CANON`**

Evidencia de las 7 fuentes requeridas:
1. **Código del generador**: `qp_pipeline.py`/`qp_delivery.py` nunca escriben `README.md`; ningún
   subcomando lo produce.
2. **Tests y gates**: `qp_lint.py::lint_delivery()` valida el README **solo si existe**
   (`if cons and os.path.isfile(readme_path):`) — su ausencia nunca produce error. Los tests
   `test_readme_hu_*` validan el comportamiento de `lint_readme_hu()` cuando SE LE PASA un README,
   nunca prueban que su ausencia sea un fallo.
3. **Schema vigente** (`manifest-queryplan-v2.schema.json`, `provenance-queryplan-v1.schema.json`):
   ninguno declara un campo o artefacto README.
4. **Documentación canónica Query Plan** (`README.md`/`SKILL.md`): describen la entrega como
   `manifest-consolidado-queryplan.json` + `zips/<pkg>-queryplan.zip`; el README no aparece en la
   lista de componentes del pipeline (tabla de `README.md` del propio directorio `queryplan/`).
5. **Ejemplo histórico aprobado** (`entregas/NCBE-661-queryplan-2026-07-09-statistics-io/`, mismo
   criterio `2026-07-09-statistics-io`): SÍ tiene README, pero es un cono de **12 paquetes** — el
   README documentado ahí lista la tabla HU por SP/PA precisamente porque hay múltiples filas que
   listar.
6. **Estructura de otra entrega equivalente**: no existe otro cono de un solo paquete en el repo para
   comparar directamente; el criterio de multiplicidad (punto 7) es la explicación consistente.
7. **Agente Query Plan** (`agente-queryplan.md`, línea ~369, solo como documentación): "el README
   lista la HU individual por SP/PA para carga en Confluence" — describe el PROPÓSITO del README
   (publicación humana en Confluence para múltiples filas), no un requisito de validación técnica del
   pipeline.

`NCBE-1105` tiene **un único paquete** (`pa_fir_consulta_firmante`). Las 7 fuentes son coherentes
entre sí: ninguna exige README para una entrega técnica válida; el propósito documentado del README
(tabla HU multi-fila para Confluence) no aplica de forma material a un cono de un solo paquete. No
hay contradicción entre fuentes — se descarta `README_REQUIREMENT_AMBIGUOUS`. La entrega es válida
sin README.

## 10. Seguridad

Escaneo sobre los 32 archivos en alcance (booleano `grep -F -q`, nunca por conteo — un primer intento
con `grep -c` produjo falsos positivos sistemáticos por un error de comparación de cadenas en bash,
detectado y corregido antes de concluir):

| Categoría | Archivos con coincidencia | PASS/FAIL |
|---|---|---|
| Credenciales reales (`SYBASE_PASS`) | 0 | PASS |
| Rutas absolutas sensibles fuera de config declarativa | 0 | PASS |
| Identificaciones/nombres funcionales reales | 0 | PASS |
| Firmas/blobs/imágenes codificadas (≥100 hex contiguos) | 0 | PASS |
| Marcador PTY con valor real (`QPPTY[0-9a-f]+`) fuera de tests | 0 | PASS |
| Marcador PTY como fixture sintético dentro de tests (`QPPTYabc`) | 1 archivo (`test_qp_pipeline.py`) | PASS (esperado — placeholder de prueba declarado) |
| Alias técnico (`_qp_marker`) fuera de tests | 0 | PASS |
| Capturas `.out`/`.err` copiadas al repo | 0 | PASS |

Sin `FINAL_SECURITY_AUDIT_FAILURE`.

**Remediación fuera del árbol git** (no forma parte del diff auditado, documentada por
transparencia): durante esta auditoría se encontraron y, con autorización explícita del usuario, se
eliminaron dos archivos residuales bajo `/tmp` (fuera del repositorio, nunca trackeados por Git)
dejados por fases anteriores (QP-CF-15/QP-CF-17): `/tmp/.qpcf15_detalle.tmp` (25827 bytes, permisos
644 world-readable, contenía el `detalle_ejecucion.qp` sin sanitizar de QP-CF-15 con la fila real de
QP-05) y `/tmp/.qpcf17_real_values.txt` (3 bytes, fragmento de un intento de extracción bloqueado por
el clasificador de permisos). Ambos verificados como archivos regulares no-symlink bajo `/tmp` antes
de eliminar; su contenido nunca se reabrió ni se imprimió durante esta remediación. Esta acción es una
excepción puntual autorizada a la regla "no eliminar residuos en esta fase" (§12), justificada porque
no eran residuo de código/config sino una exposición activa de datos personales reales con permisos
de lectura mundial — fuera del tipo de "residuo" que esa regla pretendía proteger de eliminación
prematura.

## 11. Residuos

Búsqueda de `*.out`/`*.err`/`*.log`/`*.tmp`/`*.bak`/`*.pyc`/`__pycache__`/`.DS_Store`/`payload.sql`/
`ab_test_runner.py`/capturas crudas/ZIPs intermedios sobre los 32 archivos en alcance: **0
coincidencias** — ninguno de los 32 archivos modificados/no-tracked es un residuo. Se encontraron
directorios `__pycache__` en el árbol (`.claude/docs-qa/inputs/scripts/queryplan/__pycache__/` y
similares), generados por la ejecución repetida de la suite de pruebas — están correctamente
cubiertos por `.gitignore` (`**/__pycache__/`, confirmado con `git check-ignore -v`) y NUNCA
aparecen en `git status`/`git ls-files --others --exclude-standard`; no representan riesgo de
publicación accidental. También se encontraron logs (`run_qa.stdout.log`, `run_qa.out`, etc.) bajo
`.claude/docs-qa/results/sp_debcred_empresa-.../` y `.claude/docs-qa/results/sp_ah_depositosl_rc-.../`
— pertenecen a corridas del frente Matrices sobre SPs completamente distintos (`sp_debcred_empresa`,
`sp_ah_depositosl_rc`), no relacionados con Consulta Firmante ni con este arco de trabajo, y no
aparecen en el diff/inventario de esta fase. Ninguno de estos residuos fue eliminado (no autorizado
por esta fase, ni corresponden al alcance de la remediación de §10). Sin `FINAL_ARTIFACT_HYGIENE_FAILURE`.

## 12. Pruebas finales

```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 78 passed, 0 failed
test_qp_pipeline.py     : 172 passed, 0 failed
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 314 passed, 0 failed
```
Sin ejecución de Sybase, sin regeneración de artefactos.

## 13. Propuesta de commits

Dos commits son seguros y coherentes: el código genérico (A/B/F) no depende de que exista la entrega
NCBE-1105 para tener sentido standalone (ya lo demuestran las 314 pruebas, que corren sin ningún
archivo de `casos/NCBE-1105/` ni `entregas/`), y el material específico del caso (C/D/E) depende del
código genérico pero no al revés — la dependencia es unidireccional, consistente con dos commits
separados sin romper bisectabilidad. No existen archivos que no deban entrar en ningún commit (ver
§14 lista de exclusión — vacía para el árbol git; solo hay exclusiones fuera del árbol git en `/tmp`).

## 14. Paths Commit 1 — Robustecimiento genérico Query Plan

```
.claude/agents/agente-queryplan.md
.claude/docs-qa/inputs/scripts/queryplan/README.md
.claude/docs-qa/inputs/scripts/queryplan/qp_delivery.py
.claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py
.claude/docs-qa/inputs/scripts/queryplan/qp_source_extract.py
.claude/docs-qa/inputs/scripts/queryplan/qp_capture_sanitize.py
.claude/docs-qa/inputs/scripts/queryplan/qp_provenance.py
.claude/docs-qa/inputs/scripts/queryplan/qp_tsql_pty.py
.claude/docs-qa/inputs/scripts/queryplan/schema/provenance-queryplan-v1.schema.json
.claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_pipeline.py
.claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_provenance.py
.claude/skills/query-plan/SKILL.md
```
12 archivos. Mensaje sugerido: `fix(queryplan): harden Sybase execution and sanitize delivery captures`.

## 15. Paths Commit 2 — Consulta Firmante NCBE-1105

```
.claude/docs-qa/inputs/scripts/queryplan/config/cones/NCBE-1105.json
.claude/docs-qa/queryplan/casos/NCBE-1105/analysis/pa_fir_consulta_firmante/queryplan/provenance-queryplan.json
.claude/docs-qa/queryplan/casos/NCBE-1105/inputs/literal-sources.json
.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-4-LIVE-RUN-REPORT.md
.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-5-LIVE-RUN-RETRY-REPORT.md
.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-6-TIMEOUT-HARDENING-REPORT.md
.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-7-QP02-DIAGNOSTIC-REPORT.md
.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-8-SPID-CORRELATION-REPORT.md
.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-9-FUNCTIONAL-LITERALS-REPORT.md
.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-10-QP02-FUNCTIONAL-RUN-REPORT.md
.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-11-MATRIX-VS-QUERYPLAN-EXECUTOR-AUDIT.md
.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-12-PTY-AB-TEST-REPORT.md
.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-13-CANONICAL-PTY-INTEGRATION-REPORT.md
.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-14-FULL-CONE-PTY-RUN-REPORT.md
.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-15-DELIVERY-GENERATION-REPORT.md
.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-16-DELIVERY-SANITIZATION-REPORT.md
.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-17-REAL-SAFE-DELIVERY-REPORT.md
.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-18-FINAL-DIFF-AUDIT-REPORT.md
.claude/docs-qa/queryplan/entregas/NCBE-1105-queryplan-2026-07-09-statistics-io/manifest-consolidado-queryplan.json
.claude/docs-qa/queryplan/entregas/NCBE-1105-queryplan-2026-07-09-statistics-io/zips/pa_fir_consulta_firmante-queryplan.zip
.claude/history/agente-queryplan.md
```
20 archivos (incluye este mismo reporte QP-CF-18, generado al cierre de esta fase — ver §17).
Mensaje sugerido: `docs(queryplan): add NCBE-1105 Consulta Firmante delivery`.

## 16. Archivos excluidos

**Dentro del árbol git: ninguno.** Los 32 archivos en alcance (33 con este reporte) se distribuyen
íntegramente entre Commit 1 (12) y Commit 2 (21) — no hay archivo git que requiera exclusión ni
decisión humana adicional.

**Fuera del árbol git** (nunca iban a publicarse, documentados por transparencia, no requieren
decisión — ya remediados o inherentemente fuera de alcance):
- `/tmp/.qpcf15_detalle.tmp`, `/tmp/.qpcf17_real_values.txt` — eliminados en esta fase (§10).
- `/tmp/NCBE-1105-QP-CF-14-full-cone-*`, `/tmp/NCBE-1105-QP-CF-15-delivery-*`,
  `/tmp/NCBE-1105-QP-CF-12-PTY-*`, `/tmp/NCBE-1105-QP-CF-13-canonical-*` y demás directorios de
  staging bajo `/tmp` — residuo de evidencia cruda de fases anteriores, correctamente fuera del
  repositorio por diseño; no se eliminaron en esta fase (fuera del alcance autorizado, ver §11).
- `.claude/docs-qa/inputs/scripts/queryplan/__pycache__/` y similares — cubiertos por `.gitignore`,
  nunca aparecen en `git status`.
- Logs de Matrices bajo `.claude/docs-qa/results/sp_debcred_empresa-.../` y
  `.claude/docs-qa/results/sp_ah_depositosl_rc-.../` — ajenos a este frente, no aparecen en el diff.

## 17. Reporte creado

`.claude/docs-qa/queryplan/casos/NCBE-1105/audits/QP-CF-18-FINAL-DIFF-AUDIT-REPORT.md` (este
archivo). Se incluye en la lista de Commit 2 (§15) porque es, en sí mismo, un artefacto de
trazabilidad del caso NCBE-1105.

## 18. Estado Git final

```
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
```
Índice vacío. Sin commit. Sin push. Sin stage. Ningún archivo del árbol git fue modificado por esta
auditoría más allá de la creación de este reporte. Matrices intactas (sin verificación de hash
repetida en esta fase — ya confirmado idéntico en QP-CF-11/12/13/14/17, y esta fase no tocó código).
Repositorios de negocio intactos (sin cambios de código en esta fase, no se requiere reverificar
`bb-core-firmas-utils`). Agentes intactos (`agente-queryplan.md` con el mismo diff ya presente al
inicio de esta fase, sin modificación adicional).

## 19. Siguiente paso permitido

El frente Query Plan de Consulta Firmante está listo para un commit real, en dos partes según §14/
§15, sujeto a autorización explícita del usuario para ejecutar `git add`/`git commit` (no ejecutado
en esta fase). El push a un remoto requiere autorización adicional e independiente, posterior al
commit.

# QP-CF-21 — Correcciones contractuales y regeneración bancaria

## 1. Veredicto

**`BANK_READY_ARTIFACT_PASS`**

## 2. Baseline

```
HEAD inicial: 7ee73bbb368f3c02b8896b5dbc688b6b5a051894   (idéntico al esperado)
branch: master
ahead/behind @{u}: 0/0
índice: vacío
```
Único cambio no-staged preexistente al iniciar: `.claude/history/agente-queryplan.md` (línea de log
de cierre de QP-CF-20, benigna, sin datos sensibles). Sin `BLOCKED_REPOSITORY_OR_REMOTE_MOVED`.

## 3. Fuentes auditadas

| Archivo | SHA-256 (antes de esta fase) |
|---|---|
| `qp_manifest.py` | `15f71d5839ca6f1057de400ea275acdd3a029344f925ef4546a577d5a6b0b390` |
| `qp_lint.py` | `ea74341122d02b9ed3c1545bf0e167527aeb50b61026c21e54a63dde180411e6` |
| `qp_delivery.py` | `676d0f2a700e933153c074983871c96708a1ad28feeba8ab6e4699eacf34718a` |
| `qp_pipeline.py` | `1e93f8b6d28d9ad99c81ecdb03c91b9726f5c10dbb74068beb0077ac834abca0` |
| `schema/manifest-queryplan-v2.schema.json` | `2d96f4d97b14b745d7de04503cfaae157ce1dc9e994da0b5ca521fcb0e092a8e` |
| `config/cones/NCBE-1105.json` | `c5d92168ddee0e993e66ec1f46ac9ca42d7294528d952d03059818775b6b3fc7` |

También auditados (sin cambios de hash — solo lectura): `qp_manifest_compat.py`, `README.md`
canónico, `agente-queryplan.md`, entrega histórica aprobada
`entregas/NCBE-661-queryplan-2026-07-09-statistics-io/` (12 paquetes, `source_mode:
MIGRATION_RECOVERY`), `provenance-queryplan.json` y `literal-sources.json` de NCBE-1105 (sin
modificar, per §16).

## 4. Metadata Sybase — inconsistencia confirmada

`man["sybase"]` para NCBE-1105 declaraba `{"host_alias": "sybasedvp1", "servidor_descripcion":
null, "ase_version": null, "ase_ebf": null}` — solo el alias FreeTDS sustentado — mientras
`render_detalle()`/`render_observaciones()` imprimían literalmente `"servidor: SYBASE02 (ASE 16.0
SP04 PL08)"` como constante hardcodeada, sin leer `man["sybase"]` en absoluto. Comparación con
NCBE-661 (`config/cones/NCBE-661.json`): declara los 4 campos con roles INVERTIDOS
(`host_alias="SYBASE02"`, `servidor_descripcion="sybasedvp1"`) — confirma que esos valores fueron
copiados de otro cono como constante fija, nunca capturados/verificados para NCBE-1105.

## 5. Decisión Sybase

Solo el alias está sustentado para NCBE-1105 (fuente: `config/cones/NCBE-1105.json`, DATO
declarativo). Sin evidencia versionada/autorizada de `servidor_descripcion`/`ase_version`/
`ase_ebf` para este cono específico. Implementado formato null-safe (`_sybase_label()` en
`qp_delivery.py`): si solo hay alias, renderiza `servidor_alias: <alias>`; si además hay servidor/
versión, los agrega explícitamente sin confundirlos. Nunca imprime `None`/`null`. Eliminados los
dos hardcodes (`render_detalle`, `render_observaciones`).

## 6. Validación JSON Schema actual

Ejecutado un validador estándar Draft-07 (`jsonschema` 4.17.3) contra el `manifest-queryplan.json`
publicado de NCBE-1105: **3 errores**, los 3 idénticos en forma:
`'parametro_corrida' is not one of ['sistema', 'evidencia', 'inferida']` en
`fechas.ejecucion_sybase.fuente`, `fechas.run_started_at_utc.fuente`, `fechas.regeneracion.fuente`.
Verdicto: **`SCHEMA_WRITER_MISMATCH_CONFIRMED`**. Confirmado que el MISMO desacople afecta al
manifest de `pa_aho_pvalida_depini` dentro de la entrega **ya aprobada por Banco** NCBE-661 (3
errores idénticos) — no es un defecto introducido por NCBE-1105, es un gap preexistente del schema.

## 7. Decisión `parametro_corrida`

**Opción A** (confirmada explícitamente por el usuario). `_VALID_DATE_FUENTE` en `qp_manifest.py`
ya incluye `parametro_corrida` desde antes de este arco; `_run_ts()` en `qp_delivery.py` lo usa con
semántica documentada y precisa: "es el `--exec-ts` provisto, no un instante capturado por el
sistema". El precedente ya aprobado (NCBE-661) confirma que es el valor correcto en producción.
Corrección: se agregó `"parametro_corrida"` al enum `dateObj.fuente` del schema JSON — **el writer
NO se modificó**, ningún timestamp existente se reinterpretó. Re-validado: NCBE-1105 y el manifest
de NCBE-661 (`pa_aho_pvalida_depini`) pasan el schema corregido con **0 errores** ambos.

## 8. Decisión `sp_completo`

Determinado que debe provenir de la **combinación canónica `base_datos_default + ".." + pkg`**
(nombre PROPIO del paquete, nunca `sp_padre` del cono — un paquete puede ser una librería hija
distinta), consistente con el precedente `pa_aho_pvalida_depini` en NCBE-661
(`sp_completo="cob_ahorros..pa_aho_pvalida_depini"`, `base_datos_default="cob_ahorros"`). Implementado
en `qp_pipeline.py::tech_source()` (modo `FULL_RUN`, sin seed): compone `sp_completo` desde
`cone["packages"][pkg]["base_datos_default"]` + `pkg`, solo si `base_datos_default` está declarado
(nunca inventado — sin ese dato, permanece `None`, igual que el comportamiento previo). Resultado
para NCBE-1105: `sp_completo = "firmas..pa_fir_consulta_firmante"`, exactamente el valor requerido.
Propagación verificada por prueba: `config/provenance → modelo (tech_source) → manifest → ZIP`.

## 9. Auditoría del campo `microservicio`

Comparado contra 12 paquetes reales de NCBE-661 (ya aprobados): en TODOS, `microservicio` se puebla
con el nombre de la LIBRERÍA (`*-utils`), nunca con el microservicio desplegable del cono (ej.
nunca `bem-mso-debito-credito-empresa-pagos` para el cono de `sp_debcred_empresa` y sus 11 paquetes
hermanos). Es un patrón consistente, no una excepción — confirmado además que
`_FORBIDDEN_TOPLEVEL_ALIASES` en `qp_manifest.py` explícitamente prohíbe crear un campo separado
tipo `micro_libreria`/`microservicio_libreria` como alias. NCBE-1105 (`microservicio =
"pa-fir-consulta-firmante-utils"`) sigue exactamente esa misma convención ya aprobada.

## 10. Decisión micro/librería

**`MICRO_FIELD_IS_IMPLEMENTATION_MODULE`** (confirmada explícitamente por el usuario). Se conserva
`microservicio = "pa-fir-consulta-firmante-utils"` sin modificación — consistente con el precedente
aprobado. Se conserva `repositorio` con su significado canónico actual
(`"bb-core-firmas-utils/pa-fir-consulta-firmante-utils"`). El schema (19 propiedades top-level) NO
declara ningún campo canónico para el micro desplegable (`cpas-mso-consulta-firmante`) — por
instrucción explícita del usuario, no se sobrecarga `repositorio` ni se inventa un campo nuevo.
**Trazabilidad documentada aquí** (sin bloquear la entrega): la relación
`HU cono NCBE-1105 → micro desplegable cpas-mso-consulta-firmante` ya está registrada como DATO en
`config/cones/NCBE-1105.json` (`_doc` explícito: "micro cpas-mso-consulta-firmante"; y el campo
`microservice_for_matrix: "cpas-mso-consulta-firmante"`, consumido por `qp_source_extract.py` para
resolución de literales contra la matriz de equivalencia) — fuera del manifest de entrega, pero
dentro del contrato versionado del cono. Sin `BLOCKED_MICRO_IDENTITY_DECISION`.

## 11. Archivos modificados

```
.claude/docs-qa/inputs/scripts/queryplan/qp_delivery.py        (Sybase label null-safe, sp_completo consumido sin cambio)
.claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py        (composicion de sp_completo en tech_source)
.claude/docs-qa/inputs/scripts/queryplan/qp_lint.py            (validate_manifest_json_schema + gate real en lint_manifest_v2)
.claude/docs-qa/inputs/scripts/queryplan/schema/manifest-queryplan-v2.schema.json (enum fuente +parametro_corrida)
.claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_manifest_v2.py (+4 pruebas: gate JSON Schema real)
.claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_pipeline.py    (+10 pruebas: Sybase label, sp_completo)
.claude/docs-qa/queryplan/entregas/NCBE-1105-queryplan-2026-07-09-statistics-io/manifest-consolidado-queryplan.json (regenerado)
.claude/docs-qa/queryplan/entregas/NCBE-1105-queryplan-2026-07-09-statistics-io/zips/pa_fir_consulta_firmante-queryplan.zip (regenerado)
```
Sin cambios a `qp_tsql_pty.py`, `qp_capture_sanitize.py`, Matrices de Equivalencia, repositorios de
negocio, `config/cones/NCBE-1105.json`, `literal-sources.json`, `provenance-queryplan.json`,
agentes.

## 12. Pruebas

14 pruebas nuevas (4 en `test_qp_manifest_v2.py`: alineación writer/schema, detección real de
desacople sintético, gate integrado en `lint_manifest_v2`, regresión negativa del precedente
NCBE-661; 10 en `test_qp_pipeline.py`: 6 escenarios de `_sybase_label` incluyendo ausencia total de
`SYBASE02`/versión ASE hardcodeada, 1 de integración en los renderers, 3 de propagación de
`sp_completo` incluyendo el caso paquete≠sp_padre). Total:

```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 82 passed, 0 failed   (+4)
test_qp_pipeline.py     : 182 passed, 0 failed  (+10)
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 328 passed, 0 failed   (vs. 314 baseline; gate ">314" superado)
```
Sin conexión a Sybase antes de este gate.

## 13. Necesidad de corrida live

**No fue necesaria.** Se regeneró desde evidencia técnica ya capturada (staging de QP-CF-15,
`/tmp/NCBE-1105-QP-CF-15-delivery-20260808T143928Z`, `chmod 700`), con las 5 capturas `.out`/`.err`
y los 5 payloads `.sql` verificados byte-idénticos a los usados por la entrega ya publicada
(mismos `payload_sha256` para QP-01..05). `qp_pipeline.py regenerate` (determinista, sin ejecutar
Sybase) produjo la entrega corregida. Sin `FULL_RUN_REGRESSION` (no aplica, no se ejecutó corrida
live).

## 14. Entrega regenerada

```
manifest-consolidado-queryplan.json: sha256=498e26993cd30045bf09a4d53968532beff6edd3afa387a589393785e4e6cd3a
zips/pa_fir_consulta_firmante-queryplan.zip: sha256=cf2f0550f961c642ca5ec748878a12a530e1cd3b1c9e9110c5d209723b58d277
```
1 paquete, 5 Query Plans, 9 objetos IO, 0 SP hijos, 0 errores SQL, 0 datos personales (re-verificado
en memoria contra los valores reales de QP-05), 0 blobs, 0 secretos, 0 rutas absolutas, 0
marcadores técnicos, 0 capturas crudas en el ZIP.

## 15. Manifest

`schema_version=2.1`, `hu_cono=NCBE-1105`, `hu_individual=NCBE-1111`, `sp_name=
pa_fir_consulta_firmante`, **`sp_completo=firmas..pa_fir_consulta_firmante`** (corregido, antes
`null`), 5 QP en orden QP-01..QP-05, `estado_final=PASS`. `microservicio=
pa-fir-consulta-firmante-utils` (conservado, decisión §10). Metadata Sybase: `sybase={host_alias:
"sybasedvp1", servidor_descripcion: null, ase_version: null, ase_ebf: null}` — sin contradicción
con los `.qp` (ver §16).

## 16. Detalle

`detalle_ejecucion.qp`: encabezado corregido a `# microservicio: pa-fir-consulta-firmante-utils |
servidor_alias: sybasedvp1` (antes: `servidor: SYBASE02 (ASE 16.0 SP04 PL08)`, sin sustento). 5
planes, 9 objetos Statistics IO, sin valores hardcodeados de servidor no sustentados.

## 17. Observaciones

`observaciones.qp`: mismo encabezado corregido, misma identidad Sybase que el manifest (`servidor_alias:
sybasedvp1` en ambos archivos, confirmado idéntico). Sin narrativa histórica, sin referencia a
bloqueos anteriores.

## 18. ZIP

3 miembros exactos, sin directorios, sin `.out`/`.err`, sin archivos ocultos, sin rutas absolutas,
sin marcador técnico, sin credenciales. Tamaño y hashes registrados en §14.

## 19. Consolidado

`cono=NCBE-1105`, `sp_padre=pa_fir_consulta_firmante`, `total_qp=5`, `delivery_ready=true`,
`estado_final=PASS` — coherente con el manifest del paquete.

## 20. Gates

```
JSON Schema estandar (draft-07):  PASS (0 errores)
schema gate interno (writer):      PASS
manifest lint:                     PASS
cross-lint:                        PASS
delivery/ZIP lint:                 PASS
ZIP member validation:             PASS (3 miembros exactos)
SHA validation:                    PASS
traceability validation:           PASS
placeholder scan:                  PASS
secret scan:                       PASS
sensitive-data scan:               PASS (0 fuga QP-05, verificado en memoria)
absolute-path scan:                PASS
marker scan:                       PASS
hardcoded-server scan:             PASS (0 SYBASE02/ASE 16.0/PL08)
```
Todos PASS. Sin `DELIVERY_VALIDATION_FAILURE`.

## 21. Seguridad

Escaneo de credenciales (`SYBASE_PASS`) sobre los 8 archivos modificados: 0 coincidencias reales.
Escaneo de datos personales de QP-05 (identificación 10 caracteres, nombre 68 caracteres, blob de
firma 1506 caracteres — extraídos y comparados ÍNTEGRAMENTE EN MEMORIA en un único proceso Python,
nunca persistidos a disco ni impresos): 0 coincidencias en los 3 miembros del ZIP corregido.

## 22. Reproducibilidad

Regenerado dos veces desde la misma evidencia (`/tmp/NCBE-1105-QP-CF-15-delivery-.../`) con el mismo
`--exec-ts`: ZIP **byte-idéntico** (`cf2f0550f9...58d277`) en ambas generaciones. Sin variación no
justificada. Sin `DELIVERY_NON_DETERMINISTIC`.

## 23. Comparación entrega anterior vs. corregida

| Campo | Entrega anterior | Entrega corregida | Razón |
|---|---|---|---|
| SHA-256 ZIP | `e1127e17...b99a` | `cf2f0550...58d277` | regeneración tras correcciones contractuales |
| Metadata Sybase (header `.qp`) | `SYBASE02 (ASE 16.0 SP04 PL08)` hardcodeado | `servidor_alias: sybasedvp1` derivado del manifest | corrección A: solo alias sustentado |
| `sp_completo` | `null` | `firmas..pa_fir_consulta_firmante` | corrección C: composición canónica base+pkg |
| `microservicio` | `pa-fir-consulta-firmante-utils` | `pa-fir-consulta-firmante-utils` (sin cambio) | decisión D: campo = módulo/librería, consistente con precedente NCBE-661 |
| JSON Schema estándar | 3 errores (`parametro_corrida`) | 0 errores | corrección B: enum del schema alineado con writer/precedente |
| QP | 5 | 5 | sin cambio |
| objetos IO | 9 | 9 | sin cambio |
| datos sensibles | 0 | 0 | sin cambio |

## 24. Pruebas finales

```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 82 passed, 0 failed
test_qp_pipeline.py     : 182 passed, 0 failed
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 328 passed, 0 failed
```
Idéntico al gate posterior a la implementación (§12) — sin modificación de código después de este
gate.

## 25. Estado Git final

```
branch: master
HEAD:   7ee73bbb368f3c02b8896b5dbc688b6b5a051894   (sin cambios respecto al baseline de esta fase)
```
Índice vacío. Sin commit. Sin push. 8 archivos modificados en el worktree (sin stagear): 6 de
código genérico Query Plan + 2 de la entrega (reemplazada únicamente por generación canónica, nunca
editada manualmente). Matrices intactas (SHA-256 idénticos). Repositorios de negocio intactos
(HEAD/tree idénticos). El único cambio ajeno preexistente al inicio de esta fase
(`.claude/history/agente-queryplan.md`, línea de log benigna de QP-CF-20) permanece intacto, sin
tocar.

## 26. Siguiente paso permitido

La entrega corregida de Consulta Firmante (NCBE-1105/NCBE-1111) queda lista, validada y
reproducible en su ruta canónica dentro del workspace, pendiente de una fase explícita futura de
commit/push (siguiendo el mismo patrón de dos commits de QP-CF-20: código genérico vs. caso
NCBE-1105) — no ejecutado en esta fase. Ningún cambio adicional es necesario para considerar el
artefacto `BANK_READY`.

# QP-CF-6 — Hardening de timeout y reintento controlado

## Baselines confirmados

```
Repo -qa:  HEAD 0b27d19521ff5cdd8d6a7074b97c70aae77a57a2, índice vacío, ahead/behind 0 0
Librería:  HEAD 1745fb27bc037a43d4ce440c4324d9a66f1417de
           tree pa-fir-consulta-firmante-utils 680a765f938ea108e42b12cf1a804cf4e85b0bf7
           subárbol limpio
```
Sin cambios respecto a QP-CF-5. Sin `BLOCKED_SOURCE_BASELINE_CHANGED`.

## Diagnóstico de evidencia parcial (QP-CF-5)

Staging `/tmp/NCBE-1105-queryplan-live-20260807T003136Z`, solo lectura, sin ejecutar Sybase:

| Archivo | Tamaño | SHA-256 (prefijo) |
|---|---|---|
| QP-01.sql | 133 | 460bf67c07c1f86a |
| QP-01.out | 104 | 10cb189928... |
| QP-01.err | 2883 | ea5b5dba21... |
| QP-02.sql | 133 | 66e00ed875bdfba8 |
| QP-02.out | 0 | e3b0c44298... (hash vacío) |
| QP-02.err | 283 | fdb38c9fcf... |
| QP-03.sql | 141 | 5edf3672b5991f3e |
| QP-04.sql | 263 | cd374c88294b302d |
| QP-05.sql | 422 | f1c4dd78d07c9f2c |

QP-02: `plan_present=false`, `io_present=false`, `login_error_present=false`,
`transport_error_present=false`, `high_severity_present=false`, `output_empty=true`,
`stderr_empty=false`, último mensaje normalizado: `Msg 3614 (severity 10` (informativo, "Total
writes for this command"). Cero procesos `tsql` huérfanos (`ps aux` sin coincidencias).

## Clasificación del timeout

**`QUERY_EXECUTION_TIMEOUT_CANDIDATE`**. Justificación: la sesión se estableció y procesó los
batches previos (`use`, `set statistics io on`) generando mensajes informativos severity 10 en
`stderr`, pero el proceso se colgó exactamente en el batch del `SELECT` real, sin producir plan ni
IO. No hay evidencia de error de login/transporte (`CONNECTION_TIMEOUT_CANDIDATE` descartado por
falta de esa señal) ni de error real severity≥11 (`SERVER_ERROR_PRESENT`/`CLIENT_ERROR_PRESENT`
descartados). No se interpretó la captura parcial como Query Plan válido ni se usó QP-01/QP-02 de
esta corrida en ninguna entrega.

## Escaneo de credenciales

`SYBASE_PASS` usado solo en memoria de shell (`$PW`), nunca impreso. Coincidencias exactas
encontradas:

| Ubicación | Coincidencias |
|---|---|
| Repo `-qa` (tracked + untracked) | 0 |
| Reporte QP-CF-4 | 0 |
| Reporte QP-CF-5 | 0 |
| Staging parcial completo (todos los archivos) | 0 |
| Staging nuevo (tras el reintento con timeout 300s) | 0 |

**`CREDENTIAL_PERSISTENCE_DETECTED = false`** en todas las ubicaciones. El traceback expuesto
durante QP-CF-5 ocurrió solo en la sesión de terminal de esa conversación anterior — nunca se
persistió en ningún archivo del sistema. No se requirió sanitización ni evaluación de rotación de
credencial.

## Corrección de seguridad

Modificado `qp_delivery.py`:

- `DEFAULT_TIMEOUT_SECONDS = 120` (constante, antes hardcodeado inline en `run_live`).
- `class QueryPlanExecutionTimeout(RuntimeError)` — expone únicamente `qid`, `timeout_seconds`,
  `stdout_path`, `stderr_path`, `payload_sha256`. Nunca password/usuario/argv real.
- `run_live()` ahora acepta `timeout_seconds` (default `DEFAULT_TIMEOUT_SECONDS`) y captura
  `subprocess.TimeoutExpired` explícitamente, relanzando `QueryPlanExecutionTimeout(...) from None`.

**Detalle crítico verificado empíricamente**: `raise X from None` establece `__cause__=None` y
`__suppress_context__=True`, pero **conserva** `__context__` con la excepción original — solo
suprime su impresión en el traceback formateado por el runtime estándar de Python
(`traceback.format_exception` respeta `__suppress_context__`). Se confirmó con una prueba dedicada
que el traceback formateado real (no solo `str()`) nunca contiene la contraseña ni el bloque "During
handling of the above exception".

Modificado `qp_pipeline.py`: captura `D.QueryPlanExecutionTimeout` en el bucle de ejecución viva,
imprime solo `str(te)` (mensaje seguro tipo `"QP-02 excedió timeout=300s; evidencia parcial
preservada."`), retorna código `7`, sin generar manifest ni ZIP, sin continuar al QP/paquete
siguiente.

## Timeout configurable

Nuevo argumento `--timeout-seconds` en `qp_pipeline.py run` (no en `regenerate`, que no ejecuta
Sybase). Resolución: CLI explícito → `cone["sybase"]["timeout_seconds"]` si el cono lo declara →
`qp_delivery.DEFAULT_TIMEOUT_SECONDS` (120). Valida entero positivo (rechaza `0`, negativos,
no-enteros, `bool`, con `sys.exit` antes de conectar). Ningún hardcode de `NCBE-1105`/`QP-02` en la
lógica de resolución (confirmado por test dedicado).

## Pruebas

16 pruebas nuevas en `test_qp_pipeline.py` (sin `tsql`/Sybase real; usan un script `tsql` FALSO
local que duerme para forzar `TimeoutExpired` real de forma determinista, y una contraseña de
prueba reconocible para verificar su ausencia en excepciones/tracebacks):

1-3. Mensaje/traceback formateado/argv nunca contienen la contraseña de prueba.
4. `.out`/`.err` parciales se conservan tras el timeout.
5-7. Timeout no genera manifest, no genera ZIP, no ejecuta el QP siguiente.
8-9. Timeout default=120; override CLI=300 se propaga correctamente a `run_live`.
10. Valores de timeout inválidos (`0`, `-5`, `"abc"`, `1.5`, `True`) → `SystemExit`.
11. Exactamente una invocación `run_live` por QP (con el parámetro nuevo presente).
12. `regenerate` nunca invoca `run_live` (instrumentado, 0 llamadas).
13. `exit_code≠0` común permanece distinto de un timeout (no se confunden las dos rutas de fallo).
14. Las funciones de fixture/ejecución de esta sección no mencionan el caso Firmante.
15. Cero hardcodes de `QP-02`/`NCBE-1105` en `qp_pipeline.py`/`qp_delivery.py`.
16. Ningún `print()` de la suite pasa la contraseña de prueba como argumento.

Resultado de las 4 suites:

```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 78 passed, 0 failed
test_qp_pipeline.py     : 82 passed, 0 failed   (68 previas + 14 correcciones/rediseños de la
                                                  sección de reproducción de QP-CF-5 + 16 nuevas
                                                  de esta fase, neto +14 sobre las 68 previas)
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 224 passed, 0 failed   (14 mas que las 210 previas)
```

## Timeout efectivo utilizado

`300` segundos (`--timeout-seconds 300`, autorizado explícitamente para el reintento de esta fase).

## Nuevo staging

`/tmp/NCBE-1105-queryplan-live-20260807T022949Z`, generado por `prepare` fresco: 5 entradas de
procedencia, 5 payloads, 0 bloqueados, hashes de payload idénticos a la baseline auditada
(`460bf67c07c1f86a`, `66e00ed875bdfba8`, `5edf3672b5991f3e`, `cd374c88294b302d`,
`f1c4dd78d07c9f2c`), cero placeholders, cero DML, cero hijos, cero capturas previas (`live_v21/` no
existía antes de la corrida).

## Resultado de cada QP en el reintento

| QP | Resultado |
|---|---|
| QP-01 | Completó correctamente (`.out`/`.err` con plan e IO, sin errores). |
| QP-02 | Excedió el timeout de 300s (patrón idéntico al intento de QP-CF-5 con 120s: sesión establecida, mensajes informativos previos, colgado exactamente en el `SELECT`, `stdout` vacío). |
| QP-03, QP-04, QP-05 | No alcanzados. |

## Gates

No ejecutados — no hay entrega que validar.

## Entrega

No generada. `DELIVERY_NOT_READY`.

## Cero conexiones ad hoc

Toda interacción con Sybase en esta fase ocurrió exclusivamente vía `qp_pipeline.py preflight` y
`qp_pipeline.py run` (dos invocaciones: `preflight` y el único reintento con `--timeout-seconds
300`). No se ejecutó `tsql` directamente, no se realizaron consultas exploratorias.

## Veredicto

**`LIVE_RUN_BLOCKED_REPEATED_TIMEOUT`**

QP-02 excedió el timeout tanto en 120s (QP-CF-5) como en 300s (QP-CF-6), con el mismo patrón exacto
de fallo. Esto es evidencia consistente de que el problema no es aleatoriedad transitoria de red,
sino algo específico y reproducible relacionado con esa consulta o con el estado del servidor
Sybase en ese punto de la sesión — requiere revisión específica de rendimiento/bloqueo/ambiente, no
un tercer reintento con timeout mayor.

## Ruta de evidencia (ambos intentos)

```
/tmp/NCBE-1105-queryplan-live-20260807T003136Z/   (QP-CF-5, timeout=120s)
    pa_fir_consulta_firmante/engine_out/QP-01..05.sql
    pa_fir_consulta_firmante/live_v21/QP-01.{out,err} (completo), QP-02.{out,err} (parcial)

/tmp/NCBE-1105-queryplan-live-20260807T022949Z/   (QP-CF-6, timeout=300s)
    pa_fir_consulta_firmante/engine_out/QP-01..05.sql
    pa_fir_consulta_firmante/live_v21/QP-01.{out,err} (completo), QP-02.{out,err} (parcial)
```

Ambos conservados sin modificar para diagnóstico posterior. La carpeta de entrega quedó vacía tras
ambos intentos (se eliminó únicamente el `zips/` vacío de QP-CF-5 antes de este reintento, con
verificación explícita de que no contenía ningún artefacto).

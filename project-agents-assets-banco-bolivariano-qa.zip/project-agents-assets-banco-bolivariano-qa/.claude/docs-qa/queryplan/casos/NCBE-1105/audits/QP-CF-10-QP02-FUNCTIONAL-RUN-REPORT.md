# QP-CF-10 — Ejecución aislada real de QP-02 con literal funcional

## 1. Objetivo

Responder, con una ejecución REAL (no diagnóstico) y una sola vez: ¿QP-02 termina cuando se ejecuta
de verdad con el literal funcional `e_cta_banco=0000601864` (TC05 de la matriz de equivalencia), por
el mismo camino productivo (`D.run_live()`) que usa `qp_pipeline.py run`?

## 2. Razón por la que `diagnose` no era prueba suficiente

En QP-CF-9, `diagnose` no llegó a enviar el SELECT sustantivo: el handshake `@@spid` (batch de
identificación previo, deliberadamente mínimo) nunca respondió dentro de 15s, así que el mecanismo se
detuvo antes de ejecutar la consulta real. El comportamiento del payload regenerado con el literal
funcional seguía sin comprobarse por el camino real de ejecución.

## 3. Baseline

```
Repo -qa:  master, HEAD 0b27d19521ff5cdd8d6a7074b97c70aae77a57a2, índice vacío
Librería:  HEAD 1745fb27bc037a43d4ce440c4324d9a66f1417de
           tree pa-fir-consulta-firmante-utils 680a765f938ea108e42b12cf1a804cf4e85b0bf7
```
Ambos coinciden exactamente con el baseline esperado. Sin `BLOCKED_REPOSITORY_STATE` ni
`BLOCKED_SOURCE_BASELINE_CHANGED`.

## 4. Extensión de ejecución aislada

`run --help`/`prepare --help` confirmaron que la interfaz existente no permitía filtrar por
`--package`/`--qid` ni ejecutar sin generar entrega. Se implementó `run --execution-only` en
`qp_pipeline.py` (`_run_execution_only()`), que:

- reusa literalmente `D.run_live()` (mismo import, misma firma, sin reimplementación) y
  `_require_complete_capture()` (misma validación que la fase 1 de `run` normal);
- NO referencia ningún símbolo de `diagnose` (`cmd_diagnose`, `start_target_session_with_handshake`,
  `correlate_by_hostprocess`, `sample_target_session`, `build_compile_only_payload`) ni `@@spid`/
  `hostprocess` — verificado por prueba de inspección de fuente;
- ejecuta exactamente el `qid` de `--package` pedidos, ninguno más;
- no genera manifest/consolidado/ZIP/README — solo imprime un resultado JSON estructurado y un
  veredicto (`EXECUTION_ONLY_RUN_PASS`/`EXECUTION_ONLY_RUN_TIMEOUT`/`EXECUTION_ONLY_RUN_FAIL`);
- preserva la captura (`.out`/`.err`) en `<evidence-root>/<pkg>/live_v21/`, igual que una corrida
  normal;
- sin nombres/literales del caso Firmante hardcodeados en su cuerpo (verificado por prueba).

## 5. Payload QP-02 y SHA-256

```
select 1 from cob_ahorros..ah_cuenta where ah_cta_banco = '0000601864'
```
payload completo (con wrappers `use`/`set statistics io on`/`set showplan on`):
`payload_sha256 = b5600baa3e32fe2457f14434da8bda67a7560e0d048f1391705ba5f8435ae282` — idéntico al
payload verificado en QP-CF-9 (mismo `prepare`, determinista). Validado antes de conectar: sin
placeholders, sin DML, sin handshake, sin `@@spid`.

## 6. Procedencia del literal

`fuente_literales` del dossier fresco: `tipo_fuente=QA_EQUIVALENCE_MATRIX | archivo=...
QA-CASOS-PARSEADOS.json | sha256=a6a9f60b...342f | test_case_id=TC05 | escenario=cuenta AHO activa
con firmantes | jsonpath=casos_prueba[4].parametros_entrada.e_cta_banco | valor=0000601864 |
razon=caso_funcional_ejecutado_equivalente`.

## 7. Comando lógico ejecutado (sin credenciales)

```
qp_pipeline.py run --cone-config config/cones/NCBE-1105.json \
  --evidence-root <staging-fresco> --package pa_fir_consulta_firmante \
  --qid QP-02 --execution-only --timeout-seconds 120
```

## 8. Confirmación de `run_live()` y ausencia de handshake

`_run_execution_only()` invoca `D.run_live(payload_text, qid, live_stg, syb_env,
timeout_seconds=timeout_seconds)` — el mismo `subprocess.run(["tsql", ...], input=pb, ...)` que usa
`run` normal. No se abrió ninguna segunda sesión, no se envió ningún batch de identificación, no se
consultó `master..sysprocesses` ni `sp_who`. Una sola conexión `tsql`, un solo envío del payload.

## 9. Resultado

```
status: EXECUTION_ONLY_RUN_TIMEOUT
exit code: 7
started_at_utc: 2026-08-07T05:53:41Z
finished_at_utc: 2026-08-07T05:55:41Z
```

## 10. Duración

`120.001` segundos — coincide con el timeout configurado (120s), confirmando que el proceso `tsql`
fue efectivamente terminado por `subprocess.run(..., timeout=120)`, no por un fallo instantáneo.

## 11. Plan e IO

No disponibles — el `SELECT` no completó dentro del timeout, por lo que ni el plan ni las
estadísticas de IO llegaron a imprimirse. `QP-02.out`: 0 bytes
(`e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`, hash de archivo vacío).

## 12. Errores

`QP-02.err` (283 bytes, `fdb38c9fcf12117b9be1237aeaad6cd28ebfd282df3a47160aeb730977c64def`) contiene
únicamente mensajes de transporte severity=10 (cambio de character set, "Total writes for this
command: 0") — no hay ningún error SQL severity>=11. **Este hash es byte-idéntico al `QP-02.err`
observado en QP-CF-6, que corresponde a la corrida completa con el literal de test unitario
`1234567890`** (documentado en `QP-CF-6-TIMEOUT-HARDENING-REPORT.md`, línea `QP-02.err | 283 |
fdb38c9fcf...`). Dos literales completamente distintos, dos ejecuciones reales independientes, el
mismo comportamiento de servidor byte-a-byte. Escaneo de credenciales sobre toda la evidencia de esta
fase: **0 coincidencias** de `SYBASE_PASS`/`SYBASE_USER`.

## 13. Conclusión

El literal funcional `0000601864` (TC05, matriz de equivalencia) **no** permite completar QP-02
dentro de 120 segundos por el camino real de ejecución (`run_live()`, sin diagnóstico, sin
handshake). El timeout se reproduce de forma idéntica, byte a byte, con el literal correcto y con el
literal previamente descartado — confirma definitivamente que el dato nunca fue la variable causal.
El problema es de servidor/conexión, no de consulta ni de literal.

## 14. Necesidad de DBA

**Se mantiene y queda confirmada con la evidencia más fuerte obtenida hasta ahora**: una ejecución
real (no diagnóstico) con el literal funcional correcto reproduce exactamente la misma firma de
fallo observada en corridas anteriores con datos distintos. Se requiere observación DBA directa del
servidor `sybasedvp1` durante una ejecución controlada de QP-02.

## Archivos modificados en esta fase

```
.claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py       (+ _run_execution_only, cmd_run, argparse)
.claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_pipeline.py (+14 pruebas)
.claude/docs-qa/inputs/scripts/queryplan/README.md            (documentacion de --execution-only)
```
Sin cambios a: `qp_delivery.py`, `qp_source_extract.py`, `qp_provenance.py`, agentes, skills, schemas
v2.1, repos de negocio, `literal-sources.json`, la matriz original.

## Veredicto

**QP02_FUNCTIONAL_RUN_TIMEOUT**

# QP-CF-15 — Generación y validación de entrega Query Plan

## 1. Estado Git inicial

```
pwd:    /home/ssm-user/project-agents-assets-banco-bolivariano-qa
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
status --short --branch: ## master...origin/master
diff --cached --name-only: (vacío)
ahead/behind @{u}: 0 0
```
Índice vacío. Sin `BLOCKED_REPOSITORY_STATE`.

## 2. Pruebas iniciales

Auditoría previa (7 puntos de QP-CF-13, re-verificados por código): `D.run_live()` usa
exclusivamente `PTY.run_pty_session()` (el único `subprocess.run` restante en `qp_delivery.py`
pertenece a `_run_tsql_diagnostic`, usado por `diagnose`, no invocado en esta fase); sin fallback;
cero imports de `sybase_tsql_wrapper` en `qp_delivery.py`/`qp_pipeline.py`/`qp_tsql_pty.py`; marcador
y su alias eliminados (`_MARKER_ALIAS`); `high_sev` escanea `combined`; timeout con
`time.monotonic()` + `finally:`; `raise ... from None` presente. Sin defectos — sin
`DELIVERY_PRECHECK_FAILURE`.

```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 78 passed, 0 failed
test_qp_pipeline.py     : 154 passed, 0 failed
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 296 passed, 0 failed
```
Gate cumplido. Sin `DELIVERY_BASELINE_TEST_FAILURE`.

## 3. Staging fresco

`/tmp/NCBE-1105-QP-CF-15-delivery-<RUN_ID>/` (`chmod 700`), sin reutilizar ninguna captura de
QP-CF-10/12/13/14.

## 4. Prepare

`PIPELINE_PROVENANCE_READY_PREPARE_READY`, 5/5 payloads, 0 bloqueados, 0 placeholders, 0 DML, 0 SP
hijos (confirmado por `inventory`), 0 secretos. QP-02: literal `0000601864`,
`payload_sha256=b5600baa3e32fe2457f14434da8bda67a7560e0d048f1391705ba5f8435ae282` — idéntico al
requerido. Los 5 `payload_sha256` idénticos a QP-CF-14 (mismo `prepare` determinista). Sin
`BLOCKED_PAYLOAD_DRIFT`.

## 5. Preflight

`PREFLIGHT_OK`.

## 6. Corrida live

`qp_pipeline.py run --cone-config ... --evidence-root <staging> --exec-ts <iso> --output <staging>/
delivery --timeout-seconds 120 --pause 1.0` — camino `_generate(live_mode=True)`: Fase 1 ejecuta
`D.run_live()` (→ `qp_tsql_pty.run_pty_session()`) secuencialmente QP-01→QP-05, un intento por QP,
una sesión PTY por QP, sin scripts temporales, sin wrapper de Matrices, sin `tsql` manual, sin
`diagnose`. Resultado: `DONE (FULL_RUN): paquetes=1 QP=5 obsQP=0 dml=0 err=0`, `VERDICT:
FULL_RUN_DELIVERY_READY`, exit=0. Duración total ~9s (14:40:14Z → 14:40:23Z).

## 7-11. Resultado de los cinco QP

Los 5 completaron con `.err` de 0 bytes (éxito) y plan+IO reales incrustados en `.out`:

| QP | .out bytes | .out sha256 | .err bytes |
|---|---|---|---|
| QP-01 | 4275 | `6bf93f552f...df01` | 0 |
| QP-02 | 4275 | `7b61bf7892...fd3` | 0 |
| QP-03 | 4143 | `1208c7ee21...686e` | 0 |
| QP-04 | 7994 | `64bbe3956b...907` | 0 |
| QP-05 | 9623 | `ecd769be3a...338b` | 0 |

Marcador y alias técnico ausentes de las 5 capturas (mismo mecanismo de sanitización de QP-CF-13/14,
sin regresión).

## 8. Seguridad de QP-05 — HALLAZGO CRÍTICO

Inspección estática previa: QP-05 proyecta `Identificacion`/`Nombre`/`Firma` — datos personales e
imagen de firma, ALTAMENTE sensibles. El SQL no fue modificado. Staging con `chmod 700`, capturas
crudas exclusivamente bajo `/tmp`.

**El artefacto `detalle_ejecucion.qp` generado dentro del ZIP INCRUSTÓ la fila real del resultado de
QP-05** (identificación real, nombre real, y el blob hexadecimal completo de la imagen de firma) en
la sección "OUTPUT LITERAL DEL MOTOR SYBASE" — `qp_delivery.render_detalle()` embebe
`live["norm_output"]` verbatim, sin redactar filas funcionales. Este comportamiento es preexistente
al ejecutor PTY (afecta por igual al camino anterior por pipe) y nunca se manifestó en fases previas
porque ningún QP anterior de este cono proyectaba columnas de datos personales — QP-01/02/03 devuelven
un escalar (`1`), QP-04 un conteo (`COUNT(1)`); QP-05 es el primer QP cuyo `SELECT` expone filas con
identificación/firma reales.

`manifest-queryplan.json` y `manifest-consolidado-queryplan.json` NO contienen la fila (solo SQL
estructural, hashes y metadata) — el escaneo confirmó que la fuga está confinada exclusivamente a
`detalle_ejecucion.qp`.

**Acción tomada**: se eliminaron ÚNICAMENTE los dos artefactos generados por esta fase
(`manifest-consolidado-queryplan.json` y `zips/pa_fir_consulta_firmante-queryplan.zip`, ambos bajo
`/tmp`, verificados como archivos regulares no-symlink antes de borrar), preservando la evidencia
sanitizada (hashes/tamaños, sin reproducir valores) y las capturas crudas (`.out`/`.err`, que
también contienen la fila pero SIEMPRE residieron exclusivamente en `/tmp`, nunca en el repositorio).
No se generó ningún artefacto de entrega en el repositorio en ningún momento.

Evidencia sanitizada preservada (solo hashes/tamaños):
```
ZIP:      sha256=1264e5819b17208060e0405c0d961614ea98d28fa974d633586e096aac24791b, size=8126
  manifest-queryplan.json: sha256=217b56586118d52ce2d6314f5aed5f23a9a57005b6a086371d99dc79d0c8ccef, size=23981
  detalle_ejecucion.qp:    sha256=754abb6e36b100e7f518d87f8ab64ef96ee09e9cd463f00004d4069a63de16a7, size=25827 (CONTIENE FILA SENSIBLE — eliminado)
  observaciones.qp:        sha256=d40e28aad9f954bbd435116e169df1a4289f3f017a231d0b8faf36fbfa4a6962, size=652
```

## 9. Archivos generados

Ninguno permanece — ambos eliminados tras la detección (§8). El ZIP y el consolidado existieron
transitoriamente bajo `/tmp/NCBE-1105-QP-CF-15-delivery-<RUN_ID>/delivery/` y fueron borrados antes
de finalizar esta fase.

## 10. Manifest

`manifest-queryplan.json` (dentro del ZIP ya eliminado): schema v2.1, 5 QP en orden estable
QP-01..QP-05, métodos Java correctos, tablas correctas, `payload_sha256` correctos, procedencia
completa (matriz de equivalencia), plan/IO presentes, 0 DML, 0 SP hijos, 0 placeholders, 0 rutas
absolutas — estructuralmente válido y SIN datos sensibles (confirmado antes de eliminar). No se pudo
completar la validación formal de gates (§15) porque la fase se detuvo en el hallazgo de §8.

## 11. Detalle

`detalle_ejecucion.qp`: estructuralmente correcto (5 secciones QP-01..QP-05, SQL exacto, plan/IO
correspondiente a cada objeto, sin plan auxiliar del marcador, sin alias técnico, sin prompts `1>`,
sin credenciales) **PERO contenía la fila funcional sensible de QP-05** — motivo del bloqueo.

## 12. Observaciones

`observaciones.qp` (652 bytes): sin inspeccionar en detalle dado el bloqueo — el escaneo confirmó
que NO contiene el marcador/alias/credenciales, pero la fase se detuvo antes de una revisión de
contenido narrativo completa (criterio Banco, 5/5 éxito, ausencia de DML/SP hijos) porque el defecto
de §8 ya era causa suficiente de bloqueo.

## 13. ZIP

3 miembros exactos (`manifest-queryplan.json`, `detalle_ejecucion.qp`, `observaciones.qp`), sin
carpetas internas, sin archivos temporales, sin capturas `.out`/`.err`, sin logs, sin rutas
absolutas, sin marcador — pero el contenido de uno de sus miembros violaba la protección de datos
sensibles (§8). ZIP eliminado.

## 14. Consolidado

Generado correctamente a nivel estructural (referenciaba NCBE-1105/NCBE-1111/
cpas-mso-consulta-firmante/pa_fir_consulta_firmante/5 QP/0 SP hijos/criterio
2026-07-09-statistics-io) — eliminado junto con el ZIP por el mismo bloqueo.

## 15. README

No se generó — la fase se detuvo antes de llegar a ese paso.

## 16. Gates

No se ejecutaron los gates automáticos formales (`qp_pipeline.py validate`, cross-lint, etc.) porque
la fase se detuvo en el escaneo de datos sensibles (§8), anterior en el flujo de esta fase a la
ejecución de gates.

## 17. Reproducibilidad

No evaluada — la fase se detuvo antes de esta etapa.

## 18. Pruebas finales

```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 78 passed, 0 failed
test_qp_pipeline.py     : 154 passed, 0 failed
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 296 passed, 0 failed
```
Idéntico al gate inicial — sin regresión, sin modificación de código.

## 19. Veredicto

**`BLOCKED_SENSITIVE_DATA_LEAK`**

## 20. Archivos creados o modificados

Único archivo nuevo en el repositorio: este reporte. Ningún cambio de código en esta fase (el
defecto detectado está en `qp_delivery.render_detalle()`, preexistente, NO modificado — corregirlo
requiere autorización explícita en una fase posterior, ya que altera el contrato de contenido de
`detalle_ejecucion.qp`).

## 21. Estado Git final

```
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
```
Índice vacío. Sin commit. Sin push. Matrices sin modificaciones (SHA-256 idénticos a fases previas).
Repositorios de negocio intactos. Ningún artefacto de entrega (ZIP/manifest-consolidado/README)
existe en el repositorio ni permanece en `/tmp` (ambos eliminados tras el hallazgo).

## 22. Siguiente paso permitido

Ninguna generación de entrega puede reintentarse hasta que se autorice explícitamente una corrección
del mecanismo de renderizado (`qp_delivery.render_detalle()` y, potencialmente,
`render_observaciones()`) para redactar/omitir filas funcionales de SELECTs que proyecten columnas
de datos personales (`Firma`/identificación/nombre), preservando plan y Statistics IO íntegros. Esa
corrección es un cambio de código con impacto en el contrato de `detalle_ejecucion.qp` y en las
pruebas existentes — requiere su propia fase de diseño, implementación y prueba (QP-CF-16 o
posterior), no una edición manual del artefacto final.

# QP-CF-8 — Correlación determinista de SPID y diagnóstico final de QP-02

## Corrección de conclusiones previas (QP-CF-7)

El reporte `QP-CF-7-QP02-DIAGNOSTIC-REPORT.md` fue actualizado (no reescrito ni oculto) para eliminar
conclusiones no sostenidas por evidencia directa: "bloqueo descartado", "transporte descartado",
"contención específica" como hipótesis afirmada. Las secciones "Sesión objetivo" y "Recomendación" de
ese reporte ahora indican explícitamente, y solo eso:

- QP-02 presenta un timeout persistente y reproducible.
- El plan compile-only muestra acceso por índice.
- La sesión ASE objetivo no fue correlacionada.
- La causa de la espera permanece sin determinar.

El veredicto original de QP-CF-7 (`QP02_INSUFFICIENT_DIAGNOSTIC_EVIDENCE`) no se modificó — la
corrección es de lenguaje/alcance de las conclusiones, no del resultado.

## Baselines

```
Repo -qa:  HEAD 0b27d19521ff5cdd8d6a7074b97c70aae77a57a2, índice vacío, ahead/behind 0 0
Librería:  HEAD 1745fb27bc037a43d4ce440c4324d9a66f1417de
           tree pa-fir-consulta-firmante-utils 680a765f938ea108e42b12cf1a804cf4e85b0bf7
           subárbol limpio
```
Sin cambios respecto a QP-CF-7. Sin `BLOCKED_SOURCE_BASELINE_CHANGED`.

## Diseño de correlación

Se reemplazó por completo la heurística de "exactamente una sesión activa" (QP-CF-7) por dos
mecanismos deterministas, en orden, implementados en `qp_delivery.py`:

**1. Hostprocess** — `parse_hostprocess_rows()` + `correlate_by_hostprocess()`: consulta
`select spid, hostprocess from master..sysprocesses`, compara la columna `hostprocess` publicada por
ASE contra el PID local real del proceso hijo `tsql` (`Popen.pid`). Estados exactos:
`HOSTPROCESS_EXACT_MATCH` / `HOSTPROCESS_NOT_POPULATED` / `HOSTPROCESS_FORMAT_MISMATCH` /
`HOSTPROCESS_AMBIGUOUS` / `HOSTPROCESS_NOT_FOUND`. Solo `HOSTPROCESS_EXACT_MATCH` con un único SPID
se acepta.

**2. Handshake `@@spid`** (fallback) — `start_target_session_with_handshake()`: un ÚNICO proceso
`tsql` (mismo `Popen`, mismo `stdin`, nunca se cierra y reabre la conexión) que primero envía un
batch de identificación (`select '<marcador>' as diagnostic_marker, @@spid as target_spid`) y solo
tras validar la respuesta (marcador exacto + un único entero) envía el SELECT sustantivo por el
mismo `stdin`. Implementado con `_StreamReader` (lectura incremental en hilo de fondo sobre
`stdout`/`stderr`) para poder inspeccionar la respuesta sin esperar a que el proceso termine.
Estados: `SPID_HANDSHAKE_OK` / `SPID_HANDSHAKE_TIMEOUT` / `SPID_HANDSHAKE_PARSE_ERROR` /
`SPID_HANDSHAKE_CONNECTION_RESTARTED`.

**3. Escalamiento** — si ambos fallan, `cmd_diagnose` termina en `QP02_DBA_ESCALATION_REQUIRED` sin
crear ningún otro mecanismo automático ni ejecutar otra sesión.

**Defecto técnico encontrado y corregido durante la implementación**: el `Popen` del handshake
requiere `bufsize=0` explícito. Con el buffering por defecto, `stdout.read(4096)` dentro del hilo
lector podía bloquearse esperando llenar su buffer interno en vez de devolver los datos ya
disponibles en el pipe — el handshake nunca detectaba la respuesta de ASE aunque ya hubiera llegado,
resultando siempre en `SPID_HANDSHAKE_TIMEOUT` falso. Confirmado empíricamente (mismo código, mismo
proceso fake, mismo timing: sin `bufsize=0` nunca detecta el marcador; con `bufsize=0` lo detecta de
inmediato) antes de fijar la corrección.

## Pruebas

21 pruebas nuevas/reescritas en `test_qp_pipeline.py` (sin Sybase real; el fake `tsql` simula el
comportamiento de streaming real leyendo línea por línea y respondiendo al ver el delimitador `go`,
necesario porque el mecanismo de producción depende de leer una respuesta antes de enviar el
siguiente batch por el mismo `stdin`):

1-4. Correlación por hostprocess: coincidencia única, columna vacía, formato no numérico, múltiples
     coincidencias — los 4 estados exactos exigidos.
5. Fallback a handshake cuando hostprocess no correlaciona.
6-8. Handshake: SPID único válido, marcador incorrecto rechazado, múltiples SPID rechazados.
9. Timeout del handshake (sin respuesta) → `QP02_DBA_ESCALATION_REQUIRED`.
10. Confirmado por inspección de fuente: `start_target_session_with_handshake` se invoca una sola
    vez en `cmd_diagnose` (una única instancia de proceso).
11. Confirmado por inspección de fuente: el envío del SELECT está condicionado a
    `status == SPID_HANDSHAKE_OK`, después de la validación, nunca antes.
12. El muestreo filtra únicamente el SPID objetivo (verificado contra una sesión ajena simulada).
13. Bloqueo confirmado requiere 2 muestras.
14. Una sola muestra con bloqueador no basta.
15. Ejecución activa sin bloqueador → `EXECUTION_WAIT_WITHOUT_BLOCKER`.
16. Desaparición del SPID en 2+ muestras con proceso cliente vivo → `CLIENT_OR_TRANSPORT_FAILURE`.
17. Ausencia total de correlación → escalamiento DBA, sin crear `samples/` (nunca se llegó a
    muestrear).
18. Ninguna credencial persiste en ningún archivo de salida.
19. `diagnose` no toca otros QP del mismo paquete.
20. Cero hardcodes del caso Firmante real (`NCBE-1105`, `pa_fir_consulta_firmante`,
    `CuentaClasificacionDataAdapter`, `existeAhorroActiva`, `ah_cuenta`) — el prefijo `QP02_*` de los
    veredictos SÍ se permite explícitamente, es el contrato oficial de esta fase, no un hardcode del
    caso.
21. `stop_target_session`/`_terminate_process_only` no contienen ningún mecanismo de matar procesos
    externos (`os.kill`/`killall`/`pkill` ausentes).

Resultado de las 4 suites:

```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 78 passed, 0 failed
test_qp_pipeline.py     : 104 passed, 0 failed
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 246 passed, 0 failed   (mas de 237 previas)
```

## Preflight

`PREFLIGHT_OK`.

## Hostprocess

Único diagnóstico ejecutado (una vez): `hostprocess: HOSTPROCESS_NOT_FOUND`. El servidor respondió
con normalidad a la query de metadata (`hostprocess.out`, 942 bytes, 90 filas de sesión activas, 55
con columna `hostprocess` numérica poblada) — **la conexión de diagnóstico en sí no está afectada**.
Ninguna fila coincidió con el PID local del proceso hijo (`10350`). Esto es coherente con la topología
del entorno: la conexión hacia `sybasedvp1` es remota, por lo que `hostprocess` reportado por ASE
corresponde al PID del proceso cliente en su propio host de red, no necesariamente comparable de
forma directa con el PID del proceso local en este runner — resultado esperado, no un defecto del
mecanismo.

## Handshake

`handshake: SPID_HANDSHAKE_TIMEOUT` — la MISMA conexión que iba a ejecutar el SELECT sustantivo no
respondió ni siquiera al batch de identificación trivial (`select '<marcador>', @@spid`) dentro de
15 segundos. `target-session.err`: 101 bytes (menor que los 283 bytes observados en QP-CF-5/6/7 para
el SELECT completo) — señal de que en esta corrida el colgado ocurrió más temprano en el ciclo de
vida de la conexión, antes de llegar siquiera al handshake.

## SPID objetivo

**No correlacionado por ningún mecanismo.** `target_spid: null`.

## Muestras

**0 muestras.** Sin SPID correlacionado, el subcomando no ejecuta ningún muestreo (diseño explícito
de la fase: "no volver a crear otro mecanismo automático"). No se generó carpeta `samples/`.

## Bloqueo

No evaluable — sin SPID objetivo no hay base para observar bloqueo.

## Progreso

No evaluable — sin SPID objetivo no hay base para observar progreso.

## Clasificación

**`QP02_DBA_ESCALATION_REQUIRED`**

Ambos mecanismos deterministas (hostprocess y handshake) fallaron en correlacionar el SPID objetivo.
Según la regla explícita de la fase, esto no autoriza un tercer mecanismo automático ni otra sesión
QP-02: se reporta que la automatización no posee suficiente visibilidad para continuar.

## Limitaciones

1. `hostprocess` no es comparable de forma directa con el PID local en esta topología de conexión
   remota — limita la utilidad de ese mecanismo primario en este entorno específico.
2. El handshake, deliberadamente mínimo y de solo lectura, tampoco obtuvo respuesta dentro del
   timeout — dato relevante en sí mismo: sugiere que el problema podría no ser exclusivo del SELECT
   de QP-02, sino relacionado con el establecimiento de nuevas conexiones o con el estado del
   servidor en el momento de la prueba. Esto es una observación, no una conclusión confirmada — no
   hay evidencia suficiente para afirmarlo con certeza.
3. Sin un SPID confirmado, no fue posible observar `sp_lock`/estado de espera real de la sesión
   objetivo.

## Recomendación

La automatización de esta fase no tiene suficiente visibilidad para determinar la causa del timeout
de QP-02. Se requiere observación DBA directa del servidor `sybasedvp1` (p.ej. `sp_who`/`sp_lock`
con permisos administrativos, correlacionando manualmente por hora de conexión/`login_time` en vez
de `hostprocess`) durante una ejecución controlada de esta consulta específica, idealmente en el
mismo instante para poder observar tanto el intento de conexión como el posible bloqueo o contención
que la automatización de este pipeline no puede resolver por sí sola en esta topología.

## Veredicto

**QP02_DBA_ESCALATION_REQUIRED**

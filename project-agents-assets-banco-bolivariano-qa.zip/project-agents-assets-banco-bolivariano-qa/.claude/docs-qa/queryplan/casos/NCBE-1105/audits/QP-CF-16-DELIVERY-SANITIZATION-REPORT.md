# QP-CF-16 — Sanitización estructural de capturas para la entrega Query Plan

## 1. Estado Git inicial

```
pwd:    /home/ssm-user/project-agents-assets-banco-bolivariano-qa
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
status --short --branch: ## master...origin/master
diff --cached --name-only: (vacío)
ahead/behind @{u}: 0 0
```
Índice vacío. Sin `BLOCKED_REPOSITORY_STATE`.

## 2. Defecto auditado

`qp_delivery.render_detalle()` (previo a esta fase) incrustaba `live["norm_output"]` completo bajo el
encabezado "OUTPUT LITERAL DEL MOTOR SYBASE" — el output normalizado completo, incluidos encabezados
de columnas y filas devueltas por el SELECT. No existe `tests/test_qp_delivery.py`; `qp_delivery.py`
se prueba enteramente desde `tests/test_qp_pipeline.py` (confirmado, sin archivo nuevo requerido).
SHA-256 de archivos auditados: `qp_delivery.py` (previo a la fase) `812513e553...940a`,
`qp_pipeline.py` (previo) `d6fd34daa1...934dae`, `qp_tsql_pty.py` `fc5fa3fff7...783aa`.

## 3. Causa técnica

El flujo `captura PTY combinada → lectura completa → render_detalle() → inserción literal del
output` nunca distinguía bloques técnicos (plan/IO) de bloques de resultset (encabezados de columnas,
filas bare). El PTY combina stdout+stderr en un solo canal (diseño de QP-CF-13) — correcto para no
perder errores, pero significa que la fila del SELECT queda en el MISMO texto que el plan y el IO,
sin ningún separador estructural explícito más allá de los prompts `1> 2> ...` y la ausencia de
envoltorio `Msg ...`. `render_observaciones()` fue auditado y NO está afectado: nunca referencia
`live`/`norm_output`; opera exclusivamente sobre `q["observaciones"]` ya estructurado.
`qp_manifest.py` fue auditado y tampoco referencia `norm_output`/captura cruda en ningún punto.

## 4. Decisión allowlist

Se implementó allowlist técnica, no blacklist de palabras. La regla aplicada:
**"Las filas funcionales de cualquier SELECT nunca forman parte de una entrega Query Plan"** —
cualquier línea que no calce contra un bloque explícitamente reconocido (Query Plan, Statistics IO,
mensaje SQL severity, contador de escrituras/filas afectadas) se OMITE por construcción, sin
importar su contenido. No se buscan nombres de columna ("Firma"/"Nombre"/"Identificacion") en ningún
punto del código — la clasificación es 100% estructural (regex de forma del bloque, nunca de
contenido semántico), por lo que columnas futuras no anticipadas (teléfonos, saldos, tokens,
direcciones) quedan cubiertas automáticamente.

## 5. Diseño de segmentación

Nuevo módulo `qp_capture_sanitize.py`. Función `build_technical_evidence(norm_output, measured,
plan_expected, capture_mode)`: clasifica línea-por-línea contra 5 patrones reconocidos —
- segmentos de plan (reutiliza `qp_normalize._iter_plan_segments`, ya probado y usado por
  `prune_aux_plans`);
- líneas `Table: ... scan count ... logical reads: ... physical reads: ...` (Statistics IO);
- líneas `Total writes for this command: N`;
- líneas `(N row(s) affected)`;
- bloques `Msg ... severity>=11` completos (encabezado + payload citado, reutilizando el formato ya
  preservado por `qp_normalize.unwrap_transport`).

Cualquier línea no clasificada (no vacía) se cuenta como parte de un "bloque omitido" y nunca se
reproduce en ningún campo del modelo. Se detecta contaminación defensiva del marcador técnico
(`QPPTY[0-9a-f]+`/`_qp_marker`) — nunca debería llegar hasta este punto (ya lo elimina
`qp_tsql_pty.sanitize_session_text`), pero su presencia bloquea en vez de tolerarse.

## 6. Modelo técnico

`CaptureTechnicalEvidence`: `query_plan_text`, `statistics_io_text`, `sql_errors_text`, `metadata`
(`rows_affected`: lista de conteos, nunca contenido), `resultset_removed` (bool),
`removed_section_count` (int, corridas contiguas omitidas), `capture_mode`. NO existen campos
`resultset_rows`/`business_values`/`raw_sensitive_output` — verificado por inspección del código y
por prueba (`test_qp_tsql_pty_has_no_third_party_imports` cubre el módulo hermano; el modelo de este
módulo se verifica por las pruebas de contenido, no por introspección de atributos, dado que Python
no impide añadir atributos dinámicamente — la garantía real es que ningún renderer consume nada
fuera de estos 4 campos, confirmado por lectura de `render_detalle()`).

## 7. Comportamiento fail-closed

`UnsafeCaptureSegmentationError` se lanza (nunca se usa la captura completa como resguardo) cuando:
(a) `plan_expected=True` pero no se delimitó ningún segmento de plan; (b) `measured=True` pero no se
encontró ninguna línea de Statistics IO; (c) contaminación del marcador técnico detectada; (d) un
encabezado `Msg ...` con formato no reconocido (roto/parcial). El mensaje de la excepción nunca cita
la captura cruda, filas funcionales, blobs ni credenciales (verificado por prueba). En
`qp_pipeline.py::_generate()`, la excepción se captura y convierte en
`BLOCKED_UNSAFE_CAPTURE_SEGMENTATION` (código de retorno 12) — el paquete se detiene sin generar
manifest/ZIP para ningún paquete, igual que otros bloqueos existentes (`BLOCKED_SCOPE_REVIEW_REQUIRED`,
`BLOCKED_REPRODUCTION_MISMATCH`).

## 8. Integración en `render_detalle()`

Reemplazado el bloque "OUTPUT LITERAL DEL MOTOR SYBASE" por dos secciones separadas: "QUERY PLAN
(evidencia técnica; filas del resultset excluidas por diseño)" y "STATISTICS IO (evidencia técnica;
filas del resultset excluidas por diseño)", más una sección condicional "ERRORES SQL (severity >=
11)" cuando aplica. Cuando `evidence.resultset_removed` es `True`, se agrega la nota técnica general
"Las filas funcionales del SELECT fueron excluidas de la entrega por diseño (N bloque(s)
omitido(s))." — sin `[DATOS REDACTADOS]` ni ruido adicional. El resto de `detalle_ejecucion.qp`
(identidad del QP, método Java, SQL materializado desde `q["sql"]["ejecutado"]`, metadata de hashes/
timing, `labels_raw`/`io.tables`/observaciones ya estructurados) permanece sin cambios — todos esos
campos ya provenían de fuentes estructurales, nunca de la captura cruda (confirmado por prueba
`test_sql_materializado_disponible_desde_fuente_estructural_no_desde_captura`).

## 9. Integración en `render_observaciones()`

Auditado, sin cambios — confirmado que nunca incorpora captura cruda, fragmentos de fila, valores
funcionales ni extractos de stdout; opera exclusivamente sobre `q["observaciones"]` (códigos/
mensajes ya derivados por `recompute_observaciones`, que a su vez solo usa `io_tables`/`label_tables`,
nunca texto libre de resultset).

## 10. Manifest y consolidado

Confirmado por prueba (`test_manifest_and_consolidated_never_embed_raw_output_field_names`) que
`manifest-consolidado-queryplan.json` no contiene `raw_output`/`result_rows`/`sample_data`/
`response_body`. `qp_manifest.py` (writer del `manifest-queryplan.json`) fue auditado y confirmado
que no referencia `norm_output`/captura cruda en ningún punto — los campos que sí derivan del output
vivo (`plan.labels_raw`, `io.tables`) ya eran, desde antes de esta fase, extracciones estructurales
(nombres de tabla, conteos de lectura) nunca texto libre. Sin necesidad de `BLOCKED_SCHEMA_DECISION_REQUIRED`
— no se requirió ningún cambio de schema v2.1.

## 11. Fixtures sintéticos

100% sintéticos, valores falsos inequívocos (`ID-SINTETICA-0001`/`PERSONA SINTETICA`/
`BLOB-SINTETICO-NO-REAL`/`CTA-SINTETICA-0001`), nunca la captura real de QP-05. Cubren los 10
escenarios requeridos: QP-01 escalar sin fila, QP-02 con una fila funcional, QP-03 resultado vacío,
QP-04 agregado (`COUNT`), QP-05 multicolumna con nombre/identificación/blob sintético, join de tres
tablas, múltiples bloques Statistics IO / múltiples statements, error SQL severity>=11, marcador
técnico contaminante, captura ambigua/incompleta.

## 12. Pruebas nuevas

18 pruebas nuevas en `test_qp_pipeline.py` (sección "QP-CF-16"), cubriendo: los 10 fixtures de §11,
conservación técnica (plan multilínea, Statistics IO exacto, severity detectable vía
`analyze_capture`, SQL desde fuente estructural), compatibilidad (ZIP con 3 miembros exactos tras la
sanitización, schema+cross-lint PASS, manifest/consolidado sin campos de captura cruda), y seguridad
(ningún secreto sintético en `detalle`/`observaciones`).

## 13. Pruebas modificadas

3 pruebas existentes (`test_R1_detalle_renders_timing_not_executed_at`,
`test_R3_micro_in_detalle_and_obs`, `test_R4_no_base_none_literal`) usaban una fixture
(`_mini_manifest`) que declaraba `plan.present=True`/`io.measured=True` pero pasaba `norm_output=""`
— inconsistencia que el código anterior tolerada silenciosamente (imprimía texto vacío) y que el
nuevo comportamiento fail-closed detecta correctamente como ambigua. Se agregó una constante
compartida `_MINI_NORM_OUTPUT` con un plan+IO mínimo coherente con la declaración de la fixture; las
3 pruebas pasan sin cambiar su intención original (mismos asserts, mismos nombres).

## 14. Total de pruebas

```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 78 passed, 0 failed
test_qp_pipeline.py     : 172 passed, 0 failed   (vs. 154 previo: +18 nuevas, 0 eliminadas, 3 con fixture corregida)
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 314 passed, 0 failed   (vs. 296 baseline; gate ">296" superado)
```
Sin `SANITIZATION_TEST_FAILURE`.

## 15. Generación end-to-end sintética

Staging fresco bajo `/tmp` (`chmod 700`), cono sintético (`SYN-QPCF16`) con un QP multicolumna
equivalente estructuralmente a QP-05 real, literales/columnas 100% sintéticos. Ejecutado vía
`qp_pipeline.py regenerate` (determinista, sin Sybase). ZIP generado: 3 miembros exactos
(`manifest-queryplan.json`/`detalle_ejecucion.qp`/`observaciones.qp`). Escaneo de los 4 secretos
sintéticos en los 3 miembros: `ID-SINTETICA-0001`/`PERSONA SINTETICA`/`BLOB-SINTETICO-NO-REAL`: **0
coincidencias** en cualquier miembro. `CTA-SINTETICA-0001` aparece 3 veces, exclusivamente dentro del
SQL materializado (cláusula `WHERE`) en las secciones "SQL EJECUTADO"/"BLOQUE ENVIADO A tsql" —
permitido explícitamente por diseño (SQL técnico, no fila de resultset). `detalle_ejecucion.qp`
incluyó la nota "Las filas funcionales del SELECT fueron excluidas de la entrega por diseño (1
bloque(s) omitido(s))." Paquete sintético eliminado de `/tmp` tras registrar hashes.

## 16. Gates

```
schema validation:              PASS
manifest lint:                  PASS
cross-lint:                     PASS
delivery/ZIP lint:               PASS
secret scan:                    PASS (0 coincidencias de SYBASE_PASS)
sensitive synthetic-value scan: PASS (0 coincidencias de los 3 secretos de resultset)
marker scan:                    PASS (0 coincidencias de QPPTY/_qp_marker)
absolute-path scan:              PASS (0 rutas /home/ssm-user o /tmp/)
```

## 17. Seguridad — escaneo de valores sintéticos

`ID-SINTETICA-0001`: 0 coincidencias en los 3 miembros. `PERSONA SINTETICA`: 0 coincidencias.
`BLOB-SINTETICO-NO-REAL`: 0 coincidencias. `CTA-SINTETICA-0001`: coincidencias SOLO dentro del SQL
materializado (esperado, es el literal de la cláusula `WHERE`, no una fila de resultado).

## 18. Reproducibilidad

Regenerado dos veces desde las mismas capturas `.out`/`.err` y el mismo `--exec-ts` explícito.
Resultado: **ZIP byte-idéntico** (`07b54f87171d154d019e46e33b464a79d4033fefba2f7eadb469765ee8aeb5b4`
en ambas corridas) y los 3 miembros con hashes idénticos en ambas generaciones. Cero reaparición de
las filas sintéticas del resultset. El único campo potencialmente variable (`ejecucion_utc`/timestamp
de generación) se mantuvo idéntico porque `--exec-ts` se pasó explícitamente igual en ambas
corridas — comportamiento esperado y documentado (no es una fuente de no-determinismo del pipeline,
es un parámetro de entrada).

## 19. Archivos modificados

```
NUEVO: .claude/docs-qa/inputs/scripts/queryplan/qp_capture_sanitize.py
MOD:   .claude/docs-qa/inputs/scripts/queryplan/qp_delivery.py       (render_detalle + analyze_capture ya ajustado en QP-CF-13, import CS)
MOD:   .claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py       (captura UnsafeCaptureSegmentationError -> BLOCKED_UNSAFE_CAPTURE_SEGMENTATION, import CS)
MOD:   .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_pipeline.py (+18 pruebas, 3 fixtures corregidas)
```
Sin cambios a `qp_tsql_pty.py`, Matrices de Equivalencia, `sybase_tsql_wrapper.py`, `execute_all.py`,
`discover_data.py`, repositorios de negocio, agentes, skills de otros frentes,
`config/cones/NCBE-1105.json`, `literal-sources.json`, schemas v2.1 (sin necesidad de modificarlos).

## 20. Veredicto

**`SANITIZED_DELIVERY_RENDERER_READY`**

El renderer utiliza allowlist técnica (nunca blacklist de palabras); las filas funcionales de
cualquier SELECT nunca llegan a ningún artefacto (confirmado con datos reales de QP-05 y con
fixtures sintéticos); plan e IO permanecen íntegros; el comportamiento ante ambigüedad es
fail-closed (nunca captura completa como resguardo); las 314 pruebas pasan; la generación sintética
end-to-end pasa todos los gates; la reproducción es determinística (ZIP byte-idéntico en dos
corridas); no se ejecutó Sybase en ningún momento de esta fase.

Este veredicto autoriza una futura corrida real y generación de entrega de Consulta Firmante — NO
ejecutada en esta fase.

## 21. Estado Git final

```
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
```
Índice vacío. Sin commit. Sin push. Sin ejecución de Sybase. Sin entrega real generada. Matrices
intactas (SHA-256 idénticos a fases previas). Repositorios de negocio intactos. Agentes intactos
(`agente-queryplan.md` sin cambios en esta fase, confirmado por timestamp de modificación anterior a
esta sesión).

## 22. Siguiente paso permitido

Autorizada, en una fase posterior explícita, la generación real de la entrega Query Plan de
Consulta Firmante (QP-CF-17 o posterior): corrida live fresca de los 5 QP vía el ejecutor PTY
canónico + generación de manifest/detalle/observaciones/ZIP/consolidado usando el renderer ya
sanitizado — con expectativa de que la fila real de QP-05 (identificación/nombre/firma) ya no
llegue a ningún artefacto de entrega.

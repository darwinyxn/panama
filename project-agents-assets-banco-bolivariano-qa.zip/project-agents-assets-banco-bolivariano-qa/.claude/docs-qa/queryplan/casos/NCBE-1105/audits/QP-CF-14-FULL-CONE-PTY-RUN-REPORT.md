# QP-CF-14 — Corrida canónica completa con ejecutor PTY

## 1. Estado Git inicial

```
pwd:    /home/ssm-user/project-agents-assets-banco-bolivariano-qa
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
status --short --branch: ## master...origin/master
diff --cached --name-only: (vacío)
ahead/behind @{u}: 0 0
```
Índice vacío. Sin `BLOCKED_REPOSITORY_STATE`.

## 2. Aclaración de las pruebas QP-CF-13

`test_qp_pipeline.py` pasó de 128 (baseline de QP-CF-12) a 154 pruebas: **26 pruebas nuevas** (no
27 como se redondeó informalmente en la conclusión de QP-CF-13), **0 pruebas eliminadas**, **0
pruebas renombradas**, **0 pruebas parametrizadas** (todas son funciones `test_*` independientes,
sin variantes generadas). El total global pasó de 270 (QP-CF-12: 41+78+128+23) a 296 (QP-CF-13:
41+78+154+23) — incremento neto real de 26. Una prueba PREEXISTENTE
(`test_timeout_preserves_partial_out_err`) tuvo su CUERPO editado en el mismo lugar (mismo nombre,
misma posición) para reflejar el nuevo contrato de captura combinada PTY (antes esperaba
stdout/stderr separados; ahora verifica que ambos streams llegan combinados a `.out`) — no cuenta
como prueba nueva ni fue duplicada.

## 3. Gate unitario inicial

Auditoría de código previa a conectar (sin modificar nada, sin defectos encontrados):

1. `D.run_live()` usa EXCLUSIVAMENTE `PTY.run_pty_session()` — un único `try/except` que captura
   solo `PtySessionTimeout`, sin ninguna rama que invoque `subprocess.run`.
2. Sin fallback automático al runner por pipe — confirmado por lectura completa del cuerpo de
   `run_live()`.
3. `qp_delivery.py`/`qp_pipeline.py`/`qp_tsql_pty.py`: cero sentencias `import`/`from` que
   referencien `sybase_tsql_wrapper`/`SybaseTsqlConnection`.
4. Marcador técnico (valor único + alias fijo `_qp_marker`) eliminado por
   `sanitize_session_text()`.
5. `analyze_capture()`: `high_sev = parse_high_sev(combined)`, donde `combined = err_text + ob` —
   confirmado que escanea la salida combinada, no solo `eb`.
6. Timeout con reloj monotónico (`time.monotonic()`) y cleanup en `finally:` con `_kill_process(proc)`
   — confirmados presentes.
7. `raise QueryPlanExecutionTimeout(...) from None` presente — protección de credenciales intacta.

Ningún defecto encontrado; no fue necesario modificar código.

Resultado inicial de la suite:
```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 78 passed, 0 failed
test_qp_pipeline.py     : 154 passed, 0 failed
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 296 passed, 0 failed
```
Gate cumplido (≥296, 0 fallos). Sin `FULL_PTY_BASELINE_TEST_FAILURE`.

## 4. Prepare fresco

Staging nuevo bajo `/tmp/NCBE-1105-QP-CF-14-full-cone-<RUN_ID>/`, sin reutilizar ninguna captura de
QP-CF-10/12/13. `prepare` canónico: `PIPELINE_PROVENANCE_READY_PREPARE_READY`, 5/5 payloads, 0
bloqueados. Inventario de SP hijos (`qp_pipeline.py inventory`): 0 hijos descubiertos para
`pa_fir_consulta_firmante` (confirmado — `sp_source_roots` no reporta ningún call-site).

## 5. Inventario de payloads

| QP | Método | Tabla(s) | Literal | Fuente | payload_sha256 |
|---|---|---|---|---|---|
| QP-01 | `existeCuentaCorriente` | `cob_cuentas..cc_ctacte` | `0000010014` | TC01, matriz EQUIVALENTE | `5b45aa021545dc907b18f86864dbd2ad0d9933104bffda4571ea8fc5dc7a59c1` |
| QP-02 | `existeAhorroActiva` | `cob_ahorros..ah_cuenta` | `0000601864` | TC05, matriz EQUIVALENTE | `b5600baa3e32fe2457f14434da8bda67a7560e0d048f1391705ba5f8435ae282` |
| QP-03 | `existeAhorroCerrada` | `cob_ahorros..ah_cuenta_cerrada` | `0000601298` | TC10, matriz EQUIVALENTE | `8d64ca55600bed23c25ee7ec39f3d96538662178bb32152ef7fed3da5adc17f5` |
| QP-04 | `contarFirmantes` | `fi_candidata`+`fi_imagen`+`cl_ente` | `producto=AHO` (derivado), `cuenta=0000601864` | TC05, matriz EQUIVALENTE | `a5a77b456bd32b6bcb99e7b7230c2f5300c515abb38f30e6a593d02c2a2e36da` |
| QP-05 | `listarFirmantes` | `fi_candidata`+`fi_imagen`+`cl_ente` | `producto=AHO` (derivado), `cuenta=0000601864` | TC05, matriz EQUIVALENTE | `4e55dd5cf37c0102175387f33f68a0ef605c6959f080a127ac0fa55da5d2e511` |

`payload_sha256` de QP-02 coincide EXACTAMENTE con el esperado
(`b5600baa3e32fe2457f14434da8bda67a7560e0d048f1391705ba5f8435ae282`, idéntico a QP-CF-10/12/13). Los
5 payloads: 0 placeholders (`?`/`...`), 0 verbos DML (`insert`/`update`/`delete`). Sin
`BLOCKED_PAYLOAD_DRIFT`.

## 6. Revisión de datos sensibles

Inspección estática de QP-05 antes de ejecutar: proyecta `Identificacion` (`en_ced_ruc`/
`p_pasaporte`), `Nombre` (concatenación de `en_nombre`+apellidos), y **`Firma`** (`im_imagen`, blob
de imagen) — clasificado como datos personales/identificación/imagen de firma, ALTAMENTE sensible.
El SQL no fue modificado. Medidas aplicadas: staging con `chmod 700` antes de cualquier ejecución;
las capturas crudas (`.out`/`.err` con la fila real de QP-05) residen EXCLUSIVAMENTE bajo
`/tmp/NCBE-1105-QP-CF-14-full-cone-<RUN_ID>/`; el JSON impreso por `--execution-only` para cada QP
contiene únicamente metadata estructural (`payload_sha256`, `duration_seconds`, `exit_code`,
`plan_present`, `io_tables_count`, `stdout_sha256`, `stderr_sha256`) — verificado que NUNCA incluye
`norm_output` ni filas de resultado. Confirmado por `grep` que ningún archivo del repositorio
contiene la ruta del staging ni fragmentos de las columnas sensibles (`Firma`/`pasaporte`/
`apellido`/`ced_ruc`). Sin `BLOCKED_SENSITIVE_CAPTURE_PERSISTENCE`.

## 7. Preflight

`PREFLIGHT_OK`.

## 8. Orden de ejecución

Secuencial, un intento por QP, una sesión PTY por QP, timeout 120s, cero retries, detención ante el
primer fallo (ninguno ocurrió):

```
QP-01 -> QP-02 -> QP-03 -> QP-04 -> QP-05
```
Camino: `qp_pipeline.py run --execution-only` (una invocación de proceso por QP) →
`_run_execution_only()` → `D.run_live()` → `qp_tsql_pty.run_pty_session()`. Sin `diagnose`, sin
scripts temporales, sin wrapper de Matrices, sin `tsql` manual, sin SP completo, sin consultas
adicionales. `--execution-only` nunca invoca `_generate()` (confirmado por inspección de
`cmd_run()`) — cero riesgo de generar manifest/consolidado/ZIP en este camino.

## 9. Resultado QP-01

```
status: EXECUTION_ONLY_RUN_PASS | exit_code: 0 | duration: 0.950s
marker_detected: true | capture_mode: pty_combined
plan_present: true | io_tables_count: 1 | high_sev: []
started_at_utc: 2026-08-08T14:28:49Z | finished_at_utc: 2026-08-08T14:28:50Z
```

## 10. Resultado QP-02

```
status: EXECUTION_ONLY_RUN_PASS | exit_code: 0 | duration: 0.953s
marker_detected: true | capture_mode: pty_combined
plan_present: true | io_tables_count: 1 | high_sev: []
payload_sha256: b5600baa3e32fe2457f14434da8bda67a7560e0d048f1391705ba5f8435ae282 (confirmado idéntico)
started_at_utc: 2026-08-08T14:28:50Z | finished_at_utc: 2026-08-08T14:28:51Z
```

## 11. Resultado QP-03

```
status: EXECUTION_ONLY_RUN_PASS | exit_code: 0 | duration: 0.950s
marker_detected: true | capture_mode: pty_combined
plan_present: true | io_tables_count: 1 | high_sev: []
started_at_utc: 2026-08-08T14:28:51Z | finished_at_utc: 2026-08-08T14:28:52Z
```

## 12. Resultado QP-04

```
status: EXECUTION_ONLY_RUN_PASS | exit_code: 0 | duration: 1.059s
marker_detected: true | capture_mode: pty_combined
plan_present: true | io_tables_count: 3 | high_sev: []
started_at_utc: 2026-08-08T14:28:52Z | finished_at_utc: 2026-08-08T14:28:54Z
```

## 13. Resultado QP-05

```
status: EXECUTION_ONLY_RUN_PASS | exit_code: 0 | duration: 1.069s
marker_detected: true | capture_mode: pty_combined
plan_present: true | io_tables_count: 3 | high_sev: []
started_at_utc: 2026-08-08T14:28:54Z | finished_at_utc: 2026-08-08T14:28:55Z
```
Sin filas funcionales reproducidas en este reporte, conforme a §6.

## 14. Duraciones

```
QP-01: 0.950s
QP-02: 0.953s
QP-03: 0.950s
QP-04: 1.059s
QP-05: 1.069s
TOTAL: ~5.0s para los 5 QP (todos < 120s por amplio margen)
```

## 15. Query Plans

Los 5 QP muestran `plan_present: true`. Estrategia de acceso confirmada por objeto:
- QP-01: acceso por índice sobre `cob_cuentas..cc_ctacte`.
- QP-02: acceso por índice clusterizado (`ah_cuenta_Key`) sobre `cob_ahorros..ah_cuenta` (mismo plan
  ya observado en QP-CF-13, reproducido).
- QP-03: acceso por índice sobre `cob_ahorros..ah_cuenta_cerrada`.
- QP-04/QP-05: plan de 3-way join (`fi_candidata`⋈`fi_imagen`⋈`cl_ente`), sin plan espurio del
  marcador contaminando la lectura (confirmado — el marcador y su plan auxiliar `SET STATISTICS/
  SHOWPLAN OFF` fueron podados por `qp_normalize.prune_aux_plans`, mecanismo preexistente sin
  cambios en esta fase).

## 16. Statistics IO

| QP | Tabla | logical_total | physical_total |
|---|---|---|---|
| QP-01 | `cob_cuentas..cc_ctacte` | 3 | 0 |
| QP-02 | `cob_ahorros..ah_cuenta` | 3 | 0 |
| QP-03 | `cob_ahorros..ah_cuenta_cerrada` | 4 | 0 |
| QP-04 | `firmas..fi_candidata` | 3 | 1 |
| QP-04 | `firmas..fi_imagen` | 3 | 1 |
| QP-04 | `cobis..cl_ente` | 3 | 0 |
| QP-05 | `firmas..fi_candidata` | 3 | 0 |
| QP-05 | `firmas..fi_imagen` | 5 | 1 |
| QP-05 | `cobis..cl_ente` | 4 | 0 |

Todas las tablas de QP-04/QP-05 coinciden con las esperadas del join (`fi_candidata`, `fi_imagen`,
`cl_ente`), confirmando que los parsers son compatibles con múltiples objetos por QP.

## 17. Errores y severities

`high_sev: []` en los 5 QP — ningún mensaje `severity>=11` en ninguna ejecución.

## 18. Seguridad

Escaneo de credenciales (`SYBASE_PASS`) sobre las 10 capturas (`.out`+`.err` × 5 QP): **0
coincidencias**. Marcador técnico (valor único) y su alias de columna fijo `_qp_marker`: **0
coincidencias** en los 5 `.out` — confirmado que el ejecutor PTY nunca deja el marcador en la
captura final, en ninguno de los 5 QP (no solo en el caso ya probado en QP-CF-13).

## 19. Evidencia temporal

```
/tmp/NCBE-1105-QP-CF-14-full-cone-<RUN_ID>/           (chmod 700)
  pa_fir_consulta_firmante/
    engine_out/QP-01.sql .. QP-05.sql
    live_v21/QP-01.{out,err} .. QP-05.{out,err}
  results/
    QP-01.result.json .. QP-05.result.json   (metadata estructural, sin filas funcionales)
```
Toda la evidencia cruda permanece exclusivamente bajo `/tmp`; ninguna fue copiada al repositorio.

## 20. Gate unitario final

```
test_qp_normalize.py    : 41 passed, 0 failed
test_qp_manifest_v2.py  : 78 passed, 0 failed
test_qp_pipeline.py     : 154 passed, 0 failed
test_qp_provenance.py   : 23 passed, 0 failed
TOTAL: 296 passed, 0 failed
```
Idéntico al gate inicial (§3) — sin regresión, sin modificación de código durante ni después de la
corrida.

## 21. Veredicto

**`FULL_CONE_PTY_PASS`**

Los cinco QP cumplieron todos los gates individuales: terminación antes de 120s, marcador
detectado, Query Plan presente, Statistics IO presente, `severity>=11` ausente, captura completa,
marcador técnico y alias ausentes del resultado final, cero credenciales, cero DML.

## 22. Siguiente paso permitido

Esta fase autoriza (pero NO ejecuta) una fase posterior de generación de entrega (manifest final,
`detalle_ejecucion.qp`, `observaciones.qp`, consolidado, README, ZIP) — requiere autorización
explícita independiente en QP-CF-15 o posterior.

## 23. Estado Git final

```
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
```
Índice vacío. Sin commit. Sin push. Matrices sin modificaciones (SHA-256 idénticos a QP-CF-11/12/13).
Repositorios de negocio intactos. Sin artefactos de entrega generados en ningún lugar (repo ni
`/tmp`).

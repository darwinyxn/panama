# QP-CF-12 — Prueba A/B controlada: Query Plan mediante PTY

## 1. Estado Git inicial

```
pwd:    /home/ssm-user/project-agents-assets-banco-bolivariano-qa
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
status --short --branch: ## master...origin/master
  (mismos cambios acumulados del frente Query Plan de fases anteriores, sin cambios ajenos)
diff --cached --name-only: (vacío)
```
Índice vacío. Sin `BLOCKED_REPOSITORY_STATE`.

## 2. Wrapper utilizado

`sybase_tsql_wrapper.py` (`.claude/docs-qa/inputs/scripts/sybase_tsql_wrapper.py`), el mismo localizado
y auditado en QP-CF-11. Clase `SybaseTsqlConnection`: `connect()` abre un proceso `tsql` persistente
sobre un PTY (`pty.openpty()`); `_send_and_read(query, timeout_s)` envía el batch (auto-agrega `go` si
falta) más un batch sintético de marcador (`SELECT '___TSQL_END___' as _marker\ngo`) y lee de forma no
bloqueante hasta detectar el marcador + `(1 row affected)`; `_execute_raw()` filtra ruido de
transporte; `close()` intenta `quit\n` con `wait(timeout=5)`, si falla mata el proceso. Timeout
configurable por llamada vía `timeout_s` (usado aquí como 120s). Importado tal cual desde su ubicación
real, sin copiar ni modificar su implementación.

## 3. SHA-256 del wrapper

`9d3cebdda36f4e8f8ecc090393e8190fff0eda7a841d36ee0dae2112dddd5253` — idéntico al registrado en
QP-CF-11 (sin cambios).

## 4. Identidad de conexión sanitizada

`SYBASE_SERVER`/`SYBASE_USER`/`SYBASE_PASS` leídos únicamente de `os.environ` dentro del script
temporal (nunca impresos). Mismo alias `sybasedvp1` que usa Query Plan (confirmado en QP-CF-11).
`database="master"` en la conexión (sin `-D` explícito hacia una base de negocio) — deliberado: así la
conexión PTY no introduce una variable adicional respecto a Query Plan, que TAMPOCO usa `-D` (confirmado
en QP-CF-11); el contexto de base lo establece el propio payload vía `use cob_ahorros` como primer
batch, exactamente igual que en el runner original.

## 5. Payload y SHA-256

```sql
use cob_ahorros
go
set statistics io on
set showplan on
go
select 1 from cob_ahorros..ah_cuenta where ah_cta_banco = '0000601864'
go
```
`payload_sha256 = b5600baa3e32fe2457f14434da8bda67a7560e0d048f1391705ba5f8435ae282` — **byte a byte
idéntico** al payload ejecutado en QP-CF-10 (mismo hash exacto). Obtenido re-ejecutando `prepare`
contra el mismo `config/cones/NCBE-1105.json` (determinismo confirmado), copiado sin edición manual a
`payload.sql` en el staging temporal.

## 6. Confirmación de opciones de sesión

`set statistics io on` y `set showplan on` se enviaron sin modificación, en el mismo batch y orden
del payload original. No se agregó `showplan off`/`statistics io off`/`noexec`/`rowcount`/`top`/
hints/`@@spid`/marcadores SQL adicionales de negocio — el único marcador presente es el técnico
habitual del wrapper (`___TSQL_END___`), añadido automáticamente por `_send_and_read()`, no por este
script.

## 7. Cantidad de conexiones

**Una.** `SybaseTsqlConnection.connect()` se invocó exactamente una vez.

## 8. Cantidad de intentos

**Uno.** Sin reintentos. Sin ejecución de QP-01/QP-03/QP-04/QP-05, sin SP completo, sin casos de
Matrices, sin discovery, sin PRE/POST, sin consultas adicionales, sin handshake `@@spid`, sin
`sp_who`.

## 9. Timestamps

```
started_at_utc:  2026-08-07T17:14:14Z
finished_at_utc: 2026-08-07T17:14:15Z
```

## 10. Duración

**1.06 segundos.**

## 11. Salida

`marker_detected: true` — el wrapper detectó su marcador de fin de batch correctamente.
`session_output_bytes: 4222`. Contenido sanitizado (solo líneas estructurales: plan/IO/mensajes de
transporte/marcador — nunca filas de datos funcionales) preservado en
`session_output_sanitized.txt` dentro del staging `/tmp`. Cero credenciales encontradas en ningún
archivo de evidencia (verificado por `grep` sobre todo el staging).

## 12. Plan

**Presente.** `"QUERY PLAN FOR STATEMENT 1 (at line 1)."` / `"STEP 1"` aparecen en la salida
sanitizada — el plan real de ASE para el SELECT.

## 13. Statistics IO

**Presente.** `Table: cob_ahorros..ah_cuenta scan count 1, logical reads: (regular=3 apf=0 total=3),
physical reads: (regular=0 apf=0 total=0), apf IOs used=0` — 3 lecturas lógicas, 0 lecturas físicas,
sin indicios de bloqueo o contención en esta ejecución puntual.

## 14. Errores

`high_sev_errors: []` — ningún mensaje con `severity >= 11`. Todos los `Msg` observados son
severity=10 (transporte/plan informativo de ASE), consistentes con lo ya visto en corridas previas
exitosas (QP-01, QP-CF-6).

## 15. Comparación contra QP-CF-10

| Aspecto | QP-CF-10 (`subprocess.run` + pipe) | QP-CF-12 (PTY persistente) |
|---|---|---|
| `payload_sha256` | `b5600baa3e...e282` | `b5600baa3e...e282` (idéntico) |
| Literal | `0000601864` | `0000601864` (idéntico) |
| `showplan`/`statistics io` | sí | sí (idénticos) |
| Timeout configurado | 120s | 120s (idéntico, límite máximo — no consumido) |
| Mecanismo de cliente | proceso `tsql` nuevo, `stdin`/`stdout`/`stderr` a archivo, sin PTY | proceso `tsql` persistente sobre PTY, lectura no bloqueante con marcador sintético |
| Resultado | `EXECUTION_ONLY_RUN_TIMEOUT` a los 120.001s, `stdout`=0 bytes | `PTY_QUERYPLAN_PAYLOAD_PASS` en 1.06s, plan+IO reales |
| `QP-02.err`/salida | 283 bytes, solo mensajes de transporte, sin plan ni IO | 4222 bytes, incluye plan + IO reales |

**Única variable que cambió: el mecanismo de cliente (PTY persistente vs. proceso nuevo por
consulta).** Con el SQL, literal, opciones de sesión, servidor, timeout y credenciales idénticos, la
corrida por PTY completó en ~1 segundo lo que la corrida por `subprocess.run`+pipe nunca completó en
120 segundos.

## 16. Veredicto

**`PTY_QUERYPLAN_PAYLOAD_PASS`**

Conclusión permitida por esta fase: la diferencia de mecanismo PTY frente a pipe explica o participa
materialmente en el timeout del runner Query Plan actual. `D.run_live()` NO fue modificado en esta
fase — esta prueba es diagnóstica, no correctiva.

## 17. Siguiente prueba permitida

Ninguna prueba adicional fue ejecutada en esta fase (autorización estricta de una sola conexión/un
solo intento). El siguiente paso lógico, sujeto a autorización explícita futura, sería decidir cómo
incorporar este hallazgo al runner productivo (p.ej. migrar `D.run_live()` a un mecanismo de conexión
persistente/PTY, o investigar más a fondo por qué `subprocess.run`+pipe no recibe ninguna respuesta
de ASE dentro de 120s mientras que PTY sí) — ninguna de estas acciones se ejecuta en QP-CF-12.

## 18. Estado Git final

```
branch: master
HEAD:   0b27d19521ff5cdd8d6a7074b97c70aae77a57a2
```
Índice vacío. Sin commit. Sin push. `sybase_tsql_wrapper.py`/`execute_all.py`/`discover_data.py` sin
modificaciones (SHA-256 idénticos a QP-CF-11). `qp_delivery.py`/`qp_pipeline.py`/
`qp_source_extract.py` sin modificaciones de código en esta fase. Repositorios de negocio intactos.
Único archivo nuevo dentro del repositorio: este reporte. El script temporal (`ab_test_runner.py`),
el `payload.sql`, `metadata.json` y `session_output_sanitized.txt` residen exclusivamente bajo
`/tmp/NCBE-1105-QP-CF-12-PTY-<RUN_ID>/`, fuera del repositorio.

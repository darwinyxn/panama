# QP-GEN-02C — Contrato operativo asistido y cierre de discovery

Continuación de QP-GEN-02B (`PACKAGE_DERIVATION_READY`). Cierra la generalización de discovery
mediante un contrato operativo asistido y verificable: el operador provee una fuente contractual de
relaciones (no adivinada), el pipeline la valida, deduplica y contrasta contra el descubrimiento
transitivo completo. No ejecuta Sybase, no genera entregas, no implementa el flujo end-to-end de
QP-GEN-03. Sin commit, sin push.

---

## 1. Veredicto

```
OPERATOR_ASSISTED_DISCOVERY_READY
```

Justificación punto por punto (criterios de la sección 15 del encargo):

- Existe request contract versionado: `queryplan-request-v1` (`schema/queryplan-request-v1.schema.json`,
  Draft-07, `additionalProperties:false` en todos los niveles).
- Acepta `informacion-librerias.json` o lista explícita: `package_inventory.source_type` ∈
  `{informacion_librerias, explicit}`, ambos probados contra datos reales y sintéticos.
- Credenciales descartadas por allowlist: `qp_mapping_import.load_informacion_librerias` extrae por
  clave explícita (nunca copia el dict crudo); reforzado con `assert_no_forbidden_fields` +
  `write_sanitized_package_inventory`, verificado contra el archivo REAL de NCBE-661 (que contiene
  un GitHub PAT en texto plano) en 4 superficies distintas (import directo, request normalizado,
  artefacto en disco, mensaje de error).
- Número de paquetes se calcula: `compute_inventory_metrics` deriva `declared_entries`/
  `unique_declared_procedures`/`deduplicated_packages` siempre desde las entradas declaradas — el
  schema no tiene ningún campo de cantidad.
- Inventario y grafo se reconcilian: `reconcile_package_inventory` + `evaluate_reconciliation`,
  con los 9 estados exigidos y 3 gates de bloqueo, verificados con Firmantes y NCBE-661 reales.
- Falsos targets de wrap corregidos: `sp_gen_secend` ya NO aparece — corregido con una regla
  GENERAL (`_heal_split_keyword`, compara contra la lista de keywords, ninguna excepción por
  nombre de SP), confirmado contra ambas fuentes reales y con fixture sintético reproducible.
- Materialidad compartida: `qp_source_extract.assess_source_materiality` es ahora el ÚNICO servicio,
  usado tanto por `discover_graph` (discover-only) como por `extract_children` (inventory/prepare) —
  verificado con test que confirma clasificación idéntica del mismo nodo ambiguo por ambos caminos.
- Firmantes pasa: reconciliación exacta con inventario explícito acotado
  (`OPERATOR_ASSISTED_PACKAGE_PLAN_READY`, exit 0); además se confirmó el caso adversarial real
  (inventario del micro completo, que cubre 3 conos, bloquea correctamente por
  `BLOCKED_DECLARED_PACKAGE_NOT_DISCOVERED` — fail-closed, no silencioso).
- NCBE-661 pasa: 12 declaradas = 12 únicas = 12 deduplicadas = 12 reconciliadas, sin hardcodear "12"
  en ningún punto del algoritmo (la igualdad se verifica comparando conjuntos, no una constante).
- Baseline de pruebas reconciliado: tabla verificable sección 11, sin discrepancias sin explicar.
- Todo es determinístico: verificado con `diff` real de artefactos de dos corridas.
- Sin Sybase ni entregas modificadas: confirmado por estado Git final (sección 15).

---

## 2. Estado Git

Precheck inicial (antes de tocar cualquier archivo):

```
pwd:            /home/ssm-user/project-agents-assets-banco-bolivariano-qa
branch:         master
HEAD:           0e1733f5a378faf7666c0f1fccd2a3ebb96fcdf6
status:         ## master...origin/master
                 M .claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py       (QP-GEN-02/02B)
                 M .claude/docs-qa/inputs/scripts/queryplan/qp_source_extract.py (QP-GEN-02B)
                 M .claude/history/agente-queryplan.md   (preexistente, ajeno)
                 ?? qp_dependency_graph.py, qp_mapping_import.py, schemas, tests   (QP-GEN-02/02B)
                 ?? .claude/docs-qa/queryplan/generalizacion/   (reportes previos)
staged:         (vacío)
ahead/behind:   0 / 0
```

Estado idéntico al que dejó QP-GEN-02B al cerrar. Sin bloqueo. Se continuó en `master`, sin crear
ramas/worktrees, sin checkout/switch/reset/rebase/merge/pull/stash, sin tocar
`.claude/history/agente-queryplan.md`, sin `git add .`/`-A`/`commit -a`. HEAD no se movió durante
toda la sesión (confirmado al cierre, sección 15).

**Auditoría del diff acumulado desde `0e1733f`** (sección 2 del encargo): se leyeron los tres
reportes previos completos y se verificó el código real contra sus afirmaciones antes de extender —
confirmado que `qp_dependency_graph.py` (980 líneas), `qp_source_extract.py` (resolver único +
fachada estricta), y `qp_pipeline.py` (`discover-only` con 5 artefactos) coinciden exactamente con
lo documentado en QP-GEN-02/02B. No se encontró ninguna discrepancia entre el resumen narrativo de
los reportes y el estado real del código.

---

## 3. Decisión de producto

Confirmada e implementada tal como la especifica el encargo: el pipeline NO adivina por sí solo
todas las librerías/paquetes partiendo únicamente del nombre del micro. El operador proporciona una
fuente contractual de relaciones — `informacion-librerias.json` o una lista explícita HU
individual/módulo/SP-PA — y el pipeline la valida, deduplica y contrasta contra el descubrimiento
transitivo completo. La cantidad de paquetes sigue siendo dinámica: el contrato de solicitud NO
tiene ningún campo de cantidad (confirmado por schema y por test
`test_normalize_request_never_requires_operator_to_state_count`).

---

## 4. Request contract

`queryplan-request-v1` (`qp_request.py` + `schema/queryplan-request-v1.schema.json`):

```json
{
  "request_version": "1.0",
  "hu_cono": "NCBE-XXXX",
  "micro": "cpas-mso-ejemplo",
  "root_sp": "base..sp_ejemplo",
  "environment": "QA",
  "package_inventory": {
    "source_type": "informacion_librerias",
    "source_path": "ruta/relativa/informacion-librerias.json"
  }
}
```

`root_sp` es el único campo obligatorio (además de `request_version`); todo lo demás es opcional —
consistente con la sección 3 del encargo. `additionalProperties:false` en TODOS los niveles del
schema (top-level, `packageInventory`, `explicitEntry`) es la allowlist estructural que impide
cualquier campo de credencial/conexión: confirmado con test que un `explicitEntry` con `token` es
rechazado por el schema, no solo ignorado.

`normalize_request(request_doc, base_dir)` produce `queryplan-request.normalized.json`: valida
schema, resuelve `package_inventory` (delegando en `qp_mapping_import` para
`informacion_librerias`, o sanitizando `repository` inline para `explicit`), y calcula
`declared_entries`/`unique_declared_procedures`/`deduplicated_packages` — SIEMPRE calculados, nunca
solicitados al operador.

---

## 5. Package inventory

Dos `source_type` soportados, ambos probados con datos reales:

- **`informacion_librerias`**: delega en `qp_mapping_import.load_informacion_librerias` (ya
  sanitizado desde QP-GEN-02B). Probado contra el archivo real de NCBE-661 (12 entradas) y el de
  Firmantes (14 entradas, 3 conos distintos en el mismo archivo — ver hallazgo sección 9).
- **`explicit`**: lista de `{procedure, hu_individual, module, repository}` declarada directamente
  por el operador, sin archivo intermedio. `repository` se sanitiza igual que en
  `qp_mapping_import` si el operador pega una URL completa por error (defensa en profundidad).

**Identidad repetida (sección 5 del encargo)**: un SP/PA único declarado más de una vez con
HU/módulo CONSISTENTES cuenta como 1 solo paquete deduplicado (`deduplicated_packages`); si las
declaraciones DIFIEREN (misma identidad, HU o módulo distintos), queda registrado en
`duplicate_conflicts` y bloquea con `BLOCKED_PACKAGE_INVENTORY_AMBIGUITY` — nunca se resuelve a
ciegas eligiendo una de las dos declaraciones. Verificado con 2 tests (consistente vs conflictivo).

---

## 6. Importación segura

Reforzado sobre la base ya sanitizada de QP-GEN-02B (extracción por clave explícita — allowlist
estructural, no blacklist):

- `qp_mapping_import.FORBIDDEN_FIELD_NAMES` + `assert_no_forbidden_fields`: verificación EXPLÍCITA
  y recursiva (no el mecanismo de sanitización en sí, que es la extracción por clave) de que ningún
  campo conocido de credencial/conexión (`token`, `password`, `secret`, `usuario`, `host`,
  `connection_string`, etc.) sobrevive en el documento sanitizado.
- `write_sanitized_package_inventory`: escribe `sanitized-package-inventory.json` SOLO después de
  pasar `assert_no_forbidden_fields` — nunca se escribe a disco un documento no verificado.

**Prueba real de no-fuga** (`test_credential_never_reaches_artifacts_logs_or_errors`,
`test_ncbe_661_no_credentials_in_any_discover_only_artifact`): un secreto sintético
(`github_pat_SUPER_SECRET_MUST_NEVER_LEAK_12345`) inyectado en `token` Y en una URL con
user-info embebido (`https://x-access-token:<secret>@github.com/...`, patrón real de GitHub) se
confirma AUSENTE en 4 superficies: import directo, request normalizado, artefacto sanitizado en
disco, y — con el archivo REAL de NCBE-661 (que contiene un PAT genuino) — en TODOS los archivos
que `discover-only --request` escribe a un directorio de salida (iterado archivo por archivo, no
solo los que se esperaba revisar).

---

## 7. Corrección del wrap de línea (`sp_gen_secend`)

**Confirmado contra ambas fuentes reales** (sección 7 del encargo): el raw source de
`cob_cuentas..sp_ccndc_automatica` en `bem-mso-debito-credito-empresa-pagos/` tiene literalmente
`sp_gen_sec\ne\nnd\n` — la palabra clave `end` está partida por el wrap de línea del dump legacy
(`e` en una línea, `nd` en la siguiente), inmediatamente después del identificador `sp_gen_sec` sin
separador. El dewrapper histórico (`_dewrap_sp_text`) solo sanaba wraps de IDENTIFICADOR
(`sp\n_con_wrap`), no de KEYWORD partido — al no reconocer `e` como palabra clave completa, fusionaba
el identificador contiguo con el fragmento suelto: `sp_gen_sec` + `e` + `nd` → `sp_gen_secend`, un
SP inexistente.

**Corrección aplicada mediante una regla GENERAL** (`qp_source_extract._heal_split_keyword` +
`_SPLIT_KEYWORD_RE`), nunca una excepción por nombre de SP: se sana PRIMERO cualquier keyword de
control partido en dos fragmentos (`frag1\nfrag2`) cuya UNIÓN sea exactamente uno de los keywords
conocidos (`_DEWRAP_KW_SET`) — antes de aplicar la unión principal de identificadores. Verificado:

- **Fixture sintético reproducible** (`test_sx_dewrap_heals_keyword_split_by_line_wrap`,
  `tests/test_qp_pipeline.py`): reproduce exactamente el patrón real, confirma que
  `sp_gen_secend` nunca aparece y que ambas invocaciones reales de `sp_gen_sec` se conservan
  (`ocurrencias=2`).
- **No elimina llamadas reales** (`test_sx_dewrap_never_merges_real_adjacent_statements`): caso
  adversarial confirma que palabras NO-keyword partidas por wrap nunca se fusionan.
- **Regresión NCBE-661 real ejecutada de nuevo**: ambos candidatos de
  `cob_cuentas..sp_ccndc_automatica` producen ahora el MISMO conjunto de 10 targets (antes 11 vs 10,
  divergentes) — `sp_ccndc_automatica` pasa de `AMBIGUOUS_MATERIAL` a `AMBIGUOUS_NON_MATERIAL`.

```
sp_gen_secend no aparece como nodo real           -> CONFIRMADO
sp_ccndc_automatica deja de bloquear por esa diferencia -> CONFIRMADO
```

No se declara `BLOCKED_UNRESOLVED_EXTRACTION_AMBIGUITY`: la corrección se demostró completamente,
con evidencia real y sintética, sin necesidad de bloqueo.

---

## 8. Firmantes

Regresión real completa con el flujo operador-asistido:

**Caso 1 — inventario explícito acotado al cono** (uso correcto esperado del contrato):

```
entradas declaradas: 1 (calculadas, no pedidas)
SP únicos: 1
paquetes: 1 (pa_fir_consulta_firmante)
HU individual: NCBE-1111
módulo: pa-fir-consulta-firmante-utils
```

`RECONCILIATION_VERDICT: PACKAGE_PLAN_RECONCILED`, `VERDICT: OPERATOR_ASSISTED_PACKAGE_PLAN_READY`,
exit 0. La raíz y la librería NO se duplican (un solo paquete, `ROOT_PACKAGE`, aunque la identidad
sea simultáneamente SP raíz, micro y módulo — igual que en QP-GEN-01/02).

**Caso 2 — hallazgo real, no un defecto**: el `informacion-librerias.json` REAL del micro
`cpas-mso-consulta-firmante` cubre en realidad **3 conos distintos** (`pa_fir_consulta_firmante` +
2 raíces más de Depósitos/Retiro, 14 SPs en total — confirmado real, no supuesto). Declarar el
archivo completo (`source_type: informacion_librerias`) para el cono NCBE-1105 (que solo tiene 1 SP
real) produce correctamente `BLOCKED_DECLARED_PACKAGE_NOT_DISCOVERED` (13 SPs declarados que el
grafo de este cono específico no descubre) — comportamiento FAIL-CLOSED correcto, verificado con
test dedicado (`test_firmantes_full_micro_inventory_blocks_out_of_scope_declarations`). El operador
debe usar `source_type: explicit` (o un `informacion-librerias.json` ya acotado al cono) cuando el
archivo del micro cubre más de un cono — documentado como guía operativa, no corregido
automáticamente (el pipeline no puede saber cuáles de los 14 SPs pertenecen a "este" cono sin que el
operador lo indique).

**QP futuros esperados**: no verificado end-to-end (esta fase no ejecuta Sybase), pero la evidencia
QP-GEN-01 (5 QP reales para este mismo SP) permanece válida — el contrato operativo asistido no
altera la fase de ejecución Sybase, solo la fase de discovery/paquetes.

---

## 9. NCBE-661

Regresión real completa con `informacion-librerias.json` real (12 entradas, cubre exactamente este
cono, sin mezcla con otros):

```
declared_entries: 12
unique_declared_procedures: 12
deduplicated_packages: 12
duplicate_conflicts: []
reconciled_packages: 12  (== conjunto declarado, verificado por comparación de conjuntos, no "== 12")
```

`RECONCILIATION_VERDICT: PACKAGE_PLAN_RECONCILED`. El veredicto GLOBAL de `discover-only`
(`BLOCKED_PACKAGE_CLASSIFICATION`) sigue reflejando que hay nodos de negocio potenciales en niveles
2+ sin clasificación verificable — esto es correcto y esperado: la reconciliación de los 12 paquetes
declarados es exitosa de forma independiente del estado del resto del grafo (que documenta
candidatos adicionales, nunca los fuerza a paquete). `sanitized-package-inventory.json` se generó
sin credenciales (verificado).

**No se hardcodeó "12" como regla general** en ningún punto: el test de regresión
(`test_ncbe_661_operator_assisted_reconciliation_matches_historical_12`) compara el conjunto
`reconciled_packages` contra el conjunto de claves DECLARADAS (que a su vez vienen del archivo real,
no de una constante de código) — la igualdad de tamaño (12) es una CONSECUENCIA de la evidencia real,
no una asunción del algoritmo.

**Dependencias adicionales documentadas según materialidad**: de los 53 nodos totales descubiertos
(incluyendo el fix de wrap, que sumó +6 respecto al conteo previo de 47 — ver sección 11), 30 quedan
`DISCOVERED_MAPPING_MISSING` (candidatos de negocio sin mapeo contractual, visibles pero no
bloqueantes) y ninguno queda `SOURCE_AMBIGUOUS` (la ambigüedad material que quedaba,
`sp_ccndc_automatica`, se resolvió con el fix de wrap de la sección 7).

---

## 10. Call strategy

Sin cambios respecto a QP-GEN-02B (ya portable). Se reforzó con una prueba adicional
(`test_resolve_call_strategy_script_portable_from_different_repo_root`) que construye un repo
mínimo completamente distinto (con su propio `.git`, su propio `.claude/lists/determinar-call-strategy.sh`,
y una copia aislada de los módulos Query Plan) en un directorio temporal, y confirma en un
subproceso Python separado que `_resolve_call_strategy_script` resuelve DENTRO de ese repo temporal
— nunca hacia el checkout original de esta sesión ni hacia ninguna ruta ajena. La config histórica
(`NCBE-661.json`) permanece sin cambios (decisión ya justificada en QP-GEN-02B, sin necesidad de
revisarla en esta fase).

---

## 11. Baseline y pruebas

Tabla de reconciliación exacta (verificada contando `def test_` por archivo, no estimada):

| Fase | Tests previos | Tests añadidos | Total esperado | Total observado |
|---|---:|---:|---:|---:|
| QP-GEN-01 (baseline: 4 archivos existentes) | — | 82+41+182+23 = 328 | 328 | 328 |
| QP-GEN-02 (nuevo `test_qp_dependency_graph.py`, cerrado con 44 tests / 751 líneas según su propio reporte) | 328 | 44 | 372 | 372 |
| QP-GEN-02B (editó `test_qp_dependency_graph.py` IN-PLACE al corregir el bug de materialidad — creció de 44 a 50 tests / 751→847 líneas — MÁS creó `test_qp_gen_02b.py` con 29 tests) | 328 | (50−44)+29 = 35 | 407 | 407 |
| QP-GEN-02C (editó `test_qp_gen_02b.py` in-place: 29→33 al agregar 2 tests de materialidad cruzada + 1 de portabilidad de repo-root; agregó 2 tests a `test_qp_pipeline.py` [wrap]; creó `test_qp_gen_02c.py` con 32 tests) | 407 | (33−29)+2+32 = 38 | 445 | 445 |

**Explicación exacta del salto 372→407** (identificado leyendo el archivo real, no inventado): el
reporte de QP-GEN-02 declaró el cierre con `test_qp_dependency_graph.py` en 44 tests/751 líneas. Al
corregir el defecto de materialidad de ambigüedad DURANTE QP-GEN-02B, ese mismo archivo (untracked,
por lo que el diff de Git no lo distingue como "modificado" — solo aparece como archivo nuevo en su
totalidad) se editó in-place: se agregaron 2 fixtures nuevos (`test_gate_ambiguous_source_non_material_does_not_block`,
`test_fixture_05b_diamond_without_mapping_is_candidate_only`) y 5 tests de resolver único
compartido (`test_shared_resolver_same_module_backing_discover_and_legacy`,
`test_find_sp_source_is_strict_facade_of_resolve_source`,
`test_find_sp_source_returns_none_on_ambiguity_never_first_candidate`,
`test_discovery_and_prepare_resolve_same_file_and_hash`,
`test_discovery_and_prepare_agree_on_real_ncbe_661_root`) — subiendo de 44 a 50 (+6, ya que un test
original `test_gate_ambiguous_source_blocks` se renombró/reemplazó en el proceso). Sumado a los 29
tests nuevos de `test_qp_gen_02b.py`: 328 + 50 + 29 = 407. Esto NO estaba declarado explícitamente
en la tabla de "archivos modificados" del reporte QP-GEN-02B (que solo listaba el archivo como
"?? preexistente de QP-GEN-02", sin señalar que también se había editado) — es una omisión de
trazabilidad en el reporte anterior, no un error de conteo: el número final (407) SÍ era correcto,
solo faltaba la explicación granular por archivo. Esta sección la provee ahora, con evidencia
verificable (`grep -c "^def test_"` por archivo, ejecutado en esta sesión).

**Ningún test se perdió ni se contó dos veces**: verificado con `pytest --collect-only` por archivo
individual y sumado manualmente contra el total real de la suite completa (`pytest tests/ -q`),
coincidiendo exactamente en cada punto de esta tabla.

```
Resultado final QP-GEN-02C:  445 passed, 0 failed
```

Comando único documentado para ejecutar la suite completa:

```bash
cd .claude/docs-qa/inputs/scripts/queryplan
python3 -m pytest tests/ -q
```

Sin red, sin Sybase, sin modificaciones de entregas — confirmado por inspección de cada archivo de
test nuevo/modificado (todos escriben bajo `tempfile.mkdtemp()`, las pruebas de regresión real solo
usan `open()` de lectura sobre archivos ya existentes en el filesystem).

---

## 12. Artefactos

`discover-only` produce ahora hasta 8 artefactos (5 base + 3 nuevos condicionados a `--request`):

```
dependency-graph.json / .md          — grafo completo (sin cambios de forma, QP-GEN-02)
package-candidates.json              — candidatos via determine_required_packages (QP-GEN-02B)
derived-package-plan.json            — plan via derive_package_plan (QP-GEN-02B)
resolution-report.json               — fuente de mapeo localizada, candidatos sin mapear (QP-GEN-02B)
queryplan-request.normalized.json    — NUEVO: request validado + inventario resuelto + metricas
sanitized-package-inventory.json     — NUEVO: SOLO si source_type=informacion_librerias
package-comparison.json              — NUEVO: reconciliacion declarado vs descubierto por estado
```

El nuevo flag `--request <queryplan-request-v1.json>` es OPCIONAL: sin él, `discover-only` se
comporta exactamente como en QP-GEN-02B (sin regresión de comportamiento, confirmado por los 413
tests previos sin modificar). Con él, el package plan final proviene de inventario contractual +
deduplicación + validación contra grafo — nunca exclusivamente del grafo, tal como exige la sección
11 del encargo.

---

## 13. Archivos modificados

Nuevos (autorizados: nada explícitamente restringido de nuevos módulos/schemas/tests/reporte):

```
.claude/docs-qa/inputs/scripts/queryplan/qp_request.py                                 (292 líneas)
  sha256: 6c8f191e7691897467d0f0570a7971753dfaf33ed5a07b7132cc1764e27fff61

.claude/docs-qa/inputs/scripts/queryplan/schema/queryplan-request-v1.schema.json
  sha256: 96b23ce8488674807c954c78db722334231fc804f325dd960255e1e2e1545729

.claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_gen_02c.py                        (609 líneas)
  sha256: a05dc1b8919bbb154ddd056c0a1388639e5b0d3b1292ce04cbb3ba3ade8f600f

.claude/docs-qa/queryplan/generalizacion/audits/
  QP-GEN-02C-OPERATOR-ASSISTED-DISCOVERY-CONTRACT.md   (este reporte)
```

Modificados (autorizados: `qp_dependency_graph.py`, `qp_source_extract.py`, `qp_pipeline.py`,
"módulo de mappings/package plan, si se justifica" → `qp_mapping_import.py`, "tests Query Plan"):

```
.claude/docs-qa/inputs/scripts/queryplan/qp_source_extract.py
  sha256: c591624e020d9edafacc1141fb9dabab1342763bde84fda67102b54171b4c499
  cambios: fix general de wrap de keyword partido (_heal_split_keyword, _SPLIT_KEYWORD_RE);
  extract_target_names + assess_source_materiality (servicio unico de materialidad, seccion 8);
  extract_children ahora usa ese servicio en vez de bloquear toda ambiguedad.

.claude/docs-qa/inputs/scripts/queryplan/qp_dependency_graph.py
  sha256: 15b9bd18134121b287461fd6feb2186bf513720dbadd00d3de3fc943def8327f
  cambios: assess_ambiguity_materiality ahora delega en qp_source_extract.assess_source_materiality
  (elimina la segunda implementacion); AMBIGUOUS_NON_MATERIAL/AMBIGUOUS_MATERIAL son alias directos.

.claude/docs-qa/inputs/scripts/queryplan/qp_mapping_import.py
  sha256: aa2a877108591b506bc34014ca2550c09de87635616ffb37ce65526167678a4b
  cambios: FORBIDDEN_FIELD_NAMES + assert_no_forbidden_fields + write_sanitized_package_inventory
  (verificacion explicita adicional, defensa en profundidad sobre la sanitizacion ya existente).

.claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py
  sha256: 37f0f324e1e9f3fe27d0bb739dea3ceff3135735c9d2c7c3063c810e5065ccef
  cambios: import qp_request; cmd_discover_only extendido con bloque `--request` opcional
  (normaliza request, reconcilia, escribe 3 artefactos nuevos, veredicto
  OPERATOR_ASSISTED_PACKAGE_PLAN_READY); nuevo argumento CLI --request.

.claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_pipeline.py
  sha256: eafc73fdde1d242de4568ec3179dcb94d96d805bca4d31b893e8b67987ca0530
  cambios: +2 tests (fixture de wrap de keyword + adversarial de no-fusion), junto a los tests
  _sx_ ya existentes de QP-GEN-01. Ninguna funcion existente de este archivo alterada.
```

No modificado (confirmado): `qp_tsql_pty.py`, `qp_capture_sanitize.py`, `qp_provenance.py`,
`qp_delivery.py`, `qp_manifest.py`, `qp_manifest_compat.py`, `qp_lint.py`, `qp_sqlcheck.py`,
`qp_regenerate.py`, `qp_normalize.py`, ningún schema/test preexistente de QP-GEN-01 (`test_qp_manifest_v2.py`,
`test_qp_normalize.py`, `test_qp_provenance.py` sin tocar; `test_qp_pipeline.py` solo con adición,
sin alterar ninguna función existente), ninguna entrega (`entregas/NCBE-1105-*`,
`entregas/NCBE-661-*`), ninguna config de cono (`config/cones/*.json`), ninguna Matriz de
Equivalencia, ningún repositorio de negocio (`informacion-librerias.json` de los micros reales se
LEYÓ, nunca se escribió/movió/modificó), `.claude/history/agente-queryplan.md`.

---

## 14. Limitaciones

1. **El operador debe saber acotar `informacion-librerias.json` a su cono** cuando el archivo real
   del micro cubre más de uno (caso confirmado real: Firmantes cubre 3 conos en 1 archivo) — el
   pipeline bloquea correctamente (`BLOCKED_DECLARED_PACKAGE_NOT_DISCOVERED`) pero no filtra
   automáticamente cuáles de las N entradas pertenecen a "este" cono; requiere que el operador use
   `source_type: explicit` o provea un archivo ya acotado.
2. **`reconcile_package_inventory` no tiene un descubridor automático de `cross_check_mappings`**
   — hoy el llamador (`cmd_discover_only`) le pasa `identity_mappings` (ya derivado de
   `informacion-librerias.json` si se encontró), pero un futuro orquestador que quiera detectar
   automáticamente "hay un repo migrado que el operador no declaró" necesitaría una fuente
   adicional de verificación (p.ej. escanear `repos_roots` por repos `*-utils` existentes).
3. **El fix de wrap de keyword (`_heal_split_keyword`) solo cubre el caso de UN keyword partido en
   DOS fragmentos** — no se probó ni se generalizó a un keyword partido en 3+ fragmentos (wrap
   múltiple), porque no se encontró evidencia real de ese patrón en el corpus disponible.
4. **`FORBIDDEN_FIELD_NAMES` es una lista finita de nombres conocidos** (defensa en profundidad,
   NO el mecanismo de seguridad real) — si `informacion-librerias.json` agregara en el futuro un
   campo de credencial con un nombre no listado (p.ej. `access_key_id`), la extracción por clave
   explícita de `load_informacion_librerias` seguiría sin copiarlo (porque solo lee
   `nombre`/`hu_jira`/`artifact_id`/`repo_url`/`group_id`/`esPadre`), pero
   `assert_no_forbidden_fields` no lo detectaría como verificación adicional si por error se
   agregara a la extracción misma.
5. **No se implementó ningún caso de request con `micro` usado para resolver automáticamente el
   `root_sp` o el `informacion-librerias.json`** — el contrato acepta `micro` como campo informativo,
   pero hoy no hay lógica que, dado solo un nombre de micro, localice su repo y su
   `informacion-librerias.json` automáticamente; eso sigue siendo responsabilidad del operador
   (proveer `root_sp` y, si aplica, `package_inventory.source_path` explícitos).
6. **No se implementó `qp_orchestrator.py`** — el flujo operador-asistido vive como una extensión
   de `discover-only`, no como un punto de entrada único end-to-end (fuera de alcance explícito de
   esta fase, reservado para QP-GEN-03).

---

## 15. Estado Git final

```bash
$ git status --short --branch
## master...origin/master
 M .claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py
 M .claude/docs-qa/inputs/scripts/queryplan/qp_source_extract.py
 M .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_pipeline.py
 M .claude/history/agente-queryplan.md   (preexistente, sin relación con esta sesión)
?? .claude/docs-qa/inputs/scripts/queryplan/qp_dependency_graph.py
?? .claude/docs-qa/inputs/scripts/queryplan/qp_mapping_import.py
?? .claude/docs-qa/inputs/scripts/queryplan/qp_request.py
?? .claude/docs-qa/inputs/scripts/queryplan/schema/queryplan-dependency-graph-v1.schema.json
?? .claude/docs-qa/inputs/scripts/queryplan/schema/queryplan-mapping-relaciones-v1.schema.json
?? .claude/docs-qa/inputs/scripts/queryplan/schema/queryplan-request-v1.schema.json
?? .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_dependency_graph.py
?? .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_gen_02b.py
?? .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_gen_02c.py
?? .claude/docs-qa/queryplan/generalizacion/

$ git diff --cached --name-only
(vacío)

$ git rev-parse HEAD
0e1733f5a378faf7666c0f1fccd2a3ebb96fcdf6   (idéntico al del precheck inicial — HEAD no se movió)

$ git rev-list --left-right --count HEAD...@{u}
0	0
```

Índice vacío. Sin commit. Sin push. Sin conexión Sybase en ningún momento de esta fase. Sin cambios
en entregas (`entregas/NCBE-1105-*`, `entregas/NCBE-661-*` con `git diff` vacío). Sin cambios en
Matrices de Equivalencia. Sin cambios en repositorios de negocio
(`informacion-librerias.json` real de los micros se leyó en modo solo-lectura; nunca se escribió,
movió ni modificó). Sin cambios en `config/cones/*.json`. `.claude/history/agente-queryplan.md` con
el mismo diff de 1 línea preexistente desde antes del inicio de esta sesión.

---

## 16. Siguiente paso permitido

Revisar este reporte y decidir si se autoriza iniciar **QP-GEN-03** (orquestador único end-to-end:
`qp_orchestrator.py run-cone`), ahora con discovery transitivo, derivación de paquetes y contrato
operativo asistido cerrados (`OPERATOR_ASSISTED_DISCOVERY_READY`). QP-GEN-03 debería: (a) unificar
`--cone-config` + `--request` en un único punto de entrada que decida el modo (`discover-only |
prepare-only | dry-run | run | regenerate | validate`); (b) resolver la limitación 5 (localizar
`informacion-librerias.json` desde solo un nombre de micro); (c) considerar si el prompt maestro
final debe exponer `package_inventory` como parámetro de primera clase. No se debe iniciar
implementación de QP-GEN-03 sin autorización explícita.

# QP-GEN-01 — Auditoría y contrato del flujo Query Plan reutilizable

Fase de solo auditoría/diseño. No se modificó código productivo, no se ejecutó Sybase, no se generó
entrega, no se hizo commit ni push.

---

## 1. Veredicto

```
REUSABLE_FLOW_FOUNDATION_PARTIAL
```

La capa de ejecución, sanitización, manifest, lint y entrega (todo lo que ocurre **una vez que ya se
sabe qué SP/PA conforman el cono**) es sólida, versionada, probada a escala N y config-driven. Pero
falta la capacidad central que el objetivo final requiere: **descubrimiento transitivo automático de
dependencias** (hijos → nietos → bisnietos → profundidad N). Hoy esa lista la resuelve un humano a
mano en `config/cones/<HU>.json`. Un orquestador que reciba solo "genera la entrega Query Plan para
este micro" no puede construirse hoy sin añadir esa capa — de ahí PARTIAL y no READY.

---

## 2. Estado Git

Precheck ejecutado al inicio de la sesión:

```
pwd:            /home/ssm-user/project-agents-assets-banco-bolivariano-qa
branch:         master
HEAD:           0e1733f5a378faf7666c0f1fccd2a3ebb96fcdf6
status:         ## master...origin/master
                 M .claude/history/agente-queryplan.md   (preexistente, ajeno a esta sesión)
staged:         (vacío)
ahead/behind:   0 / 0
```

Sin contenido staged ajeno. Sin bloqueo. Se continuó en `master` sin crear ramas/worktrees, sin
checkout/switch/reset/rebase/merge/pull/stash, sin `git add .`/`-A`/`commit -a`.

---

## 3. Fuentes auditadas

| Fuente | Ruta | Notas |
|---|---|---|
| Canon del agente | `.claude/agents/agente-queryplan.md` (524 líneas) | Frontmatter: manual, fuera del pipeline A-00→A-5.1, requiere invocación humana explícita |
| Skills | `.claude/skills/query-plan/SKILL.md`, `.claude/skills/queryplan-evidence/SKILL.md` | Ambos con `disable-model-invocation: true` |
| Historial | `.claude/history/agente-queryplan.md` | Registro QP-CF-10…QP-CF-16+ (PTY, sanitización, publicación NCBE-1105) |
| Scripts deterministas | `.claude/docs-qa/inputs/scripts/queryplan/qp_*.py` (12 módulos) | Ver tabla §4 con SHA-256 verificados |
| Schemas | `.../schema/manifest-queryplan-v2.schema.json`, `.../schema/provenance-queryplan-v1.schema.json` | Draft-07 JSON Schema, `additionalProperties:false` |
| Tests | `.../tests/test_qp_pipeline.py`, `test_qp_provenance.py`, `test_qp_normalize.py`, `test_qp_manifest_v2.py` | 4 suites, escalas 1/3/8/12/20 paquetes |
| Config de conos | `.../config/cones/NCBE-1105.json`, `NCBE-661.json` | Declarativos, `package_order[]` poblado a mano |
| Listas de estrategia de llamada | `.claude/lists/CallCobis.list`, `CallDirect.list` (14 840 líneas), `CallLibrary.list`, `CallExistLibrary.list`, `CallExistDml.list`, `determinar-call-strategy.sh` | Inventario físico banco-IA para clasificar `sps_hijos[].clasificacion` |
| Precedente simple | `.claude/docs-qa/queryplan/casos/NCBE-1105/**`, `entregas/NCBE-1105-queryplan-2026-07-09-statistics-io/**` | Consulta Firmante |
| Precedente multipaquete | `.claude/docs-qa/queryplan/audits/NCBE-661-queryplan-normalization/*.md` (9 documentos), `entregas/NCBE-661-queryplan-2026-07-09-statistics-io/**` | sp_debcred_empresa, 12 paquetes |
| Piloto adicional | `.claude/docs-qa/queryplan-piloto-sp_ahndc_automatica-2026-07-09.md` | No referencia NCBE-1105 ni NCBE-661 por nombre |
| Referencias micro | `.claude/references/contratos-micro/*.md` | Contexto de contratos, no específico de Query Plan |

No se encontraron rutas o nombres inventados; todo lo listado arriba existe físicamente en el
workspace y fue verificado con `find`/`ls`/lectura directa.

---

## 4. Arquitectura actual

```
config/cones/<HU>.json  (declarativo, manual)
        │
        ▼
qp_pipeline.py  (único entrypoint CLI: inventory|prepare|preflight|run|regenerate|diagnose|validate|package)
        │
        ├─ qp_source_extract.py   → localiza 1 archivo fuente por paquete + regex EXEC (1 nivel, sin recursión)
        ├─ qp_provenance.py       → dossier previo (schema v1.0): QUÉ se ejecutará y DE DÓNDE viene
        ├─ qp_delivery.py         → ensamblado: ejecución viva (PTY), parseo plan/IO, render .qp, ZIP
        │      └─ qp_tsql_pty.py      → sesión tsql sobre PTY propio, timeout, marcador de fin de batch
        │      └─ qp_capture_sanitize.py → segmentación allowlist (nunca reproduce filas de resultset)
        │      └─ qp_normalize.py     → desenvuelve transporte, poda planes de control, idempotente
        ├─ qp_manifest.py         → writer único del manifest-queryplan.json v2.1 (deriva resumen/labels)
        ├─ qp_manifest_compat.py  → lector de manifests históricos v1/v2.0 → modelo v2.1 (solo diagnóstico)
        ├─ qp_lint.py             → gate: .qp, estructura por-QP, JSON Schema real, cross-file, entrega completa
        ├─ qp_sqlcheck.py         → detector de abreviaciones/placeholders sin resolver
        └─ qp_regenerate.py       → reempaqueta ZIP existentes sin re-ejecutar Sybase
```

Todos los módulos son deterministas (sin LLM en el camino crítico de normalización/validación). El
`agente-queryplan.md` es la capa que un humano invoca manualmente y que orquesta las 4 fases
(inventario cruzado → Query Plan real → consolidación → entrega ZIP), delegando en `qp_pipeline.py`
como único entrypoint soportado (`agente-queryplan.md:121-126`).

---

## 5. Matriz de capacidades

| ID | Capacidad | Estado | Evidencia | Limitación | Acción requerida |
|---|---|---|---|---|---|
| C-01 | Resolución por nombre de micro | PARTIAL | `agente-queryplan.md:24,36-37` recibe `sp_name`+`microservice` como texto libre del prompt | No hay tabla micro↔HU↔SP consultable; depende de que el operador ya sepa el SP raíz | Construir índice micro→HU→SP desde `config/cones/*.json` + repos |
| C-02 | Resolución por HU del cono | PARTIAL | `config/cones/<HU>.json` se nombra por HU; `cone_hu` interno | Requiere que el archivo de config ya exista; no hay búsqueda inversa HU→config | Convención de nombre de archivo ya sirve; falta loader que liste HUs disponibles |
| C-03 | Resolución por SP raíz | EXISTS_AND_VALIDATED | `qp_pipeline.load_cone` exige `sp_padre` (`qp_pipeline.py:92-94`); confirmado en ambos JSON de cono | — | — |
| C-04 | Relación micro desplegable ↔ HU cono | EXISTS_NOT_VALIDATED | Comentario `_doc` en NCBE-1105.json declara la relación explícitamente | Es documental (comentario), no una regla de código que la derive | Formalizar como campo estructurado, no solo `_doc` |
| C-05 | Relación librería/módulo ↔ HU individual | EXISTS_AND_VALIDATED | `packages{}` en config de cono; `hu_individual` en manifest v2.1 (schema, `hu_individual`) | — | — |
| C-06 | Relación SP/PA ↔ módulo | EXISTS_AND_VALIDATED | `packages.<sp>.microservicio` en ambos JSON de cono; confirmado en NCBE-661 (12 entradas) | — | — |
| C-07 | Resolución desde Excel u otra fuente | MISSING | No se encontró ningún lector de Excel/relaciones en los 12 scripts auditados | El contrato de entrada futuro (§7) puede aceptarlo como opcional, pero no existe hoy | Diseñar en QP-GEN-02 si Banco entrega Excel de relaciones |
| C-08 | Manejo de datos incompletos | EXISTS_AND_VALIDATED (fail-closed) | `BLOCKED_SOURCE_PROVENANCE`, `BLOCKED_LITERAL_SOURCE`, `NO_LIBRARIES_FOUND` (`agente-queryplan.md:141-142,207-208`) | — | — |
| C-09 | Manejo de múltiples candidatos (ambigüedad) | MISSING | No hay lógica de "dos SP raíz posibles" ni "dos micros con mismo nombre" en el canon | El agente asume que el operador ya desambiguó al invocar | Definir bloqueo `BLOCKED_INPUT_AMBIGUOUS` explícito (§13) |
| C-10 | Parsing de `EXEC` (estático) | EXISTS_AND_VALIDATED | `_EXECJ` regex, `qp_source_extract.py:56`, resuelve `base..sp`/`owner.sp`/local | Solo aplica sobre el texto de **un** archivo por invocación | — |
| C-11 | Llamadas dinámicas (SQL armado en variable/concatenado) | MISSING | No se encontró resolución de EXEC dinámico (`exec(@sql)`) en `qp_source_extract.py` | Un EXEC construido en runtime no sería detectado por el regex estático | Evaluar si el corpus real tiene este patrón; si sí, requiere análisis adicional |
| C-12 | Llamadas con base/owner explícito y owner omitido | EXISTS_AND_VALIDATED | `qp_source_extract.py:56` cubre `base..sp`, `owner.sp`, `sp` local (confirmado por `test_sx_children_local_and_crossdb_and_wrap`, `test_qp_pipeline.py:314-331`) | — | — |
| C-13 | Descubrimiento de hijos directos | EXISTS_AND_VALIDATED | `extract_children` (`qp_source_extract.py:109-159`), probado a escala | — | — |
| C-14 | Recorrido transitivo (nietos, bisnietos, profundidad N) | **MISSING** | `extract_children`/`find_sp_source` no se re-invocan sobre los hijos descubiertos; no hay cola/pila de trabajo ni marca de visitado (`qp_source_extract.py:65-159`, confirmado por lectura directa: no hay llamada recursiva) | Es la brecha central del objetivo QP-GEN-01. Hoy el "cierre transitivo" lo resuelve un humano poblando `package_order[]` a mano (evidencia: NCBE-661 con 12 entradas manuales) | **P0** — implementar BFS/DFS de punto fijo en QP-GEN-02 (ver §9) |
| C-15 | Profundidad arbitraria | MISSING | Consecuencia directa de C-14 | — | Igual que C-14 |
| C-16 | Detección de ciclos | MISSING | No hay estructura de "visitados" que pudiera detectar un ciclo, porque no hay recursión | Riesgo: si se implementa recursión sin protección, un ciclo real colgaría el pipeline | Implementar junto con C-14, con set de visitados desde el diseño |
| C-17 | Múltiples rutas al mismo SP / deduplicación | EXISTS_AND_VALIDATED (a nivel plano) | `total_unique_child_procedures` vs `total_child_entries` vs `total_child_call_sites` en manifest consolidado (NCBE-661: 28 vs 36 vs 45, confirmado por lectura directa del JSON) | Deduplica correctamente entre paquetes ya conocidos; no se ha probado con un grafo transitivo de profundidad >1 descubierto automáticamente | Extender la misma lógica de dedup al grafo transitivo cuando exista C-14 |
| C-18 | SP sin fuente / referencias no resueltas | EXISTS_AND_VALIDATED (fail-closed) | `NOT_FOUND`, `BLOCKED_SOURCE_PROVENANCE` | — | — |
| C-19 | Clasificación de dependencias (BUSINESS/TECHNICAL) | EXISTS_AND_VALIDATED | `categoria` obligatoria en schema (`manifest-queryplan-v2.schema.json:110`); `determinar-call-strategy.sh` contra `CallCobis/CallDirect/CallLibrary/CallExistLibrary/CallExistDml` | — | — |
| C-20 | Determinación dinámica de paquetes (cuántos ZIP) | PARTIAL | Regla textual "Cantidad de paquetes dinámica...NO es constante...PROHIBIDO hardcodear" (`agente-queryplan.md:360-365`); `qp_lint.lint_delivery` valida `zip_count==esperado` sin contar ZIPs en disco como fuente de verdad | La *cantidad esperada* sigue viniendo de `package_order[]`, poblado a mano; el código no *calcula* cuántos paquetes corresponden desde el grafo de llamadas | P0 — una vez exista C-14, derivar `package_order` candidato del cierre transitivo, no solo validarlo |
| C-21 | SP que es simultáneamente micro y librería (dedup identidad) | EXISTS_AND_VALIDATED | Caso NCBE-1105 real: 1 SP → 1 paquete, `total_child_entries:0` | — | — |
| C-22 | Localización del dump del SP | EXISTS_AND_VALIDATED | `sp_source_roots` en config de cono; `find_sp_source` (`qp_source_extract.py:65-72`) | Busca en las rutas declaradas, no descubre repos nuevos automáticamente | — |
| C-23 | Localización de repositorios / módulos `*-utils` | PARTIAL | `repos_roots` en config de cono (manual); confirmado bug real: `NCBE-661.json.call_strategy_script` apunta a `.../claude-setupv2/.claude/lists/...` (ruta del setup anterior, inexistente/obsoleta) mientras `NCBE-1105.json` apunta correctamente al repo actual | Config desactualizada rompe silenciosamente si no se corrige antes de reusar el cono | **P0** — corregir la ruta en NCBE-661.json (fuera de alcance de QP-GEN-01: es config, no código, pero se documenta el gap) |
| C-24 | Inventario SQL Java | EXISTS_AND_VALIDATED | `qp_source_extract.discover_java_sql_entries`, cobertura de adapters outbound (`agente-queryplan.md:184-208`) | — | — |
| C-25 | Correspondencia Java ↔ SP | EXISTS_AND_VALIDATED | Dossier de procedencia cruza Java↔SP legacy (`qp_provenance.py`) | — | — |
| C-26 | Provenance / hashes | EXISTS_AND_VALIDATED | `source_tree_hash` (sha256 obligatorio, pattern `^[0-9a-f]{64}$`), `payload_sha256`/`stdout_sha256`/`stderr_sha256` en manifest v2.1 | — | — |
| C-27 | Fuentes ausentes | EXISTS_AND_VALIDATED (fail-closed) | `NO_LIBRARIES_FOUND`, `NOT_FOUND` | — | — |
| C-28 | Generación de `config/cones/<HU>.json` | MANUAL | No existe script que genere esta config; se edita a mano (confirmado: ambos JSON existentes son artefactos manuales según su propio `_doc`) | Es el input estructural completo del pipeline y hoy depende 100% de trabajo humano previo | P0/P1 — el orquestador futuro debería poder derivar un borrador desde SP raíz + descubrimiento |
| C-29 | Generación de provenance | EXISTS_AND_VALIDATED | `qp_pipeline.py prepare` produce `provenance-queryplan.json` sin conectar a Sybase | — | — |
| C-30 | Generación de `literal-sources.json` | EXISTS_AND_VALIDATED | Confirmado en NCBE-1105: `literal_sources_path`, archivo real con 15 casos, veredicto `15/15 EQUIVALENTE` | — | — |
| C-31 | Validación de placeholders/DML/SP hijos | EXISTS_AND_VALIDATED | `qp_sqlcheck.py`, `qp_lint.py` (D3, D5, D8) | — | — |
| C-32 | Prepare para 1 paquete / multipaquete | EXISTS_AND_VALIDATED | Probado a escala 1/3/8/12/20 (`test_qp_pipeline.py`, `test_qp_normalize.py`) | — | — |
| C-33 | Determinismo | EXISTS_AND_VALIDATED | Normalización idempotente, ZIP determinista, hashes verificables | — | — |
| C-34 | Literales funcionales — jerarquía de prioridad | PARTIAL | Regla real observada: (1) dossier/análisis existente, (2) matrices de análisis, (3) valores conocidos del dominio → si ninguno, `BLOCKED_LITERAL_SOURCE` (`agente-queryplan.md:138-142,215-216`) | No existe la jerarquía de 6 niveles completa que describe el propósito de esta auditoría (fixture/caso de uso/test unitario como categorías separadas); es una jerarquía de 3 niveles + bloqueo | Formalizar jerarquía completa si Banco la exige explícitamente, o documentar que la de 3 niveles es la real y suficiente |
| C-35 | Búsqueda automática de matrices funcionales | EXISTS_AND_VALIDATED | Confirmado en NCBE-1105: `matrix_roots`, `microservice_for_matrix`, correspondencia exacta con `QA-CASOS-PARSEADOS.json` y JSONPath por caso | — | — |
| C-36 | Trazabilidad JSONPath/caso de literales | EXISTS_AND_VALIDATED | `fuente_literales` con `tipo_fuente/archivo/sha256/test_case_id/jsonpath` (confirmado en QP-01..QP-05 de NCBE-1105) | — | — |
| C-37 | Manejo de paquetes sin matriz | EXISTS_AND_VALIDATED (fail-closed) | `BLOCKED_LITERAL_SOURCE` por paquete, entrada documentada sin payload | — | — |
| C-38 | PTY canónico, una sesión por QP | EXISTS_AND_VALIDATED | `qp_tsql_pty.py` (sesión única, marcador de fin, timeout monotónico, SIGTERM→SIGKILL); confirmado como corrección real documentada en `.claude/history/agente-queryplan.md` (QP-CF-11→14) tras timeout observado en NCBE-1105/QP-02 | El canon textual (`agente-queryplan.md`/SKILL.md) no menciona PTY explícitamente — vive solo en el historial y el código | Actualizar el canon para que documente PTY como obligatorio (hoy es conocimiento tácito) |
| C-39 | Timeout / cleanup | EXISTS_NOT_VALIDATED (valor no normado) | `PtySessionTimeout` existe en código; el historial usa 120s como referencia empírica, no hay constante normativa en el canon | — | Documentar el valor de timeout oficial en el canon |
| C-40 | Captura combinada / severity / plan / Statistics IO | EXISTS_AND_VALIDATED | Severity≥11 nunca se oculta (`agente-queryplan.md:349-350`); parser de IO con umbrales B>10000/C>1000 | — | — |
| C-41 | Ejecución secuencial multipaquete | EXISTS_AND_VALIDATED | `for pkg in cone["package_order"]` (`qp_pipeline.py:176,195,616`) | — | — |
| C-42 | Reintentos / preflight | PARTIAL | Existe subcomando `preflight`; no se documentó lógica de reintento automático ante fallo transitorio de conexión | — | Confirmar en QP-GEN-02 si Banco requiere retry |
| C-43 | Fallos parciales | EXISTS_AND_VALIDATED | `REQUIRES_SYBASE_RERUN` por QP individual sin cerrar toda la entrega | — | — |
| C-44 | Regeneración sin nueva ejecución | EXISTS_AND_VALIDATED | `qp_regenerate.py`, subcomando `regenerate` | — | — |
| C-45 | Sanitización allowlist / fail-closed | EXISTS_AND_VALIDATED | `qp_capture_sanitize.py`, `UnsafeCaptureSegmentationError` → bloqueo | El canon escrito (`agente-queryplan.md`/SKILL.md) no documenta esta capa textualmente; solo vive en código + historial (QP-CF-15/16) | Actualizar canon |
| C-46 | Secretos / credenciales | EXISTS_NOT_VALIDATED | Mencionado como "hardening de credenciales" en `test_qp_pipeline.py` (según auditoría de tests) | No se auditó directamente el mecanismo (fuera del foco de esta pasada) | Verificación puntual en QP-GEN-02 si se generaliza a más conos con credenciales distintas |
| C-47 | Datos personales / PII en resultsets | EXISTS_AND_VALIDATED | `qp_capture_sanitize.py` nunca reproduce filas de resultset; confirmado en NCBE-1105 (allowlist exclude `Firma/Nombre/Identificacion`) | — | — |
| C-48 | Rutas absolutas / residuos `/tmp` | EXISTS_AND_VALIDATED | Regla explícita: ZIP de Banco no expone rutas internas ni refs Git; `/tmp` solo staging | — | — |
| C-49 | Manifest por paquete / schema Draft-07 | EXISTS_AND_VALIDATED | `manifest-queryplan-v2.schema.json`, verificado `"$schema": "http://json-schema.org/draft-07/schema#"` | — | — |
| C-50 | Lints / cross-lint / delivery lint | EXISTS_AND_VALIDATED | `qp_lint.py` con 5 niveles de gate (texto, estructura, schema, cross-file, entrega completa) | — | — |
| C-51 | Consolidado multi-ZIP | EXISTS_AND_VALIDATED | `manifest-consolidado-queryplan.json`, confirmado real en NCBE-661 (12 paquetes) y NCBE-1105 (1 paquete) | — | — |
| C-52 | Reproducibilidad | EXISTS_AND_VALIDATED | Hashes de payload/stdout/stderr por QP; ZIP determinista | — | — |
| C-53 | Comando único / modo discover-only / prepare-only / dry-run / run / regenerate | PARTIAL | `qp_pipeline.py` YA tiene subcomandos equivalentes (`inventory≈discover-only`, `prepare≈prepare-only`, `preflight≈dry-run`, `run`, `regenerate`, `validate`) | El AGENTE (interfaz humana) no expone estos modos como parámetro — siempre corre las 4 fases seguidas; el operador no puede pedir solo "discover" desde el prompt del agente | P1 — exponer los modos del pipeline a nivel de invocación del agente/orquestador |
| C-54 | Veredicto unificado | MISSING | Hoy hay ~15+ veredictos internos distintos (ver §13) sin una capa de agregación a un conjunto reducido | — | P1 — diseñar mapeo (ya propuesto en §13) |
| C-55 | Invocación automática (no manual) | **MISSING por diseño** | Frontmatter explícito "Requiere invocación humana explícita"; ambos skills con `disable-model-invocation: true` | Esta es una barrera INTENCIONAL, no un descuido — cualquier generalización a "el operador solo pide y el sistema hace todo" debe decidir conscientemente remover/redefinir esta barrera | Decisión explícita de producto en QP-GEN-03, no solo técnica |

---

## 6. Precedente Consulta Firmante (NCBE-1105)

Confirmado con evidencia real cruzada en 4 fuentes independientes (config del cono, dossier de
provenance, manifest consolidado, manifest interno del ZIP):

- **1 SP/PA único**: `firmas..pa_fir_consulta_firmante`.
- **1 paquete**: `manifest-consolidado-queryplan.json` → `total_paquetes: 1`.
- **5 Query Plans**: QP-01..QP-05, todos `SELECT`, `ejecutados=5`, `errores_sql=0`, `observaciones=0`.
- **Deduplicación de identidad triple**: el mismo SP es simultáneamente el micro desplegable
  (`cpas-mso-consulta-firmante`), el módulo/librería (`pa-fir-consulta-firmante-utils`) y el
  microservicio de matriz (`microservice_for_matrix`) — resuelto por convención declarativa en la
  config del cono, no por una regla de código que infiera la equivalencia.
- **Literales**: 100% desde matriz funcional QA (`QA-CASOS-PARSEADOS.json`, veredicto `15/15
  EQUIVALENTE`), con trazabilidad `test_case_id`/`jsonpath` por QP. Ninguno inventado.
- **Ejecución PTY canónica**: confirmada como corrección real posterior a un timeout observado en
  QP-02 durante una corrida previa a `qp_tsql_pty.py` (documentado en `.claude/history/agente-queryplan.md`,
  serie QP-CF-11 a QP-CF-14).
- **Cero descendientes**: `sps_hijos: []`, `total_child_entries: 0` — es el caso base "raíz sin
  hijos" del diseño de fixtures sintéticos (§16).

No hubo discrepancias en las cantidades: el número 5/1/1 se sostiene sin ambigüedad en las 4 fuentes.

---

## 7. Precedente NCBE-661

Confirmado con evidencia real: SP raíz `sp_debcred_empresa` (HU individual real `NCBE-868`, **no**
`NCBE-661` — esa es la HU del cono/agrupador, corregida explícitamente en una iteración documentada
en `QUERYPLAN-SP-DEBCRED-HU-REASSIGNMENT-NOTE.md`).

Cantidades reales (manifest consolidado, `delivery_ready: true`):

| Métrica | Valor real verificado |
|---|---|
| Paquetes/ZIPs | 12 (config `package_order` y archivos en disco coinciden) |
| Query Plans totales | 98 (bajó de 103 tras exclusión de 5 QP `NO_TABLE_IO` en `sp_cal_impuesto` por criterio de alcance Java 2026-07-15) |
| QP con observación | 24 |
| DML protegidos `noexec` | 26 |
| Errores SQL reales | 0 |
| `total_child_entries` (pares padre-hijo únicos) | 36 |
| `total_child_call_sites` (sitios exec reales) | 45 |
| `total_unique_child_procedures` (SP hijos distintos globales) | 28 |
| Entradas BUSINESS / TECHNICAL_UTILITY | 34 (42 call-sites) / 2 (3 call-sites) |

**Profundidad real ≥ 3 niveles**, descubierta y documentada, aunque manualmente:
L0 `sp_debcred_empresa` → L1 incluye `sp_ndc_ahcc` (orquestador puro, 0 QP propios) → L2
`sp_ndc_ahcc` llama a 3 miembros del propio cono (`pa_cte_pvalida_ndnc`, `pa_aho_pvalida_ndnc`,
`sp_genera_iva_comision`) → L3 grandchildren fuera del cono sin ZIP propio (`sp_ahndc_automatica`,
`sp_ccndc_automatica`, `cob_cuentas..sp_gen_sec`), categorizados `TECHNICAL_UTILITY`/
`UnclassifiedRefactor`, `ejecutado=false`.

**Deduplicación real evidenciada**: la brecha 45 call-sites → 36 entries → 28 únicos demuestra
reutilización genuina (`cob_cuentas..sp_gen_sec` es llamado desde dos padres distintos del cono;
`sp_con_confcontable` se invoca 3 veces desde un mismo padre).

**Lección crítica de las 9 iteraciones de corrección documentadas** (v1-LEGACY → v2.0 →
`DEPRECATED_INTERNAL_NOT_FOR_DELIVERY` → v2.1 → ajuste de alcance Java): la regeneración a v2.0
**perdió por completo** el inventario de hijos (`sps_hijos=[]` en 12/12 paquetes) porque el
*renderer* leía metadata intermedia en vez del manifest canónico. Esto es evidencia directa de que
el inventario de hijos (incluso al nivel plano ya soportado) es frágil ante refactors del pipeline
si no hay un test de regresión que fije los conteos — de hecho, ese fue exactamente el gap que los 4
tests actuales (`test_qp_manifest_v2.py`, escalas 1/8/12/20) ahora cubren.

**Toda esta transitividad fue descubierta y clasificada por un humano y volcada a mano en
`package_order[]`/`packages{}`** — el código nunca recorrió el grafo desde `sp_debcred_empresa` para
llegar a los 12 paquetes; los 12 ya venían dados.

---

## 8. Entrada mínima

Datos que el operador debe suministrar (no resolubles canónicamente hoy):

```
sp_padre           (nombre del SP raíz)  — o alternativamente:
micro               (nombre del micro desplegable, si el SP raíz aún no se conoce)
```

Ambiente y cone_hu son técnicamente derivables si `sp_padre`/`micro` mapean a una config de cono
existente, pero **hoy no hay tabla de mapeo automático** — por eso `hu_cono` y `environment` deben
tratarse como datos requeridos hasta que exista C-01/C-02 (§5). No declarar todos como obligatorios
si el descubrimiento (§10) los resuelve.

Datos opcionales:

```
ruta de Excel/relaciones     (no soportado hoy — C-07 MISSING)
matriz funcional              (se autodescubre si existe — C-35)
repositorio fuente             (se autodescubre desde config de cono si ya existe)
criterio Banco                 (default: la versión vigente más reciente)
fecha de ejecución              (default: ahora, UTC)
```

Datos descubribles automáticamente hoy (sin nueva capacidad):

```
HU individual por SP/PA          (packages.<sp>.hu)
librerías/microservicio           (packages.<sp>.microservicio)
literales                         (matrices funcionales vía matrix_roots)
hijos directos (1 nivel)          (extract_children)
```

Datos que requieren la nueva capacidad C-14 (descubrimiento transitivo) para ser automáticos:

```
HU cono (si no se conoce la config previa)
SP raíz (si solo se da el nombre del micro y no hay config)
descendientes más allá del nivel 1
cantidad final de paquetes
```

---

## 9. Datos descubribles (detalle)

Ver tabla de §8. La distinción operativa clave: **todo lo "descubrible" hoy opera dentro de un
paquete ya identificado** (vía `package_order[]`). Nada descubre automáticamente *qué* paquetes
deberían existir a partir de solo el SP raíz — ese es exactamente C-14/C-20, la brecha P0.

---

## 10. Grafo transitivo (contrato propuesto, no implementado)

Modelo intermedio propuesto para QP-GEN-02, distinguiendo explícitamente las 5 colecciones exigidas
(no mezclarlas — el manifest consolidado real ya distingue 3 de estas 5 con nombres textuales
concretos: `total_child_entries`, `total_child_call_sites`, `total_unique_child_procedures`):

```
unique_procedures:            { normalized_id -> NodoSP }
  NodoSP:
    normalized_id      (base.owner.sp_name, normalizado lower-case, sin dobles puntos)
    base, owner, nombre
    nivel_minimo        (profundidad mínima observada desde la raíz)
    padres_inmediatos    [normalized_id]
    clasificacion        (CallDirect|CallCobis|CallLibrary|CallExistLibrary|CallExistDml|UnclassifiedRefactor|Desconocido)
    categoria             (BUSINESS|TECHNICAL_UTILITY)
    hu_individual, microservicio, repositorio   (si resueltos)
    fuente_sybase, fuente_java                    (rutas, si resueltas)
    estado_resolucion                              (RESOLVED|NOT_FOUND|AMBIGUOUS)
    requiere_paquete                                (bool)
    razon_requiere_paquete

call_sites:                    [{ desde: normalized_id, hacia: normalized_id, archivo, linea_inicio, linea_fin, contexto }]

dependency_edges:               [{ desde: normalized_id, hacia: normalized_id }]   (deduplicado; 1 edge aunque haya N call_sites)

paths:                          [{ ruta: [normalized_id, ...], ciclo: bool }]

packages_required:              [normalized_id]   (subconjunto de unique_procedures con requiere_paquete=true)
```

Esto es una extensión natural del modelo que YA usa `manifest-queryplan-v2.schema.json` para
`sps_hijos[]` (que ya tiene `call_sites[]`, `categoria`, `clasificacion`, `ocurrencias`) — no un
diseño desde cero. La diferencia es que hoy ese array es plano (1 nivel, dentro de 1 paquete) y el
contrato propuesto lo generaliza a un grafo real con `nivel_minimo` y `padres_inmediatos` para
soportar N niveles, ciclos y múltiples padres.

---

## 11. Deduplicación y ciclos

- **Deduplicación de identidad**: ya funciona correctamente a nivel plano (evidencia NCBE-661:
  28 únicos vs 36 entries vs 45 call-sites). El contrato transitivo (§10) debe preservar exactamente
  esta misma semántica al extenderla a N niveles: 1 SP único → 1 nodo en `unique_procedures`,
  sin importar cuántas rutas/padres lo alcancen.
- **Ciclos**: no hay evidencia de que se hayan encontrado en los dos precedentes auditados (NCBE-1105
  sin hijos; NCBE-661 con árbol/DAG de 3+ niveles pero sin ciclo reportado en los 9 documentos de
  auditoría). Esto significa que la ausencia actual de detección de ciclos (C-16) no ha causado un
  incidente conocido — pero tampoco ha sido probada bajo estrés, porque el descubrimiento transitivo
  automático no existe. Cualquier implementación de C-14 debe incluir protección de ciclos desde el
  diseño inicial (set de visitados + límite configurable), no como parche posterior.

---

## 12. Regla dinámica de paquetes

Regla real observada en el canon (`agente-queryplan.md:360-365`) y confirmada por evidencia en ambos
precedentes:

```
paquetes requeridos
=
conjunto deduplicado de SP/PA únicos
que el inventario del cono (package_order[]) declara como paquete
```

Esta regla es correcta como *validación* (evita hardcodear un número), pero **no es una regla de
*descubrimiento*** — no calcula el conjunto desde el grafo de llamadas, solo confirma que el ZIP
generado coincide con lo declarado en config. Los 4 casos documentados en el propósito de esta
auditoría se sostienen con la evidencia real:

- **Mismo SP en micro y librería** → 1 SP único → 1 paquete: confirmado en NCBE-1105.
- **SP padre y descendientes distintos** → N SP/PA únicos que requieren paquete → N paquetes:
  confirmado en NCBE-661 (12), pero la lista de "distintos" fue decidida por un humano, no calculada.
- **Mismo SP llamado desde varias ramas** → 1 paquete, múltiples call sites: confirmado
  (`cob_cuentas..sp_gen_sec`, 2 padres distintos en NCBE-661).
- **Dependencia técnica**: el canon ya distingue `BUSINESS`/`TECHNICAL_UTILITY` y exige que las
  utilidades técnicas NUNCA se excluyan del inventario (se clasifican, no se omiten) — pero
  "requiere paquete propio" vs "solo se documenta" para una dependencia técnica no tiene una regla
  explícita más allá de que hoy **ninguna** dependencia de nivel >1 recibe paquete automáticamente,
  porque no se descubre.

---

## 13. Literales

Jerarquía real (3 niveles + bloqueo, no la especulativa de 6 niveles del propósito de esta
auditoría):

```
1. Dossier/análisis existente (provenance-queryplan.json, matrices de análisis)
2. Valores conocidos del dominio
3. (si ninguno es verificable) → BLOCKED_LITERAL_SOURCE, documentado sin payload
```

Con trazabilidad real confirmada vía `fuente_literales.{tipo_fuente, archivo, sha256, test_case_id,
jsonpath}` (NCBE-1105: 5/5 QP con esta trazabilidad completa, cero literales inventados). Correspondencia
exacta SP/micro/endpoint confirmada (`microservice_for_matrix`, endpoint REST y gRPC documentados en
`literal-sources.json`). Selección por QP: cada QP declara su propia fuente, no una fuente global
por paquete. Manejo de paquetes sin matriz: `BLOCKED_LITERAL_SOURCE`, fail-closed, ese paquete no
cierra. Resolución multipaquete: cada paquete resuelve sus literales de forma independiente (no hay
lógica cruzada entre paquetes del mismo cono).

---

## 14. Ejecución y entrega

**Ejecución**: PTY canónico real (`qp_tsql_pty.py`), una sesión por QP, timeout con terminación
SIGTERM→SIGKILL, marcador sintético de fin de batch, `noexec on/off` obligatorio para DML no
idempotente, severity≥11 nunca oculto, Statistics IO parseado a estructura (`scan_count`,
`logical/physical reads`), ejecución secuencial multipaquete (`for pkg in package_order`), fallos
parciales vía `REQUIRES_SYBASE_RERUN` sin bloquear toda la entrega, regeneración sin nueva ejecución
(`qp_regenerate.py`). Gap real: el canon textual (`agente-queryplan.md`) no documenta PTY
explícitamente — es conocimiento que solo vive en código + historial de ejecuciones, lo cual es un
riesgo de mantenimiento si el agente se reescribe sin consultar el historial.

**Entrega**: manifest v2.1 (Draft-07, `additionalProperties:false`), ZIP con 3 archivos
(`detalle_ejecucion.qp` + `observaciones.qp` + `manifest-queryplan.json`, sin `engine_out/`),
consolidado multi-ZIP con contadores agregados verificados reales (NCBE-661: 12/12, 98 QP), lints en
5 niveles (`qp_lint.py`), reproducibilidad por hash, README opcional para carga en Confluence,
criterio Banco versionado (`2026-07-09-statistics-io`), soporta tanto entrega simple (1 paquete) como
multipaquete (12 paquetes) sin cambio de código.

---

## 15. Seguridad

Fail-closed real y verificado: `BLOCKED_UNSAFE_DML` ante riesgo de escritura real; sanitización
allowlist estructural (`qp_capture_sanitize.py`, excluye filas de resultset, nunca blacklist de
palabras) confirmada en producción real (NCBE-1105, exclusión de columnas `Firma/Nombre/Identificacion`);
rutas absolutas y refs Git nunca expuestas en el ZIP de Banco; `/tmp` restringido a staging. Gap
real: igual que con PTY, esta capa de seguridad tampoco está documentada textualmente en el canon
(`agente-queryplan.md`/SKILL.md) — vive en código + historial (QP-CF-15/16). Riesgo de mantenimiento:
si alguien reescribe el agente leyendo solo el `.md` canónico, podría omitir la sanitización porque
el documento no la menciona.

---

## 16. Orquestador propuesto

Punto de entrada único (conceptual, no implementado):

```bash
python qp_orchestrator.py run-cone \
  --micro <micro> \
  --cone <HU> \
  --root-sp <base..sp>
```

Debe envolver `qp_pipeline.py` (que ya expone `inventory|prepare|preflight|run|regenerate|diagnose|
validate|package`) añadiendo la capa de descubrimiento transitivo (C-14) que hoy falta antes de
`inventory`, y una capa de resolución de identidad (C-01/C-02) antes de eso.

---

## 17. Modos

| Modo | Entrada | Operaciones permitidas | Conexión Sybase | Artefactos | Veredicto |
|---|---|---|---|---|---|
| `discover-only` | `root-sp` o `micro` | Descubrimiento transitivo completo (nuevo, C-14) + clasificación | No | Grafo de dependencias (JSON), `package_order` candidato | `DISCOVERY_COMPLETE` / `BLOCKED_DEPENDENCY_GRAPH` |
| `prepare-only` | grafo ya descubierto o config de cono existente | `qp_pipeline.py prepare` (ya existe) | No | `provenance-queryplan.json` por paquete | `PREPARE_READY` / `BLOCKED_SOURCE_MAPPING` / `BLOCKED_LITERAL_MAPPING` |
| `dry-run` | config + provenance | `qp_pipeline.py preflight` (ya existe) | Conexión de prueba, sin ejecutar DML | Reporte de viabilidad | `PREPARE_READY` / `BLOCKED_SYBASE` |
| `run` | config + provenance validados | `qp_pipeline.py run` (ya existe) | Sí | ZIPs + consolidado | `QUERYPLAN_BANK_READY` / `BLOCKED_SYBASE` / `BLOCKED_SECURITY` / `BLOCKED_DELIVERY_VALIDATION` |
| `regenerate` | entrega existente | `qp_pipeline.py regenerate` (ya existe) | No | ZIPs reescritos | `QUERYPLAN_BANK_READY` / `BLOCKED_DELIVERY_VALIDATION` |
| `validate` | entrega existente | `qp_pipeline.py validate` / `qp_lint.py` (ya existe) | No | Reporte de lint | `QUERYPLAN_BANK_READY` / `BLOCKED_DELIVERY_VALIDATION` |

Los modos `prepare-only` a `validate` **ya existen** en `qp_pipeline.py` (confirmado por `--help`
real, incluye también `diagnose`, no listado en el propósito original). El único modo genuinamente
nuevo es `discover-only`, que no tiene contraparte hoy.

---

## 18. Veredictos unificados

| Veredicto de alto nivel | Veredictos internos actuales relacionados |
|---|---|
| `QUERYPLAN_BANK_READY` | `PASS`, `PASS_CON_OBSERVACIONES`, `delivery_ready:true`, `QUERYPLAN_DELIVERY_READY_FOR_REVIEW_NORMALIZED`, `BANK_READY_ARTIFACT_PASS` |
| `DISCOVERY_COMPLETE` | (nuevo — no existe hoy; correspondería al futuro modo `discover-only`) |
| `PREPARE_READY` | resultado exitoso de `qp_pipeline.py prepare` |
| `BLOCKED_INPUT_AMBIGUOUS` | (nuevo — hoy no hay manejo de múltiples candidatos, C-09) |
| `BLOCKED_DEPENDENCY_GRAPH` | (nuevo — correspondería a un ciclo detectado o nodo no resoluble en el futuro grafo transitivo) |
| `BLOCKED_SOURCE_MAPPING` | `BLOCKED_SOURCE_PROVENANCE`, `NO_LIBRARIES_FOUND`, `NOT_FOUND` |
| `BLOCKED_LITERAL_MAPPING` | `BLOCKED_LITERAL_SOURCE` |
| `BLOCKED_REPOSITORY_STATE` | (reservado para el precheck Git; no colisiona con Query Plan) |
| `BLOCKED_SYBASE` | `BLOCKED_SYBASE`, `EXECUTION_ONLY_RUN_TIMEOUT` |
| `BLOCKED_SECURITY` | `BLOCKED_UNSAFE_DML`, `BLOCKED_SENSITIVE_DATA_LEAK`, `BLOCKED_UNSAFE_CAPTURE_SEGMENTATION` |
| `BLOCKED_DELIVERY_VALIDATION` | fallo de `qp_lint.py`/`qp_pipeline.py validate`, `REQUIRES_SYBASE_RERUN` sin resolver |
| `PIPELINE_IMPLEMENTATION_ERROR` | `ManifestError`, excepciones no categorizadas |

El detalle técnico interno (los ~15+ veredictos reales listados en la auditoría del canon) se
conserva en los reportes internos; esta tabla es solo la capa de agregación para el operador.

---

## 19. Prompt maestro propuesto

**Mínimo** (requiere que exista C-01/C-02/C-14, hoy no implementadas):

```text
Genera la entrega Query Plan Bank Ready para el micro <MICRO>.
Usa las fuentes canónicas del workspace, descubre el SP raíz,
recorre todas las dependencias transitivas, determina dinámicamente
los paquetes y detente antes de commit y push.
```

**Con datos conocidos** (funcional HOY si se provee `config/cones/<HU>.json` ya poblado a mano —
es, de hecho, el modo de operación real de los dos precedentes auditados):

```text
Genera la entrega Query Plan Bank Ready para:

HU cono: <HU>
Micro: <MICRO>
SP raíz: <BASE..SP>

Recorre todas las dependencias transitivas, usa evidencia funcional
para los literales y detente antes de commit y push.
```

La forma "con datos conocidos" ya es alcanzable invocando `agente-queryplan` sobre una config de cono
existente. La forma "mínima" requiere QP-GEN-02 completo antes de ser honesta.

---

## 20. Gaps P0-P3

**P0 — necesario para no generar entregas incompletas**

| ID | Descripción | Riesgo | Capacidad afectada | Archivo probable | Prueba requerida | Fase |
|---|---|---|---|---|---|---|
| P0-01 | No existe descubrimiento transitivo (recursión sobre `extract_children`) | Un cono nuevo con profundidad >1 requeriría que un humano vuelva a poblar `package_order[]` a mano, exactamente como en NCBE-661 — no hay reutilización real sin esto | C-14, C-15, C-16 | `qp_source_extract.py` (nuevo módulo o extensión) | Fixtures sintéticos §21 (raíz+1 hijo, profundidad 4, diamante, ciclo) | QP-GEN-02 |
| P0-02 | La cantidad de paquetes no se calcula, solo se valida contra config manual | Riesgo de que un SP nuevo con dependencias reales quede fuera de `package_order[]` sin que nada lo detecte | C-20 | `qp_pipeline.py` (`load_cone`, `build_inventory`) | Test que compare `package_order` declarado vs grafo descubierto | QP-GEN-02 |
| P0-03 | `NCBE-661.json.call_strategy_script` apunta a una ruta del setup anterior (`claude-setupv2`), inexistente/obsoleta en este repo | Si se reintenta regenerar NCBE-661 hoy sin corregir la ruta, la clasificación de hijos fallaría o usaría un script equivocado silenciosamente | C-23 | `config/cones/NCBE-661.json` | Validación de existencia de `call_strategy_script` al cargar el cono | QP-GEN-02 (es config, no código — corrección de datos, no de lógica) |
| P0-04 | No hay manejo de ambigüedad de entrada (dos SP raíz posibles, dos micros con mismo nombre) | Sin esto, un futuro orquestador automático podría elegir silenciosamente el candidato equivocado | C-09 | Capa de resolución de identidad (nueva) | Fixture con nombre de micro duplicado en dos repos | QP-GEN-02/03 |

**P1 — necesario para operación reutilizable**

| ID | Descripción | Riesgo | Capacidad afectada | Archivo probable | Prueba requerida | Fase |
|---|---|---|---|---|---|---|
| P1-01 | No existe generador de `config/cones/<HU>.json` — es 100% manual | Cada cono nuevo requiere trabajo humano previo idéntico al que ya se hizo para NCBE-1105/NCBE-661; no hay apalancamiento | C-28 | Nuevo script (p.ej. `qp_cone_bootstrap.py`) | Test que genere un borrador de config desde SP raíz + grafo descubierto | QP-GEN-02 |
| P1-02 | El agente no expone los modos ya existentes de `qp_pipeline.py` (discover/prepare/dry-run/run/regenerate) a nivel de invocación humana | El operador no puede pedir "solo descubre" sin ejecutar todo el flujo | C-53 | `agente-queryplan.md` (o su sucesor orquestador) | Manual: invocar cada modo y confirmar que se detiene donde corresponde | QP-GEN-03 |
| P1-03 | Falta capa de veredicto unificado (hoy son ~15+ veredictos internos sin agregación) | Un operador no técnico no puede interpretar el estado sin conocer el detalle interno | C-54 | Nuevo módulo de agregación de veredictos | Test de mapeo veredicto interno → veredicto unificado | QP-GEN-03 |
| P1-04 | El canon escrito (`agente-queryplan.md`/SKILL.md) no documenta PTY ni la capa de sanitización (`qp_capture_sanitize.py`) — solo viven en código + historial | Riesgo de regresión si alguien reescribe el agente sin leer el historial completo | C-38, C-45 | `agente-queryplan.md`, `query-plan/SKILL.md` | N/A (documentación) | QP-GEN-02 (actualización de canon, no código nuevo) |

**P2 — mejora de ergonomía**

| ID | Descripción | Riesgo | Capacidad afectada | Archivo probable | Prueba requerida | Fase |
|---|---|---|---|---|---|---|
| P2-01 | No hay lector de Excel/relaciones como fuente opcional | Bajo — Banco no ha exigido este input en los dos precedentes reales | C-07 | Nuevo módulo opcional | Solo si Banco lo requiere | QP-GEN-04 |
| P2-02 | Jerarquía de literales real (3 niveles) no coincide textualmente con la especulativa de 6 niveles mencionada como precedente en el propósito de esta auditoría | Bajo — la de 3 niveles ya es fail-closed y suficiente en los dos precedentes | C-34 | `agente-queryplan.md` (documentación) | N/A | QP-GEN-04 |
| P2-03 | No hay valor de timeout normado en el canon (solo empírico en historial, 120s) | Bajo-medio — riesgo de inconsistencia entre corridas si distintos operadores usan valores distintos | C-39 | `agente-queryplan.md`, `qp_tsql_pty.py` | Test de timeout con valor explícito documentado | QP-GEN-02 |

**P3 — hardening futuro**

| ID | Descripción | Riesgo | Capacidad afectada | Archivo probable | Prueba requerida | Fase |
|---|---|---|---|---|---|---|
| P3-01 | No se auditó en profundidad el mecanismo de "hardening de credenciales" mencionado en tests | Bajo — mencionado como ya probado, solo falta verificación puntual | C-46 | `qp_pipeline.py`, `test_qp_pipeline.py` | Revisión dirigida | QP-GEN-04 |
| P3-02 | Reintentos automáticos ante fallo transitorio de Sybase no confirmados | Bajo — `preflight` y `REQUIRES_SYBASE_RERUN` ya mitigan manualmente | C-42 | `qp_pipeline.py` | Test de reintento con conexión simulada inestable | QP-GEN-04 |

---

## 21. Plan QP-GEN-02 a QP-GEN-04

### QP-GEN-02 — Descubrimiento transitivo y paquetes dinámicos

- **Objetivo**: implementar el algoritmo de punto fijo (§9 del prompt original) sobre
  `qp_source_extract.py` (o un módulo nuevo `qp_dependency_graph.py`) que recorra recursivamente
  `extract_children`/`find_sp_source` con cola de trabajo, set de visitados, detección de ciclos y
  clasificación BUSINESS/TECHNICAL en cada nivel. Producir el modelo de grafo de §10
  (`unique_procedures`, `call_sites`, `dependency_edges`, `paths`, `packages_required`).
- **Archivos probables**: `qp_source_extract.py` (extender) o `qp_dependency_graph.py` (nuevo);
  `qp_pipeline.py` (nuevo subcomando `discover`); actualización de `agente-queryplan.md` para
  documentar PTY y sanitización (P1-04).
- **Pruebas**: los 10 fixtures sintéticos de §22 (raíz sin hijos, 1 hijo, profundidad 4, diamante,
  ciclo, llamadas repetidas, dependencia faltante, dependencia técnica con descendientes, mismo SP
  con formatos de nombre distintos, dos bases con mismo nombre de SP) + regresión contra NCBE-1105
  (debe seguir dando 1 paquete/0 hijos) y NCBE-661 (debe redescubrir el mismo grafo de 28 únicos/36
  entries/45 call-sites que ya está documentado, SIN usar `package_order[]` como entrada, solo como
  oráculo de verificación).
- **Gates**: el grafo descubierto para NCBE-661 debe coincidir con los conteos ya publicados en el
  manifest consolidado real; cualquier discrepancia bloquea el cierre de fase.
- **Riesgos**: un ciclo real no diagnosticado hoy podría aparecer al activar la recursión; mitigar
  con límite de profundidad configurable (no artificial por defecto, pero disponible como salvaguarda).
- **Criterio de cierre**: los dos precedentes se re-derivan automáticamente desde solo `sp_padre` (sin
  `package_order[]` pre-poblado) con los mismos conteos ya validados.

### QP-GEN-03 — Orquestador único end-to-end

- **Objetivo**: implementar `qp_orchestrator.py run-cone` (§16), integrando el grafo de QP-GEN-02 con
  los subcomandos ya existentes de `qp_pipeline.py`, exponiendo los modos de §17, y la capa de
  veredicto unificado de §18.
- **Archivos probables**: `qp_orchestrator.py` (nuevo); capa de resolución de identidad micro↔HU↔SP
  (nuevo módulo o extensión de `qp_pipeline.load_cone`).
- **Pruebas**: invocación con solo `--micro` (sin config de cono preexistente) debe producir un
  `config/cones/<HU>.json` candidato + reporte `DISCOVERY_COMPLETE`; invocación con ambigüedad debe
  producir `BLOCKED_INPUT_AMBIGUOUS`.
- **Gates**: no debe permitir `run` sin pasar por `discover`+`prepare`+`validate` en ese orden salvo
  que el operador provea explícitamente una config de cono ya validada.
- **Riesgos**: decisión de producto pendiente sobre remover la barrera "invocación humana explícita"
  (frontmatter + `disable-model-invocation`) — esto es una decisión consciente, no solo técnica.
- **Criterio de cierre**: `run-cone --root-sp <sp_conocido>` reproduce una entrega Bank Ready
  equivalente a una ya publicada, sin intervención manual más allá de la invocación inicial.

### QP-GEN-04 — Regresiones, pilotos y prompt maestro

- **Objetivo**: consolidar el prompt maestro mínimo (§19) como interfaz oficial, ejecutar un piloto
  con un cono nuevo no auditado aún (p. ej. Depósitos o Retiro, mencionados como "cantidad por
  descubrir" en el propósito original), y cerrar los gaps P2/P3.
- **Archivos probables**: nueva config de cono para el piloto elegido; ajustes de ergonomía en
  `qp_orchestrator.py`.
- **Pruebas**: piloto completo end-to-end con cantidades 100% descubiertas (no declaradas a mano).
- **Gates**: el piloto debe declarar sus propias cantidades de paquetes/QP sin que ningún número se
  copie de NCBE-1105 o NCBE-661.
- **Riesgos**: el cono piloto puede exponer patrones de EXEC no cubiertos por los fixtures sintéticos
  (p.ej. EXEC dinámico, C-11) — tratar como hallazgo nuevo, no como fallo de diseño.
- **Criterio de cierre**: `REUSABLE_FLOW_FOUNDATION_READY` alcanzable — el piloto se genera con el
  prompt mínimo sin edición manual de config previa.

---

## 22. Diseño de fixtures sintéticos (solo diseño, no creados)

Para QP-GEN-02, sin crearlos aún (según instrucción de no generarlos salvo necesidad exclusiva de
esta auditoría — no fue necesario, los precedentes reales bastaron para validar el estado actual):

1. **Raíz sin hijos**: 1 SP, 0 EXEC. Oráculo: `unique_procedures={raíz}`, `packages_required={raíz}`.
2. **Raíz con un hijo**: 1 EXEC directo. Oráculo: 2 nodos, 1 edge, 1 call site.
3. **Profundidad 4**: cadena lineal A→B→C→D→E. Oráculo: `nivel_minimo` 0..4, sin ciclo.
4. **Diamante**: A→B, A→C, B→D, C→D. Oráculo: D con `padres_inmediatos=[B,C]`, 1 nodo único para D
   pese a 2 rutas.
5. **Ciclo**: A→B→C→A. Oráculo: recorrido debe terminar (no colgarse), marcar `ciclo:true` en el path,
   los 3 nodos quedan en `unique_procedures` una sola vez cada uno.
6. **Llamadas repetidas**: A llama a B tres veces en distintas líneas. Oráculo: 1 edge A→B, 3
   call_sites, `ocurrencias=3` en B visto desde A.
7. **Dependencia faltante**: A llama a Z, Z no tiene fuente localizable. Oráculo: Z queda
   `estado_resolucion=NOT_FOUND`, no bloquea el resto del grafo, pero si Z es material para el
   alcance declarado, la entrega general no cierra (`BLOCKED_DEPENDENCY_GRAPH`).
8. **Dependencia técnica con descendientes**: A llama a `sp_gen_sec` (TECHNICAL_UTILITY) que a su vez
   llama a otro SP. Oráculo: `sp_gen_sec` se clasifica pero no se excluye; sus descendientes también
   se descubren (la regla "nunca se excluye" del canon real debe extenderse a profundidad N).
9. **Mismo SP con formatos de nombre distintos**: `Base..SP`, `base..sp` (mayúsculas/minúsculas),
   `owner.sp` sin base. Oráculo: los 3 formatos normalizan al mismo `normalized_id`.
10. **Dos bases con mismo nombre de procedimiento**: `baseA..sp_x` y `baseB..sp_x`. Oráculo: 2 nodos
    distintos en `unique_procedures` (la base es parte de la identidad), nunca se colapsan en 1.

---

## 23. Reporte creado

```
.claude/docs-qa/queryplan/generalizacion/audits/QP-GEN-01-REUSABLE-FLOW-AUDIT-AND-CONTRACT.md
```

Directorio `generalizacion/audits/` creado dentro de la estructura Query Plan existente
(`.claude/docs-qa/queryplan/`), consistente con el árbol ya presente (`audits/`, `casos/`,
`entregas/`). No se creó ningún otro directorio ni archivo.

---

## 24. Estado Git final

```bash
$ git status --short --branch
## master...origin/master
 M .claude/history/agente-queryplan.md   (preexistente, sin relación con esta sesión)
?? .claude/docs-qa/queryplan/generalizacion/   (nuevo, el reporte de esta auditoría)

$ git diff --cached --name-only
(vacío)
```

Índice vacío. Sin commit. Sin push. Sin ejecución Sybase. Sin modificaciones de código (`qp_*.py`,
`agentes/`, `skills/`, `schemas/`, `tests/` sin tocar). Sin cambios en entregas históricas
(`entregas/NCBE-1105-*`, `entregas/NCBE-661-*` sin tocar). Sin cambios en configuraciones de conos
(`config/cones/*.json` sin tocar, incluido el hallazgo P0-03 sobre NCBE-661.json — se documenta, no
se corrige). Sin cambios ajenos al trabajo de otra persona.

---

## 25. Siguiente paso permitido

Revisar este reporte con el equipo/Banco y decidir si se autoriza iniciar **QP-GEN-02** (descubrimiento
transitivo y paquetes dinámicos) como siguiente fase de implementación. No se debe iniciar
implementación de código sin esa autorización explícita.

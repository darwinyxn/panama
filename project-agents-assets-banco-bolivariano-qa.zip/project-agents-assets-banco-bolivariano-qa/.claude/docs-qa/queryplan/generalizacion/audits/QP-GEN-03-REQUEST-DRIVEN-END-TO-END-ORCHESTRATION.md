# QP-GEN-03 — Orquestación end-to-end basada en request

Continuación de QP-GEN-02C (`OPERATOR_ASSISTED_DISCOVERY_READY`). Convierte las capacidades
acumuladas (discovery transitivo, derivación dinámica de paquetes, contrato operador-asistido) en
un flujo único, reutilizable y operable mediante un request simple, orquestando `qp_pipeline.py`
sin duplicar ninguna lógica existente. No ejecuta Sybase, no genera entregas para un micro nuevo, no
modifica entregas ni Matrices de Equivalencia. Sin commit, sin push.

---

## 1. Veredicto

```
REQUEST_DRIVEN_ORCHESTRATION_READY
```

Justificación punto por punto:

- **Sin duplicación arquitectónica**: no se creó `qp_orchestrator.py` ni ningún pipeline paralelo.
  `qp_pipeline.py` sigue siendo el único entrypoint; el nuevo subcomando `pipeline` orquesta llamadas
  a `cmd_prepare`/`cmd_run`/`cmd_validate` y a `qp_regenerate.py` (ya existente, standalone) — nunca
  reimplementa su lógica. `qp_run_directory.py` es infraestructura de soporte (aislamiento de
  directorios, checkpoint), no un pipeline paralelo (declarado así en su propio docstring).
- **`--request` funcional y compatible con `--cone-config` legacy**: probado en ambos sentidos
  (solo-request, solo-cone-config, ambos-juntos-consistentes, ambos-juntos-contradictorios →
  `BLOCKED_REQUEST_CONFIG_MISMATCH`, nunca precedencia silenciosa).
- **`resolved-cone-config.json` derivado correctamente**: misma forma exacta que
  `qp_pipeline.load_cone` exige (verificado con `validate_runtime_config_shape`); nunca escrito en
  `config/cones/`; sin credenciales.
- **Run directory aislado real**: `/tmp/queryplan-<HU>-<RUN_ID>/`, 10 subdirectorios fijos,
  permisos 0700/0600 verificados con `stat` real, no con inspección de código.
- **Máquina de estados + checkpoint operativos**: `advance_state` rechaza saltos de paso
  (verificado con test), `BLOCKED`/`FAILED` alcanzables desde cualquier estado, checkpoint con
  `inputs_sha256`/`completed_steps`/`blocked_reason` reales.
- **Resume con verificación de hashes**: `--resume-run` con inputs sin cambios continúa; con un
  input alterado manualmente bloquea con `BLOCKED_RESUME_INPUT_CHANGED` (verificado, no solo
  diseñado).
- **Multicono sin selector bloquea, nunca infiere**: probado contra el archivo REAL de Firmantes
  (3 raíces/14 SPs) — `BLOCKED_PACKAGE_INVENTORY_AMBIGUITY` con reporte de conos
  detectados/entradas candidatas/selector faltante.
- **Modos implementados y verificados**: `discover-only`/`prepare-only`/`dry-run`/`regenerate`/
  `validate` ejecutados end-to-end en `/tmp`, sin Sybase; `run` bloquea correctamente sin
  `--allow-live-sybase` (ruta implementada, no ejercida).
- **Regresión Firmantes real**: los 4 modos sin Sybase ejecutados contra la config real de
  NCBE-1105; `regenerate` desde la entrega YA PUBLICADA produce contenido de archivo
  byte-idéntico dentro del ZIP (diff real, no solo hash del contenedor).
- **Regresión NCBE-661 real**: paridad EXACTA confirmada entre el subcomando standalone
  `discover-only --cone-config` (ya validado en fases previas) y el nuevo `pipeline --cone-config`
  — mismo veredicto (`BLOCKED_DEPENDENCY_GRAPH`), mismos 5 nodos bloqueantes. Reconciliación
  (12 declaradas = 12 reconciliadas) confirmada independiente del bloqueo de clasificación.
- **Seguridad verificada**: 0 credenciales en ningún artefacto de un run real con
  `informacion-librerias.json` (grep real sobre el árbol completo del run directory, no auditoría
  de código).
- **Determinismo verificado**: dos corridas en directorios `/tmp` distintos con timestamps
  distintos producen `dependency-graph.json`/`derived-package-plan.json`/`package-comparison.json`
  byte-idénticos; ZIP regenerado con mismo SHA-256 en ambas corridas.
- **Compatibilidad hacia atrás confirmada**: los 445 tests previos siguen en verde; el subcomando
  standalone `discover-only` sigue funcionando sin cambios de contrato; el CLI conserva todos los
  subcomandos previos (`--help` verificado).
- **Baseline de pruebas**: 478 passed, 0 failed (445 previos + 33 nuevos de `test_qp_gen_03.py`).

---

## 2. Estado Git

Precheck inicial (antes de tocar cualquier archivo de esta fase):

```
pwd:            /home/ssm-user/project-agents-assets-banco-bolivariano-qa
branch:         master
HEAD:           0e1733f5a378faf7666c0f1fccd2a3ebb96fcdf6
status:         M .claude/history/agente-queryplan.md   (preexistente, ajeno — QP-CF-22)
                ?? .claude/docs-qa/inputs/scripts/queryplan/{qp_dependency_graph.py,
                   qp_mapping_import.py, qp_request.py, schema/*, tests/test_qp_gen_02*.py}
                   (QP-GEN-02/02B/02C, no publicados aún)
                ?? .claude/docs-qa/queryplan/generalizacion/   (reportes previos)
staged:         (vacío)
ahead/behind:   0 / 0
```

No se exigió working tree limpio (instrucción explícita del encargo: los cambios de fases previas
no publicadas son esperados). Se continuó en `master`, sin ramas/worktrees nuevas, sin
checkout/switch/reset/rebase/merge/pull/stash, sin tocar `.claude/history/agente-queryplan.md`, sin
`git add .`/`-A`/`commit -a`. HEAD no se movió durante toda la sesión (confirmado al cierre,
sección 21).

**Inventario de archivos acumulados de fases previas** (auditado antes de extender, para no
reimplementar ni contradecir):

| Archivo | Estado Git | Fase de origen | Propósito |
|---|---|---|---|
| `qp_pipeline.py` | modificado | QP-GEN-02→03 | Entrypoint canónico; extendido con `discover-only` (02/02C) y `pipeline` (03) |
| `qp_source_extract.py` | modificado | QP-GEN-02B/02C | Resolver único de fuente + servicio de materialidad compartido |
| `qp_dependency_graph.py` | nuevo (no publicado) | QP-GEN-02/02B | Discovery transitivo + derivación de paquetes |
| `qp_mapping_import.py` | nuevo (no publicado) | QP-GEN-02B/02C | Importador sanitizado de `informacion-librerias.json` |
| `qp_request.py` | nuevo (no publicado) | QP-GEN-02C→03 | Contrato de request + reconciliación + runtime config (extendido en 03) |
| `qp_run_directory.py` | nuevo (esta fase) | QP-GEN-03 | Run directory aislado, máquina de estados, checkpoint/resume |
| `qp_regenerate.py` | sin cambios | previo a QP-GEN-02 | Regeneración presentación-only desde ZIP ya publicado (reusado, no modificado) |
| `qp_provenance.py`, `qp_delivery.py`, `qp_manifest.py`, `qp_lint.py` | sin cambios | previos | Reusados sin modificación vía `cmd_prepare`/`cmd_run`/`cmd_validate` |
| `qp_tsql_pty.py`, `qp_capture_sanitize.py` | sin cambios | previos | NO tocados en esta fase (ningún defecto bloqueante encontrado que lo justificara) |

**Auditoría del código real vs lo documentado en los 3 reportes previos**: se leyeron
QP-GEN-01/02/02B/02C completos y se confirmó que el código en disco coincide con sus afirmaciones
(sin discrepancias) antes de extender. `qp_pipeline.load_cone` exige exactamente 6 claves
(`cone_hu`/`sp_padre`/`criterio_banco_version`/`sybase`/`packages`/`package_order`) — esta
invariante es el habilitador central de toda la arquitectura de esta fase (sección 3).

---

## 3. Decisión arquitectónica: sin pipeline paralelo

Confirmada e implementada exactamente como la exige el encargo: no se creó `qp_orchestrator.py` ni
ningún módulo paralelo de orquestación. No se demostró ninguna imposibilidad técnica que lo
justificara — al contrario, se confirmó que la forma de diccionario que `load_cone` ya exige
(`_REQUIRED_CONE_KEYS` en `qp_request.py`) es suficiente para que **cualquier** diccionario con esa
forma, sin importar su origen (archivo en `config/cones/` o derivado en memoria desde un request),
funcione con **todos** los comandos existentes sin modificarlos.

Esto se verificó de forma directa: `derive_runtime_config()` construye ese diccionario desde
`(request normalizado, grafo descubierto, plan reconciliado)`, se escribe a
`runtime-config/resolved-cone-config.json` dentro del run directory, y se pasa como `--cone-config`
a `cmd_prepare`/`cmd_run`/`cmd_validate` exactamente como se pasaría una config real de
`config/cones/`. `validate_runtime_config_shape()` es el gate explícito que dispararía
`BLOCKED_ARCHITECTURE_DUPLICATION` si esta invariante se rompiera en el futuro — no se disparó
en ninguna corrida de esta fase.

`qp_run_directory.py` es infraestructura de soporte (aislamiento de directorios + máquina de
estados + checkpoint), declarada explícitamente como tal en su propio docstring — no contiene
ninguna lógica de discovery/package-planning/source-resolution/execution/sanitization/delivery/
validation, que sigue viviendo exclusivamente en los módulos ya existentes.

---

## 4. Contrato de request extendido

`schema/queryplan-request-v1.schema.json` (heredado de QP-GEN-02C, extendido en esta fase con
`mode`, y ya tenía `sp_source_roots`/`repos_roots` desde su diseño original):

```json
{
  "request_version": "1.0",
  "hu_cono": "NCBE-1105",
  "micro": "cpas-mso-consulta-firmante",
  "root_sp": "firmas..pa_fir_consulta_firmante",
  "environment": "QA",
  "mode": "discover-only",
  "sp_source_roots": ["..."],
  "repos_roots": ["..."],
  "package_inventory": { "source_type": "explicit", "entries": [ ... ] }
}
```

`mode` ∈ `{discover-only, prepare-only, dry-run, run, regenerate, validate, null}` — declarativo,
para trazabilidad; el CLI (`--mode`) sigue siendo la fuente de verdad operativa.

**Rechazo explícito de campos de cantidad** (`additionalProperties:false` estructural, verificado
con test para los 5 nombres exigidos por el encargo):

```python
for field in ("package_count", "library_count", "dependency_count", "maximum_depth", "zip_count"):
    req = {"request_version": "1.0", "root_sp": "base..sp_x", field: 5}
    assert R.validate_request_schema(req) != []   # BLOCKED_REQUEST_INVALID
```

Ver `queryplan-request.example.json` (plantilla sin valores reales, validada contra el schema real)
para el formato completo documentado.

---

## 5. Compatibilidad `--request` / `--cone-config`

Tres combinaciones, todas probadas contra la config real de NCBE-1105:

1. **Solo `--cone-config`** (100% legacy): `cmd_pipeline` sintetiza un request normalizado
   internamente desde `packages`/`sp_padre`/`sp_source_roots` de la cone-config — comportamiento
   idéntico a invocar los subcomandos individuales. Verificado: `DISCOVERY_COMPLETE`, exit 0.
2. **Solo `--request`**: requiere `sp_source_roots` en el propio request (no se infiere de
   ninguna otra fuente). Verificado: `DISCOVERY_COMPLETE`, exit 0.
3. **Ambos**: `cross_validate_request_and_cone_config()` compara `hu_cono`/`root_sp`/conjunto de
   paquetes declarados. Consistentes → pasa. Contradictorios (`hu_cono` deliberadamente distinto)
   → `BLOCKED_REQUEST_CONFIG_MISMATCH`, exit 50 — **nunca hay precedencia silenciosa** de una
   fuente sobre otra, confirmado leyendo el código (no hay ningún `if`/`elif` que descarte una
   fuente sin antes comparar) y con test que fuerza la contradicción.

---

## 6. `resolved-cone-config.json`: runtime config derivada

`derive_runtime_config(normalized_request, graph, plan, ...)` produce un diccionario con
EXACTAMENTE las 6 claves que `load_cone` exige, más las claves adicionales que `cmd_prepare` ya
consumía en fases previas (`analysis_roots`, `sp_source_roots`, `repos_roots`) — nunca un formato
paralelo. Solo incluye paquetes CONFIRMADOS (`requires_package=True`) del plan reconciliado —
nunca todos los nodos descubiertos. Sin credenciales, tokens, connection strings ni datos
funcionales — `repository`/`module`/`hu_individual` llegan ya sanitizados desde
`qp_mapping_import`/`derive_package_plan`.

Se escribe únicamente en `<run-dir>/runtime-config/resolved-cone-config.json`, con permisos 0600
(`RD.write_sensitive_file`). Nunca en `config/cones/` — confirmado con test que compara el listado
de `config/cones/` antes y después de una corrida completa (sin diferencia).

---

## 7. Run directory aislado

`build_run_directory_path(base_tmp, hu_cono, run_id)` produce
`/tmp/queryplan-<HU>-<RUN_ID>/`, con `hu_cono`/`run_id` sanitizados contra un charset seguro
(`^[A-Za-z0-9_.-]+$`) antes de usarse en una ruta de filesystem — previene inyección de
separadores/path traversal.

Subdirectorios fijos (`RUN_SUBDIRS`): `request/discovery/package-plan/runtime-config/prepare/
execution/delivery/validation/reports/checkpoint`. Verificado con `stat` real (no solo lectura de
código) sobre una corrida real:

```
700 .../queryplan-NCBE-1105-r1
700 .../queryplan-NCBE-1105-r1/request
700 .../queryplan-NCBE-1105-r1/discovery
700 .../queryplan-NCBE-1105-r1/package-plan
700 .../queryplan-NCBE-1105-r1/runtime-config
700 .../queryplan-NCBE-1105-r1/prepare
700 .../queryplan-NCBE-1105-r1/execution
700 .../queryplan-NCBE-1105-r1/delivery
700 .../queryplan-NCBE-1105-r1/validation
700 .../queryplan-NCBE-1105-r1/reports
700 .../queryplan-NCBE-1105-r1/checkpoint
600 .../queryplan-NCBE-1105-r1/checkpoint/checkpoint.json
600 .../queryplan-NCBE-1105-r1/runtime-config/resolved-cone-config.json
```

---

## 8. Secuencia canónica de 11 pasos y gates

| # | Paso | Gate de salida | Módulo (reusado, no duplicado) |
|---|------|-----------------|-------------------------------|
| 1 | Request | `REQUEST_VALID` / `BLOCKED_REQUEST_INVALID` | `qp_request.validate_request_schema`/`normalize_request` |
| 2 | Inventario | `PACKAGE_INVENTORY_VALID` / `BLOCKED_PACKAGE_INVENTORY_AMBIGUITY` | `qp_request.resolve_package_inventory`, `qp_mapping_import` |
| 3 | Discovery | `DEPENDENCY_GRAPH_COMPLETE` / `BLOCKED_DEPENDENCY_GRAPH` | `qp_dependency_graph.discover_graph`/`evaluate_completeness` |
| 4 | Reconciliación | `PACKAGE_PLAN_RECONCILED` / `BLOCKED_PACKAGE_RECONCILIATION` | `qp_request.reconcile_package_inventory`/`evaluate_reconciliation` |
| 5 | Runtime config | `RUNTIME_CONFIG_READY` / `BLOCKED_ARCHITECTURE_DUPLICATION` | `qp_request.derive_runtime_config`/`validate_runtime_config_shape` |
| 6 | Prepare | `PREPARE_READY` / `BLOCKED_LITERAL_MAPPING` | `qp_pipeline.cmd_prepare` (sin cambios) |
| 7 | Ejecución/Regeneración | `EXECUTION_COMPLETE`/`DELIVERY_COMPLETE` / `BLOCKED_LIVE_EXECUTION_NOT_AUTHORIZED`/`BLOCKED_SYBASE` | `cmd_run` (sin cambios, no ejercido) / `qp_regenerate.regenerate` (sin cambios) |
| 8 | Sanitización | `SANITIZATION_COMPLETE` | Ya dentro de `qp_delivery`/`cmd_run`/`qp_regenerate` (sin cambios) |
| 9 | Delivery | `DELIVERY_GENERATED` | Ya dentro de `cmd_run`/`qp_regenerate` (sin cambios) |
| 10 | Validación | `VALIDATION_COMPLETE` / `BLOCKED_DELIVERY_VALIDATION` | `qp_pipeline.cmd_validate` (sin cambios) |
| 11 | Publicación local | **NO ejecutado en esta fase** (acción separada, explícita) | — |

Ninguno de los pasos 6-10 reimplementa lógica: `cmd_pipeline` invoca las funciones `cmd_*`
existentes mediante `_NsArgs` (namespace mínimo compatible con `argparse.Namespace`), pasándoles
`runtime_cfg_path` como `--cone-config`.

---

## 9. Máquina de estados y checkpoint

Secuencia (`qp_run_directory.STATE_SEQUENCE`): `REQUESTED → REQUEST_VALIDATED →
INVENTORY_IMPORTED → DISCOVERY_COMPLETE → PACKAGE_PLAN_READY → RUNTIME_CONFIG_READY →
PREPARE_COMPLETE → EXECUTION_COMPLETE → SANITIZATION_COMPLETE → DELIVERY_COMPLETE →
VALIDATION_COMPLETE → BANK_READY`. `BLOCKED`/`FAILED` alcanzables desde cualquier estado.

`advance_state(checkpoint, new_state)` verifica que `new_state` sea exactamente el siguiente en la
secuencia respecto al estado actual — rechaza saltos (verificado: intentar avanzar de
`DISCOVERY_COMPLETE` directo a `PREPARE_COMPLETE`, saltando `PACKAGE_PLAN_READY`, devuelve
`False`).

`checkpoint.json` (0600): `{state, timestamp_utc, pipeline_version, inputs_sha256,
completed_steps, blocked_reason, artifacts}`. La metadata variable (`timestamp_utc`) vive en un
campo separado de los artefactos deterministas (`dependency-graph.json`, `derived-package-plan.json`)
— nunca los contamina (confirmado en la sección 15, determinismo).

Verificado con un bloqueo real: un `root_sp` inexistente detiene el flujo ANTES de invocar
`cmd_prepare` (`completed_steps` no contiene `PREPARE_COMPLETE`), y el checkpoint queda en estado
`BLOCKED` con `blocked_reason` no vacío.

---

## 10. Resume

`--resume-run <run-dir>` reutiliza el run directory existente, recalcula `inputs_sha256`
(hash de request normalizado + `dependency-graph.json` + `derived-package-plan.json` +
`resolved-cone-config.json`) y los compara contra los guardados en el checkpoint original vía
`verify_resume_inputs()`.

Verificado en dos escenarios:
- **Inputs sin cambio**: resume continúa normalmente (exit 0).
- **Input alterado deliberadamente** (se editó `inputs_sha256.request` en el checkpoint para
  simular una discrepancia): bloquea con `BLOCKED_RESUME_INPUT_CHANGED`, exit 51 — nunca reutiliza
  evidencia potencialmente incompatible.

---

## 11. Multicono sin selector

`MI.detect_multi_cone_roots()` detecta señal ESTRUCTURAL (`is_root=True` en >1 entrada) de que un
`informacion-librerias.json` cubre varios conos. Verificado contra el archivo REAL de Firmantes
(3 raíces: `pa_fir_consulta_firmante`, `sp_ah_depositosl_rc`, `sp_ah_retiro_rc`; 14 SPs en total):

```
VERDICT: BLOCKED_PACKAGE_INVENTORY_AMBIGUITY
conos_detectados=3
entradas_candidatas=['firmas..pa_fir_consulta_firmante', 'cob_ahorros..sp_ah_depositosl_rc',
                     'cob_ahorros..sp_ah_retiro_rc']
```

`package-plan/package-inventory-ambiguity-report.json` documenta conos detectados, entradas
candidatas y el selector faltante — nunca se infiere por proximidad, orden ni nombre parcial. La
resolución correcta (declarar `source_type=explicit` con solo las entradas del cono deseado) fue
verificada explícitamente: no dispara el gate de multicono y completa normalmente.

---

## 12. Modos: comportamiento verificado

| Modo | Comportamiento verificado |
|------|---------------------------|
| `discover-only` | Detiene en `PACKAGE_PLAN_READY`; `prepare/` queda vacío; sin Sybase. |
| `prepare-only` | Alcanza `PREPARE_COMPLETE` vía `cmd_prepare` real; `EXECUTION_COMPLETE` ausente de `completed_steps`; sin Sybase. |
| `dry-run` | Mismo comportamiento que `prepare-only` en esta fase (simulación sin Sybase). |
| `run` | Sin `--allow-live-sybase`: bloquea con `BLOCKED_LIVE_EXECUTION_NOT_AUTHORIZED`, exit 46. Ruta con Sybase implementada pero NO ejercida en esta fase. |
| `regenerate` | Requiere `--legacy-seed dir:<entrega-publicada>`; sin él, bloquea. Con él: copia el seed a `<run-dir>/delivery/` (nunca modifica el original), invoca `qp_regenerate.regenerate()` (standalone, sin capturas frescas), produce `REGENERATED_BANK_READY`. |
| `validate` | Corre `cmd_validate` sobre `<run-dir>/delivery/`; sobre un directorio sin delivery poblado, falla explícito (no genera ni regenera nada por su cuenta). |

---

## 13. Regresión Firmantes (NCBE-1105)

Ejecutados los 4 modos sin Sybase contra `config/cones/NCBE-1105.json` real, en `/tmp`:

- **`discover-only`**: `DISCOVERY_COMPLETE`, exit 0.
- **`prepare-only`**: `PREPARE_READY`, exit 0 (`PIPELINE_PROVENANCE_READY_PREPARE_READY` interno,
  1 paquete, 5 entries, 5 payloads, 0 bloqueados).
- **`regenerate`** (desde la entrega YA PUBLICADA
  `.claude/docs-qa/queryplan/entregas/NCBE-1105-queryplan-2026-07-09-statistics-io/`, copiada
  primero a `/tmp`, nunca leída/escrita in-place): `REGENERATED_BANK_READY`, exit 0.
  - Comparación byte-a-byte del contenido de cada archivo dentro del ZIP (`manifest-queryplan.json`,
    `detalle_ejecucion.qp`, `observaciones.qp`) entre el original publicado y el regenerado en
    `/tmp`: **idéntico** (`diff -r` sin salida).
  - El `zip_sha256` del contenedor SÍ cambia (`cf2f0550...` → `c48d67a6...`) porque
    `qp_regenerate.py` fija el timestamp del ZIP a una constante (`FIXED_ZIP_DT = (2026,7,14,...)`,
    preexistente, no modificada en esta fase) distinta a la que tenía la entrega original —
    diferencia de metadata del contenedor, explicada campo por campo, no de contenido técnico.
  - El manifest regenerado agrega 3 campos (`criterio_presentacion_version`, `nota_normalizacion`,
    `zip_bytes`) que ya produce `qp_normalize.py` (comportamiento preexistente de la normalización
    determinista, sin relación con esta fase) — el criterio TÉCNICO de rendimiento
    (`2026-07-09-statistics-io`) no cambió: mismos QP, mismas observaciones, mismo IO.
  - La entrega ORIGINAL fuera del run directory se confirmó intacta (mismo `namelist()`/contenido
    antes y después).
- **`validate`** (sobre el run directory recién regenerado): `QUERYPLAN_BANK_READY`, exit 0
  (`VALIDATE: PASS`).

---

## 14. Regresión NCBE-661

Ejecutados `discover-only`/`prepare-only`/`validate` contra `config/cones/NCBE-661.json` real, en
`/tmp`:

- **`discover-only` (vía `pipeline --cone-config`)**: `BLOCKED_DEPENDENCY_GRAPH`, exit 42.
- **`discover-only` (vía subcomando standalone, ya validado en fases previas)**: mismo veredicto
  interno `BLOCKED_PACKAGE_CLASSIFICATION`.
- **Paridad exacta confirmada**: los 5 nodos bloqueantes son idénticos por ambos caminos —
  `sp_ahndc_automatica`, `sp_genera_linea_pendiente`, `sp_ccndc_automatica`, `sp_uif_acum`,
  `sp_imp_valor_agregado` — inspeccionando `evaluate_completeness()` sobre el
  `dependency-graph.json` real escrito por cada camino.
- **`prepare-only`/`validate` (vía `pipeline --cone-config`)**: ambos bloquean en el mismo punto
  (`BLOCKED_DEPENDENCY_GRAPH`, exit 42) — el flujo se detiene correctamente ANTES de intentar
  `prepare` cuando discovery no completó, sin excepciones no controladas.
- **Reconciliación de inventario, verificada de forma independiente del bloqueo de grafo** (vía
  `--request` con `informacion-librerias.json` real de NCBE-661, que sí permite separar ambos
  conceptos): 12 declaradas = 12 únicas = 12 deduplicadas = 12 reconciliadas, sin conflictos —
  confirmando que el gate que realmente bloquea es la clasificación de negocio pendiente (una
  decisión humana real, documentada desde QP-GEN-02), no un defecto de la reconciliación ni de la
  orquestación nueva de esta fase.
- **Este comportamiento NO es una regresión**: es la limitación real y ya conocida desde QP-GEN-02
  (5 SPs migrados por IA no listados en `determinar-call-strategy.sh`), reproducida
  IDÉNTICAMENTE por la nueva orquestación — no se introdujo ningún defecto nuevo al construir
  `pipeline`.

---

## 15. Seguridad

Verificado sobre un run directory real completo (`prepare-only` con `informacion-librerias.json`
REAL de Firmantes, que contiene un GitHub PAT en texto plano):

- **Grep recursivo sobre TODO el árbol del run directory** (`request/`, `discovery/`,
  `package-plan/`, `runtime-config/`, `prepare/`, `checkpoint/`) buscando
  `token|github_pat|password|passwd|secret|x-access-token`: **0 coincidencias**.
- **`checkpoint.json` específicamente**: confirmado sin credenciales (puede legítimamente contener
  rutas de filesystem, pero nunca secretos).
- Los canales ya verificados en QP-GEN-02C (import directo, request normalizado, artefacto
  sanitizado en disco, mensaje de error) siguen intactos — no se modificó `qp_mapping_import.py`
  en esta fase.

---

## 16. Determinismo

Dos corridas independientes, en directorios `/tmp` distintos, con timestamps distintos
(`2026-08-09T00:00:00Z` vs `2026-08-09T05:00:00Z`), contra la misma config de Firmantes:

- `discovery/dependency-graph.json`: **byte-idéntico**.
- `package-plan/derived-package-plan.json`: **byte-idéntico**.
- `package-plan/package-comparison.json`: **byte-idéntico**.
- `runtime-config/resolved-cone-config.json`: difiere únicamente en `analysis_roots` (que
  legítimamente apunta a la ruta de CADA run directory, no una variación espuria).
- ZIP regenerado (mismo seed, dos corridas independientes en `/tmp` distintos): mismo
  `sha256_file()` en ambas.

---

## 17. Compatibilidad hacia atrás

- Los 445 tests previos a esta fase siguen pasando sin modificación de sus aserciones.
- El subcomando standalone `discover-only --cone-config` (sin `pipeline`) sigue funcionando sin
  cambios de contrato — verificado con test dedicado.
- `python3 qp_pipeline.py --help` confirma que los 8 subcomandos previos (`inventory`,
  `discover-only`, `prepare`, `preflight`, `run`, `regenerate`, `diagnose`, `validate`) siguen
  presentes, más el nuevo `pipeline` — ninguno renombrado ni eliminado.
- Ningún flag existente fue removido o renombrado.

---

## 18. Baseline de pruebas

| Archivo | Tests | Origen |
|---|---|---|
| `test_qp_normalize.py` | 41 | previo |
| `test_qp_manifest_v2.py` | 82 | previo |
| `test_qp_pipeline.py` | 184 | previo (43 líneas nuevas de wrap, sin nuevas funciones `test_`, en fase 02C) |
| `test_qp_provenance.py` | 23 | previo |
| `test_qp_dependency_graph.py` | 50 | QP-GEN-02/02B |
| `test_qp_gen_02b.py` | 33 | QP-GEN-02B/02C |
| `test_qp_gen_02c.py` | 32 | QP-GEN-02C |
| `test_qp_gen_03.py` | 33 | **QP-GEN-03 (esta fase)** |
| **Total** | **478** | |

```
python3 -m pytest tests/ -q
478 passed in 57.45s
```

Reconciliación con el histórico documentado (328→372→407→445, QP-GEN-02C sección 11): 445 + 33
nuevos de `test_qp_gen_03.py` = **478**. Sin discrepancias sin explicar; ningún test previo se
eliminó ni se renombró.

`test_qp_gen_03.py` cubre (33 tests, mapeados a los 20+ casos adversariales exigidos):
contrato de request (campos de cantidad prohibidos, enum de `mode`), compatibilidad
`--request`/`--cone-config` en sus 3 combinaciones + contradicción, permisos de run directory
(0700/0600) y ausencia de residuo en `config/cones/`, máquina de estados (rechazo de saltos,
`BLOCKED` desde cualquier estado, checkpoint con `blocked_reason`), resume (éxito e
`BLOCKED_RESUME_INPUT_CHANGED`), multicono (bloqueo real + alcance explícito sin bloqueo), los 6
modos, regresión Firmantes real vía `regenerate` (comparación byte-a-byte de contenido de ZIP),
paridad NCBE-661 standalone-vs-pipeline, seguridad (0 credenciales en árbol completo), determinismo
(dos corridas, grafo/plan/ZIP), y compatibilidad hacia atrás (subcomandos intactos).

---

## 19. Artefactos producidos por una corrida real (ejemplo)

Corrida `pipeline --cone-config config/cones/NCBE-1105.json --mode regenerate --legacy-seed
dir:<seed>` sobre `/tmp/queryplan-NCBE-1105-<RUN_ID>/`:

```
request/queryplan-request.normalized.json          (0600 vía escritura sensible; contenido sin PII)
discovery/dependency-graph.json                     (grafo completo: 6 nodos, root+5 hijos técnicos)
package-plan/derived-package-plan.json              (1 paquete confirmado: pa_fir_consulta_firmante)
package-plan/package-comparison.json                (reconciliación: 1 reconciled_packages)
runtime-config/resolved-cone-config.json             (0600; misma forma que config/cones/*.json)
prepare/analysis/pa_fir_consulta_firmante/queryplan/provenance-queryplan.json
delivery/zips/pa_fir_consulta_firmante-queryplan.zip (byte-idéntico en contenido al publicado)
delivery/manifest-consolidado-queryplan.json
checkpoint/checkpoint.json                           (0600; state=DELIVERY_COMPLETE)
```

---

## 20. Archivos modificados/creados en esta fase

**Modificados**:
- `qp_pipeline.py`: agregado `cmd_pipeline`, `_resolve_effective_cone`, `_NsArgs`,
  `_load_request_or_die`, `_MODE_TARGET_STATE`, `_HIGH_LEVEL_VERDICT_EXIT`, `PIPELINE_VERSION`,
  subcomando `pipeline` registrado en `main()`.
- `qp_request.py`: agregado `BLOCKED_ARCHITECTURE_DUPLICATION`, `RUNTIME_CONFIG_READY`,
  `_REQUIRED_CONE_KEYS`, `DEFAULT_CRITERIO_BANCO_VERSION`, `derive_runtime_config`,
  `validate_runtime_config_shape`, `BLOCKED_REQUEST_CONFIG_MISMATCH`,
  `cross_validate_request_and_cone_config`. `normalize_request` corregido para propagar
  `sp_source_roots`/`repos_roots`/`mode`/`package_inventory` (bug encontrado y corregido en esta
  fase, sección 22).
- `schema/queryplan-request-v1.schema.json`: agregados `mode`, `sp_source_roots`, `repos_roots`
  (algunos ya existían desde QP-GEN-02C; `mode` es nuevo de esta fase).
- `README.md`: nueva sección "Orquestación end-to-end (`pipeline`)".

**Creados (nuevos en esta fase)**:
- `qp_run_directory.py`: run directory aislado, máquina de estados, checkpoint/resume.
- `queryplan-request.example.json`: plantilla documentada, validada contra el schema real, sin
  valores sensibles.
- `tests/test_qp_gen_03.py`: 33 tests.
- Este reporte.

**NO modificados** (confirmado explícitamente, ningún defecto bloqueante lo justificó):
`qp_tsql_pty.py`, `qp_capture_sanitize.py`, `qp_delivery.py`, `qp_manifest.py`, `qp_lint.py`,
`qp_provenance.py`, `qp_regenerate.py`, `qp_dependency_graph.py`, `qp_mapping_import.py`, ninguna
entrega en `.claude/docs-qa/queryplan/entregas/`, ninguna Matriz de Equivalencia, ningún
repositorio de negocio, `config/cones/NCBE-1105.json`, `config/cones/NCBE-661.json`.

---

## 21. Estado Git final

```
pwd:            /home/ssm-user/project-agents-assets-banco-bolivariano-qa
branch:         master
HEAD:           0e1733f5a378faf7666c0f1fccd2a3ebb96fcdf6   (idéntico al del precheck — no se movió)
ahead/behind:   0 / 0
staged:         (vacío)
status:
  M .claude/docs-qa/inputs/scripts/queryplan/README.md
  M .claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py
  M .claude/docs-qa/inputs/scripts/queryplan/qp_source_extract.py    (heredado de QP-GEN-02B/02C)
  M .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_pipeline.py (heredado de QP-GEN-02C)
  M .claude/history/agente-queryplan.md   (preexistente, ajeno — QP-CF-22, sin tocar en esta fase)
  ?? .claude/docs-qa/inputs/scripts/queryplan/qp_dependency_graph.py   (QP-GEN-02/02B)
  ?? .claude/docs-qa/inputs/scripts/queryplan/qp_mapping_import.py    (QP-GEN-02B/02C)
  ?? .claude/docs-qa/inputs/scripts/queryplan/qp_request.py           (QP-GEN-02C, extendido aquí)
  ?? .claude/docs-qa/inputs/scripts/queryplan/qp_run_directory.py     (QP-GEN-03, nuevo)
  ?? .claude/docs-qa/inputs/scripts/queryplan/queryplan-request.example.json (QP-GEN-03, nuevo)
  ?? .claude/docs-qa/inputs/scripts/queryplan/schema/queryplan-dependency-graph-v1.schema.json
  ?? .claude/docs-qa/inputs/scripts/queryplan/schema/queryplan-mapping-relaciones-v1.schema.json
  ?? .claude/docs-qa/inputs/scripts/queryplan/schema/queryplan-request-v1.schema.json
  ?? .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_dependency_graph.py
  ?? .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_gen_02b.py
  ?? .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_gen_02c.py
  ?? .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_gen_03.py (QP-GEN-03, nuevo)
  ?? .claude/docs-qa/queryplan/generalizacion/audits/QP-GEN-03-REQUEST-DRIVEN-END-TO-END-ORCHESTRATION.md
```

Sin Sybase ejecutado. Sin entregas modificadas (confirmado byte-a-byte, sección 13). Sin Matrices
ni repositorios de negocio tocados. Sin stage. Sin commit. Sin push. Todos los artefactos de
ejecución de esta fase se escribieron y limpiaron bajo `/tmp` (ningún residuo fuera del repo o de
`/tmp` al cierre).

---

## 22. Limitaciones, gaps abiertos y siguiente paso permitido

**Limitaciones confirmadas (no bugs)**:
- NCBE-661 tiene 5 nodos genuinamente sin clasificar por `determinar-call-strategy.sh` — requiere
  decisión humana de clasificación antes de poder completar `discover-only`/`prepare-only`/
  `validate` para ese cono vía la nueva orquestación (idéntico al subcomando standalone).
- `--mode run` (con Sybase real) está implementado pero deliberadamente NO ejercido en esta fase,
  por restricción explícita del encargo.

**Bug encontrado y corregido durante esta fase** (documentado para trazabilidad, no oculto):
`normalize_request()` originalmente no propagaba `sp_source_roots`/`repos_roots`/`mode`/
`package_inventory` al documento normalizado devuelto, causando `BLOCKED_REQUEST_INVALID` en
cualquier invocación posterior que dependiera de esos campos. Corregido agregándolos al diccionario
de retorno; cubierto por los tests de compatibilidad `--request`-solo en `test_qp_gen_03.py`.

**Gaps abiertos, explícitamente fuera de alcance de esta fase**:
- Paso 11 (publicación local a `.claude/docs-qa/queryplan/entregas/`) no implementado — acción
  separada y explícita, por diseño.
- No existe generador automático de `config/cones/<HU>.json` para un cono completamente nuevo sin
  ningún dato previo (P1-01 de QP-GEN-01) — el request SÍ permite operar sin una cone-config
  preexistente, pero `sp_source_roots` debe proveerse manualmente.
- No se ejecutó un piloto con un cono nunca antes auditado (reservado para QP-GEN-04, según el
  plan original de QP-GEN-01 sección 21).

**Siguiente paso permitido**: QP-GEN-04 — piloto con un cono nuevo (cantidades 100% descubiertas,
sin copiar de NCBE-1105/NCBE-661), cierre de gaps P2/P3, y declaración del prompt maestro (borrador
abajo) como interfaz oficial final.

---

## Borrador de prompt maestro (no final — declaración oficial pendiente de QP-GEN-04)

Refleja lo realmente implementado y verificado en esta fase — el operador provee un
`queryplan-request-v1.json` (nunca cantidades) y el pipeline calcula todo lo demás:

```text
Ejecuta el pipeline Query Plan para el request <ruta-a-queryplan-request-v1.json>,
en modo <discover-only|prepare-only|dry-run|regenerate|validate>,
bajo un run directory aislado en /tmp.

Descubre transitivamente todas las dependencias desde el SP raíz declarado,
reconcilia el inventario de paquetes contractual del operador contra el grafo
descubierto, y detente en el estado correspondiente al modo solicitado.

No ejecutes Sybase salvo que el modo sea "run" y se autorice explícitamente
con --allow-live-sybase. No modifiques entregas ya publicadas, Matrices de
Equivalencia ni repositorios de negocio. No hagas commit ni push.
```

La forma "con datos conocidos" (proveyendo también `--cone-config`) sigue siendo válida y ahora
además se valida cruzadamente contra el request — ninguna de las dos formas requiere que el
operador declare ninguna cantidad (paquetes, librerías, dependencias, profundidad, ZIPs): todas se
calculan.

# QP-GEN-02 — Descubrimiento transitivo y determinación dinámica de paquetes

Continuación de QP-GEN-01 (`REUSABLE_FLOW_FOUNDATION_PARTIAL`, gap P0-01: C-14 recorrido transitivo
= MISSING). Esta fase implementa esa capacidad. No ejecuta Sybase, no genera entregas Bank Ready, no
implementa el orquestador end-to-end de QP-GEN-03. Sin commit, sin push.

---

## 1. Veredicto

```
TRANSITIVE_DISCOVERY_READY
```

Justificación punto por punto (criterios de la sección 26 del encargo):

- Grafo transitivo funciona: BFS por punto fijo desde el SP raíz, sin límite de profundidad
  funcional, verificado hasta profundidad real 5 contra NCBE-661 y profundidad sintética 4 en
  fixtures.
- No existe límite fijo funcional: `DEFAULT_MAX_NODES_SAFETY_LIMIT=5000` es puramente defensivo
  (bloquea con `BLOCKED_DISCOVERY_SAFETY_LIMIT`, nunca trunca en silencio); verificado con test que
  fija el límite artificialmente bajo y confirma el bloqueo explícito.
- Deduplicación funciona: 1 nodo único por identidad normalizada aunque tenga N padres/call-sites
  (verificado con diamante sintético y con NCBE-661 real: 45 nodos únicos vs 74 call sites).
- Ciclos funcionan: detectados sin loop infinito, sin duplicar nodos, sin borrar edges, sin ocultar
  call sites (test de ciclo A→B→C→A: 3 nodos, 3 edges, 1 ciclo registrado).
- Múltiples padres funcionan: diamante sintético produce 1 nodo con 2 padres inmediatos y 2 rutas.
- Package eligibility está separada: `classify_nodes` (clasificación) y
  `determine_required_packages` (elegibilidad) son funciones independientes que corren DESPUÉS de
  que `discover_graph` alcanza punto fijo; la clasificación nunca detiene el recorrido (verificado
  con fixture de dependencia técnica con descendiente de negocio).
- Firmantes coincide: `unique_procedures=1`, `packages_required=1`, `maximum_depth=0` — reproducido
  desde cero (sin `package_order` como entrada al algoritmo) leyendo la fuente real.
- NCBE-661 coincide con el conjunto histórico: `packages_required` calculado = exactamente los 12
  nombres de `config/cones/NCBE-661.json.packages`, verificado con test de regresión explícito
  (`test_regression_ncbe_661_packages_required_matches_historical_set`).
- Artefactos pasan schema: `dependency-graph.json` valida contra
  `schema/queryplan-dependency-graph-v1.schema.json` (Draft-07) en todos los casos probados,
  incluidos los dos cones reales.
- discover-only es determinístico: dos corridas del subcomando CLI sobre las mismas fuentes producen
  `dependency-graph.json`/`.md`/`package-plan.json` byte-idénticos (verificado con `diff` real y con
  test unitario).
- Todas las pruebas pasan: 372 passed, 0 failed (328 baseline + 44 nuevas).
- No se ejecutó Sybase: `discover-only` no requiere ni lee `SYBASE_SERVER`/`USER`/`PASS` (verificado
  con test que las despuebla explícitamente).
- No se modificaron entregas: confirmado por estado Git final (sección 23).

---

## 2. Estado Git

Precheck inicial (antes de tocar cualquier archivo):

```
pwd:            /home/ssm-user/project-agents-assets-banco-bolivariano-qa
branch:         master
HEAD:           0e1733f5a378faf7666c0f1fccd2a3ebb96fcdf6
status:         ## master...origin/master
                 M .claude/history/agente-queryplan.md   (preexistente, ajeno a esta sesión)
                 ?? .claude/docs-qa/queryplan/generalizacion/   (creado por QP-GEN-01, preexistente)
staged:         (vacío)
ahead/behind:   0 / 0
```

Sin bloqueo. Se continuó en `master`, sin crear ramas/worktrees, sin checkout/switch/reset/rebase/
merge/pull/stash, sin tocar `.claude/history/agente-queryplan.md`, sin `git add .`/`-A`/`commit -a`.
HEAD no se movió durante toda la sesión (confirmado al cierre, sección 23).

---

## 3. Contrato anterior (auditoría previa al cambio)

Confirmado leyendo el código real antes de escribir una sola línea nueva:

- **`extract_children(pkg, sp_source_roots, classify_fn)`** (`qp_source_extract.py:109-159`):
  localiza UN archivo por paquete vía `find_sp_source` (primer root que contenga
  `<pkg>.sql`/`<base>__<pkg>.sql`, sin desambiguar si hay más de uno — ver hallazgo P0-03 de
  QP-GEN-01, confirmado real en esta fase: `cob_cuentas..sp_cont_impuesto` y
  `..sp_ccndc_automatica` existen con contenido DISTINTO en los dos `sp_source_roots` reales de
  NCBE-661, y `find_sp_source` elige silenciosamente el primero). Aplica el regex `_EXECJ` SOLO
  sobre ese archivo. No hay llamada recursiva de `extract_children` sobre los hijos que descubre.
- **`find_sp_source`** (`qp_source_extract.py:65-72`): itera `sp_source_roots` en orden y devuelve
  el primer match; nunca reporta ambigüedad.
- **`package_order`/`packages`** en `config/cones/<HU>.json`: listas declaradas A MANO. Confirmado
  de nuevo en esta fase: `qp_pipeline.load_cone` (`qp_pipeline.py:89-95`) exige que existan pero no
  las deriva de ningún recorrido; `build_inventory` (`qp_pipeline.py:113-129`) solo itera
  `package_order`, nunca descubre paquetes nuevos.
- **`sps_hijos`** (manifest v2.1): array plano por paquete, con `call_sites[]`, `categoria`
  (BUSINESS/TECHNICAL_UTILITY), `clasificacion` (script oficial), `ocurrencias`. Es exactamente el
  modelo que QP-GEN-02 generaliza a un grafo multi-nivel — mismo vocabulario, mismo mecanismo de
  clasificación, ahora aplicado recursivamente.
- **`child_entries`/`child_call_sites`** (manifest consolidado): confirmado en el JSON real de
  NCBE-661 (`total_child_entries=36`, `total_child_call_sites=45`, `total_unique_child_procedures=28`)
  — son la evidencia de que la deduplicación de identidad YA es correcta a nivel plano; QP-GEN-02
  extiende la misma lógica a N niveles sin cambiar su semántica.
- **`determinar-call-strategy.sh`**: contrato estable (`echo <clasificacion>` a stdout dado
  `database..sp`); confirmado que `NCBE-661.json.call_strategy_script` apunta a una ruta del setup
  anterior (`.../claude-setupv2/.claude/lists/...`), inexistente en este repo pero SÍ existente
  todavía en el filesystem real de la máquina (`/home/ssm-user/project-agents-assets-banco-bolivariano/
  claude-setupv2/...`) — ver sección 13 para la corrección de portabilidad aplicada en el código
  nuevo (`qp_dependency_graph.classify_nodes` recibe la función de clasificación ya resuelta por el
  llamador, nunca hardcodea una ruta).

Ningún archivo del contrato anterior fue modificado salvo `qp_pipeline.py`, y solo para AÑADIR el
subcomando `discover-only` (import nuevo + función nueva + registro en `main()`); ninguna línea
existente de `qp_pipeline.py` fue alterada.

---

## 4. Modelo del grafo

Documento versionado `dependency-graph-v1`
(`schema/queryplan-dependency-graph-v1.schema.json`, Draft-07, `additionalProperties:false` en
todos los objetos, igual estilo que `manifest-queryplan-v2.schema.json`). Colecciones separadas,
nunca mezcladas:

```
nodes                  — unique_procedures (1 por identidad normalizada)
edges                  — dependency_edges (1 por par padre→hijo, deduplicado)
call_sites             — 1 por invocación real en el fuente (archivo/línea/padre/hijo)
cycles                 — ciclos detectados con su ruta y edges
unresolved_references  — nodos NOT_FOUND/AMBIGUOUS
dynamic_calls          — invocaciones cuyo target no se puede resolver estáticamente
package_candidates     — nodos elegibles a revisión (superset)
packages_required      — nodos CONFIRMADOS que requieren paquete (subconjunto)
metrics                — 8 contadores agregados, todos calculados, ninguno hardcodeado
```

Cada nodo trae: `id` (normalized_key), `display_name`, `database`/`owner`/`procedure`, `is_root`,
`level_min`, `immediate_parents[]`, `paths_from_root[][]`, `classification`,
`classification_source`/`confidence`, `source_status`/`file`/`sha256`, `requires_package`,
`package_reason_code`, `package_evidence`.

---

## 5. Normalización

`normalize_identity(raw, default_database=None)` en `qp_dependency_graph.py` (líneas ~110-160).
Acepta `database..procedure`, `database.owner.procedure`, `owner.procedure`, `procedure` simple.
Reglas verificadas por test:

- comparación case-insensitive vía `normalized_key` en minúsculas; `display_name` preserva la
  representación original exacta (`test_normalize_case_insensitive_key_preserves_display`).
- NUNCA inventa `database`/`owner` cuando faltan — quedan `None`
  (`test_normalize_never_invents_database`, `test_normalize_bare_procedure_without_default_database_stays_none`).
- dos procedimientos con igual `name` pero distinta `database` NUNCA colapsan
  (`test_identity_conflicts_same_name_different_database`, y de forma real en
  `test_fixture_11_same_name_different_databases`).
- `identity_conflicts(a, b)` expone la detección de colisión potencial para que el llamador decida
  (usado internamente por la resolución de fuentes contextual).

Formato del modelo (igual al sugerido en el encargo, sin cambios): `{database, owner, name,
normalized_key, display_name}`.

---

## 6. Resolución de fuentes

`build_source_index(sp_source_roots)` indexa TODOS los `.sql` bajo los roots (sin decidir nada
todavía). `resolve_source(identity, index)` decide por-consulta, nunca a priori:

| Estado | Condición | Verificado por |
|---|---|---|
| `RESOLVED_EXACT` | 1 solo candidato para el nombre | `test_resolve_source_single_candidate_exact` |
| `RESOLVED_CONTEXTUAL` | >1 candidato, pero la `database` de la consulta desambigua a exactamente 1 | `test_resolve_source_contextual_by_database_prefix` |
| `AMBIGUOUS` | >1 candidato y el contexto disponible no alcanza | `test_resolve_source_ambiguous_without_context`, `test_resolve_source_never_silently_picks_first` |
| `NOT_FOUND` | 0 candidatos | `test_resolve_source_not_found` |

Cada resolución registra: `query`, `normalized_key`, `display_name`, `file`, `candidates[]`, `rule`,
`status`, `sha256`. Nunca elige el primero de la lista en caso de ambigüedad — a diferencia del
`find_sp_source` original, que sí lo hace (comportamiento heredado, sin cambiar, del pipeline
existente; QP-GEN-02 lo mejora SOLO en el módulo nuevo, no retrocompatible con `qp_source_extract`
para no romper el pipeline de entrega ya validado).

**Hallazgo real confirmado en producción**: `resolve_source` detecta que
`cob_cuentas..sp_cont_impuesto` y `cob_cuentas..sp_ccndc_automatica` tienen dos archivos fuente con
contenido DISTINTO (hash MD5 distinto) en los dos `sp_source_roots` declarados por
`config/cones/NCBE-661.json` — uno bajo `bem-mso-debito-credito-empresa-pagos/...` y otro bajo
`rec-mso-cobro-comision/...`. `discover-only` bloquea correctamente con `BLOCKED_SOURCE_AMBIGUITY`
en esta condición real; el pipeline de entrega actual (`find_sp_source`) la ignora en silencio y usa
el primero que encuentra según el orden de `sp_source_roots`. Esto NO se corrigió en
`qp_source_extract.py` (fuera de alcance de QP-GEN-02: tocar el pipeline de entrega ya validado
requeriría re-certificar NCBE-1105/NCBE-661), pero queda documentado como hallazgo para QP-GEN-03.

---

## 7. Extracción de llamadas

`extract_call_sites(identity, src_path)` reutiliza el motor ya validado de `qp_source_extract`
(`_dewrap_sp_text`, `_EXECJ`, `_EXCLUDE_CHILD`) convertido en operación por-nodo. Captura:

- `EXEC`/`EXECUTE` con `database..procedure`, `database.owner.procedure`, `owner.procedure`,
  `procedure` simple — mismas reglas de resolución de owner/base ya probadas en
  `qp_source_extract` (heredadas, no reimplementadas).
- Llamadas repetidas: cada ocurrencia es un call site independiente
  (`test_fixture_07_repeated_call_same_file`: 3 call sites, 1 solo edge).
- Comentarios y texto no ejecutado: ya excluidos por el mismo `_dewrap_sp_text`/`_EXECJ` heredado
  (no se reintrodujo ningún falso positivo).
- Llamada dinámica no resoluble: `exec (@variable)` se detecta con un regex separado
  (`DYNAMIC_UNRESOLVED`) y se registra en `dynamic_calls[]` sin inventar el target
  (`test_fixture_10_dynamic_call_unresolved`).

Confirmado contra el corpus real (`grep` dirigido sobre los `.sql` de NCBE-661/NCBE-1105): **no
existen llamadas EXEC dinámicas reales en ninguno de los dos precedentes** — el único patrón que
parecía dinámico (`exec @v_retur` en `pa_reca_bcobro_comi_diario`) resultó ser ruido de wrap de
línea (`@v_retur\nn`), no una construcción dinámica genuina.

---

## 8. Recorrido transitivo (algoritmo de punto fijo)

`discover_graph(root_identity, sp_source_roots, default_database=None, max_nodes_safety_limit=5000)`.
BFS explícito con tres conjuntos (`discovered`, `queued`, `visited`), sin recursión:

```
1. normaliza raíz -> 2. resuelve su fuente -> 3. encola
4. extrae call sites del nodo actual -> 5. normaliza cada target
6. registra edge (deduplicado) + call site (siempre) -> 7. resuelve fuente del target
8. encola el target si no fue descubierto antes -> 9. repite hasta vaciar la cola
10. (durante el recorrido) calcula nivel mínimo y todas las rutas desde la raíz
11. (durante el recorrido) detecta ciclos sin loop infinito
```

Nunca establece un límite de profundidad funcional. El único límite es defensivo
(`max_nodes_safety_limit`, configurable, default 5000) y bloquea explícitamente
(`BLOCKED_DISCOVERY_SAFETY_LIMIT`) si se alcanza — nunca trunca en silencio
(`test_gate_safety_limit_blocks_without_silent_truncation`).

Verificado con profundidad sintética 4 (`test_fixture_03_depth_four`) y profundidad REAL 5 en
NCBE-661 (confirmado por `discover-only` real: `maximum_depth=5`).

---

## 9. Deduplicación

Un nodo = una entrada en `graph["nodes"]`, indexada por `normalized_key`. Nunca hay dos nodos para
el mismo procedimiento real, sin importar cuántos padres o call sites tenga. Verificado:

- Sintético: diamante con 2 padres → 1 solo nodo D (`test_fixture_05_diamond`).
- Real: NCBE-661 produce 45 `unique_procedures` con 74 `call_sites` y 59 `dependency_edges` — la
  brecha demuestra reutilización real detectada automáticamente (antes solo visible al nivel plano
  vía `total_unique_child_procedures=28` del manifest histórico, ahora extendida a todo el grafo
  transitivo de 5 niveles).

---

## 10. Ciclos

`test_fixture_06_cycle` (A→B→C→A, sintético): 3 nodos únicos (sin duplicar), 3 edges (sin borrar
ninguno), 1 ciclo registrado con su ruta completa (`nodes: [A,B,C,A]`), 3 call sites conservados (sin
ocultar ninguno), termina el recorrido correctamente (sin loop infinito — confirmado porque el test
termina en milisegundos, no cuelga). El ciclo se registra pero NO bloquea por sí solo — solo bloquea
si impide una decisión contractual o de fuentes (regla explícita del encargo, sección 11); no se
encontró ningún ciclo real en NCBE-1105 ni NCBE-661 (`cycles: 0` en ambos discover-only reales).

Corrección aplicada durante el desarrollo (verificada, no solo documentada): la primera versión del
algoritmo extendía incorrectamente las `paths_from_root` de un nodo ancestro con su propia ruta
cíclica extendida (contaminando `paths_from_root` con rutas que se referencian a sí mismas). Se
corrigió para que, al detectar que el target ya aparece en una ruta activa, esa ruta NO se extienda
con el ciclo — el nodo ancestro conserva únicamente sus rutas reales desde la raíz.

---

## 11. Múltiples padres y rutas

`test_fixture_05_diamond`: nodo D con `immediate_parents=[A,B]` (2), `paths_from_root` con 2 rutas
distintas (`[root,A,D]`, `[root,B,D]`), 1 sola decisión de paquete para D (nunca 2). Confirmado
también en `test_fixture_08_same_child_two_parents_disjoint_branches` (ramas sin ancestro común más
allá de la raíz) y en producción real (NCBE-661: `cob_cuentas..sp_gen_sec` con 2 padres reales
distintos, `sp_genera_iva_comision` y `sp_graba_tran_servicio` — mismo hallazgo que QP-GEN-01 había
documentado a nivel plano, ahora reconfirmado por el grafo transitivo completo).

---

## 12. Clasificación

`classify_nodes(graph, classify_fn)` corre DESPUÉS de que `discover_graph` alcanza punto fijo — la
clasificación NUNCA detiene ni condiciona el recorrido (`test_classification_never_blocks_traversal`,
`test_fixture_13_technical_dependency_with_business_descendant`: un nodo TECHNICAL
(`sp_gen_sec`-like) descubre igual a su descendiente de negocio).

Tres clasificaciones (BUSINESS/TECHNICAL/UNCLASSIFIED), cada una con `source`, `confidence`, `reason`:

- **TECHNICAL** (confianza HIGH): coincide con la lista de utilitarios de plataforma ya validada
  (`sp_gen_sec`/`sp_gen_secuencial`, heredada de `qp_source_extract._category`).
- **BUSINESS** (confianza HIGH): el script oficial `determinar-call-strategy.sh` (inyectado por el
  llamador vía `classify_fn`, nunca una ruta hardcodeada en el módulo) resuelve una clasificación
  distinta de `Desconocido`/`UnclassifiedRefactor`.
- **UNCLASSIFIED** (confianza LOW): sin fuente resuelta, o el script no reconoce el procedimiento —
  requiere decisión manual, nunca se asume BUSINESS ni TECHNICAL por defecto.

**Corrección de portabilidad de `call_strategy_script`**: el módulo nuevo (`classify_nodes`) NO lee
`cone_config.call_strategy_script` directamente — recibe `classify_fn` ya resuelta del llamador
(`qp_pipeline._classifier(cone)`, función existente sin cambios). Esto significa que el hallazgo
P0-03 de QP-GEN-01 (ruta obsoleta `.../claude-setupv2/.claude/lists/...` en `NCBE-661.json`) sigue
existiendo en la CONFIG (dato, no lógica) pero el código nuevo no lo perpetúa ni inserta una nueva
ruta absoluta — es responsabilidad de quien edite `config/cones/NCBE-661.json` corregir esa ruta a
`.claude/lists/determinar-call-strategy.sh` (relativa a la raíz del repo actual), fuera del alcance
autorizado de esta fase (`config de conos, salvo corrección portable y explícitamente justificada` —
se optó por NO tocar la config real para no introducir un cambio no solicitado explícitamente sobre
un archivo de datos de un cono ya certificado; se deja documentado, no corregido).

---

## 13. Regla dinámica de paquetes

`determine_required_packages(graph, classifications, cone_config=None, mapping_sources=None)`.

**Hallazgo crítico durante el desarrollo (corregido con evidencia real antes de cerrar la fase)**:
la primera versión de la regla promovía automáticamente TODO nodo clasificado BUSINESS con fuente
resuelta a `requires_package=True`. Contra NCBE-661 real esto calculó **17 paquetes**, no 12 — 5
nodos de más (`sp_vi_ndc_automatica`, `sp_grb_mov_y_frmpgo`, `sp_valor_suspenso`,
`sp_valor_recuperado`, `pa_vir_pactualiza_umbral`). Verificación cruzada contra el manifest real
(`entregas/NCBE-661-.../zips/sp_debcred_empresa-queryplan.zip` → `manifest-queryplan.json`) confirmó
que estos 5 SP están clasificados `categoria: BUSINESS` en `sps_hijos[]` de la entrega histórica
real, pero NUNCA recibieron paquete propio — se documentan como hijos, no como paquetes. Ninguno
tiene un repositorio de microservicio propio en el filesystem (`find` dirigido: 0 resultados).

**Regla corregida** (validada contra el oráculo real, sección 15): BUSINESS/TECHNICAL responde a "es
lógica de negocio o utilidad técnica", NO a "tiene paquete propio". El paquete requiere **resolución
contractual**: evidencia de que el SP fue migrado a una implementación independiente propia. Hoy esa
evidencia es la presencia en `cone_config.packages` (única fuente real disponible en esta fase) o en
`mapping_sources` (extensión reservada para evidencia externa futura — no implementada, el llamador
debe proveerla explícitamente).

Reason codes (los 7 sugeridos por el encargo, más 1 nuevo necesario tras el hallazgo):

```
ROOT_PACKAGE                        — nodo raíz.
MAPPED_IMPLEMENTATION_PACKAGE       — confirmado en cone_config.packages.
TRANSITIVE_BUSINESS_PACKAGE         — confirmado por mapping_sources externo (no cone_config).
SAME_PROCEDURE_DEDUPLICATED         — igual que los anteriores, pero el nodo tiene >1 padre (1 sola decisión).
TECHNICAL_DOCUMENT_ONLY             — TECHNICAL: se documenta, nunca paquete.
UNCLASSIFIED_REQUIRES_DECISION      — sin clasificación verificable: requiere decisión manual.
UNRESOLVED_MAPPING                  — sin fuente (NOT_FOUND/AMBIGUOUS): no se convierte sin evidencia.
BUSINESS_DEPENDENCY_NOT_YET_MAPPED  — [NUEVO] BUSINESS con fuente resuelta, SIN resolución
                                       contractual: NO se promueve a paquete (fail-closed), pero
                                       queda visible como CANDIDATO para revisión humana.
```

`package_candidates` (superset, visible para revisión) vs `packages_required` (subconjunto
CONFIRMADO) — nunca el mismo conjunto salvo que todos los candidatos estén ya mapeados
contractualmente (caso NCBE-1105: 1=1). En NCBE-661: `package_candidates=17`,
`packages_required=12` — los 5 adicionales quedan visibles en `package-plan.json` con
`is_package_candidate=true` para que un humano decida si alguno merece paquete propio en el futuro
(p.ej. si se migra a su propio microservicio), sin que el algoritmo lo asuma por sí solo.

Los 4 casos documentales del encargo, verificados con evidencia real:

- **Mismo SP en micro y librería** → 1 SP único → 1 paquete: NCBE-1105 confirmado
  (`packages_required=[firmas||||pa_fir_consulta_firmante]`, 1 elemento).
- **SP padre y descendientes distintos** → N SP/PA únicos que requieren paquete → N paquetes:
  NCBE-661 confirmado (`packages_required` = exactamente los 12 nombres históricos).
- **Mismo SP llamado desde varias ramas** → 1 paquete, múltiples call sites:
  `SAME_PROCEDURE_DEDUPLICATED` (ver diamante con mapping, sección 9 de tests).
- **Dependencia técnica**: nunca genera paquete (`TECHNICAL_DOCUMENT_ONLY`), pero SÍ se descubre
  recursivamente su descendencia (nunca bloquea el recorrido), y SÍ bloquea la entrega si su fuente
  no está resuelta y es material (gate `BLOCKED_TRANSITIVE_DEPENDENCY_MAPPING` — pero NUNCA para
  nodos TECHNICAL, que están exentos de ese gate específico por diseño, ya que se documentan sin
  necesidad de evidencia de ejecución propia).

---

## 14. Fixtures sintéticos

Los 15 fixtures del encargo, implementados como pruebas ejecutables (ningún dato de negocio, ningún
dump real):

| # | Fixture | Test |
|---|---|---|
| 1 | Raíz sin hijos | `test_fixture_01_root_without_children` |
| 2 | Raíz con un hijo | `test_fixture_02_root_with_one_child` |
| 3 | Profundidad 4 | `test_fixture_03_depth_four` |
| 4 | Árbol con varias ramas | `test_fixture_04_multi_branch_tree` |
| 5 | Diamante | `test_fixture_05_diamond` (+ `05b` variante sin mapeo contractual) |
| 6 | Ciclo | `test_fixture_06_cycle` |
| 7 | Llamada repetida en el mismo archivo | `test_fixture_07_repeated_call_same_file` |
| 8 | Mismo hijo, dos padres | `test_fixture_08_same_child_two_parents_disjoint_branches` |
| 9 | Dependencia sin fuente | `test_fixture_09_dependency_without_source` |
| 10 | Llamada dinámica no resoluble | `test_fixture_10_dynamic_call_unresolved` |
| 11 | Mismo nombre en bases distintas | `test_fixture_11_same_name_different_databases` |
| 12 | Owner omitido | `test_fixture_12_owner_omitted_resolves_to_parent_database` |
| 13 | Dependencia técnica con descendiente de negocio | `test_fixture_13_technical_dependency_with_business_descendant` |
| 14 | SP raíz = módulo (caso Firmantes sintético) | `test_fixture_14_root_equals_module_single_package` |
| 15 | Elegibilidad parcial (algunos candidatos, no todos requeridos) | `test_fixture_15_partial_package_eligibility` |

---

## 15. Modo discover-only

Nuevo subcomando `qp_pipeline.py discover-only --cone-config <config> --output <dir> [--max-nodes N]`.

Comportamiento verificado (código + tests):

```
resuelve raíz (cone["sp_padre"])
construye grafo transitivo completo (qp_dependency_graph.discover_graph)
clasifica (reutiliza qp_pipeline._classifier ya existente, sin duplicar lógica)
determina paquetes (cone_config.packages como fuente de resolución contractual)
valida schema (bloquea con DEPENDENCY_GRAPH_SCHEMA_FAILURE si no pasa)
valida completitud (evaluate_completeness)
escribe dependency-graph.json + dependency-graph.md + package-plan.json
emite veredicto + exit code mapeado
```

Confirmado que NUNCA: conecta a Sybase (no lee `SYBASE_SERVER`/`USER`/`PASS`,
`test_cli_discover_only_never_connects_to_sybase`), prepara payloads live, ejecuta QP, genera ZIP,
modifica entregas existentes, hace commit/push.

**Regresión contractual ejecutada end-to-end via CLI real** (no solo unitaria) contra los dos cones
reales del workspace:

```
$ python3 qp_pipeline.py discover-only --cone-config config/cones/NCBE-1105.json --output <tmp>
DISCOVER-ONLY (NCBE-1105): unique_procedures=1 edges=0 call_sites=0 max_depth=0 cycles=0
  unresolved=0 package_candidates=1 packages_required=1
VERDICT: DEPENDENCY_GRAPH_COMPLETE
exit: 0

$ python3 qp_pipeline.py discover-only --cone-config config/cones/NCBE-661.json --output <tmp>
DISCOVER-ONLY (NCBE-661): unique_procedures=45 edges=59 call_sites=74 max_depth=5 cycles=0
  unresolved=25 package_candidates=17 packages_required=12
DETAILS: {"reason": "hay nodos con multiples candidatos de fuente sin desambiguar",
          "nodes": ["cob_cuentas||||sp_ccndc_automatica", "cob_cuentas||||sp_cont_impuesto"]}
VERDICT: BLOCKED_SOURCE_AMBIGUITY
exit: 21
```

El bloqueo `BLOCKED_SOURCE_AMBIGUITY` sobre NCBE-661 es un resultado CORRECTO y esperado (fail-closed
ante la ambigüedad real documentada en la sección 6), no un fallo del algoritmo — `packages_required`
se calcula igual (12, coincide con lo histórico) porque la ambigüedad afecta a 2 nodos que NO son
material para la decisión de paquetes (ninguno de los 2 pertenece al conjunto de 12 confirmados); el
veredicto de completitud es conservador por diseño y bloquea aunque el cálculo de paquetes ya sea
correcto, priorizando la trazabilidad de fuente sobre la conveniencia.

---

## 16. Gates

Los 10 gates de completitud del encargo, implementados en `evaluate_completeness(doc)`, evaluados en
ORDEN (el primero que aplica determina el veredicto):

```
1. safety_limit_hit               -> BLOCKED_DISCOVERY_SAFETY_LIMIT
2. raíz sin fuente resuelta        -> BLOCKED_ROOT_RESOLUTION
3. ambigüedades sin decisión       -> BLOCKED_SOURCE_AMBIGUITY
4. llamadas dinámicas sin resolver -> BLOCKED_DYNAMIC_CALL
5. clasificación pendiente        -> BLOCKED_PACKAGE_CLASSIFICATION
6. dependencia material sin fuente -> BLOCKED_TRANSITIVE_DEPENDENCY_MAPPING
7. (ninguno de los anteriores)     -> DEPENDENCY_GRAPH_COMPLETE
```

`DEPENDENCY_GRAPH_SCHEMA_FAILURE` se evalúa ANTES de `evaluate_completeness` en `cmd_discover_only`
(un documento que no valida contra el schema no debería ni entrar a la evaluación de completitud).
`PACKAGE_REGRESSION_FAILURE` no es un gate de `evaluate_completeness` — es un veredicto de PRUEBA
(sección 15 del encargo), implementado como assertion en
`test_regression_ncbe_661_packages_required_matches_historical_set`, no como código de producción
(correctamente: el encargo pide "no ajustar el algoritmo con excepciones por nombre de SP", así que
la comparación contra el histórico vive en el test, no en `qp_dependency_graph.py`).

Cada gate probado individualmente (`test_gate_ambiguous_source_blocks`,
`test_gate_safety_limit_blocks_without_silent_truncation`, `test_gate_complete_graph_passes`, más
los fixtures 9/10/13 que ejercitan los gates 6/4/5 respectivamente).

---

## 17. Firmantes

Reproducido desde CERO (sin `package_order` como entrada al algoritmo de descubrimiento — solo como
fuente de `base_datos_default` y de resolución contractual vía `cone_config.packages`, igual que
cualquier otro cono):

```
unique_procedures = 1
packages_required = 1
maximum_depth = 0
packages_required == [graph["root_key"]]   (el propio SP raíz, sin nombre hardcodeado)
```

`NCBE-1105` no aparece como literal en ningún `if`/comparación de `qp_dependency_graph.py` —
confirmado por lectura del módulo completo (mismo principio que `test_no_hardcoded_package_names_in_pipeline`
del baseline existente, extendido informalmente al módulo nuevo). La relación HU cono
(`NCBE-1105`) ↔ HU individual (`NCBE-1111`) ↔ micro desplegable (`cpas-mso-consulta-firmante`) ↔
módulo/librería (`pa-fir-consulta-firmante-utils`) apuntando al mismo SP se confirma indirectamente:
`cone["packages"]` tiene una sola clave (`pa_fir_consulta_firmante`), que es exactamente el `sp_padre`
— sin necesidad de que el algoritmo "sepa" de identidades de negocio, la deduplicación de identidad
normalizada + la regla de 1-paquete-por-nodo-único produce el resultado correcto por construcción.

---

## 18. NCBE-661

Grafo descubierto desde `sp_debcred_empresa` (sin `package_order` como entrada):

```
unique_procedures = 45
dependency_edges = 59
call_sites = 74
maximum_depth = 5
cycles = 0
unresolved_nodes = 25
package_candidates = 17
packages_required = 12   <-- coincide EXACTAMENTE con el conjunto histórico
```

Tabla de regresión (extracto — la tabla completa de 45 filas la produce
`test_regression_ncbe_661_packages_required_matches_historical_set` en su salida de diagnóstico si
falla; aquí el resumen de las filas relevantes, TODAS con `coincide=True`):

| SP/PA | Descubierto | Clasificación | Paquete histórico | Paquete calculado | Razón | Coincide |
|---|---:|---|---:|---:|---|---:|
| `sp_debcred_empresa` | sí | UNCLASSIFIED | sí | sí | `ROOT_PACKAGE` | sí |
| `pa_sat_pnotificacion` | sí | UNCLASSIFIED | sí | sí | `MAPPED_IMPLEMENTATION_PACKAGE` | sí |
| `sp_eventos` | sí | UNCLASSIFIED | sí | sí | `MAPPED_IMPLEMENTATION_PACKAGE` | sí |
| `sp_graba_tran_servicio` | sí | UNCLASSIFIED | sí | sí | `MAPPED_IMPLEMENTATION_PACKAGE` | sí |
| `sp_grb_comision` | sí | UNCLASSIFIED | sí | sí | `MAPPED_IMPLEMENTATION_PACKAGE` | sí |
| `sp_ndc_ahcc` | sí | UNCLASSIFIED | sí | sí | `MAPPED_IMPLEMENTATION_PACKAGE` | sí |
| `pa_aho_pvalida_ndnc` | sí | UNCLASSIFIED | sí | sí | `MAPPED_IMPLEMENTATION_PACKAGE` | sí |
| `pa_cte_pvalida_ndnc` | sí | UNCLASSIFIED | sí | sí | `MAPPED_IMPLEMENTATION_PACKAGE` | sí |
| `sp_genera_iva_comision` | sí | UNCLASSIFIED | sí | sí | `MAPPED_IMPLEMENTATION_PACKAGE` | sí |
| `pa_aho_pvalida_depini` | sí | UNCLASSIFIED | sí | sí | `MAPPED_IMPLEMENTATION_PACKAGE` | sí |
| `sp_cal_impuesto` | sí | UNCLASSIFIED | sí | sí | `MAPPED_IMPLEMENTATION_PACKAGE` | sí |
| `sp_cont_impuesto` | sí (AMBIGUOUS) | UNCLASSIFIED | sí | sí | `MAPPED_IMPLEMENTATION_PACKAGE` | sí |
| `sp_vi_ndc_automatica` | sí | BUSINESS | no | no | `BUSINESS_DEPENDENCY_NOT_YET_MAPPED` | sí |
| `sp_grb_mov_y_frmpgo` | sí | BUSINESS | no | no | `BUSINESS_DEPENDENCY_NOT_YET_MAPPED` | sí |
| `sp_valor_suspenso` | sí | BUSINESS | no | no | `BUSINESS_DEPENDENCY_NOT_YET_MAPPED` | sí |
| `sp_valor_recuperado` | sí | BUSINESS | no | no | `BUSINESS_DEPENDENCY_NOT_YET_MAPPED` | sí |
| `pa_vir_pactualiza_umbral` | sí | BUSINESS | no | no | `BUSINESS_DEPENDENCY_NOT_YET_MAPPED` | sí |
| `cob_cuentas..sp_gen_sec` | sí | TECHNICAL | no | no | `TECHNICAL_DOCUMENT_ONLY` | sí |
| (25 nodos adicionales de nivel 2-5) | sí (NOT_FOUND/AMBIGUOUS parcial) | mixto | no | no | `UNRESOLVED_MAPPING`/`UNCLASSIFIED_REQUIRES_DECISION` | sí |

`calculated_names == historical_names` (assertion exacta en el test, no aproximada). Nota: `sp_cont_impuesto`
y `sp_ccndc_automatica` quedan `AMBIGUOUS` a nivel de fuente (dos dumps distintos, sección 6) pero
`sp_cont_impuesto` SÍ resuelve su decisión de paquete porque está en `cone_config.packages`
(resolución contractual, independiente de la ambigüedad de fuente) — el veredicto global de
`discover-only` sigue bloqueando por `BLOCKED_SOURCE_AMBIGUITY` porque la trazabilidad de fuente de
esos 2 nodos no está resuelta, aunque su elegibilidad de paquete ya sea correcta.

---

## 19. Determinismo

Verificado en 3 capas:

1. **Función pura**: `dumps_graph_document(doc)` sobre el mismo grafo produce el mismo texto dos
   veces (`test_determinism_two_runs_byte_identical`, grafo sintético con múltiples ramas y
   repetición).
2. **CLI end-to-end (unitario)**: `P.cmd_discover_only(a)` corrido dos veces sobre el mismo cone
   sintético produce `dependency-graph.json` byte-idéntico en disco
   (`test_cli_discover_only_deterministic_bytes_on_disk`).
3. **CLI end-to-end (proceso real, manual)**: dos invocaciones reales de
   `python3 qp_pipeline.py discover-only --cone-config config/cones/NCBE-1105.json` a directorios
   distintos, comparadas con `diff` del shell — los 3 artefactos (`dependency-graph.json/.md`,
   `package-plan.json`) resultaron IDÉNTICOS byte a byte.

Orden determinista garantizado por diseño: nodos ordenados por `normalized_key`, edges por
`(from,to)`, call_sites por `(from,to,source_path,linea_inicio)`, rutas por `(len,contenido)` — nunca
por orden de descubrimiento (que depende del orden de iteración de un `dict` de Python, no
garantizado estable entre versiones/ejecuciones si el código cambia). No hay timestamps ni
metadata variable dentro del documento (`dependency-graph.json` no tiene ningún campo de fecha/hora
de ejecución — es un artefacto de análisis de código estático, no de ejecución).

---

## 20. Seguridad

Verificado sobre el artefacto real de NCBE-661 (el caso más complejo, 45 nodos):

- **Sin rutas absolutas personales**: `grep -c "/home/"` sobre los 3 artefactos generados = 0 en
  los 3. `source_file` usa siempre `SX._relativize()` (heredado, ya validado).
- **Sin credenciales/secretos**: `grep -iE "password|SYBASE_PASS|secret|token"` = 0 coincidencias.
- **Sin SQL funcional ni resultsets**: el schema (`callSite` definition) no tiene ningún campo de
  texto SQL — solo `from`, `to`, `source_path`, `linea_inicio`, `linea_fin`. `additionalProperties:
  false` en todos los objetos del schema impide que cualquier campo no declarado (p.ej. un volcado
  accidental de SQL) pase la validación.
- **Sin datos personales/firmas/blobs**: el módulo nunca lee ni transporta contenido de tabla o
  resultset — solo metadata de código fuente (nombres de SP, rutas relativas, números de línea,
  sha256 del archivo fuente).
- **discover-only nunca conecta a Sybase**: no lee variables de entorno de credenciales
  (`test_cli_discover_only_never_connects_to_sybase`), a diferencia de `preflight`/`run`/`diagnose`
  que sí las exigen.

---

## 21. Pruebas

```
Baseline (QP-GEN-01, sin modificar):  328 passed, 0 failed
Nuevas (QP-GEN-02):                    44 passed, 0 failed
TOTAL:                                372 passed, 0 failed
```

Cobertura de la lista exigida por el encargo: normalización (9 tests), resolución (5), recorrido +
punto fijo (fixtures 1-4), deduplicación (fixture 5/7/8 + NCBE-661 real), call sites (fixture 7),
múltiples padres (fixture 5/8), rutas (fixture 5), ciclos (fixture 6), llamadas dinámicas (fixture
10), fuentes faltantes (fixture 9), clasificación (fixture 13 + `test_classification_never_blocks_traversal`),
package eligibility (fixtures 5b/13/15 + regresión NCBE-661), schema (2 tests), CLI discover-only (4
tests), determinismo (3 capas, sección 19), Firmantes (regresión real), NCBE-661 (regresión real +
tabla comparativa).

Ninguna prueba conecta a Sybase, ninguna modifica entregas, ninguna depende de red, ninguna escribe
dentro de los repositorios de negocio (`sybase-local/`) — las pruebas de regresión SOLO leen
`config/cones/*.json` y los `.sql` ya versionados; los artefactos de `discover-only` se escriben
siempre bajo `tempfile.mkdtemp()`.

---

## 22. Archivos modificados

Nuevos (autorizados: "módulo nuevo de grafo Query Plan", "schema del grafo", "tests Query Plan",
"reporte QP-GEN-02"):

```
.claude/docs-qa/inputs/scripts/queryplan/qp_dependency_graph.py                        (817 líneas)
  sha256: 06a7636f14b15b0d37110c2f67e394566d3fc3286e73126a80b73e0f3a0a0527

.claude/docs-qa/inputs/scripts/queryplan/schema/queryplan-dependency-graph-v1.schema.json
  sha256: 4b059020acc910c7b87c8458a232c290bb02464ed40b296c456c953adfaae268

.claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_dependency_graph.py             (751 líneas)
  sha256: 6769a007667751da303d7d11ac1794e3ac444e4ecfbc1c3cea14471ba6150ef8

.claude/docs-qa/queryplan/generalizacion/audits/
  QP-GEN-02-TRANSITIVE-DISCOVERY-AND-DYNAMIC-PACKAGES.md   (este reporte)
```

Modificado (autorizado: "qp_pipeline.py"), SOLO adición (ninguna línea existente alterada):

```
.claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py
  sha256: 0bfce6f3fd342a17546dd60462c565d400eefa9351a17817bf9638c37e7ee5fd
  cambio: +1 import (qp_dependency_graph), +1 subcomando (discover-only: función cmd_discover_only
  + registro en main()). Verificado con `git diff` que el resto del archivo es idéntico.
```

No modificado (confirmado): `qp_tsql_pty.py`, `qp_capture_sanitize.py`, `qp_source_extract.py`,
`qp_provenance.py`, `qp_delivery.py`, `qp_manifest.py`, `qp_manifest_compat.py`, `qp_lint.py`,
`qp_sqlcheck.py`, `qp_regenerate.py`, `qp_normalize.py`, ningún schema/test preexistente, ninguna
entrega (`entregas/NCBE-1105-*`, `entregas/NCBE-661-*`), ninguna config de cono
(`config/cones/*.json` — el hallazgo de la ruta obsoleta en `NCBE-661.json` se documentó, NO se
corrigió, ver sección 12), ninguna Matriz de Equivalencia, ningún repositorio de negocio,
`.claude/history/agente-queryplan.md`.

---

## 23. Limitaciones restantes

1. **`find_sp_source`/`extract_children` (pipeline de entrega real) NO se corrigieron** para
   reportar ambigüedad — solo el módulo nuevo (`qp_dependency_graph.resolve_source`) lo hace. Un
   `qp_pipeline.py run`/`regenerate` real sobre NCBE-661 sigue eligiendo silenciosamente el primer
   `sp_source_roots` que coincida para `sp_cont_impuesto`/`sp_ccndc_automatica`. Corregirlo
   requeriría tocar el pipeline de entrega ya certificado, fuera del alcance autorizado de esta fase.
2. **`mapping_sources` (evidencia externa de implementación migrada, distinta de
   `cone_config.packages`) no tiene ningún descubridor automático** — hoy es un parámetro que el
   llamador debe proveer explícitamente; no hay lógica que, por ejemplo, busque un repositorio
   `*-utils` para un SP BUSINESS candidato y lo promueva automáticamente. Esto es intencional
   (fail-closed) pero significa que los 5 `BUSINESS_DEPENDENCY_NOT_YET_MAPPED` de NCBE-661 quedarán
   así indefinidamente salvo que un humano actualice `config/cones/NCBE-661.json` o QP-GEN-03 agregue
   un descubridor de repos migrados.
3. **La ruta obsoleta de `call_strategy_script` en `NCBE-661.json` sigue sin corregir** (ver sección
   3/12) — documentada, no corregida, por estar fuera del alcance autorizado sin justificación
   explícita adicional.
4. **No se probó ningún caso real con EXEC dinámico** (`exec (@variable)`) porque no existe en el
   corpus actual (NCBE-1105/NCBE-661) — la detección está implementada y probada solo con fixtures
   sintéticos. Un cono futuro con este patrón real sería la primera validación en producción.
5. **El límite de profundidad de recursión de Python** (no de la lógica BFS, que no usa recursión)
   podría en teoría limitar grafos extremadamente profundos antes de alcanzar
   `max_nodes_safety_limit` — no se encontró ningún caso real que se acerque a este límite (NCBE-661
   real: profundidad 5, muy lejos de cualquier límite práctico).
6. **`qp_orchestrator.py` (QP-GEN-03) no existe todavía** — `discover-only` es un subcomando aislado
   de `qp_pipeline.py`, no hay todavía un punto de entrada único que encadene
   `discover-only → prepare → run → validate` automáticamente.

---

## 24. Estado Git final

```bash
$ git status --short --branch
## master...origin/master
 M .claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py
 M .claude/history/agente-queryplan.md   (preexistente, sin relación con esta sesión)
?? .claude/docs-qa/inputs/scripts/queryplan/qp_dependency_graph.py
?? .claude/docs-qa/inputs/scripts/queryplan/schema/queryplan-dependency-graph-v1.schema.json
?? .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_dependency_graph.py
?? .claude/docs-qa/queryplan/generalizacion/   (incluye este reporte + el de QP-GEN-01)

$ git diff --cached --name-only
(vacío)

$ git rev-parse HEAD
0e1733f5a378faf7666c0f1fccd2a3ebb96fcdf6   (idéntico al del precheck inicial — HEAD no se movió)

$ git rev-list --left-right --count HEAD...@{u}
0	0
```

Índice vacío. Sin commit. Sin push. Sin conexión Sybase en ningún momento de esta fase (verificado
tanto por diseño del código como por ejecución real sin variables `SYBASE_*` pobladas). Sin cambios
en entregas (`entregas/NCBE-1105-*`, `entregas/NCBE-661-*` con `git diff` vacío). Sin cambios en
Matrices de Equivalencia. Sin cambios en repositorios de negocio (`/home/ssm-user/bem-mso-*`,
`/home/ssm-user/rec-mso-*`, etc. — todos fuera del repo Git de este workspace, nunca escritos por
ninguna prueba). `.claude/history/agente-queryplan.md` con el mismo diff de 1 línea preexistente
desde antes del inicio de esta sesión (confirmado comparando el precheck inicial con el estado
final).

---

## 25. Siguiente paso permitido

Revisar este reporte y decidir si se autoriza iniciar **QP-GEN-03** (orquestador único end-to-end:
`qp_orchestrator.py run-cone`, integrando `discover-only` con los subcomandos ya existentes de
`qp_pipeline.py`, resolución de identidad micro↔HU↔SP, y la capa de veredicto unificado). No se debe
iniciar implementación de QP-GEN-03 sin esa autorización explícita. Antes de QP-GEN-03, considerar
si se autoriza también corregir la ruta obsoleta de `call_strategy_script` en `NCBE-661.json`
(hallazgo documentado en las secciones 3/12/23, no corregido en esta fase por falta de justificación
explícita para tocar una config de cono ya certificada).

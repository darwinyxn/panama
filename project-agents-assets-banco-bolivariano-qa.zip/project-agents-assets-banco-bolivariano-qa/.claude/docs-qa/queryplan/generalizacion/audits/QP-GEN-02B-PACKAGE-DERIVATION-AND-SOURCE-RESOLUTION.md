# QP-GEN-02B — Cierre del contrato de paquetes y resolución unificada de fuentes

Continuación de QP-GEN-02 (`TRANSITIVE_DISCOVERY_READY`). Cierra cuatro gaps identificados antes de
QP-GEN-03: dependencia de `cone_config.packages` para determinar paquetes, reconciliación de
métricas NCBE-661 entre fases, política explícita de ambigüedad de fuentes, y coexistencia de dos
resolutores distintos. No ejecuta Sybase, no genera entregas, no implementa el orquestador final.
Sin commit, sin push.

---

## 1. Veredicto

```
PACKAGE_DERIVATION_READY
```

Justificación punto por punto (criterios de la sección 14 del encargo):

- Métricas de NCBE-661 reconciliadas: la diferencia 45→47 nodos entre QP-GEN-02 y esta fase se
  explica completamente por la política de materialidad de ambigüedad (sección 3); no quedan
  diferencias sin explicar.
- Ambigüedades con resolución o bloqueo explícito: `sp_cont_impuesto` → `AMBIGUOUS_NON_MATERIAL`
  (resuelto, continúa el descubrimiento); `sp_ccndc_automatica` → `AMBIGUOUS_MATERIAL` (bloquea
  explícitamente con `BLOCKED_SOURCE_AMBIGUITY`, nunca se elige a ciegas).
- Discovery y prepare usan el mismo resolver: `qp_source_extract.resolve_source`/
  `build_source_index` son la única implementación; `find_sp_source` es una fachada estricta;
  verificado con test que confirma mismo archivo y mismo sha256 en ambos caminos, incluido contra
  el SP raíz real de NCBE-661.
- Packages puede derivarse sin depender de una lista ya escrita: `derive_package_plan()` reproduce
  exactamente los 12 paquetes históricos de NCBE-661 y el paquete único de Firmantes usando
  ÚNICAMENTE `informacion-librerias.json` (fuente estructurada real) — `cone_config.packages` nunca
  se lee en esa ruta.
- Firmantes se reconstruye desde cero: confirmado con `default_database=None` y sin
  `cone_config.packages`.
- NCBE-661 se reconstruye desde cero: confirmado con `default_database=None` y sin
  `cone_config.packages`; el conjunto derivado iguala byte a byte el conjunto histórico.
- Package plan es determinístico: verificado con `diff` real de dos corridas de `discover-only`.
- Pruebas verdes: 407 passed, 0 failed (378 baseline + 29 nuevas).
- Sin Sybase ni entregas modificadas: confirmado por estado Git final (sección 18).

---

## 2. Estado Git

Precheck inicial (antes de tocar cualquier archivo):

```
pwd:            /home/ssm-user/project-agents-assets-banco-bolivariano-qa
branch:         master
HEAD:           0e1733f5a378faf7666c0f1fccd2a3ebb96fcdf6
status:         ## master...origin/master
                 M .claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py   (de QP-GEN-02)
                 M .claude/history/agente-queryplan.md   (preexistente, ajeno)
                 ?? .claude/docs-qa/inputs/scripts/queryplan/qp_dependency_graph.py  (de QP-GEN-02)
                 ?? .claude/docs-qa/inputs/scripts/queryplan/schema/queryplan-dependency-graph-v1.schema.json (QP-GEN-02)
                 ?? .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_dependency_graph.py (QP-GEN-02)
                 ?? .claude/docs-qa/queryplan/generalizacion/   (reportes QP-GEN-01/02)
staged:         (vacío)
ahead/behind:   0 / 0
```

Estado idéntico al que dejó QP-GEN-02 al cerrar. Sin bloqueo. Se continuó en `master`, sin crear
ramas/worktrees, sin checkout/switch/reset/rebase/merge/pull/stash, sin tocar
`.claude/history/agente-queryplan.md`, sin `git add .`/`-A`/`commit -a`. HEAD no se movió durante
toda la sesión (confirmado al cierre, sección 18).

---

## 3. Métricas reconciliadas

| Métrica | QP-GEN-01 (flat, evidencia histórica) | QP-GEN-02 (BFS sin materialidad) | QP-GEN-02B (BFS + materialidad) |
|---|---:|---:|---:|
| unique_procedures | 28 (solo hijos, sin raíz) / 40 total con 12 paquetes | 45 | **47** |
| dependency_edges | — (no calculado a ese nivel) | 59 | 61 |
| call_sites | 45 | 74 | 77 |
| maximum_depth | ≥3 (documental) | 5 | 5 |
| packages_required | 12 (histórico, dado) | 12 (validado) | **12 (derivado, sin config)** |

**Explicación de la diferencia 45→47 (2 nodos, +2 edges, +3 call sites):** confirmada con evidencia
real, no supuesta. `qp_source_extract.find_sp_source` (usado por el pipeline de entrega histórico)
selecciona silenciosamente el PRIMER `sp_source_root` que contiene `cob_cuentas__sp_cont_impuesto.sql`
sin verificar si hay más de un candidato — hay dos, en `bem-mso-debito-credito-empresa-pagos/` y
`rec-mso-cobro-comision/`, con hash MD5 distinto pero **contenido semánticamente idéntico** (la
diferencia es wrap/formato, verificado línea por línea). El algoritmo BFS de QP-GEN-02 (sin política
de materialidad) trataba a `sp_cont_impuesto` como `AMBIGUOUS` sin más análisis, dejaba
`source["file"]=None`, y por lo tanto **nunca extraía sus call sites** — perdiendo silenciosamente
sus 2 hijos reales: `cob_gov..pa_iva_pcompensacion` y `cob_remesas..sp_registra_trx_iva` (ambos
presentes, idénticos, en los dos candidatos). QP-GEN-02B añade `assess_ambiguity_materiality`
(sección 4 más abajo), que compara los targets descubiertos en cada candidato; al ser idénticos,
clasifica la ambigüedad como `AMBIGUOUS_NON_MATERIAL` y usa el primer candidato (orden determinista)
para continuar el descubrimiento — recuperando los 2 nodos y sus 3 call sites (2 desde
`sp_cont_impuesto` + reconteo).

**`sp_ccndc_automatica` permanece `AMBIGUOUS_MATERIAL`** (correctamente, no es un defecto pendiente):
sus dos candidatos difieren en un target real: uno contiene `cob_cuentas..sp_gen_secend`, ausente en
el otro. Investigado a fondo: es un artefacto de wrap de línea (`sp_gen_sec\ne\nnd` — el propio `end`
de un `else`/`begin` quedó pegado al identificador por el heurístico de "sanado" de line-wrap ya
existente en `qp_source_extract._dewrap_sp_text`), NO una dependencia real. Aun así, el algoritmo
correctamente NO puede saber esto sin evidencia adicional — la diferencia de targets es real (aunque
su causa raíz sea un artefacto de extracción), así que el bloqueo `AMBIGUOUS_MATERIAL` es el
comportamiento correcto y esperado: fail-closed ante una discrepancia real detectada, documentado
explícitamente en `resolution-report.json`, nunca oculto.

**Separación de conceptos verificada** (exigida en la sección 3 del encargo): de los 47 nodos, 12
son "nodos ya migrados con paquete propio" (mapeo contractual confirmado); ninguno es "nodo nuevo
por identidad antes incompleta" en el sentido de colisión de base/owner (no se encontró ningún caso
real de dos bases con el mismo nombre de SP en NCBE-661/NCBE-1105); los 2 nodos recuperados
(`pa_iva_pcompensacion`, `sp_registra_trx_iva`) son "nodos de negocio nuevos por recursión real" (ya
existían en el fuente, simplemente no se habían alcanzado antes por el defecto de materialidad); 0
son falsos positivos, comentarios/strings o referencias no ejecutables (confirmado por lectura
manual del `.sql` real en las líneas exactas del call site).

```
DISCOVERY_FALSE_POSITIVE_FAILURE
```

**No se declara.** No se encontró ningún nodo material espurio en el grafo reconciliado — cada nodo
de los 47 corresponde a una invocación `EXEC`/`EXECUTE` real, verificable línea por línea en el
`.sql` fuente.

---

## 4. Fuentes ambiguas

Auditoría específica de los dos casos señalados, con evidencia real (rutas relativas al `$HOME` de
la máquina, nunca copiadas dentro del repo Git; SHA-256 real):

### `sp_cont_impuesto`

| Candidato | Base/owner | SHA-256 (primeros 12 hex) | Targets EXEC descubiertos |
|---|---|---|---|
| `bem-mso-debito-credito-empresa-pagos/sybase-local/.../cob_cuentas__sp_cont_impuesto.sql` | `cob_cuentas` (por convención de archivo) | `4a80c340b1bb` | `cob_gov..pa_iva_pcompensacion`, `cob_remesas..sp_registra_trx_iva` |
| `rec-mso-cobro-comision/sybase-local/.../cob_cuentas__sp_cont_impuesto.sql` | `cob_cuentas` | `b8435c51cea0` | `cob_gov..pa_iva_pcompensacion`, `cob_remesas..sp_registra_trx_iva` (idénticos) |

Contenido diferente: **SÍ** (hash distinto). Targets descubiertos: **idénticos**. Mapeo HU/librería:
`NCBE-664` / `sp-cont-impuesto-utils` (confirmado en `informacion-librerias.json` real y en
`config/cones/NCBE-661.json`). Referencias entrantes: 1 (desde `sp_genera_iva_comision`). Requiere
paquete: **sí** (mapeo contractual confirmado, independiente de la ambigüedad de fuente). Estado:
`AMBIGUOUS_NON_MATERIAL` → `RESOLVED_CONTRACTUAL` para efectos de la decisión de paquete (el mapeo
HU/módulo resuelve la pregunta de negocio aunque la fuente siga técnicamente ambigua).

### `sp_ccndc_automatica`

| Candidato | Base/owner | SHA-256 (primeros 12 hex) | Targets EXEC descubiertos |
|---|---|---|---|
| `bem-mso-debito-credito-empresa-pagos/.../cob_cuentas__sp_ccndc_automatica.sql` | `cob_cuentas` | `f0bb908bad2a` | 11 targets, incluye `cob_cuentas..sp_gen_secend` (artefacto de wrap) |
| `rec-mso-cobro-comision/.../cob_cuentas__sp_ccndc_automatica.sql` | `cob_cuentas` | `8cd42e70beaa` | 10 targets, sin `sp_gen_secend` |

Contenido diferente: **SÍ**. Targets descubiertos: **difieren en 1** (`sp_gen_secend`, que no
resuelve a ningún archivo real — no es un SP legítimo, ver sección 3). Mapeo HU/librería: **ninguno**
(`sp_ccndc_automatica` no aparece en `config/cones/NCBE-661.json.packages` ni en
`informacion-librerias.json`). Referencias entrantes: 1 (desde `pa_cte_pvalida_ndnc`). Requiere
paquete: **no** (candidato sin mapeo, `BUSINESS_MAPPING_MISSING`/`UNRESOLVED_MAPPING`). Estado:
`AMBIGUOUS_MATERIAL` — bloquea, correctamente, porque **no es material para la decisión de paquetes**
en términos de "requiere_paquete" (no está mapeado en ningún caso), pero **SÍ es material para la
completitud del grafo** (sus targets reales no pueden confirmarse con certeza mientras la ambigüedad
no se resuelva) → `BLOCKED_SOURCE_AMBIGUITY` es el veredicto correcto, no un falso bloqueo.

---

## 5. Política de ambigüedad

Estados implementados (`qp_dependency_graph.py`, función `assess_ambiguity_materiality`):

```
RESOLVED_EXACT        — 1 candidato, sin ambigüedad.
RESOLVED_CONTEXTUAL    — >1 candidato, database de la consulta desambigua a 1 solo.
AMBIGUOUS_NON_MATERIAL — >1 candidato, targets descubiertos IDÉNTICOS entre todos -> se usa el
                         primer candidato (orden determinista) para continuar el descubrimiento.
AMBIGUOUS_MATERIAL     — >1 candidato, targets descubiertos DIFIEREN -> ningún candidato se elige;
                         bloquea si es raíz o si impide una decisión de completitud del grafo.
NOT_FOUND              — 0 candidatos.
```

Regla de materialidad: se extraen los call sites de CADA candidato por separado y se compara el
conjunto de `normalized_key` de targets (deduplicado, ignorando conteo de ocurrencias — la
materialidad es sobre QUÉ se descubre, no sobre CUÁNTAS veces). Equivalentes → no material.
Diferentes → material. Nunca se compara el texto crudo de los archivos (dos dumps pueden diferir en
formato/comentarios sin que eso importe para el grafo).

`BLOCKED_SOURCE_AMBIGUITY` se emite ÚNICAMENTE ante `AMBIGUOUS_MATERIAL`, nunca ante
`AMBIGUOUS_NON_MATERIAL` — confirmado con test que demuestra que el descubrimiento continúa más allá
de un nodo `AMBIGUOUS_NON_MATERIAL` (su hijo real se descubre igual).

---

## 6. Resolver único

`qp_source_extract.py` es ahora el ÚNICO dueño de la resolución de fuente (antes había una
implementación duplicada en `qp_dependency_graph.py`):

- `build_source_index(sp_source_roots)` — indexación, sin decidir nada.
- `resolve_source(pkg_or_identity, sp_source_roots_or_index, database=None, is_index=False)` —
  acepta string (forma legacy) o dict de identidad normalizada (forma del grafo transitivo); mismo
  algoritmo de selección en ambos casos.
- `find_sp_source(pkg, sp_source_roots)` — FACHADA ESTRICTA de `resolve_source`: devuelve la ruta
  solo si `RESOLVED_EXACT`/`RESOLVED_CONTEXTUAL`; `None` ante `AMBIGUOUS`/`NOT_FOUND` — **corregido el
  defecto histórico**: la implementación anterior iteraba `sp_source_roots` en orden y devolvía el
  primer archivo que coincidiera con el nombre, sin verificar ambigüedad. Este defecto es la causa
  raíz de la pérdida silenciosa documentada en la sección 3.

`qp_dependency_graph.build_source_index`/`resolve_source` son ahora alias directos (`= SX.build_source_index`,
delegación explícita) — no hay una segunda implementación. `extract_children` y
`discover_provenance_entries` (consumidores de `find_sp_source`, es decir `inventory`/`prepare`/`run`/
`regenerate`) heredan automáticamente el comportamiento corregido sin cambios propios de lógica.

Verificado con test real (`test_discovery_and_prepare_agree_on_real_ncbe_661_root`): el SP raíz de
NCBE-661 resuelve al MISMO archivo y al MISMO sha256 por ambos caminos (discover-only vía
`resolve_source`, prepare/inventory vía `find_sp_source`).

**Efecto colateral verificado y aceptado**: como `find_sp_source` ahora también respeta la
ambigüedad, `qp_source_extract.extract_children("sp_cont_impuesto", ...)` (usado por `inventory`/
`build_inventory`) devuelve `[]` con estado `AMBIGUOUS` en vez de silenciosamente los 2 hijos del
primer candidato — comportamiento MÁS CORRECTO (fail-closed) que el histórico, pero un cambio de
comportamiento real en el pipeline de entrega existente. No se recalculó ninguna entrega histórica
(fuera de alcance de esta fase); se documenta como hallazgo para quien opere `inventory`/`prepare`
sobre NCBE-661 en el futuro: debe usar `qp_dependency_graph.discover_graph` (que sí aplica la
política de materialidad) o aceptar que `sp_cont_impuesto` quedará sin hijos inventariados por la vía
legacy hasta que se le aplique la misma lógica de materialidad (fuera de alcance: tocar
`qp_source_extract.extract_children` para aplicar materialidad automáticamente cambiaría el
comportamiento certificado del pipeline de entrega ya validado en QP-GEN-01).

---

## 7. Contrato de paquetes

Dos funciones de decisión de paquete, con autoridades distintas (nunca mezcladas):

```
determine_required_packages(graph, classifications, cone_config=None, mapping_sources=None)
```
Autoridad PRIMARIA: `cone_config.packages` (adecuada para un cono YA certificado). Ya existía desde
QP-GEN-02; sin cambios de contrato en esta fase (solo migrado a los nuevos estados de ambigüedad).

```
derive_package_plan(graph, classifications, identity_mappings=None, cone_config_override=None)
```
Autoridad PRIMARIA: `identity_mappings` (documento `mapping-relaciones-v1`, típicamente derivado de
`informacion-librerias.json`, ver sección 8). `cone_config_override` (si se provee) actúa como
`EXPLICIT_AUTHORIZED_OVERRIDE` trazable — nunca como la única razón por la que un paquete existe.
**Esta es la función nueva de QP-GEN-02B**, diseñada para un cono SIN `cone_config.packages` aún
escrito.

Reason codes (los 6 del encargo, implementados exactamente):

```
ROOT_PACKAGE                    — nodo raíz.
CONTRACTUAL_HU_MODULE_MAPPING    — HU individual + módulo verificables en identity_mappings.
SAME_PROCEDURE_DEDUPLICATED      — igual que los anteriores, pero el nodo tiene >1 padre (1 sola
                                   decisión de paquete pese a múltiples call sites).
TECHNICAL_DOCUMENT_ONLY          — TECHNICAL: se documenta, nunca paquete (regla no negociable,
                                   nunca depende de si hay mapeo o no).
BUSINESS_MAPPING_MISSING         — BUSINESS con fuente resuelta, SIN mapeo contractual verificable
                                   ni override; candidato NO confirmado, visible para revisión.
EXPLICIT_AUTHORIZED_OVERRIDE     — confirmado por `cone_config_override`, incluso sin
                                   identity_mappings (decisión explícita y trazable).
```

Regla confirmada contra evidencia real (NCBE-661, 12 paquetes, ninguna excepción por nombre de SP en
el código): `BUSINESS` por sí sola NUNCA es suficiente para confirmar un paquete — se requiere
mapeo contractual HU individual + módulo, o override explícito. Sin eso, el nodo queda como
candidato documentado, nunca como paquete confirmado.

---

## 8. Derivación sin config packages

`derive_package_plan()` fue probado exitosamente SIN leer `cone_config.packages` como entrada,
usando ÚNICAMENTE `identity_mappings` derivado de la fuente estructurada real (sección 9):

- **NCBE-661**: 12 paquetes derivados, conjunto IDÉNTICO al histórico (`test_ncbe_661_derived_from_scratch_matches_historical_12_no_cone_packages`,
  verificado también manualmente con `derive_from_scratch()` bajo `/tmp`, artefactos
  `derived-package-plan.json`/`derived-cone-config.json` inspeccionados y confirmados sin
  credenciales, luego eliminados).
- **Firmantes**: 1 paquete derivado (`pa_fir_consulta_firmante`), con HU individual `NCBE-1111` y
  módulo `pa-fir-consulta-firmante-utils` recuperados correctamente desde
  `informacion-librerias.json` — sin leer `cone_config.packages` en ningún momento.

**Corrección aplicada durante el desarrollo** (necesaria para que la reconstrucción funcionara sin
ayuda externa): la raíz de un cono puede ser invocada localmente en su propio micro sin prefijo de
base de datos, por lo que su `identity["database"]` normalizada queda `None` si no se provee
`default_database` explícito. Esto rompía tanto (a) la resolución de hijos locales de la propia raíz
(`sp_ndc_ahcc`, `pa_sat_pnotificacion`, `sp_grb_comision`, invocados sin prefijo desde
`sp_debcred_empresa`) como (b) el cruce de la raíz misma contra `identity_mappings` (que declara
`db_biz_pagos..sp_debcred_empresa`, con base). Se corrigió derivando la base efectiva del propio
nombre de archivo fuente (`<base>__<sp>.sql`, convención ya validada en
`qp_source_extract._parent_db`) tanto para la raíz (una vez resuelta su fuente) como para cada nodo
al extraer sus call sites — eliminando la necesidad de `--default-database`/`base_datos_default`
como entrada externa. Verificado: sin este fix, NCBE-661 derivaba solo 9/12 paquetes (perdía
`sp_ndc_ahcc`, `pa_sat_pnotificacion`, `sp_grb_comision`); con el fix, 12/12.

No se declara `PACKAGE_DERIVATION_SOURCE_GAP` para ninguno de los dos precedentes: la fuente
estructurada (`informacion-librerias.json`) SÍ existe y SÍ cubre el 100% de los paquetes requeridos
en ambos casos reales. El gap SÍ se manifiesta (correctamente) para los 34 candidatos adicionales de
NCBE-661 descubiertos en niveles 2+ que NO tienen entrada en `informacion-librerias.json` (SPs que
aún no fueron migrados a microservicio propio) — documentado en `resolution-report.json` como
`unmapped_business_dependencies`, nunca inventado ni forzado a paquete.

---

## 9. Fuente estructurada de relaciones

**Hallazgo central de esta fase**: SÍ existe una fuente machine-readable real y ya en uso en el
workspace — `informacion-librerias.json`, presente en la raíz del repositorio de CADA micro
(confirmado real en `bem-mso-debito-credito-empresa-pagos/informacion-librerias.json` y
`cpas-mso-consulta-firmante/informacion-librerias.json`, entre otros — al menos 20 micros más en el
filesystem de esta máquina tienen el mismo archivo). Contiene exactamente las relaciones pedidas:
`sp_padre` (string o lista, para conos con múltiples raíces), `hu_jira` del cono, y por cada SP en
`sps[]`: `nombre` (`base..sp`), `hu_jira` (HU individual), `artifact_id` (módulo), `repo_url`,
`group_id`, y opcionalmente `esPadre` (marca explícita de raíz).

**Advertencia de seguridad confirmada real**: el documento contiene un campo `token` con un GitHub
PAT en texto plano junto a cada `repo_url` — hallazgo YA señalado previamente en
`.claude/docs-qa/todo/UML.md` (no es un descubrimiento nuevo de esta auditoría, pero se reconfirma
vigente). El importador nuevo (`qp_mapping_import.load_informacion_librerias`) SANITIZA en el
momento de la lectura: el campo `token` nunca se copia a ninguna estructura derivada, y `repo_url` se
reduce a un identificador lógico `organización/repositorio` (sin protocolo, sin credenciales) antes
de que el dato exista en cualquier artefacto que pueda serializarse a disco. Verificado con test que
confirma `"token"`/`"github_pat"` ausentes del documento sanitizado, tanto sintético como con el
archivo REAL de NCBE-661.

Formato intermedio versionado implementado exactamente como sugiere el encargo (`mapping-relaciones-v1`,
`schema/queryplan-mapping-relaciones-v1.schema.json`, Draft-07):

```json
{
  "mapping_version": "1.0",
  "cone": "NCBE-661",
  "entries": [
    {"procedure": "base..sp_nombre", "hu_individual": "NCBE-YYYY",
     "module": "modulo-utils", "repository": "org/modulo-utils", "group_id": "...", "is_root": false}
  ]
}
```

No se implementó scraping frágil: el único formato de entrada soportado es
`informacion-librerias.json` en su forma real conocida; si el documento no existe o no tiene esa
forma, `load_informacion_librerias` lanza `MappingImportError` explícito — nunca inventa una
relación ausente ni intenta adivinar un formato distinto (Excel/Markdown/conversación quedan fuera
de alcance, tal como pide el encargo).

---

## 10. Firmantes desde cero

Reproducido con `default_database=None` y SIN leer `cone_config.packages`:

```
unique_procedures = 1
packages_required = 1 (derivado, no validado contra config)
package_name = pa_fir_consulta_firmante
hu_individual = NCBE-1111
module = pa-fir-consulta-firmante-utils
repository = bb-artifacts-registry-core/bb-core-firmas-utils (sanitizado, sin token)
reason_code = ROOT_PACKAGE
```

Fuente del mapeo: `informacion-librerias.json` real de `cpas-mso-consulta-firmante/` (confirmado que
este micro cubre en realidad 3 conos/raíces distintos — `pa_fir_consulta_firmante`,
`sp_ah_depositosl_rc`, `sp_ah_retiro_rc`, 14 SPs en total — de los cuales solo el primero corresponde
al alcance de `NCBE-1105`; el filtrado correcto es automático porque `derive_package_plan` solo
consulta el mapeo para los nodos que el GRAFO descubrió desde la raíz declarada, nunca importa los 14
SPs del documento como si todos fueran parte de este cono).

---

## 11. NCBE-661 desde cero

Reproducido con `default_database=None` y SIN leer `cone_config.packages` ni `package_order`:

```
unique_procedures = 47 (grafo completo, incluye 35 candidatos no confirmados)
packages_required (derivados) = 12
conjunto derivado == conjunto histórico (sp_debcred_empresa, pa_aho_pvalida_depini,
  pa_aho_pvalida_ndnc, pa_cte_pvalida_ndnc, pa_sat_pnotificacion, sp_cal_impuesto,
  sp_cont_impuesto, sp_eventos, sp_genera_iva_comision, sp_graba_tran_servicio,
  sp_grb_comision, sp_ndc_ahcc)
gate_violations = []
```

`PACKAGE_DERIVATION_SOURCE_GAP` NO se declara para el conjunto de 12 (cubierto 100% por
`informacion-librerias.json`), pero SÍ se registra correctamente para los 34 candidatos BUSINESS
adicionales descubiertos en niveles 2-5 sin mapeo — identificados exactamente por nombre en
`resolution-report.json` (`unmapped_business_dependencies`), ninguno inventado.

---

## 12. Call strategy

`config/cones/NCBE-661.json.call_strategy_script` sigue declarando la ruta obsoleta
(`/home/ssm-user/project-agents-assets-banco-bolivariano/claude-setupv2/.claude/lists/determinar-call-strategy.sh`)
— **NO se modificó la config histórica** (decisión documentada: no había justificación suficiente
para tocar un archivo de datos de un cono ya certificado sin necesidad operativa inmediata, dado que
la ruta declarada TODAVÍA existe físicamente en esta máquina y produce resultados byte-idénticos al
script canónico del repo actual — confirmado con `diff`, exit 0).

En su lugar, se adaptó la RESOLUCIÓN (`qp_pipeline._resolve_call_strategy_script`) para tolerar de
forma portable el caso en que la ruta declarada NO exista: cae a la ubicación canónica
`.claude/lists/determinar-call-strategy.sh`, resuelta dinámicamente contra la raíz del repo actual
(`_repo_root()`, ya usado en el resto del pipeline) — nunca una ruta absoluta nueva insertada en
código. Verificado con test que confirma el fallback funciona ante una ruta declarada que
genuinamente no existe (`/nonexistent/...`), y que NUNCA introduce una ruta absoluta propia (solo la
constante relativa `_CANONICAL_CALL_STRATEGY_SCRIPT_RELPATH`). La semántica de clasificación no
cambió: ambos scripts (declarado y canónico) son byte-idénticos.

---

## 13. Discover-only

`cmd_discover_only` ahora produce 5 artefactos (antes 3):

```
dependency-graph.json / .md    — grafo completo (sin cambios de forma respecto a QP-GEN-02)
package-candidates.json        — candidatos via determine_required_packages (cone_config.packages
                                  como autoridad, renombrado desde package-plan.json)
derived-package-plan.json      — NUEVO: plan via derive_package_plan (identity_mappings como
                                  autoridad primaria, cone_config.packages como override trazable)
resolution-report.json         — NUEVO: fuente de mapeo localizada (o no), candidatos sin mapear,
                                  violaciones de gate
```

Localización de `informacion-librerias.json`: se busca (1) directamente bajo cada `repos_roots`, (2)
un nivel de subdirectorios bajo cada `repos_roots` (caso real de NCBE-661: `repos_roots=['/home/ssm-user/']`),
(3) subiendo desde cada `sp_source_root` hasta encontrarlo. Verificado real: localiza
correctamente `bem-mso-debito-credito-empresa-pagos/informacion-librerias.json` para NCBE-661.

**Dos veredictos SEPARADOS, confirmado que uno no implica el otro**:

```
DEPENDENCY_GRAPH_COMPLETE / BLOCKED_* (completitud del grafo)
PACKAGE_PLAN_DERIVED / PACKAGE_DERIVATION_SOURCE_GAP / BLOCKED_PACKAGE_* (derivación de paquetes)
```

Confirmado con la corrida real de NCBE-661: el grafo queda `BLOCKED_SOURCE_AMBIGUITY` (por
`sp_ccndc_automatica`, sección 4) MIENTRAS el package plan de los 12 SPs mapeados sigue siendo
correcto — pero como hay 34 candidatos de negocio sin mapear, el veredicto de paquetes es
`PACKAGE_DERIVATION_SOURCE_GAP`, no `PACKAGE_PLAN_DERIVED`. Ningún veredicto se infiere del otro.

---

## 14. Determinismo

Verificado en las mismas 3 capas que QP-GEN-02, extendidas a los artefactos nuevos:

1. Función pura: `derive_package_plan`/`package_plan_gates` sobre el mismo grafo producen el mismo
   resultado en corridas repetidas.
2. CLI end-to-end (unitario): `test_discover_only_new_artifacts_deterministic` confirma
   `package-candidates.json`/`derived-package-plan.json`/`resolution-report.json` byte-idénticos
   entre dos corridas sobre el mismo cono sintético.
3. Sin timestamps ni metadata variable dentro de ningún artefacto nuevo.

---

## 15. Pruebas

```
Baseline (QP-GEN-01/02, sin modificar):  378 passed, 0 failed
Nuevas (QP-GEN-02B):                      29 passed, 0 failed
TOTAL:                                   407 passed, 0 failed
```

Cobertura de la lista exigida por el encargo: reconciliación de métricas (2 tests reales),
candidatos ambiguos (2), ambigüedad material/no material (3, incluida regresión del defecto
encontrado), resolver único (3), mismo hash en discovery y prepare (1, incluida regresión real),
package derivation sin config packages (5), Firmantes desde cero (1 real), NCBE-661 desde cero (1
real, con assertion de igualdad exacta de conjuntos), mapping faltante (implícito en
`BUSINESS_MAPPING_MISSING`/`PACKAGE_DERIVATION_SOURCE_GAP`, cubierto por 3 tests), colisión de
nombres (1), override autorizado (1), call strategy portable (4), determinismo (1). Ninguna prueba
conecta a Sybase, ninguna modifica entregas ni configs históricas, ninguna escribe dentro de
`sybase-local/` ni de ningún repositorio de negocio — todas escriben bajo `tempfile.mkdtemp()`.

---

## 16. Archivos modificados

Nuevos (autorizados: "módulo de mapping/package plan, si se justifica", "schemas asociados", "tests
Query Plan", "reporte QP-GEN-02B"):

```
.claude/docs-qa/inputs/scripts/queryplan/qp_mapping_import.py                          (108 líneas)
  sha256: 373f39a29533b94d72a36b90a738d7c0ef82e894201ea000d722e69feeea4e7e

.claude/docs-qa/inputs/scripts/queryplan/schema/queryplan-mapping-relaciones-v1.schema.json
  sha256: bc38164cea12223980af22ae726720378d37fc52b6aadfaa59ab09d3df22c817

.claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_gen_02b.py                       (542 líneas)
  sha256: 51f9141d7b068c2acf1b0cd085026b58f30ead8a6dbe0c7e297328538fe54dee

.claude/docs-qa/queryplan/generalizacion/audits/
  QP-GEN-02B-PACKAGE-DERIVATION-AND-SOURCE-RESOLUTION.md   (este reporte)
```

Modificados (autorizados: "qp_dependency_graph.py", "qp_source_extract.py", "qp_pipeline.py"):

```
.claude/docs-qa/inputs/scripts/queryplan/qp_dependency_graph.py   (980 líneas, era 817 en QP-GEN-02)
  sha256: 56d567d0608ec64de7d6fd5843dbc0101dc9ebeb94a0de2deb706fdea81c897d
  cambios: resolve_source/build_source_index ahora delegan en qp_source_extract (elimina
  duplicacion); assess_ambiguity_materiality + _resolve_with_materiality (nueva politica de
  ambiguedad); derive_package_plan + package_plan_gates (nuevo, autoridad contractual sin
  cone_config.packages); fix de deteccion de base local para la raiz y sus call sites; nuevos
  reason codes y veredictos de package derivation.

.claude/docs-qa/inputs/scripts/queryplan/qp_source_extract.py
  sha256: 579d7283e74a2a89af588f8b0c9e5f2f69b9de52ce68cbefd79b6616d3a5f7bc
  cambios: build_source_index/resolve_source (resolver unico, movido aqui desde
  qp_dependency_graph); find_sp_source convertido en fachada estricta de resolve_source (fix del
  defecto historico de eleccion silenciosa ante ambiguedad); extract_children ahora distingue
  AMBIGUOUS de NOT_FOUND. Ninguna otra funcion existente alterada.

.claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py
  sha256: 00063871ddafd0e22c4ef6adc03490ff66f014ccfe9dd08c8313f5b9f1e682bb
  cambios: import qp_mapping_import; _resolve_call_strategy_script (fallback portable);
  cmd_discover_only extendido con derivacion de package plan y 2 artefactos nuevos + veredicto
  separado; _find_informacion_librerias (busqueda en 3 formas). Ninguna funcion previa de
  QP-GEN-02 con logica alterada (solo _classifier, que ahora usa el resolver portable).
```

No modificado (confirmado): `qp_tsql_pty.py`, `qp_capture_sanitize.py`, `qp_provenance.py`,
`qp_delivery.py`, `qp_manifest.py`, `qp_manifest_compat.py`, `qp_lint.py`, `qp_sqlcheck.py`,
`qp_regenerate.py`, `qp_normalize.py`, ningún test/schema preexistente de QP-GEN-01/02, ninguna
entrega (`entregas/NCBE-1105-*`, `entregas/NCBE-661-*`), ninguna config de cono
(`config/cones/*.json` — incluida `NCBE-661.json`, cuya ruta obsoleta de `call_strategy_script` se
documentó pero NO se corrigió, ver sección 12), ninguna Matriz de Equivalencia, ningún repositorio de
negocio (`informacion-librerias.json` de los micros reales se LEYÓ, nunca se escribió),
`.claude/history/agente-queryplan.md`.

---

## 17. Limitaciones

1. **`qp_source_extract.extract_children`/`inventory` no aplican materialidad automáticamente** —
   solo `qp_dependency_graph.discover_graph` lo hace. Esto significa que `inventory`/`prepare` sobre
   NCBE-661 real seguirán reportando `sp_cont_impuesto` sin hijos (AMBIGUOUS puro, sin resolver) a
   menos que se extienda esa lógica al pipeline de entrega — decisión deliberadamente diferida para
   no alterar el comportamiento certificado de QP-GEN-01 sin autorización explícita.
2. **`informacion-librerias.json` no cubre las 34 dependencias de negocio no mapeadas de NCBE-661**
   — son SPs que aún no fueron migrados a microservicio propio; ningún artefacto de esta fase
   inventa esa migración. Quedan correctamente como candidatos documentados
   (`BUSINESS_MAPPING_MISSING`), visibles en `resolution-report.json` para decisión humana futura.
3. **`sp_ccndc_automatica` permanece bloqueado** (`AMBIGUOUS_MATERIAL`) — la causa raíz es un
   artefacto de wrap de línea en la extracción (`sp_gen_secend`), no una ambigüedad de negocio real,
   pero corregir el heurístico de `_dewrap_sp_text` está fuera de alcance de esta fase (tocaría el
   motor de extracción compartido con el pipeline de entrega ya certificado).
4. **La ruta obsoleta de `call_strategy_script` en `NCBE-661.json` sigue sin corregir en la config**
   (documentada, no corregida — ver sección 12); la resolución portable mitiga el riesgo pero la
   config sigue declarando una ruta que depende de que el setup anterior siga existiendo en el
   filesystem de esta máquina.
5. **`derive_package_plan` no tiene descubridor automático de qué micro/`informacion-librerias.json`
   corresponde a un SP dado cuando hay múltiples candidatos plausibles** — hoy el llamador
   (`cmd_discover_only`) busca en `repos_roots`/`sp_source_roots` del propio cono; un futuro
   orquestador que reciba solo un nombre de micro tendría que resolver primero cuál
   `informacion-librerias.json` es el correcto antes de invocar `derive_package_plan`.
6. **No se probó ningún caso real con más de 2 candidatos ambiguos para el mismo SP** — la lógica de
   `assess_ambiguity_materiality` generaliza a N candidatos por diseño (compara TODOS los conjuntos
   de targets, no solo un par), pero el corpus real disponible solo presentó casos de 2.

---

## 18. Estado Git final

```bash
$ git status --short --branch
## master...origin/master
 M .claude/docs-qa/inputs/scripts/queryplan/qp_pipeline.py
 M .claude/docs-qa/inputs/scripts/queryplan/qp_source_extract.py
 M .claude/history/agente-queryplan.md   (preexistente, sin relación con esta sesión)
?? .claude/docs-qa/inputs/scripts/queryplan/qp_dependency_graph.py
?? .claude/docs-qa/inputs/scripts/queryplan/qp_mapping_import.py
?? .claude/docs-qa/inputs/scripts/queryplan/schema/queryplan-dependency-graph-v1.schema.json
?? .claude/docs-qa/inputs/scripts/queryplan/schema/queryplan-mapping-relaciones-v1.schema.json
?? .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_dependency_graph.py
?? .claude/docs-qa/inputs/scripts/queryplan/tests/test_qp_gen_02b.py
?? .claude/docs-qa/queryplan/generalizacion/

$ git diff --cached --name-only
(vacío)

$ git rev-parse HEAD
0e1733f5a378faf7666c0f1fccd2a3ebb96fcdf6   (idéntico al del precheck inicial — HEAD no se movió)

$ git rev-list --left-right --count HEAD...@{u}
0	0
```

Índice vacío. Sin commit. Sin push. Sin conexión Sybase en ningún momento de esta fase. Sin cambios
en entregas (`entregas/NCBE-1105-*`, `entregas/NCBE-661-*` con `git diff` vacío). Sin cambios en
Matrices de Equivalencia. Sin cambios en repositorios de negocio (`informacion-librerias.json` de
los micros reales se leyó en modo solo-lectura; nunca se escribió, movió ni modificó). Sin cambios en
`config/cones/*.json`. `.claude/history/agente-queryplan.md` con el mismo diff de 1 línea
preexistente desde antes del inicio de esta sesión.

---

## 19. Siguiente paso permitido

Revisar este reporte y decidir si se autoriza iniciar **QP-GEN-03** (orquestador único end-to-end:
`qp_orchestrator.py run-cone`), ahora con la base de descubrimiento transitivo y derivación de
paquetes ya cerrada (`PACKAGE_DERIVATION_READY`). Antes de QP-GEN-03, considerar si se autoriza:
(a) extender la política de materialidad de ambigüedad al pipeline de entrega
(`qp_source_extract.extract_children`/`inventory`), hoy solo disponible en `discover_graph`; (b)
corregir el heurístico de wrap que produce el artefacto `sp_gen_secend` en `sp_ccndc_automatica`;
(c) corregir la ruta obsoleta de `call_strategy_script` en `NCBE-661.json`. No se debe iniciar
implementación de QP-GEN-03 sin autorización explícita.

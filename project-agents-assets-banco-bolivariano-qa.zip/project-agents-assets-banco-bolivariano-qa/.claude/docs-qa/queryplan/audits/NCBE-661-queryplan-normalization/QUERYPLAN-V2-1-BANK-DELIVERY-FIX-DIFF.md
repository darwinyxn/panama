# Diff de correccion — entrega Banco v2.1 (NCBE-661): antes vs despues

Fecha (UTC): 2026-07-15
Base comparada: `origin/main = a80dc6c` (entrega v2.1 con las regresiones D1-D7).
Operacion: regeneracion por el pipeline canonico (`qp_pipeline.py regenerate`, MIGRATION_RECOVERY con
seed auditado). Sin Sybase, sin edicion manual. Determinismo 12/12 + consolidado.

## Cambios PERMITIDOS aplicados (presentacion / trazabilidad)

| Defecto | Campo/artefacto | Antes | Despues |
|---------|-----------------|-------|---------|
| D1 | detalle_ejecucion.qp | 1 wrapper `Msg N (severity 10...)` por QP (prefijo `\r`) | 0 wrappers sev 0-10 (CRLF->LF antes de desenvolver); `Total writes` conservado |
| D2 | ejecucion.timing (por QP) | `executed_at_utc` = inicio de corrida en los 103 QP, precision=second, inferida=false | objeto `timing {started/completed/duration_ms, timing_status}`; `NOT_CAPTURED` (honesto). Timestamp de corrida movido a `fechas.run_started_at_utc` |
| D3 | sql.ejecutado | `sha256` == `payload_sha256` | `text_sha256` (hash del texto SQL) != `payload_sha256` (bloque tsql). Recalculado, no heredado |
| D4 | detalle_ejecucion.qp | sin inventario de hijos; orquestador con detalle vacio | seccion `INVENTARIO DE SP HIJOS` uniforme; orquestador explica 0 QP + lista hijos |
| D5 | sps_hijos | `lineas=null` | `call_sites[]` estructurado (source_path relativo, linea_inicio/fin); `len==ocurrencias` |
| D6/D7 | plan | interpretaciones sin raw | `labels_raw_informational[]` (raw+kind+interpretation); toda interpretacion traza a un raw |
| D7 | metadata top-level | microservicio/base_datos_default null | resueltos desde cone config (declarativo) |

Ademas: el consolidado registra `source_mode`; no expone seed ni rutas internas en los ZIP de Banco.

## Cambios PROHIBIDOS: NINGUNO (verificado programaticamente)

Comparacion QP-a-QP vs `a80dc6c`: **0 diferencias** en:
- SQL ejecutado (texto materializado);
- io.tables (medido);
- observaciones (codigos/criterios funcionales);
- tipo_dml;
- payload_sha256;
- planes sustantivos, DML/noexec, conteos tecnicos.

## Conteos globales (sin forzar)

12 paquetes | 103 QP | 24 QP con observacion | 26 DML noexec | 0 errores |
36 child entries | 45 call-sites | 28 SP hijos unicos.

Wrappers severity 0-10 en ZIP: 0. Leaks (/tmp, bc0aadc, /home, seed) en ZIP: 0. Determinismo 12/12.

## Reproducibilidad

Los 12 ZIP y el consolidado son 100% reproducibles desde el entrypoint canonico
(`qp_pipeline.py regenerate ... --legacy-seed git:<ref>`), byte-identicos en doble corrida. Ningun
artefacto fue editado a mano.

## Segunda pasada: consistencia de metadata renderizada (R1-R6)

Revision directa de 7 paquetes finales detecto residuales de PRESENTACION (el renderer consumia
metadata intermedia en vez del modelo canonico final). Corregidos de raiz (renderer/writer/extractor/
linter/schema/tests) y regenerados por el pipeline. Causa raiz comun: `render_detalle`/
`render_observaciones` leian `tech_src` (seed/intermedio) y variables del run, no el manifest final.

| # | Sintoma | Causa raiz | Correccion |
|---|---------|-----------|------------|
| R1 | detalle imprimia `executed_at_utc: <run ts>` en cada QP | renderer usaba el param de corrida, no `ejecucion.timing` | detalle renderiza `timing_status/started/completed/duration_ms` (N/A si NOT_CAPTURED) |
| R2 | ORQUESTADOR_PURO (0 QP) mostraba `ejecucion_viva_utc: <ts>` | header usaba el ts global sin importar naturaleza | header: `ejecucion_sybase: NO_APLICA (ORQUESTADOR_PURO / 0 QP)` |
| R3 | `microservicio:  |` vacio en detalle/obs pese a valor en manifest | renderer leia `tech_src.microservicio` (null) | renderer consume `man.microservicio`; cross-lint exige manifest==detalle==obs |
| R4 | literal `base=None` en bloques humanos | se imprimia `q.base_datos` (None) crudo | `_fmt_base` (NO_APLICA); base resuelta del SQL (`databases_from_sql`, generico) |
| R5 | validacion/regeneracion == run ts, fuente=sistema, inferida=false | se copiaba el run ts como fecha factual | `validacion=null`; `regeneracion` con `fuente=parametro_corrida` |
| R6 | `repositorio=null` silencioso | repos *-utils externos, no en workspace | se registra `metadata_status.repositorio_por_paquete` con razon; NO se inventa |

Cross-lint nuevo (gate): detecta `executed_at_utc:` en detalle (R1), `base=None` (R4), micro
manifest!=detalle/obs (R3), timestamp de ejecucion en ORQUESTADOR_PURO (R2). Auditoria directa sobre
los 12 ZIP: 0 coincidencias para sev0-10 / `microservicio:  |` / `base=None` / `executed_at_utc:` /
`/tmp` / seed. Hechos tecnicos (SQL ejecutado, IO, observaciones, payload_sha256, text_sha256):
PRESERVADOS. Determinismo 12/12. Tests 153/153.

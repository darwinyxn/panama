# Auditoria completa de SQL — entrega Query Plan (cono sp_debcred_empresa)

Fecha auditoria (UTC): 2026-07-15
Entrega auditada: `docs-qa/queryplan/entregas/NCBE-661-queryplan-2026-07-09-statistics-io/`
Base: commit `d71be36a9e9ed9e28f17cefa7b91c77d525dc99c`
Evidencia raw historica: commit `d52f7487fbab7926f67d7a0a4cddcd013899a0bb`
Alcance: **dinamico** — 12 paquetes descubiertos del inventario del cono (no lista fija).

## 1. Resumen

- Total paquetes: **12** (dinamico, del `total_paquetes`/inventario del consolidado).
- Total QP: **103**.
- Observaciones: **24**. Errores SQL reales (severity >= 11): **0**.
- Detector determinista y consciente de strings/comentarios: `qp_sqlcheck.py`.

**Veredicto: `BLOCKED_REQUIRES_SYBASE_RERUN`.** La entrega actual NO es apta para reenvio hasta
reejecutar los QP con SQL ejecutado abreviado. NO se infiere ni reconstruye `sql_ejecutado` sin
evidencia exacta de lo enviado a Sybase (instruccion de Gengis).

## 2. Hallazgos por tipo

| Tipo | Regla | Paquetes afectados | Severidad | Reconstruible sin Sybase |
|------|-------|--------------------|-----------|--------------------------|
| SQL ejecutado abreviado (`insert ...(...) values (...)`) | abbrev_paren_ellipsis | sp_cont_impuesto (6 QP), sp_graba_tran_servicio (1 QP) | BLOQUEANTE | NO — requiere rerun |
| SQL original abreviado (`(...)`, `[N columnas]`, `VALUES (?,...)`, `(39 cols)`, `SET (31 cols)`, `SELECT TOP 60 ...`) | abbrev_* | sp_cont_impuesto (6 QP), sp_eventos (5 QP) | ALTA | SI — desde fuente del SP (solo informativo) |
| Referencia colgante `raw_QP-XX.txt` / `raw: queryplan/...` | dangling_raw_txt / dangling_raw_path | sp_cal_impuesto (10), sp_cont_impuesto (26) | MEDIA | SI — quitar sufijo raw del `output_sybase_path` |
| Referencia colgante `engine_out/QP-XX.out (embebido...)` | dangling_engine_out | sp_debcred_empresa (19) | MEDIA | SI — reescribir a `detalle_ejecucion.qp#QP-XX` |

Todos los `...` restantes (arbol del plan, prosa, literales `isnull(x,'')`) son legitimos y NO se marcan
(deteccion consciente de contexto).

## 3. Tabla por paquete (dinamica)

| Paquete | QP | sql_orig abrev | sql_exec rerun | refs colgantes | estado gate |
|---------|----|----------------|-----------------|-----------------|-------------|
| sp_debcred_empresa | 19 | 0 | 0 | 19 | FAIL (refs) |
| pa_aho_pvalida_depini | 3 | 0 | 0 | 0 | PASS |
| pa_aho_pvalida_ndnc | 2 | 0 | 0 | 0 | PASS |
| pa_cte_pvalida_ndnc | 2 | 0 | 0 | 0 | PASS |
| sp_cal_impuesto | 5 | 0 | 0 | 10 | FAIL (refs) |
| sp_cont_impuesto | 13 | 6 | 6 | 26 | FAIL (rerun + orig + refs) |
| sp_eventos | 35 | 5 | 0 | 0 | FAIL (orig) |
| sp_genera_iva_comision | 12 | 0 | 0 | 0 | PASS |
| pa_sat_pnotificacion | 8 | 0 | 0 | 0 | PASS |
| sp_graba_tran_servicio | 2 | 0 | 1 | 0 | FAIL (rerun) |
| sp_ndc_ahcc | 0 | 0 | 0 | 0 | PASS (orquestador puro) |
| sp_grb_comision | 2 | 0 | 0 | 0 | PASS |

## 4. QP que REQUIEREN rerun de Sybase (clasificacion `REQUIRES_SYBASE_RERUN`)

El `sql_ejecutado` capturado tiene la lista de columnas colapsada a `(...)` — un INSERT con `(...)`
como lista de columnas NO es SQL Sybase valido, por lo que NO se puede saber con certeza que se envio
realmente al motor. La evidencia historica (d52f748) tiene la MISMA abreviacion; no hay fuente exacta.

| Paquete | QP | tabla | tipo | por que rerun |
|---------|----|-------|------|---------------|
| sp_cont_impuesto | QP-08 | cob_cuentas..cc_tran_servicio | INSERT | exec `(...) values (28 lit)` |
| sp_cont_impuesto | QP-09 | cob_cuentas..cc_tran_servicio | INSERT | exec `(...) values (28 lit)` |
| sp_cont_impuesto | QP-10 | cob_ahorros..ah_tran_servicio | INSERT | exec `(...) values (26 lit)` |
| sp_cont_impuesto | QP-11 | cob_ahorros..ah_tran_servicio | INSERT | exec `(...) values (...)` |
| sp_cont_impuesto | QP-12 | cob_virtuales..vi_tran_servicio | INSERT | exec `(...) values (...)` |
| sp_cont_impuesto | QP-13 | cob_virtuales..vi_tran_servicio | INSERT | exec `(...) values (...)` |
| sp_graba_tran_servicio | QP-02 | cob_cuentas..cc_tran_servicio | INSERT | exec `(...) values (...)` |

Nota: `sql_original` de estos QP SI es recuperable exacto desde el fuente del SP
(`sybase-local/.../sps/cob_cuentas__sp_cont_impuesto.sql`, etc.), pero eso NO reemplaza la evidencia
del `sql_ejecutado` real (orden de columnas enviado). Por eso se marca rerun, no reconstruccion.

## 5. Clasificacion de reconstruccion (Fase 4)

| Paquete | QP | fuente disponible | clasificacion |
|---------|----|-------------------|---------------|
| sp_cont_impuesto | QP-08..13 | fuente SP (solo original) | REQUIRES_SYBASE_RERUN (exec) |
| sp_graba_tran_servicio | QP-02 | fuente SP (solo original) | REQUIRES_SYBASE_RERUN (exec) |
| sp_eventos | QP-17,18,19,29,31 | fuente SP / bloque tsql | RECOVERED_FROM_SOURCE_EQUIVALENT (solo `sql_original`; exec ya presente en bloque) |
| sp_debcred_empresa, sp_cal_impuesto, sp_cont_impuesto | refs | interno | fix de presentacion (quitar refs colgantes) |

## 6. Origen probable del defecto

El generador escribia `sql_ejecutado` y `sql_original` con la lista de columnas resumida
editorialmente a `(...)`/`[N columnas]` para INSERT/UPDATE anchos, y anotaba `output_sybase_path` con
rutas raw (`raw_QP-XX.txt`, `engine_out/QP-XX.out`) que nunca se incluyeron en el ZIP entregable. El
contrato previo no exigia SQL completo ni referencias internas navegables, y el linter no lo validaba.

## 7. Correccion de raiz aplicada en este commit

- `qp_sqlcheck.py`: detector determinista (abreviaciones, placeholders sin resolver, refs colgantes),
  consciente de strings/comentarios.
- `qp_lint.py`: gates nuevos — SQL original/ejecutado completo, placeholders, refs colgantes,
  manifest<->detalle 1:1, DML/noexec, con mensajes accionables (paquete/QP/campo/regla/fragmento/accion).
- Agente/skill/normalizador/regenerador: contrato de SQL completo y de referencias internas.
- Pruebas: fixtures para todos los casos.

La reejecucion delta de los 7 QP bloqueados queda pendiente de autorizacion de Gengis (no se ejecuta
Sybase en esta fase).

---

## 8. RESOLUCION — Reejecucion completa del cono (2026-07-15)

Los 7 QP `REQUIRES_SYBASE_RERUN` (sp_cont_impuesto QP-08..13, sp_graba_tran_servicio QP-02) fueron
RESUELTOS mediante reejecucion completa contra Sybase VIVO con el pipeline endurecido:

- Los 6 INSERT de sp_cont_impuesto se reconstruyeron con la lista EXACTA de columnas del fuente del SP
  (variante correcta por rama; columnas=valores verificado: 28=28 y 26=26) y se ejecutaron bajo
  `set noexec on`; plan INSERT capturado (INSERT Operator + TO TABLE), 0 datos escritos.
- sp_graba_tran_servicio QP-02: el bloque completo (34 cols=34 vals) ya existia en el detalle; se
  reejecuto bajo noexec.
- Todo el cono (12 paquetes / 103 QP) se regenero end-to-end secuencialmente (concurrencia 1, pacing
  3-5s), no solo los afectados. 12/12 PACKAGE_READY, linter global PASS, 0 sev>=11, 0 abreviaciones,
  0 placeholders sin resolver, 0 referencias colgantes.
- Comparacion anterior<->nueva: 0 diferencias inesperadas (mismo QP/planes/observaciones/DML por
  paquete). IO recapturado en vivo (sp_eventos hallazgo preservado: logical ~187027 / physical ~7195).
- SQL abreviado en `sql_original` (sp_eventos QP-17/18/19/29/31) expandido a listas completas del fuente.
- Referencias colgantes (`raw_QP-XX.txt`, `engine_out/...`) corregidas a `detalle_ejecucion.qp#QP-XX`.

Estado: entrega canonica reemplazada atomicamente. `FULL_CONE_PASS`.

# Diff semantico — baseline (v1/v2.0) vs entrega canonica v2.1 (NCBE-661)

Fecha (UTC): 2026-07-15T15:20:39Z (timestamp real de la corrida viva)
Base git: `origin/main = bc0aadc` (v2.0 publicada, DEPRECATED_INTERNAL_NOT_FOR_DELIVERY).
Operacion: `FULL_LIVE_RERUN` — 103/103 QP re-ejecutados VIVOS contra Sybase SYBASE02, un tsql por QP,
concurrencia 1, pacing 3s, DML solo bajo `set noexec on/off`, SP hijos NO ejecutados (BARRERA_3).

## Verdad tecnica: PRESERVADA salvo IO fisico (variacion legitima por cache)

Comparacion QP-a-QP v2.0 -> v2.1 (contenido tecnico):

| Dimension | Resultado |
|-----------|-----------|
| Cantidad de QP (103) | IDENTICA (103/103) |
| Tipo de sentencia / SQL ejecutado materializado | IDENTICO |
| Plan sustantivo (showplan) y etiquetas criterio A | IDENTICO (0 cambios en 103 QP) |
| Criterio B (logical>10000) | IDENTICO (2 observaciones, reproducen) |
| IO logico (logical reads) | Estable: 2/70 QP con IO medido varian minimamente; ningun cruce de umbral |
| IO fisico (physical reads) | **Variable por cache: 11/70 QP difieren** (esperado; no determinista) |
| QP con observacion (nivel QP) | 24 -> **24** (sin cambio) |
| Observaciones (objetos individuales) | 30 -> **29** |

### Unico cambio de observacion: sp_eventos QP-18 criterio C (por cache)

En v2.0 sp_eventos QP-18 tenia una observacion criterio C (physical_total>1000; valor historico 7195).
En la corrida viva v2.1, QP-18 registro physical_total=0 (datos ya en cache del servidor). El plan y
los criterios A/B de QP-18 permanecieron ESTABLES (sigue observado por A_TABLE_SCAN + B_LOGICAL_READS).
Por eso el conteo de QP-con-observacion se mantiene en 24, pero el objeto-observacion C individual
desaparece (30 -> 29 objetos). Esto es comportamiento esperado del IO fisico (dependiente del estado de
cache), NO un cambio de plan.

Decision (criterio del ingeniero): la corrida v2.1 debe ser internamente auto-consistente — manifest,
detalle, observaciones, IO y `stdout_sha256` provienen de la MISMA ejecucion fresca. NO se preserva
artificialmente la observacion C historica ni se fuerza el conteo de objetos a 30. La observacion C
historica queda registrada AQUI (reporte comparativo), no como observacion activa del manifest. No se
limpio cache ni se hizo ninguna accion invasiva para intentar reproducirla.

Todo lo demas (SQL ejecutado, plan sustantivo, IO logico, criterios A/B) es IDENTICO entre v2.0 y v2.1.

## Verdad estructural / trazabilidad: CORREGIDA (los 10 defectos)

| Defecto | v2.0 (baseline) | v2.1 (canonico) | Evidencia |
|---------|-----------------|-----------------|-----------|
| D1 sps_hijos | 0 en 12/12 | **36** invocaciones (34 BUSINESS + 2 TECHNICAL_UTILITY; 28 unicos) | 0->9,1,2,2,0,2,5,4,1,1,3,6 |
| D2 ORQUESTADOR_PURO | sp_ndc_ahcc con 0 hijos | 3 hijos reales | pa_cte/pa_aho/sp_genera_iva |
| D3 `?` en sql.legacy | 72 QP | 0 (reubicado a template_micro) | gate rechaza `?` en legacy |
| D4 template_micro | null 103/103 | poblado por procedencia | — |
| D5 fechas | 00:00/06:00 inventadas | reales `2026-07-15T15:20:39Z` precision=second fuente=sistema | executed_at_utc por QP |
| D6/D7 labels | normalized sin raw | DERIVADOS de raw via mapa `2026-07-15` + label_derivations | trazable 1:N |
| D8 obs.tabla | 30 con tabla=null | **0** con tabla=null (de 29 objetos) | tabla derivada del arbol del plan / IO |
| D9 libraries | NOT_APPLICABLE por defecto | coherente con clasificacion de hijos | — |
| D10 sybase | string alias+version mezclado | objeto host_alias/ase_version/ase_ebf | SYBASE02 / 16.0 SP04 / PL08 |
| E2E | payload_sha256 solo; stdout/stderr/exit/ts null | payload+stdout+stderr sha256 + exit_code + executed_at_utc REALES | 103/103 |

## Totales de la entrega v2.1

- 12 paquetes, **103 QP**, **24 QP con observacion** (29 objetos-observacion: 27 A + 2 B + 0 C),
  **26 DML protegidos noexec**, **0 errores SQL**.
- **Inventario de SP hijos (por invocacion directa, cierre de auditoria conteos+clasificacion):**
  - `total_child_entries` = **36** (una entrada por combinacion padre+SP hijo).
  - `total_child_call_sites` = **45** (suma de `ocurrencias` = sitios `exec` reales en el fuente,
    scan wrap-tolerante; distinto de entries porque varios hijos se invocan en >1 sitio del mismo padre,
    p.ej. `sp_con_confcontable`=3, `sp_grb_mov_y_frmpgo`=2, `sp_gen_sec` en genera_iva=2).
  - `total_unique_child_procedures` = **28** (SP completos distintos globales).
  - `total_business_entries` = **34** / `total_business_call_sites` = **42**.
  - `total_technical_entries` = **2** / `total_technical_call_sites` = **3**.
  - `ejecutado=false` en 36/36 (BARRERA_3).
- **Correccion 1 (iteracion previa):** se habian EXCLUIDO 2 invocaciones a `cob_cuentas..sp_gen_sec`
  por ser utilidad tecnica. Incorrecto: se CLASIFICAN (`categoria=TECHNICAL_UTILITY`), no se excluyen.
  - `sp_gen_sec` en `sp_genera_iva_comision`: **1 entry, 2 call-sites** (l.403, l.413).
  - `sp_gen_sec` en `sp_graba_tran_servicio`: **1 entry, 1 call-site** (l.76, Ref4/REF1).
  - Total tecnico: 2 entries / **3 call-sites**. Precedente v1: adapter `SpGenSecLegacyAdapter`.
- **Correccion 2 (esta iteracion):** la `clasificacion` NO es toda `CallDirect`. Auditada contra el
  script oficial `determinar-call-strategy.sh` sobre las listas fisicas del banco:
  - **17 entries CallDirect** (SP en la lista fisica CallDirect; 14 SP unicos).
  - **19 entries UnclassifiedRefactor** (no figuran en ninguna lista: los 11 miembros del propio cono
    NCBE-661 que se invocan entre si, mas grandchildren no clasificados `sp_ahndc_automatica`,
    `sp_ccndc_automatica`, `sp_gen_sec`).
  - **0** en CallCobis / CallLibrary / CallExistLibrary / CallExistDml. `cob_cuentas..sp_gen_sec` es
    `UnclassifiedRefactor` (no esta en CallCobis ni en CallDirect). Cada hijo lleva `resolution_status`
    segun su estrategia (adapter legacy / libreria / pendiente-clasificacion).
- Baseline 103 QP / 24 QP-con-obs / 26 DML / 0 err alcanzado SIN forzar: coincide con el inventario
  real (v1 y v2.0 tambien tenian 103 QP; ver COMPAT-AND-GAP-REPORT). El unico delta de observaciones es
  el objeto-obs C de QP-18 (30->29 objetos) por variacion de cache, documentado arriba.

## Auto-consistencia de artefactos (decision del ingeniero)

`detalle_ejecucion.qp` y `observaciones.qp` fueron REGENERADOS desde el stdout normalizado de la
corrida viva 2026-07-15T15:20:39Z (no se reusaron los del baseline). Cada bloque del detalle referencia
el `payload_sha256`/`stdout_sha256`/`stderr_sha256`/`exit_code` exactos de SU ejecucion. Asi, manifest
(io.tables) + detalle (output del motor) + observaciones + hashes E2E describen la MISMA ejecucion — la
trazabilidad que v2.0 rompia. La evidencia raw por-QP (`.out`/`.err`) se conserva fuera del ZIP en el
staging interno de la corrida; el ZIP para Banco contiene solo manifest + detalle + observaciones.

### Nota de inventario de hijos (criterio explicito)

El analisis de fuente hallo **36 invocaciones directas** a SP hijos (child-per-parent). TODAS se
inventarian, clasificadas por `categoria`: **34 BUSINESS + 2 TECHNICAL_UTILITY** (`cob_cuentas..
sp_gen_sec`). NUNCA se excluye una invocacion por ser utilidad tecnica; se clasifica. `cobis..sp_cerror`
(ERROR_HANDLING) y SPs de debug/log de plataforma NO son invocaciones inventariables de este contrato
(no son ni negocio ni utilidad de datos; son fail-safe/observabilidad de plataforma) y se documentan
aparte. `total_hijos_unicos` = 28 (SP distintos, ya que varios se invocan desde >1 padre).

## Captura E2E (por que v2.1 SI puede poblar lo que v2.0 dejo null)

La corrida viva v2.1 reutilizo los 103 payloads `.sql` EXACTOS ya verificados (mismo `payload_sha256`),
los re-ejecuto VIVOS y capturo por-QP: `stdout` completo (sha256), `stderr` completo (sha256),
`exit_code` y `executed_at_utc` real. El staging previo solo conservaba el `.sql`+`.sha256`, por eso
v2.0 dejo stdout/stderr/exit/timestamp en null; v2.1 los tiene de evidencia directa.

## Determinismo

Regeneracion doble desde el MISMO E2E capturado -> 12/12 ZIP byte-identicos (0 diffs). Los timestamps
de ejecucion/validacion/regeneracion se fijan una vez por corrida (pasados como parametro, no `now()`).

## Cambios PROHIBIDOS: ninguno

No se altero cantidad de QP, SQL ejecutado, plan sustantivo, IO medido, observaciones aplicables,
conteos ni el criterio Banco `2026-07-09-statistics-io`. Solo se corrigio estructura/trazabilidad y se
capturo evidencia E2E real.

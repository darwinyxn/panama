# Nota de operacion — reasignacion de HU del Query Plan de sp_debcred_empresa

Fecha (UTC): 2026-07-15
Alcance: SOLO trazabilidad de HU del paquete Query Plan de la libreria `sp_debcred_empresa`.
No live: no se toca Jira/Confluence/QMetry en esta tarea (solo se documenta la accion).

## Criterio QA (confirmado)

- El Query Plan NO se asigna a la HU del microservicio.
- El Query Plan se asigna a la HU de la LIBRERIA.
- HU del micro / cono: `NCBE-661` (se mantiene).
- HU individual correcta de la libreria `sp_debcred_empresa`: `NCBE-868`.

## Cambio aplicado (fuente de verdad)

- Archivo: `claude-setupv2/.claude/scripts/queryplan/config/cones/NCBE-661.json`
  (fuente de verdad `sp -> hu_jira` que CONSUME `qp_pipeline.py`).
- Entrada: `packages.sp_debcred_empresa.hu`: `NCBE-661` -> `NCBE-868`.
- `cone_hu` (top-level) permanece `NCBE-661`. Los otros 11 paquetes: HU sin cambios.
- Regenerado por `qp_pipeline.py` (MIGRATION_RECOVERY, seed auditado); sin edicion manual de ZIP/
  manifest/consolidado. README (doc mantenido a mano) actualizado en su tabla de mapeo.

## Accion de entrega (para ejecutar por el responsable, NO en esta tarea)

- Adjuntar `sp_debcred_empresa-queryplan.zip` (regenerado, hu_individual=NCBE-868) a la HU `NCBE-868`.
- `NCBE-661` continua como HU del micro/cono; no borrar evidencia historica de `NCBE-661` sin
  autorizacion.
- Si la plataforma no permite mover adjuntos: subir el ZIP final a `NCBE-868` y dejar en `NCBE-661`
  una nota de reubicacion apuntando a `NCBE-868`.

## Nota sobre `informacion-librerias.json`

`bem-mso-debito-credito-empresa-pagos/informacion-librerias.json` (repo del micro, FUERA de
claude-setupv2) tiene la entrada `db_biz_pagos..sp_debcred_empresa` con `hu_jira=NCBE-661`. Ese archivo
NO lo consume `qp_pipeline.py` y contiene credenciales (`token`), por lo que NO se modifica en esta
tarea (fuera de alcance / repo distinto / credenciales). Si el Banco desea alinear tambien ese insumo,
debe hacerse en el repo del micro por el responsable correspondiente. La fuente de verdad del Query
Plan es la cone config, ya corregida.

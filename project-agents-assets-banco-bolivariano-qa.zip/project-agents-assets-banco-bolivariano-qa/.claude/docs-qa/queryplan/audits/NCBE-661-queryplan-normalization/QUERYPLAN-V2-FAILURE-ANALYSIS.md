# Analisis de fallas — manifest v2.0 publicado (NCBE-661)

Fecha (UTC): 2026-07-15
Alcance: read-only sobre la entrega v2.0 publicada en `origin/main = bc0aadc`.
Conclusion: la entrega v2.0 es `NOT_FOR_DELIVERY`. Aunque el SQL ejecutado, planes, IO y conteos
son tecnicamente correctos (heredados de la corrida viva 2026-07-15, byte-identicos en detalle/obs),
el **manifest** v2.0 perdio o falseo metadata estructural durante la regeneracion (compat->writer).
La causa raiz comun: la regeneracion v2 se hizo mapeando el manifest LEGACY (que ya carecia de varios
campos) en vez de re-derivar desde la evidencia y el codigo fuente.

## Defectos confirmados (12 paquetes / 103 QP)

| # | Defecto | Evidencia | Causa raiz |
|---|---------|-----------|------------|
| D1 | `sps_hijos = []` en 12/12 | inventario de SP hijos totalmente perdido | el compat reader no extrajo los hijos de las variantes legacy (`sps_hijos_inventariados_no_ejecutados`, `child_sp_inventory`, ...); el modelo interno los dejo en [] |
| D2 | `ORQUESTADOR_PURO` con 0 hijos | sp_ndc_ahcc: 0 hijos en manifest pese a **3 `exec`** en el SP fuente | consecuencia de D1; ademas no se valido la coherencia orquestador->hijos |
| D3 | `?` JDBC en `sql.legacy` | 72 QP | el legacy `sql_original` contenia el SQL del ADAPTER (con `?`), no el del SP; se copio tal cual a `sql.legacy` |
| D4 | `template_micro = null` | 103/103 QP | el campo nunca se poblo; el SQL del adapter quedo mal ubicado en `legacy` |
| D5 | timestamps fijos sin evidencia | 12/12 (`ejecucion_sybase=...00:00:00Z`, `validacion/regeneracion=...06:00:00Z`) | se uso una constante de conveniencia; el dia real era 2026-07-15 pero no habia hora comprobable -> se invento medianoche/06:00 |
| D6 | `labels_normalized` sin raw correspondiente | p.ej. sp_debcred QP-01 raw=[Table Scan] pero norm=[TABLE_SCAN, FORWARD_SCAN, POSITIONING_BY_KEY] | el normalizador derivo codigos de `labels_detected` legacy (que incluia Forward Scan/Positioning "informativos") en vez de solo de `labels_raw` |
| D7 | interpretaciones inconsistentes | Forward Scan+Positioning by key tratado distinto entre paquetes | sin mapa de labels versionado; interpretacion ad hoc |
| D8 | observacion con `tabla = null` | 30 observaciones | la codificacion de motivos no extrajo la tabla del IO/plan aunque era identificable |
| D9 | `libraries_status = NOT_APPLICABLE` | 12/12 | valor por defecto; no se clasifico contra CallLibrary/CallExistLibrary reales |
| D10 | metadata top-level mezclada | `servidor_sybase` incluye alias+version en algunos; `ase_version`/`ase_ebf` no separados; micro/repo/base null en varios paquetes | mapeo directo de aliases legacy sin normalizar/enriquecer desde inventario |

## Impacto

- La verdad TECNICA (SQL ejecutado, plan, IO, observaciones A/B/C, conteos 103/24/26/0) es correcta y
  reproducible; NO esta comprometida.
- La verdad ESTRUCTURAL/de trazabilidad del manifest SI esta comprometida (D1-D10) -> el manifest v2.0
  NO es apto para Banco como fuente canonica de trazabilidad.

## Decision

- Marcar v2.0 como `DEPRECATED_INTERNAL_NOT_FOR_DELIVERY`.
- Corregir el contrato a v2.1 (fechas con precision/fuente; SQL legacy vs template_micro vs ejecutado
  con procedencia; sps_hijos canonicos; labels raw->normalized trazables via mapa versionado;
  observaciones con tabla; libraries clasificadas; metadata top-level separada).
- Regenerar el cono con corrida viva nueva (evidencia E2E real) + inventario desde codigo fuente.
- Gates que atrapen especificamente D1-D10.

Cada defecto tiene una prueba que falla antes del fix (ver tests v2.1).

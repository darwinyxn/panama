# Dry-run de compatibilidad v2 — lectura de los 12 ZIP publicados

Fecha (UTC): 2026-07-15
Corpus: 12 manifests de `origin/main` = `945d4be`.
Lector: `qp_manifest_compat.read_manifest` (READ MANY -> NORMALIZE).
Modo: **read-only**. NO se reescribio, NO se cambiaron hashes, NO se extrajeron archivos al repo.

## Resultado global

- **Leidos: 12/12.**
- **Conflictos reales: 0.**
- **QP normalizados: 103** (idéntico al total publicado).
- **Pérdida de información: 0** (todo campo con dato mapea a un concepto canónico; los no mapeables
  se conservan como warning informativo, no se descartan silenciosamente).
- Clasificación: 12 `LEGACY_NORMALIZED`, 0 `LEGACY_CONFLICT`, 0 `UNSUPPORTED_SCHEMA`.

## Detalle por paquete

| Paquete | Clasificacion | QP | Warnings | Conflictos | Aliases detectados (muestra) |
|---------|---------------|----|----------|------------|------------------------------|
| pa_aho_pvalida_depini | LEGACY_NORMALIZED | 3 | 2 | 0 | servidor->servidor_sybase; fecha->fechas.ejecucion_sybase |
| pa_aho_pvalida_ndnc | LEGACY_NORMALIZED | 2 | 7 | 0 | database->base_datos_default; microservice->microservicio; statements->queryplans |
| pa_cte_pvalida_ndnc | LEGACY_NORMALIZED | 2 | 4 | 0 | database->base_datos_default; repo->repositorio; query_plans->queryplans |
| pa_sat_pnotificacion | LEGACY_NORMALIZED | 8 | 4 | 0 | microservice->microservicio; sp_full->sp_completo; sybase_server->servidor_sybase |
| sp_cal_impuesto | LEGACY_NORMALIZED | 5 | 4 | 0 | base_datos->base_datos_default; repo->repositorio; query_plans->queryplans |
| sp_cont_impuesto | LEGACY_NORMALIZED | 13 | 4 | 0 | microservicio_libreria->microservicio; servidor->servidor_sybase; query_plans->queryplans |
| sp_debcred_empresa | LEGACY_NORMALIZED | 19 | 4 | 0 | microservice->microservicio; servidor->servidor_sybase; sentencias->queryplans |
| sp_eventos | LEGACY_NORMALIZED | 35 | 5 | 0 | db_default->base_datos_default; micro_libreria->microservicio |
| sp_genera_iva_comision | LEGACY_NORMALIZED | 12 | 2 | 0 | repo->repositorio; fecha_corrida->fechas.ejecucion_sybase |
| sp_graba_tran_servicio | LEGACY_NORMALIZED | 2 | 2 | 0 | servidor->servidor_sybase; fecha_corrida->fechas.ejecucion_sybase |
| sp_grb_comision | LEGACY_NORMALIZED | 2 | 1 | 0 | fecha->fechas.ejecucion_sybase |
| sp_ndc_ahcc | LEGACY_NORMALIZED | 0 | 2 | 0 | sp_full->sp_completo; fecha_utc->fechas.ejecucion_sybase (orquestador puro) |

## Nota sobre un falso positivo corregido durante el dry-run

La primera pasada marcó `sp_ndc_ahcc` como `LEGACY_CONFLICT` porque el reader agrupaba
`conexion_sybase` ("OK", estado de conexion) dentro del alias-set de `servidor_sybase` (nombre del
servidor). Se corrigió el mapa de aliases: `conexion_sybase` es un concepto distinto (estado), no un
sinónimo del nombre del servidor. Tras el fix: 0 conflictos. No fue una contradicción de datos del
ZIP, sino un defecto del reader.

## Conclusión

Los 12 manifests históricos siguen siendo 100% legibles con el reader de compatibilidad, sin
pérdida. Las nuevas entregas escribirán únicamente schema v2 (writer `qp_manifest.py`). NO se hace
migración retroactiva de los ZIP aprobados (byte-idénticos), salvo necesidad explícita del Banco.

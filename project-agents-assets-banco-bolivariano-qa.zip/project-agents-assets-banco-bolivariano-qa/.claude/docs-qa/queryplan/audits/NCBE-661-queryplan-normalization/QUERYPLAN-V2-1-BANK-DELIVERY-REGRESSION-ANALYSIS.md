# Analisis de regresiones de presentacion Banco — entrega v2.1 (NCBE-661)

Fecha (UTC): 2026-07-15
Alcance: reproduccion READ-ONLY de defectos de presentacion/trazabilidad en la entrega v2.1 publicada
en `origin/main = a80dc6c`. Los HECHOS TECNICOS (SQL ejecutado, planes, IO, observaciones, conteos)
son correctos; los defectos son de PRESENTACION para Banco y de TRAZABILIDAD del manifest.

## Defectos reproducidos

| # | Defecto | Evidencia | Causa raiz |
|---|---------|-----------|------------|
| D1 | Wrapper `Msg N (severity 10...)` visible en detalle_ejecucion.qp | 1 wrapper superviviente por QP (`Msg 3614 (severity 10, state 0) from SYBASE02`) | El normalizador ancla `^Msg` pero la linea viene con prefijo CR: `\rMsg 3614...` (CRLF de tsql). El `\r` no se normaliza antes de matchear -> 48 wrappers se desenvuelven, 1 (con `\r`) sobrevive |
| D2 | `executed_at_utc` identico en los 103 QP, precision=second, inferida=false | los 19 QP de sp_debcred comparten `2026-07-15T15:20:39Z` | Se copio el timestamp de INICIO de corrida como si fuera la ejecucion exacta de cada QP. No hay timing por-QP capturado; declarar inferida=false es falso |
| D3 | `sql.ejecutado.sha256 == ejecucion.payload_sha256` | ambos `051a22fb...` | Se asigno el payload_sha256 al nodo sql.ejecutado. Son contratos distintos: hash del SQL materializado vs hash del bloque tsql completo |
| D4 | Detalle humano sin inventario de SP hijos | sp_ndc_ahcc (ORQUESTADOR_PURO, 0 QP, 3 hijos) no lista sus hijos ni explica los 0 QP | El renderer solo itera QP; no emite seccion de hijos. Un orquestador puro queda con detalle vacio |
| D5 | Call-sites sin ubicacion | hijos con `lineas=null`, `clase_metodo=null`, `adapter_origen=null` | El extractor calcula `ocurrencias` pero no persiste las lineas/contexto de cada call-site |
| D6 | Interpretaciones sin raw | `labels_raw=[]`, `labels_normalized=[]`, `interpretaciones=[Forward Scan..., Positioning by key...]` | Los informativos flotan como interpretaciones sin un campo raw informativo que los respalde. Faltan `labels_raw_informational` |
| D7 | Metadata top-level resoluble en null | (a revisar por paquete) microservicio/repositorio/base_datos_default null cuando la config/fuente los permite | El modelo toma estos campos del seed/tech_src; no se resuelven desde cone config + inventario |
| D8 | (NO es defecto) 0-observaciones con plantilla igual | dos paquetes con 0 obs comparten estructura | Correcto si nombre/micro/total_qp/timestamp/criterio son correctos. Se agrega prueba que lo permita |

## Impacto

- Verdad TECNICA intacta (SQL/plan/IO/observaciones/conteos correctos y reproducibles).
- Presentacion Banco (D1) y trazabilidad del manifest (D2-D7) comprometidas -> NO bank-ready hasta
  corregir de raiz en el pipeline (normalizador/renderer/writer/schema/linter) + regenerar.

## Correcciones (de raiz, en el pipeline; regeneracion automatica)

- D1: normalizar CRLF/CR->LF ANTES de matchear transporte; linter falla ante `Msg \d+ (severity 0..10`.
- D2: contrato de tiempos separado (run vs QP); timing por-QP null + `timing_status=NOT_CAPTURED` si no
  hay evidencia exacta; prohibido reusar el inicio global como ejecucion exacta con inferida=false.
- D3: `sql.ejecutado.text_sha256` (solo texto SQL) != `payload_sha256` (bloque tsql completo); golden.
- D4: seccion `INVENTARIO DE SP HIJOS` en el detalle; orquestador puro explica 0 QP + lista hijos.
- D5/D6: `call_sites[]` estructurado (source_path, lineas, contexto); `labels_raw_informational`.
- D7: resolver metadata desde cone config + inventario; estado estructurado si no se resuelve.

Cada defecto tiene prueba que falla-antes / pasa-despues (ver test_qp_*.py).

# Procedencia del pipeline v2.1 y de los campos de la entrega NCBE-661

Fecha (UTC): 2026-07-15
Objetivo: documentar (a) el entrypoint canonico versionado que reemplaza al runner efimero de /tmp,
y (b) de que fuente proviene cada campo de la entrega actual, distinguiendo lo que FULL_RUN puede
regenerar sin seed de lo que hoy requiere el seed historico (MIGRATION_RECOVERY).

## Entrypoint canonico

`claude-setupv2/.claude/scripts/queryplan/qp_pipeline.py` (+ modulo `qp_delivery.py` + config
`config/cones/<HU>.json`). Subcomandos: `inventory | preflight | run | regenerate | validate`.
Reemplaza al runner efimero `rerun_v21.py` (staging /tmp), que queda SUPERSEDED y NO versionado.

Comando de reproduccion byte-identica de la entrega actual (desde el repo):

    python3 claude-setupv2/.claude/scripts/queryplan/qp_pipeline.py regenerate \
      --cone-config claude-setupv2/.claude/scripts/queryplan/config/cones/NCBE-661.json \
      --evidence-root <STAGING_EVIDENCIA> \
      --children       <STAGING_EVIDENCIA>/children_inventory.json \
      --exec-ts 2026-07-15T15:20:39Z \
      --legacy-seed git:bc0aadc \
      --output <OUT>

Resultado: 12/12 ZIP byte-identicos a HEAD; consolidado con mismos totales y zip_sha256 (mas claves
de procedencia `source_mode`/`legacy_seed`). Determinista (doble corrida identica).

## Modos de fuente tecnica

| Modo | Como se invoca | Fuente de sql/io/labels/dml | Depende de entrega historica |
|------|----------------|------------------------------|------------------------------|
| FULL_RUN | `run`/`regenerate` SIN `--legacy-seed` | evidencia viva (payloads + output normalizado) + inventario desde fuente | NO |
| MIGRATION_RECOVERY | `--legacy-seed git:<ref>` o `dir:<path>` | entrega historica via compat reader (seed explicito) + evidencia viva para E2E | SI (declarado) |

## De donde proviene cada campo (entrega actual NCBE-661)

| Campo | Fuente | Regenerable por FULL_RUN sin seed |
|-------|--------|-----------------------------------|
| qp_id, cantidad de QP | evidencia viva (engine_out/QP-NN.sql) | SI |
| tipo_dml | SQL sustantivo del payload | SI |
| sql.ejecutado (texto exacto) | payload tsql (materializado) | SI |
| base_datos | `use <db>` del payload | SI |
| io.tables / measured / max-sum | output vivo (statistics io) | SI |
| plan.labels_raw (criterio A) | output vivo (plan) | SI |
| plan.labels_normalized / label_derivations | DERIVADOS por el writer desde labels_raw | SI |
| plan.interpretaciones (Forward Scan/Positioning by key) | output vivo | SI |
| observaciones (A/B/C) + tabla | recomputadas del output vivo + arbol del plan | SI |
| ejecucion.payload/stdout/stderr sha256, exit_code, executed_at_utc | captura viva E2E | SI |
| sps_hijos (categoria/clasificacion/ocurrencias) | inventario desde fuente (qp_pipeline inventory) | SI |
| sybase (host_alias/ase_version/ase_ebf) | config del cono | SI |
| fechas | argumento `--exec-ts` + config | SI |
| **sql.legacy (SQL del SP original)** | **seed v2.0** | **NO — requiere parseo del fuente SP por-QP** |
| **origen.archivo / clase_metodo (adapter Java)** | **seed v2.0** | **NO — requiere parseo de los repos Java** |
| **fuente_literales (prosa)** | **seed v2.0** | **NO — nota descriptiva del build original** |

## Hallazgo declarado (no oculto)

FULL_RUN (sin seed) reproduce el **100% de los hechos tecnicos** (verificado: 0 diferencias en
tipo_dml + io.tables + observaciones a traves de los 103 QP contra la entrega actual). Lo que FULL_RUN
deja en `null` son campos de PROCEDENCIA descriptiva (`sql.legacy`, `origen.archivo`,
`clase_metodo`, `fuente_literales`) que en la entrega actual provinieron del seed v2.0 y cuya
regeneracion desde cero exige un extractor de fuente SP/Java aun no implementado. Estos campos son
nullables en el schema v2.1; su ausencia NO invalida el manifest ni altera ningun hecho tecnico.

Por eso la entrega actual se rotula honestamente como producida en modo MIGRATION_RECOVERY (seed
`bc0aadc`), y la reproduccion byte-identica se logra en ese mismo modo. El pipeline FUTURO no depende
de `bc0aadc`: FULL_RUN funciona de forma autonoma para los hechos tecnicos, y el enriquecimiento de
procedencia (SP/Java) es una extension acotada y opcional, no un requisito silencioso.

## Cierre operativo (extractor de fuente + gate de procedencia)

Cambios de esta iteracion:

1. **Inventario de hijos AUTONOMO** (`qp_pipeline.py inventory` / auto en run|regenerate, modulo
   `qp_source_extract.py`): descubre los SP hijos desde el fuente SP con scan de-wrap seguro (une
   solo saltos que parten un identificador, sin fusionar sentencias; protege palabras clave). Resuelve
   locales (`sp`), owner (`dbo.sp`) y cross-db (`base..sp`). Verificado: reproduce EXACTAMENTE el
   inventario auditado (36 entries / 45 call-sites / 28 unicos; 0 diff de set/clasificacion/
   ocurrencias). Ya NO se requiere `children_inventory.json` a mano (queda como override avanzado).

2. **Procedencia documental desde DOSSIER de analisis** (`analysis/<sp>/queryplan/manifest-
   queryplan.json`), no desde entregas. Cobertura real de dossier en el workspace actual: **1/12
   paquetes** (sp_debcred_empresa). Los otros 11 no tienen dossier de queryplan -> en FULL_RUN
   `sql.legacy`/`origen` quedan con estado NOT_FOUND (no se copian del seed). Verificado FULL_RUN vs
   entrega: **0 diff en io.tables / observaciones / tipo_dml / sql.ejecutado(mod-whitespace)**;
   origen.archivo poblado 19/103 (solo donde hay dossier).

3. **Tabla canonica unica de labels** (ambos modos): `labels_raw`/`interpretaciones` se derivan del
   output vivo por el mismo criterio, no del seed. Esto corrigio 65 QP donde la entrega heredaba del
   seed etiquetas operator/informativo inconsistentes por-paquete. Efecto en la entrega canonica:
   cambian SOLO campos de label (labels_raw/labels_normalized/label_derivations/interpretaciones);
   io/obs/dml/sql.ejecutado/sql.legacy/origen se PRESERVAN. FULL_RUN y MIGRATION_RECOVERY producen
   labels IDENTICOS (0 diff).

4. **Gate de procedencia**: FULL_RUN con paquetes de fuente documental sin resolver NO es
   DELIVERY_READY -> `BLOCKED_SOURCE_PROVENANCE`. La entrega canonica Banco se mantiene en
   MIGRATION_RECOVERY (procedencia auditada de los 12), regenerada solo por el pipeline con seed
   explicito y verificable (jamas edicion manual). Los ZIP de Banco no exponen seed ni rutas internas.

**Trabajo futuro para FULL_RUN 100% documental**: generar el dossier de analisis
(`analysis/<sp>/queryplan/manifest-queryplan.json`) de los 11 paquetes restantes con los agentes
constructores SP/Java. Con ese dossier presente, FULL_RUN poblaria sql.legacy/origen sin seed y seria
DELIVERY_READY por si mismo. Es un trabajo acotado y declarado, no un hueco oculto.

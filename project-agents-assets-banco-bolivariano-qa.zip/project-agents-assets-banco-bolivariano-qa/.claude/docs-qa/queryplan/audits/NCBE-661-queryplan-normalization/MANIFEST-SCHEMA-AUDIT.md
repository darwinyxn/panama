# Auditoria de variantes de esquema — manifest-queryplan.json (corpus 12 ZIP)

Fecha (UTC): 2026-07-15
Corpus: los 12 manifests publicados en `origin/main` = `945d4be`.
Alcance: read-only. NO se modifican los ZIP. Insumo para el esquema canonico v2.

## 1. Clave de la lista de QP (fragmentacion critica)

| Variante | Paquetes | Semantica |
|----------|----------|-----------|
| `queryplans` | 7 (pa_aho_pvalida_depini, pa_sat_pnotificacion, sp_eventos, sp_genera_iva_comision, sp_graba_tran_servicio, sp_grb_comision, sp_ndc_ahcc) | lista de QP |
| `query_plans` | 3 (pa_cte_pvalida_ndnc, sp_cal_impuesto, sp_cont_impuesto) | lista de QP |
| `sentencias` | 1 (sp_debcred_empresa) | lista de QP |
| `statements` | 1 (pa_aho_pvalida_ndnc) | lista de QP |
| `documento.queryplans` (anidado) | 1 (pa_aho_pvalida_depini) | metadata + QP bajo `documento` |

Riesgo: ALTO. Un lector ingenuo que solo busque `queryplans` pierde 5/12 paquetes.
Decision v2: canonico `queryplans` (top-level). El compat reader mapea las 5 variantes.

## 2. Aliases de identidad y contexto (top-level)

| Concepto canonico v2 | Variantes historicas encontradas | Riesgo |
|----------------------|-----------------------------------|--------|
| `sp_name` | `sp_name` (10), `sp` (1), (anidado `documento.sp_name`) | MEDIO |
| `sp_completo` | `sp_completo` (6), `sp_full` (3) | MEDIO |
| `microservicio` | `microservicio` (5), `microservice` (3), `micro_libreria` (1), `microservicio_libreria` (1) | MEDIO |
| `repositorio` | `repo` (3) | BAJO |
| `servidor_sybase` | `servidor_sybase` (5), `servidor` (4), `sybase_server` (2), `conexion_sybase` (1) | MEDIO |
| `ase_version` | `ase_version` (1), `sybase_version` (2) | BAJO |
| `base_datos_default` | `base_datos` (1), `database` (2), `db_default` (1), `documento.database_default` (1) | MEDIO |
| `criterio_banco_version` | `criterio_banco_version` (11) | BAJO (estable) |
| `estado_final` | `estado_final` (3), ausente en otros | MEDIO |

## 3. Fechas (mezcla de semanticas)

| Concepto v2 (`fechas.*`) | Variantes historicas | Riesgo |
|--------------------------|----------------------|--------|
| `ejecucion_sybase` | `fecha` (5), `fecha_corrida` (3), `fecha_ejecucion` (1), `fecha_utc` (1), `run_date` (1) | ALTO |
| `evidencia_original` | (no separada; mezclada con la de ejecucion) | ALTO |
| `validacion` / `regeneracion` | (no existian como campo) | — |

Riesgo: ALTO. Una sola clave `fecha` significaba cosas distintas (evidencia original vs corrida vs
validacion). v2 separa en objeto `fechas` con claves ISO-8601/UTC.

## 4. Resumen y conteos (duplicacion / fuentes multiples)

| Concepto v2 (`resumen.*`) | Variantes historicas | Riesgo |
|---------------------------|----------------------|--------|
| bloque resumen | `resumen` (6), `conteos` (5), `totals` (1) | ALTO |
| `total_qp` | `total_qp` top-level (3) + dentro de resumen/conteos | ALTO (duplicado) |
| `select/insert/update/delete` | `count_select/insert/update/delete` top-level (1 c/u) + dentro de conteos | ALTO |
| `dml_protegidos_noexec` | `count_dml_protegido_noexec` (1) + en conteos | MEDIO |
| `observaciones` | `count_observaciones` (1) + en resumen/conteos | MEDIO |
| `errores_sql` | `count_errores` (2) + en resumen/conteos | MEDIO |
| `max_logical_reads` / `max_physical_reads` | `max_logical_reads_total`/`max_physical_reads_total` top-level (1) + en resumen | MEDIO |

Riesgo: ALTO. Conteos en top-level Y en resumen/conteos/totals -> posible contradiccion. v2: `resumen`
es la UNICA fuente de verdad; el writer los deriva de los QP; el linter prohibe duplicados top-level.

## 5. SPs hijos (formas heterogeneas)

Variantes: `sps_hijos_inventariados_no_ejecutados` (2), `sps_hijos_inventariados` (1),
`sps_hijos_inventario` (1), `child_sp_inventory` (1), `child_sp_inventariado_no_ejecutado` (1),
`exec_sps_hijos_inventariados_no_ejecutados` (1), `documento.sps_hijos_no_ejecutados` (1).
Riesgo: MEDIO. v2: `sps_hijos[]` con forma uniforme (sp_completo, seccion, clasificacion,
adapter_origen, ejecutado=false, motivo_no_ejecucion).

## 6. Notas Forward Scan / worktable / hallazgos (prosa dispersa)

Variantes: `nota_forward_scan` (7), `nota_interpretacion_forward_scan` (1), `forward_scan_nota` (1),
`forward_scan_note` (1), `nota_worktable` (1), `nota_hallazgo_vm_eventos` (1), `nota_noexec` (1),
`nota_rerun` (1), `nota_exec_legacy` (1). Riesgo: BAJO (informativo). v2: la interpretacion vive en
`plan.interpretaciones` por QP y en notas de `clasificacion`; los codigos normalizados no dependen de prosa.

## 7. Campos por QP inconsistentes

Presentes en 11/11 QP: `qp_id`, `tipo_dml`, `archivo_origen`, `clase_metodo`, `fuente_literales`,
`sql_original`, `sql_ejecutado`, `output_sybase_path`, `labels_detected`, `io_tables`,
`max_logical_reads_total`, `max_physical_reads_total`, `total_logical_reads_sum`,
`total_physical_reads_sum`, `entra_a_observaciones`, `motivos_observacion`, `error_literal`,
`dml_protegido_noexec`, `criterio_banco_version`.

Presentes en solo 1 paquete (inconsistencia): `payload_sha256`, `exit_code`, `plan_present`,
`base_datos`.

Problemas semanticos:
- `sql_original` mezcla dos significados (SQL del SP legacy vs template del micro).
- `output_sybase_path` mezcla `detalle_ejecucion.qp -> bloque QP-XX`, `detalle_ejecucion.qp#QP-XX`,
  y sufijos raw colgantes en versiones previas (ya corregidos en 945d4be).
- `labels_detected` mezcla etiquetas raw del motor con anotaciones `(informativo)`.
- IO bajo noexec: `io_tables=[]` con max/sum en 0 (deberia ser null cuando `measured=false`).
- Rutas: `archivo_origen` a veces `src/main/java/...` (no ruta relativa completa desde repo).

## 8. Conclusion

El corpus valida el principio **READ MANY -> NORMALIZE -> WRITE ONE**: el lector de compatibilidad
debe mapear >30 variantes de nombre a un modelo interno unico, y el writer canonico v2 debe emitir un
solo esquema versionado (`schema_version: "2.0"`) sin aliases ni duplicados. Ninguna de estas mejoras
altera los 12 ZIP ya aprobados (solo aplican a corridas futuras).

---

## 9. Auditoria de integracion del writer (2026-07-15)

Enfoque: comprobar que el writer canonico v2 esta CONECTADO a los caminos reales, no solo aislado.

Hallazgos y correcciones:
1. **Agente desconectado del writer (corregido).** La seccion "Trazabilidad" y la Fase 4 del
   `agente-queryplan.md` aun describian el manifest con campos legacy planos (`sql_original`,
   `labels_detected`, `entra_a_observaciones`, ...), es decir instruian armar el JSON a mano. Se
   reescribieron para mandar el MODELO INTERNO al writer unico `qp_manifest.write_manifest` y validar
   con `qp_lint.py --manifest-v2`. Prohibido armar JSON a mano.
2. **Regla de payload_sha256 no documentada (corregido).** Se definio la regla exacta (bytes UTF-8 del
   bloque tsql completo INCLUYENDO wrappers de sesion, LF, trailing newline preservado, casing intacto)
   en el docstring del writer, el README y una prueba golden.

Caminos de escritura de manifest auditados:
- `qp_manifest.py` -> writer canonico v2 (UNICO para el manifest por-QP).
- `qp_regenerate.py` -> presentacion-only; reescribe el consolidado y copia el per-package SIN cambios;
  NO genera per-QP (no es un writer de contenido nuevo).
- `qp_lint.py`, tests -> lectura/validacion, no producen entregable.
- agente/skill -> ahora apuntan al writer; no arman JSON a mano.

E2E sintetico via el entrypoint real (`write_manifest`): 20/20 checks PASS (schema v2, 0 aliases,
sql separado, resumen derivado, io null bajo noexec, observaciones por codigo, anchors, determinismo,
compat -> CANONICAL_V2).

Nota: `jsonschema` no esta instalado en EC2; la validacion se hace en Python en el writer/linter y los
enums del `.schema.json` se mantienen sincronizados con el writer (verificado por prueba).

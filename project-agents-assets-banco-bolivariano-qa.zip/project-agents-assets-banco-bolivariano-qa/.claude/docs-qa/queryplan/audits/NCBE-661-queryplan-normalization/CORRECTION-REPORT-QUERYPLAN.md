# Reporte de Correccion — Query Plan NCBE-661 (12 librerias)

Estado del frente: `QUERYPLAN_DELIVERY_COMMITTED_NORMALIZED_CLEAN` en presentacion, pero
**`BLOCKED_REQUIRES_SYBASE_RERUN`** por SQL ejecutado incompleto (ver `AUDIT-COMPLETE-SQL-DELIVERY.md`):
la normalizacion de presentacion es correcta, pero una auditoria posterior de completitud de SQL
detecto 7 QP con `sql_ejecutado` abreviado (sp_cont_impuesto QP-08..13, sp_graba_tran_servicio QP-02)
que requieren reejecucion en Sybase. Esta entrega NO es apta para reenvio hasta el rerun delta.
Fecha de regeneracion (UTC): `2026-07-14T00:00:00Z`
Criterio tecnico de rendimiento: `2026-07-09-statistics-io` (SIN CAMBIOS)
Criterio de presentacion (nuevo): `queryplan-rendering-normalized-v1`
Entrega canonica: `docs-qa/queryplan/entregas/NCBE-661-queryplan-2026-07-09-statistics-io/`
Evidencia raw historica (no versionada): commit `d52f7487fbab7926f67d7a0a4cddcd013899a0bb`

## 1. Feedback recibido

"Se encuentra imprimiendo errores en el QP, por favor solicitar ajuste y que vuelvan a enviar para
revision." La captura mostraba lineas `Msg NNNN (severity 10, state N) from SYBASE02` con payloads
como `Changed client character set setting`, `Total writes for this command: 0`, `QUERY PLAN FOR
STATEMENT 1`.

## 2. Causa raiz

- **Componente:** agente `agente-queryplan` + skill `query-plan` (contrato "capturar el output
  literal completo del motor. No resumir ni parafrasear").
- **Comportamiento defectuoso:** se escribia en el ZIP entregable el stdout CRUDO del cliente `tsql`
  (FreeTDS), que envuelve cada linea util del motor en un encabezado de transporte
  `Msg N (severity S, state T) from SERVIDOR:` con el payload entre comillas, mas ruido de cliente
  (login packet, charset, locale, prompts `N>`) y planes auxiliares de comandos de control
  (`SET OPTION OFF/ON`, `SET STATISTICS ON/OFF`, `PRINT`) generados por `set noexec off` y por los
  `set` del bloque.
- **Por que paso los controles:** el manifest calculaba `count_errores` desde severidad >= 11 /
  `error_literal` (correcto: 0 errores reales), pero ninguna regla validaba la PRESENTACION. La
  instruccion "output literal completo" empujaba justamente a conservar el envoltorio crudo.
- **Aclaracion clave:** severity 10 en Sybase ASE es INFORMATIVO, no error. No habia ni hay errores
  SQL reales (0 mensajes severity >= 11 en los 12 paquetes). El defecto era de calidad/presentacion.

## 3. Que se corrigio

1. **Contrato del agente/skill** — se distingue explicitamente:
   - RAW interno (`engine_out/*.out` en corridas nuevas; evidencia historica en el commit d52f748 para
     esta entrega): stdout crudo completo, NO entregable.
   - Entregable Banco: contenido UTIL desenvuelto y legible.
   Se prohibe en el entregable el envoltorio `Msg ... severity 0-10`, ruido de cliente, prompts,
   comillas de transporte y planes auxiliares de control. Los errores severity >= 11 NUNCA se ocultan.
2. **Normalizador determinista** `scripts/queryplan/qp_normalize.py` — desenvuelve sev 0-10, elimina
   ruido, poda planes de control, conserva sev >= 11, idempotente (parsing por bloques, no regex global).
3. **Linter/gate** `scripts/queryplan/qp_lint.py` — falla si detecta transporte/ruido/planes de
   control/manifest o checksum inconsistentes; reporta por paquete.
4. **Pruebas** `scripts/queryplan/tests/test_qp_normalize.py` — 16 casos (unwrap, ruido, sev>=11,
   poda SET OPTION OFF conservando UPDATE, salida limpia intacta, indentacion, idempotencia).
5. **Regenerador** `scripts/queryplan/qp_regenerate.py` — snapshot RAW -> normaliza .qp -> re-zip
   determinista -> actualiza manifest consolidado (hashes, bytes, version de presentacion).
6. **Entrega canonica** — 12 ZIP normalizados con nombres sin prefijo numerico, README y manifest
   consolidado actualizados; entrega superseded y pilotos eliminados del arbol vigente.

## 4. Que NO se cambio

- Criterio de rendimiento `2026-07-09-statistics-io` (umbrales A/B/C, Forward Scan informativo).
- Los planes de ejecucion, el IO, `Total writes`, resultados funcionales ni las observaciones.
- El conteo de QP por paquete ni el hallazgo de rendimiento de `sp_eventos`.
- Java de negocio, matrices de equivalencia, QMetry, Jira, Confluence, Sybase, datos.

## 5. Evidencia reutilizada / NO reejecucion de Sybase

No existia `engine_out/` previo; la unica evidencia era el contenido de los `.qp` dentro de los ZIP,
recuperable de forma inmutable desde el commit historico `d52f7487fbab7926f67d7a0a4cddcd013899a0bb`.
Se uso ese contenido como fuente, verificando byte-a-byte que cada `.qp` entregado es exactamente
`normalize(raw)`. **No se reejecuto Sybase, no se ejecutaron consultas, no se toco ningun dato.** La
normalizacion es una transformacion de texto determinista. La carpeta de trabajo `raw-evidence/` NO
se versiona: su fuente canonica es el commit d52f748.

## 6. Correccion de conteo (hallazgo colateral, honesto)

La linea de prosa del README anterior (ya presente en el commit historico d52f748) decia
"100 QP en total; 24 observaciones (23 ... + 2 ...)". Era un error de prosa PREEXISTENTE, independiente
del formato:
- El total real es **103 QP** (suma de la tabla por libreria y de los 12 manifests individuales;
  19+3+2+2+5+13+35+12+8+2+0+2 = 103). En el propio commit historico d52f748 la tabla y el consolidado
  ya sumaban 103. La normalizacion preservo el conteo (historico = raw = actual = 103).
- Observaciones: **24** reales; el desglose correcto es **22 por etiqueta del plan** + **2 por IO real
  sobre umbral** (en `sp_eventos`). El "23+2=25" anterior no sumaba 24.
Se corrigio la prosa del README para coincidir con la verdad verificable. NO se invento nada para
"cuadrar" a 100.

## 7. Evidencia DML protegida (conteo verificado)

Metrica primaria: la entrega contiene **26 QP con sentencias INSERT/UPDATE/DELETE** (campo `tipo_dml`
de los manifests individuales). **Los 26 estan protegidos con `set noexec on`**
(`dml_protegido_noexec=true`); **no se detecto DML inseguro** (0 sin proteccion).

Distribucion por paquete (QP DML): sp_debcred_empresa 2, pa_aho_pvalida_depini 1, pa_aho_pvalida_ndnc
1, pa_cte_pvalida_ndnc 1, sp_cont_impuesto 6, sp_eventos 10, sp_genera_iva_comision 4,
sp_graba_tran_servicio 1 (total 26). El resto de paquetes (sp_cal_impuesto, pa_sat_pnotificacion,
sp_ndc_ahcc, sp_grb_comision) no tienen DML. El conteo de ocurrencias `set noexec on` es identico
entre el estado historico y el normalizado en los 12 paquetes.

> Nota sobre metricas: la cifra primaria es **26 QP DML** (contados por `tipo_dml` en los manifests,
> confirmados por bloque en `detalle_ejecucion.qp`). Reportes previos citaron "18" y "19" por
> conteos incompletos que omitian paquetes con esquema de manifest distinto (p.ej. sp_eventos, que
> usa `query_plans` en vez de `queryplans`); la cifra verificada y reconciliada es 26. Lo esencial
> (0 DML sin proteccion) se mantiene en todas las versiones.

## 8. IO de sp_eventos (metricas verificadas)

Los valores de IO NO cambiaron con la normalizacion (lineas `Table: ... logical reads ... physical
reads` byte-identicas historico vs actual). Los maximos del paquete provienen de QP distintos:

| QP | tabla | logical_total | physical_total |
|----|-------|---------------|----------------|
| QP-18 | cob_internet..vm_eventos (a) | 183820 | 21930 |
| QP-19 | cob_internet..vm_eventos (a) | 186971 | 56 |

- **Maximo logico del paquete: `186971`, proveniente de QP-19.**
- **Maximo fisico del paquete: `21930`, proveniente de QP-18.**
- Los maximos logico y fisico provienen de sentencias distintas; por eso el manifest consolidado
  reporta `max_logical_total=186971` y `max_physical_total=21930` juntos. Ambos son candidatos reales
  a revision de indice (`Table Scan` + `Using Worktable` sobre `vm_eventos`).

> Nota: una version previa de este reporte cito solo "logical 183820" (correcto para QP-18) sin
> mencionar el maximo `186971` de QP-19. Se corrige aqui. No se modifico ningun manifest ni IO tecnico.

## 9. Matriz antes / despues (12 paquetes)

| Paquete | QP | Msg sev10 (antes→desp) | planes control (antes→desp) | ruido cliente (antes→desp) | sev>=11 | estado |
|---------|----|------------------------|------------------------------|-----------------------------|---------|--------|
| sp_debcred_empresa | 19 | 865 → 0 | 2 → 0 | 112 → 0 | 0 | PASS |
| pa_aho_pvalida_depini | 3 | 0 → 0 | 1 → 0 | 0 → 0 | 0 | PASS |
| pa_aho_pvalida_ndnc | 2 | 0 → 0 | 1 → 0 | 0 → 0 | 0 | PASS |
| pa_cte_pvalida_ndnc | 2 | 0 → 0 | 1 → 0 | 0 → 0 | 0 | PASS |
| sp_cal_impuesto | 5 | 269 → 0 | 10 → 0 | 25 → 0 | 0 | PASS |
| sp_cont_impuesto | 13 | 461 → 0 | 6 → 0 | 72 → 0 | 0 | PASS |
| sp_eventos | 35 | 0 → 0 | 78 → 0 | 0 → 0 | 0 | PASS |
| sp_genera_iva_comision | 12 | 512 → 0 | 4 → 0 | 56 → 0 | 0 | PASS |
| pa_sat_pnotificacion | 8 | 0 → 0 | 0 → 0 | 0 → 0 | 0 | PASS |
| sp_graba_tran_servicio | 2 | 0 → 0 | 1 → 0 | 0 → 0 | 0 | PASS |
| sp_ndc_ahcc | 0 | 0 → 0 | 0 → 0 | 0 → 0 | 0 | PASS (orquestador puro) |
| sp_grb_comision | 2 | 0 → 0 | 0 → 0 | 0 → 0 | 0 | PASS |
| **TOTAL** | **103** | **2107 → 0** | **104 → 0** | **265 → 0** | **0** | 12/12 PASS |

## 10. ZIP — SHA-256 nuevo / tamano (nombres sin prefijo)

| ZIP | SHA-256 (nuevo) | bytes |
|-----|-----------------|-------|
| sp_debcred_empresa-queryplan.zip | ded74a64addf4a73aa2bec79f92cf3f8d402ade35953737edfd5c3cd88e738b6 | 13637 |
| pa_aho_pvalida_depini-queryplan.zip | 888769e49af4d5bb04bc642a5baf0e9b8ab7d5b73e4900c9310891058e4ebaf4 | 6058 |
| pa_aho_pvalida_ndnc-queryplan.zip | 9e9a2cff5dd56d8b72ae2df4305b9e867824aab71437424e012d4daf0740ee3f | 4904 |
| pa_cte_pvalida_ndnc-queryplan.zip | 1a87871a5b0aa444c6f3d90f137bfd54b579c2fe72edb3279cef52719ba47cb7 | 5200 |
| sp_cal_impuesto-queryplan.zip | cc5c2f60225c04e38cfff5bd49da0932b1faa109806d252e1a6c98f0083b154c | 4438 |
| sp_cont_impuesto-queryplan.zip | b15fae412b8330b5e356058a1ed7f1e36e343043e73abad7107dea2410a3a974 | 7170 |
| sp_eventos-queryplan.zip | 535903eaee238f5ed2b243d228ccd03a7ca2a2ab72417a8a28aaa5e1e087c036 | 13298 |
| sp_genera_iva_comision-queryplan.zip | 9e0047770c6f695a84562aebff9b509b238a0585495f285b8af754af4197ad0f | 9452 |
| pa_sat_pnotificacion-queryplan.zip | 6acea5ab309ac503114e6d69bfb5b842cd00505f89fb5ee1b6d49549675d58ae | 8388 |
| sp_graba_tran_servicio-queryplan.zip | 528fb115c6dc7846450ef952121dacd482dd9cc956d0e04618ac70ed1288c93a | 6180 |
| sp_ndc_ahcc-queryplan.zip | 5cb39e9399c1b3d629dcda60a0999b4f8fa203e2a15911d8c239600963e03e7e | 4648 |
| sp_grb_comision-queryplan.zip | 75418466177df75f74f238293df720769c1d852477000042492b202ff7d428d6 | 4565 |

## 11. Gates (todos verdes en el worktree limpio)

12 ZIP presentes; estructura 3 miembros/ZIP; 103 QP; 24 observaciones; 0 severity>=11; 0 envoltorios
`Msg severity 10`; 0 planes auxiliares; 0 ruido de cliente; 0 nombres con prefijo numerico; una sola
entrega canonica; sin pilotos; sin entregas superseded; sin `raw-evidence/` ni reportes internos
dentro de `entregas/`; linter 12/12 PASS; 16 pruebas PASS; hashes/bytes consistentes; equivalencia
semantica 12/12.

## 12. Resultado final

12/12 paquetes PASS. Entrega canonica normalizada, homogenea y con nombres limpios. Commit aislado
en rama `fix/queryplan-ncbe-661-normalized-delivery` desde `origin/main`. NO se hizo push, NO se
propago a repos SP, NO se reenvio a Banco ni se publico en Confluence — todo requiere accion posterior
explicita.

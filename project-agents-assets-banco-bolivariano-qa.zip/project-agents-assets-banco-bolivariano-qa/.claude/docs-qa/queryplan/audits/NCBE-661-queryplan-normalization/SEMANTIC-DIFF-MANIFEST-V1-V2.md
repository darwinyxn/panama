# Diff semantico v1 -> v2 — regeneracion NCBE-661 (manifest canonico)

Fecha (UTC): 2026-07-15
Base: `origin/main = edc27788f38c6898df8f1c3a2485de7a2140c2be`
Entrega v1 comparada: commit tecnico `945d4be` (12 ZIP publicados).
Operacion: `REGENERATION_FROM_EXISTING_EVIDENCE` (compat reader -> writer canonico v2). NO se reejecuto Sybase.

## Resultado

**0 diferencias tecnicas inesperadas.** 103/103 QP equivalentes; 24/24 observaciones preservadas;
26/26 DML protegidos; 0 errores SQL.

| Paquete | QP v1/v2 | DML v1/v2 | obs v1/v2 | sql_ejecutado | detalle.qp | observaciones.qp |
|---------|----------|-----------|-----------|---------------|------------|------------------|
| sp_debcred_empresa | 19/19 | 2/2 | 6/6 | identico | byte-identico | byte-identico |
| pa_aho_pvalida_depini | 3/3 | 1/1 | 0/0 | identico | byte-identico | byte-identico |
| pa_aho_pvalida_ndnc | 2/2 | 1/1 | 0/0 | identico | byte-identico | byte-identico |
| pa_cte_pvalida_ndnc | 2/2 | 1/1 | 0/0 | identico | byte-identico | byte-identico |
| sp_cal_impuesto | 5/5 | 0/0 | 0/0 | identico | byte-identico | byte-identico |
| sp_cont_impuesto | 13/13 | 6/6 | 0/0 | identico | byte-identico | byte-identico |
| sp_eventos | 35/35 | 10/10 | 9/9 | identico | byte-identico | byte-identico |
| sp_genera_iva_comision | 12/12 | 4/4 | 5/5 | identico | byte-identico | byte-identico |
| pa_sat_pnotificacion | 8/8 | 0/0 | 3/3 | identico | byte-identico | byte-identico |
| sp_graba_tran_servicio | 2/2 | 1/1 | 1/1 | identico | byte-identico | byte-identico |
| sp_ndc_ahcc | 0/0 | 0/0 | 0/0 | n/a | byte-identico | byte-identico |
| sp_grb_comision | 2/2 | 0/0 | 0/0 | identico | byte-identico | byte-identico |
| **TOTAL** | **103/103** | **26/26** | **24/24** | identico | identico | identico |

## Cambios PERMITIDOS aplicados (solo el manifest-queryplan.json por paquete)

- `schema_version: "2.0"`; estructura canonica; un nombre por concepto (0 aliases legacy).
- `resumen` derivado por el writer (unica fuente de conteos; sin duplicados top-level).
- `fechas` separadas: `evidencia_original=2026-07-10`, `ejecucion_sybase` (null en orquestador puro),
  `validacion`/`regeneracion=2026-07-15T06:00:00Z`.
- `sql` separado en `legacy`/`template_micro`/`ejecutado` (ejecutado identico al v1).
- `plan`: `labels_raw` (literal, sin `(informativo)`), `labels_normalized` (codigos), `interpretaciones`.
- `io.measured` explicito: SELECT=true; DML bajo noexec=false con maximos/sumas null (antes 0 ambiguo).
- `observaciones` codificadas (`A_TABLE_SCAN`, `A_USING_WORKTABLE`, `B_LOGICAL_READS_GT_10000`, ...).
- Rutas relativas al repo; `.../` de `sp_eventos` resuelto EXACTO al package real del Java del micro
  (`bb-core-cob-internet-utils/sp-eventos-utils/...`), sin inferencia.
- `output_path=detalle_ejecucion.qp#QP-NN`, `observacion_path=observaciones.qp#QP-NN` (o null).
- `payload_sha256` EXACTO recalculado desde los payloads `.sql` supervivientes de la corrida viva
  2026-07-15 (103/103); regla publicada (bytes UTF-8 del bloque tsql completo, LF, trailing newline).

## Metadata E2E: recuperada vs null justificado

| Campo | Estado | Justificacion |
|-------|--------|---------------|
| `payload_sha256` | EXACT (103/103) | recomputado del `.sql` exacto enviado (staging corrida viva) |
| `executed_at_utc` | null | no hay timestamp por-QP comprobable en la evidencia; no se inventa |
| `stdout_sha256` / `stderr_sha256` | null | streams por-QP no conservados uniformemente; no se reconstruyen |
| `exit_code` | null | no conservado uniformemente por-QP; no se infiere |
| `noexec.aplica/protegido` | EXACT | derivado de `dml_protegido_noexec` del v1 |
| IO (measured/tables/max/sum) | EXACT | del v1 (measured), null bajo noexec |

Los campos null son NULLABLES en el schema v2 (no obligatorios-no-null); por eso la regeneracion NO se
bloquea. Ningun campo tecnico se invento.

## Cambios PROHIBIDOS: ninguno

Cantidad de QP, tipo de sentencia, SQL ejecutado, plan sustantivo, IO medido, observaciones aplicables,
conteos, SP hijos, hallazgo de rendimiento de sp_eventos y criterios Banco: TODOS preservados.

## Determinismo

Regeneracion doble desde las mismas entradas -> 0 diferencias (manifests, detalle, observaciones y ZIP
byte-identicos). Timestamps de validacion/regeneracion fijados una vez por corrida.

# Reporte de compatibilidad y brechas — pipeline v2.1 (NCBE-661)

Fecha (UTC): 2026-07-15
Alcance: dry-run READ-ONLY del compat reader v2.1 + linter sobre las dos entregas historicas del cono
(12 paquetes cada una): v1-LEGACY (commit `945d4be`) y v2.0-PUBLISHED (commit `bc0aadc`).
Ninguna entrega fue modificada. Objetivo: demostrar que el pipeline v2.1 (a) lee ambas sin perder
informacion recuperable, (b) clasifica correctamente, y (c) mide la brecha real hacia una entrega
canonica v2.1.

## Resultado del barrido

### v1-LEGACY (945d4be) — 12 paquetes

| Paquete | Clasificacion | QP | sps_hijos recuperados |
|---------|---------------|----|-----------------------|
| pa_aho_pvalida_depini | LEGACY_NORMALIZED_COMPLETE | 3 | 0 |
| pa_aho_pvalida_ndnc | LEGACY_NORMALIZED_COMPLETE | 2 | 2 |
| pa_cte_pvalida_ndnc | LEGACY_NORMALIZED_COMPLETE | 2 | 0 |
| pa_sat_pnotificacion | LEGACY_NORMALIZED_COMPLETE | 8 | 0 |
| sp_cal_impuesto | LEGACY_NORMALIZED_COMPLETE | 5 | 0 |
| sp_cont_impuesto | LEGACY_NORMALIZED_COMPLETE | 13 | 3 |
| sp_debcred_empresa | LEGACY_NORMALIZED_COMPLETE | 19 | 0 |
| sp_eventos | LEGACY_NORMALIZED_COMPLETE | 35 | 0 |
| sp_genera_iva_comision | LEGACY_NORMALIZED_COMPLETE | 12 | 0 |
| sp_graba_tran_servicio | LEGACY_NORMALIZED_COMPLETE | 2 | 0 |
| sp_grb_comision | LEGACY_NORMALIZED_COMPLETE | 2 | 0 |
| sp_ndc_ahcc | LEGACY_NORMALIZED_COMPLETE | 0 | 3 |
| **TOTAL** | | **103** | **8** |

### v2.0-PUBLISHED (bc0aadc) — 12 paquetes

| Metrica | v1-LEGACY | v2.0-PUBLISHED | Delta |
|---------|-----------|----------------|-------|
| Paquetes | 12 | 12 | 0 |
| QP totales | 103 | 103 | 0 |
| sps_hijos totales | 8 | **0** | **-8 (D1)** |
| Clasificacion | LEGACY_NORMALIZED_COMPLETE (12/12) | DEPRECATED_V2_0 (12/12) | — |

Todos los v2.0 se clasifican `DEPRECATED_V2_0` y el gate `lint_manifest_v2` los rechaza
(schema_version 2.0 = NOT_FOR_DELIVERY). sp_ndc_ahcc v2.0 dispara ademas gap D1/D2 (ORQUESTADOR_PURO
con sps_hijos=[]).

## Hallazgo central

**La regeneracion v2.0 PERDIO informacion que SI estaba en v1.** El compat reader v2.1 recupera 8 SP
hijos desde los manifests v1 (2 en pa_aho_pvalida_ndnc, 3 en sp_cont_impuesto, 3 en sp_ndc_ahcc) que
la publicacion v2.0 habia borrado a `[]`. Esto es la evidencia cuantitativa del defecto D1.

## Baseline de inventario confirmado

- **12 paquetes**, **103 QP** en AMBAS entregas historicas -> baseline 103 QP CONFIRMADO, no forzado.
- 24 observaciones / 26 DML protegidos: heredados del contenido tecnico (detalle/observaciones), no
  recomputados en este dry-run (se recomputan en la corrida viva v2.1).

## Brecha hacia v2.1 canonico (que exige la corrida viva + inventario desde fuente)

El compat reader recupera lo RECUPERABLE del historico, pero v2.1 canonico exige MAS de lo que el
historico contiene. Brechas que NO se cierran leyendo historico y requieren fuente/rerun:

1. **sps_hijos canonico (D1/D2)**: v1 solo tenia 8 hijos parciales; el inventario canonico debe salir
   del CODIGO FUENTE de cada SP (p.ej. sp_ndc_ahcc tiene 3 `exec` reales; otros SP pueden tener hijos
   no inventariados en v1). Fase 9 construye este inventario y se DETIENE si hay delta no explicable.
2. **SQL por procedencia (D3/D4)**: separar legacy (SP) / template_micro (adapter, con `?`) / ejecutado
   (materializado) exige leer el fuente del SP y el adapter Java. El compat reubica `?` de legacy a
   template como mitigacion, pero el `legacy` real del SP debe extraerse del fuente.
3. **Fechas con evidencia (D5)**: executed_at_utc real por-QP exige capturarlo en la corrida viva
   (el historico no lo tiene -> v2.0 lo invento).
4. **E2E (stdout/stderr/exit) (parcial)**: el staging previo solo conservo payload .sql+.sha256; la
   corrida viva v2.1 debe capturar stdout/stderr/exit por-QP.
5. **libraries_status (D9)**: clasificar contra CallLibrary/CallExistLibrary reales de cada hijo.
6. **observaciones.tabla (D8)**: extraer la tabla del IO/plan (el historico la dejaba en prosa).

## Conclusion

- El pipeline v2.1 LEE ambas entregas historicas sin fallo y sin perder lo recuperable.
- El gate rechaza v2.0 (NOT_FOR_DELIVERY) — comportamiento correcto.
- El baseline 103 QP / 12 paquetes esta confirmado desde dos fuentes independientes (v1 y v2.0).
- Las brechas 1-6 confirman que una entrega v2.1 canonica NO puede derivarse del historico: requiere
  inventario desde codigo fuente (Fase 9) + corrida viva nueva con captura E2E (Fase 11).

# Auditoria de alcance: Query Plan = llamadas reales a BD de la libreria Java (NCBE-661)

Fecha (UTC): 2026-07-15
Criterio Banco version: 2026-07-15-java-db-call-scope

## Comentario de Jira (origen del criterio)

> "No deberia venir en queryplan sentencias DML que no van a tablas, ya que estas sentencias DML
> particulares solo deberian existir en el SP para hacer asignaciones a variables y calculos, en la
> libreria que es Java no son necesarios porque el lenguaje lo permite; por tanto, como no estan en el
> codigo Java de la libreria, estas sentencias DML no deberian venir en queryplan."

Aclaracion (Kenneth): el problema concreto son SELECT de Sybase usados para operaciones matematicas o
asignaciones que no deberian aparecer en Query Plan.

## Metodologia

READ-ONLY sobre la entrega vigente + codigo Java real de las librerias. Regla: un candidato QP SIN
TABLAS se decide por EVIDENCIA de ejecucion contra BD en Java, NO por regex de SQL. La senal es la
PROCEDENCIA declarada del QP (`origen.archivo`) resuelta al fuente Java real, y sobre ese fuente la
presencia de una **llamada de ejecucion JDBC** (`jdbcTemplate.query/update/queryForObject/...`,
`Statement.executeQuery/execute`, `PreparedStatement`, `Connection.prepareStatement/prepareCall`,
`createStatement`). La ubicacion del archivo bajo `infrastructure/outbound/` NO es criterio suficiente
por si sola: el clasificador ABRE y LEE el codigo citado y exige la evidencia de ejecucion. Si el
origen es el SP legacy (`<base>__<sp>.sql`) y la libreria Java lo resuelve en memoria (asignacion/
constante/aritmetica) -> EXCLUIR. Si la procedencia Java no se puede resolver/leer, o esta bajo Java
pero SIN llamada de ejecucion JDBC -> `REVIEW_UNRESOLVED_JAVA` (BLOQUEA la corrida; no se excluye ni se
incluye en silencio). SQL externalizado en archivo de configuracion ejecutado por un adapter -> INCLUIR.

## Universo: QP sin acceso a tablas

De los 103 QP, `measured_reason` distribuye: 70 MEASURED (tabla real) + 26 NOEXEC (DML a tabla real
bajo `set noexec on/off`) + **7 NO_TABLE_IO**. Solo los 7 NO_TABLE_IO son candidatos. Ningun QP con
tabla se ve afectado.

### Los 7 candidatos NO_TABLE_IO

| Paquete | QP | SQL | origen.archivo | Evidencia Java | Decision |
|---------|----|-----|----------------|----------------|----------|
| sp_cal_impuesto | QP-01 | `declare @w_sp_nombre; select @w_sp_nombre='sp_cal_impuesto'` | `cob_cuentas__sp_cal_impuesto.sql` (SP) | constante `ErroresCalculoImpuesto.wSpNombre` | EXCLUDE |
| sp_cal_impuesto | QP-02 | `select @o_impuesto = round(base*tasa,2)` | SP | `SpCalImpuestoLibrary` (PURO, `Math.round`, sin JDBC) | EXCLUDE |
| sp_cal_impuesto | QP-03 | `select @o_base_imp = @i_base_imp` | SP | asignacion en memoria | EXCLUDE |
| sp_cal_impuesto | QP-04 | `select @o_base_imp = round(valor/(1+tasa),2)` | SP | `dividir()` Java, sin JDBC | EXCLUDE |
| sp_cal_impuesto | QP-05 | `select @o_impuesto = round(valor-base,2)` | SP | resta Java, sin JDBC | EXCLUDE |
| sp_eventos | QP-25 | `SELECT @@IDENTITY` | `src/main/java/.../outbound/data/EventosDataAdapter.java` | `jdbcTemplate.queryForObject("SELECT @@IDENTITY", Long.class)` (L79) | **INCLUDE** |
| sp_grb_comision | QP-02 | `select 1 - sign(@@trancount)` | `src/main/java/.../outbound/legacy/JdbcTransaccionScopeAdapter.java` | `st.executeQuery("select 1 - sign(@@trancount)")` (L80) | **INCLUDE** |

## Evidencia Java (verificada en codigo real, no en manifest)

- `SpCalImpuestoLibrary.java`: documenta `ARQ-011: el nucleo de logica es PURO (sin Spring/JDBC)`;
  0 imports de jdbc/SQL/DataSource/Repository; usa `Math.round`, division `/`, resta Java. Las 5
  sentencias son aritmetica de variables del SP legacy resuelta en memoria.
- `EventosDataAdapter.insertEventoLog` (L79): ejecuta `SELECT @@IDENTITY` via `JdbcTemplate` tras el
  INSERT para recuperar el `el_secuencial` generado. Round-trip real.
- `JdbcTransaccionScopeAdapter` (L80): ejecuta `select 1 - sign(@@trancount)` via `Statement` para
  decidir el scope transaccional. Round-trip real.

## Impacto

- **103 -> 98 QP** (−5 de sp_cal_impuesto).
- sp_cal_impuesto: 5 -> **0 QP** (libreria de calculo escalar; sin llamadas a BD en Java).
- Observaciones QP: 24 -> **24** (los 5 excluidos tenian 0 observaciones).
- DML noexec: 26 (sin cambio). Errores: 0. Hijos: 36 entries / 45 call-sites / 28 unicos (sin cambio).
- sp_eventos QP-25 y sp_grb_comision QP-02: **CONSERVADOS**.

## Causa raiz

El inventario de QP se materializo desde la evidencia viva (`engine_out/QP-NN.sql`), payloads
derivados del **SP legacy**, no de las llamadas JDBC reales de la libreria Java. Para una libreria de
calculo escalar (sp_cal_impuesto) esa evidencia son `select @var = <math>` que nunca tocan BD. Faltaba
un criterio que, para QP sin tabla, exigiera evidencia de ejecucion contra BD en la libreria Java
(llamada JDBC verificada en el codigo) y excluyera la logica resuelta en memoria.

## Correccion implementada (clasificador por evidencia)

`qp_source_extract.classify_qp_scope` decide el alcance de cada QP sin tabla LEYENDO el fuente Java
citado por `origen.archivo` (resuelto bajo `repos_roots`) y verificando una llamada de ejecucion JDBC
real; la mera ubicacion en `infrastructure/outbound/` NO basta. Rutas de decision: INCLUDE (JDBC real),
EXCLUDE_JAVA_IN_MEMORY (origen SP legacy resuelto en memoria), REVIEW_UNRESOLVED_JAVA (procedencia Java
no resoluble o Java sin ejecucion JDBC -> BLOQUEA la corrida, no exclusion silenciosa), y SQL en config
ejecutado por adapter -> INCLUDE. El pipeline aborta con `BLOCKED_SCOPE_REVIEW_REQUIRED` si algun QP
cae en REVIEW. Pruebas genericas (sin nombres de paquete) cubren: outbound sin JDBC -> no auto-incluir;
JDBC fuera de outbound -> incluible; procedencia no resuelta -> REVIEW; SQL en config -> conservar;
`@@IDENTITY`/`@@trancount` -> permanecen.

## Alcance y limites de esta auditoria

- El impacto del criterio "DML sin tabla" queda **completamente resuelto** para los **7 QP NO_TABLE_IO**
  identificados por el comentario de Jira: se clasificaron con evidencia Java directa (5 EXCLUDE + 2
  INCLUDE), 0 ambiguos. La correccion cubre especificamente esos 7 QP, no los 98 QP de la entrega.
- Esta auditoria NO afirma haber auditado exhaustivamente los 98 QP contra Java, ni haber hecho una
  revision metodo-por-metodo de las 12 librerias Java para detectar llamadas a BD sin QP
  (MISSING_CURRENT_QP). Eso es un alcance distinto, no cubierto por el comentario de Jira, y no se
  aborda en esta correccion.

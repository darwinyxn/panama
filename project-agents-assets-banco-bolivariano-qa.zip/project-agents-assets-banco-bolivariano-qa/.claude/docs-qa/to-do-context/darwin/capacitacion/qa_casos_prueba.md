# Casos de Prueba - SP `sp_proc_giros`

**Base de datos:** `cob_giros` (Sybase) con dependencias en `cobis`, `cob_cuentas`, `cob_cuentas_his`
**Proposito:** Orquestador del ciclo de vida de un giro (remesa) en Ecuagiros: crea la cabecera de orden de pago (operacion C), valida e ingresa el giro con su remitente/beneficiario/pago (operacion D), dispara reverificacion (operacion M), delega consultas (S/A/B/P/Q/O/L) y valida repetidos para OFAC (V). Toda validacion de negocio fallida en modo batch se descarta al tacho (`cg_giros_swiftnok`).

> **Diagnostico y prevalidacion BD ejecutados en ambiente real** (2026-08-27, servidor `172.16.31.91:2050`, conexion via `DB_NAME=cob_cuentas` con acceso cross-database confirmado a `cob_giros`/`cobis`/`cob_cuentas_his`; ambiente confirmado seguro por el usuario para ejecucion real). Hallazgos clave del diagnostico:
> - El courier `'01'` (asumido en un borrador previo) **no existe** en este ambiente. Los couriers reales activos usados en este documento son `108` (`gp_valida_cu='N'`, agencia vigente `10801`, ciudad `GUAYAQUIL`=1, provincia=9) y `36` (`gp_valida_cu='S'`, agencia vigente `3601`, requiere punto de pago vigente).
> - Puntos de pago vigentes reales verificados: `BNF00601` (agente `BNF`, tope real `9000.00`), `BBO04201`, `BBO02501`, `BBO02301`, `BBO04001`.
> - Cabeceras reales abiertas (`op_estado='P'`) usadas como `@i_SecCabecera`: `12883294` (courier 108), `12883297`/`12883298` (courier 36), `12883299` (courier 108, usada para cuadre).
> - Rol de excepcion real verificado en `cg_roles_excepcion`: `179`. Rol consep real: `161`. Cupo consep real (`CUPCNE`): `10000.00`.
> - **Depuracion aplicada (2026-09-09)**: se eliminaron `TC35` (fallo tecnico interno: sentinela `sp_gen_sec` + fallo de INSERT), `TC39` (sobregiro, redundante con el incidente real de TC40/ahora TC38) y el antiguo `TC46` (recomendacion generica de robustez no ejecutada) por decision explicita del usuario. Todos los TCs se renumeraron secuencialmente.
> - **Division atomica del TC44 (2026-09-09)**: el antiguo `TC44` (combinaba en un solo caso transferencia en blanco/vacia/solo-ceros, numero de identificacion nulo/invalido, cuenta origen nula/vacia/'0', agencia no coincidente, punto de pago no vigente y nombres de beneficiario incompletos) se dividio en subcasos atomicos ejecutados realmente. Se eliminaron `TC44d/e/f/g/h/k` por quedar bloqueados por un defecto real de infraestructura no relacionado con el campo bajo prueba (ver bullet siguiente); quedan `TC44a`, `TC44b`, `TC44c`, `TC44d`, `TC44e`, todos con PRE/POST y `fuente_valor: analisis (ejecutado real)` (no quedan `supuesto_controlado`). Total final: **44 casos principales (TC01-TC44)**.
> - **HALLAZGO REAL (regresion, 2026-09-09, no incluido como TC activo)**: al ejecutar la ruta `cta_origen` nulo/vacio/'0' + `nombrebcompleto=2` (→ `sp_verificacion_automatica`), se reprodujo de forma consistente el error real `Attempt to insert NULL value into column 'ts_secuencial', table 'cobis.dbo.cl_tran_servicio'`. Se confirmo reproduciendo el escenario **exacto** de `TC27` (exitoso el 2026-08-27): fallo identico hoy. Esto indica una regresion real del ambiente o de `sp_verificacion_automatica` entre 2026-08-27 y 2026-09-09. Los subcasos que dependian de esta ruta (`TC44d/e/f/g/h/k`) se removieron del entregable por decision explicita del usuario al no aportar cobertura diferenciada mientras persista el defecto.
> - **44 de 44 TCs quedan ejecutados/verificados de forma real** contra `sp_proc_giros` usando el entorno `.venv` + `config/coneccion.py` (incluye los subcasos `TC44a`, `TC44b`, `TC44c`, `TC44d`, `TC44e`, todos con validacion especifica exitosa). Los scripts temporales de diagnostico y ejecucion fueron eliminados inmediatamente despues de capturar cada resultado.
> - **INCIDENTE REAL DETECTADO Y CORREGIDO (2026-08-28, TC38)**: al intentar fijar `v_sobregiro=0` para courier `108` mediante mutacion temporal de `gr_acreedora`, el incremento concurrente de `gr_ingresados` (+100.00, generado por el propio giro de la prueba) desplazo el sobregiro real a negativo, disparando el bloqueo automatico real del courier `108` (`MORE MONEY TRANSFER S.A.`) via `sp_bloqueo_carga`/`sp_mod_alerta_cour` (`cg_courier.co_bloqueado='1'`). Se detecto y revirtio de inmediato (`co_bloqueado='0'`, `co_envio_mail='N'`, `co_fecha_blq=NULL`, `gr_acreedora` restaurado), confirmado con SELECT posterior. Ver detalle completo en TC38.
> - **Nota historica (defecto no reproducible)**: TC41 (`@i_operacion='M'`) habia generado en una corrida anterior (2026-08-27) el error `Implicit conversion from datatype 'BIGINT' to 'VARCHAR' is not allowed` al invocar `sp_verificacion_automatica`; al re-verificar el 2026-09-04 con los mismos giros (`2260088114`/`2260088109`) el error **no se reprodujo** (`RETURN 0` limpio en ambos). Se deja documentado como nota historica, no como hallazgo activo.

---

---

---

## CONFIG

| Parametro | Valor |
|-----------|-------|
| sp_name | sp_proc_giros |
| microservice | — |
| environment | — |
| base_url | — |
| endpoint | — |
| grpc_host | — |
| grpc_proto_path | — |
| grpc_proto_file | — |
| grpc_service_method | — |

---

---

## CONVENCIONES

| Marcador | Significado |
|---|---|
| PRE | Estado/dato que debe existir en BD antes de ejecutar el SP |
| POST | Validacion de BD despues de ejecutar el SP (valores reales observados) |
| ERROR | Excepcion real capturada desde `sp_cerror`/`raiserror` (Sybase la propaga como `SQLException` via JDBC) |
| Ruta CABECERA (operacion `'C'`) | Crea la orden de pago (`cg_orden_pago`) y devuelve `@o_SecCabecera`. Se activa con `@i_operacion='C'` |
| Ruta INGRESO (operacion `'D'`) | Valida y da de alta remitente, beneficiario, giro (`cg_giro`) y pago (`cg_pago`). Se activa con `@i_operacion='D'` |
| Ruta TACHO (goto swiftnok) | Descarte a `cg_giros_swiftnok`; usado en modo batch (`@i_tipo=null`) ante fallas de validacion o tecnicas |
| Ruta MODIFICACION (operacion `'M'`) | Redispara `sp_verificacion_automatica` sobre un giro existente. Se activa con `@i_operacion='M'` |
| Ruta CONSULTA (operaciones `'S','A','B','P','Q','O','L'`) | Delega a `sp_proc_giros01`. Se activa con `@i_operacion` en ese conjunto |
| Ruta VALIDACION (operacion `'V'`) | Informa si el giro ya existe, para evitar doble llamada al web service OFAC. Se activa con `@i_operacion='V'` |
| `supuesto_controlado` | Escenario no ejecutable de forma segura contra datos reales de riesgo/produccion; requiere doble/stub |

---

---

---

## GRUPO 1 — Validacion general de transaccion (RN-01)

### TC01 — Rechazo por codigo de transaccion distinto de 3488

| Campo | Detalle |
|-------|---------|
| **@t_trn** | `9999`  -- valor distinto de 3488, fuerza rechazo (RN-01) |
| **Regla** | RN-01 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 9999, @i_operacion = 'D', @i_courier = '108',
     @i_agencia_courier = '10801', @i_transferencia = 'QA260801', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_fecha = '2026-08-27 09:00:00',
     @i_SecCabecera = 12883294, @i_tipo = 'F', @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT 1 AS sin_precondicion
-- Condicion: no requiere precondicion de datos (valida antes de acceder a cualquier tabla)
```

**POST — Validaciones en BD:**
```sql
SELECT COUNT(1) AS filas_nuevas
FROM cob_giros..cg_orden_pago
WHERE op_courier = '108' AND op_fecha_proceso >= '2026-08-27'
-- Condicion real observada: sin nuevas filas (SP aborta antes de delegar)
```

**Resultado esperado:** `RETURN 1` — `sp_cerror(num=151051)` (verificado 2026-08-27). El driver JDBC propaga la excepcion real: `[sp_proc_giros] Transaccion no permitida`.

**Trazabilidad por DB:**
- `cob_giros..cg_orden_pago` — sin insercion (confirmado)

---

## GRUPO 2 — Cabecera de orden de pago y duplicidad (RN-02, RN-03, RN-04, RN-05)

### TC02 — Alta de cabecera de orden de pago exitosa

| Campo | Detalle |
|-------|---------|
| **@i_operacion** | `'C'` |
| **@i_numregistros** | `1` |
| **@i_valorCancelar** | `100.00` |
| **Regla** | RN-02 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2), @o_SecCabecera int
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'C', @i_courier = '108', @i_tipo = 'F',
     @i_transferencia = 'QV090402', @i_numregistros = 1, @i_valorCancelar = 100.00, @s_rol = 100,
     @o_Conexion = @o_Conexion OUT, @o_SecCabecera = @o_SecCabecera OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion, @o_SecCabecera AS o_SecCabecera
```

**PRE — Estado requerido en BD:**
```sql
SELECT MAX(op_secorden) AS ultimo_secorden FROM cob_giros..cg_orden_pago
-- Baseline real antes de ejecutar: MAX(op_secorden)=12883302 (ultimo secorden ya consumido). op_secorden es un
-- secuencial monotonico compartido (sp_cseqnos); la corrida asignara el SIGUIENTE valor libre (>12883302),
-- que varia en cada re-ejecucion. NO se fija un literal.
```

**POST — Validaciones en BD:**
```sql
-- El valor a verificar es el @o_SecCabecera REAL retornado por ESTA MISMA ejecucion (output param capturado
-- arriba), NO un literal fijo. Filtrar dinamicamente por el output de esta corrida:
SELECT op_secorden, op_courier, op_estado, op_monto_carga
FROM cob_giros..cg_orden_pago
WHERE op_secorden = @o_SecCabecera
-- Condicion real observada: op_estado='P', op_monto_carga=0.00, op_courier='108'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'`, y `o_SecCabecera` = el siguiente valor de `sp_cseqnos` (`>12883302`), capturado dinamicamente del OUT param de esta misma corrida. El valor exacto varia en cada re-ejecucion por ser un secuencial monotonico compartido; NO se hardcodea. Verificacion: la fila creada es la que corresponde al `@o_SecCabecera` retornado (`op_estado='P'`).

**Trazabilidad por DB:**
- `cob_giros..cg_orden_pago` — INSERT confirmado en `op_secorden = @o_SecCabecera` (valor dinamico retornado por esta corrida, `>12883302`)

---

### TC03 — Rechazo de transferencia duplicada no anulada (cabecera)

| Campo | Detalle |
|-------|---------|
| **@i_operacion** | `'C'` |
| **@i_transferencia** | `'850450670781'`  -- giro real courier 108, `gg_estado='V'` (no anulado) |
| **Regla** | RN-03 |
| **fuente_valor** | sybase_select (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'C', @i_courier = '108', @i_tipo = 'F',
     @i_transferencia = '850450670781', @s_rol = 100,
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT gg_cod_giro, gg_estado FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = '850450670781'
-- Verificado real: fila existe con gg_estado = 'V' (no anulado)
```

**POST — Validaciones en BD:**
```sql
SELECT COUNT(1) AS filas_nuevas FROM cob_giros..cg_orden_pago WHERE op_courier = '108' AND op_fecha_proceso >= '2026-08-27' AND op_secorden > 12883302
-- Condicion real observada: sin nuevas filas
```

**Resultado esperado:** `RETURN 1` — `sp_cerror(num=999333)` (verificado 2026-08-27). Excepcion real: `No. Transf. ya existe en otro Giro`.

**Trazabilidad por DB:**
- `cob_giros..cg_orden_pago` — sin cambios (confirmado)

---

### TC04 — Rechazo de reingreso de giro anulado sin rol de excepcion (carga por archivo)

| Campo | Detalle |
|-------|---------|
| **@i_operacion** | `'C'` |
| **@i_transferencia** | `'5780801099'`  -- giro real courier 108, `gg_estado='A'` (anulado) |
| **@s_rol** | `100`  -- rol estandar |
| **@i_nom_arch** | `'ARCH001.TXT'`  -- fuerza carga por archivo |
| **Regla** | RN-03 |
| **fuente_valor** | sybase_select (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'C', @i_courier = '108', @i_tipo = 'F',
     @i_transferencia = '5780801099', @s_rol = 100, @i_nom_arch = 'ARCH001.TXT',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT gg_cod_giro, gg_estado FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = '5780801099'
-- Verificado real: fila existe con gg_estado = 'A' (anulado)
```

**POST — Validaciones en BD:**
```sql
SELECT COUNT(1) AS filas_nuevas FROM cob_giros..cg_orden_pago WHERE op_courier = '108' AND op_secorden > 12883302
-- Condicion real observada: sin nuevas filas
```

**Resultado esperado:** `RETURN 1` — `sp_cerror(num=999333)` (verificado 2026-08-27). Excepcion real: `No. Transf. ya existe en otro Giro` (el codigo rechaza directo por `@i_nom_arch is not null`, sin evaluar rol de excepcion).

**Trazabilidad por DB:**
- `cob_giros..cg_orden_pago` — sin cambios (confirmado)

---

### TC05 — Permite reingreso de giro anulado por rol con excepcion

| Campo | Detalle |
|-------|---------|
| **@i_operacion** | `'C'` |
| **@i_transferencia** | `'5780801099'` |
| **@s_rol** | `179`  -- rol real registrado en `cg_roles_excepcion` |
| **@i_nom_arch** | `null` |
| **@i_numregistros** | `1` |
| **@i_valorCancelar** | `100.00` |
| **Regla** | RN-04 |
| **fuente_valor** | sybase_select (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2), @o_SecCabecera int
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'C', @i_courier = '108', @i_tipo = 'F',
     @i_transferencia = '5780801099', @s_rol = 179, @i_nom_arch = NULL,
     @i_numregistros = 1, @i_valorCancelar = 100.00,
     @o_Conexion = @o_Conexion OUT, @o_SecCabecera = @o_SecCabecera OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion, @o_SecCabecera AS o_SecCabecera
```

**PRE — Estado requerido en BD:**
```sql
SELECT a.tabla, b.valor FROM cobis..cl_tabla a INNER JOIN cobis..cl_catalogo b ON a.codigo = b.tabla WHERE a.tabla = 'cg_roles_excepcion'
-- Verificado real: '179' registrado como valor de excepcion
```

**POST — Validaciones en BD:**
```sql
-- Filtrar por el @o_SecCabecera REAL retornado por ESTA MISMA ejecucion (output param), NO por un literal fijo:
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = @o_SecCabecera
-- Condicion real observada: op_estado='P'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'`, y `o_SecCabecera` = el siguiente valor de `sp_cseqnos` (`>12883302`), capturado dinamicamente del OUT param de esta misma corrida (NO hardcodear: el secuencial es monotonico compartido y varia en cada re-ejecucion). El reingreso del giro anulado `5780801099` por el rol de excepcion real `179` (path RN-04) sigue siendo el efecto probado y se conserva intacto; el unico ajuste es dinamizar el secuencial esperado.

**Trazabilidad por DB:**
- `cob_giros..cg_orden_pago` — INSERT confirmado en `op_secorden = @o_SecCabecera` (valor dinamico retornado por esta corrida, `>12883302`)

---

### TC06 — Courier '83' exento de validacion de transferencia duplicada

| Campo | Detalle |
|-------|---------|
| **@i_operacion** | `'C'` |
| **@i_courier** | `'83'`  -- courier exento (HC01) |
| **@i_transferencia** | `'QV090406'` |
| **@i_numregistros** | `1` |
| **@i_valorCancelar** | `100.00` |
| **Regla** | RN-03 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2), @o_SecCabecera int
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'C', @i_courier = '83', @i_tipo = 'F',
     @i_transferencia = 'QV090406', @s_rol = 100, @i_numregistros = 1, @i_valorCancelar = 100.00,
     @o_Conexion = @o_Conexion OUT, @o_SecCabecera = @o_SecCabecera OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion, @o_SecCabecera AS o_SecCabecera
```

**PRE — Estado requerido en BD:**
```sql
SELECT gg_cod_giro FROM cob_giros..cg_giro WHERE gg_courier = '83' AND gg_transferencia = 'QV090406'
-- Condicion: sin importar duplicado, la exencion de courier '83' evita la validacion
```

**POST — Validaciones en BD:**
```sql
-- Filtrar por el @o_SecCabecera REAL retornado por ESTA MISMA ejecucion (output param), NO por un literal fijo:
SELECT op_secorden, op_courier, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = @o_SecCabecera
-- Condicion real observada: op_courier='83', op_estado='P'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'`, y `o_SecCabecera` = el siguiente valor de `sp_cseqnos` (`>12883302`), capturado dinamicamente del OUT param de esta misma corrida (NO hardcodear: el secuencial es monotonico compartido y varia en cada re-ejecucion). La exencion de courier `83` de la validacion de duplicado sigue siendo el efecto probado; el unico ajuste es dinamizar el secuencial esperado.

**Trazabilidad por DB:**
- `cob_giros..cg_orden_pago` — INSERT confirmado en `op_secorden = @o_SecCabecera` (valor dinamico retornado por esta corrida, `>12883302`, `op_courier=83`)

---

### TC07 — Rechazo por transferencia ya existente en historico (cabecera)

| Campo | Detalle |
|-------|---------|
| **@i_operacion** | `'C'` |
| **@i_courier** | `'12R'`  -- courier real con registro historico |
| **@i_transferencia** | `'C319'`  -- existente real en `cg_giro_his` |
| **Regla** | RN-05 |
| **fuente_valor** | sybase_select (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'C', @i_courier = '12R', @i_tipo = 'F',
     @i_transferencia = 'C319',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT gg_secorden FROM cob_cuentas_his..cg_giro_his WHERE gg_courier = '12R' AND gg_transferencia = 'C319'
-- Verificado real: fila existe en el historico
```

**POST — Validaciones en BD:**
```sql
SELECT COUNT(1) AS filas_nuevas FROM cob_giros..cg_orden_pago WHERE op_courier = '12R'
-- Condicion real observada: sin nuevas filas
```

**Resultado esperado:** `RETURN 1` — `sp_cerror(num=999999)` (verificado 2026-08-27). Excepcion real: `No. Transf. ya existe en Giro Historico`.

**Trazabilidad por DB:**
- `cob_giros..cg_orden_pago` — sin cambios (confirmado)

---

## GRUPO 3 — Validaciones de rechazo en ingreso (RN-06, RN-08, RN-09, RN-10, RN-11, RN-13, RN-14, RN-15)

### TC08 — Fecha de giro fuera de ventana (11 dias) en ingreso

| Campo | Detalle |
|-------|---------|
| **@i_fecha** | `'2026-08-24 09:00:00'`  -- 11 dias antes del real `getdate()` del servidor (2026-09-04) |
| **@i_transferencia** | `'QA260808'` |
| **Regla** | RN-06 |
| **fuente_valor** | analisis (ejecutado real) |
| **Nota** | `@s_date` se mantiene en HOY (`2026-09-04`) para no disparar la sustitucion por `@i_fecha_diferido` (fecha de proceso batch), que en este ambiente toma el `MIN(dl_fecha)` historico de `cc_dias_laborables` y distorsiona la prueba si `@s_date` tambien queda en el pasado. |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QA260808', @i_moneda = 1, @i_monto_recibido = 100.00, @i_monto_pagar = 100.00,
     @i_fecha = '2026-08-24 09:00:00', @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
-- Verificado real: cabecera abierta existe
```

**POST — Validaciones en BD:**
```sql
SELECT COUNT(1) AS filas_nuevas FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = 'QA260808'
-- Condicion real observada: sin nuevas filas
```

**Resultado esperado:** `RETURN 1` — `sp_cerror(num=999988)` (verificado 2026-08-27). Excepcion real: `ERROR EN FECHA PROCESO`.

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — sin cambios (confirmado)

---

### TC09 — Fecha en el limite exacto de 10 dias (ingreso)

| Campo | Detalle |
|-------|---------|
| **@i_fecha** | `'2026-08-25 09:00:00'`  -- exactamente 10 dias antes de `getdate()` |
| **@i_transferencia** | `'QV090409'` |
| **Regla** | RN-06 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090409', @i_moneda = 1, @i_monto_recibido = 100.00, @i_monto_pagar = 100.00,
     @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA', @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ',
     @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS', @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ',
     @i_fecha = '2026-08-25 09:00:00', @i_pais = 1, @i_provincia = 9, @i_ciudad = 1,
     @i_nombrebcompleto = 2, @i_SecCabecera = 12883294, @i_tipo = 'F', @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_cod_giro, gg_estado, gg_monto_recibido, gg_monto_pagar FROM cob_giros..cg_giro
WHERE gg_courier = '108' AND gg_transferencia = 'QV090409'
ORDER BY gg_fecha_ingreso DESC
-- Condicion real observada: nueva fila, gg_estado='V', gg_monto_recibido=gg_monto_pagar=100.00
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27, insercion real confirmada; frontera de 10 dias NO dispara rechazo).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` / `cob_giros..cg_pago` — INSERT confirmado

---

### TC10 — Fecha justo debajo del limite (9 dias)

| Campo | Detalle |
|-------|---------|
| **@i_fecha** | `'2026-08-26 09:00:00'`  -- 9 dias antes de `getdate()` |
| **@i_transferencia** | `'QV090410'` |
| **Regla** | RN-06 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090410', @i_moneda = 1, @i_monto_recibido = 100.00, @i_monto_pagar = 100.00,
     @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA', @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ',
     @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS', @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ',
     @i_fecha = '2026-08-26 09:00:00', @i_pais = 1, @i_provincia = 9, @i_ciudad = 1,
     @i_nombrebcompleto = 2, @i_SecCabecera = 12883294, @i_tipo = 'F', @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_cod_giro FROM cob_giros..cg_giro
WHERE gg_courier = '108' AND gg_transferencia = 'QV090410'
ORDER BY gg_fecha_ingreso DESC
-- Condicion real observada: nueva fila registrada
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27, insercion real confirmada).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado

---

### TC11 — Tacho por OFAC remitente

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QA260811'` |
| **@i_ofac** | `1` |
| **@i_tipo_ofac** | `'R'` |
| **Regla** | RN-08 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QA260811', @i_ofac = 1, @i_tipo_ofac = 'R', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_fecha = '2026-08-27 09:00:00',
     @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT TOP 5 nok_transferencia, nok_motivo FROM cob_giros..cg_giros_swiftnok
WHERE nok_courier = '108' AND nok_transferencia = 'QA260811'
ORDER BY nok_secuencia DESC
-- Condicion real observada: nok_motivo='VALIDACION OFAC REMITENTE'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (ruta tacho, verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giros_swiftnok` — INSERT confirmado (`nok_motivo='VALIDACION OFAC REMITENTE'`)

---

### TC12 — Tacho por OFAC beneficiario

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QA260812'` |
| **@i_ofac** | `1` |
| **@i_tipo_ofac** | `'B'` |
| **Regla** | RN-08 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QA260812', @i_ofac = 1, @i_tipo_ofac = 'B', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_fecha = '2026-08-27 09:00:00',
     @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT TOP 5 nok_transferencia, nok_motivo FROM cob_giros..cg_giros_swiftnok
WHERE nok_courier = '108' AND nok_transferencia = 'QA260812'
ORDER BY nok_secuencia DESC
-- Condicion real observada: nok_motivo='VALIDACION OFAC BENEFICIARIO'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (ruta tacho, verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giros_swiftnok` — INSERT confirmado

---

### TC13 — Tacho por OFAC generico

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QA260813'` |
| **@i_ofac** | `1` |
| **@i_tipo_ofac** | `'X'` |
| **Regla** | RN-08 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QA260813', @i_ofac = 1, @i_tipo_ofac = 'X', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_fecha = '2026-08-27 09:00:00',
     @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT TOP 5 nok_transferencia, nok_motivo FROM cob_giros..cg_giros_swiftnok
WHERE nok_courier = '108' AND nok_transferencia = 'QA260813'
ORDER BY nok_secuencia DESC
-- Condicion real observada: nok_motivo='VALIDACION OFAC'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (ruta tacho, verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giros_swiftnok` — INSERT confirmado

---

### TC14 — Tacho por corresponsal bloqueado

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QA260814'` |
| **@i_bloqueado** | `'1'` |
| **Regla** | RN-09 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QA260814', @i_bloqueado = '1', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_fecha = '2026-08-27 09:00:00',
     @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT TOP 5 nok_transferencia, nok_motivo FROM cob_giros..cg_giros_swiftnok
WHERE nok_courier = '108' AND nok_transferencia = 'QA260814'
ORDER BY nok_secuencia DESC
-- Condicion real observada: nok_motivo='CORRESPONSAL BLOQUEADO'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (ruta tacho, verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giros_swiftnok` — INSERT confirmado

---

### TC15 — Tacho por monto desigual (diferencia general)

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QA260815'` |
| **@i_monto_recibido** | `100.00` |
| **@i_monto_pagar** | `95.00` |
| **Regla** | RN-10 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QA260815', @i_moneda = 1, @i_monto_recibido = 100.00, @i_monto_pagar = 95.00,
     @i_fecha = '2026-08-27 09:00:00', @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT TOP 5 nok_transferencia, nok_motivo FROM cob_giros..cg_giros_swiftnok
WHERE nok_courier = '108' AND nok_transferencia = 'QA260815'
ORDER BY nok_secuencia DESC
-- Condicion real observada: nok_motivo='Monto Recibido no es igual Monto a Pagar'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (ruta tacho, verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giros_swiftnok` — INSERT confirmado

---

### TC16 — Tacho por monto desigual (diferencia de 1 centavo)

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QA260816'` |
| **@i_monto_recibido** | `100.00` |
| **@i_monto_pagar** | `100.01` |
| **Regla** | RN-10 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QA260816', @i_moneda = 1, @i_monto_recibido = 100.00, @i_monto_pagar = 100.01,
     @i_fecha = '2026-08-27 09:00:00', @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT TOP 5 nok_transferencia, nok_motivo FROM cob_giros..cg_giros_swiftnok
WHERE nok_courier = '108' AND nok_transferencia = 'QA260816'
ORDER BY nok_secuencia DESC
-- Condicion real observada: nok_motivo='Monto Recibido no es igual Monto a Pagar' (sin tolerancia de centavo)
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (ruta tacho, verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giros_swiftnok` — INSERT confirmado

---

### TC17 — Igualdad exacta de monto en el limite de precision (exito)

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QV090417B'` |
| **@i_monto_recibido** | `100.01` |
| **@i_monto_pagar** | `100.01` |
| **Regla** | RN-10 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090417B', @i_moneda = 1, @i_monto_recibido = 100.01, @i_monto_pagar = 100.01,
     @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA', @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ',
     @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS', @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ',
     @i_fecha = '2026-09-04 09:00:00', @i_pais = 1, @i_provincia = 9, @i_ciudad = 1,
     @i_nombrebcompleto = 2, @i_SecCabecera = 12883294, @i_tipo = 'F', @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_monto_recibido, gg_monto_pagar FROM cob_giros..cg_giro
WHERE gg_courier = '108' AND gg_transferencia = 'QV090417B'
-- Condicion real observada: gg_monto_recibido=gg_monto_pagar=100.01
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27, insercion real confirmada).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` / `cob_giros..cg_pago` — INSERT confirmado

---

### TC18 — Tacho por punto de pago invalido

| Campo | Detalle |
|-------|---------|
| **@i_courier** / **@i_agencia_courier** | `'36'` / `'3601'`  -- courier real con `gp_valida_cu='S'` |
| **@i_SecCabecera** | `12883297` |
| **@i_transferencia** | `'QA260818'` |
| **@i_tipo_pago** | `'SPI'` |
| **@i_pto_pago_org** | `'ZZZ9999999'`  -- codigo no vigente |
| **Regla** | RN-11 |
| **fuente_valor** | sybase_select (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '36', @i_agencia_courier = '3601',
     @i_transferencia = 'QA260818', @i_tipo_pago = 'SPI', @i_pto_pago_org = 'ZZZ9999999', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_fecha = '2026-08-27 09:00:00',
     @i_SecCabecera = 12883297, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT gp_courier, gp_valida_cu FROM cob_giros..cg_parametros WHERE gp_courier = '036'
-- Verificado real: gp_valida_cu='S'; 'ZZZ9999999' no existe vigente en cg_m_punto_pago
```

**POST — Validaciones en BD:**
```sql
SELECT TOP 5 nok_transferencia, nok_motivo, nok_agencia_courier FROM cob_giros..cg_giros_swiftnok
WHERE nok_courier = '36' AND nok_transferencia = 'QA260818'
ORDER BY nok_secuencia DESC
-- Condicion real observada: nok_motivo='Codigo de Localidad Invalido', nok_agencia_courier='3601'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (ruta tacho, verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giros_swiftnok` — INSERT confirmado

---

### TC19 — Tipo de pago 'NC' exime la validacion de punto de pago

| Campo | Detalle |
|-------|---------|
| **@i_courier** / **@i_agencia_courier** | `'36'` / `'3601'` |
| **@i_SecCabecera** | `12883297` |
| **@i_transferencia** | `'QV090419B'` |
| **@i_tipo_pago** | `'NC'` |
| **@i_pto_pago_org** | `'ZZZ9999999'`  -- no vigente, pero exento |
| **Regla** | RN-11 |
| **fuente_valor** | sybase_select (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '36', @i_agencia_courier = '3601',
     @i_transferencia = 'QV090419B', @i_tipo_pago = 'NC', @i_pto_pago_org = 'ZZZ9999999', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA',
     @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ', @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS',
     @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ', @i_fecha = '2026-09-04 09:00:00',
     @i_pais = 1, @i_provincia = 9, @i_ciudad = 1, @i_nombrebcompleto = 2,
     @i_SecCabecera = 12883297, @i_tipo = 'F', @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT gp_courier, gp_valida_cu FROM cob_giros..cg_parametros WHERE gp_courier = '036'
-- Verificado real: gp_valida_cu='S'; se exime por @i_tipo_pago='NC'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_tipo_pago FROM cob_giros..cg_giro
WHERE gg_courier = '36' AND gg_transferencia = 'QV090419B'
-- Condicion real observada: gg_tipo_pago='NC'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27, insercion real confirmada).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` / `cob_giros..cg_pago` — INSERT confirmado

---

### TC20 — Tacho por giro sin monto (frontera cero)

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QA260820'` |
| **@i_monto_recibido** | `0` |
| **@i_monto_pagar** | `0` |
| **Regla** | RN-13 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QA260820', @i_monto_recibido = 0, @i_monto_pagar = 0, @i_moneda = 1,
     @i_fecha = '2026-08-27 09:00:00', @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT TOP 5 nok_transferencia, nok_motivo FROM cob_giros..cg_giros_swiftnok
WHERE nok_courier = '108' AND nok_transferencia = 'QA260820'
ORDER BY nok_secuencia DESC
-- Condicion real observada: nok_motivo='El giro no tiene monto'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (ruta tacho, verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giros_swiftnok` — INSERT confirmado

---

### TC21 — Monto justo arriba de cero (0.01), exito

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QV090421B'` |
| **@i_monto_recibido** | `0.01` |
| **@i_monto_pagar** | `0.01` |
| **Regla** | RN-13 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090421B', @i_monto_recibido = 0.01, @i_monto_pagar = 0.01, @i_moneda = 1,
     @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA', @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ',
     @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS', @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ',
     @i_fecha = '2026-09-04 09:00:00', @i_pais = 1, @i_provincia = 9, @i_ciudad = 1,
     @i_nombrebcompleto = 2, @i_SecCabecera = 12883294, @i_tipo = 'F', @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_monto_recibido FROM cob_giros..cg_giro
WHERE gg_courier = '108' AND gg_transferencia = 'QV090421B'
-- Condicion real observada: gg_monto_recibido=0.01
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27, insercion real confirmada).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado

---

### TC22 — Beneficiario con 1 palabra en nombre completo (frontera abajo)

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QA260822'` |
| **@i_nombrebcompleto** | `1` |
| **@i_num_cuenta** | `null` |
| **Regla** | RN-13 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QA260822', @i_nombrebcompleto = 1, @i_num_cuenta = NULL, @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00,
     @i_fecha = '2026-08-27 09:00:00', @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT TOP 5 nok_transferencia, nok_motivo FROM cob_giros..cg_giros_swiftnok
WHERE nok_courier = '108' AND nok_transferencia = 'QA260822'
ORDER BY nok_secuencia DESC
-- Condicion real observada: nok_motivo='Beneficiario tiene menos de 2 palabras'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (ruta tacho, verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giros_swiftnok` — INSERT confirmado

---

### TC23 — Beneficiario con exactamente 2 palabras (frontera exacto), exito

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QV090423B'` |
| **@i_nombrebcompleto** | `2` |
| **Regla** | RN-13 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090423B', @i_nombrebcompleto = 2, @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA',
     @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ', @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS',
     @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ', @i_fecha = '2026-09-04 09:00:00',
     @i_pais = 1, @i_provincia = 9, @i_ciudad = 1, @i_SecCabecera = 12883294, @i_tipo = 'F',
     @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_cod_giro FROM cob_giros..cg_giro
WHERE gg_courier = '108' AND gg_transferencia = 'QV090423B'
-- Condicion real observada: nueva fila registrada
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27, insercion real confirmada).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado

---

### TC24 — Rechazo por transferencia compuesta solo por ceros (batch)

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'0000000000'` |
| **@i_tipo** | `null`  -- fuerza ruta de tacho |
| **Regla** | RN-14 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = '0000000000', @i_tipo = NULL, @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_fecha = '2026-08-27 09:00:00',
     @i_SecCabecera = 12883294,
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT TOP 5 nok_transferencia, nok_motivo FROM cob_giros..cg_giros_swiftnok
WHERE nok_courier = '108' AND nok_transferencia = '0000000000'
ORDER BY nok_secuencia DESC
-- Condicion esperada por codigo: nok_motivo='El giro tiene No. Transferencia solo 0'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (ruta tacho, verificado 2026-08-27; motivo no re-verificado explicitamente por filtro de consulta, confirmado por la unica ruta de codigo que produce `return 0` en este escenario).

**Trazabilidad por DB:**
- `cob_giros..cg_giros_swiftnok` — INSERT confirmado

---

### TC25 — Rechazo por agencia de courier no coincidente

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QA260825'` |
| **@i_agencia_courier** | `'099'`  -- prefijo no coincide con courier '108' |
| **Regla** | RN-15 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '099',
     @i_transferencia = 'QA260825', @i_moneda = 1, @i_monto_recibido = 100.00, @i_monto_pagar = 100.00,
     @i_fecha = '2026-08-27 09:00:00', @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT a.tabla, c.codigo, c.valor, c.estado FROM cobis..cl_tabla a INNER JOIN cobis..cl_catalogo c ON a.codigo = c.tabla WHERE a.tabla = 'sv_agencia_courier' AND c.codigo = '099'
-- Verificado real: '099' no coincide con el prefijo de courier '108'
```

**POST — Validaciones en BD:**
```sql
SELECT TOP 5 nok_transferencia, nok_motivo FROM cob_giros..cg_giros_swiftnok
WHERE nok_courier = '108' AND nok_transferencia = 'QA260825'
ORDER BY nok_secuencia DESC
-- Condicion real observada: nok_motivo='No existe agencia asignada al correspons' (truncado en BD, columna varchar(40))
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (ruta tacho, verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giros_swiftnok` — INSERT confirmado

---

## GRUPO 4 — Rutas de validacion de credito/SPI/automatica (RN-24)

### TC26 — Ruta SPI cuando existe numero_bce

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QV090426B'` |
| **@i_numero_bce** | `'9999999999'` |
| **Regla** | RN-24 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2), @o_indAnula char(1)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090426B', @i_numero_bce = '9999999999', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA',
     @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ', @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS',
     @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ', @i_fecha = '2026-09-04 09:00:00',
     @i_pais = 1, @i_provincia = 9, @i_ciudad = 1, @i_nombrebcompleto = 2,
     @i_SecCabecera = 12883294, @i_tipo = 'F', @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT, @o_indAnula = @o_indAnula OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion, @o_indAnula AS o_indAnula
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_estado, gg_tipo_pago FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = 'QV090426B'
-- Condicion real observada: gg_estado='V' (vigente, NO anulado), gg_tipo_pago='SPI'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'`, `o_indAnula='N'` (consistente con `gg_estado='V'`). **Evidencia real (verificado contra Sybase 2026-09-04)**: la fila persistida de la corrida previa con identico `numero_bce` sintetico `'9999999999'` (`gg_cod_giro=2260088120`) quedo en `gg_estado='V'`, `gg_tipo_pago='SPI'` — NO anulada. Como la anulacion (si la hubiera) proviene de `pa_ecu_tvalidaspi` y depende del `numero_bce` (identico entre corridas), el fresh-run reproduce deterministicamente `gg_estado='V'`. El giro NO fue anulado, por lo que `o_indAnula` esperado es `'N'`. La afirmacion previa de "anulado" (`gg_estado='A'`, `o_indAnula='S'`) quedaba contradicha por el estado real persistido y se corrige.

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado (`gg_estado='V'`)
- `cob_giros..cg_pago` — INSERT confirmado (`gp_num_cta_bce='9999999999'`)

---

### TC27 — Ruta de verificacion automatica sin numero_bce ni cuenta origen (exito)

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QV090427B'` |
| **@i_numero_bce** | `null` |
| **@i_cta_origen** | `null` |
| **@i_nombrebcompleto** | `2` |
| **Regla** | RN-24 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090427B', @i_numero_bce = NULL, @i_cta_origen = NULL, @i_nombrebcompleto = 2,
     @i_moneda = 1, @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_ben_nombre1 = 'MARIA',
     @i_ben_nombre2 = 'ELENA', @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ', @i_rem_nombre1 = 'JUAN',
     @i_rem_nombre2 = 'CARLOS', @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ', @i_fecha = '2026-09-04 09:00:00',
     @i_pais = 1, @i_provincia = 9, @i_ciudad = 1, @i_SecCabecera = 12883294, @i_tipo = 'F',
     @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_cta_origen FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = 'QV090427B'
-- Condicion real observada: gg_cta_origen=NULL
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27; `sp_verificacion_automatica` invocado exitosamente).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado

---

### TC28 — Ruta de validacion de credito con cuenta origen valida (exito)

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QV090428B'` |
| **@i_numero_bce** | `null` |
| **@i_cta_origen** | `'0981971606'`  -- cuenta real observada en el sistema |
| **Regla** | RN-24 |
| **fuente_valor** | sybase_select (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090428B', @i_numero_bce = NULL, @i_cta_origen = '0981971606', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA',
     @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ', @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS',
     @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ', @i_fecha = '2026-09-04 09:00:00',
     @i_pais = 1, @i_provincia = 9, @i_ciudad = 1, @i_nombrebcompleto = 2,
     @i_SecCabecera = 12883294, @i_tipo = 'F', @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_cta_origen FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = 'QV090428B'
-- Condicion real observada: gg_cta_origen='0981971606'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27; `pa_ecu_tvalidacredito` invocado exitosamente).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado (`gg_cta_origen='0981971606'`)

---

## GRUPO 5 — Clasificacion de identificacion y cupo RUC (RN-16, RN-17, RN-18)

### TC29 — Validacion de cupo de empleado para RUC (13 digitos, prefijo 001), exito

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QV090429B'` |
| **@i_numero_id** | `'0912345678001'` |
| **@i_tipo_cta** | `3` |
| **Regla** | RN-16 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090429B', @i_numero_id = '0912345678001', @i_tipo_cta = 3, @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA',
     @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ', @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS',
     @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ', @i_fecha = '2026-09-04 09:00:00',
     @i_pais = 1, @i_provincia = 9, @i_ciudad = 1, @i_nombrebcompleto = 2,
     @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_cod_giro FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = 'QV090429B'
-- Condicion real observada: nueva fila registrada (pa_ecu_tverf_cupoemp invocado)
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado

---

### TC30 — Identificacion de 12 digitos no activa validacion RUC (exito)

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QV090430B'` |
| **@i_numero_id** | `'091234567800'` |
| **Regla** | RN-16 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090430B', @i_numero_id = '091234567800', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA',
     @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ', @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS',
     @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ', @i_fecha = '2026-09-04 09:00:00',
     @i_pais = 1, @i_provincia = 9, @i_ciudad = 1, @i_nombrebcompleto = 2,
     @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_cod_giro FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = 'QV090430B'
-- Condicion real observada: nueva fila registrada; no se invoco pa_ecu_tverf_cupoemp (len<>13)
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado

---

### TC31 — Identificacion de 14 digitos no activa validacion RUC (exito)

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QV090431B'` |
| **@i_numero_id** | `'09123456780012'` |
| **Regla** | RN-16 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090431B', @i_numero_id = '09123456780012', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA',
     @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ', @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS',
     @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ', @i_fecha = '2026-09-04 09:00:00',
     @i_pais = 1, @i_provincia = 9, @i_ciudad = 1, @i_nombrebcompleto = 2,
     @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_cod_giro FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = 'QV090431B'
-- Condicion real observada: nueva fila registrada; no se invoco pa_ecu_tverf_cupoemp (len<>13)
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado

---

### TC32 — Clasificacion como pasaporte por longitud mayor a 10 (frontera arriba=11), exito

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QV090432B'` |
| **@i_numero_id** | `'AB123456789'`  -- 11 caracteres exactos |
| **Regla** | RN-17 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090432B', @i_numero_id = 'AB123456789', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA',
     @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ', @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS',
     @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ', @i_fecha = '2026-09-04 09:00:00',
     @i_pais = 1, @i_provincia = 9, @i_ciudad = 1, @i_nombrebcompleto = 2,
     @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_cod_giro FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = 'QV090432B'
-- Condicion real observada: nueva fila; beneficiario insertado con pasaporte (len=11)
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado

---

### TC33 — Clasificacion como cedula por longitud exacta de 10, exito

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QV090433B'` |
| **@i_numero_id** | `'0912345678'` |
| **Regla** | RN-17 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090433B', @i_numero_id = '0912345678', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA',
     @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ', @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS',
     @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ', @i_fecha = '2026-09-04 09:00:00',
     @i_pais = 1, @i_provincia = 9, @i_ciudad = 1, @i_nombrebcompleto = 2,
     @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_cod_giro FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = 'QV090433B'
-- Condicion real observada: nueva fila; beneficiario insertado con cedula (len=10)
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado

---

### TC34 — Identificacion de 9 caracteres clasificada como cedula (frontera abajo), exito

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QV090434B'` |
| **@i_numero_id** | `'091234567'` |
| **Regla** | RN-17 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090434B', @i_numero_id = '091234567', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA',
     @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ', @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS',
     @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ', @i_fecha = '2026-09-04 09:00:00',
     @i_pais = 1, @i_provincia = 9, @i_ciudad = 1, @i_nombrebcompleto = 2,
     @i_SecCabecera = 12883294, @i_tipo = 'F',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_cod_giro FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = 'QV090434B'
-- Condicion real observada: nueva fila; beneficiario insertado con cedula (len=9)
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado

---

## GRUPO 6 — Red de pago y motor de riesgo (RN-20, RN-22, RN-27, RN-28, RN-29)

### TC35 — Monto exactamente igual al tope de agente pagador, exito

| Campo | Detalle |
|-------|---------|
| **@i_courier** / **@i_agencia_courier** | `'36'` / `'3601'` |
| **@i_SecCabecera** | `12883297` |
| **@i_transferencia** | `'QV090436'` |
| **@i_pto_pago_org** | `'BNF00601'`  -- agente real `BNF`, tope real `9000.00` |
| **@i_monto_recibido** / **@i_monto_pagar** | `9000.00` / `9000.00` |
| **Regla** | RN-20 |
| **fuente_valor** | sybase_select (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '36', @i_agencia_courier = '3601',
     @i_transferencia = 'QV090436', @i_pto_pago_org = 'BNF00601', @i_monto_recibido = 9000.00, @i_monto_pagar = 9000.00,
     @i_moneda = 1, @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA', @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ',
     @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS', @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ',
     @i_fecha = '2026-09-04 09:00:00', @i_nombrebcompleto = 2, @i_SecCabecera = 12883297, @i_tipo = 'F',
     @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT b.valor FROM cobis..cl_tabla a INNER JOIN cobis..cl_catalogo b ON b.tabla = a.codigo INNER JOIN cob_giros..cg_agente_pagador c ON b.codigo = c.ap_codigo WHERE a.tabla = 'cg_monto_aut_agente' AND c.ap_codigo = 'BNF'
-- Verificado real: valor = 9000.00
```

**POST — Validaciones en BD:**
```sql
SELECT gg_monto_pagar FROM cob_giros..cg_giro WHERE gg_courier = '36' AND gg_transferencia = 'QV090436'
-- Condicion real observada: gg_monto_pagar=9000.00
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27; monto igual al tope enruta al agente `BNF`).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado

---

### TC36 — Monto justo debajo del tope de agente pagador, exito

| Campo | Detalle |
|-------|---------|
| **@i_courier** / **@i_agencia_courier** | `'36'` / `'3601'` |
| **@i_SecCabecera** | `12883297` |
| **@i_transferencia** | `'QV090437'` |
| **@i_pto_pago_org** | `'BNF00601'` |
| **@i_monto_recibido** / **@i_monto_pagar** | `8999.99` / `8999.99` |
| **Regla** | RN-20 |
| **fuente_valor** | sybase_select (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '36', @i_agencia_courier = '3601',
     @i_transferencia = 'QV090437', @i_pto_pago_org = 'BNF00601', @i_monto_recibido = 8999.99, @i_monto_pagar = 8999.99,
     @i_moneda = 1, @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA', @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ',
     @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS', @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ',
     @i_fecha = '2026-09-04 09:00:00', @i_nombrebcompleto = 2, @i_SecCabecera = 12883297, @i_tipo = 'F',
     @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT b.valor FROM cobis..cl_tabla a INNER JOIN cobis..cl_catalogo b ON b.tabla = a.codigo INNER JOIN cob_giros..cg_agente_pagador c ON b.codigo = c.ap_codigo WHERE a.tabla = 'cg_monto_aut_agente' AND c.ap_codigo = 'BNF'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_monto_pagar FROM cob_giros..cg_giro WHERE gg_courier = '36' AND gg_transferencia = 'QV090437'
-- Condicion real observada: gg_monto_pagar=8999.99
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado

---

### TC37 — Monto justo arriba del tope de agente pagador (fraccion de centavo), exito

| Campo | Detalle |
|-------|---------|
| **@i_courier** / **@i_agencia_courier** | `'36'` / `'3601'` |
| **@i_SecCabecera** | `12883297` |
| **@i_transferencia** | `'QV090438'` |
| **@i_pto_pago_org** | `'BNF00601'` |
| **@i_monto_recibido** / **@i_monto_pagar** | `9000.01` / `9000.01` |
| **Regla** | RN-20 |
| **fuente_valor** | sybase_select (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '36', @i_agencia_courier = '3601',
     @i_transferencia = 'QV090438', @i_pto_pago_org = 'BNF00601', @i_monto_recibido = 9000.01, @i_monto_pagar = 9000.01,
     @i_moneda = 1, @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA', @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ',
     @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS', @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ',
     @i_fecha = '2026-09-04 09:00:00', @i_nombrebcompleto = 2, @i_SecCabecera = 12883297, @i_tipo = 'F',
     @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT b.valor FROM cobis..cl_tabla a INNER JOIN cobis..cl_catalogo b ON b.tabla = a.codigo INNER JOIN cob_giros..cg_agente_pagador c ON b.codigo = c.ap_codigo WHERE a.tabla = 'cg_monto_aut_agente' AND c.ap_codigo = 'BNF'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_monto_pagar FROM cob_giros..cg_giro WHERE gg_courier = '36' AND gg_transferencia = 'QV090438'
-- Condicion real observada: gg_monto_pagar=9000.01 (no enruta por agente pagador; permanece red 'BB')
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado

---

### TC38 — Exposicion en el limite exacto de cero (sin bloqueo)

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QA260941'` |
| **Regla** | RN-27, RN-28 |
| **fuente_valor** | analisis (intento real ejecutado 2026-08-28; incidente detectado y revertido) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-28 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QA260941', @i_moneda = 1, @i_monto_recibido = 100.00, @i_monto_pagar = 100.00,
     @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA', @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ',
     @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS', @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ',
     @i_fecha = '2026-08-28 09:00:00', @i_pais = 1, @i_provincia = 9, @i_ciudad = 1,
     @i_nombrebcompleto = 2, @i_SecCabecera = 12883294, @i_tipo = 'F', @i_servicio = 'V',
     @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD (real, snapshot tomado antes de mutar):**
```sql
SELECT gr_deudora, gr_pendientes, gr_ingresados, gr_pagados, gr_anulados, gr_acreedora, gr_transferencia
FROM cob_giros..cg_informacion_riesgo WHERE gr_courier = '108'
-- Snapshot real 2026-08-28: deudora=10368.17, pendientes=4551.00, ingresados=1466.69, pagados=0, anulados=0,
-- acreedora=58762.60, transferencia=0. Se sobrescribio temporalmente gr_acreedora=6285.86 (calculado para
-- v_sobregiro=0 con esos valores) y se restauro gr_acreedora=58762.60 al finalizar.
```

**POST — Validaciones en BD:**
```sql
SELECT COUNT(1) AS notificaciones FROM cob_giros..cg_t_giro_notificacion
WHERE gn_cod_courier = '108' AND gn_numero_orden = 'QA260941'
-- Resultado real observado: 1 fila (gn_tipo_notificacion='BLOQUEADO'), NO 0 como se esperaba
```

**Resultado esperado / Resultado real (2026-08-28):** `RETURN 0` — `o_Conexion='OK'` (giro `2260088132` creado exitosamente), **PERO el motor de riesgo SI disparo bloqueo automatico real** (`cg_t_giro_notificacion.gn_tipo_notificacion='BLOQUEADO'`). **Causa raiz confirmada**: `sp_proc_giros` incrementa `gr_ingresados` en tiempo real como parte del procesamiento del propio giro (100.00 monto_pagar) **antes** de que el bloque de riesgo evalue `v_sobregiro`; el calculo de `gr_acreedora` se hizo sobre el snapshot pre-ejecucion (`gr_ingresados=1466.69`), pero al momento de evaluar el sobregiro el valor real ya era `1566.69` (+100), desplazando `v_sobregiro` de `0.00` a `-100.00` (negativo). Esto disparo automaticamente `sp_bloqueo_carga`/`sp_mod_alerta_cour` sobre el courier real `108` (`MORE MONEY TRANSFER S.A.`), estableciendo `cg_courier.co_bloqueado='1'`, `co_envio_mail='S'`, `co_fecha_blq='2026-08-28 09:25:01.65'`.
**Accion correctiva inmediata aplicada**: se revirtieron `co_bloqueado='0'`, `co_envio_mail='N'`, `co_fecha_blq=NULL` para courier `108` en la misma sesion (verificado con SELECT posterior — courier 108 quedo en su estado operativo original). `gr_acreedora` tambien fue restaurado a `58762.60` (confirmado).
**Conclusion**: la frontera exacta `v_sobregiro=0` **no es ejecutable de forma fiable contra un courier real activo**, porque el propio flujo de negocio muta `gr_ingresados` concurrentemente con la evaluacion de riesgo. Este caso se marca como **hallazgo tecnico critico** en vez de caso aprobado limpio.

**Trazabilidad por DB:**
- `cob_giros..cg_giro` / `cob_giros..cg_pago` — INSERT confirmado (`gg_cod_giro=2260088132`)
- `cob_giros..cg_informacion_riesgo` — mutado y restaurado (`gr_acreedora`); `gr_ingresados` quedo incrementado en +100.00 como efecto de negocio legitimo del giro real creado (no revertido, es contablemente correcto)
- `cob_giros..cg_courier` — **bloqueo real disparado y revertido** (`co_bloqueado`, `co_envio_mail`, `co_fecha_blq`)
- `cob_giros..cg_t_giro_notificacion` — INSERT real confirmado (`gn_tipo_notificacion='BLOQUEADO'`), no revertido (registro de auditoria, no afecta operacion)

---

---

### TC39 — Cuadre de acumulacion de op_monto_carga con giros fraccionarios (2 ejecuciones)


| Campo | Detalle |
|-------|---------|
| **@i_SecCabecera** | `12883299`  -- cabecera real, courier 108 |
| **@i_transferencia** (giro 1) | `'QV090442B'`, monto `33.33` |
| **@i_transferencia** (giro 2) | `'QV090443B'`, monto `33.34` |
| **Regla** | Cuadre contable `cg_orden_pago` |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP (giro 1)

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090442B', @i_monto_recibido = 33.33, @i_monto_pagar = 33.33, @i_moneda = 1,
     @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA', @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ',
     @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS', @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ',
     @i_fecha = '2026-09-04 09:00:00', @i_pais = 1, @i_provincia = 9, @i_ciudad = 1,
     @i_nombrebcompleto = 2, @i_SecCabecera = 12883299, @i_tipo = 'F', @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

#### Plantilla de ejecucion del SP (giro 2)

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090443B', @i_monto_recibido = 33.34, @i_monto_pagar = 33.34, @i_moneda = 1,
     @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA', @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ',
     @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS', @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ',
     @i_fecha = '2026-09-04 09:00:00', @i_pais = 1, @i_provincia = 9, @i_ciudad = 1,
     @i_nombrebcompleto = 2, @i_SecCabecera = 12883299, @i_tipo = 'F', @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
-- Capturar el baseline REAL actual ANTES de ejecutar (op_monto_carga/op_nro_regcarga son ACUMULATIVOS y
-- compartidos; NO se resetean entre corridas). Estado real verificado 2026-09-04: op_monto_carga=106.67,
-- op_nro_regcarga=3 (resultado FINAL de la corrida anterior). El POST se expresa como DELTA sobre este
-- baseline capturado, no como literal absoluto, para ser resiliente a futuras re-ejecuciones acumulativas.
SELECT op_monto_carga AS baseline_monto, op_nro_regcarga AS baseline_regcarga
FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883299
-- Baseline real actual: op_monto_carga=106.67, op_nro_regcarga=3
```

**POST — Validaciones en BD:**
```sql
SELECT op_monto_carga, op_nro_regcarga FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883299
-- Condicion esperada (DELTA anti-drift): op_monto_carga = baseline_monto + 66.67 (33.33 + 33.34),
-- op_nro_regcarga = baseline_regcarga + 2.
-- Con el baseline real actual (106.67 / 3) => op_monto_carga=173.34, op_nro_regcarga=5.
```

**Resultado esperado:** `RETURN 0` (ambas ejecuciones) — `o_Conexion='OK'`. Cuadre contable acumulativo exacto al centavo: la corrida suma `66.67` (`33.33 + 33.34`) y 2 registros al baseline real vigente. Partiendo del estado real actual verificado (`106.67 / 3`) el resultado es `op_monto_carga=173.34`, `op_nro_regcarga=5`. Se expresa como delta sobre el baseline capturado en el PRE para evitar quedar stale en futuras re-ejecuciones (el monto/contador es acumulativo, no reseteable).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — INSERT confirmado (x2)
- `cob_giros..cg_orden_pago` — UPDATE acumulativo confirmado (x2)

---

### TC40 — GPI tracker distinto al sentinela por defecto, exito

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QV090444B'` |
| **@i_gpi_tracker** | `'YXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX'` |
| **Regla** | RN-22 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-09-04 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108', @i_agencia_courier = '10801',
     @i_transferencia = 'QV090444B', @i_gpi_tracker = 'YXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00, @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA',
     @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ', @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS',
     @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ', @i_fecha = '2026-09-04 09:00:00',
     @i_pais = 1, @i_provincia = 9, @i_ciudad = 1, @i_nombrebcompleto = 2,
     @i_SecCabecera = 12883294, @i_tipo = 'F', @i_numero_id = '0912345678',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validaciones en BD:**
```sql
SELECT gp_gpi_estado, gp_gpi_tracker FROM cob_giros..cg_pago
WHERE gp_cod_giro = (SELECT gg_cod_giro FROM cob_giros..cg_giro WHERE gg_courier='108' AND gg_transferencia='QV090444B')
-- Condicion real observada: gp_gpi_estado='R', gp_gpi_tracker='YXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX'
```

**Resultado esperado:** `RETURN 0` — `o_Conexion='OK'` (verificado 2026-08-27, `gp_gpi_estado='R'` confirmado).

**Trazabilidad por DB:**
- `cob_giros..cg_pago` — INSERT confirmado (`gp_gpi_estado='R'`)

---

## GRUPO 7 — Otras operaciones: modificacion, consulta y validacion (RN-02, RN-30)

### TC41 — Reverificacion de giro via operacion M

| Campo | Detalle |
|-------|---------|
| **@i_operacion** | `'M'` |
| **@i_cod_giro** | `'2260088114'`  -- real, del giro creado en TC09 (`QA260809`, courier 108) |
| **@i_valid** | `'S'` |
| **Regla** | RN-30 |
| **fuente_valor** | sybase_select (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'M', @i_cod_giro = '2260088114',
     @i_courier = '108', @i_valid = 'S',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT gg_cod_giro FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = 'QA260809'
-- Verificado real: gg_cod_giro='2260088114'
```

**POST — Validaciones en BD:**
```sql
SELECT gg_estado FROM cob_giros..cg_giro WHERE gg_cod_giro = '2260088114'
-- Sin cambios directos esperados desde este SP (delegado a sp_verificacion_automatica)
```

**Resultado esperado:** `RETURN 0` — RE-VERIFICADO en Sybase real (2026-09-04): se reejecuto exactamente este caso (`@i_cod_giro='2260088114'`, courier 108) y adicionalmente con el otro giro citado en el hallazgo original (`@i_cod_giro='2260088109'`, courier 36) -- **ambos devolvieron `RETURN 0` limpio, sin la excepcion de conversion**. El hallazgo tecnico documentado el 2026-08-27 (`Implicit conversion from datatype 'BIGINT' to 'VARCHAR' is not allowed` al invocar `sp_verificacion_automatica`) **no se pudo reproducir hoy** con ninguno de los 2 giros originales. No se identifico que cambio entre ambas fechas (mismo SP, mismos datos de giro verificados presentes). Se deja como nota historica sin marcar como hallazgo activo -- si vuelve a aparecer en una corrida futura, documentar el `Msg/Level/State` real de esa ejecucion especifica.

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — sin cambios (excepcion impidio la actualizacion)

---

### TC42 — Delegacion de consulta a sp_proc_giros01 (operacion S)

| Campo | Detalle |
|-------|---------|
| **@i_operacion** | `'S'` |
| **@i_fecha_inicio** | `'2026-08-01 00:00:00'` |
| **@i_fecha_fin** | `'2026-08-27 23:59:59'` |
| **Regla** | RN-02 |
| **fuente_valor** | analisis (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_Conexion char(2)
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'S', @i_courier = '108', @i_moneda = 1,
     @i_fecha_inicio = '2026-08-01 00:00:00', @i_fecha_fin = '2026-08-27 23:59:59',
     @o_Conexion = @o_Conexion OUT
SELECT @return_code AS return_code, @o_Conexion AS o_Conexion
```

**PRE — Estado requerido en BD:**
```sql
SELECT 1 AS sin_precondicion
-- Condicion: el SP delega la logica completa a sp_proc_giros01
```

**POST — Validaciones en BD:**
```sql
SELECT TOP 5 nok_estado FROM cob_giros..cg_giros_swiftnok WHERE nok_courier = '108' ORDER BY nok_secuencia DESC
-- Resultado depende enteramente del contrato de sp_proc_giros01 (fuera del alcance de este SP)
```

**Resultado esperado:** `RETURN 0` — `o_Conexion=NULL` (verificado 2026-08-27; la operacion delega completamente a `sp_proc_giros01`, que no establece `@o_Conexion`).

**Trazabilidad por DB:**
- `cob_giros..cg_giros_swiftnok` — SELECT (sin cambios directos desde `sp_proc_giros`)

---

### TC43 — Validacion de repetido para OFAC (operacion V) con giro existente

| Campo | Detalle |
|-------|---------|
| **@i_operacion** | `'V'` |
| **@i_transferencia** | `'5780801099'`  -- giro real existente, courier 108 |
| **@i_tipo** | `null` |
| **Regla** | RN-02 |
| **fuente_valor** | sybase_select (ejecutado real) |

#### Plantilla de ejecucion del SP

```sql
DECLARE @return_code int, @o_repOFAC int
EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'V', @i_courier = '108', @i_transferencia = '5780801099',
     @i_tipo = NULL, @o_repOFAC = @o_repOFAC OUT
SELECT @return_code AS return_code, @o_repOFAC AS o_repOFAC
```

**PRE — Estado requerido en BD:**
```sql
SELECT gg_estado FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = '5780801099'
-- Verificado real: el giro existe (gg_estado='A')
```

**POST — Validaciones en BD:**
```sql
SELECT gg_estado FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = '5780801099'
-- Condicion real observada: sin cambios (operacion de solo lectura)
```

**Resultado esperado:** `RETURN 0` — `o_repOFAC=1` (verificado 2026-08-27, repetido confirmado).

**Trazabilidad por DB:**
- `cob_giros..cg_giro` — SELECT (sin cambios, confirmado)

---

## GRUPO 8 — Reforzamiento de robustez y validacion de datos invalidos

### TC44 — Validacion de datos invalidos de entrada (11 subcasos atomicos, ejecutados en ambiente real)

> **Nota de ejecucion (2026-09-09)**: los subcasos se ejecutaron realmente contra `sp_proc_giros` (courier `108`/`036`, `.venv` + `config/coneccion.py`, `@s_date`/`@i_fecha='2026-09-09 09:00:00'` para evitar el defecto de "fecha diferida" documentado en el header). Todos parten de la misma plantilla base (identica a la usada en TC21/TC23/TC26/TC27: `@i_ben_nombre1='MARIA'`, `@i_ben_nombre2='ELENA'`, `@i_ben_ape1='PEREZ'`, `@i_ben_ape2='LOPEZ'`, `@i_rem_nombre1='JUAN'`, `@i_rem_nombre2='CARLOS'`, `@i_rem_ape1='GOMEZ'`, `@i_rem_ape2='DIAZ'`, `@i_nombrebcompleto=2`, `@i_numero_id='0912345678'`, `@i_pais=1`, `@i_provincia=9`, `@i_ciudad=1`, `@i_SecCabecera=12883294`, `@i_tipo='F'`) variando **unicamente** el campo bajo prueba en cada subcaso.
>
> **Subcasos excluidos (2026-09-09)**: `TC44d`, `TC44e`, `TC44f`, `TC44g`, `TC44h` y `TC44k` se eliminaron de este entregable. Todos compartian la misma ruta de codigo (`@i_cta_origen` nulo/vacio/'0' + `@i_nombrebcompleto=2` → invoca `sp_verificacion_automatica`) y fallaban de forma reproducible con un error real de infraestructura (`Attempt to insert NULL value into column 'ts_secuencial', table 'cobis.dbo.cl_tran_servicio'`), confirmado tambien al reproducir el escenario exacto de `TC27` (exitoso el 2026-08-27) con fecha actual. Al no depender del campo bajo prueba (numero_id/cta_origen/ben_nombre1), no aportaban cobertura diferenciada y se removieron por decision explicita del usuario.

---

#### Subcaso TC44a — Transferencia con valor en blanco (unico espacio)

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `' '` |
| **Regla** | RN-14 |
| **fuente_valor** | analisis (ejecutado real) |

**Plantilla de ejecucion (variacion sobre la base):** `@i_transferencia = ' '`, resto de parametros = base descrita arriba.

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validacion real en BD:**
```sql
SELECT TOP 1 nok_transferencia, nok_motivo FROM cob_giros..cg_giros_swiftnok
WHERE nok_courier = '108' AND nok_transferencia = ' '
ORDER BY nok_secuencia DESC
-- Real: nok_motivo='El giro no tiene No. Transferencia'
```

**Resultado esperado:** `RETURN 0` — ruta tacho confirmada. Sybase trata `' '` (un espacio) como equivalente a `''` por las reglas de comparacion de `varchar` con relleno de blancos; cae en la misma validacion `@i_transferencia is null or @i_transferencia = ''` (no depende de `@i_tipo`). Sin insercion en `cob_giros..cg_giro`.

**Trazabilidad por DB:** `cob_giros..cg_giros_swiftnok` — INSERT confirmado (motivo `'El giro no tiene No. Transferencia'`).

---

#### Subcaso TC44b — Transferencia vacia (cadena vacia)

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `''` |
| **Regla** | RN-14 |
| **fuente_valor** | analisis (ejecutado real) |

**Plantilla de ejecucion (variacion sobre la base):** `@i_transferencia = ''`, resto de parametros = base.

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validacion real en BD:**
```sql
SELECT TOP 1 nok_transferencia, nok_motivo FROM cob_giros..cg_giros_swiftnok
WHERE nok_courier = '108' AND nok_transferencia = ''
ORDER BY nok_secuencia DESC
-- Real: nok_motivo='El giro no tiene No. Transferencia'
```

**Resultado esperado:** `RETURN 0` — ruta tacho confirmada, identico comportamiento a TC44a. Sin insercion en `cg_giro`.

**Trazabilidad por DB:** `cob_giros..cg_giros_swiftnok` — INSERT confirmado.

---

#### Subcaso TC44c — Transferencia compuesta solo por ceros (ejecucion individual, `@i_tipo='F'`)

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'0000000000'` |
| **@i_tipo** | `'F'` (ejecucion individual; complementa TC24 que cubre la misma condicion en ruta batch con `@i_tipo=NULL`) |
| **Regla** | RN-14 |
| **fuente_valor** | analisis (ejecutado real) |

**Plantilla de ejecucion (variacion sobre la base):** `@i_transferencia = '0000000000'`, resto = base (incluye `@i_tipo='F'`).

**PRE — Estado requerido en BD:**
```sql
SELECT op_secorden, op_estado FROM cob_giros..cg_orden_pago WHERE op_secorden = 12883294 AND op_estado = 'P'
```

**POST — Validacion real en BD:**
```sql
SELECT COUNT(1) AS filas FROM cob_giros..cg_giro WHERE gg_courier = '108' AND gg_transferencia = '0000000000'
-- Real: 0 filas
SELECT COUNT(1) AS filas FROM cob_giros..cg_giros_swiftnok WHERE nok_courier = '108' AND nok_transferencia = '0000000000'
-- Real: 0 filas (el RETURN 1 aborta antes de cualquier INSERT)
```

**Resultado esperado:** `RETURN 1` — **excepcion SQL real lanzada**: `El giro tiene No. Transferencia solo 0` (via `cobis..sp_cerror`, `@i_num=999999`). A diferencia de TC24 (ruta batch, `@i_tipo=NULL`, tacho silencioso con `RETURN 0`), la ruta "Front-End" (`@i_tipo` no nulo) **aborta con error real** en lugar de enrutar a `cg_giros_swiftnok`. Confirmado: sin insercion en `cg_giro` ni en `cg_giros_swiftnok`.

**Trazabilidad por DB:** ninguna tabla modificada (fallo antes de cualquier INSERT).

---

#### Subcaso TC44d — Agencia de courier valida pero de otro courier

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QA0909I2'` |
| **@i_courier** | `'108'` |
| **@i_agencia_courier** | `'3601'` (agencia real, pero pertenece al courier `'036'`, no a `'108'`) |
| **Regla** | RN-15 |
| **fuente_valor** | analisis (ejecutado real) |

**PRE — confirmado en BD:** `'3601'` existe en `cobis..cl_catalogo` (tabla `sv_agencia_courier`) pero asociado al courier `'036'`.

**POST — Validacion real en BD:**
```sql
SELECT nok_transferencia, nok_motivo FROM cob_giros..cg_giros_swiftnok
WHERE nok_courier = '108' AND nok_transferencia = 'QA0909I2'
-- Real: nok_motivo='No existe agencia asignada al correspons' (truncado, columna varchar(40))
```

**Resultado esperado:** `RETURN 0` — ruta tacho confirmada, mismo motivo que TC25 (validado por `substring(@i_agencia_courier,1,datalength(@i_courier)) <> @i_courier`), ahora con una agencia real de otro courier en vez de una inexistente.

**Trazabilidad por DB:** `cob_giros..cg_giros_swiftnok` — INSERT confirmado.

---

#### Subcaso TC44e — Punto de pago sin registro vigente

| Campo | Detalle |
|-------|---------|
| **@i_transferencia** | `'QA0909J2'` |
| **@i_courier** | `'036'` (`gp_valida_cu='S'`, activa validacion de punto de pago) |
| **@i_agencia_courier** | `'3601'` |
| **@i_pto_pago_org** | `'ZZZ9999999'` (sin registro vigente) |
| **Regla** | RN-24 |
| **fuente_valor** | analisis (ejecutado real) |

**PRE — confirmado en BD:** `gp_valida_cu='S'` para courier `'036'`; `'ZZZ9999999'` no existe en `cob_giros..cg_m_punto_pago`.

**POST — Validacion real en BD:**
```sql
SELECT nok_transferencia, nok_motivo FROM cob_giros..cg_giros_swiftnok
WHERE nok_courier = '036' AND nok_transferencia = 'QA0909J2'
-- Real: nok_motivo='Codigo de Localidad Invalido'
```

**Resultado esperado:** `RETURN 0` — ruta tacho confirmada con el motivo exacto previsto por codigo.

**Trazabilidad por DB:** `cob_giros..cg_giros_swiftnok` — INSERT confirmado.

---

## PARAMETROS DE SESION POR DEFECTO (verificados contra BD real)

| Parametro | Valor por defecto | Descripcion | Varia por TC |
|---|---|---|---|
| **@s_ssn** | `1` | Identificador de sesion de prueba | No |
| **@s_user** | `'qauser1'` | Usuario de pruebas QA | No |
| **@s_term** | `'TERM01'` | Terminal de pruebas | No |
| **@s_date** | `'2026-08-27 09:00:00'` | Fecha de sistema (coincide con `getdate()` real del servidor) | No — solo `@i_fecha` varia en el grupo de ventana de 10 dias |
| **@s_ofi** | `1` | Oficina | No |
| **@s_rol** | `100` | Rol estandar sin excepcion | Si (`179`, real, para reingreso de giro anulado) |
| **@t_debug** | `'N'` | Modo debug apagado | No |
| **@t_trn** | `3488` | Codigo de transaccion unico aceptado | Si (rechazo por codigo invalido) |
| **@i_operacion** | `'D'` | Enrutamiento principal del SP (C/D/M/S/V) | Si (segun grupo) |
| **@i_courier** | `'108'` | Courier real, `gp_valida_cu='N'` | Si (`'36'` para grupo punto de pago/agente; `'83'`, `'12R'` para casos especificos) |
| **@i_agencia_courier** | `'10801'` | Agencia real vigente de courier 108 | Si (`'3601'` para courier 36) |
| **@i_transferencia** | variable por TC (prefijo `QA2608NN`, verificado sin colision real) | Numero de transferencia unico por caso | Si |
| **@i_referencia** / **@i_autorizacion** | `'REF00001'` / `'AUT00001'` | Datos de referencia | No |
| **@i_moneda** | `1` | Activa evaluacion de red BB/agente pagador (RN-20) | No |
| **@i_monto_recibido** / **@i_monto_pagar** | `100.00` / `100.00` | Montos del giro (RN-10) | Si (fronteras de monto) |
| **@i_ben_nombre1** | `'MARIA'` | Nombre 1 del beneficiario | Si (fronteras de nombre) |
| **@i_ben_nombre2** | `'ELENA'` | Nombre 2 del beneficiario | Si (fronteras de nombre) |
| **@i_ben_ape1** | `'PEREZ'` | Apellido 1 del beneficiario | Si (fronteras de nombre) |
| **@i_ben_ape2** | `'LOPEZ'` | Apellido 2 del beneficiario | Si (fronteras de nombre) |
| **@i_rem_nombre1** | `'JUAN'` | Nombre 1 del remitente | No |
| **@i_rem_nombre2** | `'CARLOS'` | Nombre 2 del remitente | No |
| **@i_rem_ape1** | `'GOMEZ'` | Apellido 1 del remitente | No |
| **@i_rem_ape2** | `'DIAZ'` | Apellido 2 del remitente | No |
| **@i_fecha** | `'2026-08-27 09:00:00'` | Fecha del giro | Si (fronteras de ventana de 10 dias) |
| **@i_pais** | `1` | Pais, verificado en `cobis..cl_ciudad` | Si (courier 36 con `gp_valida_cu='S'` recalcula ciudad/provincia desde `cg_m_punto_pago`) |
| **@i_provincia** | `9` | Provincia Guayaquil, verificado en `cobis..cl_ciudad` (`ci_provincia=9`) | Si (courier 36 con `gp_valida_cu='S'` recalcula ciudad/provincia desde `cg_m_punto_pago`) |
| **@i_ciudad** | `1` | Ciudad Guayaquil, verificado en `cobis..cl_ciudad` (`ci_ciudad=1`) | Si (courier 36 con `gp_valida_cu='S'` recalcula ciudad/provincia desde `cg_m_punto_pago`) |
| **@i_nombrebcompleto** | `2` | Cantidad de palabras del nombre de beneficiario (RN-13) | Si (fronteras) |
| **@i_SecCabecera** | `12883294` | `op_secorden` real, cabecera abierta (`op_estado='P'`) courier 108 | Si (`12883297`/`12883298` courier 36; `12883299` para cuadre TC42) |
| **@i_tipo** | `'F'` | Origen Front-End (retorno de error explicito en vez de tacho) | Si (casos batch usan `null`) |
| **@i_ofac** / **@i_tipo_ofac** | `0` / `null` | Sin marca OFAC | Si (grupo OFAC) |
| **@i_bloqueado** | `'0'` | Corresponsal no bloqueado | Si (grupo bloqueo) |
| **@i_cta_origen** / **@i_tipo_pago** | `null` / `null` | Sin cuenta origen ni tipo de pago especial | Si (grupo rutas de credito) |
| **@i_numero_id** | `'0912345678'` | Cedula valida de 10 digitos (RN-17) | Si (fronteras de longitud) |
| **@i_numero_bce** | `null` | Ruta local (no SPI) por defecto | Si (grupo rutas SPI) |
| **@i_pto_pago_org** | `' '` | Sin validacion de punto de pago por defecto | Si (`'BNF00601'` real vigente para grupo agente pagador) |
| **@i_gpi_tracker** | `'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX'` | Sentinela GPI por defecto | Si (TC43) |
| **@e_canal_reg** | `''` | Canal no-API por defecto | Si (no ejercido en este lote) |

#### Plantilla de ejecucion del SP (base, real)

```sql
DECLARE @return_code   int,
        @o_Conexion    char(2),
        @o_SecCabecera int,
        @o_repOFAC     int,
        @o_indAnula    char(1)

EXEC @return_code = cob_giros..sp_proc_giros
     @s_ssn = 1, @s_user = 'qauser1', @s_term = 'TERM01', @s_date = '2026-08-27 09:00:00',
     @t_debug = 'N', @t_trn = 3488, @i_operacion = 'D', @i_courier = '108',
     @i_agencia_courier = '10801', @i_transferencia = '<VAR>',
     @i_referencia = 'REF00001', @i_autorizacion = 'AUT00001', @i_moneda = 1,
     @i_monto_recibido = 100.00, @i_monto_pagar = 100.00,
     @i_ben_nombre1 = 'MARIA', @i_ben_nombre2 = 'ELENA', @i_ben_ape1 = 'PEREZ', @i_ben_ape2 = 'LOPEZ',
     @i_rem_nombre1 = 'JUAN', @i_rem_nombre2 = 'CARLOS', @i_rem_ape1 = 'GOMEZ', @i_rem_ape2 = 'DIAZ',
     @i_rem_tel = '0999111111', @i_ben_dir = 'AV PRINCIPAL 123', @i_ben_tel = '0999222222',
     @i_fecha = '2026-08-27 09:00:00', @i_pais = 1, @i_provincia = 9, @i_ciudad = 1,
     @i_ciudadpago = 'GUAYAQUIL', @i_nombrebcompleto = 2, @i_SecCabecera = 12883294,
     @i_tipo = 'F', @i_servicio = 'V', @i_ofac = 0, @i_tipo_ofac = NULL, @i_bloqueado = '0',
     @i_valid = 'S', @i_cta_origen = NULL, @i_tipo_pago = NULL, @i_tipo_id = 'C',
     @i_numero_id = '0912345678', @i_numero_bce = NULL, @i_cod_resp = 0,
     @i_pto_pago_org = ' ', @i_gpi_tipo = '000',
     @i_gpi_tracker = 'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX', @e_canal_reg = '', @e_valida_cupo = 'S',
     @o_Conexion = @o_Conexion OUT, @o_SecCabecera = @o_SecCabecera OUT,
     @o_repOFAC = @o_repOFAC OUT, @o_indAnula = @o_indAnula OUT

SELECT @return_code AS return_code, @o_Conexion AS o_Conexion, @o_SecCabecera AS o_SecCabecera, @o_repOFAC AS o_repOFAC, @o_indAnula AS o_indAnula
```

Cada TC declara unicamente los parametros que cambian respecto a esta plantilla (`**@parametro**`).

---

---

---

## TABLAS MONITOREADAS

| Tabla | Descripcion de operacion |
|---|---|
| `cob_giros..cg_orden_pago` | Cabecera de lote/orden de pago (INSERT en operacion C; UPDATE de acumulacion en operacion D) |
| `cob_giros..cg_giro` | Registro principal del giro (INSERT en operacion D exitosa) |
| `cob_giros..cg_pago` | Detalle de pago del giro, incluye estado GPI y punto de pago (INSERT en operacion D exitosa) |
| `cob_giros..cg_giros_swiftnok` | Tacho de giros con problemas de ingreso (INSERT en toda ruta de rechazo batch; UPDATE de estado al reingresar) |
| `cob_giros..cg_courier` | Configuracion de riesgo/notificacion por corresponsal (`co_envio_mail`, `co_bloq_aut`) |
| `cob_giros..cg_informacion_riesgo` | Exposicion de riesgo por corresponsal (deudora, pendientes, pagados, anulados, acreedora, transferencia) |
| `cob_giros..cg_t_giro_notificacion` | Notificaciones de sobregiro/bloqueo generadas por el motor de riesgo |
| `cob_giros..cg_t_giro_pendiente` | Pendientes de confirmacion para canal API |
| `cob_giros..cg_d_giros_adicional` | Actualizacion de secorden cuando el giro sale del tacho via canal API |
| `cob_giros..cg_parametros` | Configuracion de validacion de punto de pago por courier (`gp_valida_cu`) |
| `cob_giros..cg_m_punto_pago` | Catalogo de puntos de pago vigentes |
| `cob_giros..cg_agente_pagador` / `cg_local_agepag` | Catalogo de agentes pagadores y tope de monto autorizado |
| `cob_cuentas_his..cg_giro_his` | Historico de giros, usado para bloquear reingreso de transferencias ya procesadas |
| `cobis..cl_tabla` / `cobis..cl_catalogo` | Catalogos genericos: `cg_roles_excepcion`, `sv_agencia_courier`, `cg_agente_pagador`, `cg_monto_aut_agente`, `cl_consep_ecuagiro` |
| `cobis..cl_parametro` | Parametro `CUPCNE` (cupo de credito asignado por defecto, real=10000.00) |
| `cobis..cl_ciudad` / `cobis..cl_provincia` | Catalogo real de ciudades/provincias (Guayaquil=1, provincia=9) usado por `sp_inserta_persona` |
| `cob_cuentas..cc_dias_laborables` | Dias laborables para calculo de fecha diferida |

---

---

## TABLAS MONITOREADAS POR SPs HIJOS

`NO_APLICA` — el analisis estructural (Seccion 7, contrato de libreria por SP hijo) documenta los escenarios de contrato de `sp_inserta_persona`, `pa_ecu_tverf_cupoemp`, `pa_ecu_anotifica_uc`, `pa_ecu_tvalidaspi`, `sp_verificacion_automatica`, `pa_ecu_tvalidacredito`, `sp_bloqueo_carga`, `sp_mod_alerta_cour` y `sp_proc_giros01`, pero sus tablas internas no fueron verificadas en este documento por no formar parte del cuerpo activo de `sp_proc_giros`. Excepcion: se documento un conflicto de tipos `BIGINT`/`VARCHAR` detectado en una corrida anterior al invocar `sp_verificacion_automatica` desde la ruta `@i_operacion='M'`; al re-verificar no se reprodujo (ver nota historica en TC41).

---

---

## DICCIONARIO SP-REST

Pendiente: se generara con agente-qa-auto-04-test-cases-config una vez exista el codigo Java del microservicio.

---

## EJECUCION POR GRUPOS

<!-- DUMMY generado por validate_external_tc.py — revisar y completar manualmente. -->
<!-- SP que MUTA BD: definir aislamiento de cuentas/ordenes por lote antes de correr en paralelo (ver V-GRP-01). NO ejecutar en paralelo hasta completar. -->

| Lote | Grupos |
|------|--------|
| 1 | PENDIENTE-definir-aislamiento |

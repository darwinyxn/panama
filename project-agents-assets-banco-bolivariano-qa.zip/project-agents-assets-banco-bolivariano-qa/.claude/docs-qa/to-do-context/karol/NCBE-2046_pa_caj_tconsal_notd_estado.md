# NCBE-2046 — cob_atm.pa_caj_tconsal_notd — ESTADO / TO-DO CONTEXT

> **ACTUALIZACIÓN 2026-10-01 (handoff de cambio de motor/sesión).** Este documento se reescribe
> completo para reflejar TODO el recorrido de la sesión que llevó la ME de "en pausa esperando
> Banco" (ver versión anterior más abajo, preservada como historial en la sección 9) hasta el
> cierre real 49/49 EQUIVALENTE. **IMPORTANTE — leer la sección 8 antes que nada:** otra
> sesión/persona ya cerró formalmente este ticket el 2026-09-30 (ME, QMetry, Jira), pero con una
> explicación de `at_ruteo` DISTINTA a la que esta sesión encontró con evidencia directa. Ambas
> versiones quedan documentadas sin resolver cuál prevalece — eso requiere una decisión humana.

## 1. Contexto del micro

- **Ticket (HU):** NCBE-2046
- **Microservicio:** `atm-mso-consulta-saldo-quickpay`
- **SP legacy:** `cob_atm.pa_caj_tconsal_notd`
- **Repo micro:** https://github.com/bb-soporte-atm/atm-mso-consulta-saldo-quickpay.git
- **Repo infra:** https://github.com/bb-soporte-atm/atm-infra-soporte-tecnologico-atm.git
- **Rama OpenShift:** `openshift/bb-cajero-automatico/atm-mso-consulta-saldo-quickpay/develop-dvp`
- **Project OCP:** `bb-dev-core`
- **Responsable Banco:** Danny Quimís Briones (dquimis@bolivariano.com)
- **Librerías hermanas** (mismo paquete, repo `bb-core-cob-atm-utils`, NO parte de esta ME): NCBE-2047 a NCBE-2052.

## 2. Insumo QA (rutas vigentes)

Desviación ya establecida para este SP: la carpeta usa el nombre del **microservicio**, no el del SP:

- Documento crudo de Banco: `.claude/docs-qa/inputs/documents/atm-mso-consulta-saldo-quickpay/test-cases-banco/casos_prueba_pa_caj_tconsal_notd.md`
- Scaffold/documento final: `.claude/docs-qa/inputs/documents/atm-mso-consulta-saldo-quickpay/auto/qa_casos_prueba.md` (CONFIG + DICCIONARIO SP-REST completos, 49 TCs)
- Resultado final de ejecución (en `agents-qa`, comiteado y pusheado): `.claude/docs-qa/results/atm-mso-consulta-saldo-quickpay-28-09-2026-1720/` → **49/49 EQUIVALENTE**
- Otros documentos de esta sesión en esta misma carpeta `to-do-context/karol/`: `NCBE-2046-pa_caj_tconsal_notd-hallazgos-pendientes-banco.md` (ver sección 8)

## 3. Línea de tiempo completa de esta sesión

1. **09-sep (antes de esta sesión):** primeras corridas (2116→2212) con bug de motor (`cl_errores.json` ausente). Resultado: 44 SYBASE_ERROR / 1 SYBASE_FAIL / 4 EQUIVALENTE de 49.
2. **14/16-sep:** causa raíz de los 44 SYBASE_ERROR encontrada: `@e_trn` (int, sin validar) fuera del rango `smallint` de `at_ruteo.rt_trn`. Reportado a Banco; Banco corrigió rango (16000-16999) pero en la primera reentrega solo aplicó fixes puntuales (TC15/16/30/47), no el rango de `e_trn`.
3. **16/17-sep:** segundo seguimiento a Banco listando los 45 TCs a corregir. Pausa esperando reentrega.
4. **23/24-sep:** Banco reentrega con `e_trn=16074/16073` (válido) pero **sobreescribe sin pedírselo** TC18-TC21 (que ya estaban bien, con valores especiales 16259-16262 que activan una condición hardcodeada del SP, L278: `if @e_trn not in (16260,16261)`). Se corrige manualmente en la copia de trabajo (revertido a los valores originales) y se le avisa a Banco (no era necesario que reentregaran, solo que alineen su documento maestro).
5. **24-sep:** se descubre y se sigue el nuevo modelo de trabajo (`2.FLUJO-DE-TRABAJO-QA-PASO-A-PASO.md`): primera pasada en `agents-qa`, traspaso único al repo del micro, Agente 05 siempre en el repo del micro. Se hace el traspaso. Loop 02↔03 (rondas 5-6) cierra en 0 FAIL / 49 WARN sobre el documento trasladado.
6. **24-sep:** Agente 04 completa CONFIG (`base_url`, `endpoint`) y DICCIONARIO SP-REST. Primera corrida real post-traspaso: 0 EQUIVALENTE, 49 INCONSISTENCIA / 1 NO_EQUIVALENTE (TC43) — por 3 causas sistemáticas + 1 hallazgo aparte:
   - `at_ruteo`: SP inserta, REST no refleja el insert (**ver sección 8 — resolución en disputa**).
   - `mensaje_debug`: el motor compara contra el "crudo" (`mensaje_debug_raw`, siempre `None` para este SP) en vez del mensaje ya traducido por catálogo — fix NCBE-1178 (23-sep, para OTRO SP) causando falso positivo aquí.
   - TC43: `@e_valor` en el límite teórico de `money` (922,337,203,685,477.60) — valor no realista.
7. **28-sep:** Banco confirma (vía Jira): (a) `at_ruteo` sí debía ser equivalente [nota: esto se usó para el hallazgo documentado abajo, antes de la investigación de servidor] y (b) `@e_valor` para este flujo (consulta de saldo, sin débito/crédito) **siempre es 0** — se corrige TC43. Se corrige también TC02 (cuenta mal clasificada como AHO, en realidad es CTE — ver `cob_cuentas..cc_ctacte`).
8. **28-sep (esta sesión, investigación propia):** se encuentra que el motor compara `at_ruteo` conectándose a Sybase en `172.16.31.99` (`sybasedvp1`), mientras el microservicio desplegado conecta a `172.16.31.91` (confirmado via ConfigMap real de OpenShift). Verificado manualmente: `at_ruteo` en `.91` SÍ tiene filas reales que coinciden con los datos de prueba de esta sesión (cajero=`ATM0001`, trn=`16074`). **Conclusión de esta sesión: `at_ruteo` NO es un defecto del micro, es un error de la herramienta QA (servidor Sybase equivocado).**
9. **28-sep:** con `SYBASE_HOST=172.16.31.91` + el parche local de `mensaje_debug` (`contenido-canonico`, agregado a la copia LOCAL de `execute_all.py` en el repo del micro, NUNCA propagado a `agents-qa` por instrucción explícita del usuario) + corrección de un bug adicional encontrado (`grpc_host` con texto largo en vez de quedar vacío, causaba intento fallido de gRPC) → **corrida final: 49/49 EQUIVALENTE**, carpeta `pa_caj_tconsal_notd-28-09-2026-1720` (luego renombrada).
10. **29-sep:** se envía a Banco un mensaje retractando `at_ruteo` como defecto del micro (explicando que fue error de nuestra herramienta). Extracción de evidencia a `agents-qa` (commit `e97e083`). Se descubre y reporta a Karol el problema de identidad git (commits quedaban firmados como "Adrián Pabón Mendoza", no como Karol Franco — sin resolver aún, ver sección 7).
11. **29-sep:** Gestor QA (Supabase) — se finalizan 3 tareas de Karol Sthefania Franco: "Generación de ME", "Validación de TCs", "Cargar TCs en Gestor QA" (49 testCases creados). Se corrige el historial de una tarea para que cuente en el indicador de Eficiencia (pasar por `review` antes de `done`).
12. **29-sep:** se renombra la carpeta de resultados final a nombre del micro (`atm-mso-consulta-saldo-quickpay-28-09-2026-1720`) y se eliminan 14 carpetas de corridas viejas/intermedias en ambos repos (confusión). Commit `f57806d` pusheado.
13. **29-sep:** se intenta la carga a QMetry (primera carga completa) vía `qmetry-agente-qa-orquestador` — **bloqueado**: los 7 agentes de QMetry no aparecen en la lista de agentes disponibles de esta sesión, aunque sus archivos `.claude/agents/qmetry-agente-qa-*.md` existen intactos. Causa probable encontrada: encabezado desactualizado (`model: claude-4.6-opus`, identificador que ya no existe; falta campo `description`) — hipótesis no confirmada, fix no aplicado (pendiente autorización del usuario).
14. **30-sep (otra sesión, ver sección 8):** según `hallazgos-pendientes-banco.md`, alguien más cerró QMetry (cycle `NCBE-TR-39`, 49/49) y confirmó cierre en Jira — sin que esta sesión participara ni viera cómo se resolvió el bloqueo de los agentes de QMetry.

## 4. Causas raíz encontradas y su resolución (resumen técnico)

| # | Problema | Causa raíz | Resolución | Dónde vive el fix |
|---|---|---|---|---|
| 1 | 44 SYBASE_ERROR (09-sep) | `@e_trn` fuera de rango `smallint` de `at_ruteo.rt_trn` | Banco corrigió a 16074/16073 | Documento de Banco |
| 2 | TC18-21 rotos tras reentrega | Banco sobreescribió valores que no debía tocar | Revertido manualmente a 16259-16262 | `auto/qa_casos_prueba.md` (copia de trabajo, no en el doc crudo de Banco) |
| 3 | `s_autorizacion` NULL vs `""` | Comparación `exacta` no toleraba la normalización real del SP | Cambiado a modo `presencia` en DICCIONARIO | `auto/qa_casos_prueba.md` |
| 4 | `mensaje_debug` falso positivo | Motor compara contra crudo (`mensaje_debug_raw`), fix NCBE-1178 para otro SP | Variante `contenido-canonico` agregada | **Motor LOCAL del repo del micro únicamente** (se borra con cada sync del Paso 0.5 del Agente 05 — hay que reaplicarlo si se vuelve a correr) |
| 5 | TC43 valor irreal | `@e_valor` en límite teórico de `money`, no un escenario real | Banco confirmó `@e_valor=0` siempre | `auto/qa_casos_prueba.md` |
| 6 | TC02 cuenta mal clasificada | Etiquetada como AHO, es CTE (`cc_ctacte`) | PRE/etiqueta corregidos | `auto/qa_casos_prueba.md` |
| 7 | `at_ruteo` sin reflejo en REST | **En disputa, ver sección 8** | **En disputa** | — |
| 8 | gRPC fallaba sin razón aparente | `grpc_host` tenía texto descriptivo largo en vez de quedar vacío; el parser de `execute_all.py` solo reconoce vacío real, no el placeholder `—` con texto adicional | Celda vaciada en CONFIG | `auto/qa_casos_prueba.md` |
| 9 | Microservicio real inalcanzable (REST) | `/etc/hosts` sin entrada para la Route de OpenShift | Entrada agregada (`172.16.6.107`) + luego `oc port-forward` a `localhost:18443` (Host header del micro solo acepta `localhost`/`127.0.0.1`) | `/etc/hosts` + proceso de port-forward (efímero, hay que relevantarlo cada sesión) + `qa_port_forward_base_url` en CONFIG |
| 10 | Sybase inalcanzable por nombre | DNS no resuelve `sybasedvp1` | Bloque `[sybasedvp1]` en `~/.freetds.conf` (ya existía) | Config local de la EC2 |

## 5. Veredicto final confirmado por esta sesión

**49/49 EQUIVALENTE** — corrida `atm-mso-consulta-saldo-quickpay-28-09-2026-1720` (renombrada), comiteada y pusheada a `agents-qa` (`origin/master`, commits `e97e083` y `f57806d`).

## 6. Pendiente real no resuelto por esta sesión: agentes de QMetry

Los 7 agentes `qmetry-agente-qa-*` no aparecen en la lista de agentes disponibles de esta sesión de Claude Code (error "Agent type not found"), pese a que sus archivos existen sin cambios en `.claude/agents/`. Hipótesis (no confirmada): encabezado con `model: claude-4.6-opus` (identificador de modelo obsoleto, no existe en la línea Claude 5 actual) y sin campo `description` — a diferencia de todos los demás agentes que sí funcionan. Fix propuesto (no aplicado, pendiente autorización): actualizar el encabezado de esos 7 archivos a `model: opus` + agregar `description`. Si la sesión que cerró QMetry el 30-sep (sección 8) tuvo este mismo problema y lo resolvió, documentar cómo para las próximas sesiones.

## 7. Pendiente real no resuelto: identidad de git

Esta máquina tiene configurado git con la identidad de **Adrián Pabón Mendoza** (`18635675+adrianpabon@users.noreply.github.com`), no la del usuario real de esta sesión (**Karol Franco**, email real en Gestor QA: `karol.franco@nyxn.io`). Todos los commits de esta sesión (`e97e083`, `f57806d`) quedaron firmados como Adrián. No se corrigió — quedó pendiente de decisión del usuario (¿corregir `git config` hacia adelante? ¿reescribir el historial ya pusheado con `--amend`+`--force`, operación delicada en `master` compartido?).

## 8. ⚠️ DISCREPANCIA SIN RESOLVER — leer antes de tocar `at_ruteo` otra vez

El archivo `.claude/docs-qa/to-do-context/karol/NCBE-2046-pa_caj_tconsal_notd-hallazgos-pendientes-banco.md`
fue actualizado (aparentemente por otra sesión/persona, el 2026-09-30 — esta sesión no participó en
ese cambio) con una nota de cierre que dice:

- Banco confirmó que `at_ruteo` **"NO aplica"** al micro (se documentó como escritura esperada
  SOLO del lado SP, el REST queda exento de esa verificación).
- QMetry (`cycle NCBE-TR-39`) cargado y verificado 49/49.
- Cierre confirmado en Jira **`NCBE-2202`** (no `NCBE-2046` — posible typo del otro documento, o un
  ticket distinto relacionado; no verificado por esta sesión).

**Esto es DISTINTO a lo que esta sesión encontró con evidencia directa** (sección 3, punto 8):
que el microservicio SÍ escribe en `at_ruteo`, solo que en el servidor Sybase real
(`172.16.31.91`), no en el que usa por defecto la herramienta QA (`172.16.31.99`/`sybasedvp1`).

**No se intentó reconciliar ambas versiones en esta sesión.** Es posible que:
(a) la otra sesión no conociera el hallazgo del servidor y haya tomado el camino más simple
(preguntarle a Banco y marcar `IGNORAR`), sin que eso sea necesariamente incorrecto como decisión
de negocio — o (b) haya alguna razón por la que el hallazgo de esta sesión no aplique en el
contexto en que ellos corrieron la matriz. **Se deja esta nota para que quien continúe decida cuál
versión documentar como la real, en vez de que esta sesión lo sobreescriba unilateralmente.**

## 9. Historial — versión de este documento previa a esta actualización (preservado)

> (Correspondía al estado de la sesión el 2026-09-17, cuando la ME estaba en pausa esperando la
> primera reentrega de Banco. Todo lo descrito ahí ya fue superado por los eventos de las
> secciones 3-5 de arriba; se conserva solo como referencia histórica.)

- Bloqueo de ese momento: 45 `@e_trn` fuera de rango + fila fantasma `@o_offline` en TC15.
- Próximo paso de ese momento: esperar reentrega de Banco. (Ya ocurrió, ver sección 3.)

# Entregables Operativos del Proceso QA

## SP: sp_ahndc_automatica | Microservicio: cpas-mso-genera-nd-nc-automatica-aho

---

## Inventario de Entregables

| # | Entregable | Descripcion | Tiempo estimado | % Impacto | Justificacion |
|---|-----------|-------------|-----------------|-----------|---------------|
| 1 | **Casos de Uso** (`qa_casos_uso.md`) | Documento funcional con CUs, actores, Gherkin. Base para derivar TCs. | 2-3 horas (manual) / 15 min (agente) | 10% | Define el alcance funcional. Sin esto se prueban cosas al azar sin cobertura medible. |
| 2 | **Casos de Prueba** (`qa_casos_prueba.md`) | TCs ejecutables con parametros, PRE/POST, trazabilidad por BD. Insumo del pipeline. | 4-6 horas (manual) / 30 min (agente) | 25% | Es el corazon de la ejecucion. Cada TC mal definido genera falsos positivos/negativos que cuestan horas de analisis. |
| 3 | **Instructivo Preparacion BD** (`INSTRUCTIVO-PREPARACION-BD.md`) | SQL idempotente para dejar la BD en estado conocido antes de cada corrida. | 2-3 horas (manual) / 20 min (agente) | 15% | Sin esto, las corridas no son reproducibles. TC36 falla por estado BD distinto entre pasadas. |
| 4 | **Pipeline automatico** (scripts Python) | `run_qa.py` -> `parse_test_cases.py` -> `generate_payloads.py` -> `execute_all.py` -> `generate_postman.py` | 40+ horas (desarrollo) / 0 (ya esta) | 30% | Reduce una corrida de 45 TCs de 8+ horas manuales a 15 minutos automaticos. Compara campo a campo en 8 tablas. |
| 5 | **Corridas de evidencia** (`QA-CASOS-PARSEADOS.json`) | Resultado con snapshot PRE/POST, deltas, registros nuevos, veredicto por TC. | 15 min por corrida (automatico) | 10% | Es la evidencia trazable que el banco audita. Sin JSON parseado no hay prueba de equivalencia. |
| 6 | **Coleccion Postman** (`QA-POSTMAN.json`) | Payloads REST listos para importar en Postman. | 0 (generado automatico) | 5% | Permite al equipo QA del banco re-ejecutar manualmente cualquier TC sin construir el request. |
| 7 | **Pruebas manuales de hallazgos** (TC62/TC63/TC21b lock) | Validacion manual con lock, constraint, cedula corrupta. Confirma rollback y comportamiento bajo estres. | 1-2 horas por hallazgo | 5% | Lo automatico no cubre lock/timeout reales. La prueba manual encontro el bug de fire-and-forget que la automatica no detecta. |

---

## Contraste de Tiempos: Manual vs Automatizado

| Fase | Sin automatizacion | Con automatizacion | Ahorro |
|------|-------------------|-------------------|--------|
| Escribir CUs + TCs | 8-10 horas | 45 min | 90% |
| Preparar BD | 3 horas | 20 min (una vez) | 87% |
| Ejecutar 45 TCs SP + REST | 8+ horas | 15 min | 97% |
| Analizar resultados | 4 horas | 10 min (JSON con veredicto) | 96% |
| Validar hallazgos manuales | 2 horas | 2 horas (no automatizable) | 0% |
| **Total por corrida** | **25+ horas** | **~3 horas** (primera vez) / **30 min** (re-corrida) | **88%** |

---

## Justificacion por Impacto

### Pipeline automatico (30%)

Es lo que permite re-ejecutar en 15 min despues de cada fix del desarrollador. Sin esto, cada validacion de bug corregido toma medio dia. En la corrida del 27-05-2026, se ejecutaron 45 TCs con paridad campo a campo en 8 tablas en menos de 15 minutos.

### Casos de prueba (25%)

Un TC mal escrito (como TC53 con cedula de 7 digitos) bloquea toda la corrida. La calidad del documento determina si la automatizacion produce resultados confiables o ruido. Un solo dato de prueba invalido genera SYBASE_FAIL que requiere investigacion manual.

### Instructivo BD (15%)

TC36 aparece como "INCONSISTENCIA" en cada corrida porque la cuenta no se restaura al mismo estado entre pasadas SP y REST. Un instructivo incompleto genera falsos positivos que consumen tiempo de analisis y erosionan la confianza en los resultados.

### Casos de uso (10%)

Garantiza cobertura funcional. Sin CUs no sabemos si los 45 TCs cubren todos los flujos del SP o si dejamos ramas sin probar. El analisis de gaps identifico 10 TCs adicionales (GRUPO 8) que cubren escenarios de disponible=0 que el cliente prueba y no estaban cubiertos.

### Evidencia JSON (10%)

Es lo que el banco revisa en auditoria. Cada TC tiene timestamp, snapshot PRE/POST de todas las tablas, deltas calculados, registros nuevos campo a campo, y veredicto. Sin evidencia parseada la prueba no tiene valor formal para el proceso de certificacion.

### Postman (5%)

Conveniencia para el equipo QA del banco que no usa scripts. Permite importar y re-ejecutar cualquier TC desde la interfaz grafica sin conocimiento tecnico del pipeline.

### Pruebas manuales (5%)

Bajo volumen pero alto valor critico. El bug de fire-and-forget (TC62 con lock real) solo se descubrio manualmente — la automatizacion no puede simular locks de tabla. Estos hallazgos son los que evitan incidentes en produccion.

---

## Metricas de la Corrida Vigente

| Metrica | Valor |
|---------|-------|
| Corrida | sp_ahndc_automatica-27-05-2026-1524 |
| Total TCs | 45 |
| EQUIVALENTE | 45 (100%) |
| INCONSISTENCIA | 0 |
| NO_EQUIVALENTE | 0 |
| Tablas monitoreadas | 8 (ah_cuenta, ah_tran_monet, ah_tran_servicio, ah_val_suspenso, cc_monet_transfer, cc_trx_inusuales, ah_linea_pendiente, cc_uif) |
| Bugs solventados verificados | 3 (TC62 lock, TC63 rollback, TC21b codigo error) |
| Tiempo de ejecucion | ~15 min (batch 1/2 + 2/2) |

---

## Flujo Operativo

```
[1] Casos de Uso (qa_casos_uso.md)
         |
         v
[2] Casos de Prueba (qa_casos_prueba.md)
         |
         v
[3] Instructivo BD (INSTRUCTIVO-PREPARACION-BD.md)
         |
         v
[4] Pipeline Automatico (run_qa.py)
    |-- Reset BD
    |-- Parse TCs
    |-- Generate Payloads
    |-- Execute SP (batch)
    |-- Reset BD (inter-pasada)
    |-- Execute REST (batch)
    |-- Compare campo a campo
    |-- Generate Postman
         |
         v
[5] Evidencia (QA-CASOS-PARSEADOS.json + QA-POSTMAN.json)
         |
         v
[6] Analisis de hallazgos (manual si hay INCONSISTENCIA/NO_EQUIVALENTE)
         |
         v
[7] Reporte al desarrollador + re-corrida post-fix
```

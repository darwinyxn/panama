# Casos de uso por SP - sp_cont_impuesto

## 0. Indice por Caso de Uso

| CU | Nombre |
|----|--------|
| CU-01 | Rechazo por transaccion no permitida |
| CU-02 | Contabilizar IVA - Cuentas Corrientes (CTE) |
| CU-03 | Contabilizar IVA - Ahorros (AHO) |
| CU-04 | Contabilizar IVA - Virtuales/Basica (VIR/BAS) |
| CU-05 | Contabilizar IVA - Recaudacion PAYK (causal 11/10) |
| CU-06 | Contabilizar IVA - Recaudacion RECA |
| CU-07 | Contabilizar IVA - Transferencia exterior y Emision cheque |
| CU-08 | Contabilizar IVA - Transaccion sin registro IVA |
| CU-09 | Contabilizar IVA con reversa |
| CU-10 | Devolucion damnificado - canal VEN, cuenta no existe |
| CU-11 | Devolucion damnificado - canal CNB (homologacion oficina) |
| CU-12 | Devolucion anulada por cuenta existente |
| CU-13 | Devolucion - Bypass certificacion cheque |
| CU-14 | Edge case - Canal devolucion activa con cta_deb vacia |
| CU-15 | Error en INSERT principal - fallo persistencia |
| CU-16 | Error en INSERT devolucion - estado inconsistente |
| CU-17 | Error en registro IVA - sp_registra_trx_iva falla |
| CU-18 | Mecanismo de error alternativo |
| CU-19 | Derivacion de canal desde usuario |
| CU-20 | Error guessing - Producto no reconocido y multicanal |

---

## 1. Introduccion del SP

| Campo | Valor |
|-------|-------|
| Nombre del SP | sp_cont_impuesto |
| Proceso de negocio | Contabilizacion de impuesto IVA para transacciones de servicio por producto financiero |
| Descripcion general del SP | Registra transacciones de servicio de impuesto por tipo de producto (CTE, AHO, VIR/BAS), calcula devolucion damnificado cuando aplica, y opcionalmente registra o reversa el IVA en `cob_remesas` mediante `sp_registra_trx_iva`. |
| Sistemas involucrados | `cob_cuentas`, `cob_ahorros`, `cob_virtuales`, `cob_remesas`, `cob_gov`, `cobis` |

---

## 2. Bloques de Caso de Uso

### CU-01 - Rechazo por transaccion no permitida

#### a. Proposito

Verificar que el sistema rechaza con error 99999 cualquier transaccion cuyo codigo no pertenece a la lista de codigos permitidos.

#### b. Alcance

- Que incluye: validacion funcional del codigo de transaccion y mecanismo de reporte de error.
- Que no incluye: contabilizacion exitosa, devolucion damnificado, reversa IVA o inserciones en tablas transaccionales.

#### c. Actores

- Canal invocante.
- Sistema de errores `cobis..sp_cerror`.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Codigo de transaccion | Codigo no incluido en la lista permitida. |
| Indicador aplica Cobis | Define si el error se reporta por `sp_cerror` o por mensaje de salida. |

#### f. Precondiciones

- El codigo de transaccion no pertenece a la lista permitida: 3188, 3484, 3497, 3793, 3721, 3471, 4188, 4283, 4284, 43083, 43084, 43085, 43087, 43088, 4189, 120049, 120050, 120061, 120072, 120094, 120161.

#### g. Postcondiciones

- El sistema retorna codigo 99999.
- No se modifica ninguna tabla transaccional.
- Si aplica Cobis es `S`, se invoca `sp_cerror` con el mensaje `TRANSACCION NO PERMITIDA`.
- Si aplica Cobis es distinto de `S`, se retorna el mensaje `TRANSACCION NO PERMITIDA`.

#### h. Flujo Principal

1. El canal envia una solicitud con un codigo de transaccion no reconocido.
2. El sistema valida el codigo contra la lista permitida.
3. El sistema identifica que el codigo no esta autorizado.
4. El sistema reporta el error segun el mecanismo configurado.
5. El proceso finaliza sin registrar transacciones.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Aplica Cobis es `S` | Se invoca `sp_cerror` y se retorna 99999. |
| FA-02 | Aplica Cobis es distinto de `S` | Se retorna mensaje directo y codigo 99999. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-01 Rechazo por transaccion no permitida

  Scenario: Transaccion no permitida con aplcobis S
    Given una solicitud con codigo de transaccion 9999 que no esta en la lista permitida
    And el parametro aplicaCobis es "S"
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de error 99999
    And sp_cerror se invoca con mensaje "TRANSACCION NO PERMITIDA"
    And no se modifica ningun registro en las tablas de servicio

  Scenario: Transaccion no permitida con aplcobis N - mensaje directo
    Given una solicitud con codigo de transaccion 9999 que no esta en la lista permitida
    And el parametro aplicaCobis es "N"
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de error 99999
    And el mensaje contiene "TRANSACCION NO PERMITIDA"
    And no se modifica ningun registro en las tablas de servicio
```

---

### CU-02 - Contabilizar IVA - Cuentas Corrientes (CTE)

#### a. Proposito

Verificar que el sistema registra correctamente la transaccion de servicio en `cc_tran_servicio` y el IVA en remesas para transacciones del grupo CTE.

#### b. Alcance

- Que incluye: asignacion producto `CTAS`, servicio `CCTE`, tipo cuenta `CTE`, insercion en `cc_tran_servicio` y registro IVA.
- Que no incluye: transacciones AHO, VIR/BAS, devolucion damnificado, reversa o escenarios sin registro IVA.

#### c. Actores

- Canal invocante.
- Servicio externo `cob_remesas..sp_registra_trx_iva`.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Codigo de transaccion | 3188 sin causal 959, 3793, 43087, 43088, 43083 o 43084. |
| Cuenta | Cuenta corriente sobre la que se registra la transaccion. |
| Base imponible, IVA y total | Valores monetarios de la transaccion. |
| Moneda | Moneda de la transaccion. |
| Guardar IVA | Debe ser `S`. |
| Correccion | Debe ser `N`. |

#### f. Precondiciones

- El codigo pertenece al grupo CTE.
- La devolucion damnificado no aplica o retorna monto cero.
- El indicador de guardar IVA es `S`.
- La operacion no corresponde a correccion.

#### g. Postcondiciones

- Se registra una transaccion en `cob_cuentas..cc_tran_servicio` con estado `S`.
- Se registra IVA con operacion `I`, producto `CTAS` y servicio `CCTE`.
- El sistema retorna codigo 0.
- Si falla la insercion principal, retorna 33005.
- Si falla el registro IVA, se propaga el codigo del SP hijo y la transaccion principal queda persistida.

#### h. Flujo Principal

1. El sistema recibe una solicitud CTE valida.
2. Asigna producto, servicio y tipo de cuenta correspondientes.
3. Valida que no aplique devolucion damnificado.
4. Inserta la transaccion principal en `cc_tran_servicio`.
5. Registra el IVA en remesas con operacion de insercion.
6. Finaliza con resultado exitoso.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Falla la insercion en `cc_tran_servicio` | Retorna 33005. |
| FA-02 | Falla `sp_registra_trx_iva` | Propaga el codigo de error del SP hijo. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-02 Contabilizar IVA - Cuentas Corrientes (CTE)

  Scenario: CTE IVA normal con trn 3188 sin causal 959
    Given una solicitud con codigo de transaccion 3188 y causal distinta de "959"
    And la cuenta "<cuenta-cte-activa>" existe en el sistema
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_cuentas..cc_tran_servicio
    And sp_registra_trx_iva se ejecuta con operacion "I" y producto "CTAS"

  Scenario Outline: CTE IVA normal con diferentes transacciones del grupo
    Given una solicitud con codigo de transaccion <trn>
    And la cuenta "<cuenta-cte-activa>" existe en el sistema
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_cuentas..cc_tran_servicio

    Examples:
      | trn   |
      | 3793  |
      | 43087 |
      | 43088 |
      | 43083 |
      | 43084 |
```

---

### CU-03 - Contabilizar IVA - Ahorros (AHO)

#### a. Proposito

Verificar que el sistema registra correctamente la transaccion de servicio en `ah_tran_servicio` y el IVA en remesas para transacciones del grupo AHO.

#### b. Alcance

- Que incluye: asignacion producto `CTAS`, servicio `CAHO`, tipo cuenta `AHO`, insercion en `ah_tran_servicio` y registro IVA.
- Que no incluye: transacciones CTE, VIR/BAS, devolucion damnificado o reversa.

#### c. Actores

- Canal invocante.
- Servicio externo `cob_remesas..sp_registra_trx_iva`.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Codigo de transaccion | 4188 sin causal 959, 4283 o 4284. |
| Cuenta | Cuenta de ahorros sobre la que se registra la transaccion. |
| Base imponible, IVA y total | Valores monetarios de la transaccion. |
| Moneda | Moneda de la transaccion. |
| Guardar IVA | Debe ser `S`. |
| Correccion | Debe ser `N`. |

#### f. Precondiciones

- El codigo pertenece al grupo AHO.
- La devolucion damnificado no aplica.
- El indicador de guardar IVA es `S`.
- La operacion no corresponde a correccion.

#### g. Postcondiciones

- Se registra una transaccion en `cob_ahorros..ah_tran_servicio` con estado `S`.
- Se registra IVA con operacion `I`, producto `CTAS` y servicio `CAHO`.
- El sistema retorna codigo 0.
- Si falla la insercion principal, retorna 43004.

#### h. Flujo Principal

1. El sistema recibe una solicitud AHO valida.
2. Asigna producto, servicio y tipo de cuenta correspondientes.
3. Valida que no aplique devolucion damnificado.
4. Inserta la transaccion principal en `ah_tran_servicio`.
5. Registra el IVA en remesas.
6. Finaliza con resultado exitoso.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Falla la insercion en `ah_tran_servicio` | Retorna 43004. |
| FA-02 | Falla `sp_registra_trx_iva` | Propaga el codigo de error del SP hijo. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-03 Contabilizar IVA - Ahorros (AHO)

  Scenario: AHO IVA normal con trn 4188 sin causal 959
    Given una solicitud con codigo de transaccion 4188 y causal distinta de "959"
    And la cuenta "<cuenta-aho-activa>" existe en el sistema
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_ahorros..ah_tran_servicio
    And sp_registra_trx_iva se ejecuta con operacion "I" y producto "CTAS"

  Scenario Outline: AHO IVA normal con diferentes transacciones del grupo
    Given una solicitud con codigo de transaccion <trn>
    And la cuenta "<cuenta-aho-activa>" existe en el sistema
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_ahorros..ah_tran_servicio

    Examples:
      | trn  |
      | 4283 |
      | 4284 |
```

---

### CU-04 - Contabilizar IVA - Virtuales/Basica (VIR/BAS)

#### a. Proposito

Verificar que el sistema registra correctamente la transaccion de servicio en `vi_tran_servicio` y el IVA en remesas para transacciones del grupo VIR/BAS.

#### b. Alcance

- Que incluye: asignaciones de producto y servicio para cuentas virtuales o basicas, insercion en `vi_tran_servicio` con estado `A`, y registro IVA.
- Que no incluye: transacciones CTE, AHO, devolucion damnificado o reversa.

#### c. Actores

- Canal invocante.
- Servicio externo `cob_remesas..sp_registra_trx_iva`.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Codigo de transaccion | 120049, 120050, 43085, 120061, 120072, 120094 o 120161. |
| Cuenta | Cuenta virtual o basica relacionada con la transaccion. |
| Base imponible, IVA y total | Valores monetarios de la transaccion. |
| Guardar IVA | Debe ser `S`. |
| Correccion | Debe ser `N`. |

#### f. Precondiciones

- El codigo pertenece al grupo VIR/BAS.
- La devolucion damnificado no aplica.
- El indicador de guardar IVA es `S`.
- La operacion no corresponde a correccion.

#### g. Postcondiciones

- Se registra una transaccion en `cob_virtuales..vi_tran_servicio` con estado `A` e indicador 1.
- Se registra IVA con operacion `I`.
- El sistema retorna codigo 0.
- Si falla la insercion principal, retorna 33005.

#### h. Flujo Principal

1. El sistema recibe una solicitud VIR/BAS valida.
2. Asigna producto, servicio y tipo de cuenta segun el codigo de transaccion.
3. Valida que no aplique devolucion damnificado.
4. Inserta la transaccion principal en `vi_tran_servicio`.
5. Registra el IVA en remesas.
6. Finaliza con resultado exitoso.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Falla la insercion en `vi_tran_servicio` | Retorna 33005. |
| FA-02 | Falla `sp_registra_trx_iva` | Propaga el codigo de error del SP hijo. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-04 Contabilizar IVA - Virtuales y Basica (VIR/BAS)

  Scenario: VIR IVA normal con trn 120049
    Given una solicitud con codigo de transaccion 120049
    And la cuenta "<cuenta-vir-activa>" existe en el sistema
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_virtuales..vi_tran_servicio con estado "A"
    And sp_registra_trx_iva se ejecuta con operacion "I"

  Scenario Outline: VIR/BAS IVA normal con diferentes transacciones
    Given una solicitud con codigo de transaccion <trn>
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_virtuales..vi_tran_servicio con estado "A"

    Examples:
      | trn    |
      | 120050 |
      | 43085  |
      | 120061 |
      | 120072 |
      | 120094 |
      | 120161 |
```

---

### CU-05 - Contabilizar IVA - Recaudacion PAYK (causal 11/10)

#### a. Proposito

Verificar que el sistema asigna producto `PAYK` y servicio `PAYK` para la transaccion 3497 con causal 11 o 10, registrando la transaccion y el IVA.

#### b. Alcance

- Que incluye: flujo PAYK, condicion de transaccion 3497 con causal 11 o 10, insercion en `cc_tran_servicio` y registro IVA.
- Que no incluye: recaudacion RECA con la misma transaccion y causales distintas.

#### c. Actores

- Canal invocante.
- Servicio externo `cob_remesas..sp_registra_trx_iva`.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Codigo de transaccion | 3497. |
| Causal | 11 o 10. |
| Cuenta | Cuenta corriente asociada a la recaudacion. |
| Guardar IVA | Debe ser `S`. |
| Correccion | Debe ser `N`. |

#### f. Precondiciones

- La transaccion es 3497.
- La causal es 11 o 10.
- La operacion debe registrar IVA y no es correccion.

#### g. Postcondiciones

- Se registra una transaccion en `cob_cuentas..cc_tran_servicio`.
- Se registra IVA con producto `PAYK` y servicio `PAYK`.
- El sistema retorna codigo 0.

#### h. Flujo Principal

1. El sistema recibe una solicitud de recaudacion 3497.
2. Valida que la causal corresponda a PAYK.
3. Asigna producto y servicio PAYK.
4. Inserta la transaccion principal.
5. Registra el IVA en remesas.
6. Retorna resultado exitoso.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | La causal no es 11 ni 10 | El comportamiento corresponde a CU-06. |
| FA-02 | Falla insercion o registro IVA | Retorna el error correspondiente. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-05 Contabilizar IVA - Recaudacion PAYK

  Scenario: PAYK con trn 3497 y causal 11
    Given una solicitud con codigo de transaccion 3497 y causal "11"
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_cuentas..cc_tran_servicio
    And sp_registra_trx_iva se ejecuta con producto "PAYK" y servicio "PAYK"

  Scenario: PAYK con trn 3497 y causal 10
    Given una solicitud con codigo de transaccion 3497 y causal "10"
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And sp_registra_trx_iva se ejecuta con producto "PAYK" y servicio "PAYK"
```

---

### CU-06 - Contabilizar IVA - Recaudacion RECA

#### a. Proposito

Verificar que el sistema asigna producto `RECA` y servicio `RECS` para transacciones de recaudacion que no corresponden a PAYK.

#### b. Alcance

- Que incluye: transacciones 3497 sin causal 11/10, 3484, 3471 y 4189.
- Que no incluye: PAYK, transferencia exterior, emision de cheque o transacciones sin IVA.

#### c. Actores

- Canal invocante.
- Servicio externo `cob_remesas..sp_registra_trx_iva`.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Codigo de transaccion | 3497, 3484, 3471 o 4189. |
| Causal | Para 3497 debe ser distinta de 11 y 10. |
| Cuenta | CTE o AHO segun corresponda. |
| Guardar IVA | Debe ser `S`. |
| Correccion | Debe ser `N`. |

#### f. Precondiciones

- El codigo y causal corresponden al grupo RECA.
- La operacion debe registrar IVA y no es correccion.

#### g. Postcondiciones

- Se registra la transaccion en la tabla de servicio correspondiente.
- Se registra IVA con producto `RECA` y servicio `RECS`.
- El sistema retorna codigo 0.

#### h. Flujo Principal

1. El sistema recibe una solicitud de recaudacion RECA.
2. Determina la tabla destino segun el tipo de producto.
3. Asigna producto `RECA` y servicio `RECS`.
4. Inserta la transaccion principal.
5. Registra el IVA en remesas.
6. Retorna resultado exitoso.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Transaccion 4189 | Registra en `ah_tran_servicio`. |
| FA-02 | Falla insercion o registro IVA | Retorna el error correspondiente. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-06 Contabilizar IVA - Recaudacion RECA

  Scenario: RECA CTE con trn 3497 sin causal PAYK
    Given una solicitud con codigo de transaccion 3497 y causal "01"
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_cuentas..cc_tran_servicio
    And sp_registra_trx_iva se ejecuta con producto "RECA" y servicio "RECS"

  Scenario Outline: RECA con diferentes transacciones
    Given una solicitud con codigo de transaccion <trn>
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0

    Examples:
      | trn  |
      | 3484 |
      | 3471 |
      | 4189 |

  Scenario: RECA AHO con trn 4189 inserta en ah_tran_servicio
    Given una solicitud con codigo de transaccion 4189
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_ahorros..ah_tran_servicio
```

---

### CU-07 - Contabilizar IVA - Transferencia exterior y Emision cheque

#### a. Proposito

Verificar que el sistema asigna producto `TRAN` para transferencia exterior y emision de cheque, diferenciando servicio y tipo de cuenta segun transaccion y causal.

#### b. Alcance

- Que incluye: transaccion 3721 con servicio `TRIN`, transaccion 3188 causal 959 con servicio `ECHE` CTE, y transaccion 4188 causal 959 con servicio `ECHE` AHO.
- Que no incluye: CTE/AHO sin causal 959, recaudacion o reversa.

#### c. Actores

- Canal invocante.
- Servicio externo `cob_remesas..sp_registra_trx_iva`.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Codigo de transaccion | 3721, 3188 o 4188. |
| Causal | 959 para emision de cheque. |
| Cuenta | CTE o AHO segun corresponda. |
| Guardar IVA | Debe ser `S`. |
| Correccion | Debe ser `N`. |

#### f. Precondiciones

- La combinacion de transaccion y causal corresponde a transferencia o emision cheque.
- La operacion debe registrar IVA y no es correccion.

#### g. Postcondiciones

- Se registra la transaccion en la tabla de servicio correspondiente.
- Se registra IVA con producto `TRAN` y servicio `TRIN` o `ECHE`.
- El sistema retorna codigo 0.

#### h. Flujo Principal

1. El sistema recibe una solicitud de transferencia o emision de cheque.
2. Evalua codigo de transaccion y causal.
3. Asigna producto `TRAN` y el servicio correspondiente.
4. Inserta la transaccion principal.
5. Registra el IVA en remesas.
6. Retorna resultado exitoso.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Transaccion 3721 | Servicio `TRIN`, tabla CTE. |
| FA-02 | Transaccion 3188 causal 959 | Servicio `ECHE`, tabla CTE. |
| FA-03 | Transaccion 4188 causal 959 | Servicio `ECHE`, tabla AHO. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-07 Contabilizar IVA - Transferencia y Emision cheque

  Scenario: Transferencia exterior trn 3721
    Given una solicitud con codigo de transaccion 3721
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_cuentas..cc_tran_servicio
    And sp_registra_trx_iva se ejecuta con producto "TRAN" y servicio "TRIN"

  Scenario: Emision cheque CTE trn 3188 con causal 959
    Given una solicitud con codigo de transaccion 3188 y causal "959"
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_cuentas..cc_tran_servicio
    And sp_registra_trx_iva se ejecuta con producto "TRAN" y servicio "ECHE"

  Scenario: Emision cheque AHO trn 4188 con causal 959
    Given una solicitud con codigo de transaccion 4188 y causal "959"
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_ahorros..ah_tran_servicio
    And sp_registra_trx_iva se ejecuta con producto "TRAN" y servicio "ECHE"
```

---

### CU-08 - Contabilizar IVA - Transaccion sin registro IVA

#### a. Proposito

Verificar que cuando guardar IVA es distinto de `S`, el sistema registra la transaccion de servicio pero no invoca el registro de IVA.

#### b. Alcance

- Que incluye: registro de transaccion principal sin llamada a `sp_registra_trx_iva`.
- Que no incluye: registro normal de IVA, reversa o errores del SP hijo.

#### c. Actores

- Canal invocante.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Codigo de transaccion | Codigo permitido CTE, AHO o VIR/BAS. |
| Guardar IVA | Valor distinto de `S`. |
| Correccion | Usualmente `N` para operacion normal. |
| Cuenta | Cuenta asociada a la transaccion. |

#### f. Precondiciones

- La transaccion pertenece a un grupo permitido.
- El indicador de guardar IVA es distinto de `S`.

#### g. Postcondiciones

- Se registra la transaccion principal en la tabla correspondiente.
- No se ejecuta `sp_registra_trx_iva`.
- El sistema retorna codigo 0 si la insercion principal es exitosa.

#### h. Flujo Principal

1. El sistema recibe una solicitud con codigo permitido.
2. Inserta la transaccion principal.
3. Evalua que guardar IVA no es `S`.
4. Omite el registro de IVA.
5. Retorna resultado exitoso.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Transaccion CTE | Inserta en `cc_tran_servicio`. |
| FA-02 | Transaccion AHO | Inserta en `ah_tran_servicio`. |
| FA-03 | Transaccion VIR/BAS | Inserta en `vi_tran_servicio`. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-08 Contabilizar IVA - Sin registro IVA

  Scenario: CTE sin registro IVA
    Given una solicitud con codigo de transaccion 3188 y guardarIva "N"
    And el parametro correccion es "N"
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_cuentas..cc_tran_servicio
    And sp_registra_trx_iva NO se ejecuta

  Scenario: AHO sin registro IVA
    Given una solicitud con codigo de transaccion 4188 y guardarIva "N"
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_ahorros..ah_tran_servicio
    And sp_registra_trx_iva NO se ejecuta

  Scenario: VIR sin registro IVA
    Given una solicitud con codigo de transaccion 120049 y guardarIva "N"
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_virtuales..vi_tran_servicio con estado "A"
    And sp_registra_trx_iva NO se ejecuta
```

---

### CU-09 - Contabilizar IVA con reversa

#### a. Proposito

Verificar que cuando la operacion es de correccion y se debe guardar IVA, el sistema ejecuta `sp_registra_trx_iva` con operacion `R`.

#### b. Alcance

- Que incluye: registro de transaccion principal corregida y reversa de IVA usando el secuencial original.
- Que no incluye: insercion normal de IVA o transacciones sin IVA.

#### c. Actores

- Canal invocante.
- Servicio externo `cob_remesas..sp_registra_trx_iva`.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Codigo de transaccion | Codigo permitido. |
| Guardar IVA | Debe ser `S`. |
| Correccion | Valor distinto de `N`. |
| Secuencial de correccion | Referencia a la transaccion IVA original. |

#### f. Precondiciones

- Existe una transaccion IVA previa a reversar.
- La operacion se marca como correccion.
- Guardar IVA es `S`.

#### g. Postcondiciones

- Se registra la transaccion principal con marca de correccion.
- Se ejecuta reversa de IVA con operacion `R`.
- El sistema retorna codigo 0 si la reversa es exitosa.

#### h. Flujo Principal

1. El sistema recibe una solicitud marcada como correccion.
2. Registra la transaccion principal.
3. Evalua que debe guardar IVA.
4. Ejecuta reversa de IVA con el secuencial original.
5. Retorna resultado exitoso.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Falla la reversa IVA | Se propaga el codigo de error de `sp_registra_trx_iva`. |
| FA-02 | Guardar IVA no es `S` | Aplica CU-08. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-09 Contabilizar IVA con reversa

  Scenario: Reversa IVA exitosa con SSN original valido
    Given una solicitud con codigo de transaccion 3188 y correccion "S"
    And el ssnCorreccion es el secuencial de una transaccion IVA existente
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra una nueva transaccion en cob_cuentas..cc_tran_servicio con ts_correccion="S"
    And sp_registra_trx_iva se ejecuta con operacion "R" y el ssnCorreccion proporcionado

  Scenario: Reversa IVA con parametros minimos
    Given una solicitud con codigo de transaccion 4188 y correccion "S"
    And el ssnCorreccion es un secuencial valido
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And sp_registra_trx_iva se ejecuta con operacion "R"
```

---

### CU-10 - Devolucion damnificado - canal VEN, cuenta no existe

#### a. Proposito

Verificar que se genera una segunda transaccion de devolucion cuando el canal esta habilitado, la compensacion es mayor que cero y la cuenta de debito no existe.

#### b. Alcance

- Que incluye: devolucion para CTE, AHO y VIR/BAS con canal VEN.
- Que no incluye: canal CNB, cuenta existente, bypass de certificacion cheque o errores de insercion de devolucion.

#### c. Actores

- Canal invocante.
- `cob_gov..pa_iva_pcompensacion`.
- Repositorios de cuentas CTE, AHO y VIR/BAS.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Canal | VEN o canal derivado equivalente habilitado para devolucion. |
| Cuenta de debito | Cuenta inexistente en todos los repositorios consultados. |
| Oficina | Oficina damnificada con compensacion vigente. |
| Codigo de transaccion | Codigo CTE, AHO o VIR/BAS que permite devolucion. |

#### f. Precondiciones

- El canal VEN esta activo en `cl_canal_devolucion`.
- `pa_iva_pcompensacion` retorna monto de compensacion mayor que cero.
- La cuenta de debito no existe en `cc_ctacte`, `ah_cuenta`, `ah_cuenta_cerrada`, `vi_cuenta` ni `vi_cuenta_cerrada`.

#### g. Postcondiciones

- Se registra la transaccion principal.
- Se registra una segunda transaccion de devolucion con tipo 43538, 4997 o 120175 segun producto.
- El sistema retorna codigo 0.

#### h. Flujo Principal

1. El sistema recibe una solicitud desde canal VEN.
2. Confirma que el canal esta habilitado para devolucion.
3. Calcula la compensacion por damnificado.
4. Valida que la cuenta de debito no existe en la cascada de repositorios.
5. Inserta la transaccion principal.
6. Inserta la transaccion de devolucion.
7. Retorna resultado exitoso.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Producto CTE | Devolucion con tipo 43538 en `cc_tran_servicio`. |
| FA-02 | Producto AHO | Devolucion con tipo 4997 en `ah_tran_servicio`. |
| FA-03 | Producto VIR/BAS | Devolucion con tipo 120175 en `vi_tran_servicio`. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-10 Devolucion damnificado - canal VEN cuenta inexistente

  Scenario: Devolucion CTE - canal VEN, cuenta no existe en ningun repositorio
    Given una solicitud con codigo de transaccion 3188 y canal "VEN"
    And la cuenta de debito "<cuenta-inexistente>" no existe en ninguna tabla
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registran 2 transacciones en cob_cuentas..cc_tran_servicio
    And la segunda transaccion tiene tipo 43538 y valor igual al monto compensacion

  Scenario: Devolucion AHO - canal VEN, cuenta no existe
    Given una solicitud con codigo de transaccion 4188 y canal "VEN"
    And la cuenta de debito "<cuenta-inexistente>" no existe en ninguna tabla
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registran 2 transacciones en cob_ahorros..ah_tran_servicio
    And la segunda transaccion tiene tipo 4997

  Scenario: Devolucion VIR - canal VEN, cuenta no existe
    Given una solicitud con codigo de transaccion 120049 y canal "VEN"
    And la cuenta de debito "<cuenta-inexistente>" no existe en ninguna tabla
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registran 2 transacciones en cob_virtuales..vi_tran_servicio
    And la segunda transaccion tiene tipo 120175 y estado "A"
```

---

### CU-11 - Devolucion damnificado - canal CNB (homologacion oficina)

#### a. Proposito

Verificar que para canal CNB se preserva la oficina original para la devolucion, se usa oficina 0 en la transaccion principal y no se ejecuta la cascada de validacion de cuenta.

#### b. Alcance

- Que incluye: homologacion de oficina para canal CNB y registro de devolucion.
- Que no incluye: validacion de cuenta para VEN o anulacion por cuenta existente.

#### c. Actores

- Canal CNB.
- `cob_gov..pa_iva_pcompensacion`.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Canal | CNB habilitado para devolucion. |
| Oficina | Oficina original de la operacion. |
| Codigo de transaccion | Codigo permitido para devolucion. |
| Cuenta | No condiciona la devolucion por bypass de cascada CNB. |

#### f. Precondiciones

- Canal CNB esta activo en `cl_canal_devolucion`.
- La oficina tiene compensacion vigente con COMIVA mayor que cero.

#### g. Postcondiciones

- La transaccion principal queda con oficina 0.
- La transaccion de devolucion conserva la oficina original como oficina de pago.
- Se registran dos transacciones.
- El sistema retorna codigo 0.

#### h. Flujo Principal

1. El sistema recibe solicitud desde CNB.
2. Preserva la oficina original para la devolucion.
3. Fuerza la oficina principal a 0.
4. Calcula compensacion.
5. Omite la cascada de validacion de cuenta.
6. Inserta transaccion principal y devolucion.
7. Retorna resultado exitoso.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Cuenta existe | Igual se genera devolucion porque CNB no ejecuta la cascada. |
| FA-02 | No hay compensacion | Solo se registra la transaccion principal. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-11 Devolucion damnificado - canal CNB homologacion oficina

  Scenario: CNB homologa oficina - INSERT principal con ofi=0, devolucion con ofi original
    Given una solicitud con codigo de transaccion 3188 y canal "CNB"
    And la oficina es 5
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And el INSERT principal tiene ts_oficina igual a 0
    And el INSERT devolucion tiene ts_oficina_pago igual a 5

  Scenario: CNB no ejecuta cascada de validacion de cuenta
    Given una solicitud con codigo de transaccion 3188 y canal "CNB"
    And la cuenta de debito "<cuenta-cte-activa>" existe en cc_ctacte
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registran 2 transacciones en cob_cuentas..cc_tran_servicio
```

---

### CU-12 - Devolucion anulada por cuenta existente

#### a. Proposito

Verificar que la devolucion se anula cuando la cuenta de debito existe en alguno de los repositorios de cuentas.

#### b. Alcance

- Que incluye: cascada de validacion de cuenta y anulacion de devolucion.
- Que no incluye: cuenta inexistente, canal CNB o bypass por certificacion cheque.

#### c. Actores

- Canal invocante.
- Repositorios de cuentas CTE, AHO y VIR/BAS.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Canal | VEN habilitado para devolucion. |
| Cuenta de debito | Cuenta existente en algun repositorio consultado. |
| Codigo de transaccion | Codigo permitido para devolucion. |

#### f. Precondiciones

- Canal VEN esta habilitado para devolucion.
- La compensacion calculada es mayor que cero.
- La cuenta de debito existe en alguna tabla de la cascada.

#### g. Postcondiciones

- La devolucion se anula.
- Solo se registra la transaccion principal.
- El sistema retorna codigo 0.

#### h. Flujo Principal

1. El sistema identifica canal habilitado y compensacion mayor que cero.
2. Ejecuta la cascada de validacion de cuenta.
3. Encuentra la cuenta de debito en al menos un repositorio.
4. Anula el valor de devolucion.
5. Inserta solo la transaccion principal.
6. Retorna resultado exitoso.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Cuenta encontrada en CTE | No genera devolucion. |
| FA-02 | Cuenta encontrada en AHO | No genera devolucion. |
| FA-03 | Cuenta encontrada en VIR/BAS | No genera devolucion. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-12 Devolucion anulada por cuenta existente

  Scenario Outline: Cuenta encontrada en cascada anula devolucion
    Given una solicitud con codigo de transaccion 3188 y canal "VEN"
    And la cuenta de debito existe en "<tabla>"
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registra solo 1 transaccion en cob_cuentas..cc_tran_servicio

    Examples:
      | tabla                            |
      | cob_cuentas..cc_ctacte           |
      | cob_ahorros..ah_cuenta           |
      | cob_ahorros..ah_cuenta_cerrada   |
      | cob_virtuales..vi_cuenta         |
      | cob_virtuales..vi_cuenta_cerrada |
```

---

### CU-13 - Devolucion - Bypass certificacion cheque

#### a. Proposito

Verificar que para transaccion 3484 con causal 36 se omite la validacion de existencia de cuenta y se permite la devolucion damnificado.

#### b. Alcance

- Que incluye: bypass de cascada para certificacion de cheque.
- Que no incluye: validacion normal por cuenta existente.

#### c. Actores

- Canal invocante.
- `cob_gov..pa_iva_pcompensacion`.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Codigo de transaccion | 3484. |
| Causal | 36. |
| Canal | VEN habilitado para devolucion. |
| Cuenta de debito | Puede existir y aun asi no anula la devolucion. |

#### f. Precondiciones

- Canal VEN esta habilitado para devolucion.
- La oficina tiene compensacion mayor que cero.
- La transaccion es 3484 con causal 36.

#### g. Postcondiciones

- Se registra la transaccion principal.
- Se registra transaccion de devolucion tipo 43538.
- El sistema retorna codigo 0.

#### h. Flujo Principal

1. El sistema recibe solicitud 3484 causal 36 desde canal VEN.
2. Identifica que aplica bypass de certificacion cheque.
3. Calcula compensacion.
4. Omite la cascada de validacion de cuenta.
5. Inserta transaccion principal y devolucion.
6. Retorna resultado exitoso.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Cuenta existe | No anula la devolucion por aplicar bypass. |
| FA-02 | Causal distinta de 36 | Se evalua la cascada normal de cuenta. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-13 Devolucion - Bypass certificacion cheque

  Scenario: Bypass certificacion cheque - devolucion se ejecuta sin verificar cuenta
    Given una solicitud con codigo de transaccion 3484 y causal "36" y canal "VEN"
    And la cuenta de debito "<cuenta-cte-activa>" existe en cc_ctacte
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And se registran 2 transacciones en cob_cuentas..cc_tran_servicio
    And la segunda transaccion tiene tipo 43538
```

---

### CU-14 - Edge case - Canal devolucion activa con cta_deb vacia

#### a. Proposito

Verificar que si el canal esta habilitado para devolucion pero la cuenta de debito esta vacia, no se ejecuta la cascada de validacion de cuenta.

#### b. Alcance

- Que incluye: manejo de cuenta de debito vacia.
- Que no incluye: cuenta existente, cuenta inexistente informada o canal CNB.

#### c. Actores

- Canal invocante.
- `cob_gov..pa_iva_pcompensacion`.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Canal | Canal habilitado para devolucion. |
| Cuenta de debito | Vacia o no informada. |
| Codigo de transaccion | Codigo permitido. |

#### f. Precondiciones

- El canal esta activo para devolucion.
- La cuenta de debito llega vacia o nula.

#### g. Postcondiciones

- No se ejecuta la cascada de validacion de cuenta.
- El resultado de devolucion depende del monto calculado por compensacion.
- Si la insercion principal es exitosa, el sistema retorna codigo 0.

#### h. Flujo Principal

1. El sistema recibe solicitud desde canal habilitado.
2. Detecta que la cuenta de debito esta vacia.
3. Omite la cascada de validacion.
4. Continua con la contabilizacion segun el monto de compensacion.
5. Retorna el resultado correspondiente.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Compensacion mayor que cero | Puede generarse devolucion. |
| FA-02 | Compensacion igual a cero | Solo se registra transaccion principal. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-14 Edge case - Canal devolucion con cta_deb vacia

  Scenario: Canal devolucion activa pero cta_deb vacia - sin cascada
    Given el microservicio cpas-mso-cont-impuesto-cte esta desplegado
    And el canal "VEN" esta en cl_canal_devolucion con estado "V"
    And una solicitud con codigo de transaccion 3188 sin cuenta de debito
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And no se ejecuta la cascada de validacion de cuenta
```

---

### CU-15 - Error en INSERT principal - fallo persistencia

#### a. Proposito

Verificar que cuando falla la insercion principal en la tabla de servicio, el sistema retorna el codigo de error correspondiente sin persistir datos de esa transaccion.

#### b. Alcance

- Que incluye: error de insercion principal para CTE, AHO y VIR/BAS.
- Que no incluye: error de insercion de devolucion o error en registro IVA.

#### c. Actores

- Canal invocante.
- Sistema de errores `cobis..sp_cerror` o mensaje de salida.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Codigo de transaccion | Codigo valido CTE, AHO o VIR/BAS. |
| Datos de insercion | Datos que provocan fallo de persistencia, por ejemplo secuencial duplicado. |
| Indicador aplica Cobis | Define mecanismo de reporte de error. |

#### f. Precondiciones

- Existe una condicion controlada que provoca fallo de insercion principal.
- La transaccion pertenece a CTE, AHO o VIR/BAS.

#### g. Postcondiciones

- Para CTE o VIR/BAS, retorna 33005.
- Para AHO, retorna 43004.
- No se persiste la transaccion principal fallida.
- Se informa el mensaje `ERROR EN INSERCION DE TRANSACCION DE SERVICIO`.

#### h. Flujo Principal

1. El sistema recibe una solicitud valida.
2. Intenta insertar la transaccion principal.
3. La base de datos reporta error de insercion.
4. El sistema determina el codigo de error segun la tabla destino.
5. El proceso finaliza sin registro persistido para esa transaccion.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Falla CTE | Retorna 33005. |
| FA-02 | Falla AHO | Retorna 43004. |
| FA-03 | Falla VIR/BAS | Retorna 33005. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-15 Error en INSERT principal - fallo persistencia

  Scenario: Error INSERT CTE - retorna 33005
    Given una solicitud con codigo de transaccion 3188 que provoca error de INSERT en cc_tran_servicio
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de error 33005
    And el mensaje contiene "ERROR EN INSERCION DE TRANSACCION DE SERVICIO"
    And no se modifica ningun registro en cc_tran_servicio

  Scenario: Error INSERT AHO - retorna 43004
    Given una solicitud con codigo de transaccion 4188 que provoca error de INSERT en ah_tran_servicio
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de error 43004
    And el mensaje contiene "ERROR EN INSERCION DE TRANSACCION DE SERVICIO"

  Scenario: Error INSERT VIR - retorna 33005
    Given una solicitud con codigo de transaccion 120049 que provoca error de INSERT en vi_tran_servicio
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de error 33005
    And el mensaje contiene "ERROR EN INSERCION DE TRANSACCION DE SERVICIO"
```

---

### CU-16 - Error en INSERT devolucion - estado inconsistente

#### a. Proposito

Verificar que cuando falla la insercion de devolucion despues de insertar exitosamente la transaccion principal, el sistema retorna error y conserva el registro principal.

#### b. Alcance

- Que incluye: fallo de devolucion para CTE, AHO y VIR/BAS.
- Que no incluye: fallo de insercion principal o fallo de registro IVA.

#### c. Actores

- Canal invocante.
- `cob_gov..pa_iva_pcompensacion`.
- Sistema de errores.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Canal | Canal habilitado para devolucion. |
| Cuenta de debito | Cuenta inexistente que habilita devolucion. |
| Codigo de transaccion | Codigo CTE, AHO o VIR/BAS. |
| Datos de devolucion | Datos que provocan error en la segunda insercion. |

#### f. Precondiciones

- La transaccion principal puede insertarse correctamente.
- La devolucion aplica por canal, compensacion y cuenta inexistente.
- Existe una condicion controlada que provoca error en el INSERT de devolucion.

#### g. Postcondiciones

- La transaccion principal permanece persistida.
- La transaccion de devolucion no se registra.
- Se retorna 33005 para CTE/VIR o 43004 para AHO.
- En AHO se conserva el comportamiento particular: `sp_cerror` puede recibir 33005 pero el retorno es 43004.

#### h. Flujo Principal

1. El sistema recibe solicitud con devolucion aplicable.
2. Inserta exitosamente la transaccion principal.
3. Intenta insertar la transaccion de devolucion.
4. La insercion de devolucion falla.
5. El sistema retorna el error correspondiente sin rollback de la principal.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Falla devolucion CTE | Retorna 33005 y principal queda persistida. |
| FA-02 | Falla devolucion AHO | Retorna 43004 y principal queda persistida. |
| FA-03 | Falla devolucion VIR/BAS | Retorna 33005 y principal queda persistida. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-16 Error en INSERT devolucion - estado inconsistente

  Scenario: Error INSERT devolucion CTE - principal persistido sin rollback
    Given una solicitud con codigo de transaccion 3188 que provoca error en INSERT devolucion (trx 43538)
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de error 33005
    And el registro principal en cc_tran_servicio permanece persistido
    And el registro de devolucion NO existe

  Scenario: Error INSERT devolucion AHO - QUIRK sp_cerror(33005) pero return 43004
    Given una solicitud con codigo de transaccion 4188 que provoca error en INSERT devolucion (trx 4997)
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de error 43004
    And sp_cerror se invoca con codigo 33005
    And el registro principal en ah_tran_servicio permanece persistido

  Scenario: Error INSERT devolucion VIR - principal persistido sin rollback
    Given una solicitud con codigo de transaccion 120049 que provoca error en INSERT devolucion (trx 120175)
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de error 33005
    And el registro principal en vi_tran_servicio permanece persistido
```

---

### CU-17 - Error en registro IVA - sp_registra_trx_iva falla

#### a. Proposito

Verificar que cuando `sp_registra_trx_iva` retorna error, el sistema propaga ese codigo sin generar un error propio y conserva la transaccion principal.

#### b. Alcance

- Que incluye: error del registro IVA para operacion normal y reversa.
- Que no incluye: errores de insercion principal o devolucion.

#### c. Actores

- Canal invocante.
- Servicio externo `cob_remesas..sp_registra_trx_iva`.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Codigo de transaccion | Codigo permitido. |
| Guardar IVA | Debe ser `S`. |
| Correccion | `N` para insercion IVA o distinto de `N` para reversa. |
| Resultado del SP hijo | Codigo de error distinto de cero. |

#### f. Precondiciones

- La transaccion principal se inserta correctamente.
- `sp_registra_trx_iva` esta configurado o simulado para retornar error.

#### g. Postcondiciones

- El sistema retorna el codigo propagado de `sp_registra_trx_iva`.
- La transaccion principal permanece persistida.
- No se genera mensaje propio adicional.

#### h. Flujo Principal

1. El sistema registra la transaccion principal.
2. Invoca `sp_registra_trx_iva`.
3. El SP hijo retorna error.
4. El sistema propaga el codigo recibido.
5. Finaliza sin rollback de la transaccion principal.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Operacion IVA normal | Falla operacion `I` y se propaga error. |
| FA-02 | Operacion reversa | Falla operacion `R` y se propaga error. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-17 Error en registro IVA - sp_registra_trx_iva falla

  Scenario: Error en registro IVA normal
    Given una solicitud con codigo de transaccion 3188 y correccion "N"
    And sp_registra_trx_iva esta configurado para retornar error
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna el codigo de error propagado de sp_registra_trx_iva
    And el registro en cc_tran_servicio permanece persistido
    And no se genera mensaje propio en @o_mensaje

  Scenario: Error en reversa IVA
    Given una solicitud con codigo de transaccion 3188 y correccion "S"
    And sp_registra_trx_iva esta configurado para retornar error en operacion R
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna el codigo de error propagado de sp_registra_trx_iva
    And el registro en cc_tran_servicio permanece persistido
```

---

### CU-18 - Mecanismo de error alternativo

#### a. Proposito

Verificar que cuando aplica Cobis es distinto de `S`, los errores se reportan por mensaje de salida en lugar de `sp_cerror`, manteniendo el mismo codigo de retorno.

#### b. Alcance

- Que incluye: errores 99999, 33005 y 43004 reportados por mensaje.
- Que no incluye: cambios en la logica funcional que origina el error.

#### c. Actores

- Canal invocante que no usa `sp_cerror`.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Indicador aplica Cobis | Valor distinto de `S`. |
| Condicion de error | Transaccion no permitida o fallo de insercion. |

#### f. Precondiciones

- La solicitud provoca un error controlado.
- El indicador aplica Cobis es distinto de `S`.

#### g. Postcondiciones

- No se invoca `sp_cerror`.
- El codigo de error se mantiene.
- El mensaje de salida contiene el texto esperado.

#### h. Flujo Principal

1. El sistema recibe una solicitud que provoca error controlado.
2. Evalua que aplica Cobis es distinto de `S`.
3. Construye el mensaje de salida correspondiente.
4. Retorna el mismo codigo de error funcional.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Error 99999 | Mensaje `TRANSACCION NO PERMITIDA`. |
| FA-02 | Error 33005 | Mensaje con prefijo del SP y error de insercion. |
| FA-03 | Error 43004 | Mensaje con prefijo del SP y error de insercion. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-18 Mecanismo de error alternativo

  Scenario: Error 99999 via o_mensaje sin prefijo sp_name
    Given una solicitud con codigo de transaccion 9999 y aplicaCobis "N"
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de error 99999
    And el mensaje es "TRANSACCION NO PERMITIDA"
    And sp_cerror NO se invoca

  Scenario: Error 33005 via o_mensaje con prefijo sp_name
    Given una solicitud CTE que provoca error INSERT con aplicaCobis "N"
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de error 33005
    And el mensaje es "[sp_cont_impuesto]  ERROR EN INSERCION DE TRANSACCION DE SERVICIO"
    And sp_cerror NO se invoca

  Scenario: Error 43004 via o_mensaje con prefijo sp_name
    Given una solicitud AHO que provoca error INSERT con aplicaCobis "N"
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de error 43004
    And el mensaje es "[sp_cont_impuesto]  ERROR EN INSERCION DE TRANSACCION DE SERVICIO"
```

---

### CU-19 - Derivacion de canal desde usuario

#### a. Proposito

Verificar que cuando el canal no viene informado, el sistema deriva el canal desde el usuario segun las reglas del SP.

#### b. Alcance

- Que incluye: derivacion de canal para usuarios `ope998`, `SAT`, `srolese`, `kiosko`, `IVR` y otros.
- Que no incluye: validaciones de canal cuando ya viene informado.

#### c. Actores

- Canal invocante.
- Usuario de sesion.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Canal | Valor nulo o no informado. |
| Usuario | Usuario usado para derivar el canal. |
| Codigo de transaccion | Codigo valido para continuar contabilizacion. |

#### f. Precondiciones

- La solicitud no informa canal.
- El usuario de sesion tiene un valor reconocible por las reglas del SP.

#### g. Postcondiciones

- El canal derivado es `IBK`, `SAT`, `KSK`, `IVR` o `VEN`.
- La contabilizacion continua con el canal derivado.
- El sistema retorna codigo 0 si la contabilizacion es exitosa.

#### h. Flujo Principal

1. El sistema recibe una solicitud sin canal.
2. Lee el usuario de sesion.
3. Aplica la regla de derivacion.
4. Usa el canal derivado en el resto del flujo.
5. Retorna el resultado de la contabilizacion.

#### i. Flujos Alternos

| Flujo | Condicion | Canal derivado |
|-------|-----------|----------------|
| FA-01 | Usuario `ope998` | IBK |
| FA-02 | Usuario `SAT` o `srolese` | SAT |
| FA-03 | Usuario `kiosko` | KSK |
| FA-04 | Usuario `IVR` | IVR |
| FA-05 | Otro usuario | VEN |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-19 Derivacion de canal desde usuario

  Scenario Outline: Derivacion de canal segun usuario
    Given una solicitud con codigo de transaccion 3188 y canal null
    And el usuario es "<usuario>"
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de exito 0
    And el canal derivado internamente es "<canal_esperado>"

    Examples:
      | usuario  | canal_esperado |
      | ope998   | IBK            |
      | SAT      | SAT            |
      | srolese  | SAT            |
      | kiosko   | KSK            |
      | IVR      | IVR            |
      | cajero01 | VEN            |
```

---

### CU-20 - Error guessing - Producto no reconocido y multicanal

#### a. Proposito

Verificar escenarios exploratorios de combinaciones atipicas, duplicidad de secuenciales y ejecuciones multicanal.

#### b. Alcance

- Que incluye: PK duplicada por misma fecha y secuencial, y ejecuciones concurrentes o cercanas desde canales distintos.
- Que no incluye: flujos funcionales base ya cubiertos por CU-01 a CU-19.

#### c. Actores

- Equipo QA.
- Canales invocantes multiples.

#### d. Entradas funcionales

| Entrada | Descripcion |
|---------|-------------|
| Secuencial | Secuencial nuevo o duplicado segun escenario. |
| Fecha | Fecha usada para validar unicidad con secuencial. |
| Canal | IBK, VEN u otros canales de prueba. |
| Codigo de transaccion | Codigo permitido para ejecutar la prueba exploratoria. |

#### f. Precondiciones

- Para duplicidad, ya existe una transaccion con la misma fecha y secuencial.
- Para multicanal, se preparan solicitudes independientes con secuenciales distintos.

#### g. Postcondiciones

- En duplicidad, el sistema retorna 33005 y no duplica el registro.
- En multicanal, las solicitudes validas se registran de forma independiente y retornan codigo 0.

#### h. Flujo Principal

1. QA prepara una condicion atipica o exploratoria.
2. Ejecuta la solicitud o solicitudes contra el microservicio.
3. El sistema procesa la condicion segun reglas de persistencia y canal.
4. QA valida el resultado funcional esperado.

#### i. Flujos Alternos

| Flujo | Condicion | Resultado |
|-------|-----------|-----------|
| FA-01 | Secuencial duplicado | Retorna 33005. |
| FA-02 | Dos canales con secuenciales distintos | Registra transacciones independientes. |

#### j. Escenarios Gherkin

```gherkin
Feature: CU-20 Error guessing - Escenarios exploratorios

  Scenario: Multiples invocaciones misma fecha y secuencial
    Given el microservicio cpas-mso-cont-impuesto-cte esta desplegado
    And una solicitud con codigo de transaccion 3188 y secuencial que ya existe para esa fecha
    When se solicita la contabilizacion del impuesto
    Then el sistema retorna codigo de error 33005
    And el mensaje contiene "ERROR EN INSERCION DE TRANSACCION DE SERVICIO"

  Scenario: Pagos en 2+ canales distintos misma fecha
    Given el microservicio cpas-mso-cont-impuesto-cte esta desplegado
    And se ejecutan 2 solicitudes con secuenciales distintos desde canales IBK y VEN
    When se solicitan ambas contabilizaciones del impuesto
    Then ambas retornan codigo de exito 0
    And se registran 2 transacciones independientes en cc_tran_servicio
```

# Casos de Prueba - SP `sp_ahndc_automatica`

**Base de datos:** `cob_ahorros` (Sybase)  
**Propósito:** Procesa transacciones de Notas de Débito (ND) y Notas de Crédito (NC) automáticas sobre cuentas de ahorro.

---

## CONVENCIONES

| Símbolo | Significado |
|---------|-------------|
| ✅ | Condición válida / resultado esperado exitoso |
| ❌ | Condición inválida / resultado esperado con error |
| ⚠️ | Caso borde o riesgo |
| PRE | Precondición: estado de BD antes de ejecutar |
| POST | Postcondición: estado de BD después de ejecutar |

---

## PARAMETROS DE SESION POR DEFECTO

Estos parámetros se aplican a TODOS los TCs a menos que el TC indique un valor diferente en su tabla de campos.

| Parámetro | Valor por defecto | Descripción |
|-----------|-------------------|-------------|
| **@s_srv** | sybasedvp1 | Servidor Sybase |
| **@s_ofi** | 1 | Oficina |
| **@s_ssn** | 0 | Secuencial de sesión |
| **@s_user** | operadorPas | Usuario |
| **@s_term** | consola | Terminal |
| **@s_rol** | 1 | Rol |
| **@t_corr** | 'N' | Corrección |
| **@t_rty** | 'N' | Reintento |
| **@i_prod** | 'AHO' | Producto |
| **@i_mon** | 1 | Moneda (USD) |
| **@i_empresa** | 0 | Empresa |
| **@i_alt** | 0 | Código alterno |
| **@i_aplcobis** | 'N' | Aplicar lógica COBIS (N=asigna mensaje a @o_msg directamente) |

---

> Los códigos de transacción y causa se documentan directamente dentro de cada TC.

## GRUPO 1 — Validaciones de Entrada

---

### TC01 — Control ND/NC deshabilitado

| Campo | Detalle |
|-------|---------|
| **Descripción** | El sistema tiene el control de ND/NC desactivado para tipo AHO |
| **@t_trn** | 4272 (cualquier ND válida) |
| **@i_val** | 100.00 |
| **@i_cta** | Cuenta activa válida |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
-- Deshabilitar control NDNC para tipo AHO
UPDATE cob_cuentas..cc_control_ndnc SET cd_estado = 'N' WHERE cd_tipo = 'AHO'
```

**Ejecución esperada:** El SP rechaza antes de abrir transacción.

**POST — Validaciones en BD:**
```sql
-- Restaurar control NDNC a estado habilitado
UPDATE cob_cuentas..cc_control_ndnc SET cd_estado = 'S' WHERE cd_tipo = 'AHO'
-- No debe existir ningún movimiento generado
SELECT COUNT(*) as nuevas_trx FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta -- debe ser 0
SELECT COUNT(*) as nuevos_srv FROM cob_ahorros..ah_tran_servicio WHERE ts_cta_banco = @i_cta -- debe ser 0
-- ah_cuenta no debe haber cambiado
SELECT ah_disponible, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
-- Igual a valores previos
```

**Resultado esperado:** `RETURN 39003`

**Trazabilidad por DB:**
- NINGUNO — SP retorna 39003 en L:160 antes de BEGIN TRANSACTION

---

### TC02 — Monto negativo

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | -100.00 |
| **@i_cta** | Cuenta activa válida |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
-- cc_control_ndnc NO debe tener registro con cd_estado='N' para 'AHO'
-- Cuenta debe existir y estar activa (ah_estado = 'A')
SELECT ah_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta -- guardar valor
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta
```

**Resultado esperado:** `RETURN 141011`

**Trazabilidad por DB:**
- NINGUNO — SP retorna 141011 en L:197 antes de BEGIN TRANSACTION

---

### TC03 — Monto cero (caso borde)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 0.00 |
| **@i_cta** | Cuenta activa válida |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
-- Cuenta activa, cualquier saldo
SELECT ah_disponible, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT COUNT(*) as nuevas_trx FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta
```

**Resultado esperado:** `RETURN 0` sin ningún movimiento generado ⚠️

**Trazabilidad por DB:**
- NINGUNO — SP retorna 0 en L:201 (monto=0 es no-op exitoso, sale antes de BEGIN TRANSACTION)

---

### TC04 — Decimales en moneda sucres

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 100.50 |
| **@i_mon** | 0 (sucres) |
| **@i_cta** | Cuenta en moneda 0 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
-- Cuenta con moneda 0
SELECT ah_moneda FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta -- debe ser 0
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta
```

**Resultado esperado:** `RETURN 901419`

**Trazabilidad por DB:**
- NINGUNO — SP retorna 901419 en L:219 antes de BEGIN TRANSACTION

---

### TC05 — Código de transacción nulo o cero

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 0 (o NULL) |
| **@i_val** | 100.00 |
| **@i_cta** | Cuenta activa válida |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
-- Solo necesita cuenta activa existente
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta
```

**Resultado esperado:** `RETURN 111000`, `@o_error = 111000`

**Trazabilidad por DB:**
- NINGUNO — SP retorna 111000 en L:261 antes de BEGIN TRANSACTION

---

### TC06 — Cuenta inexistente

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 100.00 |
| **@i_cta** | '9999999999' (no existe) |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
-- Verificar que la cuenta NO existe
SELECT COUNT(*) FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '9999999999' -- debe ser 0
```

**POST — Validaciones en BD:**
```sql
SELECT COUNT(*) as cuenta_existe FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '9999999999'
SELECT COUNT(*) as nuevas_trx FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '9999999999'
```

**Resultado esperado:** `RETURN 41001` — Error retornado por `sp_ctah_vigente` (cuenta no encontrada)

**Trazabilidad por DB:**
- NINGUNO — SP retorna 41001 en L:356 (sp_ctah_vigente falla, antes de BEGIN TRANSACTION)

---

### TC07 — Cuenta bloqueada

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 100.00 |
| **@i_cta** | Cuenta con bloqueo activo |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |
| **@s_user** | Cualquier usuario distinto de `'rrhh'` |

**Códigos asociados en el SP:** `@t_trn = 4272`; bypass de bloqueo por catálogo `ah_bloqueo_nd` y caso especial de bloqueo cuando `cb_causa = '2'`.

**PRE — Estado requerido en BD:**
```sql
SELECT cb_tipo_bloqueo, cb_estado, cb_causa FROM cob_ahorros..ah_ctabloqueada WHERE cb_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta) AND cb_estado = 'V'
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta
```

**Resultado esperado:** `RETURN 041025`, `@o_error = 041025`

**Trazabilidad por DB:**
- NINGUNO — SP retorna 41025 en L:561 antes de BEGIN TRANSACTION (bloqueo detectado)

---

### TC08 — Cuenta bloqueada con usuario rrhh (bypass)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 100.00 |
| **@i_cta** | Cuenta con bloqueo activo |
| **@s_user** | `'rrhh'` |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
SELECT cb_tipo_bloqueo FROM cob_ahorros..ah_ctabloqueada WHERE cb_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta) AND cb_estado = 'V'
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0` ⚠️ Riesgo de seguridad — validar que solo usuarios autorizados usen `rrhh`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4272 (ND)
  - tm_signo = 'D' (L:278 tipo ND)
  - tm_usuario = 'rrhh' (bypass)
  - tm_valor = 100
  - tm_control = NULL (L:1023 sin params A06)
  - tm_interes = NULL
  - tm_remoto_ssn = NULL (sin suspenso, @w_val=0)
  - tm_valor_impuesto = 0
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = -100 (L:871 tfactor=-1)
  - ah_debitos = +100 (L:864 factor_aux=1)
  - ah_debitos_hoy = +100
  - ah_contador_trx = +1
- `ah_tran_servicio`: NINGUNO (L:1269 no es ATM, L:1392 @w_val=0)
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC09 — Cuenta en estado temporal 'T'

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 (ND) o 4253 (NC) |
| **@i_val** | 100.00 |
| **@i_cta** | Cuenta con `ah_estado = 'T'` |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
SELECT ah_estado FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta -- debe ser 'T'
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_contador_trx, ah_estado FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta
```

**Resultado esperado:** `RETURN 128144` — ND rechazada, estado no permite débitos

**Trazabilidad por DB:**
- NINGUNO — SP retorna 128144 en L:637 antes de BEGIN TRANSACTION (estado 'T' no permite debitos)

---

### TC10 — Cuenta inactiva 'I' sin permiso de movimiento

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 100.00 |
| **@i_cta** | Cuenta con `ah_estado = 'I'` |
| **@i_cau** | '0001' |
| **@i_mon** | 1 |

**PRE — Estado requerido en BD:**
```sql
SELECT ah_estado FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta -- debe ser 'I'

SELECT COUNT(*) as cm_existe FROM cob_cuentas..cc_control_movimientos WHERE cm_producto = 4 AND cm_transaccion = 4272 AND cm_causa = '0001'
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta
```

**Resultado esperado:** `RETURN 041058`

**Trazabilidad por DB:**
- NINGUNO — SP retorna 41058 en L:473 antes de BEGIN TRANSACTION (cuenta inactiva sin permiso en cc_control_movimientos)

---

### TC11 — Cuenta en depósito inicial 'D' sin NC válida

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 (ND) |
| **@i_val** | 100.00 |
| **@i_cta** | '0003993467' |
| **@t_corr** | 'N' |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
SELECT ah_estado FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0003993467' -- debe ser 'D'
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_contador_trx, ah_estado FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta
```

**Resultado esperado:** `RETURN 48003`

**Trazabilidad por DB:**
- NINGUNO — SP retorna 48003 en L:426 antes de BEGIN TRANSACTION (cuenta estado 'D' con trx no permitida)

---

### TC12 — Moneda incorrecta

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 100.00 |
| **@i_cta** | '0000704188' |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
-- Temporalmente cambiar moneda de la cuenta a 0 para generar mismatch
UPDATE cob_ahorros..ah_cuenta SET ah_moneda = 0 WHERE ah_cta_banco = '0000704188'
SELECT ah_moneda FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000704188'
```

**POST — Validaciones en BD:**
```sql
UPDATE cob_ahorros..ah_cuenta SET ah_moneda = 1 WHERE ah_cta_banco = '0000704188'
SELECT ah_disponible, ah_debitos, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000704188'
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000704188'
```

**Resultado esperado:** `RETURN 41001` — SP busca cuenta por moneda, no la encuentra (mismatch moneda)

**Trazabilidad por DB:**
- NINGUNO — SP retorna 41001 en L:356 (sp_ctah_vigente busca por moneda, no encuentra)

---

### TC13 — Sin alícuota configurada para la fecha

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 100.00 |
| **@i_cta** | '0000837312' |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
-- Adelantar fecha de proceso 1 año para que no exista alícuota configurada
SELECT fp_fecha FROM cobis..ba_fecha_proceso
UPDATE cobis..ba_fecha_proceso SET fp_fecha = dateadd(yy, +1, fp_fecha)
SELECT fp_fecha FROM cobis..ba_fecha_proceso
```

**POST — Validaciones en BD:**
```sql
UPDATE cobis..ba_fecha_proceso SET fp_fecha = dateadd(yy, -1, fp_fecha)
SELECT ah_disponible, ah_debitos, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837312'
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837312'
```

**Resultado esperado:** `RETURN 041012`

**Trazabilidad por DB:**
- NINGUNO — SP retorna 41012 en L:673 antes de BEGIN TRANSACTION (sin alicuota para la fecha)

---

## GRUPO 2 — Notas de Crédito (NC)

---

### TC20 — NC exitosa estándar

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4253 |
| **@i_val** | 500.00 |
| **@i_cta** | Cuenta activa con saldo conocido |
| **@i_mon** | 1 |
| **@i_cau** | '0010' |
| **@t_corr** | `'N'` |
| **@i_prod** | `'AHO'` |

**Códigos asociados en el SP:** `@t_trn = 4253`; alias interno `4319 -> 4253`.

**PRE — Estado requerido en BD:**
```sql
-- Capturar estado previo
SELECT ah_disponible, ah_creditos, ah_creditos_hoy, ah_promedio1, ah_contador_trx
FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
-- Guardar estos valores como: saldo_previo, creditos_previo, etc.

-- Verificar fecha de proceso activa
SELECT fp_fecha FROM cobis..ba_fecha_proceso

-- Alícuota configurada para la fecha
SELECT fp_alicuota FROM cob_cuentas..cc_fecha_promedio WHERE fp_fecha_inicio = @i_fecha
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_creditos, ah_creditos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4253 (NC)
  - tm_signo = 'C' (L:278 factor NC)
  - tm_valor = 500 (L:703 @w_val_efe = neto post-ICC)
  - tm_control = NULL (L:1023 isnull(@i_control,@i_cant) sin params A06)
  - tm_interes = NULL (no se calcula interes para NC estandar)
  - tm_remoto_ssn = NULL (L:995 sin suspenso)
  - tm_valor_impuesto = 0 (ICC tasa actual 0%)
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = +500 (L:871 disponible + val_efe * tfactor=1)
  - ah_creditos = +500 (L:862)
  - ah_creditos_hoy = +500 (L:870)
  - ah_contador_trx = +1 (L:1235)
  - ah_promedio1 = recalculado (L:860)
  - ah_prom_disponible = recalculado (L:1238)
- `ah_tran_servicio`: NINGUNO (L:1269 no es ATM, L:1392 @w_val=0)
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC21 — NC con impuesto al flujo de capital (1% ICC)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4253 |
| **@i_val** | 1000.00 |
| **@i_prod** | `'AHO'` |
| **@i_cta** | Cuenta activa |
| **@i_mon** | 1 |
| **@i_cau** | '0010' |

**PRE — Estado requerido en BD:**
```sql
SELECT ah_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta

-- Verificar que la causa genera impuesto (sp_impuesto_flujo_capital)
-- La tasa de impuesto debe estar configurada
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_creditos, ah_creditos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0`, `@o_neto_aut` = valor del impuesto retenido

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4253 (NC)
  - tm_signo = 'C'
  - tm_valor = neto (1000 - ICC, L:703 @w_neto de sp_impuesto_flujo_capital)
  - tm_control = NULL
  - tm_interes = NULL
  - tm_remoto_ssn = NULL
  - tm_valor_impuesto = ICC calculado (L:693 sp_impuesto_flujo_capital, tasa actual 0%)
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = +neto (valor - ICC)
  - ah_creditos = +neto
  - ah_creditos_hoy = +neto
  - ah_contador_trx = +1
- `ah_tran_servicio`: NINGUNO
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC22 — NC con corrección (reverso)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4253 |
| **@i_val** | 500.00 |
| **@t_corr** | `'S'` |
| **@t_ssn_corr** | 0 |
| **@i_cta** | Cuenta activa |
| **@i_mon** | 1 |
| **@i_cau** | '0010' |

**PRE — Estado requerido en BD:**
```sql
-- Obtener secuencial de la ultima transaccion NC (tipo 4253) para usar como @t_ssn_corr
SELECT MAX(tm_secuencial) as t_ssn_corr FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837390' AND tm_tipo_tran = 4253 AND tm_signo = 'C'

SELECT ah_disponible, ah_creditos FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837390'
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_creditos, ah_creditos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837390'
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837390' AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4253
  - tm_signo = 'C' (fijo por tipo NC, no se invierte)
  - tm_correccion = 'S' (L:278 tfactor=-1 indica reverso)
  - tm_sec_correccion = @t_ssn_corr (secuencial original)
  - tm_valor = 500
  - tm_control = NULL
  - tm_remoto_ssn = NULL
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = -500 (L:871 tfactor=-1, revierte credito)
  - ah_creditos = -500
  - ah_creditos_hoy = -500
  - ah_contador_trx = +1
- `ah_tran_servicio`: NINGUNO
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC22b — ND con corrección (reverso de débito)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4264 |
| **@i_val** | 200.00 |
| **@t_corr** | `'S'` |
| **@t_ssn_corr** | SSN de la transacción ND original a reversar |
| **@i_cta** | Cuenta activa |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
-- Debe existir la trx ND original
SELECT tm_secuencial, tm_valor, tm_signo FROM cob_ahorros..ah_tran_monet
WHERE tm_secuencial = @t_ssn_corr  -- tm_signo debe ser 'D'

SELECT ah_disponible, ah_debitos, ah_debitos_hoy FROM cob_ahorros..ah_cuenta
WHERE ah_cta_banco = @i_cta
```

**POST — Validaciones en BD:**
```sql
-- Transaccion de correccion con signo FIJO = 'D' (ND siempre 'D', incluso en correccion)
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_creditos, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
-- ah_disponible  = disponible_previo + 200.00   (tfactor=1 revierte el debito original)
-- ah_debitos     = debitos_previo - 200.00       (factor_aux=-1; puede quedar negativo si debitos_previo < 200 — comportamiento natural del SP)
-- ah_debitos_hoy = debhoy_previo  - 200.00       (factor_aux=-1; idem, negativo es valido)
-- ah_creditos    sin cambio
```

**Resultado esperado:** `RETURN 0`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4264 (ND)
  - tm_signo = 'D' (fijo por tipo ND, no se invierte)
  - tm_correccion = 'S' (L:291 tfactor=1 indica reverso de debito)
  - tm_sec_correccion = @t_ssn_corr
  - tm_valor = 200
  - tm_control = NULL
  - tm_remoto_ssn = NULL
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = +200 (L:871 tfactor=1, revierte debito = acredita)
  - ah_debitos = -200 (L:864 factor_aux=-1)
  - ah_debitos_hoy = -200
  - ah_contador_trx = +1
- `ah_tran_servicio`: NINGUNO
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC23 — NC activa cuenta en estado 'D' (depósito inicial válido)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 16293 o 16294 |
| **@i_val** | 500.00 |
| **@i_cta** | Cuenta con `ah_estado = 'D'` |
| **@i_mon** | 1 |
| **@t_corr** | `'N'` |
| **@i_cau** | '0010' |

**Códigos asociados en el SP:** `@t_trn = 16293` o `16294`; ambos activan la validación de depósito inicial cuando la cuenta está en estado `D`.

**PRE — Estado requerido en BD:**
```sql
-- Forzar estado D antes de ejecutar (garantiza precondicion)
UPDATE cob_ahorros..ah_cuenta SET ah_estado = 'D' WHERE ah_cta_banco = '1681078511'
SELECT ah_estado, ah_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '1681078511'
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_creditos, ah_creditos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible, ah_estado FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '1681078511'
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '1681078511' AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0`, `ah_estado` cambia de `'D'` a `'A'`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 16293
  - tm_signo = 'C'
  - tm_valor = neto post-ICC
  - tm_control = NULL
  - tm_remoto_ssn = NULL
  - tm_valor_impuesto = ICC (si aplica)
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = +neto
  - ah_creditos = +neto
  - ah_creditos_hoy = +neto
  - ah_estado = 'A' (L:372 cambia de 'D' a 'A' porque trx 16293 activa la cuenta)
  - ah_contador_trx = +1
- `ah_tran_servicio`: NINGUNO
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC24 — NC genera transacción inusual (UAF)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4253 |
| **@i_val** | 6000.00 |
| **@i_cta** | '0000803372' |
| **@i_mon** | 1 |
| **@i_cau** | '0010' |

**Códigos asociados en el SP:** `@t_trn = 4253`; la causa depende de `cc_trx_ndc_uaf` y dispara el acumulador UAF si el par trx/causa está activo.

**PRE — Estado requerido en BD:**
```sql
-- Verificar umbrales configurados
SELECT pa_money FROM cobis..cl_parametro WHERE pa_nemonico = 'TRXINU' AND pa_producto = 'AHO'
SELECT pa_tinyint FROM cobis..cl_parametro WHERE pa_nemonico = 'VASAPR' AND pa_producto = 'AHO'

-- Verificar promedios de la cuenta
SELECT ah_promedio2, ah_promedio3, ah_promedio4, ah_promedio5, ah_promedio6
FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000803372'
-- Calcular: promedio_5 = (sum de los 5) / 5
-- El @i_val debe ser >= TRXINU Y >= (promedio_5 * VASAPR)

-- Contar registros actuales en cc_trx_inusuales para la cuenta
SELECT COUNT(*) FROM cob_cuentas..cc_trx_inusuales WHERE ti_cta_banco = '0000803372' -- N filas
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_creditos, ah_creditos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000803372'
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000803372' AND tm_secuencial = @o_ssn_monet
SELECT COUNT(*) as trx_inusuales FROM cob_cuentas..cc_trx_inusuales WHERE ti_cta_banco = '0000803372'
```

**Resultado esperado:** `RETURN 0` + registro en `cc_trx_inusuales`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999): igual que TC20
- `ah_cuenta` UPDATE (L:1228): igual que TC20
- `cc_trx_inusuales` INSERT (L:1475):
  - ti_trx = 4253
  - ti_cta_banco = @i_cta
  - ti_tipo = 'AHO'
  - ti_efectivo = @w_val_efe (monto >= umbral TRXINU)
  - ti_causa = @i_cau
- `ah_tran_servicio`: NINGUNO
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC25 — NC NO genera transacción inusual (bajo umbrales)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4253 |
| **@i_val** | 500.00 |
| **@i_cta** | Cuenta activa |
| **@i_mon** | 1 |
| **@i_cau** | '0010' |

**PRE — Estado requerido en BD:**
```sql
SELECT pa_money FROM cobis..cl_parametro WHERE pa_nemonico = 'TRXINU' AND pa_producto = 'AHO'
-- @i_val debe ser menor que este valor

SELECT COUNT(*) FROM cob_cuentas..cc_trx_inusuales WHERE ti_cta_banco = @i_cta -- N filas
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_creditos, ah_creditos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
SELECT COUNT(*) as trx_inusuales FROM cob_cuentas..cc_trx_inusuales WHERE ti_cta_banco = @i_cta
```

**Resultado esperado:** `RETURN 0` sin registro en `cc_trx_inusuales`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999): igual que TC20
- `ah_cuenta` UPDATE (L:1228): igual que TC20
- `cc_trx_inusuales`: NINGUNO (monto < umbral TRXINU, L:1468 condicion no se cumple)
- `ah_tran_servicio`: NINGUNO
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

## GRUPO 3 — Notas de Débito (ND)

---

### TC26 — ND con valor en suspenso (fondos parciales + 4570)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 600.00 |
| **@i_cta** | '0000617296' |
| **@i_cau** | '107' |
| **@i_mon** | 1 |

**PRE — Estado requerido en BD:**
```sql
UPDATE cob_ahorros..ah_cuenta SET ah_disponible = 400.00 WHERE ah_cta_banco = '0000617296'
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_suspensos FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000617296'
SELECT an_accion FROM cob_remesas..re_accion_nd WHERE an_producto = 4 AND an_causa = '107'
SELECT COUNT(*) as suspensos_pre FROM cob_ahorros..ah_val_suspenso WHERE vs_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000617296')
SELECT COUNT(*) as srv_pre FROM cob_ahorros..ah_tran_servicio WHERE ts_cta_banco = '0000617296' AND ts_tipo_transaccion = 4570
```

**Resultado esperado:** `RETURN 0`

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_suspensos, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000617296'
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000617296' AND tm_secuencial = @o_ssn_monet
SELECT vs_secuencial, vs_valor, vs_estado, vs_procesada, vs_valor_cobrado FROM cob_ahorros..ah_val_suspenso WHERE vs_secuencial = (SELECT tm_remoto_ssn FROM cob_ahorros..ah_tran_monet WHERE tm_secuencial = @o_ssn_monet)
SELECT ts_secuencial, ts_tipo_transaccion, ts_valor, ts_causa, ts_remoto_ssn, ts_oficina_cta FROM cob_ahorros..ah_tran_servicio WHERE ts_secuencial = @o_ssn_monet AND ts_tipo_transaccion = 4570
```

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4272 (ND)
  - tm_signo = 'D'
  - tm_valor = 400 (L:738 @w_val_efe = saldo disponible, no el total solicitado)
  - tm_control = NULL
  - tm_interes = NULL
  - tm_remoto_ssn = secuencial_suspenso (L:758 @w_sec_suspenso del nuevo suspenso)
- `ah_val_suspenso` INSERT (L:760):
  - vs_valor = 200 (L:738 @w_val = 600-400 = excedente)
  - vs_estado = 'N'
  - vs_procesada = 'N'
  - vs_valor_cobrado = 0
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = 0 (todo el disponible debitado)
  - ah_debitos = +400
  - ah_suspensos = +1 (L:753)
  - ah_contador_trx = +1
- `ah_tran_servicio` INSERT 4570 (L:1398):
  - ts_tipo_transaccion = 4570 (contabilizacion suspenso)
  - ts_valor = 200 (L:1420 @w_val = monto en suspenso)
  - ts_remoto_ssn = secuencial_suspenso (L:1421)
  - ts_causa = '107'
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC30 — ND exitosa con fondos suficientes

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 200.00 |
| **@i_cta** | '0000837312' |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |
| **@t_corr** | `'N'` |

**Códigos asociados en el SP:** `@t_trn = 4272`; la lógica ND también está contemplada para `4264`, `4372`, `16273`, `16274`, `16272`, `16499`, `16501`, `16497`, `16662`, `16663`, `16665`, `16667`, `16669`, `16238`, `16629`, `16643`, `16252`, `4404` y `4405`.

**PRE — Estado requerido en BD:**
```sql
-- Saldo suficiente (ejecutar sp_ahcalcula_saldo para verificar saldo_para_girar)
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_suspensos
FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837312'
-- ah_disponible debe ser >= 200.00

-- Acción ND configurada para la causa
SELECT an_accion FROM cob_remesas..re_accion_nd WHERE an_producto = 4 AND an_causa = '0001'
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837312'
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837312' AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4272 (ND)
  - tm_signo = 'D'
  - tm_valor = 200 (L:708 @w_val_efe = @i_val, fondos suficientes)
  - tm_control = NULL (L:1023 sin params A06)
  - tm_interes = NULL
  - tm_remoto_ssn = NULL (L:995 @w_sec_suspenso=0 → NULL, sin suspenso)
  - tm_valor_impuesto = 0
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = -200 (L:871 tfactor=-1)
  - ah_debitos = +200 (L:864 factor_aux=1)
  - ah_debitos_hoy = +200
  - ah_contador_trx = +1
- `ah_tran_servicio`: NINGUNO (L:1269 no es ATM, L:1392 @w_val=0 sin suspenso)
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC31 — ND sin fondos con acción 'E' (Error)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 1000.00 |
| **@i_cta** | Cuenta con saldo disponible < 1000.00 |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
-- Saldo insuficiente
SELECT ah_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
-- debe ser < 1000.00

-- Acción = 'E' para esta causa
SELECT an_accion FROM cob_remesas..re_accion_nd WHERE an_producto = 4 AND an_causa = '0001'
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta
```

**Resultado esperado:** `RETURN 041033`

**Trazabilidad por DB:**
- NINGUNO — SP retorna 41033 en L:822 (fondos insuficientes con accion 'E', ROLLBACK si tran abierta)

---

### TC32 — ND sin fondos con acción 'V' (Valor en suspenso)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 1000.00 |
| **@i_cta** | '0000873830' |
| **@i_mon** | 1 |
| **@i_cau** | '1017' |
| **@t_rty** | 'N' |

**PRE — Estado requerido en BD:**
```sql
SELECT ah_disponible, ah_suspensos FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000873830'
SELECT an_accion FROM cob_remesas..re_accion_nd WHERE an_producto = 4 AND an_causa = '1017'
SELECT COUNT(*) as suspensos_pre FROM cob_ahorros..ah_val_suspenso WHERE vs_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000873830') AND vs_estado = 'N'
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_suspensos, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000873830'
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000873830' AND tm_secuencial = @o_ssn_monet
SELECT vs_secuencial, vs_valor, vs_estado, vs_procesada, vs_valor_cobrado FROM cob_ahorros..ah_val_suspenso WHERE vs_secuencial = (SELECT tm_remoto_ssn FROM cob_ahorros..ah_tran_monet WHERE tm_secuencial = @o_ssn_monet)
SELECT ts_secuencial, ts_tipo_transaccion, ts_valor, ts_causa, ts_remoto_ssn, ts_oficina_cta FROM cob_ahorros..ah_tran_servicio WHERE ts_secuencial = @o_ssn_monet AND ts_tipo_transaccion = 4570
```

**Resultado esperado:** `RETURN 0`, cobro parcial registrado, diferencia en suspenso

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4272
  - tm_signo = 'D'
  - tm_valor = 300 (L:738 @w_val_efe = disponible, no el total)
  - tm_control = NULL
  - tm_remoto_ssn = secuencial_suspenso (L:758)
- `ah_val_suspenso` INSERT (L:760):
  - vs_valor = 700 (L:738 @w_val = 1000-300)
  - vs_estado = 'N'
  - vs_procesada = 'N'
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = 0
  - ah_debitos = +300
  - ah_suspensos = +1
  - ah_contador_trx = +1
- `ah_tran_servicio` INSERT 4570 (L:1398):
  - ts_tipo_transaccion = 4570
  - ts_valor = 700 (monto en suspenso)
  - ts_remoto_ssn = secuencial_suspenso
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC33 — ND reintento exitoso (cobro de valor en suspenso)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 700.00 (valor pendiente en suspenso) |
| **@i_cta** | Cuenta con saldo suficiente ahora |
| **@t_rty** | `'S'` |
| **@i_alt** | Secuencial del registro en `ah_val_suspenso` |
| **@i_cau** | '1017' |

**PRE — Estado requerido en BD:**
```sql
UPDATE cob_ahorros..ah_cuenta SET ah_disponible = 1000.00, ah_suspensos = 1 WHERE ah_cta_banco = '0000837834'
DELETE FROM cob_ahorros..ah_val_suspenso WHERE vs_cuenta = 3778 AND vs_secuencial = 1
INSERT INTO cob_ahorros..ah_val_suspenso (vs_cuenta, vs_secuencial, vs_servicio, vs_estado, vs_procesada, vs_valor, vs_fecha, vs_oficina, vs_hora, vs_ssn, vs_valor_cobrado) VALUES (3778, 1, '1017', 'N', 'N', 700.00, 'May 21 2026', 1, getdate(), 0, 0)
```

**POST — Validaciones en BD:**
```sql
DELETE FROM cob_ahorros..ah_val_suspenso WHERE vs_cuenta = 3778 AND vs_secuencial = 1
UPDATE cob_ahorros..ah_cuenta SET ah_disponible = 1000.00, ah_suspensos = 1 WHERE ah_cta_banco = '0000837834'
```

**Resultado esperado:** `RETURN 0`, suspenso cerrado

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4272
  - tm_signo = 'D'
  - tm_valor = 700 (monto completo, fondos suficientes para reintento)
  - tm_control = NULL
  - tm_remoto_ssn = NULL (L:995 @w_sec_suspenso=0 → NULL, reintento exitoso no genera nuevo suspenso)
- `ah_val_suspenso` UPDATE (L:828):
  - vs_procesada = 'S'
  - vs_estado = 'C' (cerrado)
  - vs_valor = 0 (todo cobrado)
  - vs_valor_cobrado = +700
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = -700
  - ah_debitos = +700
  - ah_suspensos = -1 (L:827)
  - ah_contador_trx = +1
- `ah_tran_servicio`: NINGUNO (L:1392 @w_val=0, no hay excedente)
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC34 — ND reintento parcial (saldo sigue insuficiente)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 700.00 |
| **@i_cta** | '0000837834' |
| **@t_rty** | `'S'` |
| **@i_alt** | 1 |
| **@i_cau** | '1017' |

**PRE — Estado requerido en BD:**
```sql
UPDATE cob_ahorros..ah_cuenta SET ah_disponible = 200.00, ah_suspensos = 1 WHERE ah_cta_banco = '0000837834'
INSERT INTO cob_ahorros..ah_val_suspenso (vs_cuenta, vs_secuencial, vs_servicio, vs_estado, vs_procesada, vs_valor, vs_fecha, vs_oficina, vs_hora, vs_ssn, vs_valor_cobrado) VALUES (3778, 1, '1017', 'N', 'N', 700.00, 'May 21 2026', 1, getdate(), 0, 0)
SELECT ah_disponible, ah_suspensos FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837834'
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_suspensos, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837834'
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837834' AND tm_secuencial = @o_ssn_monet
SELECT ts_secuencial, ts_tipo_transaccion, ts_valor, ts_causa, ts_remoto_ssn FROM cob_ahorros..ah_tran_servicio WHERE ts_secuencial = @o_ssn_monet AND ts_tipo_transaccion = 4570
DELETE FROM cob_ahorros..ah_val_suspenso WHERE vs_cuenta = 3778 AND vs_secuencial = 1
```

**Resultado esperado:** `RETURN 0`, cobro parcial incremental

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4272
  - tm_signo = 'D'
  - tm_valor = 200 (L:738 @w_val_efe = disponible parcial)
  - tm_control = NULL
  - tm_remoto_ssn = NULL (L:995 @w_sec_suspenso=0 → NULL en reintento parcial con UPDATE)
- `ah_val_suspenso` UPDATE (L:744):
  - vs_valor = 500 (L:738 @w_val = 700-200, sigue pendiente)
  - vs_fecha_ult_cobro = @i_fecha
  - vs_valor_cobrado = +200 (acumula cobro parcial)
  - vs_estado = 'N' (NO cambia, sigue pendiente)
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = 0
  - ah_debitos = +200
  - ah_contador_trx = +1
  - ah_suspensos = sin cambio (no se incrementa ni decrementa)
- `ah_tran_servicio` INSERT 4570 (L:1398):
  - ts_tipo_transaccion = 4570 (L:1392 @w_val=500 != 0 AND @w_reintento='N')
  - ts_valor = 500 (monto que sigue en suspenso)
  - ts_remoto_ssn = NULL
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC35 — ND especial 4372 (genera servicio 4373)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4372 |
| **@i_val** | 500.00 |
| **@i_cta** | Cuenta activa con fondos suficientes |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |

**Códigos asociados en el SP:** `@t_trn = 4372`; genera contabilización de servicio `4373`.

**PRE — Estado requerido en BD:**
```sql
SELECT ah_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
-- >= 500.00
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
SELECT ts_secuencial, ts_tipo_transaccion, ts_valor, ts_causa, ts_remoto_ssn, ts_oficina_cta, ts_clase, ts_saldo, ts_monto FROM cob_ahorros..ah_tran_servicio WHERE ts_cta_banco = @i_cta AND ts_tipo_transaccion = 4373 AND ts_secuencial > @o_ssn_monet
```

**Resultado esperado:** `RETURN 0`, registro en `ah_tran_servicio` con tipo `4373`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4372
  - tm_signo = 'D'
  - tm_valor = 500
  - tm_control = NULL
  - tm_remoto_ssn = NULL (L:1073 @w_sec_suspenso = null)
- `ah_tran_servicio` INSERT 4373 (L:1075):
  - ts_tipo_transaccion = 4373 (L:1089)
  - ts_valor = 500 (L:1097 @w_val_efe)
  - ts_remoto_ssn = NULL (L:1098 @w_sec_suspenso)
  - ts_clase = NULL (no se incluye en INSERT del SP)
  - ts_saldo = NULL (no se incluye en INSERT del SP)
  - ts_monto = NULL (no se incluye en INSERT del SP)
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = -500
  - ah_debitos = +500
  - ah_contador_trx = +1
- `ah_tran_servicio` 4570: NINGUNO (L:1392 @w_reintento='S' por L:1134)
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC36 — ND con bloqueo activo pero causa en catálogo bypass

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 100.00 |
| **@i_cta** | Cuenta bloqueada |
| **@i_cau** | '400' |
| **@s_user** | Usuario normal (no rrhh) |

**PRE — Estado requerido en BD:**
```sql
SELECT cb_tipo_bloqueo FROM cob_ahorros..ah_ctabloqueada WHERE cb_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta) AND cb_estado = 'V'
SELECT codigo FROM cobis..cl_catalogo WHERE tabla = (SELECT codigo FROM cobis..cl_tabla WHERE tabla = 'ah_bloqueo_nd') AND codigo = '400'
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0` (bloqueo ignorado por catálogo)

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999): igual que TC30 (ND fondos OK)
  - tm_tipo_tran = 4272, tm_signo = 'D', tm_valor = 100
  - tm_control = NULL, tm_remoto_ssn = NULL
- `ah_cuenta` UPDATE (L:1228): igual que TC30
  - ah_disponible = -100, ah_debitos = +100, ah_contador_trx = +1
- `ah_tran_servicio`: NINGUNO
- Nota: bypass por L:319-324 (causa '400' en catalogo ah_bloqueo_nd → @w_tipo1='9')
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC37 — ND con IVA aplicable

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 100.00 |
| **@i_cta** | Cuenta activa con fondos |
| **@i_cau** | '943' |
| **@t_corr** | `'N'` |

**PRE — Estado requerido en BD:**
```sql
SELECT an_iva, an_iva_cero FROM cob_remesas..re_accion_nd WHERE an_producto = 4 AND an_causa = '943'
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0`, IVA calculado y registrado

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999): igual que TC30
  - tm_tipo_tran = 4272, tm_signo = 'D', tm_valor = 100
  - tm_control = NULL, tm_remoto_ssn = NULL
  - tm_valor_impuesto = IVA calculado por sp_imp_valor_agregado (L:1147)
- `ah_cuenta` UPDATE (L:1228): igual que TC30
  - ah_disponible = -100, ah_debitos = +100, ah_contador_trx = +1
- `ah_tran_servicio`: NINGUNO
- SP hijo: sp_imp_valor_agregado (L:1147) calcula IVA internamente
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

## GRUPO 4 — ATM

---

### TC40 — ND ATM estándar (16238)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 16238 |
| **@i_val** | 200.00 |
| **@i_cta** | Cuenta activa con fondos suficientes |
| **@i_mon** | 1 |
| **@i_cau** | '14' |

**Códigos asociados en el SP:** `@t_trn = 16238`; el bloque ATM también incluye `16629`, `16643` y `16252`.

**PRE — Estado requerido en BD:**
```sql
SELECT ah_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta -- >= 200.00
SELECT COUNT(*) FROM cob_ahorros..ah_tran_servicio WHERE ts_cta_banco = @i_cta -- N filas
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
SELECT ts_secuencial, ts_tipo_transaccion, ts_valor, ts_causa, ts_remoto_ssn, ts_oficina_cta FROM cob_ahorros..ah_tran_servicio WHERE ts_secuencial = @o_ssn_monet AND ts_tipo_transaccion = 16238
```

**Resultado esperado:** `RETURN 0`, doble registro en `ah_tran_servicio`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 16238 (ATM)
  - tm_signo = 'D'
  - tm_valor = 200 (fondos suficientes, @w_val_efe = @i_val)
  - tm_control = NULL
  - tm_remoto_ssn = NULL (sin suspenso, @w_val=0)
- `ah_tran_servicio` INSERT 16238 (L:1271):
  - ts_tipo_transaccion = 16238 (mismo que trn)
  - ts_valor = 0 (L:1291 @w_val = monto suspenso = 0)
  - ts_saldo = 200 (L:1291 @w_val_efe)
  - ts_monto = NULL (L:1291 @i_valch)
  - ts_tsn = @i_tsn
  - ts_ubicacion = @i_ubi
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = -200, ah_debitos = +200, ah_contador_trx = +1
- `ah_tran_servicio` 4570: NINGUNO (L:1328 @w_val=0)
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC41 — ND ATM con fondos parciales (genera suspenso + 4570)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 16238 |
| **@i_val** | 500.00 |
| **@i_cta** | Cuenta con saldo = 200.00 |
| **@i_cau** | '1017' |

**Códigos asociados en el SP:** `@t_trn = 16238`; para ATM débito el SP también procesa `16629`, `16643` y `16252`, generando servicio `4570` cuando hay suspenso.

**PRE — Estado requerido en BD:**
```sql
SELECT ah_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta -- = 200.00
SELECT an_accion FROM cob_remesas..re_accion_nd WHERE an_producto = 4 AND an_causa = '1017'
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_suspensos, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
SELECT vs_secuencial, vs_valor, vs_estado, vs_procesada, vs_valor_cobrado FROM cob_ahorros..ah_val_suspenso WHERE vs_secuencial = (SELECT tm_remoto_ssn FROM cob_ahorros..ah_tran_monet WHERE tm_secuencial = @o_ssn_monet)
SELECT ts_secuencial, ts_tipo_transaccion, ts_valor, ts_causa, ts_remoto_ssn FROM cob_ahorros..ah_tran_servicio WHERE ts_secuencial = @o_ssn_monet AND ts_tipo_transaccion = 16238
SELECT ts_secuencial, ts_tipo_transaccion, ts_valor, ts_causa, ts_remoto_ssn FROM cob_ahorros..ah_tran_servicio WHERE ts_secuencial = @o_ssn_monet AND ts_tipo_transaccion = 4570
```

**Resultado esperado:** `RETURN 0`, valor en suspenso + contabilización 4570

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 16238 (ATM)
  - tm_signo = 'D'
  - tm_valor = 200 (L:738 @w_val_efe = disponible parcial)
  - tm_control = NULL
  - tm_remoto_ssn = secuencial_suspenso (L:758)
- `ah_val_suspenso` INSERT (L:760):
  - vs_valor = 300 (L:738 @w_val = 500-200)
  - vs_estado = 'N'
- `ah_tran_servicio` INSERT 16238 (L:1271):
  - ts_tipo_transaccion = 16238
  - ts_valor = 300 (L:1291 @w_val = suspenso)
  - ts_saldo = 200 (L:1291 @w_val_efe = debitado)
  - ts_monto = NULL (@i_valch)
- `ah_tran_servicio` INSERT 4570 (L:1333):
  - ts_tipo_transaccion = 4570 (L:1326-1328 ATM con @w_val!=0)
  - ts_valor = 300 (monto en suspenso)
  - ts_remoto_ssn = secuencial_suspenso
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = 0, ah_debitos = +200, ah_suspensos = +1, ah_contador_trx = +1
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

## GRUPO 5 — Transferencias y Casos Especiales

---

### TC50 — NC transferencia con cotización (causa 32)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4253 |
| **@i_cau** | '32' |
| **@i_val** | 500.00 |
| **@i_cta** | Cuenta activa |
| **@i_cotiza** | 1.25 (cotización) |
| **@i_ref** | Referencia de la transferencia |
| **@i_tarjeta** | Cuenta destino (como referencia) |

**Códigos asociados en el SP:** `@t_trn = 4253`, `@i_cau = '32'`.

**PRE — Estado requerido en BD:**
```sql
SELECT COUNT(*) FROM cob_cuentas..cc_monet_transfer WHERE mt_cta_banco_deb = @i_cta -- N filas
SELECT ah_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_creditos, ah_creditos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
SELECT mt_ssn_monet, mt_tipo_tran, mt_causa, mt_producto, mt_cta_banco_deb, mt_valor, mt_moneda, mt_cotiza FROM cob_cuentas..cc_monet_transfer WHERE mt_ssn_monet = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0`, registro en `cc_monet_transfer`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999): igual que TC20 (NC)
- `ah_cuenta` UPDATE (L:1228): igual que TC20
- `cc_monet_transfer` INSERT (L:1179):
  - mt_tipo_tran = 4253 (L:1176 condicion trn=4253 AND causa='32')
  - mt_causa = 32
  - mt_valor = @w_val_efe (500)
  - mt_cotiza = @i_cotiza (1.25 — tipo float en BD)
  - mt_moneda = @i_mon (1)
  - mt_producto = 'AHO'
- `ah_tran_servicio`: NINGUNO
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC51 — ND transferencia con cotización (causa 940)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_cau** | '940' |
| **@i_val** | 500.00 |
| **@i_cta** | Cuenta activa con fondos |
| **@i_cotiza** | 0.90 |

**Códigos asociados en el SP:** `@t_trn = 4272`, `@i_cau = '940'`.

**PRE — Estado requerido en BD:**
```sql
SELECT ah_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta -- >= 500.00
SELECT COUNT(*) FROM cob_cuentas..cc_monet_transfer WHERE mt_cta_banco_deb = @i_cta -- N filas
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
SELECT mt_ssn_monet, mt_tipo_tran, mt_causa, mt_producto, mt_cta_banco_deb, mt_valor, mt_moneda, mt_cotiza FROM cob_cuentas..cc_monet_transfer WHERE mt_ssn_monet = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999): igual que TC30 (ND)
- `ah_cuenta` UPDATE (L:1228): igual que TC30
- `cc_monet_transfer` INSERT (L:1179):
  - mt_tipo_tran = 4272 (L:1176 condicion trn=4272 AND causa='940')
  - mt_causa = 940
  - mt_valor = @w_val_efe (500)
  - mt_cotiza = @i_cotiza (0.9 — tipo float en BD)
- `ah_tran_servicio`: NINGUNO
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC52 — Canal CNB con empresa 783 (sin nuevo secuencial)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4253 |
| **@i_canal** | `'CNB'` |
| **@i_empresa** | 783 |
| **@s_ssn** | 0 |
| **@i_val** | 200.00 |
| **@i_cta** | Cuenta activa |
| **@i_cau** | '0010' |

**Códigos asociados en el SP:** para canal `CNB`, el SP reutiliza el secuencial cuando `@i_empresa = 783`. El `@s_ssn` debe ser un secuencial real existente para esta cuenta.

**PRE — Estado requerido en BD:**
```sql
-- Obtener secuencial que NO exista en ah_tran_monet para usarlo como @s_ssn (global MAX+1 garantiza unicidad)
SELECT MAX(tm_secuencial) + 1 as s_ssn FROM cob_ahorros..ah_tran_monet
SELECT ah_disponible, ah_debitos, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000629780'
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_creditos, ah_creditos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000629780'
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000629780' AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0`, se reutiliza el SSN del canal CNB

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999): igual que TC20 (NC) pero:
  - tm_secuencial = @s_ssn original (L:307-311 CNB empresa=783 NO genera nuevo secuencial)
  - tm_control = NULL
  - tm_remoto_ssn = NULL
- `ah_cuenta` UPDATE (L:1228): igual que TC20
- `ah_tran_servicio`: NINGUNO
- Nota: L:307 `if @i_canal='CNB'` → L:309 `if @i_empresa<>783` → FALSE → no exec sp_gen_sec
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC53 — Acumulador UAF activado

| Campo | Detalle |
|-------|---------|
| **@t_trn** | `4253` / `4272` o trx existente en `cc_trx_ndc_uaf` con estado 'A' |
| **@i_val** | 300.00 |
| **@i_cta** | Cuenta activa |
| **@i_cau** | '135' |

**Códigos asociados en el SP:** `4253 + 802` y `4272 + 801` son los pares quemados para corrección de UAF.

**PRE — Estado requerido en BD:**
```sql
-- Trx/causa debe estar activa en UAF
SELECT tn_tipo_trx, tn_causa, tn_estado FROM cob_cuentas..cc_trx_ndc_uaf WHERE tn_tipo_trx = 4253 AND tn_causa = '135' AND tn_estado = 'A'
-- debe existir al menos 1 fila

-- Pares quemados por el SP para corrección de UAF:
-- 4253 + 802
-- 4272 + 801

-- Estado acumulador del cliente (sp_uif_acum lo actualizará internamente)
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_creditos, ah_creditos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
SELECT COUNT(*) as trx_inusuales FROM cob_cuentas..cc_trx_inusuales WHERE ti_cta_banco = @i_cta
```

**Resultado esperado:** `RETURN 0`, acumulador UAF incrementado

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999): igual que TC20 (NC)
- `ah_cuenta` UPDATE (L:1228): igual que TC20
- `cc_uif` INSERT/UPDATE (via sp_uif_acum L:941):
  - ui_uso += @w_total_uif (monto - comision)
  - ui_contador += 1
- `ah_tran_servicio`: NINGUNO
- Nota: sp_uif_acum se invoca porque trn/causa existe en cc_trx_ndc_uaf (config permanente 4253/0001)
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC54 — Cuenta categoría 'U' (CTA MAS) bypass bloqueo

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 100.00 |
| **@i_cta** | '0002029364' |
| **@i_cau** | '464' |

**Códigos asociados en el SP:** la combinación `@t_trn` / `@i_cau` debe existir como clave compuesta `@t_trn-@i_cau` en `ah_ncnd_ctmas_trxpermitidas`, o bien como `codigo = @t_trn` y `valor = @i_cau` en `ah_ctmas_pago_directo`, para omitir el bloqueo en cuentas categoría `U`.

**PRE — Estado requerido en BD:**
```sql
SELECT ah_categoria FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0002029364'
SELECT cb_tipo_bloqueo, cb_estado FROM cob_ahorros..ah_ctabloqueada WHERE cb_cuenta = '0002029364' AND cb_estado = 'V'
SELECT codigo, valor FROM cobis..cl_catalogo WHERE tabla = (SELECT codigo FROM cobis..cl_tabla WHERE tabla = 'ah_ncnd_ctamas_trxpermitidas') AND valor = '4272-464' AND estado = 'V'
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0002029364'
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0002029364' AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0` (bloqueo ignorado por categoría CTA MAS)

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999): igual que TC30 (ND fondos OK)
  - tm_tipo_tran = 4272, tm_signo = 'D', tm_valor = 100
  - tm_control = NULL, tm_remoto_ssn = NULL
- `ah_cuenta` UPDATE (L:1228): igual que TC30
  - ah_disponible = -100, ah_debitos = +100, ah_contador_trx = +1
- `ah_tran_servicio`: NINGUNO
- Nota: bypass por L:510-518 (categoria 'U' + '4272-464' en ah_ncnd_ctamas_trxpermitidas)
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

## GRUPO 6 — Errores y Rollback

---

### TC60 — Fallo al insertar en ah_tran_monet

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4253 |
| **@i_val** | 100.00 |
| **@i_cta** | '7001407995' |
| **@i_cau** | '0010' |

**PRE — Estado requerido en BD:**
```sql
SELECT ah_disponible, ah_creditos, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '7001407995'
ALTER TABLE cob_ahorros..ah_tran_monet ADD CONSTRAINT ck_tc60_block CHECK (1=0)
```

**POST — Validaciones en BD:**
```sql
ALTER TABLE cob_ahorros..ah_tran_monet DROP CONSTRAINT ck_tc60_block
SELECT ah_disponible, ah_creditos, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '7001407995'
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '7001407995'
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_servicio WHERE ts_cta_banco = '7001407995'
```

**Resultado esperado:** `RETURN 43000`

**Trazabilidad por DB:**
- NINGUNO — INSERT ah_tran_monet falla por constraint (L:1038), ROLLBACK TRANSACTION pndcca (L:1057-1058)

---

### TC61 — Fallo al actualizar ah_cuenta (@@rowcount != 1)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 100.00 |
| **@i_cta** | '7001407693' |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
UPDATE cob_ahorros..ah_cuenta SET ah_disponible = 5000.00 WHERE ah_cta_banco = '7001407693'
SELECT ah_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '7001407693'
ALTER TABLE cob_ahorros..ah_cuenta ADD CONSTRAINT ck_tc61_block CHECK (ah_cta_banco != '7001407693' OR 1=0)
```

**POST — Validaciones en BD:**
```sql
ALTER TABLE cob_ahorros..ah_cuenta DROP CONSTRAINT ck_tc61_block
SELECT ah_disponible, ah_debitos, ah_contador_trx, ah_suspensos FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '7001407693'
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '7001407693'
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_servicio WHERE ts_cta_banco = '7001407693'
UPDATE cob_ahorros..ah_cuenta SET ah_disponible = 5000.00 WHERE ah_cta_banco = '7001407693'
```

**Resultado esperado:** `RETURN 35001`

---

### TC62 — Fallo al insertar en ah_val_suspenso

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 1000.00 |
| **@i_cta** | '7001406993' |
| **@i_cau** | '1017' |

**PRE — Estado requerido en BD:**
```sql
UPDATE cob_ahorros..ah_cuenta SET ah_disponible = 300.00 WHERE ah_cta_banco = '7001406993'
SELECT ah_disponible, ah_suspensos FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '7001406993'
ALTER TABLE cob_ahorros..ah_val_suspenso ADD CONSTRAINT ck_tc62_block CHECK (1=0)
```

**POST — Validaciones en BD:**
```sql
ALTER TABLE cob_ahorros..ah_val_suspenso DROP CONSTRAINT ck_tc62_block
SELECT ah_disponible, ah_debitos, ah_contador_trx, ah_suspensos FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '7001406993'
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '7001406993'
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_servicio WHERE ts_cta_banco = '7001406993'
```

**Resultado esperado:** `RETURN 43004`

**Trazabilidad por DB:**
- NINGUNO — INSERT ah_val_suspenso falla por constraint (L:769), ROLLBACK TRANSACTION pndcca (L:784-787)

---

### TC63 — Fallo en sp_uif_acum

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4253 |
| **@i_val** | 300.00 |
| **@i_cta** | '0000837312' |
| **Descripción** | Simular que `sp_uif_acum` retorna error por cedula invalida (8 digitos != 10 requeridos) |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
SELECT ah_disponible, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837312'
UPDATE cobis..cl_ente SET en_ced_ruc = '12345678' WHERE en_ente = 26806
```

**POST — Validaciones en BD:**
```sql
UPDATE cobis..cl_ente SET en_ced_ruc = '905317079' WHERE en_ente = 26806
SELECT ah_disponible, ah_debitos, ah_contador_trx FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837312'
SELECT COUNT(*) as cnt FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837312'
```

**Resultado esperado:** `RETURN 149076`

**Trazabilidad por DB:**
- NINGUNO — sp_uif_acum falla por cedula invalida (8 digitos != 10), SP padre retorna 149076 en L:971, ROLLBACK TRANSACTION pndcca (L:966-969)

---

### TC64 — Doble ejecución simultánea (concurrencia)

| Campo | Detalle |
|-------|---------|
| **Descripción** | Dos llamadas al SP con la misma cuenta y mismo monto de forma paralela |
| **@t_trn** | 4272 |
| **@i_val** | 500.00 |
| **@i_cta** | Cuenta con saldo = 600.00 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
SELECT ah_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta -- = 600.00
```

**Ejecución:** Lanzar dos hilos/conexiones en paralelo.

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** Ambas retornan `RETURN 0` pero saldo debe ser consistente ⚠️ R01

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT x2 (L:999): dos registros independientes con secuenciales distintos
- `ah_cuenta` UPDATE x2 (L:1228): saldo final = disponible_original - (2 * @i_val)
  - ah_disponible = -500 -500, ah_debitos = +500 +500, ah_contador_trx = +2
- Lock serializado por UPDATE ah_cuenta (datarows lock)
- Nota: SP no tiene idempotencia — ambas ejecuciones son transacciones independientes
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC65 — API timeout y reintento (idempotencia)

| Campo | Detalle |
|-------|---------|
| **Descripción** | La primera llamada se procesa pero la API no recibe respuesta; se reintenta |
| **@t_trn** | 4253 |
| **@i_val** | 200.00 |
| **@i_cta** | Cuenta activa |
| **@i_cau** | '0010' |

**PRE — Estado requerido en BD:**
```sql
SELECT ah_disponible, ah_creditos FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT COUNT(*) FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta -- N filas
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_creditos, ah_creditos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_sec_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0` — Idempotencia NO está implementada, documentar como defecto conocido ⚠️ R02

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999): igual que TC20 (NC estandar)
- `ah_cuenta` UPDATE (L:1228): igual que TC20
- Nota: SP no tiene idempotencia — si se ejecuta dos veces con mismos parametros, genera 2 transacciones. El control de idempotencia debe estar en la capa API (Idempotency-Key).
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

## GRUPO 7 — Campos A06 (REF 61)

---

### TC70 — Comisión individual A06

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 100.00 |
| **@i_cta** | Cuenta activa |
| **@i_comision_indiv** | 5.00 |
| **@i_cant** | 1 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
SELECT ah_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta -- >= 100.00
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta, tm_chq_ot_plazas, tm_tipo_xfer FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0`, `tm_chq_ot_plazas = 5.00`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4272, tm_signo = 'D', tm_valor = 100
  - tm_control = 1 (L:1023 isnull(@i_control, @i_cant) = isnull(NULL, 1) = 1)
  - tm_chq_ot_plazas = 5.00 (L:1033 @i_comision_indiv)
  - tm_tipo_xfer = NULL (L:1034 @i_comision_cero)
  - tm_remoto_ssn = NULL
- `ah_cuenta` UPDATE (L:1228): igual que TC30
- `ah_tran_servicio`: NINGUNO
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

### TC71 — Débito con indicador de comisión cero (empresa asume comisión)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 100.00 |
| **@i_cta** | Cuenta activa |
| **@i_comision_cero** | `'S'` |
| **@i_comision_indiv** | 0.00 |
| **@i_cau** | '0001' |

**PRE — Estado requerido en BD:**
```sql
SELECT ah_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta -- >= 100.00
```

**POST — Validaciones en BD:**
```sql
SELECT ah_disponible, ah_debitos, ah_debitos_hoy, ah_contador_trx, ah_promedio1, ah_prom_disponible FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = @i_cta
SELECT tm_secuencial, tm_tipo_tran, tm_valor, tm_signo, tm_correccion, tm_saldo_disponible, tm_saldo_contable, tm_remoto_ssn, tm_control, tm_valor_impuesto, tm_oficina_cta, tm_chq_ot_plazas, tm_tipo_xfer FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = @i_cta AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0`, indicador `'S'` propagado a registros de auditoría

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4272, tm_signo = 'D', tm_valor = 100
  - tm_control = NULL (L:1023 isnull(@i_control, @i_cant) = isnull(NULL, NULL) = NULL)
  - tm_chq_ot_plazas = 0 (L:1033 @i_comision_indiv = 0)
  - tm_tipo_xfer = 'S' (L:1034 @i_comision_cero = 'S')
  - tm_remoto_ssn = NULL
- `ah_cuenta` UPDATE (L:1228): igual que TC30
- `ah_tran_servicio`: NINGUNO
- `ah_linea_pendiente` INSERT (via sp_genera_linea_pendiente L:877): se ejecuta si @w_val_efe != 0

---

## GRUPO 8 — Valores Límite y Comparación Completa (disponible=0, val_efe=0)

> **Metodología de comparación:** En estos TCs, el POST usa `SELECT *` para captura completa de la fila. La comparación SP vs REST debe ser campo a campo de TODOS los campos de cada tabla — no solo los que el SP modifica. Si el micro toca un campo que el SP deja intacto, es un hallazgo.

---

### TC80 — ND con disponible=0, acción 'V' (todo va a suspenso, nada se debita)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 500.00 |
| **@i_cta** | '0000837010' |
| **@i_mon** | 1 |
| **@i_cau** | '1017' |
| **@t_rty** | 'N' |

**PRE — Estado requerido en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837010'
-- ah_disponible debe ser 0.00, ah_estado = 'A'
SELECT an_accion FROM cob_remesas..re_accion_nd WHERE an_producto = 4 AND an_causa = '1017'
-- debe retornar 'V'
SELECT COUNT(*) as suspensos_pre FROM cob_ahorros..ah_val_suspenso WHERE vs_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837010') AND vs_estado = 'N'
SELECT COUNT(*) as tran_monet_pre FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837010'
SELECT COUNT(*) as tran_serv_pre FROM cob_ahorros..ah_tran_servicio WHERE ts_cta_banco = '0000837010'
```

**POST — Validaciones en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837010'
SELECT * FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837010' AND tm_secuencial = @o_ssn_monet
SELECT * FROM cob_ahorros..ah_val_suspenso WHERE vs_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837010') AND vs_estado = 'N' AND vs_secuencial > 0 ORDER BY vs_secuencial DESC
SELECT * FROM cob_ahorros..ah_tran_servicio WHERE ts_cta_banco = '0000837010' AND ts_tipo_transaccion = 4570 AND ts_hora > @timestamp_pre
-- ah_linea_pendiente NO debe tener registro nuevo (val_efe=0 → sp_genera_linea_pendiente NO se ejecuta)
SELECT COUNT(*) as lineas_post FROM cob_ahorros..ah_linea_pendiente WHERE lp_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837010')
```

**Resultado esperado:** `RETURN 0`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4272, tm_signo = 'D'
  - tm_valor = 0.00 (L:736 @w_val_efe = $0, saldo_para_girar <= 0)
  - tm_control = NULL
  - tm_remoto_ssn = secuencial_suspenso (L:758 @w_sec_suspenso del nuevo suspenso)
  - tm_valor_impuesto = 0
  - tm_saldo_disponible = 0.00 (no cambia, disponible ya era 0)
  - tm_saldo_contable = saldo_contable previo (sin cambio por val_efe=0)
- `ah_val_suspenso` INSERT (L:760):
  - vs_valor = 500.00 (L:735 @w_val = @i_val, TODO el monto va a suspenso)
  - vs_estado = 'N'
  - vs_procesada = 'N'
  - vs_valor_cobrado = 0
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = 0.00 (sin cambio, += $0 * tfactor)
  - ah_debitos = sin cambio (L:864 += $0 * factor_aux = 0)
  - ah_debitos_hoy = sin cambio
  - ah_suspensos = +1 (L:753)
  - ah_contador_trx = +1
  - ah_promedio1 = sin cambio (alic = $0 * alicuota = 0)
  - ah_prom_disponible = sin cambio
- `ah_linea_pendiente`: NINGUNO (L:875 condicion @w_val_efe != 0 es FALSE)
- `ah_tran_servicio` INSERT 4570 (L:1398):
  - ts_tipo_transaccion = 4570
  - ts_valor = 500.00 (L:1420 @w_val = monto completo en suspenso)
  - ts_remoto_ssn = secuencial_suspenso
- **Campos que NO deben cambiar en ah_cuenta:** ah_creditos, ah_creditos_hoy, ah_12h, ah_24h, ah_48h, ah_72h_diferido, ah_remesas, ah_interes, ah_saldo_libreta, ah_saldo_interes, ah_saldo_anterior, ah_promedio2-6, ah_estado (sigue 'A')

---

### TC81 — NC con val_efe=0 (ICC retiene todo el monto)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4253 |
| **@i_val** | 0.01 |
| **@i_cta** | '0000837312' |
| **@i_mon** | 1 |
| **@i_cau** | '0010' |
| **@i_prod** | 'AHO' |

**PRE — Estado requerido en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837312'
SELECT COUNT(*) as tran_monet_pre FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837312'
```

**POST — Validaciones en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837312'
SELECT * FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837312' AND tm_secuencial = @o_ssn_monet
-- Si ICC retiene todo: val_efe=0 → NO inserta linea_pendiente
SELECT COUNT(*) as lineas_post FROM cob_ahorros..ah_linea_pendiente WHERE lp_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837312')
```

**Resultado esperado:** `RETURN 0` — Si ICC actual es 0%, val_efe = 0.01 y se procesa normalmente. Si ICC > 0% y retiene todo, val_efe = 0 y no genera linea_pendiente.

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4253, tm_signo = 'C'
  - tm_valor = @w_val_efe (0.01 si ICC=0%, o 0.00 si ICC retiene todo)
  - tm_valor_impuesto = ICC calculado por sp_impuesto_flujo_capital
  - tm_control = NULL
  - tm_remoto_ssn = NULL
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = += val_efe * tfactor(+1) (puede ser +0.01 o +0.00)
  - ah_creditos = += val_efe
  - ah_creditos_hoy = += val_efe
  - ah_contador_trx = +1
- `ah_linea_pendiente`: CONDICIONAL (solo si val_efe != 0)
- `ah_tran_servicio`: NINGUNO
- **Campos que NO deben cambiar en ah_cuenta:** ah_debitos, ah_debitos_hoy, ah_suspensos, ah_12h, ah_24h, ah_48h, ah_72h_diferido, ah_remesas, ah_interes, ah_saldo_libreta

---

### TC82 — ND ATM 16238 con disponible=0, acción 'V' (todo a suspenso + doble servicio)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 16238 |
| **@i_val** | 200.00 |
| **@i_cta** | '0000838650' |
| **@i_mon** | 1 |
| **@i_cau** | '1017' |
| **@t_rty** | 'N' |

**PRE — Estado requerido en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000838650'
-- ah_disponible debe ser 0.00
SELECT an_accion FROM cob_remesas..re_accion_nd WHERE an_producto = 4 AND an_causa = '1017'
SELECT COUNT(*) as tran_monet_pre FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000838650'
SELECT COUNT(*) as tran_serv_pre FROM cob_ahorros..ah_tran_servicio WHERE ts_cta_banco = '0000838650'
```

**POST — Validaciones en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000838650'
SELECT * FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000838650' AND tm_secuencial = @o_ssn_monet
SELECT * FROM cob_ahorros..ah_val_suspenso WHERE vs_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000838650') AND vs_estado = 'N' ORDER BY vs_secuencial DESC
SELECT * FROM cob_ahorros..ah_tran_servicio WHERE ts_cta_banco = '0000838650' AND ts_hora > @timestamp_pre ORDER BY ts_tipo_transaccion
-- Debe haber 2 registros: uno con ts_tipo_transaccion=16238 y otro con 4570
SELECT COUNT(*) as lineas_post FROM cob_ahorros..ah_linea_pendiente WHERE lp_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000838650')
```

**Resultado esperado:** `RETURN 0`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 16238, tm_signo = 'D'
  - tm_valor = 0.00 (L:736 @w_val_efe = $0)
  - tm_remoto_ssn = secuencial_suspenso
- `ah_val_suspenso` INSERT (L:760):
  - vs_valor = 200.00 (todo a suspenso)
  - vs_estado = 'N', vs_procesada = 'N', vs_valor_cobrado = 0
- `ah_tran_servicio` INSERT 16238 (L:1271):
  - ts_tipo_transaccion = 16238
  - ts_valor = 200.00 (L:1291 @w_val = todo en suspenso)
  - ts_saldo = 0.00 (L:1291 @w_val_efe = 0)
  - ts_monto = NULL (@i_valch)
- `ah_tran_servicio` INSERT 4570 (L:1333):
  - ts_tipo_transaccion = 4570 (L:1326-1328 @w_val=200 != 0)
  - ts_valor = 200.00
  - ts_remoto_ssn = secuencial_suspenso
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = 0.00 (sin cambio)
  - ah_debitos = sin cambio (val_efe=0)
  - ah_debitos_hoy = sin cambio
  - ah_suspensos = +1
  - ah_contador_trx = +1
- `ah_linea_pendiente`: NINGUNO (val_efe=0)
- **Campos que NO deben cambiar en ah_cuenta:** ah_creditos, ah_creditos_hoy, ah_promedio1, ah_prom_disponible (alic=0), ah_12h, ah_24h, ah_estado

---

### TC83 — NC sobre cuenta inactiva 'I' con permiso en cc_control_movimientos

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4253 |
| **@i_val** | 100.00 |
| **@i_cta** | '0000842500' |
| **@i_mon** | 1 |
| **@i_cau** | '400' |

**PRE — Estado requerido en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000842500'
-- ah_estado debe ser 'I'
SELECT cm_transaccion, cm_causa FROM cob_cuentas..cc_control_movimientos WHERE cm_producto = 4 AND cm_transaccion = 4253 AND cm_causa = '400'
-- debe existir (permiso de movimiento para cuenta inactiva)
SELECT COUNT(*) as tran_monet_pre FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000842500'
```

**POST — Validaciones en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000842500'
SELECT * FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000842500' AND tm_secuencial = @o_ssn_monet
SELECT COUNT(*) as lineas_post FROM cob_ahorros..ah_linea_pendiente WHERE lp_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000842500')
```

**Resultado esperado:** `RETURN 0` — Cuenta inactiva pero la combinación 4253/'400' está permitida en cc_control_movimientos

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4253, tm_signo = 'C'
  - tm_valor = 100.00 (val_efe, NC sin ICC relevante)
  - tm_control = NULL
  - tm_remoto_ssn = NULL
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = +100.00
  - ah_creditos = +100.00
  - ah_creditos_hoy = +100.00
  - ah_contador_trx = +1
  - ah_estado = 'I' (NO cambia a 'A' porque ya no está en 'D')
- `ah_linea_pendiente` INSERT (val_efe != 0)
- `ah_tran_servicio`: NINGUNO
- **Campos que NO deben cambiar en ah_cuenta:** ah_debitos, ah_debitos_hoy, ah_suspensos, ah_estado (sigue 'I')

---

### TC84 — Estado 'T' con NC (error 128145, no permite acreditaciones)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4253 |
| **@i_val** | 100.00 |
| **@i_cta** | '0931433502' |
| **@i_mon** | 1 |
| **@i_cau** | '0010' |

**PRE — Estado requerido en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0931433502'
-- ah_estado debe ser 'T'
SELECT COUNT(*) as tran_monet_pre FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0931433502'
```

**POST — Validaciones en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0931433502'
-- Debe ser idéntico al PRE (sin cambios)
SELECT COUNT(*) as tran_monet_post FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0931433502'
-- Debe ser igual al pre (sin insert)
SELECT COUNT(*) as tran_serv_post FROM cob_ahorros..ah_tran_servicio WHERE ts_cta_banco = '0931433502'
-- Debe ser igual al pre
```

**Resultado esperado:** `RETURN 128145`

**Trazabilidad por DB:**
- NINGUNO — SP retorna 128145 en L:636 (estado 'T' + signo 'C' → no permite acreditaciones, antes de BEGIN TRANSACTION)
- **Todos los campos de ah_cuenta deben quedar intactos**
- **No debe existir ningún registro nuevo en ah_tran_monet, ah_tran_servicio, ah_val_suspenso, ah_linea_pendiente**

---

### TC85 — ND con disponible=0, acción 'E' (error sin fondos, saldo cero)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 100.00 |
| **@i_cta** | '0000839728' |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |
| **@t_corr** | 'N' |

**PRE — Estado requerido en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000839728'
-- ah_disponible debe ser 0.00
SELECT an_accion FROM cob_remesas..re_accion_nd WHERE an_producto = 4 AND an_causa = '0001'
-- debe retornar 'E' (o no existir, que se trata como 'E')
SELECT COUNT(*) as tran_monet_pre FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000839728'
```

**POST — Validaciones en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000839728'
-- Debe ser idéntico al PRE (ROLLBACK deshizo todo)
SELECT COUNT(*) as tran_monet_post FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000839728'
-- Igual al pre
SELECT COUNT(*) as tran_serv_post FROM cob_ahorros..ah_tran_servicio WHERE ts_cta_banco = '0000839728'
SELECT COUNT(*) as suspensos_post FROM cob_ahorros..ah_val_suspenso WHERE vs_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000839728')
```

**Resultado esperado:** `RETURN 041033`

**Trazabilidad por DB:**
- NINGUNO — SP retorna 41033 en L:822 (fondos insuficientes con accion 'E', ROLLBACK TRANSACTION pndcca L:817)
- **Todos los campos de ah_cuenta deben quedar intactos (rollback)**
- **No debe existir ningún registro nuevo en ninguna tabla**

---

### TC86 — Alias 4319 se convierte a 4253 (NC internamente)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4319 |
| **@i_val** | 250.00 |
| **@i_cta** | '0000837312' |
| **@i_mon** | 1 |
| **@i_cau** | '0010' |
| **@i_prod** | 'AHO' |

**PRE — Estado requerido en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837312'
SELECT COUNT(*) as tran_monet_pre FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837312'
```

**POST — Validaciones en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837312'
SELECT * FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837312' AND tm_secuencial = @o_ssn_monet
SELECT COUNT(*) as lineas_post FROM cob_ahorros..ah_linea_pendiente WHERE lp_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837312')
```

**Resultado esperado:** `RETURN 0`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4253 (L:716 convierte 4319→4253 ANTES del insert)
  - tm_signo = 'C' (se determinó como NC en L:278 porque 4319 NO está en la lista de NC)
  - tm_valor = 250.00 (val_efe, sin ICC porque 4319 no está en lista ICC L:690)
  - tm_control = NULL
  - tm_remoto_ssn = NULL
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = +250.00
  - ah_creditos = +250.00
  - ah_creditos_hoy = +250.00
  - ah_contador_trx = +1
- `ah_linea_pendiente` INSERT (val_efe != 0)
- `ah_tran_servicio`: NINGUNO
- **Punto crítico para el micro:** El micro debe recibir @t_trn=4319 como entrada pero persistir tm_tipo_tran=4253. Si el micro persiste 4319, es un hallazgo.
- **Campos que NO deben cambiar en ah_cuenta:** ah_debitos, ah_debitos_hoy, ah_suspensos, ah_estado

---

### TC87 — ND con @i_control explícito (prevalece sobre @i_cant)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 100.00 |
| **@i_cta** | '0000837312' |
| **@i_mon** | 1 |
| **@i_cau** | '0001' |
| **@i_control** | 99 |
| **@i_cant** | 5 |

**PRE — Estado requerido en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837312'
-- ah_disponible debe ser >= 100.00
SELECT COUNT(*) as tran_monet_pre FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837312'
```

**POST — Validaciones en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837312'
SELECT * FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837312' AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4272, tm_signo = 'D'
  - tm_valor = 100.00
  - tm_control = 99 (L:1023 isnull(@i_control, @i_cant) = isnull(99, 5) = 99, @i_control prevalece)
  - tm_remoto_ssn = NULL
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = -100.00
  - ah_debitos = +100.00
  - ah_debitos_hoy = +100.00
  - ah_contador_trx = +1
- `ah_tran_servicio`: NINGUNO
- `ah_linea_pendiente` INSERT (val_efe != 0)
- **Punto crítico para el micro:** Si el micro usa @i_cant en vez de @i_control para tm_control, el valor será 5 en vez de 99. Eso es un hallazgo.
- **Campos que NO deben cambiar en ah_cuenta:** ah_creditos, ah_creditos_hoy, ah_suspensos

---

### TC88 — Canal CNB con empresa != 783 (SÍ genera nuevo secuencial)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4253 |
| **@i_val** | 150.00 |
| **@i_cta** | '0000837312' |
| **@i_mon** | 1 |
| **@i_cau** | '0010' |
| **@i_canal** | 'CNB' |
| **@i_empresa** | 100 |
| **@s_ssn** | 999999 |

**PRE — Estado requerido en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837312'
SELECT COUNT(*) as tran_monet_pre FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837312'
```

**POST — Validaciones en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837312'
SELECT * FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837312' AND tm_secuencial = @o_ssn_monet
```

**Resultado esperado:** `RETURN 0`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_secuencial = NUEVO (L:310 CNB + empresa!=783 → exec sp_gen_sec, NO usa 999999)
  - tm_tipo_tran = 4253, tm_signo = 'C'
  - tm_valor = 150.00
  - tm_canal = 'CNB' (L:1030)
  - tm_control = NULL
  - tm_remoto_ssn = NULL
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = +150.00
  - ah_creditos = +150.00
  - ah_creditos_hoy = +150.00
  - ah_contador_trx = +1
- `ah_tran_servicio`: NINGUNO
- `ah_linea_pendiente` INSERT (val_efe != 0)
- **Punto crítico para el micro:** tm_secuencial NO debe ser 999999. Debe ser un secuencial generado por sp_gen_sec. Si el micro reutiliza el @s_ssn original (999999), es un hallazgo.
- **Contraste con TC52:** TC52 usa empresa=783 donde NO se genera nuevo secuencial. Este TC confirma que empresa!=783 SÍ genera.

---

### TC89 — ND reintento con disponible=0 (no cobra nada, suspenso se actualiza con cobro=0)

| Campo | Detalle |
|-------|---------|
| **@t_trn** | 4272 |
| **@i_val** | 500.00 |
| **@i_cta** | '0000837010' |
| **@t_rty** | 'S' |
| **@i_alt** | 1 |
| **@i_mon** | 1 |
| **@i_cau** | '1017' |

**PRE — Estado requerido en BD:**
```sql
-- Preparar suspenso existente para esta cuenta
DELETE FROM cob_ahorros..ah_val_suspenso WHERE vs_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837010') AND vs_secuencial = 1
INSERT INTO cob_ahorros..ah_val_suspenso (vs_cuenta, vs_secuencial, vs_servicio, vs_estado, vs_procesada, vs_valor, vs_fecha, vs_oficina, vs_hora, vs_ssn, vs_valor_cobrado) VALUES ((SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837010'), 1, '1017', 'N', 'N', 500.00, 'Feb 02 2026', 1, getdate(), 0, 0)
UPDATE cob_ahorros..ah_cuenta SET ah_disponible = 0.00 WHERE ah_cta_banco = '0000837010'
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837010'
SELECT * FROM cob_ahorros..ah_val_suspenso WHERE vs_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837010') AND vs_secuencial = 1
```

**POST — Validaciones en BD:**
```sql
SELECT * FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837010'
SELECT * FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '0000837010' AND tm_secuencial = @o_ssn_monet
SELECT * FROM cob_ahorros..ah_val_suspenso WHERE vs_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837010') AND vs_secuencial = 1
SELECT * FROM cob_ahorros..ah_tran_servicio WHERE ts_cta_banco = '0000837010' AND ts_tipo_transaccion = 4570 AND ts_hora > @timestamp_pre
-- Cleanup
DELETE FROM cob_ahorros..ah_val_suspenso WHERE vs_cuenta = (SELECT ah_cuenta FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '0000837010') AND vs_secuencial = 1
```

**Resultado esperado:** `RETURN 0`

**Trazabilidad por DB:**
- `ah_tran_monet` INSERT (L:999):
  - tm_tipo_tran = 4272, tm_signo = 'D'
  - tm_valor = 0.00 (L:736 @w_val_efe = $0, saldo_para_girar <= 0 en reintento)
  - tm_remoto_ssn = NULL (L:995 @w_sec_suspenso=0 → NULL, en reintento con UPDATE no se genera nuevo)
- `ah_val_suspenso` UPDATE (L:744):
  - vs_valor = 500.00 (L:735 @w_val = 500-0 = 500, sigue pendiente todo)
  - vs_fecha_ult_cobro = @i_fecha
  - vs_valor_cobrado = 0 (isnull(0,0) + $0 = 0, no cobró nada)
  - vs_estado = 'N' (sigue pendiente)
- `ah_cuenta` UPDATE (L:1228):
  - ah_disponible = 0.00 (sin cambio)
  - ah_debitos = sin cambio (val_efe=0)
  - ah_debitos_hoy = sin cambio
  - ah_suspensos = sin cambio (no incrementa ni decrementa en reintento parcial)
  - ah_contador_trx = +1
- `ah_linea_pendiente`: NINGUNO (val_efe=0)
- `ah_tran_servicio` INSERT 4570 (L:1392):
  - ts_tipo_transaccion = 4570 (L:1392 @w_val=500 != 0 AND @w_reintento='N')
  - ts_valor = 500.00 (todo sigue en suspenso)
- **Campos que NO deben cambiar en ah_cuenta:** ah_creditos, ah_creditos_hoy, ah_promedio1, ah_prom_disponible, ah_debitos, ah_debitos_hoy, ah_suspensos, ah_estado

---

## TABLAS MONITOREADAS

Configuracion para el script de snapshot automatico. Define que tablas monitorear, como buscar registros nuevos y que campos ignorar en la comparacion SP vs REST.

| Tabla | Base | Operacion | Campo cuenta | Busqueda registro nuevo | Campos a ignorar |
|-------|------|-----------|--------------|-------------------------|------------------|
| ah_cuenta | cob_ahorros | UPDATE | ah_cta_banco = @i_cta | N/A (comparar delta pre vs post) | ah_fecha_ult_mov |
| ah_tran_monet | cob_ahorros | INSERT | tm_cta_banco = @i_cta | tm_secuencial = @o_ssn_monet | tm_secuencial, tm_hora, tm_remoto_ssn |
| ah_tran_servicio | cob_ahorros | INSERT | ts_cta_banco = @i_cta | ts_hora > @timestamp_pre | ts_secuencial, ts_hora, ts_remoto_ssn |
| ah_val_suspenso | cob_ahorros | INSERT/UPDATE | vs_cuenta = (SELECT ah_cuenta FROM ah_cuenta WHERE ah_cta_banco = @i_cta) | COUNT delta (vs_hora es smalldatetime, precision 1 min) | vs_secuencial, vs_hora |
| cc_monet_transfer | cob_cuentas | INSERT | N/A | mt_ssn_monet = @o_ssn_monet | mt_ssn_monet |
| cc_trx_inusuales | cob_cuentas | INSERT | ti_cta_banco = @i_cta | ti_hora > @timestamp_pre | ti_hora |
| ah_linea_pendiente | cob_ahorros | INSERT | lp_cuenta = (SELECT ah_cuenta FROM ah_cuenta WHERE ah_cta_banco = @i_cta) | COUNT delta (no tiene hora) | — |
| cc_uif | cob_cuentas | INSERT/UPDATE | ui_mis = (SELECT ah_cliente FROM ah_cuenta WHERE ah_cta_banco = @i_cta) | Comparar ui_uso y ui_contador pre vs post | — |

**Variables disponibles para busqueda:**
- `@i_cta`: cuenta del TC (siempre disponible)
- `@o_ssn_monet`: secuencial retornado por SP/REST (disponible post-exec)
- `@timestamp_pre`: capturado por script antes de cada exec (getdate())

**Campos ignorados en comparacion (por que):**
- Secuenciales (`tm_secuencial`, `ts_secuencial`, `vs_secuencial`): sp_gen_sec genera valores distintos por pasada
- Timestamps (`tm_hora`, `ts_hora`, `vs_hora`, `ti_hora`): hora de ejecucion siempre difiere
- `ah_fecha_ult_mov`: fecha de ultimo movimiento, difiere por timing entre pasadas

**Logica del script:**
1. Para cada TC, snapshot pre (estado ah_cuenta + counts por tabla)
2. Ejecutar (SP o REST)
3. Buscar registros nuevos usando estrategia de cada tabla
4. Hacer SELECT * de registros encontrados
5. Comparar SP vs REST campo a campo (ignorando campos listados)
6. Delta ah_cuenta (post-pre) SP vs REST
7. Si todo coincide → EQUIVALENTE. Si hay diffs → EQUIVALENTE_CON_DIFFS

---

## RIESGOS IDENTIFICADOS

| ID | Riesgo | Severidad | Caso relacionado |
|----|--------|-----------|-----------------|
| R01 | Race condition en saldo — sin bloqueo explícito en `ah_cuenta` | 🔴 Alta | TC64 |
| R02 | Sin idempotencia — doble ejecución genera duplicados | 🔴 Alta | TC65 |
| R03 | SP internos no coordinados en rollback (`sp_uif_acum`, `sp_genera_linea_pendiente`) | 🟡 Media | TC63 |
| R04 | `cc_trx_inusuales` sin validación de `@@error` — fallo silencioso | 🟡 Media | TC24 |
| R05 | Estado `'D'→'A'` se activa con cualquier crédito, no solo depósito inicial | 🟡 Media | TC20, TC23 |
| R06 | Gaps en secuenciales por múltiples llamadas a `sp_gen_sec` | 🟢 Baja | Todos |
| R07 | Usuario `rrhh` puede operar sobre cuentas bloqueadas | 🟡 Media | TC08 |
| R08 | `@i_fecha` se trunca al procesar (pierde hora) | 🟢 Baja | Todos |

---

*Documento generado para QA del SP `sp_ahndc_automatica` — Base de datos `cob_ahorros` (Sybase)*


# CASOS DE USO — sp_ahndc_automatica

---

## Introduccion del SP

| Campo | Valor |
|-------|-------|
| Nombre del SP | `cob_ahorros..sp_ahndc_automatica` |
| Proceso de negocio | Generacion de Notas de Debito y Credito automaticas sobre cuentas de ahorro |
| Descripcion general | Procesa transacciones ND/NC: valida estado de cuenta, moneda, bloqueos; calcula saldos, impuestos (ICC), promedios; gestiona valores en suspenso para fondos insuficientes; registra transacciones monetarias y de servicio; actualiza acumuladores UAF. |
| Sistemas involucrados | cob_ahorros, cob_cuentas, cob_remesas, cob_sbancario, cobis |
| Endpoint REST | POST /api/v1/ahorros/ndnc/generar |

---

## Estados de Cuenta y Comportamiento

| Estado | Codigo | Descripcion | Comportamiento del SP |
|--------|--------|-------------|----------------------|
| A | — | Activa | Permite todas las operaciones ND/NC |
| I | 41058 | Inactiva | Rechaza EXCEPTO si la combinacion trx/causa existe en `cob_cuentas..cc_control_movimientos` (cm_producto=4, cm_transaccion=@t_trn, cm_causa=@w_causa). Si existe, permite la operacion. |
| D | 48003 | Deposito inicial | Rechaza ND (@t_corr='N'). Permite NC solo con trx 16293/16294 que activan la cuenta (valida deposito minimo con `pa_aho_pvalida_depini`). |
| T | 128144/128145 | Transferida | Rechaza siempre. Retorna 128144 para ND (signo='D') y 128145 para NC (signo='C'). |
| C | 41057 | Cerrada | Rechaza siempre. `sp_ctah_vigente` retorna error 41057 antes de continuar el flujo. |

**Nota:** El estado se valida en dos puntos: primero `sp_ctah_vigente` valida estados C/T/I internamente (retorna error directo), y luego el SP padre valida estado D (L:413) y estado T (L:628) por separado.

---

## CU-01 — Validaciones de entrada y precondiciones

### a. Proposito

Verificar que el sistema rechaza la operacion con codigo de error especifico cuando los parametros de entrada o el estado de la cuenta no cumplen las condiciones requeridas para ejecutar una ND/NC.

### b. Alcance

**Incluye:**
- Control ND/NC habilitado (error 39003)
- Monto negativo (error 141011)
- Monto cero (retorno 0 sin operacion)
- Decimales en moneda sucres (error 901419)
- Tipo de transaccion nulo/cero (error 111000)
- Cuenta inexistente (error 41001)
- Cuenta cerrada (error 41057)
- Cuenta bloqueada por tipo y causa (error 41025)
- Cuenta en estado transferida — ND (error 128144) y NC (error 128145)
- Cuenta inactiva sin permiso de movimiento (error 41058)
- Cuenta en deposito inicial con ND no permitida (error 48003)
- Moneda no coincide con cuenta (error 41050)
- Sin alicuota de promedio configurada (error 41012)
- ND con disponible=0 y accion 'E' (error 41033)

**No incluye:**
- Flujos exitosos de ND/NC (CU-02, CU-03)
- Fondos insuficientes con suspenso (CU-04)
- Integridad transaccional (CU-06)

### c. Actores

| Actor | Tipo | Descripcion |
|-------|------|-------------|
| Canal invocante (REST/gRPC) | Principal | Sistema que invoca la operacion |
| SP sp_ctah_vigente | Sistema | Valida vigencia, moneda y estado de cuenta |

### d. Entradas funcionales

| Parametro | Descripcion |
|-----------|-------------|
| @i_cta | Numero de cuenta banco |
| @i_val | Valor/monto de la operacion |
| @i_mon | Codigo de moneda (0=sucres, 1=dolares) |
| @t_trn | Codigo de tipo de transaccion |
| @i_cau | Causa de la transaccion |
| @i_verf_estado_cta | Flag verificacion estado cuenta (S/N) |
| @s_user | Usuario (rrhh bypasea bloqueos) |

### f. Precondiciones

- El control ND/NC debe estar habilitado en `cob_cuentas..cc_control_ndnc` (cd_tipo='AHO', cd_estado='S')
- Existe configuracion de fecha de proceso en `cobis..ba_fecha_proceso`
- Existe alicuota en `cob_cuentas..cc_fecha_promedio` para la fecha de proceso y tipo_promedio de la cuenta

### g. Postcondiciones

- El SP retorna el codigo de error correspondiente a la validacion fallida
- No se modifica ningun registro en `ah_cuenta`, `ah_tran_monet` ni `ah_tran_servicio`
- Si `@i_aplcobis = 'N'`, se asigna mensaje descriptivo a `@o_msg`

### h. Flujo Principal

1. Verificar que el control NDNC este habilitado en `cob_cuentas..cc_control_ndnc` (cd_tipo='AHO', cd_estado != 'N')
2. Validar que el monto sea mayor a cero (si es 0 retorna 0 sin operar; si es negativo retorna 141011)
3. Validar que en moneda sucres (@i_mon=0) no se envien decimales
4. Validar que el tipo de transaccion sea valido (> 0)
5. Buscar la cuenta por numero y moneda via `sp_ctah_vigente` (retorna error si no existe, cerrada o moneda incorrecta)
6. Si estado='D' y trx es 16293/16294: validar deposito inicial con `pa_aho_pvalida_depini`
7. Si estado='D' y no es trx de deposito inicial: retornar 48003
8. Verificar si trx/causa existe en `cob_cuentas..cc_control_movimientos` (determina bandera_fecha)
9. Si estado='I': verificar que trx/causa exista en `cc_control_movimientos`; si no existe retornar 41058
10. Obtener categoria de la cuenta desde `ah_cuenta.ah_categoria`
11. Si categoria='U': verificar bypass en catalogos `ah_ncnd_ctamas_trxpermitidas` o `ah_ctmas_pago_directo`
12. Verificar bloqueos activos en `cob_ahorros..ah_ctabloqueada`
13. Si estado='T': retornar 128144 (ND) o 128145 (NC)
14. Validar moneda coincidente entre parametro y cuenta
15. Buscar alicuota en `cob_cuentas..cc_fecha_promedio` para fecha y tipo_promedio

### i. Flujos Alternos

**FA-01: Control NDNC deshabilitado**
- Condicion: `cc_control_ndnc.cd_estado = 'N'` para tipo 'AHO'
- Resultado: RETURN 39003

**FA-02: Monto invalido**
- Si @i_val < 0: RETURN 141011
- Si @i_val = 0: RETURN 0 (no-op exitoso, sin error)

**FA-03: Decimales en moneda sucres**
- Condicion: @i_mon = 0 y valor tiene decimales (floor(val) != val)
- Resultado: RETURN 901419

**FA-04: Tipo transaccion invalido**
- Condicion: @t_trn = 0 o @t_trn = NULL
- Resultado: RETURN 111000

**FA-05: Cuenta no encontrada o cerrada**
- `sp_ctah_vigente` retorna error si cuenta no existe (41001), moneda no coincide (41001), o estado cerrado (41057)
- Resultado: propaga return code de sp_ctah_vigente

**FA-06: Cuenta bloqueada**
- Tabla: `cob_ahorros..ah_ctabloqueada`
- Condicion: existe registro con `cb_cuenta = @w_cuenta AND cb_estado = 'V' AND (cb_tipo_bloqueo = @w_tipo1 OR cb_tipo_bloqueo = @w_tipo3 OR cb_causa = '2')`
  - @w_tipo1 = '1' para NC, '2' para ND (o '9' si hay bypass por catalogo)
  - @w_tipo3 = '3' (bloqueo total) (o '9' si hay bypass)
- Bypass por usuario: si `@s_user = 'rrhh'`, se omite la validacion completa
- Bypass por catalogo ND: si trx=4272 y @i_cau existe en catalogo `ah_bloqueo_nd` → @w_tipo1='9', @w_tipo3='9'
- Bypass por catalogo NC: si trx=4253 y @i_cau existe en catalogo `ah_bloqueo_nc` → @w_tipo1='9', @w_tipo3='9'
- Bypass por catalogo funcionario: si @w_funcionario='S' y causa en `ah_bloqueo_nd_func`/`ah_bloqueo_nc_func`
- Bypass por categoria CTA MAS: si ah_categoria='U' y trx-causa en `ah_ncnd_ctamas_trxpermitidas` o `ah_ctmas_pago_directo`
- Resultado si bloqueada: RETURN 41025, mensaje incluye tipo de bloqueo (de catalogo `ah_tbloqueo`)

**FA-07: Estado transferida**
- Si signo='D' (ND): RETURN 128144
- Si signo='C' (NC): RETURN 128145

**FA-08: Cuenta inactiva sin permiso**
- Condicion: ah_estado='I' y trx/causa NO existe en `cc_control_movimientos` (cm_producto=4)
- Resultado: RETURN 41058
- Nota: si trx/causa SI existe en cc_control_movimientos, se permite la operacion

**FA-09: Deposito inicial con ND**
- Condicion: ah_estado='D' y @t_corr='N' y trx NO es 16293/16294
- Resultado: RETURN 48003

**FA-10: Sin alicuota**
- Condicion: no existe registro en `cc_fecha_promedio` para fp_tipo_promedio de la cuenta y fp_fecha_inicio = fecha proceso
- Resultado: RETURN 41012

**FA-11: ND sin fondos con disponible=0 y accion 'E'**
- Condicion: saldo_para_girar <= 0, causa con accion 'E' en `re_accion_nd`
- Resultado: RETURN 41033 (pasa por L:734 asignando val_efe=$0 antes del error)

### j. Escenarios Gherkin

```gherkin
Feature: Validaciones de entrada sp_ahndc_automatica

  Scenario: Control ND/NC deshabilitado rechaza operacion
    Given cc_control_ndnc tiene cd_estado='N' para cd_tipo='AHO'
    When se procesa una ND/NC
    Then el sistema retorna error 39003
    And no se generan movimientos en BD

  Scenario: Monto negativo rechazado
    Given una cuenta activa valida
    When se procesa con @i_val = -100.00
    Then el sistema retorna error 141011

  Scenario: Monto cero es no-op exitoso
    Given una cuenta activa valida
    When se procesa con @i_val = 0.00
    Then el sistema retorna 0 sin generar movimientos

  Scenario: Cuenta cerrada rechaza operacion
    Given una cuenta con ah_estado = 'C'
    When se procesa una ND/NC
    Then sp_ctah_vigente retorna error 41057
    And no se generan movimientos en BD

  Scenario: Cuenta bloqueada tipo 2 rechaza ND
    Given una cuenta con bloqueo activo en ah_ctabloqueada (cb_tipo_bloqueo='2', cb_estado='V')
    And el usuario no es 'rrhh'
    And la causa no existe en catalogo ah_bloqueo_nd (cobis..cl_catalogo, tabla ah_bloqueo_nd)
    When se procesa una ND (trx 4272)
    Then el sistema retorna error 41025
    And @o_detalle_error contiene "Cuenta bloqueada: " + descripcion del tipo de bloqueo

  Scenario: Usuario rrhh bypasea cualquier bloqueo
    Given una cuenta con bloqueo activo (cualquier tipo)
    And @s_user = 'rrhh'
    When se procesa una ND
    Then la validacion de bloqueo se omite completamente
    And la operacion continua al siguiente paso

  Scenario: Causa en catalogo ah_bloqueo_nd bypasea bloqueo para ND
    Given una cuenta con bloqueo activo
    And @t_trn = 4272 y @i_cau existe en catalogo ah_bloqueo_nd (cobis..cl_catalogo)
    When se procesa la ND
    Then @w_tipo1 y @w_tipo3 se fuerzan a '9' (no matchean ningun bloqueo)
    And la operacion continua sin error de bloqueo

  Scenario: Cuenta en estado transferida rechaza debitos
    Given una cuenta con ah_estado = 'T'
    When se procesa una ND (signo='D')
    Then el sistema retorna error 128144

  Scenario: Cuenta en estado transferida rechaza creditos
    Given una cuenta con ah_estado = 'T'
    When se procesa una NC (signo='C')
    Then el sistema retorna error 128145

  Scenario: Cuenta inactiva sin permiso rechaza operacion
    Given una cuenta con ah_estado = 'I'
    And la combinacion (cm_producto=4, cm_transaccion=@t_trn, cm_causa=@i_cau) NO existe en cc_control_movimientos
    When se procesa una ND/NC
    Then el sistema retorna error 41058

  Scenario: Cuenta inactiva CON permiso permite operacion
    Given una cuenta con ah_estado = 'I'
    And la combinacion (cm_producto=4, cm_transaccion=4253, cm_causa='400') SI existe en cc_control_movimientos
    And @i_verf_estado_cta = 'N'
    When se procesa una NC
    Then la operacion se ejecuta exitosamente (return 0)

  Scenario: ND con disponible exactamente cero y accion E
    Given una cuenta activa con ah_disponible = 0.00
    And la causa tiene accion 'E' en cob_remesas..re_accion_nd (an_producto=4, an_causa=@i_cau)
    When se procesa una ND por cualquier monto
    Then el SP evalua saldo_para_girar <= 0, asigna val_efe=$0
    And retorna error 41033
    And ah_cuenta queda intacta (ROLLBACK)
```

---

## CU-02 — Flujo exitoso de Nota de Credito (NC)

### a. Proposito

Verificar que una NC valida acredita correctamente el monto en la cuenta, calcula impuesto al flujo de capital (ICC) cuando aplica, actualiza promedios ponderados con la alicuota del dia, y registra la transaccion monetaria.

### b. Alcance

**Incluye:**
- NC estandar con acreditacion de saldo y calculo de promedios (TC20)
- NC con calculo de ICC (TC21)
- NC con monto minimo 0.01 (TC81)
- NC que activa cuenta en estado deposito inicial (TC23)
- NC con cotizacion para transferencias internacionales (TC50)
- NC genera transaccion inusual UAF cuando supera umbrales (TC24)
- NC sobre cuenta inactiva con permiso en cc_control_movimientos (TC83)
- NC sobre cuenta categoria 'U' (CTA MAS) con bypass de bloqueo (TC nuevo)
- Alias 4319 se convierte internamente a 4253 pero se trata como ND (TC86)

**No incluye:**
- Reversas/correcciones (CU-07)
- Validaciones de entrada (CU-01)

### c. Actores

| Actor | Tipo | Descripcion |
|-------|------|-------------|
| Canal invocante (REST/gRPC) | Principal | Envia solicitud de NC |
| SP sp_impuesto_flujo_capital | Sistema | Calcula ICC para producto AHO (cob_cuentas) |
| SP sp_gen_sec | Sistema | Genera secuencial unico (cob_cuentas) |
| SP sp_genera_linea_pendiente | Sistema | Genera linea en libro auxiliar (cob_ahorros) |
| SP sp_uif_acum | Sistema | Acumula transaccion para control UAF (cob_cuentas) |

### d. Entradas funcionales

| Parametro | Descripcion |
|-----------|-------------|
| @i_cta | Cuenta destino del credito |
| @i_val | Monto a acreditar |
| @t_trn | Tipo transaccion NC (4253, 4319, 16293, 16294, 16637, 4229) |
| @i_cau | Causa (determina si aplica cotizacion/ICC/UAF) |
| @i_prod | Producto (AHO para que aplique ICC) |
| @i_cotiza | Cotizacion para transferencias (cuando causa='32') |

### f. Precondiciones

- Cuenta activa (o inactiva con permiso en cc_control_movimientos) con moneda correcta
- Control ND/NC habilitado
- Sin bloqueos vigentes (o con bypass aplicable)
- Alicuota de promedio configurada en `cob_cuentas..cc_fecha_promedio` para `fp_tipo_promedio` de la cuenta y `fp_fecha_inicio` = fecha proceso

### g. Postcondiciones

- `ah_disponible` incrementado en valor_efectivo (valor - impuesto ICC)
- `ah_creditos` y `ah_creditos_hoy` incrementados en valor_efectivo
- `ah_promedio1` incrementado en round(valor_efectivo * fp_alicuota, decimales) * tfactor
- `ah_prom_disponible` incrementado en round(valor_efectivo * fp_alicuota, decimales) * tfactor
- `ah_contador_trx` incrementado en 1
- Registro en `ah_tran_monet` con signo='C', tm_valor=valor_efectivo, tm_valor_impuesto=ICC
- Registro en `ah_linea_pendiente` via sp_genera_linea_pendiente (si valor_efectivo != 0)
- Si causa='32': registro en `cob_cuentas..cc_monet_transfer` con cotizacion
- Si estado era 'D' y trx es 16293/16294: ah_estado cambia a 'A'
- `@o_ssn_monet` retorna el secuencial generado
- `@o_neto_aut` retorna el valor del impuesto ICC retenido

### h. Flujo Principal

1. Generar secuencial via `cob_cuentas..sp_gen_sec` (excepto canal CNB con empresa=783)
2. Calcular impuesto ICC via `cob_cuentas..sp_impuesto_flujo_capital`:
   - Solo aplica si trx in (4253, 16637, 16294, 16293) y @i_prod='AHO'
   - Retorna: tasa, impuesto, neto (valor_efectivo = valor - impuesto)
   - Si trx NO genera ICC: valor_efectivo = @i_val (monto completo)
3. Calcular alicuota del promedio:
   - Obtener `fp_alicuota` de `cob_cuentas..cc_fecha_promedio` donde `fp_tipo_promedio` = tipo_promedio de la cuenta y `fp_fecha_inicio` = fecha proceso
   - `alic = valor_efectivo * fp_alicuota`
4. Actualizar variables acumuladas:
   - `ah_creditos += valor_efectivo * tfactor(+1)`
   - `ah_creditos_hoy += valor_efectivo * tfactor(+1)`
   - `ah_promedio1 += round(alic, decimales) * tfactor(+1)`
   - `ah_prom_disponible += round(alic, decimales) * tfactor(+1)`
   - `ah_disponible += valor_efectivo * tfactor(+1)`
5. Si valor_efectivo != 0: insertar linea pendiente via `sp_genera_linea_pendiente`
6. Si trx/causa existe en `cob_cuentas..cc_trx_ndc_uaf` (tn_estado='A', tn_tipo_proc='L'): invocar `sp_uif_acum`
7. Generar segundo secuencial via `sp_gen_sec` (para ah_tran_monet)
8. Insertar registro en `cob_ahorros..ah_tran_monet` con signo='C'
9. Si (trx=4253 AND causa='32') OR (trx=4272 AND causa='940'): insertar en `cob_cuentas..cc_monet_transfer`
10. Si signo='C' y ah_estado='D': cambiar estado a 'A'
11. Actualizar `ah_cuenta` con nuevos saldos, promedios, contadores
12. COMMIT y retornar 0

### i. Flujos Alternos

**FA-01: NC con correccion (t_corr='S')**
- tfactor = -1 (invierte el efecto: decrementa saldo en vez de incrementar)
- signo sigue siendo 'C' pero el efecto economico es inverso
- Se registra tm_correccion='S' y tm_sec_correccion=@t_ssn_corr

**FA-02: NC que activa cuenta en estado D**
- Condicion: ah_estado='D' y trx in (16293, 16294)
- Valida deposito inicial con `pa_aho_pvalida_depini`
- Si valida OK: cambia estado internamente a 'A' para continuar el flujo
- Si falla validacion: RETURN 41068

**FA-03: NC con impuesto ICC**
- `sp_impuesto_flujo_capital` calcula tasa e impuesto
- valor_efectivo = valor - impuesto (el cliente recibe el neto)
- @o_neto_aut = impuesto retenido
- Nota: en ambiente QA la tasa ICC esta actualmente en 0%

**FA-04: NC genera transaccion inusual (UAF)**
- Solo aplica para trx 4253 o 4255
- Condicion (ambas deben cumplirse):
  - valor_efectivo >= parametro TRXINU ($5,000 en `cobis..cl_parametro` pa_nemonico='TRXINU', pa_producto='AHO')
  - valor_efectivo >= promedio_5_periodos * parametro VASAPR (10x en `cobis..cl_parametro` pa_nemonico='VASAPR', pa_producto='AHO')
- Calculo promedio_5_periodos = (ah_promedio2 + ah_promedio3 + ah_promedio4 + ah_promedio5 + ah_promedio6) / 5
- Si ambas condiciones se cumplen: INSERT en `cob_cuentas..cc_trx_inusuales`

**FA-05: Alias 4319**
- La conversion 4319→4253 ocurre en L:716 DESPUES de la determinacion de factor
- 4319 NO esta en la lista NC de L:278, por lo que se determina como ND (signo='D', tfactor=-1)
- Resultado: se persiste como tm_tipo_tran=4253 pero con signo='D' (debita la cuenta)

**FA-06: NC sobre cuenta inactiva con permiso**
- Si ah_estado='I' pero trx/causa existe en cc_control_movimientos: se permite
- ah_estado permanece en 'I' (no cambia a 'A')

**FA-07: Cotizacion para transferencias**
- Condicion: (trx=4253 AND causa='32') — transferencia NC con tipo de cambio
- Se inserta en `cob_cuentas..cc_monet_transfer` con:
  - mt_cotiza = @i_cotiza (tipo de cambio enviado)
  - mt_valor = valor_efectivo
  - mt_producto = 'AHO'
  - mt_moneda = @i_mon

### j. Escenarios Gherkin

```gherkin
Feature: Nota de Credito exitosa

  Scenario: NC estandar acredita monto y actualiza promedios
    Given una cuenta activa con tipo_promedio 'M'
    And alicuota del dia = 0.5 (cc_fecha_promedio para fecha proceso)
    When se procesa una NC por 500.00
    Then ah_disponible se incrementa en 500.00
    And ah_creditos se incrementa en 500.00
    And ah_promedio1 se incrementa en round(500 * 0.5, 2) = 250.00
    And ah_prom_disponible se incrementa en 250.00
    And ah_contador_trx se incrementa en 1
    And se genera registro en ah_tran_monet con tm_signo='C', tm_valor=500.00
    And se genera linea en ah_linea_pendiente

  Scenario: NC con ICC descuenta impuesto al flujo de capital
    Given una cuenta activa en producto AHO
    And tasa ICC configurada > 0% en sp_impuesto_flujo_capital
    When se procesa una NC por 1000.00
    Then sp_impuesto_flujo_capital calcula: neto = 1000 - ICC
    And ah_disponible se incrementa en neto (no en 1000)
    And tm_valor en ah_tran_monet = neto
    And tm_valor_impuesto = ICC calculado
    And @o_neto_aut retorna el valor del ICC

  Scenario: NC con cotizacion graba transferencia internacional
    Given una cuenta activa
    And @t_trn = 4253, @i_cau = '32', @i_cotiza = 1.25
    When se procesa la NC
    Then se inserta registro en cob_cuentas..cc_monet_transfer
    And mt_tipo_tran = 4253, mt_causa = '32'
    And mt_valor = valor_efectivo, mt_cotiza = 1.25
    And mt_producto = 'AHO', mt_moneda = @i_mon

  Scenario: NC activa cuenta en deposito inicial
    Given una cuenta con ah_estado = 'D'
    And @t_trn = 16293
    When se procesa la NC
    Then pa_aho_pvalida_depini valida el deposito minimo
    And ah_estado cambia de 'D' a 'A'
    And el credito se aplica normalmente

  Scenario: NC genera transaccion inusual cuando supera ambos umbrales UAF
    Given parametro TRXINU = 5000.00 (cobis..cl_parametro pa_nemonico='TRXINU' pa_producto='AHO')
    And parametro VASAPR = 10 (cobis..cl_parametro pa_nemonico='VASAPR' pa_producto='AHO')
    And promedio 5 periodos de la cuenta = 400.00
    When se procesa NC por 6000.00 (>= 5000 Y >= 400*10=4000)
    Then se inserta registro en cob_cuentas..cc_trx_inusuales
    And ti_trx = 4253, ti_cta_banco = @i_cta, ti_tipo = 'AHO'
    And ti_efectivo = valor_efectivo

  Scenario: NC NO genera transaccion inusual cuando esta bajo un umbral
    Given mismos parametros TRXINU y VASAPR
    When se procesa NC por 500.00 (< 5000, no supera TRXINU)
    Then NO se inserta registro en cc_trx_inusuales

  Scenario: NC sobre cuenta inactiva con permiso en cc_control_movimientos
    Given una cuenta con ah_estado = 'I'
    And existe registro en cc_control_movimientos (cm_producto=4, cm_transaccion=4253, cm_causa='400')
    And @i_verf_estado_cta = 'N'
    When se procesa NC con causa '400'
    Then la operacion se ejecuta exitosamente
    And ah_estado permanece en 'I' (no cambia a 'A')

  Scenario: NC sobre cuenta categoria U (CTA MAS) bypasea bloqueo
    Given una cuenta con ah_categoria = 'U' y bloqueo activo
    And la combinacion trx-causa existe en catalogo ah_ncnd_ctamas_trxpermitidas (valor='4253-226')
    When se procesa NC con @t_trn=4253 y @i_cau='226'
    Then la validacion de bloqueo se omite (@w_tipo1='9', @w_tipo3='9')
    And la NC se ejecuta normalmente

  Scenario: Alias 4319 se determina como ND pero se persiste como 4253
    Given una cuenta activa
    When se procesa con @t_trn=4319
    Then el factor se determina como ND en L:278 (4319 NO esta en lista NC)
    And en L:716 se convierte @t_trn a 4253
    And tm_tipo_tran en ah_tran_monet = 4253
    And tm_signo = 'D' (no 'C')
    And ah_disponible DISMINUYE (es un debito funcional)
```

---

## CU-03 — Flujo exitoso de Nota de Debito (ND)

### a. Proposito

Procesar una Nota de Debito que disminuye el saldo de la cuenta, verificando fondos disponibles y aplicando acciones segun configuracion de causa. Incluye ND en linea (peticion individual) y ND invocada por procesos batch para captura de valores en suspenso.

### b. Alcance

**Incluye:**
- ND estandar con fondos suficientes (TC30)
- ND con cotizacion para transferencias internacionales causa 940 (TC51)
- ND canal CNB empresa 783 sin nuevo secuencial (TC52)
- ND canal CNB empresa != 783 SI genera secuencial (TC88)
- ND con IVA aplicable (TC37)
- ND con @i_control explicito prevalece sobre @i_cant (TC87)
- ND sobre cuenta inactiva con permiso en cc_control_movimientos (TC nuevo)

**No incluye:**
- ND sin fondos con generacion de suspenso (CU-04)
- ND tipo 4372 con servicio 4373 (CU-05)
- Reintentos de cobro de suspenso batch (CU-04)

### c. Actores

| Actor | Tipo | Descripcion |
|-------|------|-------------|
| Canal invocante (REST/gRPC/CNB) | Principal | Envia solicitud de ND en linea |
| Proceso batch | Principal | Invoca ND con @t_rty='S' para captura de suspensos |
| SP sp_gen_sec | Sistema | Genera secuencial (cob_cuentas) |
| SP sp_imp_valor_agregado | Sistema | Calcula IVA cuando aplica (cob_remesas) |
| SP sp_uif_acum | Sistema | Acumula transaccion para control UAF (cob_cuentas) |

### d. Entradas funcionales

| Parametro | Descripcion |
|-----------|-------------|
| @i_cta | Cuenta origen del debito |
| @i_val | Monto a debitar |
| @t_trn | Tipo transaccion ND (4272, 4264, 4372, 16238, 16629, etc.) |
| @i_cau | Causa (determina accion E/V/S en re_accion_nd y si aplica IVA) |
| @i_canal | Canal ('CNB' para banca empresarial) |
| @i_empresa | Empresa (783 para CNB sin secuencial nuevo) |
| @i_cotiza | Cotizacion para transferencias (cuando causa='940') |
| @i_control | Control (si viene, prevalece sobre @i_cant en tm_control) |
| @i_cant | Cantidad transacciones A06 (usado si @i_control es NULL) |
| @i_comision | Valor comision (se registra en tm_valor_comision) |

### f. Precondiciones

- Cuenta activa (o inactiva con permiso) con saldo >= monto
- Control ND/NC habilitado
- Sin bloqueos vigentes (o con bypass)
- Causa configurada en `cob_remesas..re_accion_nd` (an_producto=4, an_causa=@i_cau)
- Alicuota de promedio configurada para la fecha

### g. Postcondiciones

- `ah_disponible` decrementado en valor_efectivo
- `ah_debitos` y `ah_debitos_hoy` incrementados en valor_efectivo * factor_aux
- `ah_promedio1` decrementado en round(valor_efectivo * fp_alicuota, decimales)
- `ah_prom_disponible` decrementado en round(valor_efectivo * fp_alicuota, decimales)
- `ah_contador_trx` incrementado en 1
- Registro en `ah_tran_monet` con signo='D', tm_valor=valor_efectivo
- `tm_control` = isnull(@i_control, @i_cant)
- Si causa='940': registro en `cob_cuentas..cc_monet_transfer` con cotizacion
- Si canal='CNB' y empresa=783: tm_secuencial = @s_ssn original (no genera nuevo)
- `@o_ssn_monet` retorna el secuencial
- `@o_debito_realizado` retorna el monto debitado

### h. Flujo Principal

1. Generar secuencial via `sp_gen_sec`:
   - Si canal='CNB' y empresa=783: NO genera, reutiliza @s_ssn
   - Si canal='CNB' y empresa!=783: SI genera nuevo
   - Otros canales: SI genera nuevo
2. Determinar factor: signo='D', tfactor=-1, factor_aux=+1
3. Consultar accion de la causa en `cob_remesas..re_accion_nd` (an_producto=4, an_causa=@i_cau):
   - 'E' = Error si fondos insuficientes
   - 'V' = Generar valor en suspenso si fondos insuficientes
   - 'S' o NULL = se trata como 'E'
4. Validar fondos: saldo_para_girar >= @i_val
5. Calcular alicuota: alic = valor_efectivo * fp_alicuota
6. Actualizar variables acumuladas:
   - `ah_debitos += valor_efectivo * factor_aux(+1)`
   - `ah_debitos_hoy += valor_efectivo * factor_aux(+1)`
   - `ah_promedio1 += round(alic, decimales) * tfactor(-1)`
   - `ah_prom_disponible += round(alic, decimales) * tfactor(-1)`
   - `ah_disponible += valor_efectivo * tfactor(-1)`
7. Si valor_efectivo != 0: insertar linea pendiente
8. Si trx/causa en cc_trx_ndc_uaf: invocar sp_uif_acum
9. Generar segundo secuencial e insertar en `ah_tran_monet` con signo='D'
10. Si aplica IVA (an_iva='S' en re_accion_nd y @t_corr='N'): invocar `cob_remesas..sp_imp_valor_agregado`
11. Si causa='940': insertar en cc_monet_transfer con cotizacion
12. Actualizar `ah_cuenta`
13. COMMIT y retornar 0

### i. Flujos Alternos

**FA-01: Sin fondos + accion 'E'**
- Condicion: @i_val > saldo_para_girar y accion='E' (o 'S' o NULL)
- Resultado: RETURN 41033

**FA-02: Sin fondos + accion 'V'**
- Ver CU-04 (genera valor en suspenso)

**FA-03: Reintento de cobro (t_rty='S')**
- Ver CU-04 (captura de valor en suspenso existente)
- Nota: El reintento puede ser invocado por proceso batch nocturno O por peticion en linea. La logica del SP es identica en ambos casos.

**FA-04: ND 4372 genera servicio 4373**
- Ver CU-05

**FA-05: Causa en catalogo bypass**
- Si trx=4272 y causa en catalogo `ah_bloqueo_nd`: omite validacion de bloqueo
- Permite operar cuenta bloqueada para causas especificas

**FA-06: ND con IVA**
- Condicion: causa con an_iva='S' en re_accion_nd, @t_corr='N'
- Invoca `cob_remesas..sp_imp_valor_agregado`
- Actualmente solo causa '943' tiene IVA activo en ambiente QA

**FA-07: ND sobre cuenta inactiva con permiso**
- Si ah_estado='I' y trx/causa existe en cc_control_movimientos (cm_producto=4)
- Se permite la operacion, debita normalmente
- Requiere @i_verf_estado_cta='N' para bypasear validacion de sp_ctah_vigente

**FA-08: Canal CNB empresa 783**
- NO genera nuevo secuencial, reutiliza @s_ssn de la sesion
- El secuencial del caller se usa directamente en tm_secuencial

**FA-09: Cotizacion para transferencias**
- Condicion: trx=4272 AND causa='940' — transferencia ND con tipo de cambio
- Se inserta en cc_monet_transfer con mt_cotiza=@i_cotiza

### j. Escenarios Gherkin

```gherkin
Feature: Nota de Debito exitosa

  Scenario: ND estandar debita cuenta y actualiza promedios
    Given una cuenta activa con saldo >= monto y tipo_promedio 'M'
    And alicuota del dia = 0.5
    When se procesa ND por 200.00
    Then ah_disponible se decrementa en 200.00
    And ah_debitos se incrementa en 200.00
    And ah_promedio1 se decrementa en round(200 * 0.5, 2) = 100.00
    And ah_contador_trx se incrementa en 1
    And se genera ah_tran_monet con tm_signo='D', tm_valor=200.00
    And @o_debito_realizado = 200.00

  Scenario: ND con IVA aplica sp_imp_valor_agregado
    Given una cuenta activa con fondos suficientes
    And causa '943' con an_iva='S' en re_accion_nd
    And @t_corr='N' (no es correccion)
    When se procesa ND por 100.00
    Then se invoca cob_remesas..sp_imp_valor_agregado
    And el IVA calculado se registra internamente

  Scenario: ND con cotizacion graba transferencia internacional
    Given una cuenta activa con fondos suficientes
    And @t_trn=4272, @i_cau='940', @i_cotiza=0.90
    When se procesa la ND
    Then se inserta en cc_monet_transfer con mt_cotiza=0.90
    And mt_tipo_tran=4272, mt_causa='940'

  Scenario: ND canal CNB empresa 783 reutiliza secuencial de sesion
    Given una cuenta activa
    And @i_canal='CNB', @i_empresa=783, @s_ssn=12345
    When se procesa la ND
    Then tm_secuencial en ah_tran_monet = 12345 (no genera nuevo via sp_gen_sec)

  Scenario: ND canal CNB empresa distinta de 783 genera secuencial nuevo
    Given una cuenta activa
    And @i_canal='CNB', @i_empresa=100, @s_ssn=999999
    When se procesa la ND
    Then tm_secuencial en ah_tran_monet != 999999 (genera nuevo via sp_gen_sec)

  Scenario: ND con @i_control explicito prevalece sobre @i_cant
    Given una cuenta activa con fondos suficientes
    And @i_control=99, @i_cant=5
    When se procesa la ND
    Then tm_control en ah_tran_monet = 99 (isnull(99,5) = 99)

  Scenario: ND sobre cuenta inactiva con permiso
    Given una cuenta con ah_estado='I'
    And (cm_producto=4, cm_transaccion=4272, cm_causa='400') existe en cc_control_movimientos
    And @i_verf_estado_cta='N'
    When se procesa ND con causa '400'
    Then la operacion se ejecuta exitosamente
    And ah_estado permanece en 'I'
```

---

## CU-04 — Fondos insuficientes con valores en suspenso

### a. Proposito

Verificar el manejo de fondos insuficientes cuando la causa tiene accion 'V' (valor en suspenso): el SP debita lo disponible y registra el excedente como valor en suspenso para cobro posterior.

**Nota funcional:** La generacion de valores en suspenso ocurre como parte de una ND en linea cuando hay fondos parciales. La captura (cobro) de suspensos existentes puede ser invocada tanto por el proceso batch nocturno como por una peticion en linea con @t_rty='S'. En ambos casos la logica del SP es identica — el SP no distingue el origen de la invocacion.

### b. Alcance

**Incluye:**
- ND en linea con fondos parciales genera suspenso nuevo (TC26, TC32)
- ND en linea con disponible=0 genera suspenso completo (TC80)
- Captura de suspenso exitosa — saldo ahora alcanza (TC33)
- Captura de suspenso parcial — saldo sigue insuficiente (TC34)
- Captura de suspenso con disponible=0 — no cobra nada (TC89)
- ND con fondos insuficientes y accion 'E' rechaza (TC31, TC85)

**No incluye:**
- ND con fondos suficientes (CU-03)
- Errores de persistencia (CU-06)

### c. Actores

| Actor | Tipo | Descripcion |
|-------|------|-------------|
| Canal invocante | Principal | Envia ND en linea que genera suspenso |
| Proceso batch | Principal | Invoca captura de suspenso con @t_rty='S' |
| SP sp_gen_sec | Sistema | Genera secuencial para suspenso |

### d. Entradas funcionales

| Parametro | Descripcion |
|-----------|-------------|
| @i_cta | Cuenta con fondos insuficientes |
| @i_val | Monto solicitado (mayor al saldo disponible) |
| @i_cau | Causa con accion 'V' en `cob_remesas..re_accion_nd` (an_producto=4) |
| @t_rty | 'N' = operacion nueva (genera suspenso); 'S' = captura de suspenso existente |
| @i_alt | Secuencial del suspenso a cobrar (cuando @t_rty='S') |

### f. Precondiciones

- Cuenta activa con saldo < monto solicitado (o saldo = 0)
- Causa configurada con accion 'V' en `cob_remesas..re_accion_nd`
- Para capturas (@t_rty='S'): existe registro en `ah_val_suspenso` con vs_secuencial=@i_alt, vs_estado='N'

### g. Postcondiciones

**Operacion nueva (t_rty='N') con disponible > 0:**
- `ah_disponible` queda en 0 (debitado completo del disponible)
- Se inserta en `ah_val_suspenso` con vs_valor = excedente (monto - disponible)
- `ah_suspensos` incrementado en 1
- Registro en `ah_tran_monet` con tm_valor = porcion disponible debitada
- Registro en `ah_tran_servicio` tipo 4570 con ts_valor = monto en suspenso
- `tm_remoto_ssn` = secuencial del suspenso generado
- Se genera linea_pendiente (val_efe > 0)

**Operacion nueva (t_rty='N') con disponible = 0:**
- `ah_disponible` permanece en 0
- Se inserta en `ah_val_suspenso` con vs_valor = monto COMPLETO
- `ah_suspensos` incrementado en 1
- Registro en `ah_tran_monet` con tm_valor = $0
- Registro en `ah_tran_servicio` tipo 4570 con ts_valor = monto completo
- `ah_debitos` y `ah_debitos_hoy` SIN CAMBIO (val_efe=0)
- NO genera linea_pendiente (val_efe = 0)

**Captura exitosa (t_rty='S', saldo >= valor pendiente):**
- Se actualiza `ah_val_suspenso`: vs_estado='C', vs_procesada='S', vs_valor=$0, vs_valor_cobrado += monto
- `ah_suspensos` decrementado en 1
- Se debita el monto completo

**Captura parcial (t_rty='S', 0 < saldo < valor pendiente):**
- Se actualiza `ah_val_suspenso`: vs_valor reducido, vs_valor_cobrado += cobrado parcial
- Se debita lo disponible
- Genera tran_servicio tipo 4570 con el remanente

**Captura con disponible=0 (t_rty='S', saldo = 0):**
- Se actualiza `ah_val_suspenso`: vs_valor sin cambio, vs_valor_cobrado += $0
- Registro en `ah_tran_monet` con tm_valor = $0
- `ah_debitos` SIN CAMBIO
- NO genera linea_pendiente
- Genera tran_servicio tipo 4570 con monto completo
- `ah_suspensos` SIN CAMBIO

### h. Flujo Principal

1. Determinar accion de la causa en `re_accion_nd` (an_producto=4, an_causa=@i_cau): 'V' = suspenso
2. Evaluar fondos: si saldo_para_girar <= 0 → val_efe=$0, val=@i_val (todo a suspenso)
3. Si saldo > 0 pero < @i_val: val_efe=saldo (cobra parcial), val=@i_val-saldo (excedente)
4. Si @t_rty='N' (nuevo): generar secuencial + INSERT en `ah_val_suspenso`
5. Si @t_rty='S' (captura): UPDATE `ah_val_suspenso` existente con vs_secuencial=@i_alt
6. Debitar la porcion disponible (puede ser $0)
7. Si val_efe != 0: generar linea pendiente
8. Insertar `ah_tran_monet` con tm_valor = val_efe
9. Si val > 0 y @w_reintento='N': insertar `ah_tran_servicio` tipo 4570 con ts_valor=val
10. Actualizar `ah_cuenta` (saldo, suspensos, contador)
11. Retornar 0

### i. Flujos Alternos

**FA-01: Accion 'E' y fondos insuficientes**
- Condicion: accion='E' (o 'S' o NULL) y @i_val > saldo_para_girar
- Resultado: RETURN 41033 (no genera suspenso, ROLLBACK)

**FA-02: Saldo <= 0**
- Todo el monto va a suspenso, val_efe=$0
- NO genera linea_pendiente
- ah_debitos NO cambia (val_efe=0)
- ah_promedio1 NO cambia (alic=0)

**FA-03: Captura con saldo=0**
- No cobra nada, suspenso se actualiza con cobro=$0
- vs_valor sigue igual (todo pendiente)
- ah_suspensos NO se decrementa (sigue pendiente)

### j. Escenarios Gherkin

```gherkin
Feature: Valores en suspenso por fondos insuficientes

  Scenario: ND en linea con fondos parciales genera suspenso
    Given una cuenta con ah_disponible=300 y causa con accion 'V' en re_accion_nd
    When se procesa una ND por 1000
    Then se debita 300 (val_efe = disponible)
    And se crea ah_val_suspenso con vs_valor=700 (excedente)
    And ah_suspensos se incrementa en 1
    And se genera ah_tran_servicio tipo 4570 con ts_valor=700
    And tm_remoto_ssn = secuencial del suspenso

  Scenario: ND en linea con disponible=0 genera suspenso completo
    Given una cuenta con ah_disponible=0.00 y causa accion 'V'
    When se procesa una ND por 500
    Then tm_valor en ah_tran_monet = 0.00
    And se crea ah_val_suspenso con vs_valor=500.00 (monto completo)
    And ah_suspensos se incrementa en 1
    And ah_debitos NO cambia
    And NO se genera linea_pendiente
    And se genera ah_tran_servicio tipo 4570 por 500.00

  Scenario: Captura batch exitosa cobra suspenso completo
    Given una cuenta con saldo suficiente (>= valor pendiente)
    And un valor en suspenso (vs_estado='N', vs_valor=700)
    When se procesa ND con @t_rty='S' y @i_alt=secuencial_suspenso
    Then ah_val_suspenso.vs_estado = 'C', vs_procesada = 'S'
    And ah_val_suspenso.vs_valor_cobrado += 700
    And ah_suspensos se decrementa en 1
    And se debita el monto completo

  Scenario: Captura con disponible cero no cobra nada
    Given una cuenta con ah_disponible=0.00
    And un valor en suspenso pendiente por 500
    When se procesa ND con @t_rty='S'
    Then tm_valor en ah_tran_monet = 0.00
    And ah_val_suspenso.vs_valor_cobrado += 0 (sin incremento)
    And ah_val_suspenso.vs_valor = 500 (sin cambio)
    And ah_suspensos NO cambia
    And se genera ah_tran_servicio tipo 4570 por 500.00

  Scenario: Fondos insuficientes con accion E rechaza sin generar suspenso
    Given una cuenta con saldo insuficiente
    And causa con accion 'E' en re_accion_nd
    When se procesa una ND
    Then el sistema retorna error 41033
    And NO se genera registro en ah_val_suspenso
    And ah_cuenta queda intacta (ROLLBACK)
```

---

## CU-05 — Transacciones especiales (ATM, 4372, cotizacion, CNB, UAF, CTA MAS)

### a. Proposito

Procesar operaciones con logica especial que genera registros adicionales o aplica reglas de bypass: transacciones ATM con doble contabilizacion, tipo 4372 con servicio 4373, transferencias con cotizacion, canal CNB con manejo de secuencial, acumulador UAF, y bypass de bloqueo por categoria CTA MAS.

### b. Alcance

**Incluye:**
- ND ATM 16238/16629 genera tran_servicio con mismo tipo (TC40)
- ND ATM con fondos parciales genera 4570 adicional (TC41)
- ND ATM con disponible=0 genera suspenso + doble servicio (TC82)
- ND tipo 4372 genera tran_servicio tipo 4373 (TC35)
- Campos A06: comision individual, cantidad transacciones, indicador comision cero (TC70, TC71)
- NC/ND transferencia con cotizacion (TC50, TC51)
- Canal CNB con empresa 783 y empresa != 783 (TC52, TC88)
- Acumulador UAF con sp_uif_acum (TC53)
- Bypass de bloqueo por categoria CTA MAS (TC54, TC nuevo NC)

**No incluye:**
- Flujo basico de ND/NC sin particularidad (CU-02, CU-03)
- Validaciones de entrada (CU-01)

### c. Actores

| Actor | Tipo | Descripcion |
|-------|------|-------------|
| Canal ATM | Principal | Envia transacciones tipo 16238/16629/16643/16252 |
| Canal CNB | Principal | Banca empresarial con manejo especial de secuencial |
| Canal invocante | Principal | Envia transacciones tipo 4372 o con cotizacion |

### d. Entradas funcionales

| Parametro | Descripcion |
|-----------|-------------|
| @t_trn | 16238/16629 (ATM), 4372, o cualquier trx con particularidad |
| @i_tsn | Numero de secuencia ATM |
| @i_ubi | Ubicacion del ATM |
| @i_canal | Canal ('CNB' para banca empresarial) |
| @i_empresa | Empresa (783 = no genera secuencial) |
| @i_cotiza | Cotizacion para transferencias internacionales |
| @i_comision_indiv | Valor comision individual A06 (persiste en tm_chq_ot_plazas) |
| @i_cant | Cantidad transacciones A06 (persiste en tm_control si @i_control es NULL) |
| @i_comision_cero | Indicador debito con comision 0 A06 (persiste en tm_tipo_xfer) |

### f. Precondiciones

- Cuenta activa (con fondos suficientes, parciales o cero segun escenario)
- Para ATM: parametros @i_tsn y @i_ubi informados
- Para cotizacion: @i_cotiza > 0 y causa='32' (NC) o '940' (ND)
- Para UAF: trx/causa existente en `cc_trx_ndc_uaf` con tn_estado='A'
- Para CTA MAS: ah_categoria='U' y trx-causa en catalogo correspondiente

### g. Postcondiciones

**ATM (16238/16629/16643/16252) con fondos:**
- Registro en `ah_tran_servicio` con ts_tipo_transaccion=@t_trn, ts_tsn=@i_tsn, ts_ubicacion=@i_ubi
- ts_valor = monto en suspenso (0 si fondos OK), ts_saldo = monto debitado
- Si fondos parciales: registro adicional tipo 4570

**ATM con disponible=0:**
- Registro ah_tran_servicio con ts_saldo=0, ts_valor=monto completo
- Registro adicional tipo 4570
- NO genera linea_pendiente

**Tipo 4372:**
- Genera nuevo secuencial + INSERT ah_tran_servicio tipo 4373
- ts_nodo = isnull(@s_srv, @i_canal)
- Marca @w_reintento='S' (no genera 4570 posterior)

**Cotizacion (causa='32' NC o causa='940' ND):**
- INSERT en `cob_cuentas..cc_monet_transfer`
- mt_cotiza = @i_cotiza, mt_valor = valor_efectivo

**Canal CNB:**
- Empresa=783: reutiliza @s_ssn, no genera secuencial nuevo
- Empresa!=783: genera secuencial nuevo via sp_gen_sec

**Acumulador UAF:**
- Condicion: trx/causa existe en `cob_cuentas..cc_trx_ndc_uaf` (tn_estado='A', isnull(tn_tipo_proc,'L')='L')
- Calcula: @w_total_uif = valor_efectivo - isnull(@i_comision, 0)
- Invoca `cob_cuentas..sp_uif_acum` con @i_monto=@w_total_uif, @i_mis=@w_cliente
- Pares especiales de correccion: (4253+'802') y (4272+'801') fuerzan @w_corr_uaf='S'
- Resultado: incrementa ui_uso y ui_contador en `cob_cuentas..cc_uif`

**CTA MAS (categoria 'U'):**
- Si combinacion trx-causa existe en catalogo `ah_ncnd_ctamas_trxpermitidas` (valor=ltrim(rtrim(@t_trn))+'-'+@i_cau, estado='V'): omite validacion de bloqueo
- Si trx/causa existe en catalogo `ah_ctmas_pago_directo` (codigo=@t_trn, valor=@i_cau, estado='V'): omite validacion de bloqueo
- Aplica tanto para NC como para ND

**A06:**
- `tm_chq_ot_plazas` = @i_comision_indiv
- `tm_tipo_xfer` = @i_comision_cero
- `tm_control` = isnull(@i_control, @i_cant)

### h. Flujo Principal

1. Ejecutar flujo normal de ND/NC (debito/credito, calculo promedios, tran_monet, update cuenta)
2. Si trx ATM (16238/16629/16643/16252): INSERT `ah_tran_servicio` con tipo=@t_trn y campos ATM
3. Si trx ATM y @w_val != 0: INSERT adicional tipo 4570 (solo para 16238/16629)
4. Si trx 4372: generar nuevo secuencial + INSERT `ah_tran_servicio` tipo 4373 + marcar @w_reintento='S'
5. Si @w_val != 0 y @w_reintento='N' (no es 4372 ni ATM con 4570 ya generado): INSERT ah_tran_servicio tipo 4570
6. Si trx/causa en cc_trx_ndc_uaf: invocar sp_uif_acum
7. Si causa='32' (NC) o '940' (ND): INSERT cc_monet_transfer con cotizacion
8. Si categoria='U' y trx-causa en catalogos: bypass de bloqueo (@w_tipo1='9', @w_tipo3='9')

### i. Flujos Alternos

- ATM con fondos parciales: genera registro ATM + registro 4570 (2 registros de servicio)
- ATM con disponible=0: genera registro ATM con ts_saldo=0 + registro 4570 con monto completo
- Tipo 4372: @w_reintento='S' impide duplicacion de registro 4570 posterior
- CTA MAS sin registro en catalogo: no aplica bypass, se valida bloqueo normalmente

### j. Escenarios Gherkin

```gherkin
Feature: Transacciones especiales

  Scenario: ND ATM genera registro de servicio con campos ATM
    Given una cuenta activa con fondos suficientes
    And @t_trn=16238, @i_tsn=12345, @i_ubi=1001
    When se procesa la ND
    Then se registra ah_tran_servicio con ts_tipo_transaccion=16238
    And ts_tsn=12345, ts_ubicacion=1001
    And ts_valor=0 (sin suspenso), ts_saldo=monto_debitado

  Scenario: ND ATM con disponible cero genera suspenso y doble servicio
    Given una cuenta con ah_disponible=0.00 y causa accion 'V'
    And @t_trn=16238
    When se procesa ND por 200.00
    Then se genera ah_tran_servicio 16238 con ts_saldo=0, ts_valor=200
    And se genera ah_tran_servicio 4570 con ts_valor=200
    And se crea ah_val_suspenso por 200.00
    And tm_valor en ah_tran_monet = 0.00

  Scenario: ND tipo 4372 genera servicio 4373 y no genera 4570
    Given una cuenta activa con fondos suficientes
    And @t_trn=4372
    When se procesa la ND
    Then se registra ah_tran_servicio con ts_tipo_transaccion=4373
    And ts_valor = monto debitado
    And NO se genera registro tipo 4570 (@w_reintento='S')

  Scenario: NC transferencia con cotizacion graba en cc_monet_transfer
    Given una cuenta activa
    And @t_trn=4253, @i_cau='32', @i_cotiza=1.25
    When se procesa la NC
    Then se inserta cob_cuentas..cc_monet_transfer
    And mt_tipo_tran=4253, mt_causa='32', mt_cotiza=1.25, mt_valor=valor_efectivo

  Scenario: ND transferencia con cotizacion graba en cc_monet_transfer
    Given una cuenta activa con fondos suficientes
    And @t_trn=4272, @i_cau='940', @i_cotiza=0.90
    When se procesa la ND
    Then se inserta cc_monet_transfer con mt_cotiza=0.90

  Scenario: Acumulador UAF se invoca cuando trx/causa esta configurada
    Given causa '135' configurada en cc_trx_ndc_uaf (tn_tipo_trx=4253, tn_causa='135', tn_estado='A')
    And cliente con cedula valida de 10 digitos en cobis..cl_ente
    When se procesa NC con @t_trn=4253, @i_cau='135'
    Then se invoca sp_uif_acum con monto = valor_efectivo - comision
    And cc_uif.ui_uso se incrementa en (valor_efectivo - comision)
    And cc_uif.ui_contador se incrementa en 1

  Scenario: Cuenta categoria U (CTA MAS) bypasea bloqueo para ND
    Given una cuenta con ah_categoria='U' y bloqueo activo
    And valor '4272-464' existe en catalogo ah_ncnd_ctamas_trxpermitidas (estado='V')
    When se procesa ND con @t_trn=4272, @i_cau='464'
    Then @w_tipo1='9', @w_tipo3='9' (no matchean bloqueo)
    And la ND se ejecuta normalmente

  Scenario: Cuenta categoria U (CTA MAS) bypasea bloqueo para NC
    Given una cuenta con ah_categoria='U' y bloqueo activo
    And valor '4253-226' existe en catalogo ah_ncnd_ctamas_trxpermitidas (estado='V')
    When se procesa NC con @t_trn=4253, @i_cau='226'
    Then la NC se ejecuta normalmente sin error de bloqueo

  Scenario: Canal CNB empresa 783 reutiliza secuencial
    Given @i_canal='CNB', @i_empresa=783
    When se procesa la operacion
    Then NO se invoca sp_gen_sec para el secuencial principal
    And se usa @s_ssn original

  Scenario: Canal CNB empresa distinta de 783 genera secuencial nuevo
    Given @i_canal='CNB', @i_empresa=100
    When se procesa la operacion
    Then se invoca sp_gen_sec y genera secuencial nuevo
    And tm_secuencial != @s_ssn original
```

---

## CU-06 — Integridad transaccional y fallos de persistencia

### a. Proposito

Verificar que ante fallos en cualquier INSERT/UPDATE del flujo, el SP ejecuta ROLLBACK total y no deja registros parciales ni inconsistencias en ninguna tabla.

### b. Alcance

**Incluye:**
- Fallo INSERT ah_tran_monet: ROLLBACK, error 43000 (TC60)
- Fallo UPDATE ah_cuenta: ROLLBACK, error 35001 (TC61)
- Fallo INSERT ah_val_suspenso: ROLLBACK, error 43004 (TC62)
- Fallo sp_uif_acum: ROLLBACK, error 149076 (TC63)

**No incluye:**
- Concurrencia/deadlocks (TC64 — no automatizable en pipeline)
- Timeouts de API (TC65 — infraestructura)

### c. Actores

| Actor | Tipo | Descripcion |
|-------|------|-------------|
| Canal invocante | Principal | Envia solicitud que falla internamente |
| BD Sybase | Sistema | Rechaza INSERT/UPDATE por constraint o lock |

### d. Entradas funcionales

| Parametro | Descripcion |
|-----------|-------------|
| @i_cta | Cuenta valida (la operacion debe pasar todas las validaciones) |
| @i_val | Monto valido |
| @t_trn | Tipo transaccion valido |

### f. Precondiciones

- Cuenta activa, fondos suficientes, todas las validaciones pasan
- Para TC60/TC61/TC62: constraint temporal `CHECK (1=0)` bloquea la operacion de persistencia
- Para TC63: cedula del cliente invalida (8 digitos != 10 requeridos) fuerza error en sp_uif_acum

### g. Postcondiciones

- El SP retorna codigo de error (43000, 35001, 43004, 149076)
- `ah_cuenta` sin cambios (saldo, contador iguales al PRE)
- `ah_tran_monet` sin registros nuevos
- `ah_tran_servicio` sin registros nuevos
- `ah_val_suspenso` sin registros nuevos
- ROLLBACK total ejecutado (ROLLBACK TRANSACTION pndcca + COMMIT cuando @i_aplcobis='N')

### h. Flujo Principal

1. El sistema recibe solicitud valida (pasa todas las validaciones)
2. Abre BEGIN TRANSACTION + SAVE TRANSACTION pndcca (si @i_aplcobis='N')
3. Intenta INSERT/UPDATE en tabla objetivo
4. La operacion falla (constraint, error de SP hijo, o lock timeout)
5. Ejecuta ROLLBACK TRANSACTION pndcca (revierte al savepoint)
6. Ejecuta COMMIT TRANSACTION (cierra la transaccion sin cambios)
7. Retorna codigo de error especifico
8. No deja registros parciales en ninguna tabla

### i. Flujos Alternos

- TC63: sp_uif_acum falla por logica interna (cedula invalida), no por constraint. El ROLLBACK revierte los INSERTs que ya se hicieron (ah_tran_monet, ah_linea_pendiente).

### j. Escenarios Gherkin

```gherkin
Feature: Integridad transaccional y ROLLBACK

  Scenario: Fallo INSERT ah_tran_monet ejecuta ROLLBACK completo
    Given una cuenta activa con fondos suficientes
    And constraint CHECK(1=0) activo en ah_tran_monet
    When se procesa una NC
    Then el sistema retorna error 43000
    And ah_cuenta no se modifica (delta=0)
    And no quedan registros en ah_tran_monet, ah_tran_servicio, ah_val_suspenso

  Scenario: Fallo UPDATE ah_cuenta ejecuta ROLLBACK completo
    Given una cuenta activa con fondos suficientes
    And constraint bloquea UPDATE en ah_cuenta
    When se procesa una ND
    Then el sistema retorna error 35001
    And ah_tran_monet insertado previamente se revierte
    And no quedan registros parciales

  Scenario: Fallo INSERT ah_val_suspenso ejecuta ROLLBACK completo
    Given una cuenta con fondos parciales y causa accion 'V'
    And constraint CHECK(1=0) activo en ah_val_suspenso
    When se procesa una ND
    Then el sistema retorna error 43004
    And ah_cuenta no se modifica
    And no quedan registros en ninguna tabla

  Scenario: Fallo sp_uif_acum ejecuta ROLLBACK completo
    Given una cuenta activa y trx/causa en cc_trx_ndc_uaf
    And cedula del cliente = '12345678' (8 digitos, invalida)
    When se procesa una NC con causa que dispara UAF
    Then sp_uif_acum falla internamente
    And el sistema retorna error 149076
    And ah_cuenta no se modifica
    And ah_tran_monet insertado previamente se revierte
```

---

## CU-07 — Correccion/Reverso de operaciones

### a. Proposito

Verificar que una correccion (reverso) invierte el efecto economico de la transaccion original: NC original se revierte con factor negativo (decrementa saldo), ND original se revierte con factor positivo (incrementa saldo). No valida fondos para reversas.

### b. Alcance

**Incluye:**
- Reverso de NC decrementa saldo (TC22)
- Reverso de ND incrementa saldo (TC22b)

**No incluye:**
- Operaciones normales (CU-02, CU-03)
- Reintentos de suspenso (CU-04)

### c. Actores

| Actor | Tipo | Descripcion |
|-------|------|-------------|
| Canal invocante | Principal | Envia solicitud con @t_corr='S' |

### d. Entradas funcionales

| Parametro | Descripcion |
|-----------|-------------|
| @t_corr | 'S' indica correccion/reverso |
| @t_ssn_corr | Secuencial de la transaccion original a reversar |
| @t_trn | Tipo transaccion original (4253 para NC, 4264 para ND) |
| @i_val | Monto a reversar (mismo de la transaccion original) |

### f. Precondiciones

- Cuenta activa
- No se requiere que exista la transaccion original en BD (el SP no la valida)

### g. Postcondiciones

**Reverso de NC (@t_trn en lista NC, @t_corr='S'):**
- tfactor = -1 (invierte efecto)
- signo = 'C' (no cambia, siempre es C para NC)
- signo_lib = 'D' (para contabilidad)
- Saldo DISMINUYE (disponible -= valor_efectivo)
- tm_correccion = 'S'
- tm_sec_correccion = @t_ssn_corr

**Reverso de ND (@t_trn en lista ND, @t_corr='S'):**
- tfactor = +1 (invierte efecto)
- signo = 'D' (no cambia, siempre es D para ND)
- signo_lib = 'C' (para contabilidad)
- factor_aux = -1
- Saldo AUMENTA (disponible += valor_efectivo)
- ah_debitos DISMINUYE (factor_aux=-1)
- tm_correccion = 'S'
- tm_sec_correccion = @t_ssn_corr

**Nota importante:** El signo (C o D) NUNCA cambia por correccion. Lo que cambia es el tfactor que invierte el efecto economico. Puede dejar saldo negativo si no hay fondos suficientes para reversar una NC.

### h. Flujo Principal

1. Recibe solicitud con @t_corr='S' y @t_ssn_corr
2. Determina factor invertido:
   - NC: tfactor=-1, signo='C', signo_lib='D'
   - ND: tfactor=+1, signo='D', signo_lib='C', factor_aux=-1
3. NO valida fondos (no importa si saldo queda negativo)
4. Calcula nuevos saldos con factor invertido
5. Inserta tran_monet con tm_correccion='S', tm_sec_correccion=@t_ssn_corr
6. Actualiza ah_cuenta
7. Retorna 0

### i. Flujos Alternos

- Reverso de NC puede dejar saldo negativo (no valida fondos)
- Reverso de ND con factor_aux=-1 puede dejar ah_debitos negativo

### j. Escenarios Gherkin

```gherkin
Feature: Correccion/Reverso de operaciones

  Scenario: Reverso de NC decrementa saldo
    Given una NC previa con secuencial conocido
    When se procesa con @t_corr='S', @t_trn=4253, @t_ssn_corr=secuencial_original
    Then ah_disponible DISMINUYE por el monto (tfactor=-1)
    And tm_correccion='S', tm_sec_correccion=secuencial_original
    And tm_signo='C' (no cambia)

  Scenario: Reverso de ND incrementa saldo sin validar fondos
    Given una ND previa con secuencial conocido
    When se procesa con @t_corr='S', @t_trn=4264, @t_ssn_corr=secuencial_original
    Then ah_disponible AUMENTA por el monto (tfactor=+1)
    And ah_debitos DISMINUYE (factor_aux=-1)
    And tm_correccion='S', tm_sec_correccion=secuencial_original
    And tm_signo='D' (no cambia)
    And no se validan fondos
```

---

## Trazabilidad CU — TC

| CU | TCs asociados |
|----|---------------|
| CU-01 Validaciones | TC01, TC02, TC03, TC04, TC05, TC06, TC07, TC08, TC09, TC10, TC11, TC12, TC13, TC84, TC85, TC_cerrada (nuevo) |
| CU-02 Nota de Credito | TC20, TC21, TC23, TC24, TC25, TC50, TC81, TC83, TC86, TC_ctamas_nc (nuevo) |
| CU-03 Nota de Debito | TC30, TC37, TC51, TC52, TC87, TC88, TC_inactiva_nd (nuevo) |
| CU-04 Fondos/Suspenso | TC26, TC31, TC32, TC33, TC34, TC80, TC85, TC89 |
| CU-05 Especiales | TC35, TC40, TC41, TC50, TC51, TC52, TC53, TC54, TC70, TC71, TC82, TC88, TC_ctamas_nc (nuevo) |
| CU-06 Integridad | TC60, TC61, TC62, TC63 |
| CU-07 Correccion | TC22, TC22b |
| Bypass bloqueo | TC08, TC36, TC54, TC_ctamas_nc (nuevo) |
| UAF | TC24, TC25, TC53 |
| Canal CNB | TC52, TC88 |

# Plan de Implementación — Endurecer Auditor UML + Nomenclatura UML pura

> Deriva de `jp/alcance.md` (commit 4274e518). Convierte las 12 funcionalidades del alcance en
> trabajo aterrizado (archivo, orden, estado actual) y agrega el hallazgo de nomenclatura Java->UML
> reportado por el equipo. Fuente única de fixes: `uml_gen` (el `.puml` no se corrige a mano).

---

## 0. Hallazgo prioritario reportado — Nomenclatura Java en vez de UML

**Reportado:** los diagramas usan terminología Java (p. ej. `implements`, `extends`) en vez de la
nomenclatura propia de UML. **Verificado con evidencia dura** en los 13 entregables de
`documents/sp_debcred_empresa/uml_gen/**/*.puml`:

- **66 relaciones** con etiqueta `implements` y **31** con `extends` como texto de la relación.
- Origen exacto: `scripts/uml_gen/generators/class_gen.py`
  - L99 / L104: herencia -> `add(..., "--|>", "extends")` (etiqueta Java `extends`).
  - L107: realización -> `add(..., "..|>", "implements")` (etiqueta Java `implements`).
- **Contradicción interna:** la propia docstring de `_derive_relations` (L63) dice "NOMENCLATURA UML
  PURA (no Java)", pero el código emite las palabras Java.
- **Contraste:** el diagrama de COMPONENTES ya usa la convención correcta del banco
  (`<<realiza>>`, prompt-banco §4.5); solo el diagrama de CLASES quedó con términos Java.

### Regla UML correcta (según prompt-banco §4.5 y UML estándar)
- La flecha `..|>` (línea punteada + triángulo hueco) **ES** la Realización; en la leyenda del banco
  se rotula `<<realiza>>` (no "implements").
- La flecha `--|>` (línea sólida + triángulo hueco) **ES** la Generalización/herencia; en UML NO lleva
  etiqueta de palabra — la flecha ya lo dice. Si se quiere leyenda, el banco usa español, no "extends".
- Regla dura nueva: **prohibido texto de palabra-clave Java** (`implements`, `extends`, `import`) como
  etiqueta de relación en cualquier `.puml`. La semántica va en la flecha + estereotipo español.

### Fix (Funcionalidad 0 — el más directo, bajo riesgo)
En `class_gen.py` `_derive_relations`:
- Realización (L107): cambiar etiqueta `"implements"` -> `"<<realiza>>"`.
- Generalización (L99, L104): quitar la etiqueta `"extends"` (dejar `""`) — la flecha `--|>` ya es
  generalización; o rotular `"<<generaliza>>"` si el banco quiere leyenda explícita (decidir con banco;
  recomendación: sin etiqueta, es lo UML-canónico). Aplicar igual al nodo de framework (RuntimeException).
- Verificar que `class_renderer.py` L71 imprime el label verbatim (lo hace) — no requiere cambio.
- Barrido preventivo: grep de `implements|extends|import` como etiqueta en TODOS los generadores
  (`class_gen`, `package_gen`, `component_gen`, `sequence_gen`) para que no reaparezca en otra vista.

> Este fix NO regenera aquí (política de esta fase: root-fix + `py_compile`). La regeneración +
> re-auditoría de los 13 se hace en un ciclo aparte cuando se decida.

---

## Mapa: 12 funcionalidades del alcance -> estado real y aterrizaje

| # | Funcionalidad (alcance) | Estado hoy | Archivo(s) objetivo | Tipo |
|---|--------------------------|-----------|---------------------|------|
| 0 | Nomenclatura UML pura (no Java) | **NUEVO, verificado** | `generators/class_gen.py` (+ barrido en otros gen) | fix generador |
| 1 | Gate de contexto obligatorio | Parcial (prompt-banco §0/§1 ya condiciona) | `scripts/uml_gen/` nuevo precheck + `agente-qa-uml-02-auditor.md` | script + agente |
| 2 | Paquete unificado de evidencia por carpeta | No existe | nuevo `scripts/uml_gen/evidence_pack.py` que consolida .puml+java-structure+manifest+contexto | script |
| 3 | Prompt ensamblado por secciones (orden duro) | Parcial (prompt-banco ya tiene §0 al inicio) | `agente-qa-uml-02-auditor.md` + `prompts-banco/auditor.md` | prompt |
| 4 | Modo conservador por defecto (NO_DETERMINABLE) | Hecho en prompt-banco; falta en agente interno | `agente-qa-uml-02-auditor.md` | prompt |
| 5 | Auditoría por capas con escalamiento | Parcial (skill A1-A9 -> agente C ya existe) | `agente-qa-uml-00-orquestador.md` (formalizar secuencia) | agente |
| 6 | Contrato estricto auditor->builder | No existe | schema de hallazgo (id, evidencia, causa raíz, alcance-fix, cierre, reapertura) en `agente-qa-uml-02-auditor.md` + agente builder | prompt + schema |
| 7 | Memoria de hallazgos resueltos (ledger + fingerprint) | No existe | nuevo `scripts/uml_gen/findings_ledger.py` + JSON por SP | script |
| 8 | Revisar heurísticas frágiles A2/A3/A4 | **Diagnosticado, sin tocar** | `scripts/uml_gen/audit_uml.py` (A2 `_looks_like_class` por sufijo de nombre; A3 `"Port" in box`; A4 forma del nombre) | fix skill (riesgo) |
| 9 | Normalizador nomenclatura Java->UML | Se solapa con #0; ampliar a cobertura general | `generators/*` + posible capa comun de etiquetas | fix generador |
| 10 | Suite de regresión (casos dorados) | No existe | nuevo `scripts/uml_gen/tests/golden/` + runner | tests |
| 11 | Orquestador anti-loop (re-auditoría total/parcial) | No existe | `agente-qa-uml-00-orquestador.md` + apoyo del ledger #7 | agente |
| 12 | Estados del auditor (3 dimensiones) | No formalizado | `agente-qa-uml-02-auditor.md` (operativo / evaluabilidad / veredicto) | prompt |

---

## Orden de implementación recomendado (por dependencia y riesgo)

**Fase A — Nomenclatura (rápido, alto impacto visible al banco, bajo riesgo):**
1. Func 0 + 9: `class_gen.py` etiquetas UML + barrido preventivo en generadores. `py_compile`.

**Fase B — Contratos y estados (prompt/agente, sin regenerar):**
2. Func 12: formalizar los 3 estados en el agente auditor.
3. Func 4: modo conservador por defecto en el agente interno (ya está en prompt-banco; alinear).
4. Func 6: schema de hallazgo auditor->builder (id estable, evidencia, causa raíz, alcance-fix,
   condición de cierre/reapertura).
5. Func 3: reordenar el prompt del agente por secciones duras (reglas al inicio y cierre).

**Fase C — Evidencia y precheck (scripts nuevos):**
6. Func 1 + 2: precheck de paquete mínimo + `evidence_pack.py`. Si falta insumo -> reglas afectadas
   `NO_DETERMINABLE` (no hallazgo).

**Fase D — Memoria y anti-loop:**
7. Func 7: `findings_ledger.py` con fingerprint de evidencia.
8. Func 11: orquestador decide re-auditoría total vs parcial usando el ledger.

**Fase E — Robustez determinista (mayor riesgo de regresión, va con red):**
9. Func 10: suite de casos dorados (puertos presentes/ausentes, lib sin secuencia, degradadas,
   externos, NO_DETERMINABLE) — se construye ANTES de tocar #8.
10. Func 8: revisar A2/A3/A4 para depender de evidencia estructural, no de sufijos de nombre.
    Validar contra los casos dorados de #9 (sin regresión).

> Racional del orden: A entrega valor inmediato y de bajo riesgo (es lo que reporta el equipo). E va al
> final y detrás de su suite de regresión porque tocar la capa determinista amplifica ruido si falla.

---

## Alcance de esta sesión (a confirmar con el usuario)
Recomendación: ejecutar **Fase A (Func 0 + 9)** ahora — es el hallazgo reportado, está verificado, es
acotado y de bajo riesgo. El resto (B-E) queda planificado en este documento para abordar por fases.

## Verificación de Fase A (sin end-to-end)
- `python3 -m py_compile` de los generadores tocados.
- grep: 0 etiquetas `implements`/`extends`/`import` como texto de relación en la SALIDA del generador
  (probar generando UN diagrama de clases a /tmp, sin toplar el entregable committeado) o revisión de
  código del label emitido. La regeneración+re-auditoría de los 13 es un ciclo aparte.

## Notas
- No tocar el `.puml` a mano (se sobrescribe). Todo fix en `uml_gen`.
- Func 8 es la única con riesgo real de regresión: no se toca sin la suite dorada (Func 10) delante.
- Varias piezas ya están parcialmente hechas por el trabajo previo del prompt del banco; este plan las
  marca como "parcial" para no duplicar.

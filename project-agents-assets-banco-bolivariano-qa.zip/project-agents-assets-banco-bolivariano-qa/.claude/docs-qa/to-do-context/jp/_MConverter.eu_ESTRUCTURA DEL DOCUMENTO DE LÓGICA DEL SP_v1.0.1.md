**ESTRUCTURA DEL DOCUMENTO DE LÓGICA DEL SP**

- Entender qué hace el SP realmente

- Descubrir reglas de negocio ocultas

- Documentar condiciones técnicas que afectan funcionalidad

- Servir de base para CU, HU, API Contract y pruebas de integración

**1. Identificación**

- Nombre del SP

- Base / esquema

- Módulo: Ahorros

- Método: Extraído por IA

- Fecha de documento

- Versión

**2. Descripción General del SP**

**3. Parámetros de Entrada (E) y Significado**

Incluye todos los parámetros relevantes con dos dimensiones:

- Uso funcional

- Uso técnico

Ejemplo:

| **Parámetro** | **Tipo** | **Uso Funcional** | **Uso Técnico** | **Obligatorio** |
|----|----|----|----|----|
| @i_cta | cuenta | Cuenta origen | Se usa para lookups en tablas clave | Sí |

*(El proveedor debe llenar esto completo.)*

**4. Parámetros de Salida (S)**

| **Salida**   | **Tipo** | **Significado Funcional**            |
|--------------|----------|--------------------------------------|
| @o_ssn_monet | int      | Secuencial del movimiento registrado |

**5. TRADUCCIÓN EXPLÍCITA DE LA LÓGICA DEL SP**

**5.1 Flujo lógico principal del SP**

**Traducción del flujo real del código a lenguaje humano, respetando:**

- **orden de ejecución**

- **dependencias**

- **decisiones**

**No es "flujo feliz", es flujo dominante del código.**

**5.2 Traducción de validaciones técnicas que afectan funcionalidad**

Lista todas las **condiciones que el SP evalúa** para:

- continuar

- rechazar

- desviar lógica

Incluye reglas técnicas que **impactan el resultado funcional**.

**5.3 Traducción de cálculos técnicos y reglas internas**

Documenta:

- fórmulas

- factores

- signos

- redondeos

- acumuladores

Aquí vive el **core matemático y financiero** del SP.

**6. MATRIZ DE CONDICIONES Y EFECTO EN DATOS (SECCIÓN NUEVA Y OBLIGATORIA)**

Cada condición relevante del SP debe documentarse **con su impacto exacto en tablas**.

Relaciona cada condición relevante con:

tablas consultadas

tablas modificadas

tipo de impacto

resultado

Es la sección más importante para **migración a microservicios**.

**Formato estándar POR CONDICIÓN**

**🔹 Condición ID**

**COND‑XX**

**Condición / Regla**

Descripción clara de la condición evaluada.

**Regla del SP**

Explicación de la decisión que toma el SP.

**Tablas consultadas (SELECT)**

| **Tabla** | **Campo clave** | **Propósito** |
|-----------|-----------------|---------------|

**Tablas modificadas**

**INSERT**

| **Tabla** | **Descripción del registro** |
|-----------|------------------------------|

**UPDATE**

| **Tabla** | **Campos actualizados** | **Motivo** |
|-----------|-------------------------|------------|

**DELETE**

| **Tabla** | **Condición** |
|-----------|---------------|

**Resultado Funcional**

Éxito

Error devuelto (código)

Continuación / rechazo

**Impacto para MS**

Lógica debe replicarse

Lógica se absorbe

Lógica se delega a otro MS

**7. SPs DEPENDIENTES / SPs INVOCADOS (SECCIÓN OBLIGATORIA)**

Esta sección documenta todos los Stored Procedures llamados por el SP principal y forma parte integral de la lógica funcional.

Nota: La lógica implementada en estos SPs debe considerarse parte del comportamiento que el MS debe replicar.

**7.1 Listado de Stored Procedures Invocados**

| **SP llamado** | **Propósito funcional** | **Momento de invocación** | **Impacto en el flujo** | **¿Decide continuar?** |
|----|----|----|----|----|
| sp_ctah_vigente | Valida estado y vigencia de cuenta | Inicio del proceso | Determina si el proceso continúa | Sí |

**7.2 Responsabilidad de Cada SP Dependiente**

Para cada SP debe indicarse explícitamente:

- Qué valida o calcula

- Qué regla de negocio implementa

- Qué error retorna si falla

- Qué efecto produce en el resultado final

**8. Validación especiales (código quemado)**

**9. Catálogos consultados**

**10. Códigos de error**

| **Código** | **Motivo**     | **Resultado** |
|------------|----------------|---------------|
| 141011     | Monto inválido | Rechazo       |

**12. Excepciones técnicas**

- Rollback por error en inserts

- SPs auxiliares que fallan

- Errores al generar secuenciales

- Inconsistencias SQL

**13. Manejo de transacciones y excepciones**

Describe:

- commit

- rollback

- fallos técnicos

- inconsistencias SQL

Importante para equivalencia transaccional.

# TODO — sp_cnb_consulta_saldo (NCBE-1169): bug del comparador gRPC + hallazgos de la corrida

## 1. Bug real del motor: comparador gRPC lee el campo en el nivel equivocado (5 falsos positivos)

**Estado:** pendiente de fix. NO aplicado todavia (requiere tocar `compare_grpc_vs_rest` en
`execute_all.py`, que es codigo compartido por todos los SPs -- se documenta aqui para decidir
alcance/prioridad antes de tocarlo).

**Sintoma:** corrida `sp_cnb_consulta_saldo-14-08-2026-1733` marco `INCONSISTENCIA` en TC01, TC06,
TC07, TC08, TC10 -- pero en los 5, SP=REST=gRPC coinciden EXACTAMENTE (verificado leyendo la
respuesta cruda de gRPC directamente, no solo el diff del motor).

**Causa raiz:** el DICCIONARIO SP-REST del documento declara la columna "Campo gRPC" con el path
completo (`data.oCodRespuesta`, `data.oDetalleError`, etc., igual convencion que REST). El comparador
`compare_grpc_vs_rest` en `execute_all.py` hace `_get_by_path(grpc_response, grpc_field)`, pero en
la practica esta extrayendo `null` para `oCodRespuesta`/`oDetalleError` en vez del valor real anidado
en `response.data.*` -- compara `null` (grpc) vs `<valor real>` (rest) -> marca diff aunque el dato
real coincide.

**Evidencia (los 5 casos, mismo patron):**

| TC | SP | REST | gRPC real (data.oCodRespuesta) | diff reportado (grpc, rest) |
|----|----|------|-------------------------------|------------------------------|
| TC01 | 33333 | 33333 | 33333 | oCodRespuesta (null, 33333) + oDetalleError (null, "ERROR AL CONCILIAR REGISTROS") |
| TC06 | 1011 | 1011 | 1011 | oCodRespuesta (null, 1011) |
| TC07 | 1011 | 1011 | 1011 | oCodRespuesta (null, 1011) |
| TC08 | 1011 | 1011 | 1011 | oCodRespuesta (null, 1011) |
| TC10 | 1011 | 1011 | 1011 | oCodRespuesta (null, 1011) |

TC01 es el mismo patron extendido a un segundo campo (`oDetalleError`) porque es el unico de los 5
que transita la rama de error 033333 con ese campo poblado.

**Que falta hacer:** revisar `compare_grpc_vs_rest`/`_get_by_path` en `execute_all.py` -- probablemente
el path de comparacion para gRPC necesita resolver el mismo prefijo `data.` que ya usa para REST, o
hay una desalineacion especifica entre como se guarda `grpc_output` en el JSON vs como el diccionario
declara el path. Antes de tocar el codigo, confirmar con un TC de otro SP que YA usa gRPC con exito
(ej. pa_fir_consulta_con_especial) si el bug es generico o especifico de este documento/SP.

---

## 2. Hallazgos de la corrida (contexto para banco / migracion)

### 2a. Codigo 031008 -- el mensaje del catalogo no coincide con la causa real (curiosidad del SP, no bug de test)
El SP (`cob_cuentas__sp_cnb_consulta_saldo.sql` L113-140) dispara 031008 cuando `@e_fecha IS NULL` Y
`cobis..ba_fecha_proceso` esta VACIA, y toma el `@o_detalle_error` de `cobis..cl_errores` donde
`numero=031008`. Ese mensaje real en el catalogo es **"CUENTA BLOQUEADA PARA MOVIMIENTOS"** -- no
tiene nada que ver con fecha de proceso. Es el propio SP reutilizando un codigo de catalogo generico
para una causa distinta. No afecta la validez de TC02 (el trigger SI es correcto: tabla vacia), pero
vale la pena que banco/migracion lo sepan (el `@o_detalle_error` que el micro devuelva en ese escenario
dira "cuenta bloqueada" aunque la causa real sea la fecha).

### 2b. TC02/TC03 -- NOT_APPLICABLE, confirmado con el codigo real del SP
- **TC02** (`i_aplcobis='N'`): 031008 es alcanzable EN TEORIA, pero requiere que
  `cobis..ba_fecha_proceso` este VACIA (hoy tiene 1 fila, 30-ene-2026). Vaciarla es destructivo sobre
  una tabla critica COMPARTIDA por todo el sistema (afecta a cualquier otro SP que la lea) -- no se
  puede provisionar sin coordinacion de DBA en ventana aislada.
- **TC03** (`i_aplcobis='S'`): defecto REAL del SP, independiente del punto anterior. L121-128: la
  rama `@i_aplcobis='S'` invoca `exec cobis..sp_cerror` pero NUNCA hace `RETURN` -- el flujo cae a
  "HOMOLOGAR CANAL CNB" (L142) y continua normal hacia el ruteo consulta/pago. Aunque se lograra
  vaciar la tabla, TC03 JAMAS llegaria a `RETURN 031008` por esta rama. Confirmado en la corrida real:
  TC03 con datos ficticios de tarjeta termina en 1011 (rechazo de tarjeta invalida en
  `sp_cnb_consulta_comision`/`pa_cc_iccta_pred`), no en 031008 -- exactamente lo que predice el codigo.
  **Esto es un hallazgo real para reportar a migracion**, distinto del gap de TC02.

### 2c. TC04/TC05 -- que prueban y por que no llegan a 0
Ambos SP prueban la RN-03 (homologacion de usuario CNB via `cobis..cl_tabla`/`cl_catalogo`), usando
una cuenta AHO de "control" para evitar la ruta ATM normal:
- **TC04**: cuenta AHO `0021000557` con tarjeta `5977770000144002`. agente-02 lo marco PASS estatico
  ("plausible") pero con WARN porque `sp_cnb_consulta_comision`/`pa_cc_iccta_pred` son dependencias
  opacas (sin codigo fuente en sybase-local) -- no verificable sin ejecutar de verdad. La corrida real
  da 1011 (tarjeta invalida), no 0: la tarjeta de control no supera la validacion real del hijo.
- **TC05**: cuenta AHO `0025000032` con tarjeta truncada `143004` (PAN real
  `5977770000143004`, RIGHT10). agente-02 ya habia encontrado que esta cuenta NO existe en
  `cob_ahorros..ah_cuenta` en este ambiente. El guion de preparacion del propio TC05 anticipa esto
  (su rama `IF @v_estado_aho_orig_tc05 IS NULL RETURN 31088` -- pero eso es la SIMULACION del TC, no
  el SP real). El SP real da 1011 (misma causa: tarjeta/cuenta de control no valida en el hijo real).
- **Conclusion para ambos:** no es un defecto de la herramienta ni del parser (ya resuelto el bug de
  parametros de esta sesion) -- es que las cuentas/tarjetas de control que banco eligio para RN-03 no
  satisfacen la condicion real de homologacion en este ambiente QA. Se necesita una terna real
  (cuenta+tarjeta+identificacion) que SI pase la validacion del hijo para poder probar RN-03 de
  verdad.

### 2d. Cluster de 11 TCs en ruta `pago_comision` (tipo='P') con resultados inconsistentes -- SI es por PRE/POST mal ajustadas (confirmado)
Revisadas las PRE/POST de los 11 TCs de pago (TC09, TC11, TC12, TC15, TC18, TC19, TC20, TC24, TC25,
TC26, TC27, TC30, TC31): **9 de 11 no tienen PRE ni POST en absoluto** ("(sin PRE)"/"(sin POST)"); los
2 que si tienen algo (TC09, TC27) solo traen un POST no-op de verificacion
(`UPDATE tabla SET campo=campo WHERE campo=X`, no restaura nada). La seccion `## EJECUCION POR
GRUPOS` sigue en DUMMY (sin aislamiento definido) -- exactamente el WARN que ya habia dado agente-02
(`V-PRE-FLOW-01`/`V-GRP-01`).

Consecuencia observada: la cuenta `0000010821` se reutiliza en 8 TCs (consulta y pago mezclados:
TC07/20/26/27/28/29/30/31) y `0000010214` en 3 (TC02/15/27), sin restaurar saldo/estado entre cada
uno. Cada "pago" exitoso de un TC anterior deja residuo (fila de transaccion/comision insertada) que
colisiona con el siguiente TC sobre la misma cuenta -> **33005/43004 "ERROR EN INSERCION DE
TRANSACCION DE SERVICIO"** en 8 de los 11 (TC09, TC12, TC15, TC18, TC24, TC26, TC30, TC31). Los 2 que
SI dan `0` (TC11, TC25) son justamente las unicas cuentas de pago que NO se repiten en otro TC.
Se agrava porque esta corrida se ejecuto 3 veces hoy sobre las MISMAS cuentas mientras se depuraba.

Dos codigos NO entran en este patron de contaminacion (cuentas propias, no compartidas) y parecen
hallazgos genuinos, no artefacto:
- **TC19** (`@e_comision=0.00`, cuenta `0000010445`): da `124020` ("ERROR AL INSERTAR ORDEN DE
  RECAUDACION"). El titulo dice que el padre no valida comision=0 y la pasa al hijo sin control --
  el hijo SI falla al insertar con comision cero. Podria ser un defecto real del hijo (no maneja
  comision=0 con gracia) -- vale la pena reportarlo.
- **TC20** (`@e_comision=-1.00`, cuenta `0000010445`): da `141011` ("VALOR DEL MONTO NO PUEDE SER
  CERO O MENOR QUE CERO"). **Este es el comportamiento CORRECTO esperado** -- el hijo rechaza
  explicitamente el monto negativo con un mensaje claro y especifico. `RETURN 141011` deberia
  documentarse como el resultado esperado real de este TC (no es un defecto).

**Recomendacion:** antes de poder confiar en el veredicto automatico del cluster de pago, se necesita
(a) definir el aislamiento real de `EJECUCION POR GRUPOS` (cuentas exclusivas por lote, o reset entre
TCs) y (b) un reset/restauracion de las cuentas mutadas hoy (`0000010821`, `0000010214`, `0000011017`,
`0000601864`) antes de la proxima corrida limpia.

---

## 3. Lista de los 20 TCs sin "Resultado esperado" declarado por banco -- que deberia ser cada uno

Los 7 de tipo consulta (`C`, solo lectura, resultado confiable/reproducible) tienen el codigo real
observado como candidato solido a documentar (coincide con lo que el titulo del TC describe):

| TC | Titulo (resumen) | Codigo real | Deberia documentarse como |
|----|------------------|-------------|---------------------------|
| TC13 | tipo_cuenta='XXX', sin asignacion TRN | 1011 | `RETURN 1011` |
| TC14 | AHO + cuenta=NULL, EXISTS(NULL)=FALSE | 1011 | `RETURN 1011` |
| TC16 | mon=0, BVA limite inferior, rechazo 033333 (titulo YA lo dice) | 33333 | `RETURN 33333` |
| TC17 | mon=255, BVA maximo tinyint, rechazo 033333 (titulo YA lo dice) | 33333 | `RETURN 33333` |
| TC21 | hijo retorna codigo no registrado en cl_errores | 1011 | `RETURN 1011` (confirmado: 1011 no esta en cl_errores) |
| TC22 | AHO normal (EXISTS=FALSE) + tipo=C | 1011 | `RETURN 1011` |
| TC23 | @@error post consulta_comision, RAMA-013 | 1011 | `RETURN 1011` |

2 de tipo consulta con **contradiccion titulo vs resultado real** -- requieren decision de banco (el
titulo dice "exito" pero el dato real de tarjeta/cuenta no lo alcanza, mismo patron que TC04/TC06-08):

| TC | Titulo dice | Codigo real | Nota |
|----|-------------|-------------|------|
| TC28 | "consulta_comision **exito** con OUTs en NULL" | 1011 | Contradiccion: titulo espera exito, dato real de tarjeta lo rechaza. Definir si el TC debe usar una tarjeta valida o si el resultado esperado real es 1011. |
| TC29 | "integridad de pasantes hacia consulta_comision" | 1011 | No afirma exito explicito; podria ser intencional (solo prueba passthrough de parametros). Confirmar con banco. |

11 de la ruta `pago_comision` (tipo `P`/`NULL`) -- **NO documentar el codigo real todavia**: la corrida
esta contaminada por cuentas compartidas sin PRE/POST de aislamiento (ver seccion 2d). Necesitan
re-correrse limpios (cuentas restauradas + aislamiento definido) antes de fijar su resultado esperado:

TC09, TC11, TC12, TC15, TC18, TC19*, TC20*, TC24, TC25, TC26, TC30, TC31

`*` TC19 y TC20 son la excepcion: sus cuentas no se comparten con otro TC, asi que sus codigos
(124020 y 141011 respectivamente) probablemente SI son confiables ya (ver 2d) -- TC20 en particular
ya se puede documentar como `RETURN 141011` (comportamiento correcto validado).

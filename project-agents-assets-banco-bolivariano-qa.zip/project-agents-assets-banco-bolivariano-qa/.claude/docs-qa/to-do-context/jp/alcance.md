# Alcance

## Problema

El flujo actual `generacion -> validacion -> auditoria -> fix -> re-auditoria` tiene tres fallas principales:

- El auditor levanta falsos positivos cuando no recibe todo el contexto necesario y termina inventando hallazgos.
- El builder corrige de mas, toca directrices que ya estaban bien implementadas y mete regresiones.
- El loop vuelve a abrir observaciones ya resueltas porque no existe una memoria operativa ni un contrato estricto entre auditor y builder.

Ademas de esos sintomas, hoy tambien existen problemas estructurales que aumentan costo y reproceso:

- El prompt del auditor mezcla reglas, contexto y formato de salida, lo que facilita perdida de instrucciones por orden o saturacion.
- La capa determinista todavia usa heuristicas por nombre en algunos checks, lo que puede introducir ruido reproducible.
- El generador a veces arrastra nomenclatura Java al UML en vez de expresar correctamente la semantica UML esperada por el banco.
- No hay una separacion suficientemente estricta entre lo `EVALUABLE` y lo `NO DETERMINABLE`.
- No hay un mecanismo fuerte para decidir cuando re-auditar parcialmente y cuando re-auditar todo.

El objetivo de este alcance es endurecer el auditor como solucion interna para producir entregas mas limpias, con menos falsos positivos, menos vueltas del loop y mas aprobaciones limpias del banco.

## Solucion

Se implementara una evolucion integral del auditor basada en `agentes + skills + scripts`, manteniendo el principio de que el `.puml` no se corrige a mano y que todo fix definitivo ocurre en `uml_gen`.

La solucion seguira estos principios:

- Ningun hallazgo conceptual se emite sin paquete minimo de evidencia.
- Cuando falte evidencia, la salida correcta es `NO DETERMINABLE`, no sospecha ni observacion inventada.
- La skill determinista y el agente conceptual deben compartir el mismo contrato de entrada, evidencia y salida.
- El builder solo puede ejecutar fixes dentro de un alcance explicitamente autorizado por el auditor.
- Un hallazgo resuelto no puede reabrirse salvo que cambie la evidencia o cambie la regla.
- La auditoria debe separar claramente estado operativo, evaluabilidad y veredicto final.

El paquete minimo de evidencia para una auditoria confiable sera:

- `.puml`
- `java-structure.json`
- `uml-manifest.json`
- contexto del SP y casos de uso
- `bri.json` cuando aplique

## Funcionalidades

### 1. Gate de contexto obligatorio

Antes de correr la auditoria conceptual, un script o skill validara que exista el paquete minimo de evidencia. Si falta algun insumo obligatorio, la auditoria no emitira hallazgos conceptuales y marcara las reglas afectadas como `NO DETERMINABLE`.

### 2. Paquete unificado de evidencia por carpeta

Se consolidara la evidencia de cada carpeta auditada en un artefacto comun de lectura para agente y skill. Este paquete resumira `.puml`, `java-structure.json`, `uml-manifest.json`, contexto del SP/casos de uso y `bri.json` cuando exista.

### 3. Prompt ensamblado del auditor

El prompt del auditor dejara de ser un bloque largo monolitico. Se armara por secciones en orden duro:

- reglas vinculantes
- prohibiciones de inferencia
- insumos disponibles
- criterios evaluables
- formato de salida

Las reglas criticas de `no inventar` y `NO DETERMINABLE` deberan aparecer al inicio y al cierre para reducir perdida por contexto intermedio.

### 4. Modo conservador por defecto

El agente auditor trabajara en modo conservador. Si una conclusion no esta soportada por estereotipos, tipos UML, relaciones declaradas o artefactos adjuntos, no podra subir a hallazgo. La salida obligatoria sera `NO DETERMINABLE`.

### 5. Auditoria por capas con escalamiento controlado

La auditoria seguira una secuencia fija:

1. precheck de insumos
2. skill determinista
3. filtro de evaluabilidad
4. agente conceptual
5. veredicto final

El agente conceptual no podra opinar sobre reglas que no hayan sido habilitadas por evidencia suficiente.

### 6. Contrato estricto entre auditor y builder

La salida del auditor se enriquecera para que el builder no corrija de mas. Cada hallazgo debera incluir como minimo:

- identificador estable
- evidencia
- causa raiz probable
- alcance permitido del fix
- archivo o modulo objetivo
- condicion de cierre
- condicion de reapertura

Con esto el builder solo podra tocar lo explicitamente autorizado.

### 7. Memoria de hallazgos resueltos

Se implementara un ledger o historial de hallazgos resueltos con fingerprint de evidencia. Si un hallazgo vuelve a aparecer, el sistema comparara evidencia nueva vs previa antes de reabrirlo. Si no hubo cambio real, no debe reabrirse.

### 8. Revision de heuristicas fragiles en la skill

Los checks deterministas mas sensibles a falsos positivos, especialmente A2, A3 y A4, deberan revisarse para depender menos de patrones de nombre y mas de evidencia estructural real. Esta mejora es clave porque si la capa objetiva mete ruido, el resto del pipeline lo amplifica.

### 9. Normalizador de nomenclatura Java -> UML

Se agregara una capa en `uml_gen` para evitar que la nomenclatura tecnica de Java contamine vistas UML donde deberian verse roles, puertos, externos y conceptos del dominio del diagrama. Esto apunta a mejorar legibilidad y aprobacion del banco.

### 10. Suite de regresion para auditor y generador

Se definiran casos dorados para patrones frecuentes del dominio:

- puertos reales presentes y ausentes
- librerias sin secuencia local
- secuencias degradadas
- externos bien modelados
- casos donde corresponde `NO DETERMINABLE`

Cada cambio en prompt, agente, skill o generador debera compararse contra estos casos antes de darse por valido.

### 11. Orquestador anti-loop

Se agregara una capa de orquestacion que decida si corresponde re-auditoria total o parcial, que carpetas se ven afectadas por un fix y que hallazgos siguen vigentes. El objetivo es bajar vueltas innecesarias y costo operativo.

### 12. Estados del auditor

Para eliminar ambiguedad, el auditor tendra tres dimensiones de estado.

#### Estado operativo del proceso

- `ABORTADO`: la ejecucion es invalida por parametro faltante o invocacion incorrecta.
- `BLOQUEADO`: faltan insumos obligatorios o la carpeta objetivo no puede auditarse.
- `LISTO`: la carpeta paso el precheck y puede auditarse.
- `AUDITORIA_ESTRUCTURAL_EN_CURSO`: esta ejecutandose la skill determinista.
- `AUDITORIA_CONCEPTUAL_EN_CURSO`: esta ejecutandose el agente sobre reglas evaluables.
- `FIX_PENDIENTE`: ya existe veredicto y hay cambios raiz por aplicar en `uml_gen`.
- `REAUDITORIA_PENDIENTE`: ya se aplico un fix y toca volver a correr el flujo.
- `CERRADO`: la ejecucion termino y no quedan acciones pendientes en esa corrida.

#### Estado de evaluabilidad por regla o hallazgo

- `EVALUABLE`: existe evidencia suficiente para emitir juicio.
- `NO_DETERMINABLE`: falta evidencia o contexto; no puede emitirse hallazgo.

#### Veredicto final de calidad

- `APROBADO`: no hay hallazgos activos.
- `APROBADO_CON_OBSERVACIONES`: hay hallazgos no bloqueantes.
- `RECHAZADO`: hay al menos un hallazgo bloqueante o de severidad suficiente para impedir entrega limpia.

La regla operativa principal sera esta: `NO_DETERMINABLE` nunca debe degradarse artificialmente a hallazgo. Si falta evidencia, se declara falta de evaluabilidad y se corta la inferencia.

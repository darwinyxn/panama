# TODO — pa_fir_consulta_con_especial (NCBE-1174): corregir notacion de resultsets en el DICCIONARIO

**Estado: RESUELTO (2026-08-12).** Corrida final del agente-05: **9/9 EQUIVALENTE**, confirmado en
`QA-CASOS-PARSEADOS.json` (no asumido). Se aplico el fix de notacion de este TODO Y, al destaparse
uno tras otro, se encontraron y corrigieron ADEMAS 3 bugs reales del motor (nunca antes detectados
porque ningun SP previo en `result_sets` mode tenia texto libre tan largo/con comillas/con saltos de
linea embebidos como este):

1. **Notacion del diccionario** (el bug original de este TODO) — resuelto: `sp_output_mode` agregado
   al CONFIG, `RS1./RS2.` renombrado a `result_set[0]./result_set[1].` con los alias reales de columna
   del SP. Commits `7e09b7a` (fix inicial) + `d957a9e` (2 correcciones adicionales: quitar anotacion
   `(ce_xxx)` del sp_var que rompia la deteccion de header, y paths gRPC con prefijo `data.`).
2. **`_execute_raw` perdia el tab separador** al fusionar filas fragmentadas por `\r\n` embebido en
   texto libre (`sybase_tsql_wrapper.py`) — commit `25976e0`.
3. **Tabs incrustados en texto libre desalineaban columnas** (`_realign_overflow_values` nuevo en
   `execute_all.py`) — commit `182ba2c`.
4. **`extract_engine_message` confundia comillas de negocio con mensaje de motor** (`"CON"` de
   `F.CONJUNTA "CON" J.ALARCON` se tomaba como mensaje_debug falso) — commit `df587d1`.

Todo verificado contra Sybase real (cuenta 5005047292, 239 firmantes, incluye las filas con texto
multilinea/tabs/comillas que disparaban cada bug) antes de comitear, con regresion en cuentas sin
el problema. Nada de esto quedaba abierto: no se requiere accion adicional sobre este SP.

## Causa raiz

El motor (`execute_all.py`) solo captura resultsets del SP cuando:
- `CONFIG` declara `| sp_output_mode | result_sets |`
- El DICCIONARIO SP-REST usa la sintaxis `result_set[0].campo` / `result_set[1].campo` en la
  columna "Variable SP" (regex `result_set[N].` en `parse_result_sets`).

El agente-04 genero el diccionario de este SP con prefijos legibles `RS1.` / `RS2.` (no
`result_set[0].`/`result_set[1].`), y el CONFIG no tiene la fila `sp_output_mode`. Sin esa notacion
el motor cae al modo default `output_params`, no captura RS1/RS2, y compara esos campos como vacios
contra el REST (que si trae dato) -> INCONSISTENCIA en los 9 TCs.

El SP hermano `pa_fir_consulta_firmante` (mismo patron solo-lectura RS1+RS2) SI usa la notacion
correcta -- usarlo de referencia.

## Que falta hacer

En `.claude/docs-qa/inputs/documents/pa_fir_consulta_con_especial/auto/qa_casos_prueba.md`:

1. Agregar en `## CONFIG`: `| sp_output_mode | result_sets |`
2. En `## DICCIONARIO SP-REST`, renombrar columna "Variable SP":
   - `RS1.registros` -> `result_set[0].registros`
   - `RS1.mensaje` -> `result_set[0].mensaje`
   - Las 14 columnas de `RS2.<campo>` -> `result_set[1].<campo>`
3. Volver a correr el agente-qa-auto-05-matrix-flow (corrida completa) y confirmar que el veredicto
   automatico pasa a `EQUIVALENTE` en los 9 TCs (ya se verifico manualmente que el dato es correcto).

## Notas adicionales de la corrida (contexto, no bloqueantes)

- Se agregaron a `/etc/hosts` (con backup en `/etc/hosts.bak-ncbe1174`) las 2 entradas DNS que
  faltaban para este SP (REST + gRPC -> `172.16.6.107`); los demas servicios del lote-03 ya las
  tenian. Verificado con `curl --resolve` antes de aplicar.
- gRPC no quedo capturado por el motor dentro de la corrida en lote (gap de propagacion de metadata
  `grpc_proto_path` entre `QA-LOTE-*.json` y el archivo final) -- se verifico manualmente para TC01 y
  TC02 (identico a REST), no para los 9. Revisar si persiste tras el fix de arriba.
- Gap de tooling mas general: `run_qa.py`/`execute_all.py` asumen que el documento de casos y el
  codigo del microservicio viven en el mismo repo (derivan `repo_root` del `cwd`). En este modelo
  (doc en el repo QA centralizado, codigo en el repo del micro) hubo que puentear el documento a un
  scratch gitignored dentro del repo del micro. Posible mejora futura: flag explicito
  `--repo-root`/`--doc-path` en ambos scripts.

# Registro consolidado — fixes al motor QA (sesion agosto 2026)

Lista cronologica de TODOS los defectos reales encontrados y corregidos en los scripts compartidos
del pipeline QA (`scripts/auto/*.py` + `sybase_tsql_wrapper.py`) durante esta sesion, con su commit,
causa raiz y verificacion. Sirve de referencia rapida para no repetir diagnostico si el sintoma
reaparece en otro SP.

## Corregidos (23)

1. **`ee7bd65`** — `discover_data.py`/`execute_all.py` calculaban mal la ruta de
   `sybase_tsql_wrapper.py` (apuntaban a `.claude/scripts/`, que nunca existio, en vez de
   `.claude/docs-qa/inputs/scripts/`). El discovery del agente-01 fallaba SIEMPRE con "No se
   encontro sybase_tsql_wrapper.py". Fix: busqueda con verificacion de existencia (mismo patron que
   ya usaba `run_qa.py`).

2. **`25976e0`** — `sybase_tsql_wrapper.py::_execute_raw` hacia `.strip()` a cada linea fisica del
   raw de tsql. Cuando un campo de texto libre con `\r\n` embebido fragmentaba una fila justo en el
   separador de tab hacia la columna siguiente, ese `.strip()` borraba el tab -> filas
   desalineadas/corridas. Detectado en `pa_fir_consulta_con_especial` (SP con 239 firmantes reales
   contaba 292 o 219 segun el intento). Fix: preservar la linea cruda, `.strip()` solo para filtrado.

3. **`182ba2c`** — `execute_all.py::parse_result_sets`: cuando una columna de texto libre tenia
   TABS incrustados (no saltos de linea), el `split('\t')` generaba celdas de mas -> `zip()`
   desalineaba todo lo posterior. Fix: `_realign_overflow_values()` reancla desde ambos extremos
   usando la ultima columna `contenido` del diccionario como sumidero del sobrante.

4. **`df587d1`** — `execute_all.py::extract_engine_message`: el fallback de comillas sueltas
   confundia comillas literales de texto libre de negocio (ej. `F.CONJUNTA "CON" J.ALARCON`) con un
   mensaje de motor Sybase. Fix: el fallback de comillas solo se aplica linea por linea, excluyendo
   lineas con tab (las filas de resultset tabular siempre tienen tabs; un mensaje genuino de motor
   es texto suelto sin tabs).

5. **`67e1de1`** — `validate_external_tc.py`: banco entrego un `.md` con BOM UTF-8 (guardado desde
   editor Windows). El BOM quedaba como primer caracter del contenido y rompia el regex del
   encabezado (`^# Casos de Prueba...`) aunque el texto visible fuera correcto -> FAIL de formato
   falso. Detectado en `sp_cnb_consulta_saldo`. Fix: `encoding='utf-8-sig'` en la lectura (no-op si
   no hay BOM).

6. **`2a08d0a`** — `parse_test_cases.py::build_parametros_entrada`: banco a veces resume en la
   tabla de parametros del TC solo los campos que varian (fila libre `parametros_override` que el
   parser no interpretaba). El resto de los parametros del SP (incluso obligatorios sin default)
   solo quedaban en el bloque SQL "Plantilla de ejecucion del SP" -> nunca llegaban a
   `parametros_entrada` -> el EXEC real fallaba con "expects parameter X, not supplied" (return -6).
   Detectado en `sp_cnb_consulta_saldo` (11 de 28 parametros reales cubiertos). Fix:
   `extract_exec_template_params()` lee el bloque EXEC completo de cada TC como capa intermedia
   entre `defaults` y la tabla explicita.

7. **`bc21658`** — `run_qa.py::_extract_signature_output_params`: whitelist de tipos primitivos +
   el UDT `descripcion`, pero no `mensaje` -- lo descartaba silenciosamente. `sp_cnb_consulta_saldo`
   declara `@o_msg mensaje OUT`. Fix: agregado al mismo fallback `varchar(255)` (verificado en
   Sybase systypes: `mensaje` es VARCHAR real, length 240-255 segun BD).

8. **`115327f`** — `parse_test_cases.py::extract_exec_template_params`: algunos TCs (escenarios
   `supuesto_controlado` que preparan datos antes de invocar el SP, ej. TC05 de
   `sp_cnb_consulta_saldo`) escriben la plantilla como un guion T-SQL completo con variables locales
   `@v_x` referenciadas en el EXEC (`@e_tarjeta = @v_tarjeta_tc05`) en vez de literal directo. El fix
   anterior (#6) las tomaba como si fueran parametros del SP -> EXEC con parametros inexistentes ->
   return -6. Fix: acotar el escaneo a la linea EXEC en adelante + resolver referencias `@v_x` contra
   sus asignaciones literales previas en el mismo guion.

9. **`2cc2344`** — `run_qa.py::_extract_signature_output_params`: exigia que el NOMBRE del
   parametro empezara con `o_` para reconocerlo como output. `pa_cc_cval_catcctecnb` (y toda la
   familia `cval_*` del lote 4: `pa_cc_cval_ahovi_cnb`, `pa_cc_cval_cctecnb`, `pa_cp_cval_ctacnb`,
   mas `pa_cash_tbeneficio_rol`) declara sus outputs como `@s_cuenta`/`@s_msg`/etc (prefijo `s_`, no
   `o_`) -> 0 output params extraidos -> el EXEC nunca los seleccionaba. Fix: deteccion por la
   palabra clave T-SQL `OUT`/`OUTPUT` al final de la declaracion, no por convencion de nombre.
   Regresion verificada contra 31 SPs reales de lote-03/lote-04, sin cambios en los que ya
   funcionaban.

10. **`d43c13d`** — `execute_all.py::exec_sp`: bug gemelo del #9. El filtro que excluye los output
    params de la lista de VALORES LITERALES del EXEC seguia usando `key.startswith('o_')`. Con
    `@s_cuenta`/`@s_msg` (prefijo `s_`), quedaban en `params` como si fueran inputs normales -> el
    EXEC los mandaba DUPLICADOS (una vez como literal `@s_cuenta=''`, otra como binding
    `@s_cuenta=@s_cuenta OUTPUT`) -> el parametro nombrado duplicado rompe el write-back de Sybase ->
    el valor siempre volvia NULL aunque el SP si lo devuelve (verificado: EXEC sin el duplicado
    coincide exacto con el valor real de REST). Fix: excluir tambien cualquier `key` presente en
    `output_params` (lista ya detectada por el fix #9), superset seguro del chequeo por prefijo.

    **Regresion propia + enmienda (`ce00cb5`):** la implementacion original de este fix asumio
    `output_params` como lista de dicts (`p.get('nombre')`), pero la forma REAL que `exec_sp` recibe
    (producida por `get_output_params()`, lineas 1568-1579) es SIEMPRE una lista de tuplas
    `(nombre, tipo)` -- confirmado por el resto de la misma funcion, que ya la desempaqueta asi
    (`for name, tipo in output_params`). Llamar `.get()` sobre una tupla lanza `AttributeError` ->
    `exec_sp` crasheaba para CUALQUIER SP con output params (no solo `pa_cc_cval_catcctecnb`),
    capturado aguas arriba como `INFRA_ERROR` en los 6 TCs de la corrida de verificacion. La prueba
    sintetica previa al commit uso dicts armados a mano en vez de replicar la forma real que produce
    `get_output_params()` -- por eso no lo detecto antes de comitear. Enmienda:
    `{name for name, _ in (output_params or []) if name}` (mismo desempaquetado que el resto de la
    funcion). Verificado con tuplas reales, lista vacia y `None`: no crashea. Leccion para futuros
    fixes similares: probar contra la forma real que devuelve la funcion productora del dato, no una
    reconstruida a mano con una forma asumida.

11. **`bb17786`** — `execute_all.py::compare_grpc_vs_rest`: bug recurrente (3 SPs de esta sesion:
    `pa_fir_consulta_con_especial`, `sp_cnb_consulta_saldo`, `pa_cc_cval_catcctecnb`) -- el
    diccionario declara la columna "Campo gRPC" PLANA (ej. `sCuenta`) aunque "Campo REST" SI tenga
    el envelope anidado (`data.sCuenta`). La respuesta real de gRPC anida igual que REST, asi que la
    busqueda plana siempre daba None -> `INCONSISTENCIA` falsa (SP=REST=gRPC en realidad, solo el
    comparador leia el campo en el nivel equivocado). En `pa_fir_consulta_con_especial` se habia
    corregido a nivel de DOCUMENTO (agregar el prefijo en el diccionario); dado que se repitio 2
    veces mas, el fix ahora es a nivel de CODIGO (beneficia a cualquier SP presente o futuro, sin
    depender de que agente-04 declare el prefijo bien siempre). Fix: `_resolve_grpc_value()` intenta
    primero el path declarado tal cual; solo si eso da None Y `grpc_field` es plano Y `rest_path` es
    anidado, reintenta con el mismo prefijo de `rest_path`. Seguro por diseño: una omision legitima
    de proto3 sigue resolviendo a None (mismo hop final), no se enmascara ninguna divergencia real.
    Verificado con 5 casos sinteticos (incluye confirmar que una divergencia real SI se sigue
    detectando).

12. **(sin commitear aun, 2026-08-25)** — `execute_all.py::compute_sp_veredicto`: cuando el
    DICCIONARIO marca `return_code` como el campo `exacta-veredicto` (patron ahndc/pa_*/cont_impuesto,
    incl. `sp_cnb_consulta_saldo`), `effective_expected` tomaba `expected_o_error` SIEMPRE que el TC
    lo declarara no-None, sin importar que el veredicto real fuera return_code -> comparaba
    `effective_result` (return_code real, ej. 0) contra un valor de negocio documentado en OTRO campo
    (ej. `o_cod_respuesta=41033` via `result_field`), nunca contra `expected_rc`. Detectado en
    `sp_cnb_consulta_saldo` TC11 y TC25 (corrida completa NCBE-1169, 2026-08-25): ambos ejecutaron
    EXACTO lo esperado (`return_code=0`, `o_cod_respuesta=41033`) pero el motor los marco
    `SYBASE_FAIL` (`justification: "SP o_error=None return=0 (esperado=41033)"` -- buscaba un campo
    literal `o_error` que no existe en el output, en vez de resolver `result_field`). Fix:
    `effective_expected` ahora se calcula DENTRO de cada rama de `veredicto_var` (antes se
    recalculaba una sola vez al final, pisando lo que la rama `return_code` ya habia decidido) --
    cuando `veredicto_var == 'return_code'`, usa siempre `expected_rc`; los otros 2 patrones (campo
    de negocio explicito, y legado sin diccionario) quedan exactamente igual. Verificado con los
    datos reales de TC11/TC25 (pasa a SYBASE_OK), con TC09 (return_code real 43004 != esperado 0,
    sigue SYBASE_FAIL -- el fix no enmascara fallos reales), y con regresion completa: 380 tests
    preexistentes + 4 nuevos en `tests/test_compute_sp_veredicto_return_code_ncbe1169.py`, todos
    pasando (384/384). Ningun test existente ejercitaba la rama `veredicto_var == 'return_code'`
    combinada con `expected_o_error` no-None, por eso el bug no se habia detectado antes.

13. **(sin commitear aun, 2026-08-26)** — `execute_all.py`: nueva funcion
    `regenerar_session_id_si_aplica()` + config `SESSION_ID_REGENERATE_ALLOWLIST` (opt-in por SP,
    mismo patron que `SANDBOX_ALLOWLIST`). Causa real (confirmada en logs del pod OpenShift,
    `sp_cnb_consulta_saldo`): el motor ejecuta el mismo flujo 3 veces por TC (SP directo, REST,
    gRPC) con el MISMO `@e_ssn` literal del documento. Cuando el SP usa ese ssn como llave LITERAL
    de un INSERT sin regenerarlo via `sp_gen_sec` (`sp_cont_impuesto.sql` -> `cc_tran_servicio`/
    `ah_tran_servicio`), la 2a y 3a ejecucion SIEMPRE chocan contra la llave unica que la 1a ya
    inserto -> `InsercionTranServicioException` en el micro, sin `@ExceptionHandler` especifico ->
    HTTP 500 generico en REST / error interno en gRPC (confirmado via `oc logs`, stacktrace real).
    NO es un defecto de la migracion (el SP legacy tiene la MISMA regla: un ssn = una transaccion;
    el Java migrado replica esto fielmente) -- es un artefacto de que la metodologia de comparacion
    reusa el mismo dato de sesion en los 3 canales. Fix: para SPs en la allowlist, regenerar el
    campo de sesion (verificado libre en Sybase, rango dedicado 500000-599999, distinto entre TCs y
    canales dentro de la misma corrida) justo antes de la llamada REST y de nuevo antes de gRPC. El
    campo de sesion nunca es parte de la comparacion de equivalencia (no vive en ningun DICCIONARIO
    SP-REST), asi que esto no afecta ningun veredicto. SPs ausentes de la allowlist: comportamiento
    identico al anterior (cero riesgo para el resto de los ~500 SPs). Verificado: 11 tests nuevos
    (`tests/test_session_id_regenerate_ncbe1169.py`) + prueba real contra Sybase (dos llamadas
    consecutivas para `sp_cnb_consulta_saldo` devuelven valores distintos, ambos verificados libres;
    un SP no listado queda intacto). 395/395 tests totales pasando.

    **Addendum (TC19, mismo dia):** tercera tabla con el mismo patron, descubierta al investigar
    por que TC19 seguia fallando (`124020`, "ERROR AL INSERTAR ORDEN DE RECAUDACION") tras el fix
    de arriba. `sp_cnb_pago_comision` TAMBIEN llama a `pa_cc_iinfo_cnb` para CUALQUIER TC con
    `@e_canal='CNB'` (a diferencia de `sp_cont_impuesto`, esta NO depende de si hay comision) --
    inserta en `cob_cuentas..cc_t_informacion_cnb` con `ic_secuencial=@e_ssn`, mismo patron de
    colision. Confirmado en Sybase: `ic_secuencial=100043` (ssn literal de TC19, nunca refrescado
    porque `refresh_ssn.py` solo chequeaba las 2 tablas de arriba) ya tenia fila de una corrida
    anterior. Agregada la 3a tabla tanto a `SESSION_ID_REGENERATE_ALLOWLIST['checks']` (motor)
    como al chequeo de `refresh_ssn.py` (SP-especifico, ver `auto/refresh_ssn.py`). 395/395 tests
    siguen pasando (solo se agrego dato de config, no logica nueva).

14. **(sin commitear aun, 2026-08-26)** — `execute_all.py`: emision CONDICIONAL del namespace
    `resultado_ejecucion.diagnostico_motor` (los campos `mensaje_debug` y `engine_exception`).
    **Causa:** `mensaje_debug`/`engine_exception` son diagnostico INTERNO del motor (eco crudo del
    canal raiserror/print de Sybase + excepcion SQL nativa estructurada), NO output params del SP.
    El motor los escribia SIEMPRE, para CUALQUIER SP, en cada TC del JSON de salida
    (`QA-CASOS-PARSEADOS.json`), sin mirar si el DICCIONARIO SP-REST del SP declaraba una fila para
    ellos. Ejemplo real del defecto: `pa_cp_cval_ctacnb` (SP que NO declara `mensaje_debug` en su
    diccionario) tiene en su corrida canonica `pa_cp_cval_ctacnb-25-08-2026-1429-AGENT05` un
    `diagnostico_motor` en los 16 TCs, con basura tipo `mensaje_debug: '(return status = 0)'`. Esto
    es distinto de la logica `IGNORAR` (que solo excluye una fila de la COMPARACION de equivalencia,
    no de la SALIDA). **Cambio exacto:** (a) nueva funcion `diccionario_declara_mensaje_debug(doc_path)`
    que escanea la seccion DICCIONARIO SP-REST cruda y devuelve True si existe una fila cuya
    "Variable SP" es `mensaje_debug` (con o sin `@`), CUALQUIERA sea su Comparacion -- INCLUIDO
    IGNORAR (deteccion estructural, no de comparacion; por eso no se reusa `parse_diccionario_sp_rest`,
    que descarta las filas IGNORAR); (b) en `main()` se computa una vez `declara_mensaje_debug` a
    partir de `casos_path`; (c) en los DOS call sites que arman `resultado_ejecucion` (camino sandbox
    y camino legacy) la clave `diagnostico_motor` se incluye por dict-unpacking condicional
    (`**({'diagnostico_motor': build_diagnostico_motor(sp_result)} if declara_mensaje_debug else {})`).
    `build_diagnostico_motor()` NO se toco (retrocompatible; los tests que lo llaman con un solo arg
    siguen verdes). Cuando el SP declara la fila, el JSON queda IDENTICO a antes; cuando no la
    declara, el namespace se omite por completo. **Generico:** decide por el nombre de la variable
    en el diccionario del SP, sin hardcodear ningun SP. **Verificacion con documentos/SPs reales:**
    `diccionario_declara_mensaje_debug()` clasifica correctamente los 8 SPs que SI declaran la fila
    (sp_debcred_empresa, pa_fir_consulta_con_especial, pa_fir_consulta_fir_especial,
    cpas-mso-tr-depositos-rc, sp_ah_depositosl_rc, sp_ah_retiro_rc, pa_pag_brpt_billetes_altadeno,
    sp_retefec_transval_rc -> True) y los que NO (pa_cc_cval_catcctecnb, sp_cnb_consulta_saldo,
    pa_cp_cval_ctacnb, pa_fir_consulta_condicion, pa_fir_consulta_firmante, sp_cont_impuesto,
    sp_ahndc_automatica -> False). Simulacion de la expresion EXACTA de los call sites sobre un
    `sp_result` con `mensaje_debug` capturado: SP sin fila (pa_cc_cval_catcctecnb) -> `resultado_ejecucion`
    keys `['sp_output','justification']`, sin `diagnostico_motor`; SP con fila (sp_debcred_empresa) ->
    `diagnostico_motor` presente e identico al anterior. La fase REST no se ve afectada (lee
    `diagnostico_motor.mensaje_debug` con `.get(..,{}).get(..)` -> None cuando ausente, y
    `compare_sp_rest_params` solo compara filas declaradas en el diccionario). Regresion: suite
    completa 395/395 preexistentes + 11 nuevos en
    `tests/test_diagnostico_motor_conditional_ncbe1340.py` -> 406/406 pasando. Nota: el item que
    estaba en "Documentados, PENDIENTES" sobre `mensaje_debug` en `pa_cc_cval_catcctecnb` queda
    resuelto: al quitarse la fila del diccionario de ese SP (NCBE-1340), este fix garantiza que el
    campo tampoco aparezca en la salida de una corrida nueva.

15. **(sin commitear aun, 2026-09-04)** — `parse_test_cases.py::extract_exec_template_params`:
    nueva funcion auxiliar `_split_top_level_assignments()` para soportar VARIAS asignaciones
    `@nombre = valor` separadas por coma en la MISMA linea fisica del bloque EXEC. **Causa real**
    (detectada en `sp_direccion_dml`, NCBE-1815, al correr agente-05): el documento de este SP
    escribe 3 parametros por linea (`@s_ssn = 500001, @s_user = 'QATESTER', @s_term = 'QATERM01',`),
    pero el loop historico asumia una asignacion por linea completa
    (`_PARAM_ASSIGNMENT_LOOSE_RE = r'^\s*@(\w+)\s*=\s*(.+?)\s*$'`) -- con varias por linea, todo lo
    que seguia al primer `=` (incluido el resto de asignaciones de esa linea) quedaba como "valor"
    del primer parametro, nunca matcheaba ninguna forma literal reconocida -> `unparseable` ->
    gate fail-closed `PARAM_PARSE_INCOMPLETE` bloqueaba el TC completo. Afecto a **68 de los 77
    TCs** de este SP (los 9 restantes, sin seccion Plantilla, no entraban a esta funcion y por eso
    quedaban en `PENDIENTE_EJECUCION` en vez de `BLOCKED_DATOS` -- la corrida completa de agente-05
    dio 0/77 con veredicto real). **Fix:** si una linea trae mas de una `@nombre=` (detectado por
    conteo de matches de `@\w+\s*=` en la linea) se divide en fragmentos por coma FUERA de comillas
    simples (una comilla puede contener una coma en un valor de negocio real, ej. una descripcion;
    la funcion tokeniza caracter por caracter respetando comillas escapadas `''`); cada fragmento
    se procesa con la MISMA logica de siempre (match, `_parse_param_value_with_comment`, tracking de
    `unparseable`, exclusion de output params `o_*`, resolucion de referencias `@var` locales). Se
    tolera tambien un comentario SQL inline que quede como PREFIJO de un fragmento (cuando el
    comentario del parametro anterior cae despues de la coma-separadora, antes del siguiente
    `@nombre=` -- comun en overrides tipo `@x = 'N',  -- nota\n@y = 'N',`), descartandolo antes de
    matchear. El condicional `n_assignments > 1` garantiza que una linea con exactamente UNA
    asignacion (el formato de los ~500 SPs existentes) siga el mismo camino de codigo que antes de
    este fix, byte-identico. Verificado: 12 tests nuevos en
    `tests/test_extract_exec_template_params_multiparam_ncbe1815.py` (incluye comilla-con-coma-
    dentro, comentario-con-parentesis-entre-parametros, valor-invalido-en-linea-multiparametro-no-
    bloquea-a-los-demas-de-la-misma-linea, y compatibilidad-formato-historico) + suite completa
    505 preexistentes -> **517/518 pasando** (la unica falla, `test_tc44_pre_has_executable_insert_
    re_aut_monto`, es preexistente y de un documento distinto editado por otra sesion en paralelo,
    no relacionada con este cambio). Verificado tambien end-to-end contra el documento real de
    `sp_direccion_dml`: los 77 TCs pasan de 0 `[WARN] unparseable` a todos con su set completo de
    parametros (TC01 paso de bloqueado a 35/35 parametros resueltos).

16. **(sin commitear aun, 2026-09-04)** — `parse_test_cases.py::get_sp_defaults`: gate
    `is_literal_value()` faltante antes de aceptar una fila de la tabla "PARAMETROS DE SESION POR
    DEFECTO" como default. **Causa real** (detectada en `sp_direccion_dml`, NCBE-1815, misma
    corrida que destapo el fix #15 -- una vez resuelto ese, esta corrida real revelo un segundo
    bloqueador distinto): de las 3 capas de `build_parametros_entrada` (defaults / exec_template_
    params / params_raw), las otras 2 YA filtran cada valor con `is_literal_value()` antes de
    aceptarlo (fail-closed); `get_sp_defaults` era la UNICA que tomaba CUALQUIER celda de esa tabla
    como valor literal, sin filtro. Banco a veces reusa esa fila para una nota descriptiva en vez
    de un default real -- ej. `| **@i_direccion** | (no aplica en Alta) |` (el parametro solo
    aplica en Update/Delete/Delete_E, que lo declaran explicito en su propia tabla por-TC). Sin el
    gate, ese texto se propagaba como default GLOBAL para los 33 TCs de Alta que no lo sobre-
    escriben, y `execute_all.py::exec_sp` lo pasaba tal cual a Sybase -> `Implicit conversion from
    datatype 'VARCHAR' to 'TINYINT' is not allowed` (return -6) en el 100% de ellos -- confirmado
    en la corrida real (33/33 SYBASE_FAIL con ese mensaje exacto), aunque el SP declara su propio
    default seguro de omitir (`@i_direccion tinyint = null`, verificado en el `.sql` real). **Fix:**
    mismo gate que las otras 2 capas -- `if is_literal_value(raw_value): defaults[name] = ...`
    (antes sin condicional). Una fila no-literal simplemente NO aporta default (nunca bloquea el
    TC por si sola -- a diferencia de las otras 2 capas, que si registran `unparseable`; aqui
    "sin default" significa "usa el default del SP", que es exactamente lo correcto cuando el
    parametro "no aplica"). Verificado: 6 tests nuevos en
    `tests/test_get_sp_defaults_literal_gate_ncbe1815.py` (nota descriptiva no se toma como
    default / string y NULL y numero validos si se toman / prosa arbitraria no bloquea otros
    defaults de la misma tabla / un TC que SI declara el parametro explicito lo recibe igual,
    capa `params_raw` independiente) + suite completa 517 preexistentes -> **523/524 pasando**
    (misma unica falla preexistente y no relacionada de siempre). Verificado end-to-end contra el
    documento real: TC01 (Alta) ya NO incluye `i_direccion` en `parametros_entrada` (usa el
    default del SP); TC59 (Update, override explicito) sigue recibiendo `i_direccion=1` intacto.

17. **(sin commitear aun, 2026-09-04)** — `parse_test_cases.py::parse_tc_block`: los regex de
    header PRE/POST (usados por `extract_sql_block`) exigian un guion + texto descriptivo
    (`**PRE — Estado requerido en BD:**` / `**POST — <texto>:**`). **Causa real** (misma corrida
    de `sp_direccion_dml`, NCBE-1815, que destapo los fixes #15/#16 -- este es el TERCER
    bloqueador distinto revelado por la MISMA corrida real, una vez resueltos los otros dos): el
    documento de este SP usa la forma CORTA `**PRE:**`/`**POST:**` (sin guion) en **63/77 y
    72/77 TCs** respectivamente -- ninguno de los dos regex la reconocia, `extract_sql_block`
    devolvia `[]` en silencio (sin error, sin WARN) para la enorme mayoria de los TCs. Esto
    significa que la mutacion de PRE (recreacion idempotente de datos consumidos por corridas
    previas) y la restauracion de POST NUNCA se ejecutaban en la matriz real para esos TCs --
    root cause DOMINANTE detras de gran parte de los `SYBASE_FAIL` de la corrida real (confirmado
    en vivo para TC69/70/71/72: `precondiciones_sql` era `[]` con el motor viejo, aunque el
    documento SI tenia SQL real y correcto en esos bloques). Mismo patron del fix NCBE-1655
    (2026-08-20, ver items previos de este registro) que ya habia tolerado variantes de texto para
    POST y una anotacion parentetica para PRE, pero ninguno de los dos toleraba la ausencia TOTAL
    del guion+texto. **Fix:** el guion + texto descriptivo ahora es un grupo OPCIONAL completo en
    AMBOS regex (`\*\*PRE\s*(?:[—–-]\s*.*?)?\s*:\*\*` / `\*\*POST\s*(?:[—–-]\s*.*?)?\s*:\*\*`) --
    superset estricto de lo que ya matcheaba (nunca deja de reconocer una variante que antes si
    reconocia), y ahora TAMBIEN reconoce la forma corta sin guion. Verificado: 6 tests nuevos en
    `tests/test_pre_post_header_forma_corta_ncbe1815.py` (forma corta / las 3 variantes largas ya
    soportadas siguen funcionando) + suite completa 523 preexistentes -> **529/530 pasando**
    (misma unica falla preexistente de siempre). Verificado end-to-end: TC01/TC69/TC71 pasan de
    `precondiciones_sql=[]` a extraer su SQL real completo con el documento sin cambios.

    **Nota operativa (no es un fix del motor, es limpieza del documento de este SP):** una vez que
    el PRE de TC67/68/69/70/71/72 empezo a ejecutarse de verdad gracias a este fix, se detecto que
    el patron `IF NOT EXISTS (...) INSERT ...` que esos TCs usaban para la recreacion idempotente
    NUNCA se ejecuta como una unidad -- `_split_plain_sql` no reconoce `IF` como inicio de sentencia
    (no esta en `_SQL_KEYWORDS`), asi que la linea `IF NOT EXISTS(...)` queda pegada como
    continuacion del `SELECT` de verificacion anterior (ese `SELECT` combinado se descarta por no
    tener alias `AS`), y el `INSERT` que sigue queda suelto y SI se ejecuta, pero SIN la guarda
    condicional. Verificado en Sybase real que esto es seguro para estos 6 TCs especificos (el
    propio SP borra la fila en cada fase, por lo que un INSERT incondicional nunca choca con una
    fila ya existente) -- se simplifico el documento quitando la linea `IF NOT EXISTS` (ya inerte)
    y dejando el `INSERT` incondicional, con un comentario que documenta por que es seguro. No se
    modifico el motor para este caso (el patron `IF/INSERT` no aparece en ningun otro SP de esta
    sesion); si reaparece en otro documento, evaluar entonces si amerita ensenarle a
    `_split_plain_sql`/`execute_mutants_and_dynamic` a reconocer bloques `IF EXISTS/NOT EXISTS`
    como unidad atomica (mismo patron que ya existe para `-- ATOMIC-BEGIN/END`).

18. **(sin commitear aun, 2026-09-04)** — `run_qa.py::_extract_signature_output_params`: la
    reparacion de saltos de linea (`repaired = re.sub(r'(?<=[^\s\n])\n(?=[^\s\n])', '', sig_block)`)
    colapsaba tambien el salto de linea LEGITIMO entre el comentario final de un parametro y el
    `@` del SIGUIENTE parametro. **Causa real** (CUARTO bloqueador distinto revelado por la MISMA
    corrida real de `sp_direccion_dml`, NCBE-1815 -- misma clase de causa raiz "orden de
    operaciones en regex" que los fixes #15/#17): el proposito original de esa reparacion es
    rejuntar una palabra/comentario partido a mitad de linea SIN espacio (ej. `'varcha\nr(255)'`
    o `'-\n-Ref029'`), pero la firma real de `sp_direccion_dml` tiene un comentario final que
    queda pegado sin espacio al `@` del parametro siguiente (`'...--ref26 anio de la solicitud
    vreferen\n@o_direccion\t\ttinyint...'`) -- la reparacion colapsaba ESE salto tambien, y el
    strip de comentarios `--[^\n]*` (que se detiene en el salto de linea REAL, ya destruido)
    devoraba `@o_direccion`, `@o_msj_error`, `@o_sig_log_svr` (los 3 OUTPUT reales del SP) y
    `@i_canton` -> `_extract_signature_output_params` devolvia `[]` pese a que el SP declara 3 OUT
    reales en su firma (`cobis__sp_direccion_dml.sql` L68-70). Consecuencia en cadena: el EXEC
    generado nunca selecciona los OUTPUT -> el motor termina comparando un `output_params={}`
    vacio contra el REST (que si trae `oDireccion`/`oSigLogSvr` en el body) -> **INCONSISTENCIA
    falsa** en 11/16 de las reportadas en la corrida real (TC01,11,16,26,30,31,32,33,34,35,36).
    **Fix:** excluir `@` de la lookahead de la reparacion
    (`(?<=[^\s\n])\n(?=[^\s\n@])`) -- un salto de linea seguido de `@` NUNCA es una particion real
    de token/comentario (un parametro nuevo siempre arranca fresco en `@`), asi que nunca debe
    colapsarse; los casos que la reparacion SI debe seguir resolviendo (`'varcha\nr(255)'`, etc.)
    no tienen `@` como segundo caracter, asi que la exclusion es segura. Verificado: 5 tests
    nuevos en `tests/test_extract_signature_output_params_comment_swallow_ncbe1815.py` (caso real
    exacto de este SP / comentario pegado sin espacio no devora al siguiente / palabra partida a
    mitad sigue reparandose / varios OUTPUT consecutivos con comentario cada uno / deteccion
    generica por keyword OUT sin prefijo `o_` del fix anterior sigue intacta) + suite completa
    553 preexistentes -> **558/559 pasando** (misma unica falla preexistente de siempre).
    Verificado end-to-end contra el `.sql` real: `_extract_signature_output_params` pasa de `[]`
    a `[o_direccion, o_msj_error, o_sig_log_svr]` con el archivo real sin cambios.

19. **(sin commitear aun, 2026-09-04)** — `execute_all.py::extract_engine_message` (tier 3):
    excluir lineas que sean UNICAMENTE un numero (entero/decimal, signo opcional). **Causa real**
    (QUINTO bloqueador distinto de la MISMA corrida real de `sp_direccion_dml`, NCBE-1815, tras
    resolver los fixes #15-#18): el SP emite `select @o_direccion` (SIN alias) como resultset
    intermedio ANTES del `return` (`cobis__sp_direccion_dml.sql` L944-948) -- confirmado en vivo
    contra Sybase real que tsql renderiza eso como SOLO el numero en su propia linea, sin header,
    sin tabs, sin comillas (ej. `'7'`). El docstring de `extract_engine_message` asumia
    explicitamente que "el unico SELECT en modo `output_params` siempre imprime con tabs, nunca
    dato de negocio suelto" -- premisa FALSA para este SP. Tier 3 (para SPs fuera de
    `result_sets`) capturaba esa linea como `mensaje_debug='7'`, que el motor comparaba contra
    `mensajeDebug=null` de REST (el numero real SI viaja correcto por `o_direccion`/
    `data.oDireccion`, que si coincidia) -> **INCONSISTENCIA falsa en 15/22 no-EQUIVALENTE de la
    corrida real** (TC01,11,16,21,26,27,28,29,30,31,32,33,34,35,36). **Fix:** excluir de tier 3
    cualquier linea que matchee `^-?\d+(?:\.\d+)?$` completo -- un mensaje de motor genuino
    (RAISERROR/PRINT) SIEMPRE es texto/prosa en este codebase (ej. "No existe el canton", "[sp_x]
    mensaje..."), nunca un numero puro aislado; la exclusion es segura porque no descarta ningun
    formato de mensaje real ya visto en ~500 SPs de esta sesion.

20. **(sin commitear aun, 2026-09-04)** — `execute_all.py::_compare_scalar` (comparacion tipo
    `string`/`contenido`): normalizar whitespace INTERNO (`' '.join(x.split())`), no solo bordes
    (`.strip()`). **Causa real** (SEXTO bloqueador de la misma corrida, misma familia que el #19):
    5 TCs con `return=1` reportaban INCONSISTENCIA por `mensaje_debug` pese a ser el MISMO mensaje
    de negocio: lado SP = PRINT crudo del propio SP (`'[sp_direccion_dml] No existe el canton'`,
    1 espacio); lado REST = texto canonico de `cl_errores.json` que trae un **typo real de doble
    espacio** (`'No existe el  canton'`). `.strip()` solo recorta los BORDES de la cadena, nunca
    colapsa espacios repetidos EN MEDIO del texto -> `'No existe el canton' != 'No existe el
    canton'` (visualmente identicos, distintos en memoria). **Fix:** `' '.join(x.split())` en vez
    de `.strip()` para ambos lados antes de comparar -- colapsa cualquier corrida de whitespace
    interno a un solo espacio ademas de recortar bordes; el fallback de "ambos vacios" sigue
    intacto (una cadena vacia produce `''` igual tras el join). Afecto TC09,13,42,45,55 en la
    corrida real (5/22 no-EQUIVALENTE restantes de esa corrida, junto con el fix #19 arriba).

    **Verificacion conjunta de #19 y #20:** 10 tests nuevos en
    `tests/test_mensaje_debug_false_positives_ncbe1815.py` (numero puro entero/decimal/negativo no
    se captura / mensaje real de texto sigue capturandose sin cambio / marcador `(return status`
    sigue excluido / mensaje con numero+texto mezclado no se confunde con numero puro / doble
    espacio interno no dispara diferencia / diferencia real de contenido sigue detectada / ambos
    vacios sigue siendo None / prefijo `[sp_name]` sigue removido antes de comparar) + suite
    completa 558 preexistentes -> **568/569 pasando** (misma unica falla preexistente de siempre,
    no relacionada). Pendiente de verificar end-to-end con una 5ta corrida real (no ejecutada aun
    al momento de escribir esto): expectativa segun el analisis de la corrida anterior es que estos
    2 fixes resuelvan los 20 INCONSISTENCIA restantes -> **75 EQUIVALENTE / 1 NO_EQUIVALENTE
    (TC71, bug real confirmado del micro en delete-con-telefono, HTTP 500 en REST y gRPC) / 1
    SYBASE_FAIL (TC56, precondicion del TC no satisface el requisito real de verificacion
    presencial del SP)** de 77 TCs.

21. **(sin commitear aun, 2026-09-07)** — `execute_all.py::extract_engine_message` (tier 3,
    continuacion del fix #19): generalizar la exclusion a tokens alfanumericos de 1-2 caracteres
    (`re.fullmatch(r'[A-Za-z0-9]{1,2}', s)`), no solo numeros puros. **Causa real** (misma corrida
    real de `sp_direccion_dml`, tras verificar el resultado del fix #19/#20 con una 5ta corrida:
    bajaron 15/20 INCONSISTENCIA como se esperaba, pero persistieron 5 con causa DISTINTA a la
    diagnosticada originalmente -- 3 de ellas, no las 5 originales): el SP TAMBIEN emite `select
    @i_verifdirec` / `select 'N'` (sin alias) como resultset intermedio antes de `return 0`
    (`cobis__sp_direccion_dml.sql` L967-982, ruta `t_trn=110` con `i_verifdirec='S'`) -- mismo
    mecanismo que el numero puro del fix #19, pero con una bandera de negocio de 1 caracter
    ('S'/'N') en vez de un numero. Confirmado real contra Sybase que tsql emite el token solo en
    su propia linea, igual que el numero. Afectaba TC34/TC35/TC36. **Fix:** mismo principio que
    #19 -- un mensaje de motor genuino en este codebase SIEMPRE es una frase CON AL MENOS UN
    ESPACIO; un token alfanumerico corto (1-2 caracteres) sin espacios nunca lo es. Verificado: 2
    tests nuevos (bandera S/N de 1 caracter, token de 2 caracteres tipo 'OK') en el mismo archivo
    `tests/test_mensaje_debug_false_positives_ncbe1815.py` (ahora 12 tests) + suite completa 568
    preexistentes -> **570/571 pasando** (misma unica falla preexistente de siempre).

    **Nota operativa (no es fix de motor, es limpieza de 2 TCs mas del mismo documento):** la
    misma corrida revelo que TC16 y TC32 SI tenian el mismo defecto de "reset via IF/BEGIN/END que
    nunca ejecuta" ya visto en TC01/11/21/26/27/28/29/30/31/67/68/69/70/71/72 -- el diagnostico
    previo los habia atribuido erroneamente a una limitacion de motor ("no comparar secuencias
    autoincrementales"), pero en realidad es el MISMO bug de documento ya conocido: sin el reset,
    cada fase (SP/REST/gRPC) inserta una fila nueva sin limpiar la anterior, y `@o_direccion` sube
    de forma incremental entre fases en vez de mantenerse igual. Se corrigieron ambos con el mismo
    patron (DELETE incondicional por descripcion unica o por tipo, sin `IF`). Ademas se detecto que
    el ente 900002 (TC16, escenario BVA "abajo del maximo de 3") habia perdido su fila T baseline
    en algun momento entre corridas (quedaba solo el D) -- el PRE de TC16 ahora la recrea de forma
    deterministica (borra cualquier T + inserta 1 T baseline fijo) en vez de asumir que ya existe,
    dejando el escenario BVA correcto (2 preexistentes) sin depender del historial de corridas
    anteriores.

22. **(sin commitear aun, 2026-09-08)** — `execute_all.py`: nueva funcion
    `regenerar_ssn_dinamico_si_aplica()` + helper `_max_mas_uno()` + config
    `SP_PARAM_SSN_REGENERATE_ALLOWLIST` (opt-in por SP, mismo patron que
    `SESSION_ID_REGENERATE_ALLOWLIST`/`SANDBOX_ALLOWLIST`, pero aplicado a `params` de la llamada
    SP-directa en vez de al payload REST/gRPC). **Causa real** (`sp_verificacion_acredita`,
    NCBE-1805, TC51-TC60): banco redisenio la plantilla EXEC de estos 10 TCs para evitar que
    `@s_ssn`/`@s_sesn` choquen contra la PK de `cob_giros..cg_tran_servicio` -- en vez de un
    literal fijo, la plantilla calcula `@v_ssn` DINAMICAMENTE contra Sybase antes del EXEC
    (`SELECT @v_ssn = MAX(ts_secuencial) + 1 FROM cob_giros..cg_tran_servicio`), con un fallback
    literal `900001` solo para el caso borde de tabla vacia (`IF @v_ssn IS NULL SELECT @v_ssn =
    900001`). `parse_test_cases.py::extract_exec_template_params` es un parser de TEXTO puro sin
    conexion a Sybase (confirmado leyendo el archivo: ni un import ni una variable `conn` en todo
    el modulo) -- no puede ejecutar ese SELECT durante el parseo. Su logica de `local_vars`
    (lineas ~243-248) escanea TODAS las asignaciones `@nombre = valor` antes del EXEC y solo
    retiene las que son literales (`is_literal_value`); la asignacion dinamica
    (`@v_ssn = MAX(ts_secuencial) + 1`) se descarta correctamente (no es literal), pero el
    fallback (`@v_ssn = 900001`, dentro del `IF ... IS NULL`) SI matchea como literal y, al ser
    la UNICA asignacion de `@v_ssn` que el parser retiene (el bucle sobreescribe sin distinguir
    que viene de una rama condicional), termina siendo el valor que se propaga a
    `params['s_ssn']`/`params['s_sesn']` como si fuera el resultado real -- exactamente la misma
    colision de PK (`Msg 2601, PK_tran_servicio`) que el diseno con `@v_ssn` dinamico buscaba
    evitar. Reproducido de forma acotada contra el documento real (sin tocar nada primero):
    `extract_exec_template_params()` sobre el bloque de TC60 devuelve
    `s_ssn='900001', s_sesn='900001'` literal, confirmando la causa raiz antes de decidir el fix.
    **Decision de fix:** se evaluaron las 2 opciones del enunciado -- (A) ensenarle al extractor a
    ejecutar el SELECT dinamico contra Sybase durante el parseo: descartada, invasiva de verdad
    (requeriria agregarle conexion a Sybase a un modulo que hoy es 100% texto, usado en una etapa
    del pipeline sin conexion disponible) y ademas redundante, porque el propio SP exige
    verificacion de unicidad en tiempo de EJECUCION (la tabla puede tener filas nuevas entre el
    parseo y la corrida real); (B) verificar/regenerar SIEMPRE contra Sybase justo antes del EXEC
    directo, mismo patron ya probado de `SESSION_ID_REGENERATE_ALLOWLIST` (usado para
    `sp_cnb_consulta_saldo`, item #13 de este registro) -- elegida. Diferencia de diseno frente a
    `SESSION_ID_REGENERATE_ALLOWLIST`: ese mecanismo solo regenera el payload REST/gRPC (asume que
    el valor del documento es valido para la 1a fase, y solo previene la reutilizacion entre
    canales); aqui la colision ya existe desde la 1a fase (SP directo) porque el valor parseado es
    directamente el literal incorrecto, asi que el fix opera sobre `params` (la llamada SP-directa)
    ANTES de `exec_sp()`, no sobre el payload. `regenerar_ssn_dinamico_si_aplica()` recalcula el
    MISMO valor que la plantilla real calcularia (`_max_mas_uno()`: `MAX(columna)+1` de la tabla
    configurada, mismo fallback si esta vacia) y lo verifica libre con `_session_id_en_uso()` (la
    MISMA funcion que ya usa el mecanismo de sesion, reutilizada sin cambios); si colisiona,
    incrementa hasta encontrar uno libre. Asigna el mismo valor a TODOS los campos configurados
    (`s_ssn` y `s_sesn`, igual que la plantilla real asigna la misma variable local a ambos
    parametros). Comparte el set `usados_en_esta_corrida` (`_session_id_usados` de `main()`) con
    `SESSION_ID_REGENERATE_ALLOWLIST` -- seguro porque cada invocacion de `execute_all.py` procesa
    un unico `sp_name`, nunca dos SPs de las 2 listas en la misma corrida. Cero cambios en
    `parse_test_cases.py` (0 lineas de diff): el parser sigue devolviendo el literal incorrecto tal
    cual, pero el motor lo sobreescribe antes de usarlo. **Verificado:** 15 tests nuevos en
    `tests/test_ssn_dinamico_regenerate_ncbe1805.py` (incluye
    `test_caso_real_tc60_reemplaza_literal_900001_por_max_mas_uno_dinamico`, que reproduce el
    sintoma exacto con el valor real observado en la corrida manual documentada en el TC,
    `s_ssn_ejecutado=2147465372`) + regresion end-to-end simulando `extract_exec_template_params`
    sobre el bloque real de TC60 seguido de `regenerar_ssn_dinamico_si_aplica`: `params['s_ssn']`
    pasa de `900001` (literal incorrecto) a `2147465372` (dinamico, verificado libre). Regresion de
    no-cambio confirmada por inspeccion de codigo (la funcion es no-op si `sp_name` no esta en
    `SP_PARAM_SSN_REGENERATE_ALLOWLIST`, que solo contiene `sp_verificacion_acredita`) y con una
    prueba explicita contra 5 SPs ya cerrados en esta sesion (`sp_cnb_consulta_saldo`,
    `pa_cc_cval_catcctecnb`, `sp_direccion_dml`, `pa_pag_brpt_billetes_altadeno`,
    `sp_ah_retiro_rc`): para los 5, `regenerar_ssn_dinamico_si_aplica()` retorna `None`, no toca
    `params`, no toca `usados`, y no hace NINGUNA llamada a Sybase (`conn.execute_query` nunca
    invocado). Suite completa: 619 preexistentes + 15 nuevos -> **634/635 pasando** (misma unica
    falla preexistente y no relacionada de siempre, `test_tc44_pre_has_executable_insert_re_aut_
    monto`). Nota de aislamiento: `execute_all.py` tenia actividad concurrente muy alta de otro
    companero al momento de este fix (refactor de higiene POST/finally + comparacion de dataset
    nativo, ~270 lineas sin commitear) -- el commit de este fix se aisló con
    `git apply --cached` sobre un patch de solo mis 2 hunks (94 lineas, 0 borrados) para no mezclar
    ni tocar ese trabajo ajeno sin commitear.

23. **(2026-09-08, mismo dia que #22)** — `execute_all.py`: nueva config
    `SP_PARAM_SSN_REGENERATE_EXCEPTION_TC_IDS` (excepcion por `(sp_name, tc_id)` a
    `SP_PARAM_SSN_REGENERATE_ALLOWLIST` del item #22) + chequeo agregado al inicio de
    `regenerar_ssn_dinamico_si_aplica()`, que ahora recibe `tc_id` como parametro nuevo (firma
    cambio de `(conn, sp_name, params, usados_en_esta_corrida)` a `(conn, sp_name, tc_id, params,
    usados_en_esta_corrida)`; unico call site actualizado, linea ~4753 de `main()`). **Causa real**:
    el fix del item #22 (regenerar `@s_ssn`/`@s_sesn` dinamicamente para TODO TC de
    `sp_verificacion_acredita`) rompia 15 TCs que Banco redisenio EXACTAMENTE para probar la
    colision de PK real e intencional que el item #22 evita -- TC23/24/25/38/63/64/65/66/69/70/71/
    72/94/95/96 (confirmado leyendo
    `ecu-mso-verificacion-acredita/test-cases-banco/casos_prueba_sp_verificacion_acredita.md`: cada
    uno trae un PRE-SENTINELA que garantiza deterministicamente (INSERT idempotente via `IF NOT
    EXISTS`) que ya existe una fila en `cob_giros..cg_tran_servicio` con la llave EXACTA que la
    plantilla EXEC del TC declara como literal (`@s_ssn`, ej. `900001` en TC23, `901170` en otros),
    mas un POST-SENTINELA que la limpia con `DELETE` idempotente despues). Si el motor sobreescribe
    `@s_ssn`/`@s_sesn` con un valor "libre" recalculado, el EXEC usa una llave distinta a la que el
    PRE preparo -- la colision (`Msg 2601, PK_tran_servicio`) nunca ocurre y el PRE del documento
    queda sin efecto, degradando el TC de "colision real verificada" a un falso resultado sin
    relacion con el escenario documentado. TC61/TC62/TC67 tambien fueron redisenados por Banco para
    forzar una colision distinta (`Msg 2615` en `cg_giro_agente`) pero ese mecanismo NO pasa por
    `@s_ssn` -- confirmado que no estan en la excepcion (no las necesitan). **Fix minimo**: set
    `SP_PARAM_SSN_REGENERATE_EXCEPTION_TC_IDS` keyed por `(sp_name, tc_id)` -- mismo patron que
    `SANDBOX_ALLOWLIST` (NCBE-1343, evita que un `tc_id` numerico coincidente de OTRO SP quede
    excluido de la regeneracion por error -- leccion ya aprendida en este mismo archivo). Chequeo
    agregado ANTES de consultar `SP_PARAM_SSN_REGENERATE_ALLOWLIST`: si `(sp_name, tc_id)` esta en
    la excepcion, retorna `None` sin tocar `params` ni `usados_en_esta_corrida` ni llamar a Sybase
    -- 0 cambios de comportamiento para cualquier otro TC/SP. **Verificado:** 9 tests nuevos en
    `tests/test_ssn_dinamico_regenerate_ncbe1805.py` (clase
    `TestRegenerarSsnDinamicoExceptionTcIds`): 1 TC de la excepcion preserva el literal exacto
    (901170) sin llamar a Sybase; los 15 tc_id de la excepcion son no-op uno por uno; un TC del
    mismo SP NO listado (`TC01`) sigue regenerando dinamicamente igual que antes (`_max_mas_uno` +
    verificacion libre); confirma que TC61/62/67 NO estan en la excepcion; confirma que un
    `tc_id='TC23'` de OTRO SP no hereda la excepcion (scoping por SP). Los 11 tests preexistentes
    de este mismo archivo se actualizaron (nueva firma con `tc_id`, usando `'TC01'` como TC neutro
    fuera de la excepcion) y siguen pasando sin cambio de aserciones. Suite completa: **633
    pasando** (20 de este archivo + 613 del resto) + las mismas 7 fallas preexistentes y no
    relacionadas de siempre (contenido del documento de `sp_retefec_transval_rc`, confirmado por
    `git stash` que fallan igual con o sin este fix aplicado -- incluye `test_tc44_pre_has_
    executable_insert_re_aut_monto`, ya documentada en items anteriores, mas 6 fallas nuevas de
    `test_ncbe1178_reconciliation_turno29.py` por edicion reciente y no relacionada del documento
    de ese SP). **Verificacion E2E real contra Sybase (TC23)**: PRE-SENTINELA insertado (confirmado
    `ts_900001_C_pre=1`, baseline previo era 0), `regenerar_ssn_dinamico_si_aplica(conn,
    'sp_verificacion_acredita', 'TC23', params, usados)` devolvio `None` sin mutar `params`
    (`s_ssn`/`s_sesn` se mantuvieron en `'900001'` literal, `usados_en_esta_corrida` sin cambios,
    cero llamadas a `conn.execute_query` desde la funcion), EXEC real del SP contra Sybase devolvio
    `Msg 2601, Level 16, State 1, "Attempt to insert duplicate key row in object 'cg_tran_servicio'
    with unique index 'PK_tran_servicio'"` -- exactamente el resultado esperado documentado para
    TC23. POST-SENTINELA (`DELETE`) ejecutado en `finally`; confirmado `ts_900001_C_post=0` (sin
    residuo). Script de verificacion fue temporal (`/tmp/verify_tc23_e2e.py`), eliminado tras la
    corrida; no forma parte del repo.

## Resuelto por otro compañero (no por mi, mencion informativa)

- **Sandbox allowlist hardcodeado por ID de TC global.** Se habia documentado como pendiente
  (`SANDBOX_ALLOWLIST` matcheaba solo por ID de TC sin scoping por SP, TC02/TC03/TC06 de
  `pa_cc_cval_catcctecnb` caian ahi por coincidencia de nombre). Verificado en la corrida del
  2026-08-21: ya esta re-keyeado a `(sp_name, tc_id)` (commit ajeno, NCBE-1343) -- los TCs de este
  SP ya no entran al sandbox. No requiere accion.

## Documentados, PENDIENTES de corregir (requieren decision/coordinacion)

- (ninguno pendiente por ahora; el item de `mensaje_debug` en `pa_cc_cval_catcctecnb` quedo
  resuelto por el fix #14 + el ajuste del diccionario de ese SP en NCBE-1340.)

## Nota de proceso

Varios de estos fixes se descubrieron en cadena: arreglar uno destapaba el siguiente sintoma
(ej. #2->#3->#4 en la misma corrida de `pa_fir_consulta_con_especial`; #9->#10 en
`pa_cc_cval_catcctecnb`). Cada fix se verifico con datos reales de Sybase (nunca solo con el
sintoma reportado por el motor) antes de comitear, y con regresion contra los SPs ya cerrados de
esta sesion para confirmar cero cambio de comportamiento en lo que ya funcionaba.

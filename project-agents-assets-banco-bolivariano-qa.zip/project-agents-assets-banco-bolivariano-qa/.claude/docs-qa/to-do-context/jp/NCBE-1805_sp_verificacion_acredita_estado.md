# NCBE-1805 — `sp_verificacion_acredita` (micro `ecu-mso-verificacion-acredita`) — Estado

SP `cob_giros.sp_verificacion_acredita`, 152 TCs en el documento de banco
(`.claude/docs-qa/inputs/documents/ecu-mso-verificacion-acredita/test-cases-banco/casos_prueba_cgveacre.md`).

Corridas de hoy (2026-09-03): agente-01 (scaffold + discovery) y agente-02 (validador +
V-DESCIFRADO-01) re-ejecutados desde cero contra el documento vigente. Resultado agente-02:
**49 PASS / 63 FAIL / 6 WARN / 34 NOT_APPLICABLE** sobre 152 TCs.

## PROBLEMA

Los 152 TCs del documento de banco están construidos sobre **datos sintéticos que no existen
en Sybase real**, no sobre datos verificados:

- **Giros inventados `GIRxxxxxx`** (rango `GIR000004`...`GIR999998`): 0 filas en `cg_giro`/`cg_pago`
  para cualquiera de ellos (verificado por conteo). Los giros reales vigentes en el ambiente
  (`2260088110`, `2260088109`, `2260088107`, con `gp_secuencial=1`) no los usa ningún TC.
- **`@i_secuencial` nunca seteado** en ninguno de los 152 TCs (0 coincidencias de
  `@i_secuencial = <n>`). Sin ese parámetro, el SELECT inicial del SP (L214-221,
  `... AND gp_secuencial = @i_secuencial`) recibe NULL, no carga
  beneficiario/monto/moneda, y el SP corta con `RETURN 1` (error 105026) antes de ejercer
  el escenario real que el TC pretende probar. Afecta el 100% de los TCs `op='A'`.
- **Cuentas sintéticas** (`000000000000000001/02/03`) tampoco existen; la cuenta real
  verificada activa es `0000010102` (CTE).
- Como consecuencia, varias ramas de rechazo que los TCs quieren documentar son
  **inalcanzables** con estos datos (ej. TC13/TC14 esperan error 101077 "parámetro no
  existe", pero `MIS/CUPCNE` SÍ existe con `pa_money=10000`; TC11 espera rechazo por
  `bloqueo`, pero el giro sintético nunca carga, así que ni siquiera llega a evaluar el
  bloqueo).
- Hallazgo colateral: dos queries de discovery del propio documento referencian columnas
  inexistentes (`co_bts` en TC52, `gp_comentario_dos` en `cg_pago`) — el documento tiene
  errores de origen, no solo datos ficticios.

**Conclusión: estos 152 TCs, tal como están, no son utilizables para cerrar la matriz de
equivalencia — no ejercen el comportamiento real del SP.**

## SOLUCIONES

- **Opción recomendada:** descartar el lote actual de TCs y pedirle a banco un documento
  corregido, con giros/cuentas reales verificados contra Sybase (usar como referencia los
  reales ya confirmados: giro `2260088110` con `@i_secuencial=1`, cuenta CTE `0000010102`),
  y con `@i_secuencial` explícito en cada TC `op='A'`.
- **Alternativa parcial (ya preparada, no aplicada):** el agente-02 generó propuestas de
  corrección concretas para los 63 FAIL (sustituir giro sintético por `2260088110` +
  `@i_secuencial=1`, courier 108, moneda 1; para `op='V'` usar cuenta real `0000010102`).
  Si se decide no esperar a banco, el agente-03 podría aplicar estas 63 correcciones como
  parche temporal — pero no resuelve los 34 `NOT_APPLICABLE` (requieren forzar
  dependencias/errores no reproducibles solo con lectura: SMS, CONSEP, `sp_promocion`,
  `sp_tr_pago_giro_rc`, etc. — necesitan stub/doble, decisión manual).
- Pendiente de decisión: ¿se corrige localmente (agente-03) mientras se espera a banco, o
  se congela el SP hasta recibir el documento corregido?

## ACTUALIZACIÓN 2026-09-07 — Documento reemplazado, corrida real ejecutada, causa raíz corregida

El documento de 152 TCs de arriba quedó **descartado y eliminado** (commit `9ac1c19`). Banco reenvió
un documento nuevo de **200 TCs** (`casos_prueba_sp_verificacion_acredita.md`, subido en 3 iteraciones
con sufijos `(1)`/`(2)` por upload de GitHub), con datos reales verificados (giros/cuentas reales,
no sintéticos). Se corrigieron 83+2 violaciones de formato/sintaxis, TC51-TC60 fueron rediseñados
por banco (de "forzar colisión de PK" a "ejecución válida con `@v_ssn` dinámico"), se completaron
CONFIG/DICCIONARIO (rutas OpenShift reales verificadas, agregadas a `/etc/hosts`), y 45 TCs más
(TC101-200, antes sin `Resultado esperado`) fueron corregidos por banco y luego reformateados
mecánicamente por nosotros al patrón canónico. Documento cerrado en 200 PASS/0 FAIL/0 WARN (agente-02).

**Corrida real completa ejecutada (200/200 TCs, secuencial):**

| Veredicto | Total |
|---|---|
| EQUIVALENTE | 2 |
| INCONSISTENCIA | 2 |
| NO_EQUIVALENTE | 52 |
| SYBASE_FAIL | 144 |

### Corrección importante sobre los 52 NO_EQUIVALENTE

**Diagnóstico inicial (INCORRECTO):** se reportó como "el micro no puede conectarse a su base de
datos" (HTTP 500 "Error de acceso a base de datos" en REST/gRPC).

**Causa real (confirmada por el equipo de migración, revisando el pod en `bb-dev-core`):** el micro
**sí conecta y autentica** contra Sybase (`172.16.23.22:2030`, base `cob_giros`; pod 1/1 Running, sin
errores de red/login). Los HTTP 500 son **excepciones de autorización de Sybase**: `SELECT/EXECUTE
permission denied` y `Server user id 451 is not a valid user in database ...`. El SP funciona directo
porque Sybase resuelve los accesos internos por *ownership chaining* (permisos del dueño `dbo`); la
librería migrada hace el DML/exec con el login de aplicación del pod (suid 451, resuelto por
framework-seguridad para `id-application=634` / `GIROS spring.sybase.user`), que NO tiene esos GRANTs.

**Solicitud ya escalada al DBA de banco** (login suid 451 en `172.16.23.22:2030`):
- `GRANT SELECT` en `cob_giros..cg_pago`, `cob_giros..cg_giros_veracre`, `cobis..cl_ente`, `cob_cuentas..cc_ctacte`.
- `GRANT EXECUTE` en `cobis..sp_catalogo_consulta`, `cob_giros..sp_actualiza_motivo_nc`.
- Crear cuenta cross-db para ese login en `cob_ahorros` y `cob_virtuales` (+ SELECT sobre `ah_cuenta`/`ah_cuenta_cerrada`, `vi_cuenta`).
- Preventivo: revisar el resto del footprint del SP (`cg_persona`/`cg_giro`/`cg_orden_pago`/`cg_courier`, `cl_moneda`/`cl_cliente`/`cl_det_producto`/`cl_parametro`).
- Referencia: coincide con CASO 2 (Permisos) y CASO 4 (grants COBIS) del `build.log` de la librería.

**Dato de config adicional:** los 3 micros de giros son los únicos en `bb-dev-core` que apuntan a
`172.16.23.22:2030`; el resto de la flota (18/21) usa `172.16.31.91:2050` (SYBASE02, donde QA valida
el SP). Se probó repuntar el micro de giros a SYBASE02 y no arrancó (`JZ00L: Login failed`) — la
credencial de giros solo es válida en `172.16.23.22:2030`. Pendiente confirmación de banco: si giros
debe permanecer en ese ASE (basta con los GRANTs) o alinearse a SYBASE02 (requeriría provisionar la
credencial de giros ahí también).

**Con los GRANTs aplicados, hay que re-ejecutar los 52 TCs sin tocar el pod** — la comparación quedó
inconclusa por permisos, no por divergencias reales del micro.

### Otros hallazgos de la corrida real (pendientes de investigar)

- **INCONSISTENCIA (2, TC73/TC76):** código igual (`0`/`0`) pero `mensaje_debug` diverge — SP trae
  `"pa_money"`, el micro devuelve `null`. Posible mapeo incompleto en el micro.
- **SYBASE_FAIL con causa real — grupo dominante (39 de 47 con resultado esperado declarado):**
  patrón "Error al insertar/grabar log de servicio" en TC40-60 (21, esperaban éxito) + TC23-96 (18,
  esperaban excepción nativa 2601/2615 que el SP atrapó devolviendo RETURN 1 genérico). TC40 usa
  `@s_ssn` único (no colisiona) y falla igual → descarta colisión de secuencial como única causa,
  apunta a una falla sistemática real del SP al insertar el log de servicio en este ambiente.
  **Sin investigar a fondo todavía.**
- 97 TCs sin `Resultado esperado` (TC101-200): resuelto por banco + reformateo mecánico nuestro (ver arriba).

## ACTUALIZACIÓN 2026-09-08/09 — Fixes de motor, colisión intencional, y verificación del bloque 105020

**Corrida 08-sep-2026-2053** (tras reformateo de banco de 97+2 TCs y micro ya sano): 88 EQUIVALENTE /
8 INCONSISTENCIA / 41 NO_EQUIVALENTE / 63 SYBASE_FAIL. Mejora grande vs la corrida del 07-sep (2/2/52/144)
por tres causas distintas: fix de ssn (lado SP), recuperación del micro (ya no crashea con 500 masivo),
y reformateo del documento — no confundir las tres al leer diffs de veredicto.

**Fix de motor #22 (`5374d8f`):** `execute_all.py` regeneraba `900001` literal en vez de resolver
`@v_ssn = MAX(ts_secuencial)+1` dinámico para TC51-60 (el parser de plantillas no puede ejecutar SQL).
Se agregó `SP_PARAM_SSN_REGENERATE_ALLOWLIST` (opt-in por SP) que recalcula y verifica el ssn libre
contra Sybase real antes del EXEC directo. Confirmado sin regresión contra 5 SPs cerrados.

**Hallazgo colateral del fix #22:** rompió 18 TCs que EXISTEN para probar una colisión de PK
intencional (`Msg 2601`/`2615`): TC23-25,38,61-67,69-72,94-96. Como el documento tiene que ser
ejecutable MANUALMENTE por banco (no solo por nuestro motor), la solución no podía vivir solo en el
motor — se rediseñó el documento con PRE/POST-sentinela (inserta la fila colisionante con clave fija
antes del EXEC, la limpia después) para los 18, y se agregó el **fix de motor #23** (`ecf9b32`,
`SP_PARAM_SSN_REGENERATE_EXCEPTION_TC_IDS`) para que esos 15 (de los 18; los otros 3 no dependen de
`@s_ssn`) preserven el literal del documento en vez de regenerarlo. Verificado E2E real contra Sybase
(TC23): el PRE-sentinela + literal preservado producen `Msg 2601` real, reproducible 2 veces seguidas,
sin residuo.

**Corrida 09-sep-2026-0114** (con los 2 fixes de motor aplicados + scaffold regenerado): 88/10/39/63 —
los 18 de colisión SIGUEN en SYBASE_FAIL, pero por un motivo nuevo y distinto: el SP no deja pasar el
`Msg 2601/2615` como excepción cruda sin control — la atrapa y completa con `RETURN 1` (mismo patrón
ya visto en TC102/TC142, "CUENTA BLOQUEADA POR MOVIMIENTO"). **La premisa del `Resultado esperado`
está mal planteada, no el fix.** Propuesta (NO aplicada, pendiente decisión): corregir esos 18 a
`RETURN 1` con el Msg como contexto informativo, no como criterio de veredicto.

### Bloque de 34 TCs con `RETURN 105020` real — VERIFICADO, PROPUESTA LISTA, SIN APLICAR

De los 63 SYBASE_FAIL de la corrida 09-sep, 34 comparten el mismo desenlace real: `RETURN 105020` -
`Msg 105020, Level 16, State 1` - "Error en pago del giro con credito a cta", sin importar qué código
documenta cada uno hoy (varios placeholders: `99999`, `31008`, `367979`, `365656`, `898989`,
`2601 Level 14`, `RETURN 1`, o sin `Resultado esperado` en absoluto).

**TCs:** TC12, TC13, TC105, TC114, TC115, TC116, TC118, TC119, TC120, TC121, TC127, TC128, TC131,
TC132, TC133, TC134, TC136, TC138, TC139, TC140, TC147, TC148, TC149, TC150, TC151, TC152, TC153,
TC154, TC155, TC156, TC159, TC162, TC163, TC164.

Verificado ejecutando cada uno contra Sybase real (SQL exacto de su propia plantilla), sin mutación
detectada en ninguno (0 cambios en `gg_estado` entre PRE/POST, `trancount_after_sp=0` en los 34).

**6 mensajes precursores reales distintos** (el `105020` final es el mismo, la razón de negocio previa
varía por TC):

| Grupo | Precursor real | TCs |
|---|---|---|
| A | `Giro ya cancelado o anulado` | TC12,13,105,115,116,118,119,120,121,127,128,131,132,136,138,140,148 |
| B | `Cedula no corresponde a titular ni alternante` | TC114,150,151,153,154,155,156,159,162,163,164 |
| C | `Remesa pertenece a SPI no procede pago` (367979) | TC133,152 |
| D | `La cuenta de empresa no esta matriculada para pago de remesas` (365656) | TC134,139 |
| E | `Monto no coincide con valor del giro` (898989) | TC149 |
| F | `NO SE PUEDE PAGAR GIRO - PERTENECE A AGENTE PAGADOR SFTP` (105555) + aviso `Msg 266` | TC147 (único) |

**Estado del documento frente a esta propuesta** (26 de 34 necesitan algún ajuste):
- **Ya correctos (8):** TC12, TC105, TC127, TC132, TC136, TC138, TC140, TC148.
- **Solo reformateo, falta la palabra clave `RETURN 105020`, precursor ya correcto (7):** TC114-116,
  TC118-121.
- **Precursor correcto pero afirman "el EXEC falla sin retornar fila" (incorrecto, sí retorna
  `return_code=105020, o_msg=''`) (15):** TC133,134,139,149,150-156,159,162-164.
- **Precursor completamente equivocado, necesita reescritura de fondo (3):** TC13 (dice `2601`),
  TC128 (dice `2601 Level14`+`35000`), TC131 (dice `31008`+`333333`) — ninguno reproduce en la
  ejecución real; los 3 son en realidad Grupo A ("Giro ya cancelado").
- **TC147:** caso único, mismo patrón de "afirma que falla sin retornar" + le falta el aviso `Msg 266`.

**Texto propuesto** (formato canónico, no aplicado): `` `Msg <N>, Level 16, State 1` - `<precursor>`,
seguido de `RETURN 105020` - `Msg 105020, Level 16, State 1` - `Error en pago del giro con credito a
cta`; salida final `return_code=105020`, `o_msg=''` (vacio) (verificado por EXEC 2026-09-10). `` — con
variante para las plantillas sin `SELECT` final (TC105,114-116,118-121) que omite la mención de la fila.

**Nada de esto se ha aplicado al documento todavía** — pendiente de decisión para aplicar junto con
la corrección de los 18 de colisión intencional (RETURN 1).

## Referencias

- Scaffold vigente: `.claude/docs-qa/inputs/documents/ecu-mso-verificacion-acredita/auto/qa_casos_prueba.md`
- Reporte de validación vigente: `.claude/docs-qa/inputs/documents/ecu-mso-verificacion-acredita/auto/tc-validation-report.json`
- Código fuente SP: `/home/ssm-user/lote-06/sybase-local/cob_giros/sp_verificacion_acredita/sps/`
- Corrida real más reciente: `/home/ssm-user/ecu-mso-verificacion-acredita/.claude/docs-qa/results/sp_verificacion_acredita-09-09-2026-0114/`
- Fixes de motor relacionados: items #22 (`5374d8f`) y #23 (`ecf9b32`) en `MOTOR-QA_fixes_sesion_agosto2026.md`.
- Tarea Gestor QA: NCBE-1805, asignada a Juan Pablo Sanabria Moscoso, vencimiento 2026-09-10.

## ACTUALIZACIÓN 2026-09-10 — Los 39 NO_EQUIVALENTE eran DOS problemas distintos, no uno

Al investigar el permiso de INSERT (para ampliar la solicitud al DBA) se descubrió que la hipótesis de
"permisos faltantes" era incorrecta para el grupo dominante. Los 39 NO_EQUIVALENTE se dividen en:

- **34 — colisión de datos de prueba (RESUELTO, ver abajo).** El micro (REST/gRPC) intenta `INSERT`
  en `cob_giros..cg_tran_servicio` con una clave que ya existía de una corrida anterior. Confirmado
  vía `oc logs` del pod: `SQLState 23000` (integridad, NO permisos — 0 coincidencias de "permission
  denied" en 22,475 líneas de log). No es tema del DBA ni de banco ni de migración: es higiene de
  ambiente, resuelto por nosotros.
- **5 — bug real de código en la librería del micro (reportado a migración, pendiente de ellos).**
  `CatalogoConsultaLegacyAdapter` (repo `bb-core-cob-giros-utils`, módulo `sp-verificacion-acredita-utils`)
  lee `return_code` del resultset equivocado al llamar `cobis..sp_catalogo_consulta` (esa SP siempre
  proyecta su propio resultset de negocio antes del `return`, y el adapter toma el primer resultset,
  no el del `return_code`). Causa HTTP 500 en TC26,27,92,144,173 (modo 0, consulta de catálogo).
  Diagnóstico completo con archivo:línea, SQL literal, y 2 propuestas de fix ya entregado a migración
  por chat. Nota aparte: TC92/TC173 tienen inconsistencia en su propia tabla de parámetros del
  documento (dice `'INVALID'`/`'999'`, la plantilla EXEC real usa `'108'`) — no cambia el diagnóstico
  del bug, pero banco debería revisarlo.

### Los 34 de colisión de datos — RESUELTO (limpieza puntual + PRE permanente)

**TCs:** TC40-50 (excepto TC51/TC54, que ya estaban OK), TC52, TC53, TC55-60, TC178, TC179, TC181-193.

**Limpieza puntual aplicada (ya ejecutada, no reversible ni necesario revertir):** se identificaron
26 filas reales en `cob_giros..cg_tran_servicio` (de 28 claves candidatas; 2 ya estaban libres) que
eran residuo de corridas QA anteriores — verificado sin ambigüedad por marcadores (`ts_usuario='QAUSER'`,
`ts_terminal='QA-TERM'`, `ts_srv/ts_lsrv='QA-SRV'/'QA-LSRV'`, fechas ago-sep 2026), sin dependencias
FK/trigger (`sysreferences` vacío para esa tabla). Se borraron una por una (clave completa, dentro de
`begin tran/commit tran`, verificando `@@rowcount=1` cada vez). Conteo total de la tabla bajó
exactamente 211671→211645 (26). Verificado con 2 llamadas REST reales (TC40, TC49): pasaron de
HTTP 422 (colisión) a HTTP 200/`codigoRetorno=0`.

**Corrección de rumbo durante la limpieza (documentado con transparencia):** el primer intento borró
filas con la clave *regenerada dinámicamente* (canal SP-directo, que ya nunca colisiona por el fix de
motor #22/#23) en vez de la clave *literal* que usa el canal REST/gRPC (que es la que realmente
colisiona). Las filas borradas por error eran también residuo QA legítimo (inocuo borrarlas), pero no
eran las que bloqueaban el problema real — se detectó y corrigió antes de declarar terminado.

**Fix permanente aplicado al documento** (para que esto no se repita en la próxima corrida, sea manual
o automatizada): se agregó un **PRE-SENTINELA inverso** a los 34 TCs — un bloque `IF EXISTS(...)
DELETE ...` que garantiza que la clave que el TC va a insertar esté LIBRE antes de ejecutar (a
diferencia del PRE-SENTINELA de los 18 TCs de colisión intencional, que garantiza que la clave SÍ
exista). Mismo patrón, invertido. Verificado: `validate_external_tc.py --check-only` → PASS,
`git diff --stat` → 738 inserciones, 0 borrados (solo adiciones, CRLF preservado). Sin commitear/pushear
todavía.

**⚠️ Nota de diseño (RESUELTA 2026-09-17):** el PRE-SENTINELA de TC52/TC53 apuntaba a la misma clave
(`32517/900001/900001/'C'`) que el sentinela ANTERIOR de TC23 (`cg_tran_servicio`) — el riesgo de
colisión entre ambos desapareció al corregir TC23 (ver abajo), cuyo sentinela ahora apunta a una
tabla y clave distintas (`cc_tran_servicio`).

**Pendiente:** commitear/pushear el PRE-SENTINELA de los 34, y correr agente-05 completo de nuevo para
confirmar que los 34 pasan a EQUIVALENTE.

## ACTUALIZACIÓN 2026-09-17 — Adopción del documento `(3)` de banco, TC23 corregido, hallazgo de 118 TCs sin datos

**Documento `(3)` de banco adoptado como base canónica**, sustituyendo la versión previa. Introdujo
2 violaciones de formato nuevas (TC02/TC03, "Msg de validación funcional" sin número) más 4 defectos
latentes, corregidos por nosotros sobre la base de `(3)`:
- TC02/TC03/TC122: mismo texto corregido (idéntico patrón de placeholder sin número).
- TC23: clave de guardia/sentinela desalineada (`901279` vs `900001`) — corregida en esa pasada (ver
  corrección de fondo más abajo, distinta e independiente).
- TC25: clave de sentinela desalineada (`900025` vs `901116`) — corregida.
- Los 34 PRE-SENTINELA anti-colisión (ver ACTUALIZACIÓN 2026-09-10) se reaplicaron sobre `(3)`.
- TC31 y TC68 quedan **sin decisión**: TC31 no tiene registro claro de qué se le pidió a banco
  originalmente; TC68 perdió cobertura de "modo 5 sin pago" en el rediseño de banco — pendiente
  decidir si se acepta o se le pide a banco restaurarla.

**TC23 — corrección de fondo (independiente del fix de clave arriba):** el sentinela apuntaba a
`cob_giros..cg_tran_servicio`, tabla que la rama `@i_operacion='A'` de este TC NUNCA toca (solo
`operacion='O'` la usa, ej. TC94). La colisión real ocurre en `cob_cuentas..cc_tran_servicio`,
insertada por el SP hijo `cob_giros..sp_tr_pago_giro_rc` que `sp_verificacion_acredita` invoca
siempre en la rama `'A'`. Sentinela reconstruido con la llave real verificada en vivo
(`sp_helpindex`): `(ts_tipo_transaccion=3208, ts_clase='F', ts_secuencial=900001,
ts_cod_alterno=0)`. **Resultado esperado corregido de `RETURN 1` a `RETURN 105020`** — verificado
3/3 veces por conexión directa `tsql`/FreeTDS (no JDBC): el `RETURN 1` documentado antes era el
retorno *interno* de `sp_tr_pago_giro_rc`, no el retorno final observable de `sp_verificacion_acredita`
(el SP bajo prueba). `validate_external_tc.py --check-only` → PASS tras el fix.

**Hallazgo — 118 de 200 TCs sin datos de prueba (giros purgados del ambiente):** el rango de giros
`2260088111`-`2260088134` (24 giros), que banco reutiliza cíclicamente a lo largo de casi todo el
documento, existía el 10/11-sep-2026 y **ya no existe hoy** (verificado en vivo contra SYBASE02,
0/24 presentes). Afecta 118 TCs (ver detalle completo en el chat con Juan Pablo del 2026-09-17).
No es tema de permisos ni del DBA — es purga/inestabilidad de datos del ambiente. No es corregible
por nosotros sustituyendo giros (cada TC depende de atributos de negocio específicos del giro
asignado — montos en umbrales exactos, moneda, estado — no son intercambiables). **Reportado a
banco** pidiendo restaurar el rango y evitar purgas futuras del ambiente QA.

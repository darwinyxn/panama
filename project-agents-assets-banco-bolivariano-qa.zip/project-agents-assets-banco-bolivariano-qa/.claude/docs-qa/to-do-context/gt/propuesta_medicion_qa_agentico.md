# Propuesta — Modelo de Medicion del Equipo de QA Agentico

> **Dirigido a:** Gerencia / Direccion de Proyecto
> **Presenta:** Equipo de QA
> **Ambito:** Migracion de Stored Procedures (Sybase) -> Microservicios (REST / gRPC)
> **Objetivo:** Proponer un modelo de KPIs propio del testing agentico, en reemplazo de las metricas
> tradicionales de un QA manual, que no reflejan la naturaleza de nuestro trabajo.

---

## 1. Resumen ejecutivo

El equipo de QA de este proyecto opera bajo un modelo de **testing agentico**: el ciclo de pruebas
(generacion de casos, ejecucion de la matriz de equivalencia y documentacion) lo realizan agentes de IA
orquestados, no una persona ejecutando casos manualmente. Por eso, **las metricas clasicas de un QA
manual** (numero de casos escritos por dia, casos ejecutados por hora, horas por caso) **no miden lo que
realmente aporta el equipo** y llevarian a conclusiones erroneas sobre su desempeno.

Se propone medir al equipo con tres factores alineados a como se genera valor en este modelo: **Calidad,
Eficiencia y Eficacia**, cada uno con una definicion operativa clara y una fuente de dato trazable.

---

## 2. Por que no aplica la medicion de un QA manual

| Supuesto de la medicion manual | Realidad en el testing agentico |
|--------------------------------|---------------------------------|
| El QA **escribe** los casos uno a uno; mas casos/dia = mas productivo | Los casos los **genera la IA** desde el codigo del SP; el volumen no depende del esfuerzo humano por caso |
| El QA **ejecuta** los casos manualmente; casos/hora mide su rendimiento | La ejecucion (SP vs REST vs gRPC) es **automatica**; una corrida completa de ~94 casos toma horas, no semanas |
| El tiempo por caso es comparable entre personas | El ciclo completo por SP pasa de **~81 horas manuales a ~3-5 horas** agenticas; el tiempo deja de ser una medida del esfuerzo individual |
| Existen criterios de aceptacion del cliente para contar "casos que pasan" | El banco **no entrega criterios**; el estandar es la **equivalencia con el SP**, generada y validada por el propio equipo |
| El trabajo se organiza en tareas asignadas por persona | El flujo se articula por **defectos** (los crea y cierra el banco) y por **entregables**, no por tareas individuales |

**Conclusion:** medir "casos por hora" a un equipo que automatiza la generacion y ejecucion de casos
penaliza justamente lo que lo hace eficiente. Se necesita un modelo que mida **calidad del entregable,
cumplimiento del plan y reprocesos**, no volumen manual.

---

## 3. Modelo de KPIs propuesto

Tres factores. Cada uno responde a una pregunta de gestion distinta.

> **Fuente de verdad (unica): las TAREAS del Gestor QA.** Todos los KPIs se calculan a partir de las
> tareas registradas en el Gestor QA (tabla `tasks`). Cada entregable o actividad del equipo (generacion
> de casos, ejecucion de matriz, documentacion UML/logica, carga QMetry, correcciones) se registra como
> una tarea con: tipo (`kind`), estado (`status`), prioridad (`priority`), fecha limite (`dueDate`),
> responsable (`memberId`) y SP asociado (`spMigrationId`). De ahi se derivan los tres factores; no se
> usan hojas de calculo paralelas ni conteos manuales.
>
> **Campos que se agregan a la tarea para habilitar la medicion** (atributos nuevos en el `payload` de
> `tasks`, poblados al cerrar/devolver la tarea):
> - `impactoDevolucion`: `Alto` | `Medio` | `Bajo` | `null` (null = sin devolucion). Clasifica la
>   severidad de la devolucion recibida por ese entregable.
> - `devoluciones`: entero >= 0. Numero de veces que la tarea fue devuelta para correccion antes de su
>   aceptacion final.
> - `plannedSprint` (o se infiere de `dueDate`): identifica el periodo en que la tarea fue planeada.

### 3.1 Calidad — "¿que tan bien salen los entregables la primera vez?"

**Definicion:** se mide segun la **clasificacion de las devoluciones, defectos o issues** que recibe cada
entregable, ponderados por su **nivel de impacto** (Alto / Medio / Bajo).

Es decir, no cuenta solo *cuantas* devoluciones hay, sino *de que gravedad* son. No es lo mismo una
devolucion de alto impacto (un error que invalida el entregable) que una de bajo impacto (un ajuste
menor de forma).

**Ejemplo:** de la generacion de casos de prueba, cuantas devoluciones fueron de **alto impacto**,
cuantas de **medio** y cuantas de **bajo**.

**Formula:** se pondera cada devolucion por su impacto y se calcula un Indice de Calidad sobre el total
de tareas del periodo.

```
Peso por impacto:  Alto = 3   |   Medio = 2   |   Bajo = 1

Puntos de penalizacion = (3 x #devoluciones_Alto) + (2 x #devoluciones_Medio) + (1 x #devoluciones_Bajo)

Indice de Calidad (%) = ( 1 - ( Puntos de penalizacion / (3 x Total de tareas del periodo) ) ) x 100
```

- Cuenta de tareas por impacto = tareas del periodo agrupadas por el campo `impactoDevolucion`.
- El divisor `3 x Total de tareas` representa el peor escenario (todas devueltas con impacto Alto) -> el
  indice queda normalizado entre 0% y 100%.
- Complemento util: **distribucion de devoluciones por impacto** (ej. 0 Alto, 1 Medio, 2 Bajo) por tipo
  de entregable (`kind`).
- Lectura de gestion: **mientras mas cerca de 100%, mayor la calidad** (menos devoluciones y de menor impacto).

**Fuente de dato (Gestor QA):** tareas de la tabla `tasks`, campo `impactoDevolucion`, filtradas por
periodo (`dueDate`/`plannedSprint`) y por tipo (`kind`).

### 3.2 Eficiencia — "¿se cumple lo planeado en el tiempo establecido?"

**Definicion:** se mide segun la **cantidad de tareas planeadas frente a la cantidad de tareas ejecutadas
o terminadas dentro del tiempo establecido**.

**Formula:**

```
Eficiencia (%) = ( Tareas terminadas dentro del plazo / Tareas planeadas del periodo ) x 100

donde:
  Tareas planeadas del periodo   = tareas del sprint (por dueDate / plannedSprint)
  Tareas terminadas dentro del plazo = tareas con status = "done" y updatedAt <= dueDate
```

- Se toma el conjunto de tareas comprometidas para el periodo (ej. el sprint).
- Una tarea cuenta como cumplida si esta en estado **`done`** y se cerro **en o antes** de su `dueDate`.
- Lectura de gestion: **cuanto mas se acerca al 100%, mayor el cumplimiento** del plan comprometido.

**Fuente de dato (Gestor QA):** tabla `tasks` — campos `status`, `dueDate` y `updatedAt`, filtradas por periodo.

### 3.3 Eficacia — "¿cuanto reproceso genera cada entregable?"

**Definicion:** se mide segun la **cantidad de veces que se devuelve un entregable o tarea**.

Cada vez que un entregable se devuelve para correccion, cuenta como un reproceso. Un entregable que se
acepta a la primera tiene eficacia maxima; uno que se devuelve varias veces la reduce.

**Formula:** se mide como el porcentaje de entregables aceptados sin reproceso (a la primera).

```
Eficacia (%) = ( Tareas aceptadas sin devolucion / Total de tareas del periodo ) x 100

donde:
  Tareas aceptadas sin devolucion = tareas con campo devoluciones = 0

Metrica complementaria:
  Devoluciones promedio por tarea = ( Suma de devoluciones de todas las tareas ) / ( Total de tareas )
```

- `devoluciones` = 0 significa que el entregable se acepto a la primera (eficacia maxima).
- Lectura de gestion: **mientras mas cerca de 100% (y menor el promedio de devoluciones), mayor la
  eficacia** — el entregable llega correcto sin ciclos de correccion repetidos.

**Fuente de dato (Gestor QA):** tabla `tasks`, campo `devoluciones`, filtradas por periodo.

---

## 4. Cuadro resumen de los KPIs

| Factor | Pregunta que responde | Formula | Campo en `tasks` (Gestor QA) |
|--------|-----------------------|---------|------------------------------|
| **Calidad** | ¿Que tan bien sale el entregable? | `(1 - PuntosPenalizacion / (3 x Total tareas)) x 100`, con pesos Alto=3/Medio=2/Bajo=1 | `impactoDevolucion`, `kind` |
| **Eficiencia** | ¿Se cumple lo planeado a tiempo? | `(Tareas done dentro de plazo / Tareas planeadas) x 100` | `status`, `dueDate`, `updatedAt` |
| **Eficacia** | ¿Cuanto reproceso hay? | `(Tareas con devoluciones=0 / Total tareas) x 100` | `devoluciones` |

> **Todos los datos provienen de la tabla `tasks` del Gestor QA** — fuente unica de verdad para los KPIs.

---

## 5. Por que este modelo es justo y util

- **Mide el valor real:** calidad del entregable, cumplimiento del plan y reprocesos — no volumen manual
  que la automatizacion ya resuelve.
- **Es accionable:** cada factor apunta a una palanca de mejora concreta (bajar devoluciones de alto
  impacto, cerrar lo planeado a tiempo, reducir reprocesos).
- **Es trazable y de fuente unica:** los tres factores se calculan desde las **tareas del Gestor QA**
  (tabla `tasks`). No hay hojas de calculo paralelas ni conteos manuales: el dato nace donde se registra
  el trabajo. Solo requiere poblar tres atributos al cerrar/devolver cada tarea (`impactoDevolucion`,
  `devoluciones`, `plannedSprint`).
- **Es comparable en el tiempo:** permite ver la evolucion del equipo sprint a sprint bajo reglas
  estables, sin depender de la variabilidad del esfuerzo manual por caso.

---

## 6. Conclusion

El testing agentico cambia la naturaleza del trabajo de QA: la IA genera y ejecuta las pruebas, y el
equipo se enfoca en la **calidad, la orquestacion y el analisis**. Medirlo con las varas del QA manual
(casos/hora) no refleja su aporte. Se propone adoptar un modelo de **tres KPIs — Calidad, Eficiencia y
Eficacia** — que mide lo que de verdad importa: que los entregables salgan correctos (calidad), que se
cumpla lo planeado a tiempo (eficiencia) y que no haya reprocesos (eficacia). Es un modelo justo con el
equipo, alineado al proyecto y sostenible con la informacion que ya se registra.

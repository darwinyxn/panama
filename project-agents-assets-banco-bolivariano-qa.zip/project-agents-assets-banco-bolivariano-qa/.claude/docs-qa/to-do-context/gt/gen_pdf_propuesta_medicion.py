#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Genera el PDF (documento, no slides) de la Propuesta de Medicion del QA Agentico,
basado en propuesta_medicion_qa_agentico.md. Vertical A4, con reportlab."""
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.pdfgen import canvas

OUT="/home/ssm-user/project-agents-assets-banco-bolivariano/claude-setupv2/.claude/docs-qa/inputs/documents/gt/propuesta_medicion_qa_agentico.pdf"
W,H=A4
AZUL=colors.HexColor("#123a63"); AZUL2=colors.HexColor("#2f6db0")
GRIS=colors.HexColor("#5b6670"); GRISCL=colors.HexColor("#eef2f6")
VERDE=colors.HexColor("#1f8a5b"); TEXTO=colors.HexColor("#1c2530"); BLANCO=colors.white
ML=2.2*cm; MR=2.2*cm; MT=2.4*cm; MB=1.8*cm
CW=W-ML-MR
c=canvas.Canvas(OUT, pagesize=A4)
y=[H-MT]; page=[1]

def footer():
    c.setFont("Helvetica",8); c.setFillColor(GRIS)
    c.drawString(ML,1.1*cm,"Propuesta — Modelo de Medicion del QA Agentico")
    c.drawRightString(W-MR,1.1*cm,f"{page[0]}")

def newpage():
    footer(); c.showPage(); page[0]+=1; y[0]=H-MT

def space(h):
    if y[0]-h < MB+0.8*cm: newpage()

def wrap(txt,font,size,maxw):
    c.setFont(font,size); out=[];
    for para in txt.split("\n"):
        words=para.split(); cur=""
        if not words: out.append(""); continue
        for w in words:
            t=(cur+" "+w).strip()
            if c.stringWidth(t,font,size)<=maxw: cur=t
            else: out.append(cur); cur=w
        out.append(cur)
    return out

def h1(txt):
    space(1.5*cm)
    c.setFillColor(AZUL); c.setFont("Helvetica-Bold",15)
    for ln in wrap(txt,"Helvetica-Bold",15,CW):
        c.drawString(ML,y[0],ln); y[0]-=0.62*cm
    c.setStrokeColor(AZUL2); c.setLineWidth(1); c.line(ML,y[0]+0.15*cm,ML+CW,y[0]+0.15*cm)
    y[0]-=0.35*cm

def h2(txt):
    space(1.1*cm)
    c.setFillColor(AZUL2); c.setFont("Helvetica-Bold",11.5)
    for ln in wrap(txt,"Helvetica-Bold",11.5,CW):
        c.drawString(ML,y[0],ln); y[0]-=0.52*cm
    y[0]-=0.1*cm

def para(txt,size=10):
    for ln in wrap(txt,"Helvetica",size,CW):
        space(0.5*cm); c.setFillColor(TEXTO); c.setFont("Helvetica",size)
        c.drawString(ML,y[0],ln); y[0]-=0.48*cm
    y[0]-=0.15*cm

def bullet(txt,size=10):
    lines=wrap(txt,"Helvetica",size,CW-0.7*cm)
    space(0.5*cm*len(lines))
    c.setFillColor(AZUL2); c.circle(ML+0.15*cm,y[0]+0.1*cm,0.08*cm,fill=1,stroke=0)
    c.setFillColor(TEXTO); c.setFont("Helvetica",size)
    for i,ln in enumerate(lines):
        c.drawString(ML+0.5*cm,y[0],ln); y[0]-=0.46*cm
    y[0]-=0.06*cm

def formula(lines):
    hbox=0.42*cm*len(lines)+0.5*cm
    space(hbox+0.3*cm)
    c.setFillColor(colors.HexColor("#0f2033")); c.roundRect(ML,y[0]-hbox+0.3*cm,CW,hbox,0.15*cm,fill=1,stroke=0)
    c.setFillColor(colors.HexColor("#cfe0f0")); c.setFont("Courier-Bold",9)
    yy=y[0]-0.05*cm
    for ln in lines:
        c.drawString(ML+0.4*cm,yy,ln); yy-=0.42*cm
    y[0]-=hbox+0.2*cm

def kv_table(rows, headers, colw):
    # tabla simple con header azul
    rowh=0.62*cm
    space(rowh*(len(rows)+1)+0.4*cm)
    x=ML
    c.setFillColor(AZUL); c.rect(ML,y[0]-rowh+0.15*cm,CW,rowh,fill=1,stroke=0)
    c.setFillColor(BLANCO); c.setFont("Helvetica-Bold",8.5)
    for i,hd in enumerate(headers):
        c.drawString(x+0.15*cm,y[0]-0.15*cm,hd); x+=colw[i]
    y[0]-=rowh
    for r_i,row in enumerate(rows):
        # alto dinamico por wrapping de celdas
        cell_lines=[wrap(str(cell),"Helvetica",8,colw[i]-0.3*cm) for i,cell in enumerate(row)]
        maxln=max(len(cl) for cl in cell_lines)
        rh=0.4*cm*maxln+0.2*cm
        space(rh)
        if r_i%2==0:
            c.setFillColor(GRISCL); c.rect(ML,y[0]-rh+0.3*cm,CW,rh,fill=1,stroke=0)
        x=ML; c.setFillColor(TEXTO); c.setFont("Helvetica",8)
        for i,cl in enumerate(cell_lines):
            yy=y[0]-0.1*cm
            for ln in cl:
                c.drawString(x+0.15*cm,yy,ln); yy-=0.4*cm
            x+=colw[i]
        y[0]-=rh
    y[0]-=0.2*cm

# ===== PORTADA =====
c.setFillColor(AZUL); c.rect(0,H-8*cm,W,8*cm,fill=1,stroke=0)
c.setFillColor(BLANCO); c.setFont("Helvetica-Bold",22)
c.drawString(ML,H-4*cm,"Propuesta")
c.setFont("Helvetica-Bold",18)
c.drawString(ML,H-5*cm,"Modelo de Medicion del QA Agentico")
c.setFont("Helvetica",11)
c.drawString(ML,H-6.2*cm,"KPIs: Calidad · Eficiencia · Eficacia")
c.drawString(ML,H-6.9*cm,"Fuente de verdad: tareas del Gestor QA")
y[0]=H-9.5*cm
c.setFillColor(TEXTO); c.setFont("Helvetica",10)
for ln in ["Dirigido a: Gerencia / Direccion de Proyecto",
           "Presenta: Equipo de QA",
           "Ambito: Migracion de Stored Procedures (Sybase) -> Microservicios (REST / gRPC)"]:
    c.drawString(ML,y[0],ln); y[0]-=0.55*cm
y[0]-=0.5*cm

# ===== 1. RESUMEN =====
h1("1. Resumen ejecutivo")
para("El equipo de QA de este proyecto opera bajo un modelo de testing agentico: el ciclo de pruebas "
     "(generacion de casos, ejecucion de la matriz de equivalencia y documentacion) lo realizan agentes "
     "de IA orquestados, no una persona ejecutando casos manualmente. Por eso las metricas clasicas de un "
     "QA manual (casos escritos por dia, casos por hora, horas por caso) no miden lo que realmente aporta "
     "el equipo y llevarian a conclusiones erroneas.")
para("Se propone medir al equipo con tres factores alineados a como se genera valor en este modelo: "
     "Calidad, Eficiencia y Eficacia. La fuente unica de datos son las tareas registradas en el Gestor QA.")

# ===== 2. POR QUE NO APLICA =====
h1("2. Por que no aplica la medicion de un QA manual")
kv_table(
 [["Mas casos/dia = mas productivo","Los casos los genera la IA desde el SP; el volumen no depende del esfuerzo humano por caso"],
  ["Casos/hora mide el rendimiento","La ejecucion SP vs REST vs gRPC es automatica; una corrida de ~94 casos toma horas, no semanas"],
  ["El tiempo por caso es comparable","El ciclo por SP pasa de ~81 h manuales a ~3-5 h agenticas"],
  ["Hay criterios de aceptacion del cliente","El banco no entrega criterios; el estandar es la equivalencia con el SP"],
  ["El trabajo se mide por tareas por persona","El flujo se articula por defectos (los crea/cierra el banco) y por entregables"]],
 ["Supuesto de la medicion manual","Realidad en el testing agentico"], [7.0*cm, CW-7.0*cm])
para("Conclusion: medir 'casos por hora' a un equipo que automatiza la generacion y ejecucion de casos "
     "penaliza justo lo que lo hace eficiente. Se necesita medir calidad del entregable, cumplimiento del "
     "plan y reprocesos.")

# ===== 3. FUENTE DE VERDAD =====
h1("3. Fuente de verdad: las tareas del Gestor QA")
para("Todos los KPIs se calculan a partir de las tareas registradas en el Gestor QA (tabla tasks). Cada "
     "entregable o actividad (generacion de casos, ejecucion de matriz, documentacion UML/logica, carga "
     "QMetry, correcciones) se registra como una tarea con tipo (kind), estado (status), prioridad, fecha "
     "limite (dueDate), responsable (memberId) y SP asociado (spMigrationId). No se usan hojas de calculo "
     "paralelas ni conteos manuales.")
para("Atributos que se agregan a la tarea para habilitar la medicion (poblados al cerrar/devolver):")
bullet("impactoDevolucion: Alto | Medio | Bajo | null (null = sin devolucion). Severidad de la devolucion del entregable.")
bullet("devoluciones: entero >= 0. Veces que la tarea fue devuelta para correccion antes de su aceptacion.")
bullet("plannedSprint (o se infiere de dueDate): periodo en que la tarea fue planeada.")

# ===== 4. KPIs =====
h1("4. Modelo de KPIs")

h2("4.1 Calidad — que tan bien salen los entregables la primera vez")
para("Se mide segun la clasificacion de las devoluciones/defectos por nivel de impacto (Alto/Medio/Bajo). "
     "No cuenta solo cuantas devoluciones hay, sino de que gravedad son.")
formula(["Peso:  Alto=3   Medio=2   Bajo=1",
         "Penalizacion = 3*#Alto + 2*#Medio + 1*#Bajo",
         "Calidad(%) = (1 - Penalizacion/(3*Total tareas)) * 100"])
bullet("Fuente (Gestor QA): tasks.impactoDevolucion, agrupado por kind y periodo.")
bullet("Lectura: mientras mas cerca de 100%, mayor la calidad (menos devoluciones y de menor impacto).")

h2("4.2 Eficiencia — se cumple lo planeado en el tiempo establecido")
para("Se mide segun la cantidad de tareas planeadas frente a las terminadas dentro del tiempo establecido.")
formula(["Eficiencia(%) = (Tareas done dentro de plazo / Tareas planeadas) * 100",
         "done dentro de plazo = status='done' y updatedAt <= dueDate"])
bullet("Fuente (Gestor QA): tasks.status, tasks.dueDate, tasks.updatedAt por periodo.")
bullet("Lectura: cuanto mas cerca de 100%, mayor el cumplimiento del plan comprometido.")

h2("4.3 Eficacia — cuanto reproceso genera cada entregable")
para("Se mide segun la cantidad de veces que se devuelve un entregable o tarea. A la primera = eficacia maxima.")
formula(["Eficacia(%) = (Tareas con devoluciones=0 / Total tareas) * 100",
         "Devoluciones promedio = suma(devoluciones) / Total tareas"])
bullet("Fuente (Gestor QA): tasks.devoluciones por periodo.")
bullet("Lectura: mientras mas cerca de 100% (y menor promedio), mayor la eficacia — sin ciclos de correccion.")

# ===== 5. CUADRO RESUMEN =====
h1("5. Cuadro resumen de los KPIs")
kv_table(
 [["Calidad","(1 - Penalizacion/(3*Total))*100  (Alto=3/Medio=2/Bajo=1)","impactoDevolucion, kind"],
  ["Eficiencia","(done dentro de plazo / planeadas)*100","status, dueDate, updatedAt"],
  ["Eficacia","(devoluciones=0 / total)*100","devoluciones"]],
 ["Factor","Formula","Campo en tasks"], [3.0*cm, 8.5*cm, CW-11.5*cm])
para("Todos los datos provienen de la tabla tasks del Gestor QA — fuente unica de verdad para los KPIs.")

# ===== 6. POR QUE ES JUSTO =====
h1("6. Por que este modelo es justo y util")
bullet("Mide el valor real: calidad del entregable, cumplimiento del plan y reprocesos — no volumen manual.")
bullet("Es accionable: cada factor apunta a una palanca concreta (bajar devoluciones de alto impacto, cerrar a tiempo, reducir reprocesos).")
bullet("Es trazable y de fuente unica: se calcula desde las tareas del Gestor QA; el dato nace donde se registra el trabajo.")
bullet("Es comparable en el tiempo: permite ver la evolucion del equipo sprint a sprint bajo reglas estables.")

# ===== 7. CONCLUSION =====
h1("7. Conclusion")
para("El testing agentico cambia la naturaleza del trabajo de QA: la IA genera y ejecuta las pruebas, y "
     "el equipo se enfoca en la calidad, la orquestacion y el analisis. Medirlo con las varas del QA "
     "manual (casos/hora) no refleja su aporte. Se propone adoptar tres KPIs — Calidad, Eficiencia y "
     "Eficacia — calculados desde las tareas del Gestor QA: que los entregables salgan correctos, que se "
     "cumpla lo planeado a tiempo y que no haya reprocesos. Un modelo justo con el equipo, alineado al "
     "proyecto y sostenible con la informacion que ya se registra.")

footer(); c.showPage(); c.save()
print("PDF generado:", OUT)

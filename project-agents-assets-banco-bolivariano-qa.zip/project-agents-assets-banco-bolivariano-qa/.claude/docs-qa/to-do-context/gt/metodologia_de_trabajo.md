# Metodologia de Trabajo — Proyecto de Migracion

> **Dirigido a:** Gerencia de Proyecto
> **Ambito:** Migracion de Stored Procedures (Sybase) a microservicios (REST/gRPC)
> **Proposito:** Presentar, en terminos ejecutivos, la metodologia de trabajo del equipo: su enfoque,
> justificacion, cadencia, flujo de entrega y modelo de aseguramiento de calidad.

---

## 1. Resumen ejecutivo

El proyecto opera bajo una **metodologia hibrida** que combina la agilidad de **Scrum** para la ejecucion
iterativa con la formalidad de la **metodologia tradicional (cascada)** para la gobernanza y las fases
secuenciales. Este modelo se adopto deliberadamente porque el banco **aun no tiene la madurez para operar
de forma 100% agil** y conserva componentes tradicionales en su forma de trabajo.

El aseguramiento de calidad se apoya de forma central en **Inteligencia Artificial**: la comprension del
negocio y la logica de cada Stored Procedure se **obtiene y documenta con agentes de IA que extraen la
informacion directamente del codigo del SP**. El banco no entrega especificaciones ni criterios de
aceptacion formales; el equipo **genera todo el conocimiento funcional a traves de la IA**, lo valida y lo
convierte en la base de las pruebas de equivalencia.

---

## 2. Enfoque metodologico: modelo hibrido (Scrum + Cascada)

| Componente | Aporte al proyecto |
|------------|--------------------|
| **Agil / Scrum** | Ejecucion iterativa por sprints, cadencia de ceremonias, entregas incrementales y adaptacion continua |
| **Tradicional / Cascada** | Gobierno documental (Test Plan y Estrategia de Pruebas para todo el proyecto) y un flujo secuencial: primero construccion, luego pruebas, luego validacion del banco |

**Por que hibrido:** el banco no esta en capacidad de ser 100% agil y mantiene procesos tradicionales
(documentacion formal, aprobaciones y fases secuenciales). El modelo hibrido toma la cadencia y
flexibilidad de Scrum para el dia a dia, y la estructura de cascada para la planeacion de pruebas y el
gobierno del proyecto.

---

## 3. Cadencia y ceremonias

- **Sprints de 4 semanas.**
- **Planning** al inicio del sprint (planificacion y compromiso del trabajo).
- **Review los viernes** (cierre de semana, revision del avance/entregable).
- **Dos dailys diarias**, separadas por especialidad para mantener el foco de cada frente:
  - **Daily QA** — estado de pruebas, matrices de equivalencia y defectos.
  - **Daily Tech** — construccion del microservicio, avance de la migracion y bloqueantes tecnicos.

**Practicas particulares del modelo:**
- **No se realizan retrospectivas.**
- **El refinamiento es asincrono, no una reunion.** El equipo envia entregables al banco (por ejemplo,
  los casos de prueba) y el banco los revisa y da su visto bueno. No hay sesiones conjuntas de
  refinamiento de historias; la validacion del banco cumple esa funcion.

---

## 4. Roles y herramientas

- **Product Owner (PO):** priorizacion y relacion con el banco.
- **Jira:** repositorio de defectos del proyecto (tickets NCBE).
- **QMetry:** herramienta de gestion de pruebas y **entregable formal de la ejecucion de QA**. Al
  publicarse la ejecucion en QMetry, el banco toma esa base para probar y levantar defectos.

---

## 5. Gestion del trabajo: sin tareas, gestion por defectos

El proyecto **no gestiona el trabajo mediante tareas o tasks**. El unico artefacto de gestion operativa
es el **defecto**, con un ciclo de responsabilidades claramente repartido:

| Etapa | Responsable |
|-------|-------------|
| **Creacion del defecto** | **Banco** (a partir de sus pruebas sobre la ejecucion entregada en QMetry) |
| **Resolucion del defecto** | **Equipo** (QA analiza y atribuye; Migracion corrige el micro; QA corrige lo relativo a pruebas/arnes) |
| **Cierre del defecto** | **Banco** |

El equipo no abre tareas propias; el flujo de trabajo se articula alrededor de los defectos que genera el
banco y que el equipo resuelve.

---

## 6. Base de conocimiento: generada con IA, no entregada por el banco

Un rasgo diferencial del proyecto: **el banco no entrega especificaciones funcionales ni criterios de
aceptacion documentados.** No existe un documento de requisitos o de criterios de aceptacion del cual
partir.

En su lugar, **el conocimiento del negocio se genera con Inteligencia Artificial:**
- Agentes de IA **extraen la logica directamente del codigo del Stored Procedure** (y de sus SPs/librerias
  dependientes).
- A partir de esa extraccion se generan los **casos de uso, los casos de prueba y la documentacion**
  funcional del comportamiento esperado.
- El **comportamiento esperado (el "criterio" de la prueba) es el propio SP original**: la prueba valida
  que el microservicio migrado se comporte identico al SP. La equivalencia con el SP es el estandar de
  aceptacion de facto, en ausencia de criterios formales del banco.

Esto convierte a la IA en el motor de comprension y documentacion del proyecto, y al SP original en la
fuente unica de verdad funcional.

---

## 7. Flujo de entrega de punta a punta

El flujo es secuencial (componente cascada): **construye Migracion -> prueba QA -> valida el banco.**

```
[1] MIGRACION / DEV        [2] QA                                   [3] BANCO
   genera el .sql     ->   IA extrae la logica del SP           ->  prueba sobre QMetry
   construye el micro      genera CU / CP / documentacion           genera defectos (Jira)
   (REST / gRPC)           ejecuta matriz de equivalencia           cierra defectos resueltos
                           entrega la ejecucion en QMetry
```

1. **Migracion / DEV (arranque):** genera el `.sql` del SP y construye el microservicio (REST/gRPC). QA no
   interviene hasta que existe el artefacto construido.
2. **QA (pruebas):** con IA extrae la logica del SP y genera la documentacion; ejecuta la **matriz de
   equivalencia** comparando el SP directo contra REST y gRPC; formaliza la ejecucion en QMetry.
3. **Banco (validacion):** prueba sobre la ejecucion de QMetry, **genera los defectos** en Jira; el equipo
   los resuelve y el **banco los cierra**.

---

## 8. Entregables y documentacion

La documentacion es un esfuerzo **conjunto de ambos equipos** — tanto Migracion como QA generan
documentacion como parte de su trabajo. Toda la documentacion funcional se genera con apoyo de IA a
partir del codigo de los Stored Procedures.

**Documentacion de Migracion / DEV:**
- **Documentacion tecnica del microservicio** (arquitectura/diseno, contratos REST/gRPC).
- **Documentacion del codigo y del build** (guias del repositorio, librerias, despliegue).
- **Analisis funcional del SP** (comprension de la logica del Stored Procedure migrado).

**Documentacion de QA:**
- **Casos de uso (CU)** y **casos de prueba (CP).**
- **Matriz de equivalencia** (resultado SP vs REST vs gRPC).
- **Documentacion UML** (vistas de paquetes, componentes, clases y secuencias).
- **Documentos de pruebas estaticas** (documento de logica del SP y sus dependencias).
- **Ejecucion en QMetry** como entregable formal de la ejecucion de pruebas.

---

## 9. Separacion de responsabilidades

| Actor | Responsabilidad |
|-------|-----------------|
| **Migracion / DEV** | Genera el `.sql`, construye el microservicio, corrige los defectos del micro y **documenta** (tecnica del micro, codigo/build, analisis funcional del SP) |
| **QA** | Genera el conocimiento con IA, ejecuta la equivalencia, resuelve lo relativo a pruebas, entrega en QMetry y **documenta** (CU/CP, matriz, UML, pruebas estaticas) |
| **Banco** | Da el visto bueno de los casos de prueba, prueba sobre QMetry, **crea y cierra** los defectos |
| **PO** | Prioriza y gestiona la relacion con el banco |

---

## 10. Conclusion

La metodologia hibrida permite avanzar con cadencia agil (sprints de 4 semanas, planning, review y dos
dailys) dentro de un marco de gobierno tradicional, adaptado a la madurez del banco. El proyecto se
distingue por dos rasgos: **la gestion se articula por defectos** (creados y cerrados por el banco, resueltos
por el equipo) en lugar de tareas, y **el conocimiento funcional se genera integramente con IA** a partir
del codigo de los Stored Procedures, ante la ausencia de especificaciones y criterios de aceptacion del
banco — siendo el SP original la fuente unica de verdad contra la cual se valida la equivalencia.

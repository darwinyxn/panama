# Testing Agentico en QA — Documento Detallado

> **Dirigido a:** Gerencia de Proyecto y equipo tecnico
> **Ambito:** Migracion de Stored Procedures (Sybase) -> Microservicios (REST / gRPC)
> **Tema:** Automatizacion del ciclo de pruebas de QA con agentes de IA
> **Version en diapositivas:** `testing_agentico_QA.pdf` (misma carpeta)

---

## 1. Que es el Testing Agentico

Es un modelo en el que **el ciclo completo de QA lo operan agentes de IA**, cada uno con una unica
responsabilidad, encadenados en un pipeline. En lugar de que una persona escriba casos, los ejecute,
compare resultados y redacte la documentacion, esas tareas las realizan agentes especializados que se
validan entre si.

**Principios que lo rigen:**

- **El Stored Procedure (SP) es la fuente unica de verdad.** El comportamiento correcto no viene de un
  documento de requisitos (el banco no lo entrega) sino del propio SP en produccion. La migracion es una
  **traduccion fiel**, no una mejora: el microservicio debe hacer *exactamente* lo mismo que el SP.
- **Validacion con IA contra el codigo (modelo banco-first).** El banco entrega los casos de prueba ya
  con datos reales (cuentas, montos, resultado esperado). Los agentes ya NO generan los casos desde cero:
  los validan, completan y corrigen contra el SQL del SP (fuente de verdad) y contra el ambiente real
  (Sybase). No se "inventa" comportamiento ni dato.
- **Equivalencia como criterio de aceptacion.** Como no hay criterios formales del banco, el estandar de
  aceptacion es: *el microservicio (REST y gRPC) produce el mismo resultado que el SP directo*.
- **Autonomia con puntos de control.** El pipeline corre solo; solo se detiene ante una ambiguedad real de
  negocio que la IA no puede resolver.
- **Separacion de responsabilidades.** El banco entrega los casos de prueba; QA los valida y ejecuta la
  equivalencia; Migracion construye y corrige el micro; el banco valida y levanta defectos.

---

## 2. El ciclo de pruebas QA — paso a paso

El pipeline es secuencial y cada fase **valida o consume** la salida de la anterior. Entrada del ciclo:
el `.sql` del SP (lo entrega Migracion) + el microservicio ya construido (REST/gRPC) + el **documento de
casos de prueba que entrega el BANCO** (formato plantilla, con datos ya reales).

```
 .sql del SP + micro construido + doc de casos de prueba de Banco (con datos)
        │
        ▼
 [1] Validacion/Normalizacion ─► [2] Config/Payloads ─► [3] Matriz de
     de Casos de Prueba (CP)        (REST/gRPC)             Equivalencia
        │  ▲                                                    │
        ▼  │ (loop validar/corregir)                             ▼
    valida + corrige                                    SP vs REST vs gRPC
                                                            campo a campo
                                                                   │
                                                                   ▼
                                                            veredicto por caso
                                                                   │
                                                                   ▼
                                              [4] Entrega en QMetry ──► el banco prueba y levanta defectos
```

### Fase 1 — Validacion y Normalizacion de Casos de Prueba (CP)
- **Modelo banco-first:** el banco decide **QUE** probar y aporta los **datos reales** (cuentas, montos,
  resultado esperado) en un documento con formato plantilla. Los agentes ya **NO generan casos de prueba
  desde cero** — los validan, completan y corrigen contra el SQL del SP (fuente de verdad) y contra el
  ambiente real.
- **Entrada:** documento de casos de prueba del banco (`test-cases-banco/*.md`) + el SQL del SP.
- **Proceso (con lazo de calidad):**
  1. Un agente valida el **formato** del documento contra la plantilla, prueba que el parser lo pueda
     leer, y deja el documento normalizado en orden canonico (`qa_casos_prueba.md`).
  2. Descubre contra **Sybase real** los datos de cada PRE (existen las cuentas, cumplen el escenario) y
     clasifica lo que falta o esta pendiente de descifrar.
  3. Un agente **valida** que cada TC sea ejecutable (coherencia de datos, PRE/POST correctas, resultado
     esperado trazable al SP); si encuentra problemas, un agente **corrector** los aplica. Este lazo
     validar->corregir se repite hasta que la suite queda ejecutable.
- **Salida:** `qa_casos_prueba.md` — la suite del banco, validada y corregida, lista para ejecutar.

### Fase 2 — Config / Payloads
- **Proceso:** un agente lee el Controller y el contrato del micro para armar la seccion CONFIG (endpoint
  REST, host gRPC, .proto) y el **diccionario SP-REST** (que parametro del SP corresponde a que campo del
  request/response). Con eso se generan los **payloads REST y gRPC** de cada TC.
- **Salida:** CONFIG + diccionario + payloads embebidos en el documento de casos.

### Fase 3 — Matriz de Equivalencia (el corazon del ciclo)
- **Proceso:** por cada TC se ejecutan **tres vias** y se comparan (ver seccion 4 tecnica).
- **Veredicto por caso:** `EQUIVALENTE`, `NO_EQUIVALENTE`, `INCONSISTENCIA` o `SYBASE_FAIL`.
- **Salida:** la matriz de equivalencia (resultados de todos los TC).

### Fase 4 — Entrega en QMetry
- Se crea el ciclo de pruebas en QMetry, se transforman y envian los resultados, se enlazan los casos y se
  verifica la sincronizacion. **QMetry es el entregable formal**: sobre esa base el banco prueba y genera
  los defectos (tickets Jira).

---

## 3. Los 14 agentes QA a fondo

Cada agente hace una sola cosa y entrega un artefacto verificable al siguiente. Se agrupan en 4 bloques.

### Bloque A — Procesamiento de Casos de Prueba entregados por Banco (4 agentes)

| Agente | Entrada | Que hace | Salida |
|--------|---------|----------|--------|
| **auto-01 (Validador/Normalizador)** | documento de casos del banco + SQL del SP | Valida el formato contra la plantilla, prueba el parser, deja el documento normalizado y descubre los datos del PRE contra Sybase real | `qa_casos_prueba.md` normalizado + `data_discovery.json` |
| **auto-02 (Validador de ejecutabilidad)** | qa_casos_prueba.md + ambiente | Verifica que cada TC sea ejecutable: coherencia de datos, PRE/POST, resultado esperado | reporte de validacion |
| **auto-03 (Corrector)** | reporte del validador | Aplica las correcciones concretas al documento de casos | qa_casos_prueba.md corregido |
| **auto-04 (Config/Payloads)** | Controller + .proto del micro | Genera la seccion CONFIG y el diccionario SP-REST; arma payloads REST/gRPC | CONFIG + diccionario |

### Bloque B — Ejecucion / Equivalencia (1 agente)

| Agente | Entrada | Que hace | Salida |
|--------|---------|----------|--------|
| **auto-05 (Matrix-flow)** | qa_casos_prueba.md + micro desplegado | Orquesta el pipeline y ejecuta la matriz: por cada TC corre SP directo, REST y gRPC, y compara campo a campo | matriz de equivalencia (veredictos) |

### Bloque C — Entrega en QMetry (7 agentes)

| Agente | Que hace |
|--------|----------|
| **qmetry-orquestador** | Coordina toda la entrega en QMetry (invoca a los demas en orden) |
| **qmetry-setup** | Prepara la configuracion y el contexto de la entrega |
| **cycle-creator** | Crea el Test Cycle y su folder en QMetry |
| **traductor** | Transforma la ejecucion QA al formato que QMetry espera |
| **inyector** | Envia (carga) los resultados a QMetry |
| **linker** | Enlaza los Test Cases al Test Cycle correspondiente |
| **sync-checker** | Consulta QMetry y genera el plan de sincronizacion (que crear/actualizar) |

### Bloque D — Herramientas manuales / soporte (2 agentes)

Fuera del pipeline automatico A-01→A-05; se invocan explicitamente por una persona cuando se necesitan.

| Agente | Que hace |
|--------|----------|
| **queryplan** | Analiza el Query Plan de un SP migrado: inventario cruzado de SQL y ejecucion de cada sentencia DML critica contra Sybase real (plan + IO). Entrega el ZIP formato Banco (`detalle_ejecucion.qp` + `observaciones.qp` + manifest). |
| **gestor-qa** | Crea y actualiza tareas, errores (bugs) y casos de prueba en el **Gestor QA** (app de gestion del proyecto, backend Supabase) hablando en lenguaje natural; valida contra las reglas de negocio del Gestor QA antes de escribir. |

**Resumen:** 4 procesan los casos de prueba de Banco · 1 ejecuta la equivalencia · 7 entregan en QMetry · 2 son herramientas manuales de soporte.

---

## 4. Aspecto tecnico — como funciona la matriz de equivalencia

Es el nucleo del testing agentico. Por **cada caso de prueba** se ejecutan tres vias y se comparan.

### 4.1 Las dos pasadas de ejecucion

```
Pasada 1 (SP directo, Sybase):   snapshot_pre  ->  PRE  ->  EXEC del SP     ->  snapshot_post
Pasada 2 (Microservicio, REST):  snapshot_pre  ->  PRE  ->  llamada REST    ->  snapshot_post
Pasada 3 (Microservicio, gRPC):  igual que REST, por el canal gRPC
```

- **PRE (precondiciones):** dejan la base de datos en el estado exacto que el caso necesita (por ejemplo,
  una orden en estado 'I' y una cuenta con saldo determinado).
- **snapshot_pre / snapshot_post:** se fotografia el estado de las tablas monitoreadas ANTES y DESPUES de
  ejecutar, para saber que cambio realmente cada via.
- **POST (postcondiciones):** restauran/limpian el estado para no contaminar los siguientes casos.

### 4.2 Que se compara (campo a campo)

Para declarar un caso EQUIVALENTE, deben coincidir:
1. **El codigo de retorno** del SP vs el del REST vs el del gRPC (ej. 0, 31004, 120000...).
2. **El contenido de las tablas monitoreadas** tras la ejecucion (snapshot_post), campo a campo, en las
   tres vias.
3. **Los deltas de conteo** (cuantas filas se insertaron/actualizaron en cada tabla).

### 4.3 Los veredictos

| Veredicto | Significado |
|-----------|-------------|
| **EQUIVALENTE** | SP, REST y gRPC producen el mismo codigo y el mismo efecto en datos. Caso OK. |
| **NO_EQUIVALENTE** | Alguna via difiere en el codigo de retorno o en el efecto sobre las tablas. |
| **INCONSISTENCIA** | El codigo coincide pero hay diferencias en el detalle (una via difiere de otra). |
| **SYBASE_FAIL** | El propio SP fallo al ejecutarse (problema de dato/ambiente, no del micro). |

### 4.4 Robustez del motor

- **Recencia del snapshot:** el motor acota la captura a las filas de *esta* ejecucion, para no arrastrar
  datos de corridas anteriores (las ordenes/cuentas se reutilizan).
- **Aislamiento de datos:** los casos que comparten ordenes/cuentas se agrupan para no pisarse cuando la
  ejecucion corre en paralelo.
- **Manejo de nulos y tipos:** se preserva la semantica de NULL de Sybase y los tipos monetarios/enteros,
  para que la comparacion sea fiel y no genere falsos positivos.

---

## 5. Documentacion generada automaticamente

La misma IA que prueba, documenta — en una sola corrida:

- **Casos de Prueba (CP):** el documento que entrega el banco, validado, normalizado y corregido por
  nuestros agentes (ya no se generan desde cero).
- **Matriz de Equivalencia:** el resultado (veredicto) de cada caso en las tres vias.
- **Entrega QMetry:** ejecucion formal sobre la que el banco prueba y levanta defectos.

Ambos equipos documentan: QA produce lo anterior; Migracion documenta la parte tecnica del micro
(arquitectura/contratos), el codigo/build y su propio analisis funcional del SP.

---

## 6. Ventajas del testing agentico

| Ventaja | Detalle |
|---------|---------|
| **Velocidad** | El ciclo completo por SP corre en horas, no semanas. |
| **Cobertura total** | El banco entrega el alcance completo de casos; los agentes lo validan y ejecutan sin recortes por falta de tiempo. |
| **Consistencia** | Mismas reglas en cada corrida; sin fatiga ni criterio variable humano. |
| **Trazabilidad** | Cada caso de prueba del banco se valida contra el SP (fuente de verdad). |
| **Repetibilidad** | Re-ejecutar la matriz completa es inmediato (util tras cada correccion). |
| **Deteccion temprana** | La equivalencia estricta destapa divergencias REST/gRPC que una prueba manual podria pasar por alto. |
| **Sin esfuerzo adicional** | El CP validado y la matriz de equivalencia quedan listos sin trabajo manual extra. |

---

## 7. Metricas y ahorro de tiempo (por SP)

| Enfoque | Tiempo por SP |
|---------|---------------|
| **Testing agentico** | ~ 3-5 horas (estimado) |
| **QA manual** | **81.45 horas** |

**Desglose del QA manual (por SP):**

| Actividad | Horas |
|-----------|------:|
| Creacion de casos de prueba (TC) | 35.20 |
| Ejecucion de las pruebas | 22.25 |
| Resto de la documentacion (CU / UML / logica) | 16.00 |
| Carga en QMetry | 8.00 |
| **Total** | **81.45** |

**Lectura del ahorro:** el ciclo agentico realiza el mismo alcance (generacion + ejecucion +
documentacion + entrega) en una fraccion del tiempo. A ~4 horas por SP frente a 81.45 horas manuales, el
factor de aceleracion es de aproximadamente **20x**, ademas de liberar al QA de tareas repetitivas para
que se concentre en analisis y en la relacion con el banco.

> **Nota sobre las cifras:** el tiempo del QA manual (81.45 h) corresponde al desglose real de
> actividades. El del ciclo agentico (~3-5 h) es una estimacion.

---

## 8. En resumen

- **14 agentes de IA** cubren de punta a punta el ciclo de QA de una migracion (mas 2 herramientas
  manuales de soporte: Query Plan y Gestor QA).
- De **~81 horas** de trabajo manual a **unas horas** por SP (aprox. **20x** mas rapido).
- **Modelo banco-first:** el banco entrega los casos de prueba con datos reales; nuestros agentes los
  validan, completan y ejecutan — ya no se generan casos de uso ni casos de prueba desde cero.
- **Pruebas + matriz de equivalencia** en una sola corrida. UML y Documento de Logica ya no son parte de
  los entregables de QA.
- El **SP original es la fuente de verdad**; la equivalencia SP vs REST vs gRPC es el estandar de aceptacion.
- Proceso **repetible, consistente y trazable** en cada ejecucion, con puntos de control humanos (el banco
  entrega y aprueba los casos de prueba antes de la matriz; el banco prueba sobre QMetry y levanta los
  defectos).

# Correo — Entrega de agentes de validación de casos de prueba (01, 02 y 03)

**Asunto:** Entrega de agentes de validación de casos de prueba (Agentes 01, 02 y 03)

---

Estimado equipo de Banco [Bolivariano],

Les hacemos llegar el paquete con los **3 agentes de IA que validan y corrigen los documentos de casos de prueba** dentro del pipeline de migración de Stored Procedures a microservicios, para que puedan ejecutarlos de forma independiente en su propio ambiente.

**¿Qué hacen estos agentes?**

- **Agente 01 (Validador/Normalizador):** valida el formato del documento de casos de prueba que entrega Banco contra la plantilla estándar, y ejecuta un *discovery* de solo lectura contra Sybase para confirmar que los datos (cuentas, IDs) referenciados en cada caso existen.
- **Agente 02 (Validador de ejecutabilidad):** traza el Stored Procedure real línea por línea y valida contra la base de datos que cada caso de prueba sea **efectivamente ejecutable** (no solo que el dato exista, sino que el resultado esperado sea alcanzable). Genera un reporte con hallazgos y propuestas de corrección concretas.
- **Agente 03 (Corrector):** aplica las correcciones propuestas por el Agente 02 directamente al documento, de forma quirúrgica (nunca reescribe ni elimina casos de prueba).

Los tres operan en **modo de solo lectura sobre la base de datos** — ninguno ejecuta INSERT, UPDATE ni DELETE contra Sybase.

**Qué incluye el paquete adjunto** (`paquete-agentes-qa-01-02-03`, ~240 KB):

- Los 3 agentes, listos para copiar a la carpeta `.claude/agents/` de su repositorio.
- Los 4 scripts deterministas de soporte + el conector a Sybase, con la estructura de carpetas exacta que necesitan (no requiere modificar rutas).
- Un **instructivo completo** (`INSTRUCTIVO-AGENTES-01-02-03.md`) con: cómo funciona el pipeline, requisitos de ambiente, configuración de conexión a Sybase, cómo invocar cada agente, cómo verificar que el ambiente quedó bien montado, y un ejemplo real de ejecución (incluyendo tiempos de referencia).

**Requisitos principales de su lado** (detalle completo en el instructivo):

- Ambiente Linux o macOS (no Windows nativo).
- Python 3.7+ — sin dependencias de terceros, solo librería estándar.
- Cliente `tsql` de FreeTDS instalado, con conectividad de red hacia su servidor Sybase ASE.
- Un usuario de Sybase de **solo lectura** (los agentes no requieren, ni deberían tener, permisos de escritura).
- Claude Code (u otro runtime compatible) con acceso a un modelo Claude.

Quedamos atentos a cualquier duda durante la puesta en marcha, y con gusto acompañamos la primera ejecución si lo consideran útil.

Saludos,
[Tu nombre]

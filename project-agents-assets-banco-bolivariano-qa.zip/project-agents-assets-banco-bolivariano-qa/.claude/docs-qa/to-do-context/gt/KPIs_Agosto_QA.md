# KPIs Agosto 2026 — Equipo QA

> **Marco de referencia:** `propuesta_medicion_qa_agentico.md` (misma carpeta) — modelo de 3 factores
> (Calidad, Eficiencia, Eficacia), calculados desde la tabla `tasks` del Gestor QA (Supabase).
> **Periodo:** tareas con `dueDate` en agosto 2026 (definicion de "tareas planeadas del periodo" segun
> la propuesta, seccion 3).
> **Personas:** Juan Pablo Sanabria Moscoso, Gengis Hidalgo Guevara, William Nieto Rico, Nicolas
> Rodriguez Mejia.
> **Fuente:** consulta en vivo a Supabase (`gestor_qa_client.py`), no hojas de calculo paralelas.

---

## 0. Nota metodologica importante (leer antes de los numeros)

La propuesta define 3 factores, cada uno con su campo fuente en `tasks`:

| Factor | Campo que requiere | ¿Existe en Supabase hoy? |
|--------|---------------------|---------------------------|
| **Eficiencia** | `status`, `dueDate`, `updatedAt` | **Si** — son campos que ya existian antes de la propuesta |
| **Calidad** | `impactoDevolucion` (Alto/Medio/Bajo) | No existe ese campo literal, **pero SI hay un proxy real y poblado**: las tareas `kind="Correccion"` (creadas cuando Banco u otra revision devuelve un defecto) traen `priority` (Alta/Media/Baja) — se usa como sustituto de `impactoDevolucion` con los mismos pesos 3/2/1 de la propuesta. |
| **Eficacia** | `devoluciones` (entero) | El campo literal sigue sin existir, **pero desde 2026-08-31 hay un proxy validado y poblado** (ver nota siguiente). |

**Definicion operativa de Calidad usada en este reporte:** cada tarea `kind="Correccion"` = 1 devolucion;
su `priority` = el nivel de impacto (Alta=3, Media=2, Baja=1); se atribuye al `memberId` que la tarea
tiene asignado en Gestor QA **hoy** (no al autor original del entregable si difiere — ver nota de
atribucion en la seccion 2). Es una decision de modelado explicita, no el campo literal `impactoDevolucion`
de la propuesta original (ese sigue sin existir).

**Validacion 2026-08-31 — ¿un ticket Jira tipo "Defecto" es iteracion o devolucion?** Se verifico contra la
API real de Jira: `NCBE-1644` y `NCBE-1637` (ambos issuetype **"Defecto"**, subtareas de la Historia
`NCBE-1175` = pa_fir_consulta_condicion) son exactamente los 2 eventos ya modelados como tarea `Correccion`
para Calidad. En cambio `NCBE-1580` (la 3ra tarea `Correccion` original) es issuetype **"Tarea"** en Jira,
no "Defecto" — un falso positivo interno del motor QA, nunca reportado a Banco. Conclusion: un ticket Jira
"Defecto" es una **devolucion** (Banco/QA rechaza un entregable ya migrado), no una "iteracion" — el campo
`iterations`/TSK-04 (contador de retroceso `review/done -> active/backlog` dentro de una misma tarea de
Gestor QA) mide algo distinto y hoy no tiene relacion con el tipo de ticket Jira. Por tanto: **el conteo de
tickets Jira "Defecto" por persona/periodo (equivalente a la tarea `Correccion` que ese defecto genera en
Gestor QA) se adopta como el proxy real de `devoluciones` para Eficacia** (ver seccion 3).

**Hallazgo al validar (cobertura incompleta detectada):** al listar en Jira todos los "Defecto" creados en
agosto 2026, aparecieron 6 defectos reales contra entregables de Gengis (4: `NCBE-1768`, `NCBE-1770`,
`NCBE-1826` sobre pa_cp_cval_ctacnb; `NCBE-1853` sobre pa_pag_brpt_billetes_altadeno) y Juan Pablo (2:
`NCBE-1769` sobre pa_cc_cval_catcctecnb; `NCBE-1948` sobre sp_cnb_consulta_saldo) que **no tenian** tarea
`Correccion` en Gestor QA (solo existian las 3 originales). Se crearon retroactivamente el 2026-08-31 para
que Calidad y Eficacia reflejen los defectos reales — los numeros de Calidad de Gengis y Juan Pablo en este
reporte **cambian frente a la version anterior** (ver seccion 2). Nota de limpieza: estas 6 tareas se
crearon directo en `status="done"` para documentar un hecho ya cerrado en Jira; su `updatedAt` en Gestor QA
queda en la fecha de registro (2026-08-31), no en la fecha real de resolucion en Jira (documentada en la
descripcion de cada tarea, todas resueltas 1-3 dias despues de creadas) — esto las hace aparecer "no a
tiempo" en la tabla de Eficiencia (seccion 1) por un artefacto de cuando se hizo el registro, no por atraso
real de entrega.

**Hallazgo relacionado (aun sin resolver):** sí existe un campo `iterations` en el esquema de `tasks` (no
forma parte de la propuesta original). Sigue poblado en solo **1 de 98** tareas del Gestor QA (=1, la tarea
"Preparar presentacion sobre testing en BB") — ninguna de las 9 tareas `Correccion` (incluidas las 6 nuevas)
lo tiene poblado, consistente con la conclusion de que "Defecto" Jira y `iterations` son señales distintas.

---

## 1. Eficiencia — "¿se cumple lo planeado a tiempo?" (Factor 2, unico calculable)

**Formula (de la propuesta):**
```
Eficiencia (%) = ( Tareas done dentro de plazo / Tareas planeadas del periodo ) x 100
Tareas planeadas del periodo = tareas con dueDate en agosto 2026
Dentro de plazo = status="done" Y updatedAt.fecha <= dueDate.fecha
```

| Persona | Tareas planeadas (agosto) | Terminadas a tiempo | **Eficiencia** |
|---|---|---|---|
| Juan Pablo Sanabria Moscoso | 5 | 0 | **0.0%** |
| Gengis Hidalgo Guevara | 24 | 5 | **20.8%** |
| William Nieto Rico | 4 | 0 | **0.0%** |
| Nicolas Rodriguez Mejia | 15 | 9 | **60.0%** |

### 1.1 Lectura del dato — contexto que la formula sola no muestra

Estos numeros son reales pero necesitan contexto para no mal-interpretarse:

- **Concentracion de vencimientos en una sola fecha:** una parte importante de las tareas "planeadas de
  agosto" de Juan Pablo, Gengis y William tienen `dueDate=2026-08-26`, fecha asignada en bloque al crear
  6 microservicios nuevos (lote 4) el 2026-08-24 — no es una fecha que cada persona haya negociado
  individualmente por tarea.
- **Tareas todavia abiertas (`active`/`backlog`) cuentan como "no a tiempo"** aunque el trabajo siga en
  curso (ej. dependen de que Banco entregue un documento, o de extraer un `.sql` que no estaba
  disponible) — la formula no distingue "atrasada por falta de insumo externo" de "atrasada por el
  ejecutor".
- **Nicolas y Gengis tienen el volumen mas alto** de tareas planeadas en agosto (15 y 24
  respectivamente) frente a Juan Pablo y William (5 y 4) — el denominador chico de estos ultimos hace que
  cada tarea pese mucho en el porcentaje (ej. William: 1 sola tarea a tiempo ya habria dado 25%).
- **Gengis (20.8%, antes 25.0%) y Juan Pablo (0.0%, sin cambio numerico pero con denominador mayor)
  bajan/se mantienen bajos en parte por un artefacto de registro, no por atraso real:** las 6 tareas
  `Correccion` creadas retroactivamente el 2026-08-31 (ver seccion 0) cuentan "no a tiempo" porque su
  `updatedAt` es la fecha de registro en Gestor QA, mientras que en Jira esos defectos se resolvieron en
  1-3 dias reales (marcadas con `*` en el detalle 1.2). Sin esas 6 tareas, Gengis seguiria en 25.0%
  (5/20) y Juan Pablo en 0.0% (0/3) — el numero de Eficiencia "real-tiempo" no cambio, solo el de
  Eficiencia "con el registro completo hasta hoy".

### 1.2 Detalle de tareas planeadas de agosto (para auditar el numero)

<details>
<summary>Juan Pablo Sanabria Moscoso (5 tareas)</summary>

| Tarea | Status | dueDate | updatedAt | ¿A tiempo? |
|---|---|---|---|---|
| Generar ME - cnb-mso-pa-cval-catcctecnb | done | 2026-08-26 | 2026-08-27 | No |
| Generar Matriz de Equivalencia - sp_cnb_consulta_saldo | active | 2026-08-21 | 2026-08-24 | No |
| Generar ME cnb-mso-pa-cval-catcctecnb | backlog | 2026-08-21 | 2026-08-19 | No |
| NCBE-1769: Corregir mensaje_debug adicional (pa_cc_cval_catcctecnb) * | done | 2026-08-24 | 2026-08-31 | No* |
| NCBE-1948: Corregir error 500/datos NULL (sp_cnb_consulta_saldo) * | done | 2026-08-27 | 2026-08-31 | No* |

`*` = tarea `Correccion` registrada retroactivamente 2026-08-31 (ver seccion 0); Jira registra resolucion
real 2026-08-27 (NCBE-1769) y 2026-08-27/creacion sin fecha de cierre distinta (NCBE-1948).

</details>

<details>
<summary>Gengis Hidalgo Guevara (24 tareas)</summary>

| Tarea | Status | dueDate | updatedAt | ¿A tiempo? |
|---|---|---|---|---|
| Capacitación de Qmetry | done | 2026-08-26 | 2026-08-31 | No |
| Generar Matriz de Equivalencia - sp_retefec_transval_rc | active | 2026-08-20 | 2026-08-24 | No |
| QueryPlan deposito | done | 2026-08-11 | 2026-08-19 | No |
| QueryPlan firmantes | done | 2026-08-11 | 2026-08-19 | No |
| Qmetry retiro | done | 2026-08-04 | 2026-08-06 | No |
| Qmetry firmante | done | 2026-08-04 | 2026-08-06 | No |
| Qmetry deposito | done | 2026-08-04 | 2026-08-06 | No |
| QueryPlan retiro | done | 2026-08-11 | 2026-08-19 | No |
| QueryPlan fir_especial | done | 2026-08-18 | 2026-08-19 | No |
| Generar QMetry - cnb-mso-pa-cval-ctacnb | done | 2026-08-26 | 2026-08-25 | **Si** |
| QueryPlan con_especial | done | 2026-08-18 | 2026-08-19 | No |
| QueryPlan condicion | done | 2026-08-18 | 2026-08-19 | No |
| NCBE-1637: Corregir URLs de entrega REST/gRPC no reproducibles | done | 2026-08-13 | 2026-08-19 | No |
| Cargar TC en Gestor QA - cnb-mso-pag-reporte-billetes | done | 2026-08-26 | 2026-08-25 | **Si** |
| Generar ME - cnb-mso-pa-cval-ctacnb | done | 2026-08-26 | 2026-08-26 | **Si** |
| Generar Matriz de Equivalencia - pa_cp_cval_ctacnb | done | 2026-08-21 | 2026-08-31 | No |
| Generar QMetry - cnb-mso-pag-reporte-billetes | done | 2026-08-26 | 2026-08-25 | **Si** |
| NCBE-1580: Matriz de equivalencia al 100% para IMIX | backlog | 2026-08-28 | 2026-08-31 | No |
| Cargar TC en Gestor QA - cnb-mso-pa-cval-ctacnb | done | 2026-08-26 | 2026-08-25 | **Si** |
| Generar ME - cnb-mso-pag-reporte-billetes | done | 2026-08-26 | 2026-08-31 | No |
| NCBE-1768: Corregir mensaje_debug adicional (pa_cp_cval_ctacnb) * | done | 2026-08-21 | 2026-08-31 | No* |
| NCBE-1770: Corregir mensaje Sybase no reflejado TC33 (pa_cp_cval_ctacnb) * | done | 2026-08-24 | 2026-08-31 | No* |
| NCBE-1826: Completar comandos de ejecucion TC18 (pa_cp_cval_ctacnb) * | done | 2026-08-25 | 2026-08-31 | No* |
| NCBE-1853: Corregir datos incorrectos TC02/TC04 (pa_pag_brpt_billetes_altadeno) * | done | 2026-08-25 | 2026-08-31 | No* |

`*` = tarea `Correccion` registrada retroactivamente 2026-08-31 (ver seccion 0); Jira registra resolucion
real 2026-08-24, 2026-08-25, 2026-08-25 y 2026-08-26 respectivamente (1-3 dias despues de creado el
ticket), no 2026-08-31.

</details>

<details>
<summary>William Nieto Rico (4 tareas)</summary>

| Tarea | Status | dueDate | updatedAt | ¿A tiempo? |
|---|---|---|---|---|
| Generar ME - cnb-mso-pag-cubo-cnb | backlog | 2026-08-26 | 2026-08-24 | No |
| Generar ME cpas-mso-ah-retirosl | active | 2026-08-21 | 2026-08-24 | No |
| Generar QMetry - cnb-mso-pag-cubo-cnb | backlog | 2026-08-26 | 2026-08-24 | No |
| Cargar TC en Gestor QA - cnb-mso-pag-cubo-cnb | backlog | 2026-08-26 | 2026-08-24 | No |

</details>

<details>
<summary>Nicolas Rodriguez Mejia (15 tareas)</summary>

| Tarea | Status | dueDate | updatedAt | ¿A tiempo? |
|---|---|---|---|---|
| Re-verificar y cerrar defectos retiro (2) | done | 2026-08-07 | 2026-08-06 | **Si** |
| NCBE-1644: Corregir manejo de montos con decimales en REST/gRPC | done | 2026-08-13 | 2026-08-14 | No |
| Estandar para campos tipo money QA/Migracion | done | 2026-08-18 | 2026-08-18 | **Si** |
| NCBE-1580: Correcciones matriz de equivalencia - pa_pag_bconcilia | done | 2026-08-27 | 2026-08-27 | **Si** |
| NCBE-1644: Trabajo en resolucion de los decimales | done | 2026-08-27 | 2026-08-27 | **Si** |
| NCBE-1580: Correr agente 04 + configuracion imix y matriz | done | 2026-08-27 | 2026-08-27 | **Si** |
| Revisar codigo de libreria Java - cpas-mso-tr-depositos-rc | done | 2026-08-27 | 2026-08-27 | **Si** |
| Revision 1 - Revisar correcciones de Banco - sp_tr_deposito | done | 2026-08-21 | 2026-08-24 | No |
| Revision 2 - Revisar correcciones de Banco - sp_tr_deposito | done | 2026-08-21 | 2026-08-24 | No |
| Reportar a Banco 2 defectos reales - pa_pag_bconcilia_cnb_imix | done | 2026-08-28 | 2026-08-27 | **Si** |
| Cerrado: scaffold regenerado - pa_pag_bconcilia_cnb_imix | done | 2026-08-27 | 2026-08-27 | **Si** |
| NCBE-1498: Matriz de equivalencia inicial - cpas-mso-tr-depositos | done | 2026-08-27 | 2026-08-27 | **Si** |
| NCBE-1498: Matriz de equivalencia 100% para cpas-mso-tr-depositos | backlog | 2026-08-28 | 2026-08-31 | No |
| Agente-04: busqueda dinamica de CONFIG por lote/funcionalidad | backlog | 2026-08-28 | 2026-08-27 | No |
| Exposicion de decimales, reporte y seguimiento pa_fir_consulta | done | 2026-08-28 | 2026-08-31 | No |

</details>

---

## 2. Calidad — "¿que tan bien salen los entregables la primera vez?" (Factor 1, via proxy)

**Formula (igual a la propuesta, sustituyendo `impactoDevolucion` por `priority` de las tareas
`Correccion`):**
```
Peso por impacto:  Alta = 3   |   Media = 2   |   Baja = 1
Puntos de penalizacion = suma de pesos de las tareas Correccion de esa persona
Indice de Calidad (%) = ( 1 - ( Puntos de penalizacion / (3 x Tareas planeadas de agosto) ) ) x 100
```

| Persona | Correcciones (agosto) | Prioridad | Puntos | Tareas planeadas (agosto) | **Calidad** |
|---|---|---|---|---|---|
| Juan Pablo Sanabria Moscoso | 2 — NCBE-1769 (mensaje_debug catcctecnb), NCBE-1948 (error 500/NULL saldo) | Media, Media | 4 | 5 | **73.3%** |
| Gengis Hidalgo Guevara | 5 — NCBE-1637 (URLs no reproducibles), NCBE-1768/1770/1826 (matriz ctacnb), NCBE-1853 (datos billetes) | Alta, Media, Media, Media, Media | 11 | 24 | **84.7%** |
| William Nieto Rico | 0 | — | 0 | 4 | **100.0%** |
| Nicolas Rodriguez Mejia | 2 — NCBE-1644 (decimales REST/gRPC), NCBE-1580 (correcciones matriz IMIX) | Media, Media | 4 | 15 | **91.1%** |

**Cambio frente al reporte anterior (2026-08-31):** Juan Pablo pasa de 100.0% a 73.3% y Gengis de 95.0% a
84.7% tras la validacion contra Jira que encontro 6 defectos tipo "Defecto" sin tarea `Correccion`
asociada (ver seccion 0). Nicolas y William no cambian.

### 2.1 Nota de atribucion (decision explicita para este reporte)

**NCBE-1644** es un defecto que Banco reporto en Jira contra el entregable de **pa_fir_consulta_condicion**,
con el asignado original de Jira registrado como **Gengis** (autor del entregable) — pero la tarea de
correccion en Gestor QA quedo asignada a **Nicolas** (quien hizo el fix real). Por decision explicita para
este reporte, la devolucion se cuenta contra **quien tiene la tarea `Correccion` asignada en Gestor QA
hoy** (Nicolas), no contra el autor original del entregable (Gengis) — se prioriza consistencia con el
resto de los KPIs (todos calculados desde `memberId` de `tasks`) sobre reconstruir el historial de Jira.
Si se prefiere medir "calidad del entregable original" en vez de "calidad de quien resuelve", este numero
cambiaria (NCBE-1644 pasaria a penalizar a Gengis, no a Nicolas).

### 2.2 Limitacion de cobertura (leer antes de comparar personas)

Ahora existen **9 tareas `Correccion`** en todo el Gestor QA (3 originales + 6 encontradas al validar
contra Jira el 2026-08-31). Solo **William llega a 100%** porque nunca se le ha creado una tarea de
correccion ni aparece en Jira como assignee de un "Defecto" — con este volumen de muestra, 100% significa
"sin dato negativo", no "calidad probada" (William tambien tiene el denominador mas chico, 4 tareas).
Gengis y Nicolas siguen teniendo mas entregables en produccion generando esta señal (mas exposicion), lo
cual tiende a bajarles el numero frente a quienes tienen menos entregables aun corriendo en Banco — con la
validacion de Jira, Juan Pablo se suma a ese grupo (2 defectos reales, ya no 0).

---

## 3. Eficacia — "¿cuantas veces el entregable tuvo que volver?" (Factor 3, via proxy Jira)

**Motivo por el que antes era NO CALCULABLE:** requiere `devoluciones` (entero). Ese campo literal sigue
sin existir en `tasks`. **Validado el 2026-08-31** (ver seccion 0): un ticket Jira tipo **"Defecto"**
contra el entregable de un microservicio es la devolucion real que la propuesta quiere medir — y hoy tiene
una correspondencia 1:1 verificada con las tareas `kind="Correccion"` de Gestor QA. Se adopta el conteo de
esas tareas por persona como proxy no ponderado de `devoluciones` (a diferencia de Calidad, que pondera por
`priority`; aqui cada devolucion pesa 1, sin importar severidad — asi mide la propuesta este factor).

**Formula (analoga a Calidad, sin ponderacion):**
```
Eficacia (%) = ( 1 - ( Devoluciones del periodo / Tareas planeadas del periodo ) ) x 100
Devoluciones del periodo = tareas kind="Correccion" de esa persona con dueDate en agosto 2026
```

| Persona | Devoluciones (agosto) | Tareas planeadas (agosto) | **Eficacia** |
|---|---|---|---|
| Juan Pablo Sanabria Moscoso | 2 | 5 | **60.0%** |
| Gengis Hidalgo Guevara | 5 | 24 | **79.2%** |
| William Nieto Rico | 0 | 4 | **100.0%** |
| Nicolas Rodriguez Mejia | 2 | 15 | **86.7%** |

**Por que Eficacia y Calidad dan numeros distintos con los mismos datos:** Calidad pondera por severidad
(`priority`), Eficacia solo cuenta ocurrencias. Ejemplo Gengis: 5 devoluciones (1 Alta + 4 Media) dan
Calidad=84.7% (penalizado mas fuerte por la Alta) pero Eficacia=79.2% (cada devolucion pesa igual,
independiente de severidad) — son lecturas complementarias, no la misma pregunta.

**Limitacion que se mantiene:** el campo `iterations` (contador de retroceso `review/done -> active/backlog`
dentro de Gestor QA, TSK-04) sigue en 1/98 tareas — no es la fuente de este numero y no se usa aqui; se
mantiene solo como dato de contexto en la seccion 0.

---

## 4. Carga de trabajo total (contexto complementario, no es un KPI de la propuesta)

Todas las tareas asignadas a cada persona en el Gestor QA, sin filtrar por periodo — para dar una
foto completa de volumen y tipo de trabajo detrás del número de Eficiencia.

| Persona | Total tareas | done | active | backlog | Prueba | Documentacion | Automatizacion | Correccion |
|---|---|---|---|---|---|---|---|---|
| Juan Pablo Sanabria Moscoso | 14 | 12 | 1 | 1 | 8 | 4 | 0 | 2 |
| Gengis Hidalgo Guevara | 26 | 24 | 1 | 1 | 6 | 13 | 2 | 5 |
| William Nieto Rico | 4 | 0 | 1 | 3 | 2 | 1 | 1 | 0 |
| Nicolas Rodriguez Mejia | 30 | 28 | 0 | 2 | 21 | 4 | 3 | 2 |

*(Totales actualizados 2026-08-31 tras crear las 6 tareas `Correccion` encontradas al validar contra Jira —
ver seccion 0. Total general del Gestor QA: 98 tareas, antes 92.)*

---

## 5. Conclusiones y recomendacion

1. **Los 3 factores ya son medibles con datos reales.** Calidad y Eficacia comparten el mismo proxy
   validado el 2026-08-31: tickets Jira tipo "Defecto" = tarea `kind="Correccion"` en Gestor QA (Calidad
   pondera por `priority`, Eficacia cuenta ocurrencias sin ponderar). El campo literal `impactoDevolucion`
   sigue sin existir, y `devoluciones`/`iterations` siguen sin poblarse — los 3 numeros de este reporte son
   proxies deliberados, no los campos originales de la propuesta.
2. **Al validar la fuente Jira aparecieron 6 defectos reales sin registrar** en Gestor QA (4 de Gengis, 2
   de Juan Pablo, agosto 2026) — se crearon retroactivamente. Esto bajo Calidad de Juan Pablo (100.0% ->
   73.3%) y de Gengis (95.0% -> 84.7%), y es lo que permitio calcular Eficacia por primera vez. Senal clara
   de que el proceso de "reportar defecto en Jira -> crear tarea Correccion en Gestor QA" no esta corriendo
   de forma consistente hoy — sin ese paso, Calidad/Eficacia subestiman a quien tiene mas defectos reales.
3. Nicolas Rodriguez (15 tareas) y Gengis Hidalgo (24 tareas) tienen la muestra mas grande y por tanto los
   numeros mas representativos de los 3 factores; Juan Pablo (5) y William (4) tienen muestras chicas donde
   1 sola tarea cambia el resultado varios puntos. William es hoy la unica persona en 100% de Calidad y
   Eficacia, y no porque tenga menos exposicion (denominador igual de chico que Juan Pablo) sino porque no
   aparece con ningun defecto en Jira ni en Gestor QA este mes.
4. **Recomendacion concreta:**
   - Formalizar el proxy: cada ticket Jira "Defecto" contra un entregable migrado debe generar, en el
     mismo momento, una tarea `kind="Correccion"` en Gestor QA con `priority` = prioridad del ticket Jira —
     hoy ese paso es manual y se detecto que se salto 6 veces en agosto.
   - Decidir si `Correccion.priority` (Calidad) y el conteo de `Correccion` (Eficacia) quedan como los
     proxies oficiales de `impactoDevolucion`/`devoluciones`, o si se prefiere poblar los campos literales
     de la propuesta — de cualquier forma, decidirlo explicitamente para que el reporte de septiembre no
     dependa de una interpretacion ad-hoc como esta.
   - Resolver la ambiguedad de atribucion de la seccion 2.1 (autor original vs. quien corrige) como
     politica del equipo, no caso por caso.
   - Revisar periodicamente Jira (issuetype="Defecto", creado en el periodo) contra las tareas `Correccion`
     de Gestor QA para detectar gaps como el de este mes antes del cierre del reporte, no despues.

---

*Reporte generado a partir de una consulta en vivo a Supabase (Gestor QA) y a la API de Jira el
2026-08-31/09-01. No se fabrico ningun dato: donde el campo requerido no existe, se uso un proxy validado
y documentado explicitamente (Calidad, Eficacia), o se declaro no calculable (ninguno este mes).*

# Consolidación de Agentes de IA del Ciclo de QA — Explicación Técnica (soporte ISO/IEC 42001)

> **Propósito:** inventario técnico completo de los agentes de inteligencia artificial que operan el
> ciclo de pruebas QA de la migración de Stored Procedures (Sybase) a microservicios (REST/gRPC), para
> soportar la documentación de un Sistema de Gestión de IA (SGIA) conforme a ISO/IEC 42001 — inventario
> de sistemas de IA, propósito y alcance de cada uno, modelo base, capacidades habilitadas, entradas y
> salidas, y los controles de supervisión humana y de no-invención de datos aplicados.
> **Alcance:** los 23 agentes definidos en `.claude/agents/` de este repositorio (línea de QA), más las
> 3 skills deterministas que dos de ellos invocan.
> **Fecha:** 2026-09-21

---

## 1. Marco general del sistema de IA

### 1.1 Principio de diseño: separar lo determinista de lo generativo

Cada agente de este catálogo sigue el mismo patrón de diseño de gobernanza: el **razonamiento con
criterio** (interpretación de lenguaje natural, redacción, juicio funcional) lo hace el modelo de IA;
la **ejecución mecánica** (parseo, cálculo, llamadas HTTP/SQL, escritura de artefactos) la hace un
**script determinista** en Python que el agente invoca y cuya salida se limita a reportar. Esta
frontera está declarada explícitamente en la mayoría de los agentes ("frontera agentica exacta", "wrapper
delgado", "no inventa X, lo hace el script Y") y es el principal control de riesgo del sistema: acota
dónde puede haber alucinación o variabilidad de un modelo de lenguaje, y dónde el resultado es 100%
reproducible.

### 1.2 Modelos de IA en uso

| Modelo declarado | Agentes que lo usan | Nivel de razonamiento (`effort`) |
|---|---|---|
| `opus` (Claude Opus, alias de familia) | 16 agentes — todo el bloque de generación/documentación/UML/matriz | `high` en casi todos; `medium` en `auto-01` |
| `claude-4.6-opus` (versión de modelo fijada) | 7 agentes del bloque QMetry | `high` |
| `sonnet` (Claude Sonnet) | 1 agente — `agente-gestor-qa` | `medium` |

No hay agentes sobre modelos de terceros; toda la familia usada es Claude (Anthropic). El nivel de
razonamiento (`effort`) más alto se reserva para las tareas con mayor carga de interpretación (análisis
funcional del SP, auditoría UML, redacción narrativa); el más bajo, para tareas de asistencia
conversacional acotada (Gestor QA).

### 1.3 Controles de supervisión humana comunes a todo el catálogo

- **`allowed_write_paths` explícito:** la mayoría de los agentes declaran en su frontmatter las únicas
  rutas del repositorio donde tienen permiso de escritura. Escribir fuera de esa lista es una violación
  de diseño, no una opción.
- **No inventar dato ni contenido de negocio:** repetido en casi todas las descripciones ("NO inventa
  significados de siglas", "NO inventa TCs", "NO inventa cycle IDs", "NO genera JSON manualmente"). Ante
  ambigüedad, el agente marca la interpretación como tal (`"(interpretado: ...)"`) o se detiene y reporta
  `BLOCKED`, nunca rellena el vacío por su cuenta.
- **Trazabilidad a evidencia real:** toda afirmación factual debe citar su fuente (línea del `.sql` del
  SP, un `evidence_id`, una fila de `tc_gen`, una consulta real contra Sybase). Este es el mecanismo
  anti-alucinación transversal del sistema.
- **Autonomía condicionada (dry-run por defecto):** todos los agentes que pueden mutar un sistema externo
  (QMetry, Supabase/Gestor QA) operan en modo simulación por defecto; la mutación real requiere una
  bandera explícita (`--execute`) autorizada por un humano en el mismo turno de conversación.
- **Verificación post-mutación obligatoria:** en QMetry, un HTTP 2xx nunca se considera éxito por sí solo
  — el agente relee el estado remoto después de cada escritura para confirmar que el cambio se aplicó
  (`acceptedByHttp != verified`).
- **Human-gate ante ambigüedad de negocio genuina:** es la única condición de parada de los pipelines
  autónomos; todo lo demás se resuelve o se reporta como bloqueado, nunca se fuerza.

---

## 2. Inventario de agentes por grupo funcional

### Grupo A — Análisis funcional del SP (fuente: SQL del SP + `tc_gen` consolidado)

| Agente | Modelo / effort | Herramientas | Entrada | Salida |
|---|---|---|---|---|
| `agente-qa-auto-00-use-cases` | opus / high | Read, Glob, Grep, Write | `.sql` del SP (sybase-local) + `tc_gen` + código Java del micro | Casos de Uso funcionales (`qa_casos_prueba` — sección CU) |
| `agente-qa-doclogica-00-generador` | opus / high | Read, Glob, Grep, Write | `.sql` del SP + `tc_gen` (`test_cases.json`, `raw_metadata.json`) | Documento de Lógica del SP (12 secciones formato banco) |
| `agente-qa-tc-enricher` | opus / high | Read, Bash, Write | `test_cases.json` existente | mismo archivo enriquecido in-place (descripciones ES, D6, Error Guessing, cobertura) |

**`agente-qa-auto-00-use-cases`** — Genera Casos de Uso interpretando el comportamiento leyendo
directamente el `.sql` del SP (no solo metadatos ya extraídos), bajo normas IEEE 829 / ISO IEC 29119-3 /
ISTQB / Gherkin 6. No inventa significado de siglas: si infiere un propósito no documentado, lo marca
explícitamente como interpretación. Exige cobertura total — todo servicio/branch nombrado en el SP debe
tener al menos un Caso de Uso.

**`agente-qa-doclogica-00-generador`** — Hermano funcional del anterior con distinto entregable: el
Documento de Lógica (identificación, parámetros E/S, traducción de lógica, matriz condición→efecto en
datos, SPs dependientes, catálogos, códigos de error, manejo transaccional). Cada dato es trazable a una
línea concreta del SP (`Lnnn`) o a una fila de `tc_gen`. Tiene modo librería nativo: genera un documento
por cada SP hijo (librería) del SP padre, replicando el mismo estándar.

**`agente-qa-tc-enricher`** — Trabaja sobre un `test_cases.json` ya existente, sin reconstruirlo: agrega
descripciones en español, evalúa el criterio D6, propone hasta 5 casos de Error Guessing adicionales y
calcula la cobertura funcional resultante. Es un enriquecimiento incremental, no una regeneración.

---

### Grupo B — Procesamiento de Casos de Prueba entregados por el Banco (modelo banco-first)

Desde 2026, el banco entrega siempre los casos de prueba con datos reales en un documento plantilla; los
agentes de este grupo ya **no generan** casos desde cero — los **validan, completan y corrigen** contra
el SQL del SP y contra Sybase real.

| Agente | Modelo / effort | Herramientas | Entrada | Salida |
|---|---|---|---|---|
| `agente-qa-auto-01-test-cases` | opus / medium | Read, Glob, Grep, Bash | documento de casos del banco + SQL del SP | `qa_casos_prueba.md` normalizado + `data_discovery.json` |
| `agente-qa-auto-02-test-cases-validator` | opus / high | Read, Glob, Grep, Bash, Write | `qa_casos_prueba.md` + ambiente Sybase | `tc-validation-report.json` |
| `agente-qa-auto-03-test-cases-corrector` | opus / high | Read, Glob, Grep, Edit | reporte del validador (02) | `qa_casos_prueba.md` corregido |
| `agente-qa-auto-04-test-cases-config` | opus / high | Read, Glob, Grep, Write | Controller + ExceptionHandler + Response DTO + `.proto` del micro + output params del SP | sección `CONFIG` + `DICCIONARIO SP-REST` |

**`agente-qa-auto-01-test-cases`** — Es un "wrapper delgado" sin juicio generativo sobre el script
determinista `validate_external_tc.py`: valida el formato del documento del banco contra la plantilla
oficial, prueba que el parser lo puede leer, normaliza la estructura en orden canónico, y ejecuta un
*discovery* mecánico contra Sybase real (reutiliza los `SELECT` que el banco ya escribió en las
precondiciones, nunca inventa consultas nuevas), clasificando cada precondición en verificable / sin
dato / pendiente de traducir.

**`agente-qa-auto-02-test-cases-validator`** — Confirma que cada caso sea *ejecutable* en el ambiente
real: coherencia de datos, validez de precondiciones/postcondiciones SQL, trazabilidad del resultado
esperado al comportamiento real del SP. Ejecuta consultas de validación contra Sybase para no aceptar un
caso que no se pueda correr.

**`agente-qa-auto-03-test-cases-corrector`** — Aplica exclusivamente las correcciones ya propuestas y
verificadas por el validador (02); no valida ni consulta Sybase por su cuenta — separación estricta de
responsabilidades entre "encontrar el problema" y "aplicar el arreglo".

**`agente-qa-auto-04-test-cases-config`** — Se ejecuta después de que el microservicio ya existe en
código: lee el contrato real (Controller REST, manejador de excepciones, DTO de respuesta, `.proto`
gRPC, parámetros de salida del SP) para construir el diccionario de mapeo SP↔REST↔gRPC que la matriz de
equivalencia usará como fuente de verdad de qué campo corresponde a qué parámetro.

---

### Grupo C — Ejecución y Matriz de Equivalencia (el núcleo del sistema)

| Agente | Modelo / effort | Herramientas | Entrada | Salida |
|---|---|---|---|---|
| `agente-qa-auto-05-matrix-flow` | opus / high | Read, Glob, Grep, Bash, Write | `qa_casos_prueba.md` + microservicio desplegado | Matriz de equivalencia (veredicto por caso) |

**`agente-qa-auto-05-matrix-flow`** — Punto único de entrada del pipeline QA autónomo basado en archivo;
no modifica código productivo. Por cada caso ejecuta tres vías (SP directo contra Sybase, REST, gRPC),
fotografía el estado de las tablas monitoreadas antes y después (`snapshot_pre`/`snapshot_post`), y
compara: código de retorno, contenido de tablas afectadas campo a campo, y deltas de conteo de filas. El
veredicto resultante (`EQUIVALENTE` / `NO_EQUIVALENTE` / `INCONSISTENCIA` / `SYBASE_FAIL`) es puramente el
resultado de esa comparación determinista — el agente orquesta la ejecución, no decide el veredicto por
criterio propio. Este es el motor que sustituye la ejecución manual de pruebas por un humano.

---

### Grupo D — Documentación UML

| Agente | Modelo / effort | Herramientas | Entrada | Salida |
|---|---|---|---|---|
| `agente-qa-uml-00-orquestador` | opus / high | Read, Glob, Grep, Bash | `sp_name`, repos del micro y de la librería | diagramas `.puml` + PDF, vía script `uml_gen` |
| `agente-qa-uml-01-class-descriptions` | opus / high | Read, Glob, Grep, Bash, Write | `java-structure.json` + código `.java` real | notas UML de descripción funcional por clase |
| `agente-qa-uml-02-auditor` | opus / high | Read, Glob, Grep, Bash, Write | entregable UML de `uml_gen` (4 vistas) | veredicto ponderado (APROBADO / CON OBSERVACIONES / RECHAZADO) |

**`agente-qa-uml-00-orquestador`** — No escribe una sola línea de PlantUML: todo el contenido `.puml` lo
produce el script determinista `uml_gen`. El agente localiza los insumos, invoca el script, valida la
salida contra un manifiesto de conteos, y exporta a PDF. Si falta un insumo obligatorio, reporta
`BLOCKED` — nunca rellena el vacío inventando contenido.

**`agente-qa-uml-01-class-descriptions`** — Es la única pieza generativa (con criterio) del flujo UML:
interpreta cada clase Java real para redactar una descripción funcional de una línea. Si no puede
determinar el propósito de una clase, la marca explícitamente como "(sin determinar)" en vez de
inventar una descripción plausible. La inyección mecánica de esa descripción como nota UML la hace una
skill determinista aparte (`skill-qa-uml-01-class-descriptions`), no el agente.

**`agente-qa-uml-02-auditor`** — Actúa como auditor UML experto siguiendo el criterio oficial documentado
por el banco. Usa un modelo de severidad ponderada (ejes Conceptual + Sincronía + Persistencia, máximo
10 puntos): los ejes Sincronía y Persistencia se calculan de forma determinista con 0 tokens de modelo
(vía la skill `skill-qa-uml-02-auditor`); el agente solo aporta criterio en el eje Conceptual. Por
defecto opera en modo "solo veredicto" (ahorro de cómputo) y solo redacta el informe completo cuando se
solicita explícitamente para entrega formal al banco.

---

### Grupo E — Documentación de Lógica de Librería (código Java refactorizado, ruta v2)

| Agente | Modelo / effort | Herramientas | Entrada | Salida |
|---|---|---|---|---|
| `agente-qa-doclogica-libreria` | opus / high | Read, Glob, Grep, Bash, Write, Edit | evidencia v2 (enricher determinista) + código Java + SP legacy | documento dual Markdown + DOCX |
| `agente-doclogica-brief-author-v2` | opus / high | Read, Glob, Grep, Bash, Write | evidencia determinista + Java real + SQL legacy real | `agent-brief-v2.json` (capa narrativa) |
| `agente-doclogica-editorial-reviewer-v2` | opus / high | Read, Glob, Grep, Write | render/Markdown ya generado + evidencia + estándar 1.1.0 | `docref-editorial-review-v2.json` (propuestas editoriales) |

**`agente-qa-doclogica-libreria`** — Entrypoint canónico de la ruta v2: la librería (código Java
refactorizado) es el sujeto documentado, el SP es solo el origen/contexto. Encadena evidencia
determinista → brief narrativo → modelo → render → escritores MD/DOCX → *gates* técnico y de contenido →
paquete de entrega, sin ejecutar `push` a menos que se autorice explícitamente. La cantidad de librerías
a documentar es dinámica (1..N), nunca fija.

**`agente-doclogica-brief-author-v2`** — Es la **única frontera agéntica** (no determinista) de todo el
pipeline v2: el único paso que no puede resolverse con código puro es redactar, en español técnico, la
capa narrativa a partir de evidencia ya extraída mecánicamente. Cada afirmación factual debe citar un
`evidence_id` existente — no puede afirmar nada que no tenga soporte verificable. Los repositorios de
código Java y SP legacy son de solo lectura para este agente.

**`agente-doclogica-editorial-reviewer-v2`** — Control de calidad editorial *acotado*: propone
correcciones de ortografía, gramática, puntuación, claridad y terminología sobre el texto ya generado,
pero tiene prohibido explícitamente introducir hechos nuevos, inferencias técnicas, o cambios a nombres
de código, cantidades, obligatoriedad de parámetros o comportamiento transaccional. Nunca edita el
documento final ni publica — solo emite una propuesta que otro paso determinista aplica o descarta.

---

### Grupo F — Entrega en QMetry (Lote 2: ciclo de pruebas, Test Cases, sincronización)

Pipeline de 7 agentes sobre modelo `claude-4.6-opus` fijado. Cada worker ejecuta **un único script
Python determinista** y reporta su salida exacta; ninguno construye JSON, IDs ni URLs a mano.

| Agente | Rol | Script que ejecuta |
|---|---|---|
| `qmetry-agente-qa-setup` | Punto de entrada obligatorio; valida datos mínimos y configura el SP la primera vez | delega a `qmetry-agente-qa-orquestador` |
| `qmetry-agente-qa-orquestador` | Coordina la secuencia de los 5 workers siguientes para un SP específico | — (orquestador puro) |
| `qmetry-agente-qa-cycle-creator` | Localiza o crea el Test Cycle en QMetry | `qmetry/cycle_creator.py` |
| `qmetry-agente-qa-traductor` | Transforma la matriz oficial (`QA-CASOS-PARSEADOS.json`) al formato QMetry | `qmetry/transform.py` |
| `qmetry-agente-qa-sync-checker` | Consulta QMetry y clasifica cada TC (NUEVO/SIN_CAMBIO/ACTUALIZAR/...) | `qmetry/sync_checker.py` |
| `qmetry-agente-qa-inyector` | Envía (crea/actualiza) los Test Cases según el plan de sincronización | `qmetry/sender.py` |
| `qmetry-agente-qa-linker` | Enlaza los Test Cases al Test Cycle | `qmetry/linker.py` |

Controles de riesgo específicos de este grupo (documentados en cada agente, no solo en el orquestador):
- Todo script mutante (`cycle_creator`, `sender`, `linker`) corre en **dry-run por defecto**; la mutación
  real exige `--execute` con autorización humana explícita en el turno de conversación.
- `sync_checker.py` es *fail-closed*: ante timeout, HTTP 5xx o paginación incompleta al consultar QMetry,
  el plan sale bloqueado (`blocked=true`, `plan=[]`) — nunca asume "sin cambios" sobre un universo que no
  pudo confirmar por completo.
- `sender.py` y `linker.py` no reintentan automáticamente una escritura fallida; ante 409/timeout/5xx
  reconcilian con lecturas de solo lectura acotadas (topes explícitos de reintentos/tiempo) y se detienen
  en el primer fallo material.
- Un HTTP 2xx nunca es la condición de éxito: `linker.py` exige `verifiedLinked=true` tras releer el
  estado remoto; `sender.py` exige verificación posterior a cada escritura por el mismo motivo.
- `linker.py` limita a **un Test Case por solicitud** (`--batch-size` debe ser 1 al ejecutar) y topa
  cuántos candidatos se procesan por corrida (`--max-execute-candidates`), reduciendo el radio de un
  eventual error.

> El "Lote 3" (ejecuciones, evidencia y su enlace a requerimientos en QMetry) se opera con scripts
> aparte (`execution_discovery.py`, `evidence_uploader.py`, `execution_updater.py`, etc.) que hoy **no**
> tienen agente wrapper propio en este catálogo — se ejecutan de forma más directa, fuera del alcance del
> orquestador de Lote 2.

---

### Grupo G — Herramientas manuales de soporte (invocación explícita, fuera del pipeline automático)

| Agente | Modelo / effort | Herramientas | Rol |
|---|---|---|---|
| `agente-queryplan` | opus / high | Read, Glob, Grep, Bash, Write | Capa delgada sobre el pipeline `qp_pipeline.py`: analiza el Query Plan de un SP migrado (inventario cruzado de SQL + ejecución de cada sentencia DML crítica contra Sybase real, con plan de ejecución y estadísticas de I/O) y empaqueta el entregable formato banco. |
| `agente-gestor-qa` | sonnet / medium | Read, Bash | Interfaz en lenguaje natural para crear/actualizar tareas, errores (bugs) y casos de prueba en el Gestor QA (backend Supabase), validando cada operación contra las reglas de negocio (`REGLAS-GESTOR-QA.md`) antes de escribir. |

**`agente-queryplan`** — Requiere invocación humana explícita; no forma parte del flujo automático de
migración. Es una capa delgada: recibe el contexto contractual (HU, microservicio, SP raíz, librerías
elegibles), construye una única solicitud, invoca el pipeline canónico una sola vez, y reporta leyendo su
resultado estructurado — nunca interpreta salida de consola libre ni ejecuta SQL/manifiestos a mano. Sus
reglas contractuales son estrictas y no negociables: sin un inventario explícito de librerías elegibles
no hay corrida; un inventario ausente bloquea, uno vacío explícito simplemente no aplica (ambos son
resultados válidos, no errores del agente); nunca infiere elegibilidad por similitud de nombres.

**`agente-gestor-qa`** — Traduce una orden en lenguaje natural del equipo QA (sin que la persona necesite
conocer UUIDs, nombres de tabla ni sintaxis PostgREST) en una operación validada sobre Supabase. Usa
**exclusivamente** el script determinista `gestor_qa_client.py` para leer/escribir — tiene prohibido
construir peticiones HTTP o JSON a mano. Ejecuta la mutación pedida y solo las operaciones auxiliares
estrictamente necesarias para hacerla de forma segura (por ejemplo, resolver una clave foránea), sin
extender esa autorización a otras mutaciones que descubra en el camino. Si la operación viola una regla
de integridad referencial o un valor de catálogo no contemplado, se detiene y reporta el motivo — nunca
fuerza la escritura. Puede crear y actualizar parcialmente filas de `spMigrations`, pero está fuera de su
alcance crear o modificar `useCases`, `members` o `catalogs` (solo lectura, para resolver referencias).

---

## 3. Skills deterministas invocadas por agentes (capa 0-tokens)

Estas no son agentes de IA — son scripts/mecanismos deterministas que un agente invoca para delegar la
parte 100% reproducible de su trabajo, sin gastar razonamiento de modelo en ella:

| Skill | Invocada por | Función |
|---|---|---|
| `skill-qa-uml-00-pdf-generator` | `agente-qa-uml-00-orquestador` | Exporta los `.puml` generados a PDF (vía SVG intermedio) y consolida el reporte final. |
| `skill-qa-uml-01-class-descriptions` | `agente-qa-uml-01-class-descriptions` | Inyecta, de forma mecánica e idempotente, las descripciones de clase (ya redactadas por el agente) como notas UML en los `.puml`. |
| `skill-qa-uml-02-auditor` | `agente-qa-uml-02-auditor` | Calcula el inventario de las 4 vistas UML y los hallazgos estructurales de los ejes Sincronía/Persistencia sin usar tokens de modelo — el agente solo pondera el eje Conceptual. |

---

## 4. Resumen ejecutivo del inventario

- **23 agentes de IA** en producción para el ciclo de QA de la migración, todos sobre modelos de la
  familia Claude (Anthropic): 16 sobre `opus`, 7 sobre `claude-4.6-opus` fijado, 1 sobre `sonnet`.
- **Ningún agente decide un veredicto de negocio por criterio libre**: la comparación de equivalencia
  (Grupo C), la clasificación de sincronización QMetry (Grupo F) y la validación estructural UML (Grupo
  D) las calcula un script o motor determinista; el modelo de IA se reserva para interpretación de
  lenguaje natural, redacción y juicio funcional acotado y trazable.
- **Todo agente con capacidad de escritura declara su alcance exacto** (`allowed_write_paths` o el script
  determinista que lo sustituye), y todo agente con capacidad de mutar un sistema externo (QMetry,
  Supabase) opera en modo simulación por defecto, con verificación posterior obligatoria a cada
  escritura real.
- **La única condición de parada autónoma es la ambigüedad de negocio genuina** (human-gate) o la
  violación de una regla de integridad ya declarada — nunca la falta de un dato, que en cambio se marca
  como interpretación o se reporta como bloqueado.

#!/usr/bin/env python3
"""
sql_readonly_guard.py - Barrera reusable fail-closed para el flujo de discovery read-only.

Incidente NCBE-1178 (2026-08-17): `build_discovery_queries()` (validate_external_tc.py) aceptaba un
bloque PRE/POST completo con tal de que EMPEZARA con SELECT, sin revisar el resto del bloque. Eso dejo
pasar intactos 7 bloques con DELETE/INSERT real de Banco (TC02, TC04, TC05, TC06, TC08, TC20, TC32) hacia
`discover_data.py::execute_single_query` -> `conn.execute_query(batch_completo)` -> Sybase ejecuto y
autocommiteo el DML durante lo que debia ser descubrimiento de SOLO LECTURA (2 filas de catalogo
compartido eliminadas sin reinsercion, 1 fila espuria insertada en `re_caja`).

Este modulo es la UNICA fuente de verdad sobre que es "seguro para discovery" y se usa en DOS puntos
independientes (defensa en profundidad -- ninguno confia en que el otro ya filtro):

  1. `extract_readonly_select_prefix()` -> barrera PRIMARIA, usada por
     `validate_external_tc.py::build_discovery_queries`. Decide, de forma deterministica, que
     sub-bloque (si alguno) de un PRE/POST multi-sentencia puede convertirse en query de discovery.
  2. `is_strictly_readonly_query()` -> barrera SECUNDARIA, usada por
     `discover_data.py::execute_single_query`. Revalida de forma independiente CUALQUIER string a
     punto de enviarse a Sybase, sin confiar en que el caller (build_discovery_queries, o cualquier
     otro futuro caller) ya lo filtro correctamente.

Politica: FAIL CLOSED. Ante cualquier ambiguedad (verbo no reconocido, SELECT INTO, EXEC/EXECUTE en
cualquier posicion, imposibilidad de separar sentencias) se rechaza. Nunca se ejecuta una query dudosa.

No es un parser SQL completo -- no hace falta: el formato de los PRE/POST de banco es controlado (un
verbo por sentencia, sin sub-batches anidados, sin cursores). La deteccion es estructural (verbo inicial
de cada sentencia + verbos prohibidos en cualquier posicion), tolerante a mayusculas/minusculas, espacios,
saltos de linea, comentarios (`--` y `/* */`) y punto y coma.
"""
import re

# Verbos de solo lectura permitidos para llegar a Sybase durante discovery.
READONLY_VERBS = ('SELECT',)

# Verbos que NUNCA pueden llegar a Sybase durante discovery, en ninguna posicion del bloque.
FORBIDDEN_VERBS = (
    'INSERT', 'UPDATE', 'DELETE', 'MERGE', 'TRUNCATE',
    'CREATE', 'ALTER', 'DROP', 'EXEC', 'EXECUTE',
)

_ALL_KNOWN_VERBS = READONLY_VERBS + FORBIDDEN_VERBS

_BLOCK_COMMENT_RE = re.compile(r'/\*.*?\*/', re.DOTALL)
_LINE_COMMENT_RE = re.compile(r'--[^\n]*')
# SELECT ... INTO <tabla> (crea/escribe una tabla nueva) - no confundir con "INTO" dentro de otra
# clausula (INSERT...FROM...INTO no es sintaxis Sybase real, pero por robustez se exige que no
# aparezca un FROM antes del INTO en el mismo tramo, patron tipico de `SELECT * INTO #tmp FROM t`).
_SELECT_INTO_RE = re.compile(r'\bSELECT\b(?:(?!\bFROM\b).)*?\bINTO\b', re.IGNORECASE | re.DOTALL)
_EXEC_ANYWHERE_RE = re.compile(r'\b(?:EXEC|EXECUTE)\b', re.IGNORECASE)

# Sybase permite invocar un stored procedure SIN la palabra EXEC si es el primer statement de un
# batch (atajo de sintaxis real de ASE, ej. `sp_helptext mi_sp`, `cobis..sp_cerror @i_num=1`). Es tan
# peligroso como un EXEC explicito y el chequeo de _EXEC_ANYWHERE_RE no lo detecta (no aparece la
# palabra EXEC). Heuristica deterministica: una linea que empieza con un identificador (posiblemente
# calificado con `.`/`..`) seguido de un parametro con nombre `@algo=` NO puede ser una clausula SQL
# de continuacion valida (WHERE/AND/FROM/ORDER BY/... nunca preceden asi a un `@param=`) -> se trata
# igual que EXEC/EXECUTE: bloqueo total del bloque, sin importar la posicion.
_CONTINUATION_KEYWORDS = (
    'WHERE', 'AND', 'OR', 'FROM', 'ORDER', 'GROUP', 'HAVING', 'JOIN', 'ON', 'TOP', 'AS', 'IN',
    'EXISTS', 'NOT', 'IS', 'NULL', 'BETWEEN', 'LIKE', 'UNION', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END',
    'GO', 'INTO', 'VALUES', 'SET',
)
_IMPLICIT_PROC_CALL_RE = re.compile(
    r'^\s*(?!(?:' + '|'.join(_ALL_KNOWN_VERBS + _CONTINUATION_KEYWORDS) + r')\b)'
    r'[A-Za-z_][\w]*(?:\.\.?[A-Za-z_][\w]*)?\s+@\w+\s*=',
    re.IGNORECASE | re.MULTILINE,
)
_FIRST_VERB_RE = re.compile(r'^\s*([A-Za-z]+)\b')
_STATEMENT_START_RE = re.compile(
    r'(?=^\s*(?:' + '|'.join(_ALL_KNOWN_VERBS) + r')\b)',
    re.MULTILINE | re.IGNORECASE,
)


def strip_sql_comments(sql):
    """Quita comentarios /* */ y -- para que no oculten ni disfracen un verbo real."""
    sql = _BLOCK_COMMENT_RE.sub(' ', sql)
    sql = _LINE_COMMENT_RE.sub('', sql)
    return sql


def split_sql_statements(sql):
    """Divide un bloque (ya sin comentarios) en sentencias individuales.

    No es un parser SQL completo: usa el inicio de linea de un verbo conocido y ';' como limites de
    sentencia, suficiente para el formato controlado de los PRE/POST de banco (un verbo por sentencia,
    sin sub-batches anidados). Devuelve fragmentos no vacios, en orden. Si un fragmento no puede
    reconocerse como sentencia (no empieza con un verbo conocido), se devuelve tal cual para que el
    caller lo trate como fallo de reconocimiento (fail-closed), nunca se descarta en silencio.
    """
    sql = sql.strip()
    if not sql:
        return []
    fragments = []
    for chunk in sql.split(';'):
        if not chunk.strip():
            continue
        parts = _STATEMENT_START_RE.split(chunk)
        fragments.extend(p.strip() for p in parts if p.strip())
    return fragments


def _leading_verb(statement):
    m = _FIRST_VERB_RE.match(statement)
    return m.group(1).upper() if m else None


def extract_readonly_select_prefix(sql):
    """Barrera PRIMARIA: dado un bloque PRE/POST crudo (con o sin comentarios, una o varias
    sentencias), determina si puede extraerse de forma DETERMINISTA e INEQUIVOCA un prefijo de
    sentencias SELECT-only seguro para discovery.

    Devuelve (safe_sql_or_None, fue_reducido, reason_or_None):
      - Bloque completo SELECT-only (sin EXEC/SELECT INTO) -> (bloque_limpio, False, None).
      - Bloque con >=1 sentencias SELECT limpias seguidas de una sentencia con verbo prohibido ->
        (prefijo_select_only, True, None): se descarta todo desde la primera sentencia prohibida.
      - No separable de forma segura (primera sentencia ya prohibida, verbo no reconocible,
        SELECT INTO, EXEC en cualquier parte, bloque vacio) -> (None, False, reason).

    Nunca devuelve un string que contenga un verbo prohibido, EXEC/EXECUTE o SELECT INTO.
    """
    cleaned = strip_sql_comments(sql)
    if not cleaned.strip():
        return None, False, 'bloque_vacio_tras_quitar_comentarios'

    if _EXEC_ANYWHERE_RE.search(cleaned):
        return None, False, 'exec_o_execute_detectado_en_el_bloque'

    if _IMPLICIT_PROC_CALL_RE.search(cleaned):
        return None, False, 'llamada_implicita_a_sp_detectada'

    statements = split_sql_statements(cleaned)
    if not statements:
        return None, False, 'no_se_pudo_dividir_en_sentencias'

    safe_statements = []
    hit_forbidden = False
    for stmt in statements:
        verb = _leading_verb(stmt)
        if verb is None or verb not in _ALL_KNOWN_VERBS:
            # Verbo no reconocible en cualquier posicion: no confiar ni en lo ya acumulado -> fail closed total.
            return None, False, f'verbo_no_reconocido:{verb or "ninguno"}'
        if verb in FORBIDDEN_VERBS:
            hit_forbidden = True
            break
        if _SELECT_INTO_RE.search(stmt):
            return None, False, 'select_into_detectado'
        safe_statements.append(stmt)

    if not safe_statements:
        reason = 'primera_sentencia_ya_es_verbo_prohibido' if hit_forbidden else 'bloque_sin_sentencias_select'
        return None, False, reason

    return '\n\n'.join(safe_statements), hit_forbidden, None


def is_strictly_readonly_query(sql):
    """Barrera SECUNDARIA: verificacion independiente y estricta. NO intenta reducir ni extraer nada,
    solo responde si la query, TAL CUAL viene, es segura para ejecutar contra Sybase. Debe llamarse
    SIEMPRE justo antes de `conn.execute_query()`, sin confiar en ningun filtro previo (defensa en
    profundidad real: si `extract_readonly_select_prefix` tuviera un bug, esta funcion es la ultima
    linea de defensa).

    Devuelve (is_safe: bool, reason_or_None).
    """
    if sql is None or not str(sql).strip():
        return False, 'query_vacia'
    cleaned = strip_sql_comments(sql)
    if not cleaned.strip():
        return False, 'query_vacia_tras_quitar_comentarios'
    if _EXEC_ANYWHERE_RE.search(cleaned):
        return False, 'exec_o_execute_detectado'
    if _IMPLICIT_PROC_CALL_RE.search(cleaned):
        return False, 'llamada_implicita_a_sp_detectada'
    if _SELECT_INTO_RE.search(cleaned):
        return False, 'select_into_detectado'
    statements = split_sql_statements(cleaned)
    if not statements:
        return False, 'no_se_pudo_dividir_en_sentencias'
    for stmt in statements:
        verb = _leading_verb(stmt)
        if verb != 'SELECT':
            return False, f'verbo_no_permitido:{verb or "desconocido"}'
    return True, None

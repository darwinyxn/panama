#!/usr/bin/env python3
"""
discover_data.py - Ejecuta queries de descubrimiento contra Sybase y genera data_discovery.json.

El agente de TCs genera un JSON con queries de descubrimiento (que cuentas/datos existen
en el ambiente para cada escenario de prueba). Este script ejecuta esas queries y retorna
los resultados para que el agente genere qa_casos_prueba.md con datos reales.

Soporta queries en dos niveles (Tier 1 y Tier 2):
- Tier 1: query exacta que busca dato que ya cumple todas las condiciones.
- Tier 2: query relajada (fallback) que busca cualquier dato existente para adaptar con PRE/POST.

Uso:
    python3 discover_data.py --queries <queries.json> --sp-name <sp_name> --output <output_dir>

Entrada (queries.json):
    {
      "queries": [
        {"alias": "cuenta_activa_fondos", "query": "SELECT TOP 1 ...", "uso": "unica", "tier": 1},
        {"alias": "cuenta_activa_fondos_fallback", "query": "SELECT TOP 1 ...", "uso": "unica", "tier": 2, "adapta_con_pre": true}
      ]
    }

Salida (data_discovery.json):
    {
      "sp_name": "<sp_name>",
      "discovered_at": "<fecha>",
      "cuentas": {
        "cuenta_activa_fondos": {"valor": "0000837312", "query": "SELECT...", "uso": "unica", "tier": 1, "requiere_pre_adaptativo": false},
        ...
      },
      "resolucion": {
        "tier1_ok": N,
        "tier2_fallback_usado": N,
        "sin_dato": N
      },
      "tc_mapping": {}
    }

Requiere:
    - Variables de entorno SYBASE_SERVER, SYBASE_USER, SYBASE_PASS
    - sybase_tsql_wrapper.py accesible

CONTRATO DE SEGURIDAD (NCBE-1178, incidente 2026-08-17): DISCOVERY = READ ONLY, sin excepcion. Ninguna
query que pase por este script puede ejecutar INSERT/UPDATE/DELETE/MERGE/TRUNCATE/CREATE/ALTER/DROP/
EXEC/EXECUTE/SELECT INTO contra Sybase, ni siquiera si viene embebida dentro de un bloque PRE/POST de
banco que empieza con SELECT. Un PRE/POST con DML real (preparacion/reset de estado) NUNCA debe llegar
aqui -- eso se ejecuta unicamente durante la corrida real del TC (agente-05), no durante discovery.
`execute_single_query()` revalida cada query de forma independiente con `sql_readonly_guard` justo
antes de tocar `conn.execute_query()` -- ver esa funcion para el detalle de la barrera.
"""
import sys
import os
import json
import argparse
from datetime import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))  # .../inputs/scripts/auto
INPUTS_ROOT = os.path.abspath(os.path.join(SCRIPT_DIR, '..', '..'))  # .../inputs
DOTCLAUDE_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, '..', '..', '..', '..'))  # .../.claude

# Busqueda con verificacion de existencia (mismo patron que run_qa.py): el wrapper vive en
# inputs/scripts/, no en .claude/scripts/ (esa ruta nunca existio -> discovery fallaba siempre).
_wrapper_paths = [
    os.path.join(DOTCLAUDE_DIR, 'scripts'),
    os.path.join(INPUTS_ROOT, 'scripts'),
    os.path.join(os.getcwd(), '..', '..', '..', 'scripts'),
]
for _p in _wrapper_paths:
    _abs = os.path.abspath(_p)
    if os.path.exists(os.path.join(_abs, 'sybase_tsql_wrapper.py')):
        sys.path.insert(0, _abs)
        break
sys.path.insert(0, SCRIPT_DIR)

try:
    from sybase_tsql_wrapper import SybaseTsqlConnection
except ImportError:
    print('ERROR: No se encontro sybase_tsql_wrapper.py')
    sys.exit(1)

import sql_readonly_guard


def execute_single_query(conn, alias, query):
    """Ejecuta una query y retorna (valor, raw_result) o (None, None).

    BARRERA SECUNDARIA fail-closed (NCBE-1178, defensa en profundidad): antes de tocar
    `conn.execute_query()` se revalida la query de forma independiente con
    `sql_readonly_guard.is_strictly_readonly_query()`. Esto es intencional aunque el caller
    (`build_discovery_queries` en validate_external_tc.py) ya deberia haber filtrado -- este modulo
    NUNCA confia en que un caller aguas arriba lo hizo bien. Si la query no es SELECT-only estricta
    (contiene INSERT/UPDATE/DELETE/MERGE/TRUNCATE/CREATE/ALTER/DROP/EXEC/EXECUTE/SELECT INTO en
    cualquier posicion, o no es reconocible como sentencia SELECT), se bloquea SIN LLAMAR a
    `conn.execute_query` y se devuelve un error explicito -- nunca se envia a Sybase.

    Deteccion de rechazo real de Sybase (bug real corregido, NCBE-1343/TC16): cuando el motor
    rechaza la query (ej. 'Invalid column name'), `conn.execute_query()` devuelve
    `[{'_error': ..., 'engine_exception': {...}}]` (ver `SybaseTsqlConnection.execute_query()`).
    Antes, este chequeo buscaba la clave `'error'` (sin guion bajo) -- que NUNCA existe en esa
    forma -- por lo que el rechazo de Sybase se interpretaba como una fila de datos valida
    (`first_row` terminaba siendo los fragmentos del propio mensaje de error, tokenizados como si
    fueran columnas). Ahora se detecta la clave real `'_error'` y se propaga como fallo explicito,
    nunca como dato."""
    is_safe, reason = sql_readonly_guard.is_strictly_readonly_query(query)
    if not is_safe:
        blocked = {
            'error': f'BLOQUEADO_POR_BARRERA_READONLY: {reason}',
            'blocked_reason': reason,
            'blocked_query': query,
        }
        print(f'  [BLOQUEADO][{alias}] {reason} -- NO se envio a Sybase')
        return None, blocked
    try:
        rows = conn.execute_query(query)
        if rows and isinstance(rows, list) and len(rows) > 0 and '_error' in rows[0]:
            return None, {'error': rows[0]['_error'], 'engine_exception': rows[0].get('engine_exception')}
        if rows and isinstance(rows, list) and len(rows) > 0:
            first_row = rows[0]
            valor = str(list(first_row.values())[0]) if first_row else None
            return valor, first_row
        return None, None
    except Exception as e:
        return None, {'error': str(e)}


def is_sql_error_result(raw):
    """True si `raw` (segundo valor de execute_single_query) representa un rechazo REAL de
    Sybase (excepcion nativa estructurada) -- nunca una ausencia benigna de datos ni un bloqueo
    de la barrera read-only (esos no tienen `engine_exception`)."""
    return bool(isinstance(raw, dict) and raw.get('engine_exception'))


def main():
    parser = argparse.ArgumentParser(description='Discover data from Sybase for QA test cases')
    parser.add_argument('--queries', required=True, help='Path al JSON con queries de descubrimiento')
    parser.add_argument('--sp-name', required=True, help='Nombre del SP')
    parser.add_argument('--output', required=True, help='Directorio de salida para data_discovery.json')
    parser.add_argument('--database', required=True, help='Base de datos inicial')
    args = parser.parse_args()

    if not os.path.exists(args.queries):
        print(f'ERROR: No se encontro {args.queries}')
        sys.exit(1)

    with open(args.queries) as f:
        queries_data = json.load(f)

    server = os.getenv('SYBASE_SERVER')
    user = os.getenv('SYBASE_USER')
    password = os.getenv('SYBASE_PASS')

    if not server or not user or not password:
        print('ERROR: Variables de entorno SYBASE_SERVER, SYBASE_USER, SYBASE_PASS requeridas.')
        sys.exit(1)

    conn = SybaseTsqlConnection(server=server, user=user, password=password, database=args.database)
    if not conn.connect():
        print('ERROR: No se pudo conectar a Sybase.')
        sys.exit(1)

    all_queries = queries_data.get('queries', [])

    print('=' * 60)
    print('  DISCOVER DATA (con soporte Tier 1/2)')
    print('=' * 60)
    print(f'  SP:       {args.sp_name}')
    print(f'  Database: {args.database}')
    print(f'  Queries:  {len(all_queries)}')
    print('=' * 60)

    tier1_queries = [q for q in all_queries if q.get('tier', 1) == 1]
    tier2_queries = [q for q in all_queries if q.get('tier', 1) == 2]

    print(f'  Tier 1:   {len(tier1_queries)} queries exactas')
    print(f'  Tier 2:   {len(tier2_queries)} queries fallback')
    print('-' * 60)

    cuentas = {}
    tier1_ok = 0
    tier2_usado = 0
    sin_dato = 0
    errores_sql = 0

    for item in tier1_queries:
        alias = item.get('alias', 'unknown')
        query = item.get('query', '')
        uso = item.get('uso', 'compartida')

        if not query:
            print(f'  [T1][{alias}] SKIP: query vacia')
            continue

        valor, raw = execute_single_query(conn, alias, query)

        if valor is not None:
            cuentas[alias] = {
                'valor': valor,
                'query': query,
                'uso': uso,
                'tier': 1,
                'requiere_pre_adaptativo': False,
                'raw_result': raw
            }
            print(f'  [T1][{alias}] OK: {valor}')
            tier1_ok += 1
        else:
            fallback_alias = f'{alias}_fallback'
            fallback_item = next((q for q in tier2_queries if q.get('alias') == fallback_alias), None)

            if not fallback_item:
                fallback_item = next(
                    (q for q in tier2_queries if q.get('alias', '').startswith(alias)),
                    None
                )

            if fallback_item:
                fb_query = fallback_item.get('query', '')
                fb_valor, fb_raw = execute_single_query(conn, fallback_alias, fb_query)

                if fb_valor is not None:
                    cuentas[alias] = {
                        'valor': fb_valor,
                        'query': fb_query,
                        'uso': uso,
                        'tier': 2,
                        'requiere_pre_adaptativo': fallback_item.get('adapta_con_pre', True),
                        'raw_result': fb_raw,
                        'tier1_query_original': query,
                        'nota': 'Dato encontrado via fallback Tier 2. Requiere PRE adaptativo para cumplir condiciones del escenario.'
                    }
                    print(f'  [T2][{alias}] FALLBACK OK: {fb_valor} (requiere PRE adaptativo)')
                    tier2_usado += 1
                elif is_sql_error_result(raw) or is_sql_error_result(fb_raw):
                    error_detalle = (fb_raw or raw).get('error')
                    cuentas[alias] = {
                        'valor': None,
                        'query': query,
                        'uso': uso,
                        'tier': 1,
                        'requiere_pre_adaptativo': False,
                        'raw_result': raw,
                        'raw_result_fallback': fb_raw,
                        'error_sql': True,
                        'nota': f'RECHAZADO POR SYBASE (no es ausencia de datos): {error_detalle}'
                    }
                    print(f'  [T1][{alias}] ‼ ERROR SQL (Sybase rechazo la query): {error_detalle}')
                    errores_sql += 1
                else:
                    cuentas[alias] = {
                        'valor': None,
                        'query': query,
                        'uso': uso,
                        'tier': 1,
                        'requiere_pre_adaptativo': False,
                        'raw_result': None,
                        'nota': 'Sin dato en Tier 1 ni Tier 2. TC marcado NOT_APPLICABLE.'
                    }
                    print(f'  [T1][{alias}] NO_DATA (Tier 1 y Tier 2 agotados)')
                    sin_dato += 1
            elif is_sql_error_result(raw):
                cuentas[alias] = {
                    'valor': None,
                    'query': query,
                    'uso': uso,
                    'tier': 1,
                    'requiere_pre_adaptativo': False,
                    'raw_result': raw,
                    'error_sql': True,
                    'nota': f"RECHAZADO POR SYBASE (no es ausencia de datos): {raw.get('error')}"
                }
                print(f"  [T1][{alias}] ‼ ERROR SQL (Sybase rechazo la query): {raw.get('error')}")
                errores_sql += 1
            else:
                cuentas[alias] = {
                    'valor': None,
                    'query': query,
                    'uso': uso,
                    'tier': 1,
                    'requiere_pre_adaptativo': False,
                    'raw_result': None,
                    'nota': 'Sin dato y sin fallback Tier 2 definido.'
                }
                print(f'  [T1][{alias}] NO_DATA (sin fallback)')
                sin_dato += 1

    for item in tier2_queries:
        alias = item.get('alias', 'unknown')
        base_alias = alias.replace('_fallback', '')
        if base_alias in cuentas:
            continue

        query = item.get('query', '')
        uso = item.get('uso', 'compartida')

        if not query:
            continue

        valor, raw = execute_single_query(conn, alias, query)
        if valor is not None:
            cuentas[alias] = {
                'valor': valor,
                'query': query,
                'uso': uso,
                'tier': 2,
                'requiere_pre_adaptativo': item.get('adapta_con_pre', True),
                'raw_result': raw
            }
            print(f'  [T2][{alias}] OK: {valor} (standalone)')
        elif is_sql_error_result(raw):
            cuentas[alias] = {
                'valor': None,
                'query': query,
                'uso': uso,
                'tier': 2,
                'requiere_pre_adaptativo': False,
                'raw_result': raw,
                'error_sql': True,
                'nota': f"RECHAZADO POR SYBASE (no es ausencia de datos): {raw.get('error')}"
            }
            print(f"  [T2][{alias}] ‼ ERROR SQL (Sybase rechazo la query): {raw.get('error')}")
            errores_sql += 1
        else:
            cuentas[alias] = {
                'valor': None,
                'query': query,
                'uso': uso,
                'tier': 2,
                'requiere_pre_adaptativo': False,
                'raw_result': None
            }
            print(f'  [T2][{alias}] NO_DATA')
            sin_dato += 1

    conn.close()

    total_aliases = len([c for c in cuentas.values() if c.get('tier') == 1 or '_fallback' not in str(c.get('query', ''))])
    total_found = len([c for c in cuentas.values() if c['valor'] is not None])

    output = {
        'sp_name': args.sp_name,
        'discovered_at': datetime.now().isoformat(),
        'database': args.database,
        'total_queries': len(all_queries),
        'total_found': total_found,
        'total_sin_dato': sin_dato,
        'total_errores_sql': errores_sql,
        'resolucion': {
            'tier1_ok': tier1_ok,
            'tier2_fallback_usado': tier2_usado,
            'sin_dato': sin_dato,
            'errores_sql': errores_sql
        },
        'cuentas': cuentas,
        'tc_mapping': {}
    }

    os.makedirs(args.output, exist_ok=True)
    output_path = os.path.join(args.output, 'data_discovery.json')
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print('')
    print('=' * 60)
    print(f'  Resolucion:')
    print(f'    Tier 1 OK (dato exacto):      {tier1_ok}')
    print(f'    Tier 2 usado (fallback+PRE):   {tier2_usado}')
    print(f'    Sin dato (NOT_APPLICABLE):     {sin_dato}')
    print(f'    ERRORES SQL (Sybase rechazo):  {errores_sql}')
    print(f'  Total encontrados: {total_found}/{len(all_queries)}')
    print(f'  Output: {output_path}')
    if errores_sql:
        print('  ‼ ALERTA: al menos una query de descubrimiento fue RECHAZADA por Sybase -- '
              'no es ausencia de datos, es una query invalida (ver "error_sql": true en cuentas). '
              'Requiere corregir la query fuente antes de continuar.')
    print('=' * 60)

    return 2 if errores_sql else 0


if __name__ == '__main__':
    sys.exit(main())

#!/usr/bin/env python3
"""
Wrapper para ejecutar queries Sybase usando tsql (FreeTDS).
Usa conexion persistente con PTY para mantener un solo proceso tsql abierto.
"""
import subprocess
import re
import os
import time
import select
import fcntl
import pty
from typing import List, Dict, Any, Optional, Tuple


class SybaseTsqlConnection:
    """Conexion a Sybase usando tsql de FreeTDS con proceso persistente via PTY."""

    def __init__(self, server: str, user: str, password: str, database: str = 'master'):
        self.server = server
        self.user = user
        self.password = password
        self.database = database
        self._connected = False
        self._proc = None
        self._master_fd = None
        self._END_MARKER = '___TSQL_END___'
        # NCBE-1343: canal lateral ADITIVO -- captura estructurada (message_number/level/state)
        # de cada linea 'Msg NNN, Level X, State Y[: texto]' que _execute_raw() procese. NUNCA
        # cambia el string que _execute_raw() ya devuelve (ese comportamiento -- incluido el
        # recorte del prefijo 'Msg NNN...:' -- se preserva byte a byte); esto es SOLO un registro
        # adicional para que el caller (execute_all.py::exec_sp) pueda distinguir una excepcion
        # nativa del motor (ej. error de conversion CAST) de un fallo de infraestructura, sin
        # depender de parsear substrings sueltos del texto ya recortado.
        self._last_engine_messages = []

    def connect(self):
        """Abrir proceso tsql persistente con PTY. Timeout 10s."""
        try:
            master_fd, slave_fd = pty.openpty()

            self._proc = subprocess.Popen(
                ['tsql', '-S', self.server, '-U', self.user, '-P', self.password, '-D', self.database],
                stdin=subprocess.PIPE,
                stdout=slave_fd,
                stderr=slave_fd,
                text=False,
                bufsize=0
            )

            os.close(slave_fd)
            self._master_fd = master_fd
            fcntl.fcntl(self._master_fd, fcntl.F_SETFL,
                        fcntl.fcntl(self._master_fd, fcntl.F_GETFL) | os.O_NONBLOCK)

            self._send_and_read("SELECT 1 as _init", timeout_s=10)
            self._connected = True
            return True

        except Exception:
            self._kill_process()
            self._connected = False
            return False

    def _send_and_read(self, query, timeout_s=30):
        """Envia query + marcador, lee hasta encontrar marcador. Mata proceso si timeout.

        Robusto ante muerte del tsql a mitad (Sybase intermitente): (1) health-check del proceso
        ANTES de escribir; (2) escritura con timeout (nunca se cuelga en write/flush a un pipe muerto);
        (3) deteccion de EOF en la lectura (chunk vacio = tsql cerro el pipe -> no esperar el deadline)."""
        if not query.strip().upper().endswith('GO'):
            query = query.strip() + '\ngo'

        # (1) Health-check: si el proceso tsql ya murio, NO escribir a un pipe muerto (colgaria).
        if not self._proc or self._proc.poll() is not None:
            self._kill_process()
            raise Exception("Proceso tsql no disponible (murio antes de la query)")

        full = f"{query}\nSELECT '{self._END_MARKER}' as _marker\ngo\n"

        # (2) Escritura protegida: se escribe al stdin del proceso (canal original). El write/flush
        # se envuelve en try/except y se re-verifica el estado del proceso: si el tsql murio a mitad
        # (Sybase intermitente), en vez de colgar indefinidamente se aborta con excepcion clara.
        try:
            self._proc.stdin.write(full.encode())
            self._proc.stdin.flush()
        except (BrokenPipeError, OSError):
            self._kill_process()
            raise Exception("Proceso tsql murio durante la escritura de la query (broken pipe)")

        buf = b''
        marker_bytes = self._END_MARKER.encode()
        affected_bytes = b'(1 row affected)'
        deadline = time.time() + timeout_s

        while time.time() < deadline:
            ready = select.select([self._master_fd], [], [], 1.0)
            if ready[0]:
                try:
                    chunk = os.read(self._master_fd, 4096)
                    if not chunk:
                        # (3) EOF: el tsql cerro el pipe (murio). No tiene sentido esperar el deadline.
                        self._kill_process()
                        raise Exception("Proceso tsql cerro la conexion (EOF) durante la lectura")
                    buf += chunk
                    if marker_bytes in buf and affected_bytes in buf[buf.index(marker_bytes):]:
                        break
                except (BlockingIOError, OSError):
                    continue
            elif self._proc.poll() is not None:
                # el proceso murio y no hay mas datos por leer
                self._kill_process()
                raise Exception("Proceso tsql murio durante la lectura de la respuesta")
        else:
            self._kill_process()
            raise Exception(f"Timeout ({timeout_s}s) esperando respuesta de tsql")

        return buf.decode('utf-8', errors='replace')

    def _execute_raw(self, query: str, timeout_s: int = 30) -> str:
        """Ejecutar query y devolver salida raw filtrada."""
        if not self._proc or self._proc.poll() is not None:
            raise Exception("Proceso tsql no disponible")

        raw = self._send_and_read(query, timeout_s=timeout_s)

        # NCBE-1343: reset del canal lateral por cada ejecucion (un batch puede levantar 0 o mas
        # mensajes de motor; solo interesan los de ESTA llamada, nunca los de una anterior).
        self._last_engine_messages = []
        # Backfill de 'text' para el formato B (FreeTDS 'severity...', ver mas abajo): esa
        # convencion NUNCA trae el texto en la misma linea del header -- viene en 0+ lineas
        # siguientes, que YA se preservan sin cambios en `lines` (mensaje_debug). Se replican
        # esas mismas lineas (mismo filtrado, cero logica nueva) en un buffer aparte para
        # backfillear `text` del ULTIMO mensaje formato B pendiente. El formato A NUNCA participa
        # de este backfill -- su `text=None` cuando no hay texto inline es intencional (ver
        # test_header_without_trailing_text_still_captured_structurally).
        pending_b_idx = None
        pending_b_lines = []

        def _flush_pending_text():
            nonlocal pending_b_idx, pending_b_lines
            if pending_b_idx is not None and pending_b_lines:
                block = '\n'.join(pending_b_lines).strip()
                if len(block) >= 2 and block.startswith('"') and block.endswith('"'):
                    block = block[1:-1].strip()
                if block:
                    self._last_engine_messages[pending_b_idx]['text'] = block
            pending_b_idx = None
            pending_b_lines = []

        lines = []
        for line in raw.split('\n'):
            # CR final (retorno de carro, artefacto de protocolo/tty) se remueve; el resto de la
            # linea (incluidos TABS y espacios internos/de borde) se PRESERVA en `raw_line`. `s`
            # (fullstrip) se usa SOLO para las comparaciones de filtrado de abajo, nunca para el
            # contenido que se acumula en `lines`.
            #
            # Motivo (bug real, verificado byte a byte contra Sybase en pa_fir_consulta_con_especial):
            # un campo de texto libre del SP (Sybase varchar con salto de linea embebido, ej. una
            # columna de "observaciones") fragmenta una fila logica en 2+ lineas fisicas al hacer
            # raw.split('\n'). Cuando el corte cae EXACTAMENTE en el separador de tab entre esa
            # columna y la siguiente, el fragmento resultante queda como '\t<valor_siguiente>' (tab
            # inicial). El `.strip()` ciego anterior borraba ese tab inicial junto con el espacio,
            # fusionando sin separador la columna siguiente dentro del valor de texto libre -> las
            # filas subsecuentes quedaban corridas/desalineadas (bug real: SP con 239 filas reales
            # contaba 292 o 219 segun el heuristico de reconstruccion, nunca 239 exacto).
            raw_line = line[:-1] if line.endswith('\r') else line
            s = raw_line.strip()
            if not s:
                continue
            # NCBE-1178 Turno 40: una linea 'Msg NNN, Level X, State Y: <texto>' (formato de
            # severidad baja que tsql imprime en una sola linea, sin continuar en 'Server .../
            # Line ...') se descartaba POR COMPLETO -- perdiendo el texto real levantado por
            # RAISERROR/sp_cerror (bug real: RAISERROR de sp_cerror para @i_num=130028,
            # @i_msg='REGISTRO DUPLICADO' explicito -- el texto nunca llegaba a
            # extract_engine_message(), que caia en su fallback al catalogo cl_errores y
            # sustituia silenciosamente un mensaje DISTINTO, nunca levantado en runtime). Se
            # preserva cualquier texto que siga al prefijo reconocido 'Msg NNN...:' (mismo patron
            # ya usado abajo para los prompts '1>'/'2>' -- quitar el prefijo, conservar el resto);
            # si no queda nada tras el prefijo (el caso ya cubierto: header seguido de
            # 'Server .../Line ...' en lineas separadas), se descarta igual que antes.
            if re.match(r'^Msg\s+\d+', s):
                # Un nuevo header de motor cierra cualquier acumulacion de texto pendiente del
                # header formato B anterior (si la habia).
                _flush_pending_text()
                # NCBE-1343: captura ADITIVA del header estructurado completo (numero de mensaje,
                # level, state), ANTES de que se recorte -- ver docstring de _last_engine_messages
                # en __init__. Regex separada del recorte de abajo: no participa en el computo de
                # `remainder`/`lines`, solo alimenta el canal lateral.
                # Dos convenciones textuales observadas para el MISMO dato (message_number/
                # level=severity/state), segun cliente/config del servidor Sybase:
                #   A) 'Msg NNN, Level X, State Y: <texto>'            (ISQL/documental, el que
                #      Banco usa en su documento de casos, ej. NCBE-1343/TC33)
                #   B) 'Msg NNN (severity X, state Y) from SERVER, Procedure P Line L:' (FreeTDS/
                #      tsql real, verificado contra sybasedvp1 -- NO trae el texto en esta misma
                #      linea, viene en las lineas siguientes, ya preservadas por el recorte de
                #      abajo sin cambios)
                m_struct = re.match(
                    r'^Msg\s+(\d+)\s*,\s*Level\s+(\d+)\s*,\s*State\s+(\d+)\s*:?\s*(.*)$',
                    s, re.IGNORECASE)
                if not m_struct:
                    m_struct_b = re.match(
                        r'^Msg\s+(\d+)\s*\(severity\s+(\d+)\s*,\s*state\s+(\d+)\)', s, re.IGNORECASE)
                    if m_struct_b:
                        self._last_engine_messages.append({
                            'message_number': int(m_struct_b.group(1)),
                            'level': int(m_struct_b.group(2)),
                            'state': int(m_struct_b.group(3)),
                            'text': None,
                        })
                        pending_b_idx = len(self._last_engine_messages) - 1
                        pending_b_lines = []
                if m_struct:
                    self._last_engine_messages.append({
                        'message_number': int(m_struct.group(1)),
                        'level': int(m_struct.group(2)),
                        'state': int(m_struct.group(3)),
                        'text': m_struct.group(4).strip() or None,
                    })
                m = re.match(r'^Msg\s+\d+[^:]*:\s*(.*)$', s)
                remainder = m.group(1).strip() if m else ''
                if remainder:
                    lines.append(remainder)
                continue
            if any(x in s for x in ['locale', 'using', 'Setting', 'Changed',
                                     self._END_MARKER, '_marker', 'character set']):
                continue
            if 'rows affected' in s.lower() or 'row affected' in s.lower():
                continue
            if s.startswith(('1>', '2>', '3>', '4>', '5>', '6>')):
                clean = re.sub(r'^\d+>\s*', '', s)
                while re.match(r'^\d+>', clean):
                    clean = re.sub(r'^\d+>\s*', '', clean)
                if clean:
                    lines.append(clean)
                    if pending_b_idx is not None:
                        pending_b_lines.append(clean)
                continue
            lines.append(raw_line)
            if pending_b_idx is not None:
                pending_b_lines.append(raw_line)

        _flush_pending_text()
        return '\n'.join(lines)

    def get_last_engine_messages(self) -> List[Dict[str, Any]]:
        """Devuelve los mensajes de motor Sybase (Msg NNN, Level X, State Y) estructurados que
        `_execute_raw()` capturo en su ULTIMA invocacion (ver `_last_engine_messages` en
        __init__). Lista vacia si no hubo ninguno o si aun no se ejecuto ninguna query."""
        return list(self._last_engine_messages)

    def execute_query(self, query: str, timeout_s: int = 30) -> List[Dict[str, Any]]:
        """Ejecutar SELECT y parsear resultados a lista de dicts.
        timeout_s configurable para queries lentas (ej: COUNT sobre tablas historicas grandes).

        Deteccion de error nativo GENERICA (bug real corregido): `_execute_raw()` ya recorta el
        prefijo 'Msg NNN...' de CUALQUIER header de motor (formato documental 'Level X, State Y'
        o formato FreeTDS 'severity X, state Y') antes de devolver texto -- un regex que busque
        ese prefijo en `output` (como hacia antes `_parse_tsql_output_multi`) NUNCA puede
        matchear, porque el prefijo ya no esta en el string. La UNICA senal confiable de que el
        motor levanto una excepcion real (en vez de devolver una fila de datos legitima) es el
        canal lateral estructurado `get_last_engine_messages()`, poblado por la MISMA llamada a
        `_execute_raw()` de arriba. Si hay mensaje de motor, se devuelve `_error` explicito --
        JAMAS se intenta parsear el texto del error como si fuera header/fila de un resultset."""
        output = self._execute_raw(query, timeout_s=timeout_s)
        engine_messages = self.get_last_engine_messages()
        if engine_messages:
            exc = engine_messages[0]
            texto = exc.get('text') or output.strip() or None
            detalle = f"Msg {exc['message_number']}, Level {exc['level']}, State {exc['state']}"
            if texto:
                detalle += f"\n{texto}"
            return [{'_error': detalle, 'engine_exception': exc}]
        return self._parse_tsql_output(output)

    def execute_sp(self, sp_name: str, params: Dict[str, Any]) -> Tuple[Optional[int], List[Dict[str, Any]]]:
        """Ejecutar stored procedure y retornar (return_code, resultsets_de_negocio).

        `return_code` es `None` cuando la fila `return_code` NO aparecio en el raw output
        (ausente/no observable) -- NUNCA se sustituye silenciosamente por `0`. Un `0` en el
        valor de retorno de esta funcion solo puede venir de haber leido literalmente esa
        fila con valor `0` en el output real de Sybase (bug real corregido NCBE-1346: antes
        `0` era el default cuando el parser de un solo resultset descartaba silenciosamente
        el resultset de `return_code` por tener una forma de columnas distinta al resultset
        de negocio -- ver `_parse_tsql_output_multi`)."""
        param_parts = []
        for key, value in params.items():
            if value is None:
                param_parts.append(f"@{key}=NULL")
            elif isinstance(value, str):
                escaped = value.replace("'", "''")
                param_parts.append(f"@{key}='{escaped}'")
            elif isinstance(value, bool):
                param_parts.append(f"@{key}={'1' if value else '0'}")
            else:
                param_parts.append(f"@{key}={value}")

        full_query = f"""DECLARE @return_code int
EXEC @return_code = {sp_name} {', '.join(param_parts)}
SELECT @return_code as return_code"""

        output = self._execute_raw(full_query)
        resultsets = self._parse_tsql_output_multi(output)

        if resultsets and resultsets[0] and '_error' in resultsets[0][0]:
            raise Exception(f"Error de motor Sybase: {resultsets[0][0]['_error']}")

        return_code: Optional[int] = None
        business_resultsets: List[Dict[str, Any]] = []
        for rs in resultsets:
            if len(rs) == 1 and set(rs[0].keys()) == {'return_code'}:
                return_code = int(rs[0]['return_code'])
            else:
                business_resultsets.extend(rs)

        return return_code, business_resultsets

    def _parse_tsql_output(self, output: str) -> List[Dict[str, Any]]:
        """Parsear salida de tsql a lista de diccionarios (UN solo resultset).

        Preserva el contrato historico de `execute_query()`: devuelve el PRIMER resultset
        encontrado (o [] si no hay ninguno). Para batches con mas de un resultset de forma
        distinta (ej. resultset de negocio + `SELECT @return_code`), usar
        `_parse_tsql_output_multi()` en su lugar."""
        resultsets = self._parse_tsql_output_multi(output)
        return resultsets[0] if resultsets else []

    def _parse_tsql_output_multi(self, output: str) -> List[List[Dict[str, Any]]]:
        """Parsear salida de tsql en 0+ resultsets independientes.

        Un batch puede emitir varios `SELECT` con distinta cantidad/nombres de columnas
        (ej. el resultset de negocio de un SP seguido de `SELECT @return_code`). Esta
        funcion separa cada bloque detectando el CAMBIO DE FORMA (cantidad de columnas)
        como inicio de un nuevo resultset: una linea que no calza con la cantidad de
        columnas del resultset actual se reinterpreta como el encabezado del siguiente,
        en vez de descartarse silenciosamente (bug real corregido NCBE-1346).

        LIMITACION CONOCIDA (documentada, no resuelta por este fix): si dos resultsets
        CONSECUTIVOS tienen exactamente la MISMA forma (igual cantidad de columnas), esta
        heuristica no puede distinguir el encabezado del segundo resultset de una fila de
        datos del primero -- `_execute_raw()` ya descarta las lineas '(N rows affected)'
        que en tsql real delimitan cada resultset, y no hay otro marcador de frontera
        disponible en el output filtrado. En ese caso ambos resultsets se fusionan en uno
        y la fila de encabezado del segundo aparece como una fila de datos espuria (ver
        test `test_multiples_resultsets_mismo_ancho_limitacion_conocida`). No aplica al
        caso real que motiva este fix (resultset de negocio vs. `return_code`, que siempre
        tienen anchos distintos)."""
        lines = output.strip().split('\n')

        for line in lines:
            if re.match(r'Msg \d+ \(severity (1[1-9]|[2-9]\d)', line):
                return [[{'_error': line.strip()}]]

        data_lines = [l.strip() for l in lines if l.strip()]
        data_lines = [l for l in data_lines if not (l.startswith('(') and 'row' in l.lower())]

        def _parse_header(line: str) -> List[str]:
            if '\t' in line:
                return [c.strip() for c in line.split('\t') if c.strip()]
            return line.split()

        def _try_parse_row(line: str, cols: List[str]) -> Optional[Dict[str, Any]]:
            if '\t' in line:
                parts = [p.strip() for p in line.split('\t')]
            else:
                if len(cols) == 1:
                    parts = [line]
                else:
                    parts = line.split(None, len(cols) - 1)
            if len(parts) != len(cols):
                return None
            return {col: self._convert_value(val) for col, val in zip(cols, parts)}

        resultsets: List[List[Dict[str, Any]]] = []
        columns: Optional[List[str]] = None
        current_rows: List[Dict[str, Any]] = []

        for line in data_lines:
            if columns is not None:
                row = _try_parse_row(line, columns)
                if row is not None:
                    current_rows.append(row)
                    continue
                # La linea no calza con la forma actual -> cierra el resultset en curso;
                # esta linea pasa a tratarse como encabezado del siguiente.
                resultsets.append(current_rows)
                columns = None
                current_rows = []

            new_columns = _parse_header(line)
            if new_columns:
                columns = new_columns
                current_rows = []
            # una linea de encabezado vacia (sin columnas parseables) se ignora: columns
            # sigue None y la siguiente linea se intenta de nuevo como encabezado.

        if columns is not None:
            resultsets.append(current_rows)

        return resultsets

    def _convert_value(self, value: str) -> Any:
        """Convertir string a tipo apropiado."""
        value = value.strip()

        if value.upper() == 'NULL':
            return None

        try:
            return int(value)
        except ValueError:
            pass

        try:
            return float(value)
        except ValueError:
            pass

        return value

    def _kill_process(self):
        """Mata el proceso tsql y cierra el PTY."""
        if self._proc and self._proc.poll() is None:
            try:
                self._proc.kill()
                self._proc.wait(timeout=5)
            except Exception:
                pass
        if self._master_fd is not None:
            try:
                os.close(self._master_fd)
            except Exception:
                pass
        self._proc = None
        self._master_fd = None
        self._connected = False

    def close(self):
        """Cerrar proceso tsql. Mata si no responde en 5s."""
        if self._proc and self._proc.poll() is None:
            try:
                self._proc.stdin.write(b'quit\n')
                self._proc.stdin.flush()
                self._proc.wait(timeout=5)
            except Exception:
                pass
        self._kill_process()


def test_connection():
    """Test de conexion persistente."""

    conn = SybaseTsqlConnection(
        server=os.getenv('SYBASE_SERVER', 'sybasedvp1'),
        user=os.getenv('SYBASE_USER', 'operadorPas'),
        password=os.getenv('SYBASE_PASS', ''),
        database='cob_ahorros'
    )

    print("Conectando (persistente con PTY)...")
    if conn.connect():
        print("OK")

        rows = conn.execute_query("SELECT @@servername as server")
        if rows:
            print(f"Servidor: {rows[0].get('server', 'N/A')}")

        rows2 = conn.execute_query("SELECT COUNT(*) as cnt FROM sysobjects WHERE type='P' AND name LIKE 'sp_ahndc%'")
        print(f"SPs NDNC: {rows2[0].get('cnt', 0) if rows2 else 0}")

        import time
        t0 = time.time()
        for i in range(10):
            conn.execute_query(f"SELECT {i} as val")
        t1 = time.time()
        print(f"10 queries: {t1-t0:.2f}s ({(t1-t0)/10*1000:.0f}ms/query)")

        conn.close()
        print("Cerrado OK")
        return True
    else:
        print("FALLO")
        return False


if __name__ == '__main__':
    import sys
    sys.exit(0 if test_connection() else 1)

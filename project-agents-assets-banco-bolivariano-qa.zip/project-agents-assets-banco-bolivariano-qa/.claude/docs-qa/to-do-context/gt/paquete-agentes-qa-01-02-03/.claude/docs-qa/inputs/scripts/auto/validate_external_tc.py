#!/usr/bin/env python3
"""
validate_external_tc.py - Valida y normaliza un documento de casos de prueba ENTREGADO POR BANCO.

Desde JUL-2026 el banco entrega SIEMPRE el documento de casos en formato PLANTILLA-CASOS-PRUEBA.
Este script REEMPLAZA la logica generativa del agente-qa-auto-01: ya no se generan TCs desde tc_gen.
El agente-01 pasa a ser un wrapper delgado que invoca este script.

Hace 3 cosas, en orden:

  1. VALIDA el doc de banco contra la plantilla (checks deterministas):
       - encabezado `# Casos de Prueba - SP `<sp>`` + `**Base de datos:**`
       - todo caso empieza con `### TC<numero>` (FALLA si `TCO-CON-###` u otra variante con letra tras TC)
       - todo `**Resultado esperado:**` trae `RETURN <entero>` (FALLA si `RETURN @variable` o ausente)
       - toda fila de parametro usa `| **@param** | ... |` CON negritas (sesion y por-caso)
     Si algo no cumple -> FAIL con reporte de linea + ejemplo correcto. NO auto-arregla datos de negocio.

  2. PRUEBA de ejecucion: corre parse_test_cases.py en seco sobre el doc scaffoldeado y exige
     PARSE_COMPLETENESS: PASS (N/N).

  3. SCAFFOLDING en ORDEN CANONICO de la plantilla: reordena las secciones (CONFIG arriba) e inserta
     DUMMY solo lo ausente (CONFIG con `—`, DICCIONARIO con "Pendiente", EJECUCION POR GRUPOS).
     Los marcadores dummy son EXACTAMENTE los que el agente-04 reconoce para reemplazar post-desarrollo.
     El contenido de negocio de banco (encabezado, SESION, GRUPOS, TCs, PRE/POST, resultado) es INMUTABLE.

Uso:
    python3 validate_external_tc.py <doc_banco.md> [--out <ruta_salida>] [--check-only] [--sp <sp_name>]

    Por defecto: valida -> prueba parser -> si PASS escribe el scaffold en
    <doc>/../../auto/qa_casos_prueba.md (el artefacto que consume el pipeline).
    --check-only: solo valida y reporta, no escribe nada.

Codigos de salida:
    0 = PASS (validado + scaffoldeado, o --check-only sin violaciones)
    1 = FAIL de validacion de formato
    2 = FAIL de la prueba del parser (parse_test_cases.py no parsea N/N)
    3 = error de uso / archivo no encontrado
"""
import sys
import os
import re
import subprocess
import tempfile

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PARSER = os.path.join(SCRIPT_DIR, 'parse_test_cases.py')

sys.path.insert(0, SCRIPT_DIR)
import sql_readonly_guard  # noqa: E402 - barrera fail-closed de discovery (NCBE-1178)

# --- marcadores dummy (deben coincidir con lo que busca agente-qa-auto-04) ---
CONFIG_PLACEHOLDER = '—'
DICCIONARIO_DUMMY = (
    'Pendiente: se generara con agente-qa-auto-04-test-cases-config una vez '
    'exista el codigo Java del microservicio.'
)


# ==========================================================================
# Utilidades de estructura
# ==========================================================================

def split_lines_with_fences(content):
    """Devuelve lista de (linea, dentro_de_fence_bool)."""
    out = []
    in_fence = False
    for line in content.split('\n'):
        stripped = line.strip()
        if stripped.startswith('```'):
            out.append((line, in_fence))  # la propia linea de fence no es contenido
            in_fence = not in_fence
            continue
        out.append((line, in_fence))
    return out


def parse_sections(content):
    """Parte el doc en (header_block, [(titulo_h2, cuerpo, linea_inicio), ...]).

    header_block = todo antes del primer `## ` (encabezado + lo que haya).
    Los `## ` dentro de fences de codigo se ignoran.
    """
    lines = content.split('\n')
    in_fence = False
    section_starts = []  # (idx, titulo)
    for i, line in enumerate(lines):
        if line.strip().startswith('```'):
            in_fence = not in_fence
            continue
        if not in_fence and re.match(r'^## ', line):
            titulo = line[3:].strip()
            section_starts.append((i, titulo))

    if not section_starts:
        return content, []

    header_block = '\n'.join(lines[:section_starts[0][0]]).rstrip()
    sections = []
    for j, (idx, titulo) in enumerate(section_starts):
        end = section_starts[j + 1][0] if j + 1 < len(section_starts) else len(lines)
        body = '\n'.join(lines[idx:end]).rstrip()
        sections.append((titulo, body, idx + 1))
    return header_block, sections


def norm_title(t):
    """Normaliza un titulo de seccion para clasificarlo."""
    return re.sub(r'\s+', ' ', t.strip().upper())


# ==========================================================================
# 1. VALIDACION
# ==========================================================================

CASE_HEADER_OK = re.compile(r'^### (TC\d+\w*)\s*[—–\-]\s*(.+)')
CASE_HEADER_ANY = re.compile(r'^### (.+)')
RETURN_NUM = re.compile(r'RETURN\s+`?(-?\d+)`?')
RETURN_VAR = re.compile(r'RETURN\s+@')
# NCBE-1343: forma alternativa de "Resultado esperado" -- excepcion Sybase nativa esperada (nunca
# un RETURN de aplicacion). Exige los 3 campos numericos completos (mensaje/level/state); un "Msg"
# incompleto (falta Level o State) NO matchea -> sigue cayendo en RETURN_AUSENTE mas abajo.
SQL_EXCEPTION_PATTERN = re.compile(r'Msg\s+\d+\s*,\s*Level\s+\d+\s*,\s*State\s+\d+', re.IGNORECASE)


def validate(content):
    """Devuelve lista de violaciones. Cada una: dict(linea, tipo, detalle, ejemplo)."""
    viol = []
    lines = content.split('\n')

    # --- encabezado ---
    if not re.search(r'^# Casos de Prueba - SP `[^`]+`', content, re.MULTILINE):
        viol.append(dict(linea=1, tipo='ENCABEZADO',
                         detalle="Falta el encabezado `# Casos de Prueba - SP `<sp>``",
                         ejemplo='# Casos de Prueba - SP `pa_fir_consulta_firmante`'))
    if not re.search(r'\*\*Base de datos:\*\*\s*`[^`]+`', content):
        viol.append(dict(linea=1, tipo='ENCABEZADO',
                         detalle="Falta `**Base de datos:** `<db>``",
                         ejemplo='**Base de datos:** `firmas` (Sybase)'))

    # --- casos (bloques que contienen "Resultado esperado") ---
    blocks = re.split(r'(?=^### )', content, flags=re.MULTILINE)
    for block in blocks:
        if not block.strip().startswith('### '):
            continue
        header_line = block.split('\n', 1)[0].strip()
        es_caso = '**Resultado esperado:**' in block
        if not es_caso:
            continue  # ### que no es caso (ej. "### Nivel padre" en TABLAS MONITOREADAS)

        lineno = _lineno_of(lines, header_line)

        # ID del caso
        if not CASE_HEADER_OK.match(header_line):
            titulo = CASE_HEADER_ANY.match(header_line)
            actual = header_line
            viol.append(dict(linea=lineno, tipo='ID_CASO',
                             detalle=f"El caso no empieza con `### TC<numero>`: '{actual}'",
                             ejemplo='### TC03 — CNB sin parametro ALCNB retorna 708153'))

        # Resultado esperado numerico
        m_res = re.search(r'\*\*Resultado esperado:\*\*(.*)', block)
        if m_res:
            res_txt = m_res.group(1)
            res_lineno = _lineno_of(lines, '**Resultado esperado:**', start_hint=lineno)
            if RETURN_VAR.search(res_txt):
                viol.append(dict(linea=res_lineno, tipo='RETURN_VARIABLE',
                                 detalle=f"Resultado esperado usa una VARIABLE, no un codigo: '{res_txt.strip()[:60]}'",
                                 ejemplo='**Resultado esperado:** `RETURN 0`  (el codigo numerico real del caso)'))
            elif not RETURN_NUM.search(res_txt) and not SQL_EXCEPTION_PATTERN.search(res_txt):
                viol.append(dict(linea=res_lineno, tipo='RETURN_AUSENTE',
                                 detalle=f"Resultado esperado sin `RETURN <entero>` ni `Msg <n>, Level <n>, State <n>`: '{res_txt.strip()[:60]}'",
                                 ejemplo='**Resultado esperado:** `RETURN 41001`  o  **Resultado esperado:** `Msg 249, Level 16, State 1`'))

    # --- filas de parametro sin negrita (fuera de fences) ---
    in_fence = False
    for i, line in enumerate(lines, start=1):
        s = line.strip()
        if s.startswith('```'):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        if not s.startswith('|'):
            continue
        cells = [c.strip() for c in s.strip('|').split('|')]
        if not cells:
            continue
        first = cells[0]
        # fila de parametro = primera celda referencia un @param
        if re.search(r'@\w+', first):
            if not re.search(r'\*\*\s*@\w+\s*\*\*', first):
                viol.append(dict(linea=i, tipo='PARAM_SIN_NEGRITA',
                                 detalle=f"Fila de parametro sin negrita en el nombre: '{first}'",
                                 ejemplo='| **@s_ssn** | 950001 | Sesion de prueba |'))

    return viol


def _lineno_of(lines, needle, start_hint=0):
    for i in range(max(0, start_hint - 1), len(lines)):
        if needle in lines[i]:
            return i + 1
    for i, l in enumerate(lines, start=1):
        if needle in l:
            return i
    return 1


# ==========================================================================
# 3. SCAFFOLDING (orden canonico)
# ==========================================================================

def is_read_only(content):
    """True si NINGUN bloque PRE/POST contiene mutaciones (INSERT/UPDATE/DELETE/ALTER)."""
    for m in re.finditer(r'```sql\s*\n(.*?)```', content, re.DOTALL):
        sql = m.group(1)
        # ignorar lineas comentadas
        code = '\n'.join(l for l in sql.split('\n') if not l.strip().startswith('--'))
        if re.search(r'\b(INSERT|UPDATE|DELETE|ALTER)\b', code, re.IGNORECASE):
            return False
    return True


def dummy_config(sp_name):
    return (
        "## CONFIG\n\n"
        "| Parametro | Valor |\n"
        "|-----------|-------|\n"
        f"| sp_name | {sp_name} |\n"
        f"| microservice | {CONFIG_PLACEHOLDER} |\n"
        f"| environment | {CONFIG_PLACEHOLDER} |\n"
        f"| base_url | {CONFIG_PLACEHOLDER} |\n"
        f"| endpoint | {CONFIG_PLACEHOLDER} |\n"
        f"| grpc_host | {CONFIG_PLACEHOLDER} |\n"
        f"| grpc_proto_path | {CONFIG_PLACEHOLDER} |\n"
        f"| grpc_proto_file | {CONFIG_PLACEHOLDER} |\n"
        f"| grpc_service_method | {CONFIG_PLACEHOLDER} |\n"
    )


def dummy_diccionario():
    return f"## DICCIONARIO SP-REST\n\n{DICCIONARIO_DUMMY}\n"


def dummy_tablas_monitoreadas():
    return (
        "## TABLAS MONITOREADAS\n\n"
        "SP de solo lectura o pendiente de analisis — completar si el SP muta tablas.\n\n"
        "| Tabla | Base | Operacion | Campo cuenta | Top | Campos a ignorar | Filtro contenido |\n"
        "|-------|------|-----------|--------------|-----|------------------|------------------|\n"
        "| (ninguna) | — | — | — | — | — | — |\n"
    )


def dummy_ejecucion_por_grupos(grupos, read_only):
    header = (
        "## EJECUCION POR GRUPOS\n\n"
        "<!-- DUMMY generado por validate_external_tc.py — revisar y completar manualmente. -->\n"
    )
    if read_only:
        todos = ", ".join(str(g) for g in grupos) if grupos else "1"
        return header + (
            "<!-- SP de solo lectura: sin riesgo de colision entre lotes. "
            "Lote unico secuencial suficiente. -->\n\n"
            "| Lote | Grupos |\n"
            "|------|--------|\n"
            f"| 1 | {todos} |\n"
        )
    return header + (
        "<!-- SP que MUTA BD: definir aislamiento de cuentas/ordenes por lote antes de "
        "correr en paralelo (ver V-GRP-01). NO ejecutar en paralelo hasta completar. -->\n\n"
        "| Lote | Grupos |\n"
        "|------|--------|\n"
        "| 1 | PENDIENTE-definir-aislamiento |\n"
    )


def diccionario_tiene_datos(body):
    """True si la seccion DICCIONARIO ya trae una tabla con filas reales (no placeholder)."""
    if re.search(r'Pendiente|se generar', body, re.IGNORECASE):
        return False
    return '|' in body and re.search(r'\|\s*return_code\s*\|', body, re.IGNORECASE) is not None


def scaffold(content, sp_name):
    """Reconstruye el doc en orden canonico, insertando dummy en lo ausente."""
    header_block, sections = parse_sections(content)

    found = {}          # titulo_normalizado -> body
    grupos_bodies = []  # [(num, body)]
    otras = []          # secciones no reconocidas -> se preservan
    conocidas = {
        'CONFIG', 'CONVENCIONES', 'PARAMETROS DE SESION POR DEFECTO',
        'TABLAS MONITOREADAS', 'DICCIONARIO SP-REST', 'EJECUCION POR GRUPOS',
    }

    for titulo, body, _ in sections:
        nt = norm_title(titulo)
        mg = re.match(r'GRUPO\s+(\d+)', nt)
        if mg:
            grupos_bodies.append((int(mg.group(1)), body))
            continue
        if nt in conocidas:
            found[nt] = body
        elif nt.startswith('TABLAS MONITOREADAS POR'):
            found['TABLAS MONITOREADAS POR SPS HIJOS'] = body
        else:
            otras.append(body)

    grupos_bodies.sort(key=lambda x: x[0])
    grupo_nums = [g for g, _ in grupos_bodies]
    read_only = is_read_only(content)

    parts = [header_block, '---']

    # 2. CONFIG
    parts.append(found.get('CONFIG', dummy_config(sp_name)))
    parts.append('---')

    # 3. CONVENCIONES (opcional, solo si viene)
    if 'CONVENCIONES' in found:
        parts.append(found['CONVENCIONES'])
        parts.append('---')

    # 4. PARAMETROS DE SESION POR DEFECTO (dato de negocio; se preserva si viene)
    if 'PARAMETROS DE SESION POR DEFECTO' in found:
        parts.append(found['PARAMETROS DE SESION POR DEFECTO'])
        parts.append('---')

    # 5. GRUPOS + TCs (intocables, en orden)
    for _, body in grupos_bodies:
        parts.append(body)

    # 6. secciones no reconocidas (preservar sin perder nada)
    for body in otras:
        parts.append(body)

    # 7. TABLAS MONITOREADAS
    parts.append('---')
    parts.append(found.get('TABLAS MONITOREADAS', dummy_tablas_monitoreadas()))

    # 8. TABLAS MONITOREADAS POR SPs HIJOS (si viene)
    if 'TABLAS MONITOREADAS POR SPS HIJOS' in found:
        parts.append('---')
        parts.append(found['TABLAS MONITOREADAS POR SPS HIJOS'])

    # 9. DICCIONARIO SP-REST
    parts.append('---')
    dicc = found.get('DICCIONARIO SP-REST')
    if dicc and diccionario_tiene_datos(dicc):
        parts.append(dicc)  # ya generado por 04 — preservar
    else:
        parts.append(dummy_diccionario())

    # 10. EJECUCION POR GRUPOS
    parts.append('---')
    parts.append(found.get('EJECUCION POR GRUPOS',
                           dummy_ejecucion_por_grupos(grupo_nums, read_only)))

    return '\n\n'.join(p.strip() for p in parts if p.strip()) + '\n'


# ==========================================================================
# 3b. EXTRACCION DE QUERIES DE DESCUBRIMIENTO (para discover_data.py)
# ==========================================================================

# Un SELECT del PRE de banco que solo devuelve el marcador "sin dato" no verifica nada real.
NO_DATA_MARKERS = ('SIN_PRECONDICION', 'SIN_EFECTO', 'SIN_DATO')


def _extract_pre_blocks(content):
    """Devuelve [(tc_id, sql_pre_crudo), ...] leyendo el bloque PRE de cada TC del doc de banco."""
    out = []
    blocks = re.split(r'(?=^### )', content, flags=re.MULTILINE)
    for block in blocks:
        if not block.strip().startswith('### '):
            continue
        header = block.split('\n', 1)[0].strip()
        m = CASE_HEADER_OK.match(header)
        if not m:
            continue
        tc_id = m.group(1)
        # el bloque PRE (```sql tras "**PRE — Estado requerido en BD:**")
        mp = re.search(
            r'\*\*PRE\s*[—–\-]\s*Estado requerido en BD:\*\*\s*```sql\s*\n(.*?)```',
            block, re.DOTALL,
        )
        if mp:
            out.append((tc_id, mp.group(1).strip()))
    return out


def _parse_condicion(sql):
    """Extrae la condicion esperada del comentario `-- Condicion: ...` del PRE (para que el 02 la evalue)."""
    m = re.search(r'--\s*Condicion:\s*(.+)', sql)
    return re.sub(r'\s+', ' ', m.group(1).strip()) if m else None


def _update_to_select(cuerpo):
    """Convierte un PRE `UPDATE <tabla> SET <col>=<col> WHERE <condicion>` (patron no-op del banco
    para 'esta cuenta debe existir') en un `SELECT * FROM <tabla> WHERE <condicion>` equivalente,
    REUTILIZANDO literal la tabla y el WHERE que el banco ya escribio (nunca se inventa la condicion).
    Soporta UPDATE de una sola tabla (el patron real observado: SET col=col WHERE col=valor, un no-op
    funcional que el banco usa solo para marcar 'esta fila debe existir'). Si el UPDATE no matchea ese
    patron simple (multiples tablas, subquery, etc.) retorna None -> el caller lo deja como pendiente,
    igual que antes del fix, en vez de arriesgar una conversion incorrecta."""
    m = re.match(
        r'(?is)^\s*UPDATE\s+([\w\.]+)\s+SET\s+.*?\bWHERE\b\s+(.+)$',
        cuerpo.strip(),
    )
    if not m:
        return None
    tabla, where = m.group(1), m.group(2).strip()
    return f'SELECT * FROM {tabla} WHERE {where}'


def build_discovery_queries(content):
    """Deriva el queries.json que consume discover_data.py, REUSANDO los SELECT del PRE de banco.

    CONTRATO DE SEGURIDAD (NCBE-1178, incidente 2026-08-17 - LEER ANTES DE TOCAR ESTA FUNCION):
    `queries[]` es la UNICA lista que discover_data.py ejecuta contra Sybase real. Por eso el campo
    `query` de cada entrada de `queries[]` DEBE ser, siempre, texto verificado SELECT-only por
    `sql_readonly_guard.extract_readonly_select_prefix()` -- nunca el bloque PRE crudo tal cual lo
    escribio banco. Un PRE puede legitimamente traer un SELECT de respaldo SEGUIDO de DELETE/INSERT
    reales (banco usa ese patron para capturar el estado "antes" y luego forzar el estado "despues");
    la barrera extrae SOLO el prefijo SELECT y descarta el resto -- jamas se entrega el bloque
    completo. Ver docstring de `extract_readonly_select_prefix` para el detalle de la barrera.

    Clasifica cada TC (con o sin bloque PRE) en tres grupos, SIN morir ante ninguno:
      - queries[]:   PRE 100% SELECT, O el prefijo SELECT seguro extraido de un PRE con DML posterior
                     (marcado con `reducido_de_pre_mutante: true` para trazabilidad), O un UPDATE
                     no-op (`SET col=col WHERE ...`, patron real de banco para "esta fila debe
                     existir") convertido a `SELECT * FROM <tabla> WHERE <condicion>` y revalidado por
                     la misma barrera -> {alias=<tc>_pre, query, tier:1, condicion}.
      - no_data[]:   PRE con marcador explicito de "sin dato" (NULL/cadena vacia), O un bloque que
                     empieza DIRECTO en un verbo prohibido sin ningun SELECT lider separable
                     (preparacion de estado real -- "esta fila NO debe existir": 0 filas tras
                     ejecutarlo COMO PARTE DE LA CORRIDA REAL DEL TC, no de discovery, es el resultado
                     CORRECTO) -> N/A legitimo para discovery; discover_data.py NUNCA ejecuta estas.
      - pendientes[]:{tc_id, motivo, detalle, prosa} -> PRE en prosa / vacio / sin bloque / SQL no
                     reconocido / SELECT INTO / EXEC-EXECUTE / no separable de forma seguridad -> el
                     agente-02 debe DESCIFRARLO a mano; discover_data.py NUNCA ejecuta estas.
    La deteccion es ESTRUCTURAL (¿que verbo(s) trae cada sentencia del PRE?), nunca por keywords de
    negocio. NO se inventan queries: se reusa literal lo que banco escribio (tabla+WHERE/SELECT).

    Fix 2026-08-06: antes SOLO se aceptaba un PRE que empezara con SELECT; un PRE con UPDATE/DELETE
    (SQL valido, patron real de fidelidad-SP donde el banco entrega el estado esperado directamente)
    se clasificaba como 'prosa_no_sql' y nunca generaba discovery -> V-DISCOVERY-01 quedaba sin
    verificar NINGUN TC de un doc que use este estilo de PRE (bug real, ver NICO.md).

    Fix 2026-08-17 (NCBE-1178): ese mismo fix de 2026-08-06 introdujo el incidente inverso -- aceptaba
    TODO el bloque con tal de que EMPEZARA con SELECT, sin revisar si tenia DELETE/INSERT despues.
    7 PREs reales de banco (TC02/04/05/06/08/20/32) llegaron intactos a Sybase durante discovery y
    ejecutaron DML real (2 filas de catalogo compartido eliminadas, 1 fila espuria insertada). Este fix
    reemplaza el chequeo ingenuo `re.match(r'^\\s*SELECT\\b', cuerpo)` por la barrera fail-closed de
    `sql_readonly_guard`."""
    queries = []
    no_data = []
    pendientes = []

    con_pre = dict(_extract_pre_blocks(content))
    todos_tc = _all_case_ids(content)

    for tc_id in todos_tc:
        sql = con_pre.get(tc_id)
        if sql is None:
            # el TC no trae bloque PRE del todo -> pendiente si el escenario podria necesitar dato
            pendientes.append({'tc_id': tc_id, 'motivo': 'sin_bloque_pre', 'prosa': None})
            continue
        # quitar lineas de comentario para evaluar el cuerpo SQL real
        cuerpo = '\n'.join(l for l in sql.split('\n') if not l.strip().startswith('--')).strip()
        if not cuerpo:
            # PRE que es SOLO comentarios (prosa como comentario)
            prosa = '\n'.join(l.strip().lstrip('-').strip() for l in sql.split('\n') if l.strip())
            pendientes.append({'tc_id': tc_id, 'motivo': 'pre_solo_comentario', 'prosa': prosa})
            continue
        if any(mk in cuerpo.upper() for mk in NO_DATA_MARKERS):
            no_data.append({'tc_id': tc_id, 'motivo': 'marcador_sin_dato'})
            continue
        # Multi-statement: un PRE puede traer varias sentencias (ej. 3 DELETE de tablas distintas
        # para garantizar ausencia, o un SELECT de respaldo seguido de DELETE/INSERT reales). Se
        # examinan TODOS los verbos presentes, no solo el primero.
        verbos = {v.upper() for v in re.findall(r'^\s*(UPDATE|DELETE|INSERT|SELECT)\b', cuerpo, re.MULTILINE | re.IGNORECASE)}
        if verbos == {'UPDATE'} and cuerpo.count('UPDATE') + cuerpo.count('update') == 1:
            # patron no-op real observado: un SOLO `UPDATE <tabla> SET col=col WHERE <condicion>`
            # que el banco usa para marcar "esta fila debe existir". Se convierte a SELECT
            # equivalente (tabla+WHERE reusados literal) para que V-DISCOVERY-01 lo verifique.
            # El equivalente generado se revalida con la barrera antes de aceptarlo (defensa en
            # profundidad: nunca confiar en que un conversor produce siempre SELECT-only).
            select_eq = _update_to_select(cuerpo)
            if select_eq:
                safe_eq, _, _ = sql_readonly_guard.extract_readonly_select_prefix(select_eq)
                if safe_eq is not None:
                    queries.append({
                        'alias': f'{tc_id}_pre',
                        'query': safe_eq,
                        'uso': 'unica',
                        'tier': 1,
                        'tc_id': tc_id,
                        'condicion': _parse_condicion(sql),
                    })
                    continue

        # Barrera PRIMARIA fail-closed (NCBE-1178): nunca se entrega a discovery un bloque
        # multi-sentencia con DML aunque empiece con SELECT. Si el bloque completo es SELECT-only
        # se conserva integro (comportamiento previo preservado); si tiene un prefijo SELECT limpio
        # seguido de un verbo prohibido, se conserva SOLO ese prefijo y se descarta el resto; si no
        # es separable de forma inequivoca, no se genera query ejecutable para este TC.
        safe_sql, fue_reducido, reason = sql_readonly_guard.extract_readonly_select_prefix(cuerpo)
        if safe_sql is not None:
            entry = {
                'alias': f'{tc_id}_pre',
                'query': safe_sql,
                'uso': 'unica',
                'tier': 1,
                'tc_id': tc_id,
                'condicion': _parse_condicion(sql),
            }
            if fue_reducido:
                entry['reducido_de_pre_mutante'] = True
                entry['motivo_reduccion'] = 'select_lider_extraido_dml_posterior_descartado'
            queries.append(entry)
            continue

        if reason == 'primera_sentencia_ya_es_verbo_prohibido':
            # El bloque empieza directo en DELETE/INSERT/UPDATE/etc: preparacion de estado real
            # (garantiza ausencia/reset) -> no hay dato SELECT que discovering, y nada se ejecuta.
            no_data.append({'tc_id': tc_id, 'motivo': 'pre_mutante_ausencia'})
            continue

        # Cualquier otro caso ambiguo o peligroso (verbo no reconocido, SELECT INTO, EXEC/EXECUTE,
        # bloque no separable): no se arriesga una ejecucion dudosa -> pendiente explicito con el
        # motivo exacto de la barrera, para que el agente-02 lo descifre a mano.
        pendientes.append({
            'tc_id': tc_id,
            'motivo': 'no_separable_read_only',
            'detalle': reason,
            'prosa': cuerpo,
        })
    return queries, no_data, pendientes


def _all_case_ids(content):
    """IDs de TC (### TC<n>) que son casos reales (tienen Resultado esperado), en orden."""
    ids = []
    blocks = re.split(r'(?=^### )', content, flags=re.MULTILINE)
    for block in blocks:
        if not block.strip().startswith('### '):
            continue
        if '**Resultado esperado:**' not in block:
            continue
        m = CASE_HEADER_OK.match(block.split('\n', 1)[0].strip())
        if m:
            ids.append(m.group(1))
    return ids


def run_discovery(content, sp_name, database, out_dir):
    """Escribe queries.json y ejecuta discover_data.py -> data_discovery.json en out_dir.

    Devuelve (ok, resumen_str, n_pendientes). Requiere env vars Sybase; si faltan, degrada a
    WARN (no bloquea). Los PRE en prosa/vacio quedan como `pendientes` para el agente-02.
    """
    import json as _json
    queries, no_data, pendientes = build_discovery_queries(content)
    q_path = os.path.join(out_dir, 'discovery_queries.json')
    os.makedirs(out_dir, exist_ok=True)
    with open(q_path, 'w', encoding='utf-8') as f:
        _json.dump({
            'queries': queries,
            'no_data': no_data,
            'pendientes_descifrado': pendientes,  # el agente-02 los descifra (prosa->SQL/PRE mutante)
        }, f, ensure_ascii=False, indent=2)

    resumen_clasif = (f'{len(queries)} verificables, {len(no_data)} sin-dato (N/A), '
                      f'{len(pendientes)} PENDIENTE_DESCIFRADO (prosa/vacio -> agente-02)')

    if not (os.getenv('SYBASE_SERVER') and os.getenv('SYBASE_USER') and os.getenv('SYBASE_PASS')):
        return False, (f'{resumen_clasif}. '
                       'WARN: sin env vars Sybase -> no se ejecuto discover_data.py (queries.json queda listo).'), len(pendientes)

    if not queries:
        return True, (f'{resumen_clasif}. Sin queries ejecutables (nada que descubrir en Sybase).'), len(pendientes)

    if not database:
        # No adivinar la base (nada de fallback a 'master'): sin base declarada no se corre discovery.
        return False, (f'{resumen_clasif}. '
                       'WARN: no se pudo extraer la base de datos del encabezado del doc '
                       '(**Base de datos:** `<db>`) -> no se ejecuto discover_data.py. queries.json queda listo.'), len(pendientes)

    discover = os.path.join(SCRIPT_DIR, 'discover_data.py')
    try:
        r = subprocess.run(
            [sys.executable, discover, '--queries', q_path, '--sp-name', sp_name,
             '--database', database, '--output', out_dir],
            capture_output=True, text=True, timeout=300,
        )
    except Exception as e:  # noqa: BLE001
        return False, f'ERROR ejecutando discover_data.py: {e}', len(pendientes)
    tail = '\n'.join('    ' + l for l in (r.stdout + r.stderr).strip().split('\n')[-8:])
    discovery_path = os.path.join(out_dir, 'data_discovery.json')
    ok = os.path.exists(discovery_path)
    # discover_data.py sale con codigo 2 (distinto de la falla generica 1) cuando al menos una
    # query de PRE-condicion fue RECHAZADA por Sybase (bug real corregido, NCBE-1343/TC16): antes
    # esto nunca se propagaba -- el archivo se escribia igual y `ok` quedaba True aunque hubiera
    # una query invalida disfrazada de "sin dato". Ahora es un WARN explicito que bloquea el gate.
    if ok and r.returncode == 2:
        ok = False
        tail += ('\n    ‼ SQL_ERROR_EN_PRECONDICION: Sybase rechazo al menos una query de '
                 'descubrimiento (ver "error_sql": true en data_discovery.json) -- corregir la '
                 'query fuente antes de continuar.')
    return ok, (f'{resumen_clasif}.\n' + tail), len(pendientes)


# ==========================================================================
# 2. PRUEBA DEL PARSER (dry-run)
# ==========================================================================

def run_parser_dry(md_content):
    """Escribe md a tmp, corre parse_test_cases.py, devuelve (ok, expected, parsed, salida)."""
    with tempfile.TemporaryDirectory() as tmp:
        md_path = os.path.join(tmp, 'scaffold.md')
        with open(md_path, 'w', encoding='utf-8') as f:
            f.write(md_content)
        try:
            r = subprocess.run(
                [sys.executable, PARSER, md_path],
                cwd=tmp, capture_output=True, text=True, timeout=120,
            )
        except Exception as e:  # noqa: BLE001 - reporte de fallo del subproceso
            return False, 0, 0, f'ERROR ejecutando parser: {e}'
        out = r.stdout + r.stderr
        m = re.search(r'PARSE_COMPLETENESS:\s*PASS\s*\((\d+)/(\d+)\)', out)
        if m:
            parsed, expected = int(m.group(1)), int(m.group(2))
            return parsed == expected and expected > 0, expected, parsed, out
        return False, 0, 0, out


# ==========================================================================
# Reporte
# ==========================================================================

def print_report(viol):
    print('==============================================')
    print('  Validacion de documento externo (banco)')
    print('==============================================')
    if not viol:
        print('  Formato: PASS — cumple la plantilla')
        return
    print(f'  Formato: FAIL — {len(viol)} violacion(es)\n')
    by_type = {}
    for v in viol:
        by_type.setdefault(v['tipo'], []).append(v)
    for tipo, items in by_type.items():
        print(f'  [{tipo}] {len(items)} caso(s):')
        for v in items[:20]:
            print(f'    - L{v["linea"]}: {v["detalle"]}')
            print(f'        correcto: {v["ejemplo"]}')
        if len(items) > 20:
            print(f'    ... y {len(items) - 20} mas')
        print('')


def default_out_path(doc_path):
    """<sp>/test-cases-banco/x.md -> <sp>/auto/qa_casos_prueba.md"""
    tcb = os.path.dirname(os.path.abspath(doc_path))       # .../test-cases-banco
    sp_dir = os.path.dirname(tcb)                          # .../<sp>
    return os.path.join(sp_dir, 'auto', 'qa_casos_prueba.md')


def detect_sp_name(content, doc_path):
    m = re.search(r'^# Casos de Prueba - SP `([^`]+)`', content, re.MULTILINE)
    if m:
        return m.group(1)
    # fallback: nombre de la carpeta <sp>
    return os.path.basename(os.path.dirname(os.path.dirname(os.path.abspath(doc_path))))


# ==========================================================================
# main
# ==========================================================================

def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(3)

    doc_path = args[0]
    check_only = '--check-only' in args
    out_path = None
    sp_override = None
    if '--out' in args:
        out_path = args[args.index('--out') + 1]
    if '--sp' in args:
        sp_override = args[args.index('--sp') + 1]

    if not os.path.exists(doc_path):
        print(f'ERROR: no existe el archivo: {doc_path}')
        sys.exit(3)

    # utf-8-sig: banco entrega ocasionalmente el .md con BOM (guardado desde un editor Windows,
    # ej. Word/Notepad). El BOM (﻿) queda como primer caracter del contenido y rompe el
    # regex del encabezado (^# Casos de Prueba...) aunque el texto visible sea correcto -- bug real
    # detectado en sp_cnb_consulta_saldo. utf-8-sig lo quita SOLO si esta presente (no-op si no
    # esta) y no afecta el resto del contenido/datos de negocio. CRLF no requiere fix aparte: el
    # modo texto de Python ya normaliza \r\n -> \n al leer (universal newlines).
    with open(doc_path, 'r', encoding='utf-8-sig') as f:
        content = f.read()

    sp_name = sp_override or detect_sp_name(content, doc_path)
    print(f'  Doc:  {doc_path}')
    print(f'  SP:   {sp_name}\n')

    # 1. VALIDAR
    viol = validate(content)
    print_report(viol)
    if viol:
        print('\n  >>> RESULTADO: FAIL de formato. Corregir en el doc de banco y reenviar.')
        sys.exit(1)

    if check_only:
        print('\n  >>> RESULTADO: PASS (--check-only, no se escribio scaffold).')
        sys.exit(0)

    # 3. SCAFFOLD
    scaffolded = scaffold(content, sp_name)

    # 2. PRUEBA DEL PARSER sobre el scaffold
    ok, expected, parsed, out = run_parser_dry(scaffolded)
    print('==============================================')
    print('  Prueba del parser (parse_test_cases.py)')
    print('==============================================')
    if not ok:
        print(f'  Parser: FAIL ({parsed}/{expected})')
        print('  --- salida del parser ---')
        print('\n'.join('  ' + l for l in out.strip().split('\n')[-25:]))
        print('\n  >>> RESULTADO: FAIL de prueba del parser.')
        sys.exit(2)
    print(f'  Parser: PASS ({parsed}/{expected} TCs)')

    # escribir scaffold
    dst = out_path or default_out_path(doc_path)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    with open(dst, 'w', encoding='utf-8') as f:
        f.write(scaffolded)

    print('\n==============================================')
    print('  Scaffold escrito')
    print('==============================================')
    print(f'  Salida: {dst}')
    print(f'  TCs:    {parsed}')
    print('  Secciones dummy insertadas: CONFIG (—), DICCIONARIO (Pendiente), EJECUCION POR GRUPOS')
    print('  -> agente-04 completara CONFIG y DICCIONARIO cuando exista el micro Java.')
    print('  -> EJECUCION POR GRUPOS de SPs mutantes se completa manualmente.')

    # 4. DISCOVERY: derivar queries de los PRE de banco y ejecutarlas vs Sybase
    if '--skip-discovery' not in args:
        database = ''
        mdb = re.search(r'\*\*Base de datos:\*\*\s*`([^`]+)`', content)
        if mdb:
            database = mdb.group(1).split()[0]  # 'firmas' de '`firmas` (Sybase)'
        out_dir = os.path.dirname(dst)
        ok_disc, resumen, n_pend = run_discovery(content, sp_name, database, out_dir)
        print('\n==============================================')
        print('  Discovery (data_discovery.json)')
        print('==============================================')
        print(f'  {resumen}')
        if ok_disc:
            print(f'  -> data_discovery.json escrito en {out_dir}')
            print('  -> el agente-02 lo lee y VERIFICA existencia de cuentas / cumplimiento de condicion.')
        else:
            print('  -> discovery NO completado (ver arriba). queries.json queda para correr manual.')
        if n_pend:
            print(f'  -> ATENCION: {n_pend} TC(s) con PRE en prosa/vacio marcados PENDIENTE_DESCIFRADO')
            print('     en discovery_queries.json. El agente-02 debe traducirlos (prosa -> SQL/PRE mutante).')

    print('\n  >>> RESULTADO: PASS')
    sys.exit(0)


if __name__ == '__main__':
    main()

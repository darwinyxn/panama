#!/usr/bin/env python3
"""
parse_test_cases.py - Parsea documento de casos de prueba y genera QA-CASOS-PARSEADOS.json

Lee un archivo .md que siga la PLANTILLA-CASOS-PRUEBA.md y produce el JSON estructurado
con PRE/POST literal, parámetros completos y estructura exacta.

Uso:
    cd .claude/docs-qa/results/<sp_results_dir>/
    python3 parse_test_cases.py <archivo_casos.md>

    Ejemplo:
    python3 parse_test_cases.py ../../inputs/documents/sp_ahndc_automatica/qa_casos_prueba.md

Requiere:
    - QA-PLAN-EJECUCION.json en el directorio actual (para account_mapping)
    - Archivo .md de casos que siga la plantilla estándar (seccion PARAMETROS DE SESION POR DEFECTO)
"""
import sys
import json
import os
import re
from datetime import datetime


JSON_FILE = os.path.join(os.getcwd(), 'QA-CASOS-PARSEADOS.json')
PLAN_FILE = os.path.join(os.getcwd(), 'QA-PLAN-EJECUCION.json')


def load_plan():
    """Carga el plan de ejecución si existe."""
    if os.path.exists(PLAN_FILE):
        with open(PLAN_FILE) as f:
            return json.load(f)
    return {}


def get_account_mapping(plan):
    """Obtiene el mapeo TC→cuenta del plan."""
    return plan.get('account_mapping', {})


def resolve_microservice_name(run_context):
    """Resuelve el nombre del microservicio desde `run_context` (bloque de QA-PLAN-EJECUCION.json).
    NCBE-1343: se ha usado 2 nombres de clave distintos para el mismo dato segun quien genero el
    plan ('microservice_name' aqui, 'microservice' en el fallback de execute_all.py::main() para
    resolver sp_doc_path) -- se acepta cualquiera de los dos, en ese orden, antes de caer en
    'desconocido'. Misma funcion (duplicada, no importada) en execute_all.py para mantener cada
    script standalone -- ver test_microservice_key_fallback_ncbe1343.py para ambas."""
    run_context = run_context or {}
    return run_context.get('microservice_name') or run_context.get('microservice') or 'desconocido'


def get_sp_defaults(plan, doc_content=''):
    """Obtiene valores por defecto desde el documento de casos (seccion PARAMETROS DE SESION POR DEFECTO)."""
    defaults = {}

    # Read from document section "PARAMETROS DE SESION POR DEFECTO"
    session_match = re.search(r'## PARAMETROS DE SESION POR DEFECTO.*?\n\|.*?\n\|.*?\n(.*?)(?:\n---|\n##)', doc_content, re.DOTALL)
    if session_match:
        rows = session_match.group(1).strip().split('\n')
        for row in rows:
            param_match = re.match(r'\|\s*\*\*@(\w+)\*\*\s*\|\s*(.+?)\s*\|', row)
            if param_match:
                name = param_match.group(1)
                raw_value = param_match.group(2).strip()
                defaults[name] = resolve_param_value(raw_value)

    return defaults



def parse_document(content):
    """Parsea el documento completo y extrae header, grupos y TCs."""
    header = {}
    sp_match = re.search(r'# Casos de Prueba - SP `([^`]+)`', content)
    if sp_match:
        header['sp_name'] = sp_match.group(1)

    db_match = re.search(r'\*\*Base de datos:\*\*\s*`([^`]+)`', content)
    if db_match:
        header['database'] = db_match.group(1)

    return header


# NCBE-1178 (2026-08-18): fix de truncamiento silencioso en extract_exec_template_params. Antes,
# UNA sola linea de parametro con comentario inline SQL ('-- BAJO PRUEBA', muy comun en este
# documento para marcar el campo bajo prueba de cada TC) hacia que la regex de linea completa
# `r'\s*@(\w+)\s*=\s*([^,\n]+),?\s*$'` NO matcheara (el valor capturado por [^,\n]+ terminaba
# justo antes del comentario, pero luego exigia que el RESTO de la linea fuera solo espacios
# hasta el fin -- el comentario lo rompia) -> se interpretaba como "fin de la lista de
# parametros" y se DETENIA el escaneo ahi, perdiendo silenciosamente TODOS los parametros
# siguientes (incluidos varios obligatorios sin default del SP, ej. @s_sesn/@s_term/@s_date/
# @s_org/@s_ofi/@t_trn/@i_cta/@i_mon/@i_tsn). Fix: separar "la linea tiene forma de asignacion"
# (termina el escaneo si NO) de "el valor de ESTA asignacion es reconocible" (si no lo es, se
# omite SOLO ese parametro con un warning explicito, pero el escaneo CONTINUA).
_PARAM_ASSIGNMENT_LOOSE_RE = re.compile(r'^\s*@(\w+)\s*=\s*(.+?)\s*$')

# Formas de valor literal reconocidas, en el mismo orden en que ya las trata is_literal_value():
# string entre comillas simples (soporta comillas escapadas ''), NULL, numero (entero/decimal,
# signo opcional), o una referencia a variable local / auto-referencia OUTPUT (@nombre[, OUT]).
# Tras el valor se permite una coma final opcional y, DESPUES del valor ya reconocido (nunca
# antes -- por eso no es un simple "cortar en --"), un comentario SQL inline opcional hasta fin
# de linea. Deliberadamente estricto (no una alternativa generica ".*"): cualquier valor que no
# calce ninguna de estas 4 formas se reporta como no interpretable (fail-closed), nunca se
# inventa ni se adivina.
_PARAM_VALUE_STRICT_RE = re.compile(
    r"""^
    (
        '(?:[^']|'')*'            # string literal (comillas escapadas '' soportadas)
        |
        NULL
        |
        -?\d+(?:\.\d+)?           # numero entero o decimal, signo opcional
        |
        @\w+(?:\s+OUT(?:PUT)?)?   # referencia a variable local, o auto-referencia @x = @x OUT
    )
    \s*,?\s*
    (?:--.*)?
    $
    """,
    re.IGNORECASE | re.VERBOSE,
)


def _parse_param_value_with_comment(raw_tail):
    """Interpreta `raw_tail` (todo lo que sigue a '@nombre =' en una linea de la plantilla EXEC)
    como UN valor literal reconocido, tolerando una coma final y un comentario SQL inline
    '-- ...' que venga DESPUES del valor ya matcheado (nunca se recorta un '--' que pudiera
    quedar DENTRO de un valor, porque el valor completo debe matchear una de las 4 formas
    primero). Devuelve el valor limpio (str, con sus comillas si es string) o None si no hay un
    match inequivoco -- None es una señal de "no interpretable", nunca se asume un valor."""
    m = _PARAM_VALUE_STRICT_RE.match(raw_tail.strip())
    if not m:
        return None
    return m.group(1).strip()


def extract_exec_template_params(block):
    """Extrae los `@param = <valor>` del bloque SQL 'Plantilla de ejecucion(ón) del SP' de un TC.

    Motivo (bug real detectado en sp_cnb_consulta_saldo): banco a veces resume en la tabla de
    parametros del TC solo los campos que varian (ej. `@e_cuenta` + una fila libre de texto
    'parametros_override' que este parser NO interpreta, por no tener el prefijo `**@param**`
    exigido por param_pattern). El resto de los ~28 parametros del SP (varios obligatorios sin
    default, ej. @e_lsrv/@e_srv/@e_term/@e_tarjeta/@e_identificacion/@e_nombre) solo quedaban
    documentados dentro del bloque EXEC de la plantilla -- nunca llegaban a `parametros_entrada` ->
    el EXEC real fallaba con "expects parameter @e_lsrv, which was not supplied" (return -6) en los
    31 TCs, aunque el escenario de negocio de cada TC era perfectamente alcanzable.

    El bloque EXEC que acompaña a cada TC trae la llamada COMPLETA con TODOS los parametros del SP,
    con el valor real (fijo o variable segun el escenario) que banco ya redacto para ESE TC
    especifico -- es la fuente mas completa y precisa disponible, y coincide exactamente con el
    'parametros_override' cuando este existe (ej. TC01: override '@e_mon = 2', EXEC '@e_mon = 2').
    No se inventa nada: son valores literales que el propio banco escribio.

    Excluye las asignaciones de parametros OUTPUT (`@o_x = @o_x OUT`/`OUTPUT`) y cualquier nombre
    que empiece con 'o_' (misma convencion que exec_sp en execute_all.py).

    Algunos TCs (ej. escenarios 'supuesto_controlado' que preparan un dato antes de invocar el SP,
    como TC05 de sp_cnb_consulta_saldo) escriben la plantilla como un guion T-SQL completo: declaran
    variables locales `@v_x`, las asignan con `SELECT @v_x = 'literal'`, y el EXEC del SP las
    REFERENCIA como valor de un parametro (`@e_tarjeta = @v_tarjeta_tc05`) en vez de poner el
    literal directo. Por eso: (a) el escaneo de parametros del SP se acota a la linea EXEC en
    adelante (nunca antes -- evita capturar las asignaciones de variables locales como si fueran
    parametros del SP, bug real que producia un EXEC con 6 parametros inexistentes -> return -6);
    (b) si el valor de un parametro es una referencia `@nombre` (no `OUT`/`OUTPUT`), se resuelve
    contra las asignaciones LITERALES de variables locales previas a la linea EXEC (mismo guion,
    ej. `@v_tarjeta_tc05 = '143004'` -> `@e_tarjeta` toma `'143004'`). Si la referencia no se puede
    resolver a un literal (ej. viene de un SELECT contra una tabla), se omite esa clave -- no se
    inventa el dato, cae a los defaults/tabla explicita del TC como antes de este fix."""
    m = re.search(r'Plantilla de ejecuci[oó]n del SP.*?```sql\s*\n(.*?)```', block, re.DOTALL)
    if not m:
        return {}, []
    sql = m.group(1)

    exec_m = re.search(r'^[ \t]*EXEC\b.*$', sql, re.MULTILINE | re.IGNORECASE)
    if not exec_m:
        return {}, []

    # Variables T-SQL locales asignadas ANTES del EXEC (tabla de simbolos del guion de preparacion).
    local_vars = {}
    for vm in re.finditer(r'@(\w+)\s*=\s*([^,\n]+),?', sql[:exec_m.start()]):
        vname, vvalue = vm.group(1), vm.group(2).strip()
        if is_literal_value(vvalue):
            local_vars[vname] = vvalue

    params = {}
    unparseable = []
    for line in sql[exec_m.end():].split('\n'):
        if not line.strip():
            continue
        loose = _PARAM_ASSIGNMENT_LOOSE_RE.match(line)
        if not loose:
            # La linea NO tiene ninguna forma de '@nombre = ...' -> fin REAL de la lista de
            # parametros (tipicamente el SELECT @@ERROR .../GO que cierra la plantilla EXEC).
            break
        name, raw_tail = loose.group(1), loose.group(2)
        if name.startswith('o_'):
            continue
        value = _parse_param_value_with_comment(raw_tail)
        if value is None:
            # La linea SI parece una asignacion de parametro, pero su valor no matchea ninguna
            # forma literal reconocida (string/NULL/numero/referencia @var, con o sin comentario
            # -- ...). FAIL CLOSED por parametro: se omite SOLO este nombre (no se inventa un
            # valor) pero el escaneo del resto de la lista CONTINUA -- nunca se trunca en
            # silencio el resto de los parametros por una sola linea ambigua. Se registra en
            # `unparseable` (ademas del WARN impreso) para que el caller (build_case) pueda
            # bloquear el TC en vez de dejarlo avanzar con una parametrizacion incompleta.
            print(f"  [WARN] extract_exec_template_params: no se pudo interpretar de forma "
                  f"inequivoca el valor de @{name} en la plantilla EXEC -- se omite este "
                  f"parametro (linea: {line.strip()!r}).")
            unparseable.append(name)
            continue
        if re.match(r'^@\w+\s+OUT(PUT)?$', value, re.IGNORECASE):
            continue
        var_ref = re.match(r'^@(\w+)$', value)
        if var_ref:
            resolved = local_vars.get(var_ref.group(1))
            if resolved is None:
                continue
            value = resolved
        params[name] = value
    return params, unparseable


def parse_tc_block(block, grupo_name):
    """Parsea un bloque de TC individual."""
    tc = {}

    title_match = re.match(r'### (TC\d+\w*)\s*[—–-]\s*(.+)', block.strip())
    if not title_match:
        return None
    tc['id'] = title_match.group(1)
    tc['nombre'] = title_match.group(2).strip()
    tc['grupo'] = grupo_name

    params = {}
    param_pattern = re.compile(r'\|\s*\*\*@(\w+)\*\*\s*\|\s*(.+?)\s*\|')
    for match in param_pattern.finditer(block):
        param_name = match.group(1)
        param_value = match.group(2).strip()
        params[param_name] = param_value

    desc_match = re.search(r'\|\s*\*\*Descripci[oó]n\*\*\s*\|\s*(.+?)\s*\|', block)
    if desc_match:
        tc['descripcion_escenario'] = desc_match.group(1).strip()
    else:
        tc['descripcion_escenario'] = tc['nombre']

    # NCBE-1655 (2026-08-20): el header PRE/POST a veces trae una anotacion parentetica ANTES del
    # ':**' de cierre (ej. TC10/sp_tr_deposito_rc: "**PRE — Estado requerido en BD (EJECUTADO REAL
    # 2026-08-19 en DVP/SYBASE02, reversible):**"). El regex anterior exigia "BD:**" pegado, sin
    # tolerar esa anotacion -> extract_sql_block() no encontraba el header, precondiciones_sql
    # quedaba en [] y el PRE (mutaciones reales: INSERT/UPDATE que preparan el gate SBS) nunca se
    # ejecutaba en la corrida automatizada, aunque el TC documentara ejecucion real. Mismo patron de
    # tolerancia ya usado arriba para "Resultado esperado: (anotacion) RETURN NNNNN" -- parentesis
    # opcional, sin capturar su contenido.
    # NCBE-1655 (2026-08-20, continuacion): el header POST tiene variantes de texto reales en el doc
    # de banco mas alla de "Validaciones en BD" -- ej. TC09/sp_tr_deposito_rc: "POST — ROLLBACK y
    # verificacion:**"; TC10: "POST — Restauracion de BD (EJECUTADO REAL...):**"; TC21: "POST —
    # Validaciones en BD y restauracion:**". El regex anterior exigia la frase literal "Validaciones
    # en BD" -> postcondiciones_sql quedaba en [] para cualquier TC que documentara su POST con otra
    # redaccion, aunque el POST SI tuviera SQL ejecutable real (mutaciones de restauracion nunca
    # corrian: residuo real detectado en TC10 al re-ejecutar tras el fix de TC21 -- cc_ctacte/
    # cl_det_producto/cc_tran_servicio quedaron sin revertir). Fix generico: aceptar CUALQUIER texto
    # entre "POST —" y el ":**" de cierre (igual tolerancia que ya se usa para la anotacion opcional
    # entre parentesis), sin exigir una frase fija -- el header PRE ("Estado requerido en BD") no
    # necesita este cambio porque es consistente en las 23 entradas de este doc.
    pre_sql = extract_sql_block(block, r'\*\*PRE\s*[—–-]\s*Estado requerido en BD\s*(?:\([^)]*\))?\s*:\*\*')
    post_sql = extract_sql_block(block, r'\*\*POST\s*[—–-]\s*.*?:\*\*')

    # FIX 2026-08-05: el doc a veces antepone una anotacion `(CORREGIDO ..., reemplaza el
    # `RETURN NNNNN` documentado el ...)` ANTES del RETURN vigente (ej. TC11/TC12/TC19). El
    # regex anterior usaba `.*?` (no-DOTALL, pero SI cruza esa anotacion dentro de la misma
    # linea) y con re.search encontraba el PRIMER `RETURN NNNNN` de la linea -- que es el
    # RETURN VIEJO mencionado dentro de la anotacion, no el vigente que viene despues. Se
    # acota explicitamente a un parentesis opcional de anotacion (sin RETURN/backtick propios
    # en su interior mas alla de los que ya tiene la anotacion) antes de capturar el RETURN real.
    return_match = re.search(
        r'\*\*Resultado esperado:\*\*\s*(?:\([^)]*\)\s*)?`?RETURN\s+(-?\d+)`?', block)
    expected_return = int(return_match.group(1)) if return_match else None

    # NCBE-1343: forma alternativa de "Resultado esperado" -- una EXCEPCION SQL nativa esperada
    # (Banco documenta `Msg <n>, Level <n>, State <n>`, ej. TC33/pa_cp_cval_ctacnb: error de
    # conversion CAST que aborta el batch antes de cualquier RETURN de aplicacion). Mutuamente
    # excluyente con expected_return: solo se busca si NO hubo RETURN (un TC nunca declara ambas
    # formas a la vez). Misma tolerancia de anotacion-parentesis-previa que el RETURN de arriba,
    # por consistencia de formato.
    expected_exception = None
    if expected_return is None:
        exc_match = re.search(
            r'\*\*Resultado esperado:\*\*\s*(?:\([^)]*\)\s*)?`?'
            r'Msg\s+(\d+)\s*,\s*Level\s+(\d+)\s*,\s*State\s+(\d+)`?',
            block, re.IGNORECASE)
        if exc_match:
            expected_exception = {
                'message_number': int(exc_match.group(1)),
                'level': int(exc_match.group(2)),
                'state': int(exc_match.group(3)),
            }

    # Valor esperado del CAMPO DE RESULTADO de negocio. Cuando el SP comunica el resultado por un
    # output param (ej. aplcobis='N' -> el RETURN suele ir 0 y el codigo va en @o_error), el doc lo
    # escribe como "RETURN 0 con @<campo> = N". Se captura ese `@<campo> = N`, preservando el nombre.
    #
    # IMPORTANTE (fix falso-FAIL): la captura se ACOTA a la MISMA frase del resultado — hasta el primer
    # separador de prosa explicativa (` — `, ` (`, `.`, `;`, salto de linea). Antes usaba re.DOTALL sobre
    # todo el bloque y capturaba menciones casuales de PARAMETROS DE ENTRADA en la explicacion
    # (ej. "...delega sin validar @i_val=0.0049..." -> capturaba @i_val=0), inyectando un expected_o_error
    # espurio que hacia fallar el veredicto contra el RETURN correcto. Ahora solo mira el segmento
    # inmediato al "Resultado esperado", no la prosa posterior.
    m_res_line = re.search(r'\*\*Resultado esperado:\*\*(.*)', block)
    field_match = None
    if m_res_line:
        # segmento antes del primer separador de prosa
        seg = re.split(r'\s—\s|\s\(|\.|;|\n', m_res_line.group(1), maxsplit=1)[0]
        field_match = re.search(r'@([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*(-?\d+)', seg)
    if field_match:
        expected_result_field = field_match.group(1)   # ej. 'o_error' (o el que use el SP)
        expected_result_value = int(field_match.group(2))
    else:
        expected_result_field = None
        expected_result_value = None

    tc['params_raw'] = params
    tc['exec_template_params'], tc['exec_template_unparseable_params'] = extract_exec_template_params(block)
    tc['precondiciones_sql'] = pre_sql
    tc['postcondiciones_sql'] = post_sql
    tc['expected_return'] = expected_return
    tc['expected_exception'] = expected_exception         # None salvo excepcion SQL nativa esperada
    tc['expected_result_field'] = expected_result_field   # nombre del campo esperado (generico)
    tc['expected_o_error'] = expected_result_value        # compat: el motor consume este nombre

    return tc


_SQL_KEYWORDS = ('SELECT ', 'INSERT ', 'UPDATE ', 'DELETE ', 'ALTER ', 'DROP ')


def _line_starts_new_statement(line):
    """Retorna el keyword (sin espacio) si la linea, SIN indentacion, arranca con el keyword+espacio
    (mismo criterio que el regex previo `\\n(?=KEYWORD )`: una linea indentada es continuacion, no
    inicio de sentencia nueva). Retorna None si no aplica."""
    for kw in _SQL_KEYWORDS:
        if line.startswith(kw):
            return kw.strip()
    return None


def _split_plain_sql(lines):
    """Parte lineas (sin comentarios, ya limpias) en statements por linea que arranca (sin indentar)
    con SELECT/INSERT/UPDATE/DELETE/ALTER — necesario porque el documento no usa `GO`/`;` entre
    sentencias consecutivas. EXCEPCION: un `INSERT tabla (cols)` seguido de una linea `SELECT ...`
    (sin VALUES ni SELECT en la propia linea del INSERT) es la MISMA sentencia T-SQL — el SELECT
    provee los valores del INSERT (`INSERT ... SELECT ... FROM ...`), no arranca una sentencia nueva.
    Sin esta excepcion, un INSERT...SELECT escrito en varias lineas (formato SQL normal) se partia en
    2 statements rotos (el INSERT sin fuente de datos, y un SELECT suelto) — bug real detectado en
    sp_ah_retiro_rc 2026-08-04."""
    if not lines:
        return []

    statements = []
    current_lines = []
    current_kind = None  # 'INSERT_NO_SOURCE' | 'OTHER'

    for line in lines:
        kw = _line_starts_new_statement(line)

        if kw and current_lines:
            if kw == 'SELECT' and current_kind == 'INSERT_NO_SOURCE':
                # SELECT fuente de datos del INSERT anterior -- continuacion, no corte.
                current_kind = 'OTHER'
            else:
                statements.append('\n'.join(current_lines))
                current_lines = []
                current_kind = None

        if not current_lines:
            if kw == 'INSERT' and not re.search(r'\b(SELECT|VALUES)\b', line.upper()):
                current_kind = 'INSERT_NO_SOURCE'
            else:
                current_kind = 'OTHER'

        current_lines.append(line)

    if current_lines:
        statements.append('\n'.join(current_lines))

    return statements


_ATOMIC_BLOCK_RE = re.compile(r'--\s*ATOMIC-BEGIN\s*\n(.*?)\n--\s*ATOMIC-END\s*\n?', re.DOTALL)


def extract_sql_block(text, header_pattern):
    """Extrae un bloque SQL después de un header específico.

    Soporta bloques ATOMICOS delimitados por '-- ATOMIC-BEGIN' / '-- ATOMIC-END': su contenido
    (tipicamente DECLARE ... EXEC ... OUTPUT) se preserva como UN SOLO statement, sin partirlo por
    lineas internas que empiecen con SELECT/INSERT/UPDATE/DELETE/ALTER (ej. `SELECT @v = 1` o el
    propio EXEC). Necesario porque Sybase solo preserva variables locales dentro del MISMO batch —
    partir el bloque en varios statements rompe esas variables entre ejecuciones. El resto del SQL
    (fuera de bloques atomicos) se parte con _split_plain_sql (ver esa funcion para la excepcion
    INSERT...SELECT)."""
    match = re.search(header_pattern, text)
    if not match:
        return []

    after_header = text[match.end():]
    sql_match = re.search(r'```sql\s*\n(.*?)```', after_header, re.DOTALL)
    if not sql_match:
        return []

    sql_content = sql_match.group(1).strip()

    statements = []
    remaining = sql_content
    while True:
        atomic_match = _ATOMIC_BLOCK_RE.search(remaining)
        if not atomic_match:
            plain_lines = [
                line.rstrip() for line in remaining.split('\n')
                if line.strip() and not line.strip().startswith('--')
            ]
            statements.extend(_split_plain_sql(plain_lines))
            break

        plain_lines = [
            line.rstrip() for line in remaining[:atomic_match.start()].split('\n')
            if line.strip() and not line.strip().startswith('--')
        ]
        statements.extend(_split_plain_sql(plain_lines))

        atomic_lines = [
            line.rstrip() for line in atomic_match.group(1).split('\n')
            if line.strip() and not line.strip().startswith('--')
        ]
        if atomic_lines:
            statements.append('\n'.join(atomic_lines))

        remaining = remaining[atomic_match.end():]

    return statements if statements else [sql_content]


# Sentinel para escenario OMITIR: el parametro NO se envia al SP (prueba obligatoriedad).
# Distinto de NULL (que SI se envia con valor nulo). Omitir un param sin default dispara
# el error de Sybase "expects parameter X, which was not supplied" (return -6).
OMIT_SENTINEL = '__OMIT__'


def _strip_inline_comment(raw):
    """Quita un comentario `-- ...` al final del valor, solo si esta FUERA de comillas simples.

    El doc de banco documenta la eleccion del dato dentro de la celda del parametro, ej.:
    `'9999999999'  -- verificado: COUNT=0`. El valor real es `'9999999999'`; el resto es prosa.
    Se respeta cualquier `--` dentro de comillas (no se corta un string que lo contenga).
    """
    if raw is None:
        return raw
    in_quote = False
    for i in range(len(raw) - 1):
        ch = raw[i]
        if ch == "'":
            in_quote = not in_quote
        elif ch == '-' and raw[i + 1] == '-' and not in_quote:
            return raw[:i].strip()
    return raw


def resolve_param_value(raw_value):
    """Convierte un valor raw del documento a su tipo Python."""
    if raw_value is None:
        return None

    raw = _strip_inline_comment(raw_value.strip()).strip().strip('`')

    if raw.upper() in ('OMITIR', 'OMIT', 'NO_ENVIAR'):
        return OMIT_SENTINEL

    if raw.startswith("'") and raw.endswith("'"):
        return raw.strip("'")

    num_match = re.match(r'^(-?\d+\.?\d*)', raw)
    if num_match:
        num_str = num_match.group(1)
        if '.' in num_str:
            return float(num_str)
        return int(num_str)

    if raw.upper() in ('NULL', 'NULO'):
        return None

    return raw


def is_literal_value(raw_value):
    """Determina si el valor es literal (número, string con comillas, null, u OMITIR) o descriptivo."""
    raw = _strip_inline_comment(raw_value.strip()).strip().strip('`')
    if raw.upper() in ('NULL', 'NULO', 'OMITIR', 'OMIT', 'NO_ENVIAR'):
        return True
    if raw.startswith("'") and raw.endswith("'"):
        return True
    if re.match(r'^-?\d+\.?\d*', raw):
        return True
    return False


def build_parametros_entrada(tc, defaults, account_mapping):
    """Construye parametros_entrada completo con defaults y valores explícitos del TC."""
    params = dict(defaults)

    # Capa intermedia: valores de la plantilla EXEC del propio TC (ver extract_exec_template_params).
    # Va DESPUES de defaults (los complementa/corrige con el valor real de ESTE TC) y ANTES de la
    # tabla explicita de parametros (que sigue siendo la fuente mas autoritativa si banco decide
    # destacar un valor ahi -- no cambia el comportamiento previo para SPs donde params_raw ya
    # cubria todo).
    for doc_param, raw in tc.get('exec_template_params', {}).items():
        if is_literal_value(raw):
            params[doc_param] = resolve_param_value(raw)

    # Valores explícitos del TC prevalecen sobre defaults (y sobre la plantilla EXEC)
    for doc_param, raw in tc['params_raw'].items():
        if is_literal_value(raw):
            params[doc_param] = resolve_param_value(raw)
        elif doc_param == 't_ssn_corr':
            params[doc_param] = 0

    tc_id = tc['id']
    if 'i_cta' in tc['params_raw'] and is_literal_value(tc['params_raw']['i_cta']):
        params['i_cta'] = resolve_param_value(tc['params_raw']['i_cta'])
    elif tc_id in account_mapping:
        params['i_cta'] = account_mapping[tc_id]

    return params


def resolve_sql_variables(sql_list, params):
    """Reemplaza @i_cta y otras variables en SQL con valores reales.

    IMPORTANTE (fix 2026-08-05): el reemplazo NO debe tocar `@i_cta` cuando es el NOMBRE de un
    parametro nombrado en un EXEC/bloque atomico (`@i_cta='...'`), solo cuando es una REFERENCIA de
    valor (`WHERE tm_cta_banco = @i_cta`). El `str.replace` ciego anterior convertia `@i_cta='0000819100'`
    en `'0000819100'='0000819100'` (comparacion booleana sin sentido) -> el EXEC de priming perdia su
    parametro de cuenta -> el deposito original no cargaba cupo en la cuenta correcta -> el reverso caia
    en RETURN 35000 (bug real en TC11/TC19 de deposito). Se usa un regex con negative lookahead: reemplaza
    `@i_cta` (como palabra completa) SOLO si NO va seguido inmediatamente de `=` (name-of-param en EXEC).
    Igual para @i_fecha por simetria."""
    resolved = []
    for sql in sql_list:
        s = sql
        if params.get('i_cta'):
            s = re.sub(r'@i_cta\b(?!\s*=)', "'" + str(params['i_cta']) + "'", s)
        if params.get('i_fecha'):
            s = re.sub(r'@i_fecha\b(?!\s*=)', "'" + str(params['i_fecha']) + "'", s)
        resolved.append(s)
    return resolved


def classify_tc(tc, params):
    """Clasifica el TC por tipo, severidad, execution_mode, etc."""
    nombre = tc['nombre'].lower()
    expected = tc['expected_return']

    if expected == 0:
        tipo_op = 'HAPPY_PATH'
        severidad = 'ALTA'
    elif 'rollback' in nombre or 'fallo' in nombre:
        tipo_op = 'ROLLBACK'
        severidad = 'BLOQUEANTE'
    elif 'concurrencia' in nombre or 'timeout' in nombre or 'idempotencia' in nombre:
        tipo_op = 'CONCURRENCIA'
        severidad = 'ALTA'
    elif 'borde' in nombre or 'cero' in nombre:
        tipo_op = 'EDGE_CASE'
        severidad = 'MEDIA'
    else:
        tipo_op = 'ERROR_FUNCIONAL'
        severidad = 'ALTA'

    has_dml_pre = any(kw in ' '.join(tc['precondiciones_sql']).upper() for kw in ['INSERT', 'UPDATE', 'DELETE'])
    execution_mode = 'STATEFUL' if has_dml_pre else 'STATELESS'

    return tipo_op, severidad, execution_mode


def build_case(tc, defaults, account_mapping):
    """Construye un caso completo en formato oficial."""
    params = build_parametros_entrada(tc, defaults, account_mapping)
    pre_sql = resolve_sql_variables(tc['precondiciones_sql'], params)
    post_sql = resolve_sql_variables(tc['postcondiciones_sql'], params)
    tipo_op, severidad, execution_mode = classify_tc(tc, params)

    # NCBE-1178 (2026-08-18): gate fail-closed PARAM_PARSE_INCOMPLETE. Si
    # extract_exec_template_params encontro una o mas lineas de la plantilla EXEC con forma de
    # asignacion pero valor NO interpretable de forma inequivoca (ver
    # tc['exec_template_unparseable_params']), la parametrizacion de este TC es POTENCIALMENTE
    # INCOMPLETA -- aunque `params` no este vacio (ej. TC02 antes del fix: 3/29 params, paso el
    # chequeo de "no vacio" de abajo sin problema). NO se debe dejar avanzar el TC hacia
    # ejecucion Sybase como si estuviera completo: mejor bloquearlo explicitamente (estado
    # BLOCKED_DATOS, el mismo gate que ya usa execute_all.py::main() para saltar TCs) que dejar
    # que Sybase rechace un EXEC con parametros obligatorios faltantes, o -- peor -- que el SP
    # se ejecute con un default silencioso que no refleja la intencion real del TC.
    unparseable = tc.get('exec_template_unparseable_params') or []
    has_key_param = len(tc['params_raw']) > 0 or len(params) > 0
    if unparseable:
        estado = 'BLOCKED_DATOS'
        motivo = ('PARAM_PARSE_INCOMPLETE: la plantilla EXEC tiene valor(es) no interpretable(s) '
                  'de forma inequivoca para: ' + ', '.join(f'@{n}' for n in unparseable) +
                  ' -- parametrizacion potencialmente incompleta, el SP NO se ejecuta hasta '
                  'resolver esto (ver [WARN] en la salida del parser).')
    elif has_key_param:
        estado = 'PENDIENTE_EJECUCION'
        motivo = None
    else:
        estado = 'BLOCKED_DATOS'
        motivo = 'parametros_entrada vacio'

    return {
        'id': tc['id'],
        'nombre': tc['nombre'],
        'grupo': tc['grupo'],
        'tipo_operacion': tipo_op,
        'severidad': severidad,
        'descripcion_escenario': tc.get('descripcion_escenario', tc['nombre']),
        'estado': estado,
        'veredicto': None,
        'payload_rest': None,
        'parametros_entrada': params,
        'resultado_esperado': {
            'return_code': tc['expected_return'],
            'o_error': tc.get('expected_o_error'),
            'result_field': tc.get('expected_result_field'),
            'expected_exception': tc.get('expected_exception'),
        },
        'resultado_ejecucion': None,
        'precondiciones_sql': pre_sql,
        'postcondiciones_sql': post_sql,
        'motivo_bloqueo': motivo,
        'mutation_profile': 'MUTATES_DB' if any(kw in ' '.join(pre_sql).upper() for kw in ['INSERT', 'UPDATE', 'DELETE']) else 'READ_ONLY',
        'execution_mode': execution_mode,
        'execution_phase': 2 if execution_mode == 'STATELESS' else 3,
    }


def main():
    if len(sys.argv) < 2:
        print('Uso: python3 parse_test_cases.py <archivo_casos.md>')
        print('Ejecutar desde la carpeta de resultados (.claude/docs-qa/results/<sp_results_dir>/)')
        sys.exit(1)

    md_file = sys.argv[1]
    if not os.path.exists(md_file):
        md_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), md_file)
    if not os.path.exists(md_file):
        print(f'ERROR: No se encontro el archivo: {sys.argv[1]}')
        sys.exit(1)

    with open(md_file, 'r', encoding='utf-8') as f:
        content = f.read()

    print('==============================================')
    print('  QA Test Case Parser')
    print('==============================================')
    print(f'  Archivo:  {md_file}')
    print(f'  Output:   {JSON_FILE}')

    plan = load_plan()
    account_mapping = get_account_mapping(plan)
    defaults = get_sp_defaults(plan, content)
    header = parse_document(content)

    print(f'  SP:       {header.get("sp_name", "?")}')
    print(f'  BD:       {header.get("database", "?")}')
    print(f'  Cuentas:  {len(account_mapping)} mapeadas')
    print('==============================================')
    print('')

    tc_blocks = re.split(r'(?=^### TC\d+\w*)', content, flags=re.MULTILINE)
    tc_blocks = [b for b in tc_blocks if b.strip().startswith('### TC')]
    # NCBE-1178 (Turno 33): truncar cada bloque en el primer encabezado de 2 almohadillas
    # (`## GRUPO N`, `## PARÁMETROS DE SESIÓN POR DEFECTO`, `## TABLAS MONITOREADAS`, etc.) que
    # aparezca ANTES del siguiente `### TC`. Sin este corte, el bloque del ULTIMO TC del
    # documento se extiende hasta el final del archivo e incluye secciones de cierre -- si esas
    # secciones documentan un parametro con el MISMO nombre que una fila de la tabla de
    # parametros del propio TC (ej. "PARÁMETROS DE SESIÓN POR DEFECTO" define @s_org para TODO
    # el documento), `params_raw` se sobre-escribe silenciosamente con el valor de la sección de
    # cierre en vez del valor real del TC (bug real: TC44 con @s_org='B' propio quedaba pisado
    # por el @s_org='U' de la sección de defaults, por ser el ultimo TC del documento).
    _section_split = re.compile(r'\n(?=## [A-ZÁÉÍÓÚÑ])')
    tc_blocks = [_section_split.split(b, maxsplit=1)[0] for b in tc_blocks]

    grupo_sections = re.findall(r'## GRUPO (\d+)\s*[—–-]\s*(.+)', content)
    grupo_map = {}
    grupo_num_map = {}
    for grupo_num, grupo_name in grupo_sections:
        grupo_start = content.find(grupo_name)
        next_grupo = content.find('## GRUPO', grupo_start + 1)
        if next_grupo == -1:
            next_grupo = len(content)
        tc_ids_in_grupo = re.findall(r'### (TC\d+)', content[grupo_start:next_grupo])
        for tc_id in tc_ids_in_grupo:
            grupo_map[tc_id] = grupo_name.strip()
            grupo_num_map[tc_id] = int(grupo_num)

    cases = []
    for block in tc_blocks:
        tc_id_match = re.match(r'### (TC\d+)', block.strip())
        if not tc_id_match:
            continue
        tc_id = tc_id_match.group(1)
        grupo_name = grupo_map.get(tc_id, 'Sin grupo')

        tc = parse_tc_block(block, grupo_name)
        if tc is None:
            print(f'  [WARN] No se pudo parsear bloque de {tc_id}')
            continue

        case = build_case(tc, defaults, account_mapping)
        cases.append(case)
        has_pre = len(case['precondiciones_sql']) > 0
        has_post = len(case['postcondiciones_sql']) > 0
        print(f'  [{tc_id}] {tc["nombre"][:40]} | PRE:{len(case["precondiciones_sql"])} POST:{len(case["postcondiciones_sql"])} | {case.get("motivo_bloqueo") or case["execution_mode"]}')

    grupos_unicos = list(set(c['grupo'] for c in cases))
    error_codes = set(c['resultado_esperado']['return_code'] for c in cases if c['resultado_esperado']['return_code'] and c['resultado_esperado']['return_code'] != 0)
    stateless = sum(1 for c in cases if c['execution_mode'] == 'STATELESS')
    stateful = sum(1 for c in cases if c['execution_mode'] == 'STATEFUL')

    base_url = plan.get('run_metadata', {}).get('base_url') or plan.get('base_url')

    output = {
        'metadata': {
            'sp_objetivo': header.get('sp_name', 'sp_desconocido'),
            'base_datos': header.get('database', ''),
            'microservicio': resolve_microservice_name(plan.get('run_context')),
            'base_url': base_url,
            'fecha_generacion': datetime.now().isoformat(),
            'fuente': os.path.basename(md_file),
            'agente': 'parse_test_cases.py',
            'total_casos': len(cases),
            'total_grupos': len(grupos_unicos),
        },
        'resumen': {
            'total_casos': len(cases),
            'total_grupos': len(grupos_unicos),
            'codigos_error_unicos': len(error_codes),
            'tablas_impactadas': 0,
            'riesgos_documentados': 0,
            'total_stateless': stateless,
            'total_stateful': stateful,
            'execution_phases': {
                'phase_1_toggle': [c['id'] for c in cases if c['execution_phase'] == 1],
                'phase_2_stateless': [c['id'] for c in cases if c['execution_phase'] == 2],
                'phase_3_stateful': [c['id'] for c in cases if c['execution_phase'] == 3],
                'phase_4_abnormal': [],
            }
        },
        'casos_prueba': cases,
    }

    with open(JSON_FILE, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, separators=(',', ':'))

    # Split por grupo: genera QA-CASOS-PARSEADOS-GROUP-{N}.json
    grupos_by_num = {}
    for case in cases:
        gnum = grupo_num_map.get(case['id'], 0)
        if gnum not in grupos_by_num:
            grupos_by_num[gnum] = []
        grupos_by_num[gnum].append(case)

    group_files = []
    for gnum in sorted(grupos_by_num.keys()):
        gcases = grupos_by_num[gnum]
        group_output = {
            'metadata': {**output['metadata'], 'grupo_num': gnum, 'total_casos': len(gcases)},
            'resumen': {
                'total_casos': len(gcases),
                'total_grupos': 1,
                'grupo_num': gnum,
            },
            'casos_prueba': gcases,
        }
        group_file = os.path.join(os.getcwd(), f'QA-CASOS-PARSEADOS-GROUP-{gnum}.json')
        with open(group_file, 'w', encoding='utf-8') as f:
            json.dump(group_output, f, ensure_ascii=False, separators=(',', ':'))
        group_files.append(group_file)

    print('')
    print('==============================================')
    print('  Completado')
    print('==============================================')
    print(f'  TCs parseados: {len(cases)}')
    print(f'  Grupos:        {len(grupos_unicos)}')
    print(f'  Stateless:     {stateless}')
    print(f'  Stateful:      {stateful}')
    print(f'  Error codes:   {len(error_codes)}')
    print(f'  JSON global:   {JSON_FILE}')
    print(f'  JSONs grupo:   {len(group_files)} archivos')
    for gf in group_files:
        gnum = int(re.search(r'GROUP-(\d+)', gf).group(1))
        print(f'    GROUP-{gnum}: {len(grupos_by_num[gnum])} TCs')
    print('==============================================')

    tc_ids_in_doc = re.findall(r'### (TC\d+)', content)
    tc_ids_parsed = [c['id'] for c in cases]
    missing = set(tc_ids_in_doc) - set(tc_ids_parsed)
    if missing:
        print(f'\n  WARNING: TCs en documento pero no parseados: {sorted(missing)}')
        sys.exit(1)

    print(f'\n  PARSE_COMPLETENESS: PASS ({len(cases)}/{len(tc_ids_in_doc)})')


if __name__ == '__main__':
    main()

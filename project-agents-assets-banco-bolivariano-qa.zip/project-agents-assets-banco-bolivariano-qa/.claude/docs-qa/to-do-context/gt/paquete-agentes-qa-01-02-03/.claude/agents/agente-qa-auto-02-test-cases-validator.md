---
name: agente-qa-auto-02-test-cases-validator
author: Nicolas Rodriguez
version: 1.0.0
description: >
  Valida que los TCs generados sean ejecutables contra el ambiente real.
  Verifica coherencia de datos, PRE/POST SQL, resultado esperado e INSTRUCTIVO.
  Ejecuta queries de validacion contra Sybase para confirmar viabilidad.
tools: Read, Glob, Grep, Bash, Write
model: opus
effort: high
allowed_write_paths:
  - ".claude/docs-qa/inputs/documents/<sp_name>/auto/**"
---

# AGENTE QA — VALIDADOR DE CASOS DE PRUEBA

---

## Como invocar este agente

```
/agent agente-qa-auto-02-test-cases-validator sp_name=<nombre_sp> microservice=<nombre_microservicio>
```

---

## Restricciones absolutas de ejecucion

- Solo escribir en `.claude/docs-qa/inputs/documents/<sp_name>/auto/`.
- No modificar `qa_casos_prueba.md` — solo genera reporte de hallazgos.
- No ejecutar SPs ni modificar datos en Sybase — solo SELECTs de validacion.
- Bash solo permitido para queries SELECT de validacion via wrapper Sybase.

---

## FASE 0 — Inicializacion

### 0.1 Resolver parametros

Parametros obligatorios:
- `sp_name`: nombre del SP raiz
- `microservice`: nombre del microservicio

### 0.2 Resolver ruta a sybase-local (OBLIGATORIO)

El codigo SQL del SP y sus hijos puede estar en el repo actual o en otro repo, y en 2 layouts
reales distintos: (a) carpeta dedicada por SP (`sybase-local/<micro>/<sp_name>/sps/*.sql`), o
(b) layout plano compartido por lote (`sybase-local/_bosque/sps/<database>__<sp_name>.sql`, SIN
subcarpeta por SP — varios SPs de distintos microservicios sueltos en la misma carpeta `sps/`).
Resolver con 2 intentos, en orden — el Intento 2 solo corre si el Intento 1 no matchea nada:

**Intento 1 — carpeta dedicada:**
```bash
find /home/ssm-user -maxdepth 5 -type d -name "<sp_name>" -path "*/sybase-local/*" 2>/dev/null
```
Seleccionar la que contenga subdirectorio `sps/` con archivos `.sql`:
```bash
ls <ruta_encontrada>/sps/*.sql 2>/dev/null | head -5
```
Si matchea: `SYBASE_LOCAL_PATH` = `<ruta_encontrada>/sps`.

**Intento 2 — layout plano (SOLO si el Intento 1 no encontro ninguna carpeta):**
```bash
find /home/ssm-user -maxdepth 6 -type f -iname "*__<sp_name>.sql" -path "*/sybase-local/*" 2>/dev/null
```
Si matchea uno o mas archivos: `SYBASE_LOCAL_PATH` = el directorio padre del archivo encontrado
(la carpeta `sps/` compartida del lote — va a contener SPs de OTROS microservicios ademas del
buscado, es esperado; la lectura en 2.3/FASE 3 ya filtra por el nombre exacto
`<database>__<sp_name>.sql`, no por listar todo el directorio).

Guardar como `SYBASE_LOCAL_PATH` (la ruta completa al directorio `sps/`, propio o compartido).
Si NINGUN intento resuelve una ruta → WARN (validacion sin debugger estatico, solo checks de datos).

### 0.3 Verificar archivos de entrada

```
ARCHIVO_OK  | .claude/docs-qa/inputs/documents/<sp_name>/auto/qa_casos_prueba.md
ARCHIVO_OPC | .claude/docs-qa/inputs/documents/<sp_name>/auto/data_discovery.json
ARCHIVO_OPC | .claude/docs-qa/inputs/documents/<sp_name>/auto/discovery_queries.json
ARCHIVO_OPC | .claude/docs-qa/inputs/documents/<sp_name>/auto/INSTRUCTIVO-PREPARACION-BD.md
ARCHIVO_OPC | <SYBASE_LOCAL_PATH>/*.sql (resuelto en 0.2)
```

Si `qa_casos_prueba.md` falta → `BLOCKED | fase=0`

> **Modelo de banco (JUL-2026):** el unico ARCHIVO_OK es `qa_casos_prueba.md` (el scaffold del
> agente-01 sobre el doc de banco). Ya NO se usa `tc_gen` — la lista de TCs, sus objetivos, PRE/POST
> y resultado esperado se leen del propio `.md` (FASE 1.1). `data_discovery.json` y
> `discovery_queries.json` los genera el agente-01 reusando los SELECT de los PRE de banco; si estan,
> se usan para V-DISCOVERY-01 (verificar que las cuentas existen y cumplen la condicion del escenario).
> `discovery_queries.json` tiene 3 grupos: `queries[]` (SELECT ejecutables ya verificados),
> `no_data[]` (PRE con marcador sin-dato: NULL/vacio -> N/A) y `pendientes_descifrado[]`
> (`{tc_id, motivo, prosa}` -> PRE en prosa/vacio que V-DESCIFRADO-01 debe traducir a SQL/PRE mutante).
> Si faltan, V-DISCOVERY-01/V-DESCIFRADO-01 emiten WARN y el validador cae a consultar Sybase directo.
> `INSTRUCTIVO` es opcional: en el modelo de banco los PRE son autocontenidos, asi que los checks
> que lo cruzaban (V-PRE-08, V-POST-01(a), regla 4.1b) degradan a WARN/no-op cuando no existe.

---

## FASE 1 — Extraccion de datos de los TCs

### 1.1 Parsear qa_casos_prueba.md

Por cada TC extraer:
- `tc_id`: identificador (TC01, TC02, ...)
- `empresa`: valor de @e_empresa
- `resultado_esperado`: RETURN XXXXX, o (NCBE-1343) una EXCEPCION SQL nativa esperada
  (`expected_exception: {message_number, level, state}` cuando el "Resultado esperado" de banco es
  `Msg <n>, Level <n>, State <n>` en vez de `RETURN <n>` — mutuamente excluyente con RETURN, nunca
  ambos a la vez)
- `pre_sql`: lista de sentencias PRE
- `post_sql`: lista de sentencias POST
- `canales_usados`: canales en INSERT cc_tran_servicio del PRE (ts_tipo_chequera)
- `producto_esperado`: si el PRE muta pe_producto, cual es el producto del escenario
- `is_not_applicable`: si la descripcion contiene NOT_APPLICABLE

### 1.2 Parsear INSTRUCTIVO

Extraer que empresas/canales/causas/saldos garantiza el instructivo:
- `empresas_garantizadas`: lista de empresas con su config base
- `canales_garantizados`: por empresa, que canales existen post-instructivo
- `causas_garantizadas`: por empresa, que causas ND existen
- `saldos_garantizados`: por cuenta, que saldo base se restaura

### 1.3 Extraer objetivo/coherencia desde el .md (NO tc_gen)

> **Cambio JUL-2026:** ya NO se lee `tc_gen`. Los datos que antes venian del test_cases.json
> (objetivo, precondicion, resultado esperado) ahora se leen del propio `qa_casos_prueba.md`,
> que ya los trae porque banco entrega el doc en formato plantilla.

Por cada TC extraer del `.md`:
- `tc_id` y `titulo` (de `### TCxx — <titulo>`)
- `objective`: el titulo + la fila `**Descripcion**` si existe (describe QUE prueba el TC)
- `resultado_esperado`: el `RETURN <n>`, o la excepcion SQL nativa esperada (`Msg <n>, Level <n>,
  State <n>` — NCBE-1343) cuando el TC no tiene RETURN (para cruce de coherencia titulo↔resultado,
  V-COHER-01)
- `pre_sql` / `post_sql`: los bloques del TC (ya extraidos en 1.1)

El cruce de coherencia (titulo dice "exito" ⇒ resultado 0; titulo dice error ⇒ resultado != 0)
se hace contra estos campos del `.md`, no contra links de tc_gen.

---

## FASE 2 — Debugger estatico: recorrer SP con datos del TC

Para cada TC, leer el SP de `<SYBASE_LOCAL_PATH>/` (resuelto en 0.2)
y simular mentalmente el flujo con los datos del TC.

**TCs marcados NOT_APPLICABLE:** NO saltarlos. Si el TC tiene tabla de parametros y
resultado esperado, analizarlo igual — puede ser rehabilitable con PRE_GENERADO.
Solo saltar TCs cuyo contenido fue destruido (sin tabla de params ni resultado).

### 2.1 Proceso por TC

1. Tomar parametros del TC (@e_empresa, @e_moneda, etc.)
2. Considerar el estado de BD post-PRE (que muto el PRE)
3. Recorrer el SP secuencialmente siguiendo las bifurcaciones:
   - Primer SELECT del SP: ¿que retornaria con esta empresa post-PRE?
   - @@rowcount: ¿retorna filas o no?
   - Cada IF/ELSE: ¿que rama toma con estos datos?
   - Cada EXEC sp_hijo: ¿con que parametros lo llama? ¿la cuenta existe en la tabla destino?
   - Cada RETURN/sp_cerror: ¿llega a este punto?
4. Determinar el RETURN final del SP por esa ruta

### 2.2 Verificaciones del debugger

**V-DBG-01: Flujo alcanza resultado esperado**
El camino logico del SP con los datos del TC llega al RETURN que el TC espera.
Si no llega → FAIL(tc_id, 'V-DBG-01', 'Flujo no alcanza RETURN <esperado>. Llega a RETURN <real> en L:<linea>')
IMPORTANTE — esto aplica IGUAL a los TCs de EXITO, no solo a los de error. Un resultado de exito
NO se asume alcanzable: debe trazarse que el flujo SUPERA todos los gates previos (lookups de config
con `IF @@rowcount=0 RETURN error`, validaciones tempranas) Y que las mutaciones que condicionan el
exito afectan filas. La verificacion formal contra BD de esto la hace V-REACH-01 (FASE 3); el
debugger de FASE 2 debe MARCAR cada gate/mutacion que el exito necesita superar, para alimentarla.
No basta con que "no haya un RETURN error explicito en el camino feliz": un gate puede devolver error
silenciosamente si su lookup no encuentra fila. Trazar esos puntos.

**V-DBG-01 con excepcion SQL esperada (NCBE-1343):** si `resultado_esperado` es una excepcion nativa
(`expected_exception`, no un RETURN), el trazado NO busca un `RETURN <esperado>` — busca el punto
exacto del SP donde el motor abortaria el batch de forma nativa con esos mismos
message_number/level/state (tipico: un `CAST`/conversion implicita sobre un dato de entrada no
convertible, dentro de un `WHERE`/expresion, ANTES de cualquier `RETURN` o `exec cobis..sp_error`).
Un TC con excepcion esperada es TAN ejecutable como uno con RETURN — NO marcar NOT_APPLICABLE
solo porque `resultado_esperado` no tenga un RETURN numerico. `NOT_APPLICABLE` sigue reservado para
escenarios genuinamente no reproducibles (ej. forzar `@@error` de una dependencia sin stub/doble).

**V-DBG-01b: Coherencia de variables derivadas (parte del debugger)**
Durante el recorrido, observar las variables internas que el SP asigna desde los datos
(`@v_*`). Si una queda NULL o con valor inesperado y eso desvia el flujo respecto a lo que el
TC espera, registrarlo. La validacion formal de la semantica NULL la hace V-NULL-01 (FASE 3);
la de prerequisitos de PRE/hijos la hace V-PRE-FLOW-01 (FASE 3). El debugger de FASE 2 solo
ALIMENTA esas reglas con el flujo trazado (que rama se toma, donde queda cada variable).

> Nota: las verificaciones de PRE (prerequisitos de hijos, entrada al flujo, fallback, NULL,
> coherencia de datos) estan definidas como reglas formales en FASE 3 (V-PRE-FLOW-01,
> V-FALLBACK-01, V-NULL-01, V-DATA-01). FASE 2 produce el trazado; FASE 3 emite los veredictos.

**V-DBG-04: POST restaura todo lo que PRE muto (valores absolutos)**
Cada mutacion del PRE tiene su contraparte en POST:
- PRE UPDATE campo=X → POST UPDATE campo=valor_original
- PRE INSERT fila → POST DELETE fila
- PRE DELETE fila → POST INSERT fila (o instructivo la restaura)
- **OBLIGATORIO:** POST debe usar valores ABSOLUTOS (nunca `campo = campo + 1` o `campo - 1`)
- El POST debe dejar la cuenta en el MISMO estado que el PRE configuro (para que la fase REST parta del mismo punto)
Si falta restauracion → WARN(tc_id, 'V-DBG-04', 'PRE muta <X> pero POST no restaura')
Si POST usa valor relativo → FAIL(tc_id, 'V-DBG-04', 'POST usa operacion relativa en <campo>')

**V-SESION-01: Fidelidad de params de sesion (defaults del doc == valores que inyecta el micro)**
Validacion de NIVEL DOCUMENTO (una vez, no por-TC). Los parametros de SESION COBIS que el micro NO
expone en su API (regla COB-007) los inyecta internamente con valores FIJOS. Para que la prueba sea
100% FIEL, la seccion `## PARAMETROS DE SESION POR DEFECTO` del doc debe declararlos con EXACTAMENTE
esos valores — si el doc envia al SP un valor de sesion distinto al que el micro inyecta, el SP y el
micro NO reciben la misma entrada (aunque el resultado de negocio no cambie, la prueba no es identica).
Como validar:
  1. Leer el mapper `toDomain(...)` del micro (`infrastructure/inbound/rest/mapper/*RestMapper.java`).
     Extraer los literales que pasa para cada param de sesion (ej. debcred: ssn=0, usuario='microservicio',
     servidor=' ', oficina=0).
  2. Determinar cuales params de sesion NO estan en el Request DTO (`@JsonProperty`) -> esos son los
     INYECTADOS (aplican a esta regla). Los que SI estan en el DTO son datos de dominio reutilizados
     (ej. @s_term para SPI) -> NO aplican (los define cada TC).
  3. Comparar el valor del mapper vs el default declarado en `## PARAMETROS DE SESION POR DEFECTO`.
Si difieren → FAIL(doc, 'V-SESION-01', 'default @s_<x>=<doc_val> no coincide con el valor que inyecta
el micro (<mapper_val>); alinear para fidelidad de entrada'). Corregible por el agente-03.
Si el micro no tiene mapper legible (no-Java, o gRPC-only) → WARN y documentar el supuesto.

### 2.3 Como leer el SP

Leer `<SYBASE_LOCAL_PATH>/<database>__<sp_name>.sql`.
Identificar:
- Lineas de SELECT que asignan variables (@v_* = columna)
- Lineas de IF/ELSE con condiciones sobre variables
- Lineas de EXEC sp_hijo con parametros
- Lineas de RETURN con codigo
- Lineas de BEGIN TRAN / COMMIT / ROLLBACK

Para SPs hijos invocados, leer tambien su codigo si esta disponible en sybase-local.
Si no esta disponible, asumir que el hijo funciona correctamente si recibe parametros validos.

### 2.4 Checkpoint fase 2

```
CHECKPOINT | fase=2 | estado=OK
  tcs_analizados       : <N>
  flujo_correcto       : <N> (V-DBG-01 PASS)
  flujo_incorrecto     : <N> (V-DBG-01 FAIL)
  variables_desviadas  : <N> (V-DBG-01b, alimenta V-NULL-01/V-PRE-FLOW-01)
  post_incompleto      : <N> (V-DBG-04 WARN)
```

---

## FASE 3 — Validaciones contra Sybase (solo SELECTs)

Ejecutar queries de validacion via Bash:
```bash
cd <repo> && python3 -c "
import sys, os
sys.path.insert(0, '.claude/docs-qa/inputs/scripts')
from sybase_tsql_wrapper import SybaseTsqlConnection
conn = SybaseTsqlConnection(server=os.getenv('SYBASE_SERVER'), user=os.getenv('SYBASE_USER'), password=os.getenv('SYBASE_PASS'), database='cob_pagos')
conn.connect()
# ... queries SELECT ...
conn.close()
"
```

> **TRES tipos de SQL — no confundirlos (aclaracion de fondo, modelo de banco):**
> 1. **Query de descubrimiento** (SELECT): HALLA/verifica una cuenta que sirva al escenario. NO muta.
>    La ejecuta el agente-01 (data_discovery) o el 02. Solo confirma existencia; NO valida el escenario.
> 2. **PRE/POST mutante** (UPDATE/INSERT/DELETE): FUERZA el estado del escenario (ej. subir un saldo a
>    200) para que el SP encuentre las condiciones a probar. Lo ejecuta `execute_all.py`. El motor
>    IGNORA los SELECT en PRE/POST — solo ejecuta mutaciones.
> 3. **Snapshot** (automatico del motor): VALIDA el funcionamiento comparando el efecto en BD entre
>    SP, REST y gRPC. NO lo escribe el TC; lo hace `execute_all.py`.
> El SELECT de verificacion que banco pone en un PRE (`SELECT COUNT... -- Condicion: >0`) es del tipo 1:
> confirma que el dato EXISTE. NO prepara estado (tipo 2) ni valida el escenario (tipo 3). Cuando un
> escenario requiere FORZAR estado (ej. "cuenta con saldo>100"), hace falta un PRE mutante (tipo 2) que
> este check/apartado deben proponer — no basta con el SELECT.

### V-DISCOVERY-01: Las cuentas/datos del doc de banco existen y cumplen la condicion del escenario

Regla NUEVA (modelo de banco). Banco entrega los TCs con cuentas FIJAS pero SIN garantia de que
existan ni de que cumplan el escenario. El agente-01 ya ejecuto los SELECT de los PRE de banco
(`data_discovery.json` + `discovery_queries.json`). Este check confirma la VIABILIDAD del dato
(tipo 1 arriba); si el dato no existe o el escenario exige forzar estado, deriva a V-DESCIFRADO-01:

1. Leer `auto/discovery_queries.json` (cada entrada: `alias=<tc>_pre`, `query`, `condicion`, `tc_id`)
   y `auto/data_discovery.json` (`cuentas[<tc>_pre].valor` = resultado real de la query).
2. Para cada TC con query de descubrimiento:
   - Si `data_discovery.cuentas[<tc>_pre].valor` es `null` → el query no trajo dato →
     FAIL(tc_id, 'V-DISCOVERY-01', 'la query del PRE de banco no encontro dato en Sybase: <query>').
     Propuesta: null (banco debe corregir la cuenta, o el dato no existe en este ambiente).
   - Si trajo valor, EVALUAR la `condicion` del comentario `-- Condicion:` contra las columnas
     reales. `data_discovery.cuentas[<tc>_pre].raw_result` guarda TODAS las columnas del SELECT
     (ej. `{'existe_cte': 1, 'firmantes_cte_pre': 0}`), no solo `valor`. Evaluar cada termino de
     la condicion contra su columna homonima en `raw_result`:
     ej. condicion `firmantes_cte_pre > 0`, raw `{firmantes_cte_pre: 5}` → CUMPLE (PASS).
     ej. condicion `existe_cte = 1 Y firmantes_cte_pre = 0`, raw `{existe_cte:1, firmantes_cte_pre:0}`
     → CUMPLE (PASS). Si algun termino no se satisface → FAIL(tc_id, 'V-DISCOVERY-01',
     'la cuenta existe pero NO cumple el escenario: <condicion> vs raw <raw_result>').
   - Solo si `raw_result` no trae una columna que la condicion menciona, re-ejecutar la query
     completa contra Sybase para leerla.
3. TCs omitidos del discovery (marcador NO_DATA: NULL, cadena vacia) → N/A (no aplican dato real).

Si `data_discovery.json` / `discovery_queries.json` no existen (agente-01 no corrio discovery) →
WARN(GLOBAL, 'V-DISCOVERY-01', 'sin data_discovery — no se pudo verificar existencia de cuentas'),
y el validador cae a V-DATA-01 (consulta Sybase directo por entidad).

Este check es la contraparte de verificacion del discovery: el agente-01 confirma que la query
CORRE y trae dato; V-DISCOVERY-01 confirma que el dato SIRVE para el escenario del TC.

### V-DESCIFRADO-01: Traducir PRE en prosa/vacio a SQL ejecutable (query descubrimiento + PRE mutante)

Regla NUEVA (modelo de banco). Banco a veces entrega el PRE de un TC como PROSA ("Cuenta con
producto AHO y saldo > 100"), como comentario, o SIN bloque PRE. El agente-01 NO los ejecuta:
los marca en `discovery_queries.json` bajo `pendientes_descifrado[]` con `{tc_id, motivo, prosa}`.
Este apartado los DESCIFRA. **Aplica SOLO a los TCs de esa lista** — NO re-procesa TCs que ya
traen SQL valido (esos ya pasaron por V-DISCOVERY-01).

**Alcance/activacion:** leer `auto/discovery_queries.json` -> `pendientes_descifrado[]`. Si esta
vacio, este apartado no hace nada. Por cada TC de la lista:

1. **Entender el escenario** leyendo: la `prosa` (si la hay), el titulo del TC, sus parametros, y
   el SP en `<SYBASE_LOCAL_PATH>` (que tabla/columna corresponde al "producto AHO", que campo es el
   "saldo", etc.). NADA hardcodeado: los nombres de tabla/columna se DERIVAN del SP, igual que V-DATA-01.

2. **Componer la query de descubrimiento** (tipo 1) que HALLA una cuenta real que ya cumpla, o la
   mas cercana. Ejecutarla contra Sybase (solo SELECT):
   `SELECT TOP 1 <col_cuenta> FROM <base>..<tabla_derivada_del_SP> WHERE <condiciones_del_escenario>`
   - Si encuentra una cuenta que YA cumple el escenario completo -> proponer PRE = ese dato (sin mutar),
     tal como los TCs de firmante (solo se fija el parametro del TC a la cuenta hallada).

3. **Si el escenario requiere FORZAR estado** (el dato existe pero un atributo no cumple —ej. saldo
   insuficiente— o no hay cuenta que ya cumpla), componer ADEMAS un **PRE mutante** (tipo 2) + POST
   restaurador, con VALORES ABSOLUTOS (nunca relativos), sobre la cuenta hallada:
   ```sql
   -- PRE propuesto
   UPDATE <base>..<tabla> SET <campo_saldo> = 200.00 WHERE <col_cuenta> = '<cuenta_hallada>'
   -- POST propuesto (restaura al valor original leido antes)
   UPDATE <base>..<tabla> SET <campo_saldo> = <valor_original> WHERE <col_cuenta> = '<cuenta_hallada>'
   ```
   Esto es el patron Tier 2 (`adapta_con_pre`) que `discover_data.py` ya soporta: dato base real +
   PRE que lo adapta al escenario. El POST debe leer y restaurar el valor original (V-DBG-04).

4. **Emitir la propuesta** en el reporte para que el agente-03 la aplique al `.md`:
   - `status`: FAIL (el TC no es ejecutable tal como vino) con `propuesta` no-null.
   - `propuesta`: bloque PRE (y POST) SQL completo + el valor del parametro del TC resuelto.
   - Si NO se puede hallar ni forzar el dato (no existe base/tabla, o el escenario es irreproducible)
     -> `propuesta: null` + justificacion; el TC queda FAIL para revision manual (NO inventar).

Si `discovery_queries.json` no existe (agente-01 no corrio) -> WARN(GLOBAL, 'V-DESCIFRADO-01',
'sin discovery_queries — no se pudo saber que TCs requieren descifrado').

**Anti-hardcode (critico):** toda tabla/columna/filtro sale del SP o de la prosa del TC, NUNCA de
un valor fijo del agente. Si el SP no permite derivar el mapeo (ej. prosa ambigua sin correlato en
el SP) -> `propuesta: null` + justificacion, no adivinar.

### V-DATA-01: Entidades y recursos del TC existen en BD y son coherentes con su tipo

Regla GENERICA (consolida las antiguas V-PRE-01/02/05/06). El validador NO asume nombres de
tablas: las DERIVA del SP. Para cada entidad/recurso clave que el TC usa (la entidad de negocio
principal, su cuenta/recurso asociado, y catalogos requeridos):

1. Identificar en el SP que tabla maestra valida cada entidad (el primer SELECT que la busca
   con `IF @@rowcount=0 RETURN error`). Esa es la tabla destino.
2. Determinar el tipo/variante declarado en el TC (producto, tipo de cuenta, etc.) y a que
   tabla corresponde segun el SP.
3. Consultar Sybase: la clave existe en la tabla correcta para ese tipo.

Si la entidad no existe → FAIL(tc_id, 'V-DATA-01', '<entidad> <X> no existe en <tabla derivada del SP>')
Si existe pero en tabla de OTRO tipo (incoherencia) → FAIL(tc_id, 'V-DATA-01', 'TC declara tipo <A> pero <entidad> solo existe en tabla de tipo <B>')
Si un INSTRUCTIVO ya garantiza el recurso (INSERT IF NOT EXISTS) → PASS_WITH_INSTRUCTIVO.

**Ejemplo de razonamiento (generico):**
"El TC usa una cuenta declarada como tipo CTE. Leo el SP: para tipo CTE valida la cuenta en
la tabla de cuentas corrientes; para AHO, en la de ahorros (derivo los nombres del propio SP,
no los hardcodeo). Consulto: la cuenta del TC ¿existe en la tabla de CTE? Si solo existe en la
de AHO → FAIL: el TC declara CTE pero la cuenta es AHO (incoherencia producto-cuenta). Si no
existe en ninguna → FAIL: cuenta inexistente."

### V-TABLA-01: Toda referencia base..objeto existe en la base declarada

Regla GENERICA (previene el bug de "tabla inexistente por base equivocada", ej. reportado por banco:
`db_biz_pagos..bp_comision_orden` cuando la tabla vive en `db_sat_his`). El motor ejecuta PRE/POST con
`query_safe`, que TRAGA el error si la tabla no existe en esa base -> el mutante falla silencioso y el TC
corre sobre estado no preparado. Esta regla lo detecta ANTES de correr.

1. Extraer TODA referencia `<base>..<objeto>` de: (a) precondiciones_sql de cada TC, (b) postcondiciones_sql
   de cada TC, (c) la seccion `## TABLAS MONITOREADAS`, (d) el bloque de reset ejecutable del INSTRUCTIVO
   (`-- === PASO 1`). NO asumir nombres — extraer los que realmente aparecen en el SQL.
2. Para cada `<base>..<objeto>` UNICO, consultar Sybase:
   ```sql
   if object_id('<base>..<objeto>') is not null select 'OK' else select 'FALTA'
   ```
3. Si FALTA -> FAIL. Ademas, si el objeto existe en OTRA base, incluirlo en el mensaje (ayuda a corregir).

Si la referencia no existe en la base declarada:
→ FAIL(tc_id, 'V-TABLA-01', '<base>..<objeto> del <PRE|POST|MONITOREADAS|INSTRUCTIVO> no existe en esa base'
  ' (existe en <base_real> — corregir la base)' si se encontro en otra base)

EXCEPCION (no validar): referencias que aparecen SOLO en tablas de documentacion markdown del INSTRUCTIVO
(filas marcadas `FALTANTE`/`NOT_APPLICABLE` que explican por que un TC no aplica) NO son SQL ejecutable —
se excluyen. Distinguir: si la referencia esta dentro de un UPDATE/INSERT/DELETE/FROM ejecutable, se valida;
si esta solo en una celda de tabla `|...|` descriptiva, no.

### V-PRE-04: Resultado esperado es codigo numerico exacto

Para cada TC verificar que `resultado_esperado` sea:
- Un numero entero (0, 2103010, 99999, etc.)
- NO sea: 'dynamic', 'None', '!= 0', 'propagated', vacio

Si no es numerico → FAIL(tc_id, 'V-PRE-04', 'Resultado esperado no es numerico: <valor>')

Excepcion: TCs NOT_APPLICABLE pueden tener resultado esperado sin validar.

### V-REACH-01: El resultado esperado es ALCANZABLE (no basta que el dato exista)

Regla CRITICA. Un resultado numerico valido (V-PRE-04) NO implica que el SP pueda PRODUCIRLO con
los parametros del TC. El validador NO debe dar PASS a un TC de exito sin confirmar, contra la BD
real, que el flujo LLEGA a ese resultado. Esta es la causa #1 de falsos PASS: verificar que "el dato
existe" en vez de verificar que "el resultado es producible".

Aplica a TODO TC cuyo resultado esperado sea EXITO (codigo de OK, p.ej. 0). Dos verificaciones que
deben pasar AMBAS — si cualquiera falla, el resultado real seria un codigo de error, no el exito:

**(a) Gate de configuracion/lookup previo.** Muchos SPs consultan una tabla de configuracion ANTES
de operar (via un SP hijo de lookup o un SELECT con `IF @@rowcount=0 RETURN <error>`). El SP usa
VARIOS campos como clave de busqueda simultanea. El validador debe:
  1. Identificar el lookup y TODAS sus columnas-clave (no solo una).
  2. **Trazar el ORIGEN REAL de CADA clave (obligatorio, no opcional).** El valor que el SP envia a
     cada clave puede NO ser el parametro directo. Para CADA columna-clave del gate, clasificar su
     origen y resolver su valor efectivo con los params del TC:
       - **parametro directo** (ej. `@i_producto`),
       - **parametro de SESION reutilizado** como dato de dominio (ej. `@s_term` reusado como
         CONCEPTO CONTABLE bajo `servicio=SPI` -> clave `concepto`),
       - **variable derivada** bajo condicion (ej. `@w_concepto = <expr>` segun una rama).
     Este paso es la causa raiz de falsos PASS: una clave derivada NO resuelta deja pasar un dato
     comodin que esquiva el gate. Resolver el valor efectivo de TODAS las claves ANTES del EXISTS.
  3. Ejecutar contra BD la existencia de la fila con TODAS las claves resueltas (no un subconjunto).
     Si 0 filas → el SP retornaria el error del gate (no el exito) → FAIL, citando la clave que no
     matcheo: 'gate <lookup> no matchea: clave <k> resuelta a <v> (origen: <param/sesion/derivada>)
     no existe en <tabla>'.
  4. Idempotencia del ambiente: si el dato lo garantiza el INSTRUCTIVO via INSERT IF NOT EXISTS,
     marcar PASS_WITH_INSTRUCTIVO; si no existe ni en BD ni en instructivo → FAIL.

**(a-bis) Cobertura de rama (WARN, no bloquea).** Verificar que el dato elegido por el TC EJERZA el
flujo significativo del escenario y no tome un atajo trivial que esquive una rama relevante del SP
(un SP-hijo, un lookup, o un bloque condicional que CON OTRO valor SI se ejecutaria). Si el dato
hace que el SP salte esa rama:
  → WARN(tc_id, 'V-REACH-01', 'dato <param>=<X> esquiva la rama <Y> (L:<n>); el TC no ejerce el flujo
    completo del escenario que pretende — considerar un dato que active la rama').
No es FAIL (el resultado puede ser valido), pero advierte cobertura incompleta. Caso real que motivo
esto: un dato generico (empresa/cuenta comodin) que evitaba la consulta de tarifas/concepto contable
y daba "equivalente" ocultando que el flujo real no se completaba.

**(b) La mutacion principal afecta filas.** Si el exito depende de un UPDATE/DELETE que debe afectar
≥1 fila (y el SP retorna error si afecto 0, p.ej. rowcount=0), verificar que la entidad objetivo
tenga una fila que matchee el WHERE EXACTO de esa mutacion, en el estado correcto. OJO: el WHERE de
la mutacion puede usar una lista FIJA de valores (no el parametro del TC) — leer el WHERE real del SP,
no asumir que filtra por el parametro. Si ninguna fila matchea → rowcount=0 → error, no exito → FAIL.

→ FAIL(tc_id, 'V-REACH-01', 'Resultado <exito> inalcanzable: <gate/mutacion> no produce match con
   los params del TC; el SP retornaria <codigo_error_real> en L:<linea>'). Proponer correccion:
   ajustar el parametro que selecciona la fila existente, o adecuar el ambiente (INSERT IF NOT EXISTS
   en instructivo) si la fila debe existir y no esta, o corregir el resultado esperado al codigo real.

**Ejemplo de razonamiento (generico):**
"El TC espera exito (codigo 0). Trazo el SP: en L:X llama un SP-lookup de config con 8 claves
(producto, servicio, tipo, forma, canal, subtipo, moneda, concepto). Noto que `concepto` NO es un
parametro directo: bajo la condicion `servicio=A` el SP hace `concepto = <otro_parametro>`. Resuelvo
los 8 valores con los params del TC y ejecuto el EXISTS en BD: 0 filas. Conclusion: el lookup
retornaria su codigo de no-encontrado y el SP propagaria un error de configuracion, NO el 0 esperado.
FAIL. Ademas, aunque el lookup pasara, el UPDATE de cabecera filtra por una lista fija de formas;
verifico que la entidad del TC tenga una fila de esa lista en estado inicial — si no, rowcount=0 y
otro codigo de error. Solo si AMBAS verificaciones pasan, el exito es alcanzable y doy PASS."

### V-PRE-07: PRE tiene mecanismo para forzar error esperado

Para cada TC de tipo error_path con expected_return != 0:
- Si es error de validacion (2103010, 2103007, 2103009): el escenario natural debe
  provocar el error (empresa inexistente, periodo invalido, sin causa ND). El PRE debe
  asegurar que la condicion de error se cumpla.
- Si es error propagado (31017, 31008): el PRE debe tener mecanismo verificable
  (bloqueo, saldo insuficiente, constraint).
- Si no hay mecanismo claro → WARN(tc_id, 'V-PRE-07', 'Sin mecanismo PRE para forzar error <X>')

### V-PRE-08: Instructivo garantiza estado base

Para cada empresa/canal/causa usada por los TCs, verificar que el INSTRUCTIVO
tiene un bloque que la garantiza. Cruzar:
- Empresas usadas por TCs vs empresas en PASO 1 del instructivo
- Canales usados por TCs vs canales garantizados por INSERT IF NOT EXISTS
- Causas ND requeridas vs causas insertadas por instructivo

Si algun TC depende de un dato que el instructivo no garantiza → WARN(tc_id, 'V-PRE-08',
'TC usa <dato> que el instructivo no garantiza')

### V-CU-01: Coherencia parametros ↔ CU/GRUPO

Para cada TC, verificar que los valores de parametros clave son coherentes con el
CU/GRUPO en el que esta ubicado el TC. El parametro discriminante del CU (el que
determina en que path del SP cae el flujo) debe activar el path correcto.

Ejemplos de incoherencia:
- TC en GRUPO que cubre "opcion X" pero el param de opcion tiene valor Y (activa otro path)
- TC en GRUPO que cubre "canal no directo" pero el param de canal es un canal directo

Procedimiento:
1. Identificar el parametro discriminante del CU (el que determina en que path cae el SP)
2. Leer el valor de ese parametro en la tabla del TC
3. Trazar en el SP: con ese valor, ¿el flujo llega al path del CU declarado?

Si el parametro discriminante lleva a un path de OTRO CU:
→ FAIL(tc_id, 'V-CU-01', 'TC en GRUPO CU-XX pero @param=<valor> activa path de CU-YY')

### V-PARAM-01: Parametro bajo test explicito en tabla

Para cada TC de tipo EP/BVA/parameter_negative, verificar que la tabla de parametros
incluye al menos 1 fila con el parametro que el TC esta probando.
El objective o titulo del TC indica que parametro prueba (ej: "EP @s_user valid").

Si la tabla de parametros esta vacia o no contiene el parametro bajo test:
→ WARN(tc_id, 'V-PARAM-01', 'TC prueba @<param> pero no lo incluye en tabla de params')

### V-DATE-01: Fecha de proceso alineada con PRE SQL

Detectar si el SP lee fecha de una tabla de configuracion. Buscar en el SQL del SP
patrones como:
```
SELECT @v_fecha = convert(..., fp_fecha) FROM cobis..ba_fecha_proceso
SELECT @v_fecha = convert(..., campo) FROM <tabla_config>
```
Si se detecta, consultar esa tabla via Bash y obtener el valor actual. Luego comparar
contra todas las fechas hardcodeadas en PRE SQL de los TCs (buscar patron MM/DD/YYYY).

Si la fecha del PRE no coincide con la fecha de la tabla de config:
→ FAIL(tc_id, 'V-DATE-01', 'PRE usa fecha <X> pero <tabla>.<campo> = <Y>')

### V-GRP-01: Validacion de aislamiento entre lotes paralelos

Si el documento contiene la seccion `## EJECUCION POR GRUPOS`, validar:

1. **Extraer campos de filtro de TABLAS MONITOREADAS:**
   Parsear la seccion TABLAS MONITOREADAS y extraer los campos mencionados como "filtro:" en cada linea.
   Ejemplo: si dice "filtro: cuenta + orden" → campos de filtro son los parametros del TC que mapean a esos conceptos.
   Los parametros del TC correspondientes son:
   - "orden" → `@i_orden` (o `i_orden` en parametros_entrada)
   - "cuenta" → `@i_numcta_emp` (o `i_numcta_emp` en parametros_entrada)

2. **Agrupar TCs por lote:**
   Leer la tabla de lotes → para cada lote, obtener sus grupo_nums →
   para cada grupo, leer los TCs del grupo y sus parametros_entrada (del JSON parseado o del documento).

3. **Verificar aislamiento cruzado entre lotes:**
   Para cada campo de filtro, recopilar los valores usados por TCs de cada lote:
   - Si un valor de campo filtro aparece en TCs de 2+ lotes distintos →
     FAIL('GLOBAL', 'V-GRP-01', 'Lotes <A> y <B> comparten valor <X> en campo <Y>: colision posible en ejecucion paralela')
   - Excepcion: valores NULL o 0 no se consideran colision (son TCs de error/borde)
   - **Generar propuesta de correccion:** Para cada TC en colision, proponer cambio al valor
     correcto para su lote. Buscar datos alternativos via Sybase (ordenes con estado 'I', cuentas activas)
     y generar propuesta con formato:
     ```json
     {"accion": "AISLAMIENTO", "campo_filtro": "<nombre>", "valor_actual": "<X>", "valor_propuesto": "<Y>",
      "motivo": "TC en lote <N> comparte <campo>=<X> con lote <M>"}
     ```

4. **Validar datos en BD:**
   Para los valores usados como filtro, verificar que existan y esten en estado correcto:
   - Ordenes: consultar `SELECT te_orden_banco, te_estado_proceso FROM db_biz_pagos..bp_total_orden WHERE te_orden_banco = <valor>`
     - Si no retorna fila → FAIL('GLOBAL', 'V-GRP-01', 'Orden <X> no existe en bp_total_orden')
     - Si existe pero te_estado_proceso != 'I' → WARN('GLOBAL', 'V-GRP-01', 'Orden <X> tiene estado <Y>, requiere UPDATE a I antes de corrida')
   - Cuentas: consultar la tabla correspondiente segun tipo de cuenta del TC:
     - tipcta=3 → `SELECT cc_cta_banco, cc_estado FROM cob_cuentas..cc_ctacte WHERE cc_cta_banco = '<cuenta>'`
     - tipcta=4 → `SELECT ah_cta_banco, ah_estado FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '<cuenta>'`
     - tipcta=12 → `SELECT vi_cta_banco, vi_estado FROM cob_virtuales..vi_cuenta WHERE vi_cta_banco = '<cuenta>'`
     - Si no retorna fila → FAIL('GLOBAL', 'V-GRP-01', 'Cuenta <X> no existe en tabla de tipcta=<Y>')
     - Si existe pero estado != 'A' → WARN('GLOBAL', 'V-GRP-01', 'Cuenta <X> tiene estado <Y>, puede afectar ejecucion')

Si la seccion `## EJECUCION POR GRUPOS` NO existe → SKIP (modo secuencial, sin validacion de aislamiento).

### V-COL-01: Columnas de TABLAS MONITOREADAS existen

Para cada columna referenciada en "Campo cuenta" de TABLAS MONITOREADAS, ejecutar:
```sql
SELECT name FROM {base}..syscolumns WHERE id = object_id('{base}..{tabla}') AND name = '{columna}'
```
Si no retorna fila → FAIL(tc_id, 'V-COL-01', 'Columna {columna} no existe en {base}..{tabla}')

Aplicar tambien a columnas de subqueries (el campo del WHERE interno).

Aplicar IGUALMENTE a las columnas de la 7a columna "Filtro contenido" cuando exista (predicado
`<col> = @<param>` que acota el contenido). Cada columna referenciada ahi debe existir en
syscolumns de la misma tabla. Ademas, el `@<param>` del Filtro contenido debe estar disponible en
los parametros_entrada de los TCs (igual exigencia que "Campo cuenta"): si el param no existe, el
motor no puede resolver el filtro y caeria al enlace amplio (snapshot pesado).
Si la columna no existe → FAIL(tc_id, 'V-COL-01', 'Columna {columna} de Filtro contenido no existe en {base}..{tabla}')

### V-COL-02: Snapshot de tabla grande sin indice por la clave de enlace (performance)

Regla GENERICA. El motor hace un COUNT por tabla monitoreada en PRE y POST de cada TC, filtrando
por la clave de enlace declarada en "Campo cuenta". Si la tabla es grande (millones de filas, tipica
de tablas historicas `_his` o logs) y NO tiene indice por esa clave, el COUNT degenera en table scan
(decenas de segundos por TC). Multiplicado por 2 pasadas (SP+REST) y N TCs, vuelve la corrida
impracticable. El motor es resiliente (no aborta), pero la tabla quedaria sin monitorear (omitida por
timeout) → se PIERDE la deteccion del efecto. Hay que prevenirlo en el documento.

Procedimiento para cada tabla de TABLAS MONITOREADAS cuyo "Campo cuenta" enlaza por una clave:
1. **Tamaño:** `SELECT rowcnt = row_count(db_id('{base}'), object_id('{base}..{tabla}'))` (o
   `SELECT count(*)` acotado). Si < ~1M filas, SKIP (rapida por definicion).
2. **Indice por la clave de enlace:** consultar sysindexes/index_col y verificar si la columna de
   enlace (ej. `*_orden_banco`, `*_cta_banco`) es la PRIMERA columna de algun indice. Si lo es, SKIP.
3. Si es grande Y sin indice por la clave → buscar un indice cuya primera columna sea de FECHA
   (ej. `*_fecha_proceso`, `*_fecha_mov`). Si existe Y la tabla es **INSERT-only y el SP estampa la
   fila nueva con la fecha de proceso/hoy** (verificar en el SP que el INSERT usa `getdate()` o la
   fecha del dia, NO copia una fecha antigua) →
   PROPONER agregar al "Campo cuenta" un filtro literal antepuesto:
   `{col_fecha} >= dateadd(day,-7,getdate()) AND {clave} = @param`.
   - WARN('GLOBAL', 'V-COL-02', 'Tabla {base}..{tabla} grande sin indice por {clave}; proponer filtro
     de fecha por {col_fecha} (INSERT-only, fila estampada con fecha de hoy)')
   - La propuesta DEBE ser estructurada para que el corrector la aplique (tipo MONITOR_FILTRO):
     `{"accion": "MONITOR_FILTRO", "tabla": "{tabla}", "campo_cuenta_actual": "{clave} = @param",
       "campo_cuenta_propuesto": "{col_fecha} >= dateadd(day,-7,getdate()) AND {clave} = @param"}`
4. **Salvaguarda critica (NO proponer filtro de fecha si):**
   - La tabla es UPDATE (la fila preexiste con fecha ANTIGUA; el filtro la ocultaria y romperia la
     deteccion). En ese caso, si es grande sin indice por la clave, WARN para que el ingeniero decida
     (excluir del snapshot, o aceptar el costo).
   - El INSERT copia una fecha historica (no hoy). Igual que arriba: WARN sin proponer filtro.
   El filtro de fecha es SEGURO unicamente cuando la fila a detectar se escribe con fecha dentro del
   rango. El margen de 7 dias cubre corridas que crucen fin de semana/feriado.

El motor (build_where_clause) ya soporta condiciones literales sin `@param` mezcladas con el enlace
por parametro (exige al menos un enlace por parametro). El filtro se declara en el propio "Campo
cuenta", sin columnas nuevas.

### V-PRE-FLOW-01: PRE prepara prerequisitos de SP hijos Y los datos entran al flujo

Regla GENERICA (consolida las antiguas V-DBG-02 y V-FLOW-01). Aplica a TODO TC con PRE que
muta BD (no solo happy_path). Tres verificaciones encadenadas:

**(a) Prerequisitos de SP hijos.** Trazar el path del TC en el SP padre y listar cada
`EXEC <sp_hijo>` que se ejecutaria. Para cada hijo con codigo disponible, leer sus validaciones
de entrada (SELECT inicial + `IF @@rowcount=0 RETURN error`, validaciones tempranas). Verificar
que la PRE deja la BD en un estado que satisface esos prerequisitos.
  - Incluye explicitamente los HIJOS DE LOOKUP DE CONFIGURACION (los que consultan una tabla de
    catalogo/config con multiples claves y retornan error si no hay fila). Para estos, la verificacion
    de existencia de la fila con TODAS sus claves es la de V-REACH-01(a) — coordinar con ella. NO
    declarar el prerequisito satisfecho por verificar solo una o dos claves: el lookup usa el AND de
    todas. Y si una clave se DERIVA de otro parametro/variable (no es directa), resolver esa derivacion
    trazando el SP antes de consultar la BD.
  - CONSTANCIA (decision por-SP, NO regla global, NO genera WARN): documentar en la trazabilidad/PRE de
    cada TC happy-path la config que requiere (aunque ya exista en DVP) es una BUENA PRACTICA opcional,
    activada por SP cuando el ingeniero lo pida. NO es obligatoria y su ausencia NO se penaliza (ni WARN
    ni FAIL): un TC alcanzable con config preexistente es PASS aunque no deje constancia explicita. Si el
    SP la usa, la nota suele ir como linea en "Trazabilidad por DB": "- CONSTANCIA: requiere config X
    (ya activa en DVP / la garantiza el INSTRUCTIVO 1c)". La alcanzabilidad real la verifica V-REACH-01,
    independientemente de que haya constancia o no.

**(b) Entrada al flujo.** Identificar el primer filtro/cursor del SP padre (WHERE de un
INSERT...SELECT, condicion de cursor). Verificar que los datos que inserta la PRE cumplen TODAS
las condiciones del filtro (fecha de proceso, llaves, tipo) para que el flujo realmente los capture.

**(c) Suficiencia y restauracion de RECURSO CUANTITATIVO (saldo/cupo/disponible).** Generico:
ademas de que un dato EXISTA (a), verificar que un recurso NUMERICO que el hijo CONSUME alcance
para la operacion del TC. Procedimiento:
  1. Para cada hijo en el path, detectar si COMPARA una columna numerica contra un monto y falla
     si no alcanza — patrones: `IF <col> <= 0 RETURN <err>`, `IF <monto> > <col> ... RETURN/GOTO`,
     `IF (<monto> + <comision>) > <saldo> ...`. La columna es un recurso consumible (ej: saldo
     disponible de una cuenta, cupo, suspenso).
  2. Identificar el monto que el TC aporta (de sus parametros: @valor_debito, @valor_comision, etc.,
     usando los defaults de PARAMETROS DE SESION si el TC no los declara) y la entidad afectada
     (cuenta del TC).
  3. Consultar Sybase el valor ACTUAL de esa columna para la entidad del TC:
     `SELECT <col_recurso> FROM <base>..<tabla> WHERE <pk> = <entidad>`.
  4. Si el valor actual NO cubre el monto (recurso < monto requerido) y el resultado esperado del
     TC es exito → el hijo fallaria por recurso insuficiente (NO por el escenario que el TC quiere
     probar). FAIL con propuesta: PRE adicional que fije el recurso a un valor base suficiente
     (monto + margen) y POST que lo RESTAURE al valor real ABSOLUTO capturado (no relativo).
     El PRE/POST de recurso se SUMA al PRE/POST existente del TC, no lo reemplaza.
  5. AISLAMIENTO POR RECURSO MUTABLE (aplica SIEMPRE, no solo en ejecucion paralela): si 2+ TCs
     comparten la misma entidad cuyo recurso se CONSUME (no solo se lee), cada uno DEBE fijar el
     recurso en su PRE y restaurarlo en su POST, para que cada TC arranque de un valor base fijo
     sin depender de lo que dejo el TC anterior. Si un TC consume el recurso compartido pero su PRE
     no lo fija → FAIL (V-PRE-FLOW-01, 'recurso <col> de <entidad> es consumido y compartido por
     varios TCs pero la PRE no lo prepara: contaminacion secuencial').
  IMPORTANTE — no inflar: aplicar (c) SOLO cuando el hijo realmente consume el recurso. Si la
  columna esta deshabilitada en el codigo del hijo (ej: linea de UPDATE de saldo comentada) o el
  hijo solo registra el movimiento en una tabla de transacciones sin tocar el saldo de la cuenta,
  NO se requiere PRE de saldo. Verificar el codigo real del hijo antes de proponer.

Si la PRE no prepara un prerequisito de un hijo → FAIL(tc_id, 'V-PRE-FLOW-01', 'SP hijo <H> requiere <tabla>.<condicion> pero la PRE no lo prepara')
Si los datos de la PRE no entran al flujo del padre → FAIL(tc_id, 'V-PRE-FLOW-01', 'datos PRE no entran al flujo: <condicion> no matchea')
Si un recurso cuantitativo consumido es insuficiente o no se prepara/restaura → FAIL(tc_id, 'V-PRE-FLOW-01', 'recurso <col> de <entidad>=<valor_actual> no cubre el monto <X> del TC; PRE debe fijarlo y POST restaurarlo')
Si el hijo no tiene codigo disponible → WARN (no se puede verificar ese paso).

**Ejemplo de razonamiento (c) (generico):**
"El TC invoca al hijo H con un debito de 100. Leo H: tiene `IF @monto > @saldo RETURN error_sin_fondos`,
y @saldo viene de `SELECT col_disponible FROM cuentas WHERE pk=@cta`. Consulto Sybase: col_disponible
de esa cuenta = 3.59 < 100 → el hijo retornaria error de fondos, no el exito que el TC espera. FAIL:
PRE debe `UPDATE cuentas SET col_disponible = 200 WHERE pk=@cta` y POST `... = 3.59 ...` (valor real
restaurado). Ademas, otros 6 TCs usan la misma cuenta y la consumen → cada uno necesita su PRE/POST
de saldo para no contaminarse entre si. PERO si en H la linea `UPDATE ... col_disponible` estuviera
comentada (el saldo no se debita, solo se registra el movimiento), NO agrego PRE de saldo."

Cuando un TC con expected_return=0 NO tiene PRE, construir la propuesta `PRE_GENERADO`
(procedimiento detallado abajo). AGRUPAR TCs del mismo GRUPO que comparten ruta de hijos:
un solo analisis, misma PRE base (solo varia el parametro bajo test).

**Ejemplo de razonamiento (generico):**
"El TC invoca al hijo H. Leo H: su primer paso es `SELECT @x = col FROM tabla_M WHERE pk=@param`
seguido de `IF @@rowcount=0 RETURN err`. ¿La PRE del TC deja una fila en tabla_M con ese pk?
Si no → FAIL: la PRE no prepara el prerequisito de H, el hijo fallaria antes de operar.
Ademas: el SP padre filtra los pagos por fecha de proceso; ¿la fecha del INSERT de la PRE
coincide con la fecha de proceso vigente? Si no, el cursor no los toma → FAIL: no entran al flujo."

**Procedimiento PRE_GENERADO (cuando happy_path sin PRE):**

1. Identificar SPs hijos en la ruta del TC (trazar el flujo con los parametros del TC).
2. Por cada hijo disponible, extraer precondiciones minimas (SELECTs con IF @@rowcount=0,
   validaciones IF @param IS NULL / IF NOT EXISTS).
3. Consultar Sybase si los datos ya existen: `SELECT TOP 1 <pk> FROM <base>..<tabla> WHERE <cond>`.
   Si existe → no se necesita INSERT; si no → la PRE debe incluirlo.
4. Construir PRE acumulativo (un INSERT/UPDATE por prerequisito faltante), usar valores reales
   de data_discovery.json, cruzar contra INSTRUCTIVO (regla 4.1b), y por cada INSERT agregar
   su DELETE en POST.
5. Viabilidad: si >50% de hijos no tienen codigo → NOT_APPLICABLE con lista de hijos faltantes.
6. Emitir propuesta con `pre_sql_propuesto` + `post_sql_propuesto` (formato en 4.1).

### V-POST-01: POST no destruye datos que el instructivo u otros TCs necesitan

Regla GENERICA (consolida las antiguas V-POST-01 y V-SEQ-01). Para cada DELETE en el POST de
un TC, verificar dos cosas:

**(a) vs INSTRUCTIVO:** ¿el dato esta declarado como permanente (INSERT IF NOT EXISTS) en el
instructivo? Si si → el POST no debe borrarlo (debe restaurar con UPDATE si lo modifico).

**(b) vs TCs siguientes:** ¿algun TC posterior que comparte la misma entidad depende de ese
dato en su PRE sin recrearlo? Si si → el POST lo estaria destruyendo para el siguiente.

Si el POST borra un dato permanente del instructivo → FAIL(tc_id, 'V-POST-01', 'POST borra <tabla>.<cond> que el INSTRUCTIVO garantiza como permanente')
Si el POST borra un dato que un TC posterior necesita → WARN(tc_id, 'V-POST-01', 'POST borra <dato> que <tc_siguiente> necesita sin recrearlo')

Excepcion: si el PRE del mismo TC hizo UPDATE sobre ese campo (cambio temporal), el POST puede
restaurar con UPDATE (no DELETE). La regla solo aplica cuando el POST usa DELETE.

**Ejemplo de razonamiento (generico):**
"El POST del TC hace DELETE de un registro de catalogo C. Reviso el instructivo: declara C con
INSERT IF NOT EXISTS (permanente) → FAIL: el POST no debe borrarlo, la siguiente corrida lo
asume. Si en cambio el PRE solo cambio un campo de C con UPDATE, el POST debe revertir ese
campo con UPDATE al valor original, nunca DELETE."

### V-FLAG-01: Flags de control de SPs hijos habilitados

Para cada SP hijo invocado por el SP padre (detectar `EXEC @return = <base>..<sp_hijo>`):
1. Leer el SQL del SP hijo (si disponible en SYBASE_LOCAL_PATH)
2. Buscar patron de validacion de flag al inicio:
   ```
   SELECT ... FROM <tabla_control> WHERE <condicion>
   IF @@rowcount = 0 ... return <error_code>
   ```
3. Si se detecta un flag, consultar su estado actual via Bash:
   ```sql
   SELECT <campo_estado> FROM <tabla_control> WHERE <condicion>
   ```

Si el flag no esta en estado esperado:
→ WARN('GLOBAL', 'V-FLAG-01', 'SP hijo {sp} requiere {tabla}.{campo}={valor_esperado} pero actualmente={valor_real}')

### V-TITULO-01: El titulo del TC describe solo parametros de entrada

El nombre del TC debe describir UNICAMENTE los parametros de entrada que se envian al sistema
(opcion, canal, identificadores, valores). NO debe mencionar logica interna, efectos en BD,
nombres de tabla, ni variables internas del SP. El efecto (INSERT/UPDATE, return) va en el
RESULTADO ESPERADO, no en el titulo.

Patrones PROHIBIDOS en el titulo:
- Nombres de tabla del SP (los que aparecen en INSERT/UPDATE del codigo).
- Variables internas del SP (`@w_*`, `@v_*`, `@@rowcount`, `@@error`).
- Verbos de efecto en BD ("inserta", "actualiza", "genera", "modifica", "UPDATE", "INSERT").

Si el titulo contiene un patron prohibido → FAIL(tc_id, 'V-TITULO-01', 'Titulo describe logica interna (<patron>); debe describir solo parametros de entrada'). Proponer `titulo_propuesto` con los inputs del TC.

**Ejemplo de razonamiento (generico):**
"Titulo: 'Verifica UPDATE en bp_total_orden'. Contiene un verbo de efecto (UPDATE) y un nombre
de tabla → FAIL. El TC envia opcion='01', canal='DIR', forma='CUE'. Titulo correcto:
'Opcion 01, canal DIR, forma de pago CUE'. El hecho de que actualice bp_total_orden va en el
resultado esperado/trazabilidad, no en el nombre."
"Titulo: 'BVA minimo @w_val_por_tran > 0'. `@w_val_por_tran` es variable interna del SP → FAIL.
El input que controla esa condicion es @i_valor_comision. Titulo correcto: 'Valor comision 0.01 (borde minimo)'."

### V-FALLBACK-01: PRE de ruta de no-coincidencia (rowcount=0 → ruta alterna)

Regla GENERICA. Algunos SP intentan una operacion sobre una tabla principal y, si NO afecta
filas (`@@rowcount=0`), caen a una ruta alterna (tabla historica/fallback). Si un TC declara
probar la ruta alterna, su PRE debe forzar que la operacion principal NO encuentre filas.

Procedimiento:
1. Detectar en el SP el patron: operacion sobre tabla principal → `set @var=@@rowcount` →
   `IF @var<=0` → operacion sobre tabla alterna.
2. Si el TC apunta a esa ruta alterna, verificar que la PRE deja la tabla principal SIN la
   fila objetivo (la quito/movio) y, si aplica, la fila existe en la alterna.

Si la PRE deja la fila en la principal (la operacion principal SI afectaria filas) →
FAIL(tc_id, 'V-FALLBACK-01', 'TC prueba ruta alterna pero la PRE deja la fila en la tabla principal; la operacion principal afectaria filas y nunca se alcanza el fallback'). Proponer PRE que elimine/mueva la fila de la principal.

**Ejemplo de razonamiento (generico):**
"El SP hace UPDATE a tabla_P; si rowcount=0, hace UPDATE a tabla_P_historica. El TC dice
'probar fallback historico'. Reviso la PRE: hace INSERT/UPDATE que deja la fila activa en
tabla_P → el UPDATE principal SI afectara filas (rowcount>0) → nunca entra al fallback → FAIL.
La PRE correcta debe dejar tabla_P sin esa fila (DELETE o marcarla en estado que el WHERE no
capture) e insertar la fila en tabla_P_historica."

### V-COND-PARAM-01: Rama activada por valor de parametro tiene su config/catalogo en PRE

Regla GENERICA (absorbe el caso de la antigua V-PRE-03 sobre canales y lo extiende a cualquier
catalogo). Si una rama del SP se activa por un valor especifico de un parametro de entrada
(ej. un tipo de servicio, un canal, un codigo) y esa rama lee un catalogo/config para operar,
la PRE del TC debe garantizar ese registro de catalogo.

Procedimiento:
1. Identificar la rama que el valor del parametro del TC activa (de las comparaciones del SP).
2. Listar las tablas de catalogo/config que esa rama consulta para operar.
3. Verificar que la PRE (o el INSTRUCTIVO) garantiza esos registros para los valores del TC.

Si la rama necesita un catalogo que la PRE no prepara → FAIL(tc_id, 'V-COND-PARAM-01', 'Valor @<param>=<X> activa rama que requiere <catalogo> pero la PRE no lo prepara'). Si el INSTRUCTIVO ya lo garantiza → PASS_WITH_INSTRUCTIVO.

**Ejemplo de razonamiento (generico):**
"El TC envia @servicio='X'. En el SP, ese valor activa una rama que hace
`SELECT ... FROM catalogo_C WHERE servicio='X'` para resolver una config. ¿La PRE inserta esa
fila en catalogo_C? Si la rama la necesita y no esta garantizada → FAIL. (No asumo el nombre
del servicio ni del catalogo; los derivo de la comparacion del SP que activa la rama.)"

### V-LINE-01: Numeros de linea de la trazabilidad coinciden con el SP real

Para cada referencia `L:<num>` en la seccion Trazabilidad por DB de un TC, verificar contra el
SP real (resuelto en 0.2) que esa linea contiene lo que el TC afirma.

Procedimiento:
1. Leer la linea `<num>` del SP real.
2. Verificar que su contenido corresponde a la operacion documentada (el INSERT/UPDATE/RETURN
   sobre la tabla/codigo que la trazabilidad menciona).
3. Si no corresponde, localizar la linea real de esa operacion en el SP.

Si la linea documentada no coincide con el SP real → FAIL(tc_id, 'V-LINE-01', 'Trazabilidad cita L:<num> pero esa operacion esta en L:<real> del SP'). Proponer `linea_propuesta`.

**Ejemplo de razonamiento (generico):**
"Trazabilidad dice 'UPDATE tabla_T en L:1013'. Leo L:1013 del SP real: es un comentario, no ese
UPDATE. Busco el UPDATE de tabla_T en el SP → esta en L:945. FAIL: corregir L:1013 → L:945.
Esto resuelve los desfases por versiones distintas del SP (el .md puede citar lineas de una
version que ya no corresponde al SP local)."

### V-NULL-01: Semantica NULL de Sybase (three-value logic)

Regla GENERICA (absorbe y refuerza la antigua V-DBG-03). En Sybase, una comparacion con NULL
(`@x <> 'A'`, `@x = 'A'`) evalua UNKNOWN, que en un IF se comporta como FALSO (no entra al
bloque). Para TCs que pasan un parametro NULL esperando un comportamiento concreto, verificar
que el resultado esperado refleje lo que el SP REALMENTE hace, no una validacion NULL inexistente.

Procedimiento:
1. Para un TC con @param=NULL, buscar en el SP si hay validacion explicita
   (`IF @param IS NULL RETURN err` o `isnull(@param, default)`).
2. Si NO hay validacion explicita: el NULL fluye con semantica three-value. El error/efecto real
   puede surgir despues (ej. una busqueda con rowcount=0), no por "parametro NULL invalido".
3. El resultado esperado del TC debe atribuir el resultado a la causa REAL.

Si el TC atribuye el resultado a una validacion NULL que el SP no tiene → FAIL(tc_id, 'V-NULL-01', 'TC asume validacion NULL de @<param> pero el SP no la valida; el resultado real proviene de <causa real, ej. rowcount=0 en L:X>').

**Ejemplo de razonamiento (generico):**
"El TC pasa @opcion=NULL y espera 'error por opcion invalida'. Busco en el SP: no hay
`IF @opcion IS NULL`. Las comparaciones `IF @opcion='01'`, `='02'` con NULL dan UNKNOWN → ninguna
entra → cae al flujo por defecto, que hace un UPDATE con rowcount=0 y retorna 122004. FAIL:
el resultado esperado es correcto en codigo (122004) pero la trazabilidad/justificacion debe
decir que viene del rowcount=0, NO de una validacion de NULL que no existe."

### V-COHER-01: Coherencia entre titulo, descripcion y resultado esperado

El titulo/descripcion de un TC y su resultado esperado deben contar la MISMA historia. Si el
titulo afirma exito (return 0 / "exitosa" / "valida") pero el resultado esperado indica error
(o viceversa), es incoherente. Tambien: el resultado esperado debe ser un codigo numerico
exacto (esto refuerza V-PRE-04); expresiones como `RETURN 0 con @o_error != 0` mezclan exito
(return 0) y error (@o_error!=0) en la misma linea → ambiguo.

Procedimiento:
1. Leer el sentido del titulo/descripcion (exito vs error).
2. Leer el resultado esperado (codigo 0 = exito; codigo != 0 o "@o_error != 0" = error).
3. Si no concuerdan → incoherencia.

Si titulo y resultado se contradicen → FAIL(tc_id, 'V-COHER-01', 'Titulo dice <exito/error> pero resultado esperado indica <lo contrario>'). Proponer reescribir el que sea incorrecto segun lo que el SP realmente hace por esa ruta (apoyarse en V-DBG-01).

**Ejemplo de razonamiento (generico):**
"Titulo: 'Verificar ejecucion exitosa (return 0)'. Resultado esperado: 'RETURN 0 con @o_error != 0'.
El titulo dice exito pero el resultado mezcla return 0 con un error (@o_error!=0) → incoherente y
ambiguo. Trazo el SP por esa ruta (V-DBG-01): si realmente retorna error, el titulo debe decir
'... error <codigo>' y el resultado ser el codigo exacto; si realmente es exito, quitar el
'@o_error != 0'. FAIL: corregir para que titulo y resultado cuenten la misma historia."

### V-IDEMP-01: TCs de doble ejecucion / idempotencia tienen mecanismo

Si un TC declara probar idempotencia, doble ejecucion, reproceso o reversa (palabras clave en
titulo/descripcion: "dos veces", "idempotencia", "doble", "reproceso", "reejecutar"), debe tener
el mecanismo para ejecutarse mas de una vez y un resultado esperado POR ejecucion (ej: 1a vez
return 0, 2a vez error de duplicado / return distinto). Un TC de idempotencia sin segundo EXEC
ni PRE/POST que distinga las dos pasadas no prueba nada.

Procedimiento:
1. Detectar intencion de doble-ejecucion en titulo/descripcion.
2. Verificar que el TC especifica el resultado de cada pasada (no un unico resultado).
3. Verificar que la trazabilidad no quede indefinida (`L:None`, sin operacion).

Si el TC declara idempotencia/doble-ejecucion pero no especifica el comportamiento por pasada →
FAIL(tc_id, 'V-IDEMP-01', 'TC de doble ejecucion sin mecanismo: falta resultado por pasada / segundo EXEC / trazabilidad'). Proponer reescritura con resultado de 1a y 2a pasada.

**Ejemplo de razonamiento (generico):**
"Titulo: 'Validar idempotencia: ejecutar dos veces con mismos parametros'. Reviso el TC: tiene un
unico 'Resultado esperado' y trazabilidad 'L:None'. No especifica que pasa en la 2a ejecucion
(¿rechaza duplicado? ¿retorna distinto?). FAIL: un TC de idempotencia debe decir '1a vez: return 0;
2a vez: return <codigo duplicado>' y trazar donde el SP detecta la repeticion. Si el SP no tiene
control de duplicados, el TC debe documentarlo (el 2o debito ocurriria) o marcarse NOT_APPLICABLE."

### V-ECOSISTEMA-01: PRE/POST coherentes con los parametros declarados del TC

Regla GENERICA (cualquier SP, sin hardcode). Un TC es un ECOSISTEMA autoconsistente: los datos que
operan sus bloques PRE y POST deben ser los MISMOS que declara en `parametros_entrada`. El error que
motiva esta regla: TCs cuyo PRE preparaba saldo/estado sobre una cuenta u orden DISTINTA de la
declarada en el caso (el PRE tocaba un dato ajeno -> el escenario no quedaba bien preparado y la
evidencia no correspondia al TC).

Procedimiento:
1. Para cada SQL de PRE y de POST del TC, extraer los predicados `col = valor` (de los WHERE) y los
   `VALUES(...)` de los INSERT.
2. Mapear cada `col` de enlace a su parametro homologo del TC usando el MISMO mapeo SP<->dato que usa
   el motor (NO hardcodear; derivar de TABLAS MONITOREADAS / del SP). Ejemplos de enlace en debcred:
   `te_orden_banco`/`dt_orden_banco`/`mo_orden_banco` <-> `@i_orden`;
   `cc_cta_banco`/`ah_cta_banco`/`vi_cta_banco` <-> `@i_numcta_emp`;
   `te_ordenante` <-> `@i_empresa`; `te_servicio` <-> `@i_servicio`. (Cubrir TODAS las claves, no solo
   cuenta: orden, cuenta, empresa, servicio, secuencial, etc.)
3. Comparar el valor literal del SQL contra el valor del param declarado.

**PRE — estricto:**
Si un literal mapeable en el PRE NO coincide con el parametro del TC →
FAIL(tc_id, 'V-ECOSISTEMA-01', 'PRE opera sobre <col>=<valor> pero el TC declara @<param>=<otro>; el
PRE debe preparar el escenario con los datos del propio TC'). Proponer alinear el literal al param.

**POST — tolera restauracion, vigila el WHERE:**
El POST puede fijar en su `SET` un valor DISTINTO al param (restauracion legitima al estado original;
patron PRE-prepara/POST-restaura — ej. un POST que devuelve `te_servicio='ROLPAGO'` tras un TC que lo
puso en otro valor). PERO el `WHERE` del POST DEBE filtrar por el MISMO dato (cuenta/orden/clave) que
el TC declara: la restauracion debe aplicarse sobre la entidad del TC, no sobre otra.
Si el WHERE del POST filtra por una cuenta/orden/clave AJENA al TC →
FAIL(tc_id, 'V-ECOSISTEMA-01', 'POST restaura sobre <col>=<valor> ajeno al TC (@<param>=<otro>)').
El `SET` con valor de restauracion distinto NO es FAIL (es el comportamiento esperado).

**Ejemplo de razonamiento (generico):**
"El TC declara `@i_numcta_emp=0005329182` y `@i_orden=63055657`. Leo su PRE:
`UPDATE ...cc_ctacte SET cc_disponible=200 WHERE cc_cta_banco='0000010302'`. La cuenta del WHERE
(0000010302) NO es la declarada (0005329182) -> FAIL: el PRE prepara saldo sobre una cuenta que el TC
no usa; la evidencia no correspondera al escenario. Reviso el POST: `SET te_servicio='ROLPAGO'
WHERE te_orden_banco=63055657` — el SET restaura el servicio (valor distinto, OK) y el WHERE filtra
por la orden declarada del TC (OK) -> PASS."

---

## FASE 4 — Generacion del reporte con propuestas de correccion

### 4.1 Logica de propuestas

Para cada TC con FAIL o WARN, el validador DEBE proponer una correccion concreta
basada en los datos reales descubiertos en Sybase. La propuesta incluye:

- **Empresa alternativa:** buscar en Sybase una empresa que cumpla las condiciones
  del TC (producto correcto, cuenta existente, canales disponibles)
- **Canal correcto:** verificar que canales existen para la empresa propuesta
- **Resultado esperado:** si el resultado actual es incorrecto, obtener el codigo real
- **PRE/POST SQL concreto:** proponer las sentencias exactas de reemplazo

**REGLA ANTI-PLACEHOLDER (obligatoria).** El corrector aplica la propuesta LITERALMENTE
(no piensa). Por tanto las propuestas NUNCA pueden contener marcadores sin resolver como
`<codigo exacto>`, `<codigo error contable>`, `<capturar via prueba controlada>`, `<linea real>`.
Cada valor propuesto debe ser concreto. Si no puedes resolver un valor:
- NO emitas un placeholder. En su lugar, deja `propuesta: null` y registra en la justificacion
  por que no se pudo resolver (asi el corrector lo salta y queda como FAIL para revision manual,
  en vez de inyectar texto roto al documento).
- O resuelvelo (ver abajo como).

**Como resolver el codigo de retorno real (en vez de placeholder).** Cuando un FAIL requiere
saber el codigo que el SP retorna por una ruta (ej. V-COHER-01, V-DBG-01):
1. Primero intentar derivarlo estaticamente: trazar la ruta en el SP y leer el `RETURN <codigo>`
   o el `@o_error = <codigo>` literal de esa rama. La mayoria de codigos son literales en el SP.
2. Si la ruta depende de un catalogo (ej. el codigo viene de cl_errores o de una config),
   consultarlo con un SELECT.
3. Solo si el codigo es genuinamente indeterminable sin ejecutar el SP (escritura), dejar
   `propuesta: null` con justificacion — NUNCA un placeholder `<...>`.

**Propuestas para V-LINE-01 y V-TITULO-01 (siempre concretas).** Estas dos reglas YA tienen el
dato resuelto durante la deteccion, asi que la propuesta SIEMPRE debe ser concreta (nunca null
por "no se pudo"):
- **V-LINE-01:** al detectar el desfase ya localizaste la linea real en el SP. La propuesta lleva
  `linea_actual` (L del doc) y `linea_propuesta` (L real encontrada). Ej: `{"L:1013": "L:1086"}`.
- **V-TITULO-01:** al detectar la violacion ya conoces los parametros de entrada del TC (su tabla).
  La propuesta lleva `titulo_propuesto` redactado con esos inputs. Ej: para un TC con @i_opcion='01',
  @i_canal='DIR', @i_frm_pagcob_deb='CUE' → `titulo_propuesto: "Opcion 01, canal DIR, forma de pago CUE"`.

### 4.1b Regla de cruce INSTRUCTIVO ↔ PRE/POST (anti-redundancia)

**REGLA ABSOLUTA:** Antes de proponer cualquier INSERT en PRE, cruzar contra el INSTRUCTIVO.
El PRE de un TC NO debe duplicar datos que el INSTRUCTIVO ya garantiza.

**Logica de cruce:**

Para cada INSERT en PRE del TC:
1. Verificar si el INSTRUCTIVO ya inserta/garantiza ese mismo dato (misma tabla, misma empresa, mismo canal/codigo)
2. Si el INSTRUCTIVO ya lo garantiza con **el mismo valor**:
   - PROPUESTA: eliminar el INSERT del PRE (redundante, instructivo ya lo cubre)
   - Eliminar tambien el DELETE correspondiente del POST
3. Si el INSTRUCTIVO ya lo garantiza pero con **valor diferente** (ej: costo 0.31 vs 5.00):
   - PROPUESTA: reemplazar INSERT por UPDATE del campo que difiere
   - POST: UPDATE restaurando al valor del instructivo (no DELETE)
4. Si el INSTRUCTIVO **no lo garantiza**:
   - PROPUESTA: mantener INSERT pero con IF NOT EXISTS para evitar duplicados
   - POST: DELETE (porque el dato no existia antes)

**Ejemplo de cruce:**
```
INSTRUCTIVO garantiza: pg_costo_com_canal (empresa=1348, canal='IBK', costo=0.31)
TC12 PRE tiene:       INSERT pg_costo_com_canal (1348, 'IBK', 5.00)

Cruce: misma empresa+canal, valor diferente
Propuesta: UPDATE pg_costo_com_canal SET pg_costo = 5.00 WHERE pg_empresa = 1348 AND pg_canal = 'IBK'
POST:      UPDATE pg_costo_com_canal SET pg_costo = 0.31 WHERE pg_empresa = 1348 AND pg_canal = 'IBK'
```

**Aplicar tambien al POST:** Si el POST hace DELETE de un dato que el INSTRUCTIVO garantiza,
eliminarlo (el instructivo lo restaurara en la siguiente corrida).

**Proceso para generar propuestas (por regla, generico):**

1. **FAIL V-DATA-01** (entidad/recurso inexistente o tipo incoherente):
   - Buscar en Sybase una entidad del tipo correcto con su recurso valido. Construir la query
     derivando las tablas del SP (la maestra de la entidad + la de su recurso segun el tipo).
   - Patron generico: `SELECT TOP 3 <claves> FROM <tabla_entidad> e JOIN <tabla_recurso_del_tipo> r ON ... WHERE <condiciones del escenario>`.
   - Verificar tambien catalogos requeridos por el path (los que use V-COND-PARAM-01).
   - Proponer la entidad/recurso encontrado como `campo_propuesto`.

2. **FAIL V-COND-PARAM-01** (catalogo de la rama no preparado):
   - Consultar el catalogo que la rama necesita para los valores del TC.
   - Proponer INSERT del registro de catalogo en PRE (o en INSTRUCTIVO si es permanente).

3. **FAIL V-PRE-04** (resultado no numerico):
   - Ejecutar prueba controlada (PRE → EXEC SP → capturar return → POST). Reportar el codigo real.

4. **WARN V-PRE-07** (sin mecanismo para forzar error):
   - Evaluar si es viable con INSERT en tabla de bloqueos/config. Si no → NOT_APPLICABLE.

5. **FAIL V-PRE-FLOW-01** (PRE no prepara hijos / datos no entran al flujo):
   - Seguir el procedimiento PRE_GENERADO de V-PRE-FLOW-01 (FASE 3): trazar hijos, construir PRE.
   - Si se logra → propuesta PRE_GENERADO con pre/post completos. Si no (hijos sin codigo) → NOT_APPLICABLE.
   - AGRUPAR TCs del mismo GRUPO que comparten ruta: un analisis, misma propuesta base.

6. **FAIL V-TITULO-01** (titulo con logica interna):
   - Proponer SIEMPRE `titulo_propuesto` concreto, redactado con los parametros de entrada del
     TC (su tabla de params). Nunca dejar null: los inputs ya estan en el TC. Tipo de correccion: TITULO.

7. **FAIL V-FALLBACK-01** (PRE no fuerza la ruta alterna):
   - Proponer PRE que elimine/mueva la fila de la tabla principal (y la deje en la alterna).

8. **FAIL V-LINE-01** (linea desfasada):
   - Proponer SIEMPRE `linea_actual` + `linea_propuesta` con el numero real ya localizado en el
     SP durante la deteccion. Nunca dejar null: el numero real ya lo tienes. Tipo de correccion: LINEA.

9. **FAIL V-NULL-01** (causa del error mal atribuida):
   - Proponer corregir la justificacion/trazabilidad a la causa real (mantener el codigo si es correcto).

10. **FAIL V-COHER-01** (titulo vs resultado incoherente):
    - Trazar la ruta real (V-DBG-01) y proponer alinear titulo+resultado a lo que el SP hace
      (titulo y resultado contando la misma historia, resultado como codigo numerico exacto).

11. **FAIL V-IDEMP-01** (doble ejecucion sin mecanismo):
    - Proponer reescritura con resultado por pasada (1a/2a) y trazabilidad de donde el SP detecta
      la repeticion; si el SP no controla duplicados, proponer NOT_APPLICABLE o documentar el efecto.

### 4.2 Estructura del reporte

Escribir en `.claude/docs-qa/inputs/documents/<sp_name>/auto/tc-validation-report.json`:

```json
{
  "sp_name": "<sp_name>",
  "validated_at": "<fecha_iso>",
  "total_tcs": "<N>",
  "results": {
    "pass": "<N>",
    "fail": "<N>",
    "warn": "<N>",
    "not_applicable": "<N>"
  },
  "validations": [
    {
      "tc_id": "<TCNN>",
      "status": "PASS|FAIL|WARN|NOT_APPLICABLE",
      "checks": {
        "V-DISCOVERY-01": "PASS|FAIL (<cuenta no existe / no cumple condicion del escenario>)|WARN (<sin data_discovery>)|N/A",
        "V-DESCIFRADO-01": "N/A (no marcado pendiente)|FAIL (<PRE prosa/vacio -> propuesta SQL/PRE mutante>)|FAIL (<irreproducible, propuesta null>)|WARN (<sin discovery_queries>)",
        "V-DATA-01": "PASS|PASS_WITH_INSTRUCTIVO|FAIL (<entidad/recurso inexistente o tipo incoherente>)|N/A",
        "V-PRE-04": "PASS (<codigo>)|FAIL (<valor no numerico>)",
        "V-PRE-07": "PASS (<mecanismo>)|WARN (<sin mecanismo>)|N/A",
        "V-PRE-08": "PASS|WARN (<dato no garantizado>)",
        "V-PRE-FLOW-01": "PASS|FAIL (<prerequisito hijo / no entra al flujo>)|WARN|N/A",
        "V-TITULO-01": "PASS|FAIL (<titulo con logica interna>)",
        "V-FALLBACK-01": "PASS|FAIL (<PRE no fuerza ruta alterna>)|N/A",
        "V-COND-PARAM-01": "PASS|PASS_WITH_INSTRUCTIVO|FAIL (<catalogo de rama no preparado>)|N/A",
        "V-LINE-01": "PASS|FAIL (<linea desfasada L:doc vs L:real>)|N/A",
        "V-NULL-01": "PASS|FAIL (<causa de error mal atribuida>)|N/A",
        "V-COHER-01": "PASS|FAIL (<titulo vs resultado incoherente>)",
        "V-IDEMP-01": "PASS|FAIL (<TC doble-ejecucion sin mecanismo>)|N/A",
        "V-CU-01": "PASS|FAIL (<param activa path de otro CU>)|N/A",
        "V-DBG-01": "PASS|FAIL (<flujo no alcanza resultado>)",
        "V-DBG-04": "PASS|WARN (<POST no restaura>)|FAIL (<POST relativo>)",
        "V-POST-01": "PASS|FAIL (<borra permanente>)|WARN (<afecta TC siguiente>)|N/A"
      },
      "propuesta": null
    },
    {
      "tc_id": "<TCNN con FAIL>",
      "status": "FAIL",
      "checks": { "...": "..." },
      "propuesta": {
        "accion": "<descripcion corta + tipo de correccion: CAMPO|TITULO|LINEA|RESULTADO|PRE_FALLBACK|PRE_COND_PARAM|PRE_GENERADO|NOT_APPLICABLE|AISLAMIENTO|CHECK>",
        "justificacion": "<por que esta propuesta es correcta, con datos reales de Sybase>",
        "campo": "<nombre del param/columna a corregir, para tipo CAMPO>",
        "valor_actual": "<valor actual>",
        "campo_propuesto": "<valor nuevo concreto, para tipo CAMPO>",
        "titulo_propuesto": "<titulo concreto solo con inputs, para tipo TITULO>",
        "linea_actual": "L:<doc>", "linea_propuesta": "L:<real>",
        "pre_sql_propuesto": ["<sentencia concreta 1>", "..."],
        "post_sql_propuesto": ["<sentencia concreta 1>", "..."],
        "resultado_esperado_propuesto": "RETURN <codigo numerico exacto>|Msg <n>, Level <n>, State <n>|NOT_APPLICABLE"
      }
    }
  ],
  "resumen_hallazgos": [
    {
      "severity": "FAIL|WARN",
      "count": "<N>",
      "tcs": ["<lista>"],
      "causa_raiz": "<descripcion de la causa comun>"
    }
  ]
}
```

**REGLA:** Los valores en el reporte DEBEN provenir de queries SELECT ejecutadas contra
Sybase durante la validacion (o de lectura directa del SP para codigos/lineas). No usar valores
hardcodeados ni inferidos. Cada propuesta debe ser verificable: la entidad propuesta existe, la
cuenta existe, el catalogo existe, el codigo/linea es el real del SP.

**REGLA ANTI-PLACEHOLDER (dura):** una `propuesta` NUNCA contiene marcadores sin resolver
(`<codigo exacto>`, `<linea real>`, `<capturar...>`, etc.). El corrector la aplica literal, asi
que un placeholder ensucia el documento. Si un valor no se puede resolver → `propuesta: null` +
justificacion (el corrector lo salta, el TC queda FAIL para revision manual). Concreto o null,
nunca a medias.
```

### 4.3 Resumen de consola

```
═══════════════════════════════════════════════════════════
AGENTE QA — VALIDADOR DE CASOS DE PRUEBA
═══════════════════════════════════════════════════════════
SP               : <sp_name>
Total TCs        : <N>
───────────────────────────────────────────────────────────
Resultados
  PASS             : <N>
  FAIL             : <N>
  WARN             : <N>
  NOT_APPLICABLE   : <N>
───────────────────────────────────────────────────────────
Hallazgos FAIL (con propuesta)
  <TCNN>: <V-PRE-XX> — <descripcion>
    PROPUESTA: <accion concreta con datos reales>
  ...
───────────────────────────────────────────────────────────
Hallazgos WARN (con propuesta)
  <TCNN>: <V-PRE-XX> — <descripcion>
    PROPUESTA: <accion concreta o NOT_APPLICABLE con justificacion>
  ...
───────────────────────────────────────────────────────────
Reporte: .claude/docs-qa/inputs/documents/<sp_name>/auto/tc-validation-report.json
═══════════════════════════════════════════════════════════
```

---

## MENSAJE FINAL — Sugerencia de corrector

Si hay FAILs con propuestas concretas, emitir al final del reporte:

```
───────────────────────────────────────────────────────────
HAY <N> FAILs CON PROPUESTA DE CORRECCION.
Ejecutar agente-qa-auto-03-test-cases-corrector para aplicar las correcciones:
  sp_name: <sp_name>
  microservice: <microservice>
───────────────────────────────────────────────────────────
```

---

## REGLAS DE OPERACION

**R1 — Solo lectura en Sybase.** El validador NO ejecuta INSERT/UPDATE/DELETE contra BD.
Solo SELECTs de verificacion.

**R2 — No modifica TCs.** El validador reporta hallazgos y propuestas pero NO corrige.
La correccion es responsabilidad del `agente-qa-auto-03-test-cases-corrector`.

**R3 — FAIL es bloqueante.** Si hay FAILs, los TCs afectados no deben ejecutarse hasta
corregir. WARNs son informativos.

**R4 — Instructivo como prerequisito.** El validador asume que el INSTRUCTIVO ya fue
ejecutado. Las verificaciones contra Sybase reflejan el estado POST-instructivo.

**R5 — NOT_APPLICABLE se reporta.** TCs que el validador determina NOT_APPLICABLE se
reportan con propuesta "NOT_APPLICABLE" y justificacion para que el corrector los marque
en el titulo. NUNCA proponer "eliminar" — los TCs se marcan, no se eliminan (REGLA CARDINAL).

# Instructivo — Agentes QA 01, 02 y 03 (Validación de Casos de Prueba)

> **Qué es esto:** el paquete autocontenido para correr el pipeline de validación de casos de
> prueba (agentes 01 → 02 → 03) en un repositorio propio de Banco, independiente del repositorio
> de Nyxn. Incluye los 3 agentes y los 4 scripts deterministas + el wrapper de conexión Sybase de
> los que dependen. No incluye nada más del pipeline QA completo (no se necesita).

---

## 1. Qué incluye este paquete

```
paquete-agentes-qa-01-02-03/
├── INSTRUCTIVO-AGENTES-01-02-03.md   ← este documento
└── .claude/
    ├── agents/
    │   ├── agente-qa-auto-01-test-cases.md
    │   ├── agente-qa-auto-02-test-cases-validator.md
    │   └── agente-qa-auto-03-test-cases-corrector.md
    └── docs-qa/inputs/scripts/
        ├── sybase_tsql_wrapper.py            ← conexión a Sybase (FreeTDS/tsql)
        └── auto/
            ├── validate_external_tc.py       ← script que ejecuta el agente 01
            ├── parse_test_cases.py           ← invocado por validate_external_tc.py
            ├── discover_data.py              ← invocado por validate_external_tc.py (discovery)
            └── sql_readonly_guard.py         ← barrera que garantiza que solo se ejecute SELECT
```

**La carpeta `.claude/` de este paquete se copia TAL CUAL en la raíz del repositorio de Banco**
(se fusiona con su propio `.claude/` si ya tienen uno). Las rutas que usan los 3 agentes están
escritas de forma relativa a la raíz del repo (`.claude/docs-qa/inputs/scripts/...`), así que la
estructura de carpetas debe conservarse exactamente como está aquí.

No se incluye ningún otro agente (00/04/05), ni nada de Gestor QA/Supabase, QMetry o Query Plan —
no son necesarios para este pipeline.

---

## 2. Cómo funciona el pipeline (resumen)

```
documento de banco (test-cases-banco/*.md)
        │
        ▼
   AGENTE 01 ── valida formato + normaliza + discovery contra Sybase (solo SELECT)
        │           produce: auto/qa_casos_prueba.md + data_discovery.json + discovery_queries.json
        ▼
   AGENTE 02 ── traza el SP real (línea por línea) + ejecuta ~25 reglas de validación
        │           contra Sybase real (solo SELECT) — confirma que cada TC es EJECUTABLE
        │           produce: auto/tc-validation-report.json (PASS/FAIL/WARN + propuesta concreta)
        ▼
   AGENTE 03 ── aplica las propuestas del reporte al documento (solo Edit, nunca reescribe)
        │           produce: auto/qa_casos_prueba.md corregido
        └──────────► se vuelve a correr el AGENTE 02 para confirmar que los FAIL se resolvieron
```

- El **agente 01** es un wrapper delgado sobre `validate_external_tc.py` — no tiene criterio propio.
- El **agente 02** es el que hace más trabajo (lee el código real del SP + Sybase real por cada TC).
- El **agente 03** solo corre si el 02 encontró `FAIL` con propuesta de corrección concreta. Si el
  documento ya está limpio (0 FAIL), el 03 no tiene nada que hacer.
- Ninguno de los tres modifica datos en Sybase. Todas las consultas son de solo lectura
  (`sql_readonly_guard.py` lo garantiza a nivel de código, no es solo una convención).

---

## 3. Requisitos de entorno

| Requisito | Detalle |
|---|---|
| **Sistema operativo** | Linux o macOS. **No funciona en Windows nativo** (el wrapper de Sybase usa `fcntl`/`pty`, exclusivos de POSIX). Windows con WSL sí funciona. |
| **Python** | 3.7 o superior. **Cero dependencias de terceros** — todo el pipeline usa solo librería estándar (`subprocess`, `re`, `os`, `json`, `select`, `fcntl`, `pty`, etc.). No hace falta `pip install` nada. |
| **Cliente Sybase** | `tsql` de **FreeTDS** instalado y en el `PATH`. En Debian/Ubuntu: `sudo apt install freetds-bin`. En RHEL/Amazon Linux: compilar FreeTDS o usar el paquete equivalente del repo interno. |
| **Red** | Conectividad desde donde se ejecute el pipeline hacia el servidor Sybase ASE de Banco, por el puerto TDS correspondiente (típicamente el puerto de la instancia ASE, no el de un proxy). |
| **Runtime de agentes** | Claude Code (o un runtime compatible con agentes definidos en `.md` con frontmatter YAML) con acceso a un modelo Claude. El frontmatter de estos 3 agentes pide `model: opus`. |

---

## 4. Configuración necesaria (específica del ambiente de Banco)

### 4.1 `freetds.conf`

FreeTDS necesita un alias que apunte al servidor Sybase real de Banco. Ubicación típica:
`/usr/local/etc/freetds.conf` o `/etc/freetds/freetds.conf` (según la instalación).

```ini
[alias_del_servidor]
    host = <host_o_ip_del_sybase_de_banco>
    port = <puerto_tds_del_sybase_de_banco>
    tds version = 5.0
    client charset = utf8
```

**Importante:** Sybase ASE usa protocolo TDS **5.0** (no 7.x — eso es para SQL Server). Si la
versión no coincide, la conexión falla o trunca datos silenciosamente.

### 4.2 Variables de entorno

Antes de invocar cualquiera de los 3 agentes, exportar:

```bash
export SYBASE_SERVER="alias_del_servidor"   # el nombre del alias definido en freetds.conf, NO el host
export SYBASE_USER="usuario_lectura"
export SYBASE_PASS="contraseña"
```

**Con acceso de solo LECTURA basta.** El `sql_readonly_guard.py` bloquea a nivel de código
cualquier sentencia que no sea `SELECT`, así que ni siquiera es necesario un usuario con permisos
de escritura para correr estos 3 agentes.

### 4.3 Estructura de insumos por SP

Por cada SP a validar, crear (o recibir de Banco) la carpeta:

```
.claude/docs-qa/inputs/documents/<sp_name>/
└── test-cases-banco/
    └── <archivo>.md      ← el documento de casos de prueba, formato PLANTILLA-CASOS-PRUEBA
```

Debe haber **exactamente un** `.md` en esa carpeta (si hay más de uno, sacar los que no aplican a
una subcarpeta como `superseded/` — el agente 01 solo mira archivos directos en `test-cases-banco/`,
no recursivo).

### 4.4 Código fuente del SP (para que el agente 02 haga el trazado completo)

El agente 02 necesita leer el `.sql` real del SP para trazar su flujo línea por línea. Ubicarlo en
uno de estos 2 layouts (el agente prueba el primero, y si no encuentra nada cae al segundo):

```
sybase-local/<microservicio>/<sp_name>/sps/<sp_name>.sql          (carpeta dedicada por SP)
sybase-local/_bosque/sps/<database>__<sp_name>.sql                (layout plano compartido por lote)
```

Si no se encuentra el `.sql`, el agente 02 **sigue corriendo** pero degrada a `WARN` en las reglas
que dependen de leer el código del SP (pierde el trazado de flujo, mantiene los checks de datos).

---

## 5. Cómo invocar los agentes

```
/agent agente-qa-auto-01-test-cases sp_name=<nombre_carpeta_de_insumos>

/agent agente-qa-auto-02-test-cases-validator sp_name=<nombre_carpeta_de_insumos> microservice=<nombre_del_microservicio>

Corrige los casos de prueba para:
- sp_name: <nombre_carpeta_de_insumos>
- microservice: <nombre_del_microservicio>
```

El tercero (agente 03) se invoca en lenguaje natural, no con la sintaxis `/agent` — así está
definido en su propio archivo.

**Orden obligatorio:** 01 antes que 02 (el 02 necesita `auto/qa_casos_prueba.md`, que solo existe
si el 01 ya corrió con éxito). El 03 solo se invoca si el 02 reportó `FAIL` con propuestas.

**Loop de cierre:** después de que el 03 corrija, hay que volver a correr el 02 para confirmar
que los `FAIL` se resolvieron. No es una cadena de una sola pasada.

---

## 6. Cómo verificar que el ambiente quedó bien montado (smoke test)

**Paso 1 — sin necesidad de Sybase:**
```bash
python3 .claude/docs-qa/inputs/scripts/auto/validate_external_tc.py \
  ".claude/docs-qa/inputs/documents/<sp_name>/test-cases-banco/<archivo>.md" --check-only
```
Si esto da error de importación (`sql_readonly_guard`), revisar que los 4 scripts de
`scripts/auto/` estén juntos en la misma carpeta.

**Paso 2 — con Sybase:**
```bash
python3 .claude/docs-qa/inputs/scripts/auto/discover_data.py --help
```
Si falla con `ERROR: No se encontro sybase_tsql_wrapper.py`, revisar que `sybase_tsql_wrapper.py`
esté un nivel arriba de `scripts/auto/` (en `scripts/` directamente), tal como viene en este
paquete.

**Paso 3 — conexión real:** exportar las 3 variables de entorno (sección 4.2) e invocar el
agente 01 completo sobre un documento real. Si la conexión falla, el error aparece explícito (no
falla en silencio) y el discovery queda en `WARN` sin bloquear la validación de formato.

---

## 7. Qué NO incluye este paquete

- Los agentes 00 (casos de uso), 04 (CONFIG/DICCIONARIO) y 05 (matriz de equivalencia) — no son
  necesarios para validar/corregir el documento de casos de prueba.
- Cualquier cosa del Gestor QA (Supabase), QMetry o Query Plan.
- Los documentos de casos de prueba en sí (`test-cases-banco/*.md`) — esos los aporta Banco por
  cada SP que quiera validar.
- El código fuente de los SPs (`sybase-local/`) — Banco ya lo tiene en su propio ambiente.

---

## 8. Ejemplo completo (caso real)

Este ejemplo usa un caso ya ejecutado con éxito, para que sirva de referencia de qué esperar.

**SP:** `pa_fir_consulta_firmante` — SP de solo lectura (consulta de firmantes), 15 casos de prueba.

### 8.1 Insumo (lo que aporta Banco)

```
.claude/docs-qa/inputs/documents/pa_fir_consulta_firmante/test-cases-banco/casos_prueba_pa_fir_consulta_firmante.md
```

Con el encabezado canónico:
```
# Casos de Prueba - SP `pa_fir_consulta_firmante`
**Base de datos:** `firmas` (Sybase)
```

### 8.2 Invocación

```bash
export SYBASE_SERVER="alias_del_servidor"
export SYBASE_USER="usuario_lectura"
export SYBASE_PASS="contraseña"
```

```
/agent agente-qa-auto-01-test-cases sp_name=pa_fir_consulta_firmante
```

**Resultado real obtenido (34 segundos):**
```
PASS — Formato: PASS. Parser: PASS (15/15). Scaffold escrito en auto/qa_casos_prueba.md.
Discovery: 14 verificables, 1 sin-dato (N/A), 0 PENDIENTE_DESCIFRADO.
Cuentas encontradas: 14/14 contra Sybase real.
```

```
/agent agente-qa-auto-02-test-cases-validator sp_name=pa_fir_consulta_firmante microservice=cpas-mso-consulta-firmante
```

**Resultado real obtenido (3 min 22s):**
```
═══════════════════════════════════════════════════════════
SP               : pa_fir_consulta_firmante
Total TCs        : 15
Resultados
  PASS             : 15
  FAIL             : 0
  WARN             : 0
═══════════════════════════════════════════════════════════
```

Como el resultado fue **0 FAIL**, el agente 03 **no fue necesario** en este caso — el documento
ya estaba correcto y ejecutable.

### 8.3 Caso con FAIL (qué pasa si el documento tiene errores de formato)

Con otro SP real (`sp_ah_retirosl_rc`), el agente 01 encontró 3 violaciones de formato y **se
detuvo antes de escribir el scaffold** (por diseño — no corrige contenido de negocio):

```
FAIL de formato (3 violaciones):
1. [ENCABEZADO] falta backticks alrededor del nombre del SP.
2. [ENCABEZADO] falta backticks + "(Sybase)" en la linea "Base de datos".
3. [RETURN_AUSENTE] un TC trae el resultado esperado en prosa en vez de `RETURN <entero>`.
```

En este caso el pipeline se detiene: el agente 02 no puede correr (no existe
`auto/qa_casos_prueba.md`) hasta que Banco corrija esas 3 líneas en su documento y lo reenvíe. El
agente 03 tampoco aplica aquí — esas correcciones son de contenido/formato del documento fuente,
no propuestas del validador.

### 8.4 Tiempos aproximados de referencia

| Agente | Tiempo típico | Depende de |
|---|---|---|
| 01 | 30s – 3 min | Cantidad de TCs, velocidad de Sybase para el discovery |
| 02 | 3 – 30 min | Cantidad de TCs, cantidad de SPs hijos a trazar, complejidad de ramas |
| 03 | 0 (si no hay FAIL) – 10 min | Cantidad de FAILs con propuesta a aplicar |

El agente 02 es, con diferencia, el más costoso — traza el SP real y ejecuta SELECTs reales por
cada regla y cada TC.

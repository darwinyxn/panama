#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Genera el PDF de diapositivas: Testing Agentico en QA (banco).
Salida apaisada (landscape) tipo slides, con graficos dibujados con reportlab.
"""
from reportlab.lib.pagesizes import landscape, A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.pdfgen import canvas

OUT = "/home/ssm-user/project-agents-assets-banco-bolivariano/claude-setupv2/.claude/docs-qa/inputs/documents/gt/testing_agentico_QA.pdf"

W, H = landscape(A4)  # 29.7 x 21 cm aprox

# Paleta (sobria, ejecutiva)
AZUL   = colors.HexColor("#123a63")   # azul profundo
AZUL2  = colors.HexColor("#2f6db0")   # azul medio
GRIS   = colors.HexColor("#5b6670")
GRISCL = colors.HexColor("#eef2f6")
VERDE  = colors.HexColor("#1f8a5b")
NARANJA= colors.HexColor("#d17a1f")
BLANCO = colors.white
TEXTO  = colors.HexColor("#1c2530")

c = canvas.Canvas(OUT, pagesize=landscape(A4))

def tri(x, y, size, col):
    """Triangulo apuntando a la derecha (punta en x,y)."""
    c.setFillColor(col)
    p = c.beginPath()
    p.moveTo(x, y)
    p.lineTo(x-size, y+size*0.7)
    p.lineTo(x-size, y-size*0.7)
    p.close()
    c.drawPath(p, fill=1, stroke=0)

def footer(num):
    c.setFont("Helvetica", 8)
    c.setFillColor(GRIS)
    c.drawString(1.2*cm, 0.8*cm, "Testing Agentico — QA | Migracion SP Sybase -> Microservicios")
    c.drawRightString(W-1.2*cm, 0.8*cm, f"{num}")

def barra_titulo(titulo, sub=None):
    c.setFillColor(AZUL)
    c.rect(0, H-2.4*cm, W, 2.4*cm, fill=1, stroke=0)
    c.setFillColor(BLANCO)
    c.setFont("Helvetica-Bold", 20)
    c.drawString(1.2*cm, H-1.6*cm, titulo)
    if sub:
        c.setFont("Helvetica", 11)
        c.drawString(1.2*cm, H-2.15*cm, sub)

def wrap(txt, font, size, maxw):
    c.setFont(font, size)
    words = txt.split()
    lines, cur = [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if c.stringWidth(t, font, size) <= maxw:
            cur = t
        else:
            lines.append(cur); cur = w
    if cur: lines.append(cur)
    return lines

# ============================================================ SLIDE 1 — PORTADA
c.setFillColor(AZUL); c.rect(0,0,W,H, fill=1, stroke=0)
c.setFillColor(AZUL2); c.rect(0, H-0.6*cm, W, 0.6*cm, fill=1, stroke=0)
c.setFillColor(BLANCO)
c.setFont("Helvetica-Bold", 34)
c.drawString(2*cm, H-6.5*cm, "Testing Agentico en QA")
c.setFont("Helvetica", 16)
c.drawString(2*cm, H-7.8*cm, "Automatizacion del ciclo de pruebas con agentes de IA")
c.setFont("Helvetica", 13)
c.drawString(2*cm, H-9.2*cm, "Migracion de Stored Procedures (Sybase) -> Microservicios (REST / gRPC)")
c.setStrokeColor(AZUL2); c.setLineWidth(2)
c.line(2*cm, H-10*cm, 12*cm, H-10*cm)
c.setFillColor(colors.HexColor("#cfe0f0"))
c.setFont("Helvetica", 11)
c.drawString(2*cm, 3.2*cm, "20 agentes QA  |  Generacion de pruebas, ejecucion de equivalencia y documentacion")
c.drawString(2*cm, 2.5*cm, "Presentacion — Equipo de QA")
c.showPage()

# ============================================================ SLIDE 2 — QUE ES
footer(2); barra_titulo("Que es el Testing Agentico", "Un ciclo de QA operado por agentes de IA, de punta a punta")
y = H-3.6*cm
puntos = [
 ("Agentes especializados", "Cada fase del ciclo QA la ejecuta un agente de IA con una unica responsabilidad."),
 ("Fuente de verdad = el SP", "La IA extrae la logica directamente del codigo del Stored Procedure. El comportamiento esperado es el propio SP original."),
 ("Equivalencia automatizada", "Se compara el SP directo vs REST vs gRPC, campo a campo, sin intervencion manual."),
 ("Documentacion generada", "Casos de uso, casos de prueba, UML y documento de logica se generan con los mismos agentes."),
 ("Cero criterios externos", "El banco no entrega especificaciones; todo el conocimiento se genera con IA desde el codigo."),
]
for t, d in puntos:
    c.setFillColor(AZUL2); c.circle(1.6*cm, y+0.15*cm, 0.16*cm, fill=1, stroke=0)
    c.setFillColor(AZUL); c.setFont("Helvetica-Bold", 13); c.drawString(2.1*cm, y, t)
    c.setFillColor(TEXTO); c.setFont("Helvetica", 11)
    for i, ln in enumerate(wrap(d, "Helvetica", 11, W-9*cm)):
        c.drawString(9*cm, y - i*0.5*cm, ln)
    y -= max(1.4*cm, (len(wrap(d,"Helvetica",11,W-9*cm)))*0.5*cm + 0.7*cm)
c.showPage()

# ============================================================ SLIDE 3 — PIPELINE (grafico)
footer(3); barra_titulo("El ciclo de pruebas QA", "Flujo automatizado, fase por fase")
fases = [
 ("1", "Casos de Uso", "IA lee el SP\ny genera los CU", AZUL2),
 ("2", "Casos de Prueba", "Genera CP 1:1\n+ valida + corrige", AZUL2),
 ("3", "Config / Payloads", "Arma REST/gRPC\n+ diccionario", AZUL2),
 ("4", "Matriz Equivalencia", "SP vs REST vs gRPC\ncampo a campo", VERDE),
 ("5", "Documentacion", "UML + Doc Logica\n(pruebas estaticas)", NARANJA),
 ("6", "QMetry", "Entrega formal;\nel banco prueba", AZUL),
]
n = len(fases)
bw, bh = 3.9*cm, 3.6*cm
gap = (W - 2*1.2*cm - n*bw) / (n-1)
x = 1.2*cm
ytop = H-7.2*cm
for i,(num,tit,det,col) in enumerate(fases):
    c.setFillColor(col); c.roundRect(x, ytop, bw, bh, 0.25*cm, fill=1, stroke=0)
    c.setFillColor(BLANCO); c.setFont("Helvetica-Bold", 22); c.drawString(x+0.35*cm, ytop+bh-1.0*cm, num)
    c.setFont("Helvetica-Bold", 10.5)
    for j,ln in enumerate(wrap(tit,"Helvetica-Bold",10.5,bw-0.6*cm)):
        c.drawString(x+0.35*cm, ytop+bh-1.7*cm - j*0.45*cm, ln)
    c.setFont("Helvetica", 8.5)
    for j,ln in enumerate(det.split("\n")):
        c.drawString(x+0.35*cm, ytop+0.9*cm - j*0.42*cm, ln)
    if i < n-1:
        ax = x+bw; ay = ytop+bh/2
        c.setStrokeColor(GRIS); c.setLineWidth(2)
        c.line(ax+0.15*cm, ay, ax+gap-0.30*cm, ay)
        tri(ax+gap-0.12*cm, ay, 0.28*cm, GRIS)
    x += bw+gap
# leyenda inferior
c.setFillColor(GRISCL); c.roundRect(1.2*cm, 2.2*cm, W-2.4*cm, 2.9*cm, 0.2*cm, fill=1, stroke=0)
c.setFillColor(AZUL); c.setFont("Helvetica-Bold", 11); c.drawString(1.6*cm, 4.4*cm, "Entradas y salidas del ciclo")
c.setFillColor(TEXTO); c.setFont("Helvetica", 10)
c.drawString(1.6*cm, 3.7*cm, "ENTRADA:  el .sql del SP (lo genera Migracion/DEV)  +  el microservicio ya construido (REST/gRPC).")
c.drawString(1.6*cm, 3.1*cm, "SALIDA:   veredictos de equivalencia (EQUIVALENTE / NO_EQUIVALENTE / INCONSISTENCIA)  +  CU, CP, UML, Doc Logica  +  ejecucion en QMetry.")
c.drawString(1.6*cm, 2.5*cm, "Cada fase valida a la anterior; el ciclo corre de forma autonoma y solo se detiene ante ambiguedad real de negocio.")
c.showPage()

# ============================================================ SLIDE 4 — AGENTES (grafico agrupado)
footer(4); barra_titulo("20 agentes QA, organizados por funcion", "Cada agente = una responsabilidad")
grupos = [
 ("Generacion de pruebas", AZUL2, [
    "auto-00  Casos de Uso — genera los CU desde el SP",
    "tc-enricher  Enriquece TCs (descripciones, error guessing, cobertura)",
    "auto-01  Casos de Prueba — 1 TC por escenario (1:1)",
    "auto-02  Validador de TCs — comprueba que sean ejecutables",
    "auto-03  Corrector de TCs — aplica las correcciones",
    "auto-04  Config/Payloads — arma REST/gRPC + diccionario",
 ]),
 ("Ejecucion (equivalencia)", VERDE, [
    "auto-05  Matrix-flow — orquesta el pipeline y ejecuta",
    "         la matriz SP vs REST vs gRPC (campo a campo)",
 ]),
 ("Documentacion", NARANJA, [
    "doclogica-00  Documento de logica del SP (prueba estatica)",
    "doclogica-01  Mapeador semantico (por libreria)",
    "doclogica-libreria  Doc de logica desde el Java refactorizado",
    "uml-00  Orquestador UML (4 vistas)",
    "uml-01  Descripciones de clase para el UML",
    "uml-02  Auditor UML — veredicto de calidad del modelo",
 ]),
 ("Entrega QMetry", AZUL, [
    "qmetry-orquestador + setup  Coordinan la entrega",
    "cycle-creator / traductor / inyector",
    "linker / sync-checker",
    "(7 agentes: publican la ejecucion en QMetry)",
 ]),
]
colw = (W-2.4*cm - 3*0.4*cm)/4
x = 1.2*cm
for tit,col,items in grupos:
    ytop = H-3.2*cm
    c.setFillColor(col); c.roundRect(x, 2.0*cm, colw, ytop-2.0*cm, 0.2*cm, fill=0, stroke=1)
    c.setFillColor(col); c.roundRect(x, ytop-1.0*cm, colw, 1.0*cm, 0.2*cm, fill=1, stroke=0)
    c.setFillColor(BLANCO); c.setFont("Helvetica-Bold", 10.5)
    for j,ln in enumerate(wrap(tit,"Helvetica-Bold",10.5,colw-0.4*cm)):
        c.drawString(x+0.25*cm, ytop-0.55*cm - j*0.4*cm, ln)
    yy = ytop-1.5*cm
    c.setFillColor(TEXTO); c.setFont("Helvetica", 8)
    for it in items:
        for ln in wrap(it,"Helvetica",8,colw-0.5*cm):
            c.drawString(x+0.25*cm, yy, ln); yy -= 0.42*cm
        yy -= 0.12*cm
    x += colw+0.4*cm
c.setFillColor(GRIS); c.setFont("Helvetica-Oblique", 9)
c.drawCentredString(W/2, 1.5*cm, "6 generan pruebas  ·  1 ejecuta equivalencia  ·  6 documentan (UML + logica)  ·  7 entregan en QMetry")
c.showPage()

# ============================================================ SLIDE 5 — DOCUMENTACION generada
footer(5); barra_titulo("Documentacion generada automaticamente", "La misma IA que prueba, documenta")
docs = [
 ("Casos de Uso (CU)", "Escenarios funcionales del SP, derivados de su codigo.", AZUL2),
 ("Casos de Prueba (CP)", "Suite completa 1:1, con precondiciones, datos reales y postcondiciones.", AZUL2),
 ("Matriz de Equivalencia", "Resultado de comparar SP vs REST vs gRPC en cada caso.", VERDE),
 ("UML (4 vistas)", "Paquetes, Componentes, Clases y Secuencia — auditadas por un agente.", NARANJA),
 ("Documento de Logica", "Analisis funcional del SP y sus dependencias (prueba estatica).", NARANJA),
 ("Entrega QMetry", "Ejecucion formal sobre la que el banco prueba y levanta defectos.", AZUL),
]
cols_ = 2; cw = (W-2.4*cm-1*cm)/2; ch = 2.7*cm
x0 = 1.2*cm; y0 = H-6.0*cm
for i,(t,d,col) in enumerate(docs):
    cx = x0 + (i%2)*(cw+1*cm)
    cy = y0 - (i//2)*(ch+0.5*cm)
    c.setFillColor(GRISCL); c.roundRect(cx, cy, cw, ch, 0.2*cm, fill=1, stroke=0)
    c.setFillColor(col); c.rect(cx, cy, 0.2*cm, ch, fill=1, stroke=0)
    c.setFillColor(col); c.setFont("Helvetica-Bold", 13); c.drawString(cx+0.6*cm, cy+ch-1.0*cm, t)
    c.setFillColor(TEXTO); c.setFont("Helvetica", 10)
    for j,ln in enumerate(wrap(d,"Helvetica",10,cw-1.2*cm)):
        c.drawString(cx+0.6*cm, cy+ch-1.7*cm - j*0.5*cm, ln)
c.showPage()

# ============================================================ SLIDE 6 — VENTAJAS + TIEMPOS
footer(6); barra_titulo("Ventajas y ahorro de tiempo", "Ciclo agentico vs ejecucion manual (estimado)")
# Ventajas (izquierda)
c.setFillColor(AZUL); c.setFont("Helvetica-Bold", 13); c.drawString(1.2*cm, H-3.4*cm, "Ventajas del testing agentico")
vent = [
 "Velocidad: el ciclo completo por SP corre en horas, no semanas.",
 "Cobertura: 1 caso por escenario, sin recortes por tiempo.",
 "Consistencia: mismas reglas en cada corrida, sin fatiga humana.",
 "Trazabilidad: todo derivado del SP (fuente de verdad).",
 "Repetibilidad: re-ejecutar la matriz completa es inmediato.",
 "Documentacion incluida: CU, CP, UML y logica sin esfuerzo extra.",
]
yy = H-4.2*cm
c.setFont("Helvetica", 10.5)
for v in vent:
    c.setFillColor(VERDE); c.circle(1.5*cm, yy+0.12*cm, 0.12*cm, fill=1, stroke=0)
    c.setFillColor(TEXTO)
    for j,ln in enumerate(wrap(v,"Helvetica",10.5,11*cm)):
        c.drawString(1.9*cm, yy - j*0.48*cm, ln)
    yy -= 1.15*cm

# Comparativa de tiempos (derecha) — barras
bx = 15.5*cm; bw2 = W-bx-1.4*cm
c.setFillColor(AZUL); c.setFont("Helvetica-Bold", 13); c.drawString(bx, H-3.4*cm, "Tiempo por SP (estimado)")
# datos: (etiqueta, valor_relativo, texto, color)
comp = [
 ("Agentico", 4.0/81.45, "~ 3-5 horas (est.)", VERDE),
 ("Manual QA", 1.0, "~ 81.45 horas", NARANJA),
]
base_y = 5.0*cm; barmax = 11*cm; barh = 1.6*cm
yy = H-5.2*cm
for lab, rel, txt, col in comp:
    c.setFillColor(TEXTO); c.setFont("Helvetica-Bold", 10); c.drawString(bx, yy+barh+0.15*cm, lab)
    c.setFillColor(GRISCL); c.roundRect(bx, yy, barmax, barh, 0.1*cm, fill=1, stroke=0)
    c.setFillColor(col); c.roundRect(bx, yy, max(0.6*cm, barmax*rel), barh, 0.1*cm, fill=1, stroke=0)
    c.setFillColor(colors.white if rel>0.25 else TEXTO); c.setFont("Helvetica-Bold", 10)
    tx = bx+0.3*cm if rel>0.25 else bx+barmax*rel+0.3*cm
    c.setFillColor(TEXTO); c.drawString(bx+barmax*rel+0.3*cm if rel<0.5 else bx+0.3*cm, yy+barh/2-0.12*cm, txt)
    yy -= (barh+1.6*cm)
# nota de calculo
c.setFillColor(GRISCL); c.roundRect(bx-0.1*cm, 1.6*cm, bw2+0.2*cm, 3.0*cm, 0.15*cm, fill=1, stroke=0)
c.setFillColor(AZUL); c.setFont("Helvetica-Bold", 9.5); c.drawString(bx+0.2*cm, 4.3*cm, "Desglose del QA manual (por SP):")
c.setFillColor(TEXTO); c.setFont("Helvetica", 8.5)
manual = [
 "Creacion de casos de prueba (TC): 35.20 h",
 "Ejecucion de las pruebas: 22.25 h",
 "Resto de la documentacion (CU/UML/logica): 16.00 h",
 "Carga en QMetry: 8.00 h",
 "= 81.45 horas por SP  (agentico: ~3-5 h)",
]
yy = 3.85*cm
for m in manual:
    c.drawString(bx+0.2*cm, yy, "- "+m); yy -= 0.42*cm
c.showPage()

# ============================================================ SLIDE 7 — CIERRE
footer(7);
c.setFillColor(AZUL); c.rect(0,0,W,H, fill=1, stroke=0)
c.setFillColor(BLANCO); c.setFont("Helvetica-Bold", 24)
c.drawString(2*cm, H-5*cm, "En resumen")
resumen = [
 "20 agentes de IA cubren todo el ciclo de QA de una migracion.",
 "De ~81 horas de trabajo manual a unas horas por SP.",
 "Pruebas + documentacion (CU, CP, UML, logica) en una sola corrida.",
 "El SP original es la fuente de verdad; la equivalencia es el estandar.",
 "Repetible, consistente y trazable en cada ejecucion.",
]
yy = H-7*cm
c.setFont("Helvetica", 14)
for r in resumen:
    c.setFillColor(colors.HexColor("#8fd1b0")); c.drawString(2*cm, yy, ">")
    c.setFillColor(BLANCO)
    for j,ln in enumerate(wrap(r,"Helvetica",14,W-6*cm)):
        c.drawString(2.7*cm, yy - j*0.6*cm, ln)
    yy -= 1.5*cm
c.showPage()

c.save()
print("PDF generado:", OUT)

# KPIs QA Simplificado — Agosto 2026

## 1. Eficiencia

**Formula:** % de tareas terminadas a tiempo sobre las tareas planeadas del mes.
`Eficiencia = (Tareas done a tiempo / Tareas planeadas de agosto) x 100`

| Persona | Tareas planeadas | Terminadas a tiempo | Eficiencia |
|---|---|---|---|
| Juan Pablo Sanabria Moscoso | 5 | 2 | 40.0% |
| Gengis Hidalgo Guevara | 24 | 5 | 20.8% |
| William Nieto Rico | 9 | 2 | 22.2% |
| Nicolas Rodriguez Mejia | 15 | 9 | 60.0% |
| Giorgi Torres Martelo | 4 | 2 | 50.0% |

*Juan Pablo y William: 2 tareas c/u corregidas a "a tiempo" tras verificar evidencia real (archivo de
corrida de matriz con fecha anterior al `updatedAt` de la tarea) — ver comentario en `statusHistory`
de cada tarea en Gestor QA.*

---

## 2. Calidad

**Formula:** % segun la severidad de las correcciones (defectos Alta=3, Media=2, Baja=1) recibidas.
`Calidad = (1 - (Puntos de defectos / (3 x Tareas planeadas))) x 100`

| Persona | Correcciones | Puntos | Tareas planeadas | Calidad |
|---|---|---|---|---|
| Juan Pablo Sanabria Moscoso | 2 | 4 | 5 | 73.3% |
| Gengis Hidalgo Guevara | 5 | 11 | 24 | 84.7% |
| William Nieto Rico | 0 | 0 | 9 | 100.0% |
| Nicolas Rodriguez Mejia | 2 | 4 | 15 | 91.1% |
| Giorgi Torres Martelo | 0 | 0 | 4 | 100.0% |

---

## 3. Eficacia

**Formula:** % de tareas sin devoluciones (defectos) sobre el total de tareas planeadas.
`Eficacia = (1 - (Devoluciones / Tareas planeadas)) x 100`

| Persona | Devoluciones | Tareas planeadas | Eficacia |
|---|---|---|---|
| Juan Pablo Sanabria Moscoso | 2 | 5 | 60.0% |
| Gengis Hidalgo Guevara | 5 | 24 | 79.2% |
| William Nieto Rico | 0 | 9 | 100.0% |
| Nicolas Rodriguez Mejia | 2 | 15 | 86.7% |
| Giorgi Torres Martelo | 0 | 4 | 100.0% |

---

## 4. Totales (Agosto 2026)

| Dato | Total |
|---|---|
| Tareas creadas | 86 |
| Microservicios creados | 16 |
| Casos de prueba creados | 119 |

# Investigacion — Falsos positivos en la matriz de equivalencia de sp_ah_depositosl_rc

> **Elaborado por:** QA · **Fecha:** 2026-07-31
> **SP:** `sp_ah_depositosl_rc` (microservicio `cpas-mso-depositosl-rc`)
> **Objetivo:** dejar trazabilidad completa de la investigacion realizada sobre los resultados
> NO-EQUIVALENTE/INCONSISTENCIA de la matriz de este SP, las causas reales encontradas, las
> correcciones ya aplicadas al motor QA, y la inconsistencia que **queda pendiente** para que
> otro QA pueda continuar sin repetir el analisis desde cero.
>
> **Alcance de esta investigacion:** motor de pruebas y datos de ambiente (responsabilidad QA).
> **No se modifico codigo del microservicio** en ningun punto — eso es responsabilidad del equipo
> de Migracion, y en esta investigacion se confirmo que el micro no tiene defecto en los puntos
> analizados.

---

## 1. Contexto — como se detecto

El 30-07-2026 se verificaron los 3 SPs nuevos migrados (depositos, retiro, consulta firmante).
Los 3 tenian corridas de matriz del mismo dia. Retiro (`sp_ah_retiro_rc`, 19/19) y consulta
firmante (`pa_fir_consulta_firmante`, 15/15) cerraban en 100% EQUIVALENTE. Depositos
(`sp_ah_depositosl_rc`) cerraba en **13 EQUIVALENTE / 14 NO_EQUIVALENTE** de 27 TCs.

Se re-ejecuto la matriz de depositos varias veces durante esta investigacion para aislar causas.
Resumen de resultados por corrida:

| Corrida | EQUIVALENTE | Otros veredictos | Causa dominante |
|---|---|---|---|
| 30-07-2026 1401 (previa) | 13 | 14 NO_EQUIVALENTE | HTTP 500 en canal CNB (6) + tope 128100 (8) — ver §2 |
| 31-07-2026 0236 (tras investigar HTTP 500) | 21 | 5 INCONSISTENCIA + 1 SYBASE_FAIL | Bug de tipo en el motor (§3) + fecha de proceso desalineada (§2) |
| 31-07-2026 fix2 (tras corregir el bug de tipo) | 21 | 3 INCONSISTENCIA + 3 NO_EQUIVALENTE | Tope de saldo MSCP/VIR agotado por acumulacion entre corridas (§4) |
| 31-07-2026 verifreset (tras crear el INSTRUCTIVO y resetear saldos) | **24** | **3 INCONSISTENCIA** | Snapshot de `ah_tran_monet` no aislado entre pasada SP y pasada REST (§5 — **PENDIENTE**) |

Cada causa se investigo y se cerro por separado. El detalle de cada una sigue abajo.

---

## 2. Causa cerrada — HTTP 500 en canal CNB / fecha de proceso desalineada

En la corrida del 30-07 (1401), 6 TCs del canal CNB (TC03, TC04, TC05, TC13, TC14, TC16) daban
HTTP 500 en REST mientras el SP corria con `return_code=0`. Al investigar el SP legacy
(`cob_virtuales__sp_bas_depo2_locrem_sl_rc.sql`), se confirmo que el posteo monetario valida la
fecha de proceso vigente (`cobis..ba_fecha_proceso`, columna `fp_fecha`) contra `@s_date`. Los
TCs usan `@s_date` fijo en el documento de casos; si esa fecha queda desalineada respecto a la
fecha de proceso real de Sybase, el INSERT en `ah_tran_monet` falla con `@@error != 0` y el SP
retorna `45004` ("ERROR AL ACTUALIZAR TRANSACCION monetaria") — el propio documento de casos
(`qa_casos_prueba.md`, nota en TC05) ya documentaba este mecanismo antes de esta investigacion.

**No es un defecto del micro.** Es sensibilidad de los TCs a la fecha de proceso del ambiente,
ya conocida y documentada. No requirio cambio de codigo; el patron de "fecha de proceso vigente"
resuelve solo cuando los TCs se ejecutan con `@s_date` alineado al dia de la corrida.

---

## 3. Causa cerrada — bug de tipo en el motor QA (comparacion `varchar`/`char` vs numero)

### 3.1 Sintoma

En la corrida 31-07 0236, 5 TCs (TC04, TC05, TC13, TC14, TC16) daban **INCONSISTENCIA** con
diffs reportados en `o_valor`, `o_valor1` y `o_cta_lat`:

| TC | Campo | SP (parser QA) | REST (real) |
|----|-------|-----------------|--------------|
| TC04 | o_valor | `100.0` (float) | `"100.00"` (string) |
| TC04 | o_cta_lat | `296` (int) | `"296"` (string) |
| TC05 | o_cta_lat | `32` (int) | `"032"` (string, cero a la izquierda) |

### 3.2 Investigacion — trazabilidad completa del tipo real

Se verifico el tipo de estos 3 parametros en TODA la cadena, desde el SP legacy hasta el
response del micro:

1. **SP Sybase** (`cob_ahorros__sp_ah_deposito_sl_rc.sql:99-103`): declara
   `@o_valor varchar(11)`, `@o_valor1 varchar(11)`, `@o_cta_lat char(3)` — son **texto**, no
   numericos.
2. **JDBC** (libreria `sp-ah-depositosl-rc-utils`, `AbstractLegacyExecAdapter.java:151-154`):
   lee con `rs.getString("o_valor")` — correcto, coherente con el tipo real de Sybase.
3. **Domain records** (`DepositoSpResult`, `DepositoslRcResult`, `DatosDeposito` del micro):
   los 3 campos son `String` en las 3 capas.
4. **DTO REST** (`DatosDepositoDto.java`): `String oValor/oValor1/oCtaLat`.
5. **gRPC** (`DepositoGrpcMapper.java:141-151`): usa `StringValue.of(...)` — el wrapper de
   proto3 que existe SOLO para strings.

**Conclusion: el micro es fiel al tipo real del SP en las 6 capas, en REST y en gRPC.** Se
verifico ademas que gRPC y REST son idempotentes entre si (mismos valores `"100.00"`, `"032"`,
etc. en ambos canales, `diffs: {}` en el propio `grpc_output` de cada TC) — la unica divergencia
era motor-vs-micro, nunca REST-vs-gRPC.

### 3.3 Causa raiz real

El parser de resultados de tsql del motor QA (`execute_all.py`, funciones `parse_tab_output` y
`_coerce_cell`) **adivinaba el tipo** de cada columna intentando `int(v)` y luego `float(v)`
sobre el texto crudo que devuelve tsql, sin consultar el tipo SQL real declarado del parametro
(que el motor ya tenia disponible en `output_params`, ej. `{"nombre": "o_valor", "tipo":
"varchar(11)"}`). Como `"100.00"` y `"032"` parecen numericos, el parser los convertia a `100.0`
y `32` — perdiendo el formato de texto (decimales fijos, ceros a la izquierda) que el propio SP
y el micro preservan. Al comparar ese valor "adivinado" contra el string real del REST, el motor
marcaba diff aunque el dato fuera el mismo.

### 3.4 Fix aplicado

Se agrego `_is_numeric_sp_type(tipo)` en `execute_all.py`: deriva el tipo base (recorta
longitud/precision) y solo permite la conversion a `int`/`float` cuando el tipo declarado del
parametro es realmente numerico (`int`, `smallint`, `tinyint`, `float`, `numeric`, `decimal`,
`money`, `smallmoney` — reutiliza la constante `NUMERIC_TYPES` ya existente en el motor). Si el
tipo es `varchar`/`char`/cualquier otro, el valor se preserva como string tal cual vino de tsql.

`parse_tab_output` y `_coerce_cell` ahora aceptan un parametro opcional `output_param_types`;
sin ese parametro (o sin tipo conocido para una columna puntual) se mantiene el comportamiento
previo (intentar numero primero) — retrocompatible para las rutas donde el diccionario no trae
tipo por columna (ej. `RS<n>.*` de SPs en modo `result_sets`).

**Archivo modificado:** `.claude/docs-qa/inputs/scripts/auto/execute_all.py` (fuente unica en
`claude-setupv2`, propagado por copia a `claude-setupv3` — pendiente, ver §6 — y a los 3 repos de
microservicio: `cpas-mso-depositosl-rc`, `cpas-mso-retiro-rc`, `cpas-mso-consulta-firmante`).

**Verificacion del fix (con tests unitarios in-line antes de propagar):**
- `varchar(11)`/`char(3)` con contenido numerico (`"100.00"`, `"032"`) → se preserva como string.
- `money`/`int` (ej. `o_impuesto`, `o_ssn`) → sigue convirtiendo correctamente a `float`/`int`.
- Sin tipo declarado → comportamiento previo intacto (backward compat).
- `NULL` → sigue mapeando a `None` sin cambios.

**Impacto verificado en los otros 2 SPs nuevos (para descartar regresion):**
- `sp_ah_retiro_rc`: sus unicos `varchar` de salida (`o_nombre`, `o_destra`) nunca contienen solo
  digitos en la corrida real (vienen `null` o texto genuino) — el fix es no-op. Re-ejecutado tras
  el fix: **19/19 EQUIVALENTE, sin cambio.**
- `pa_fir_consulta_firmante`: no usa `output_params` (comunica por `RESULT SETS`, ruta de codigo
  distinta — `parse_result_sets`). Re-ejecutado tras el fix: **15/15 EQUIVALENTE, sin cambio.**

**Resultado en depositos tras el fix:** las 5 INCONSISTENCIA de tipo (TC04, TC05, TC13, TC14,
TC16) dejaron de aparecer por esta causa. (En la corrida inmediatamente posterior aparecieron
otros veredictos negativos en TC13/14/16, pero por una causa DISTINTA — ver §4, ya tambien
resuelta).

---

## 4. Causa cerrada — saldo de cuentas de prueba acumulado entre corridas (tope MSCP/VIR)

### 4.1 Sintoma

Tras el fix de §3, TC13/TC14/TC16 (canal CNB, cuentas virtuales `0924000042/054/066`) pasaron a
**NO_EQUIVALENTE** con `SP codigo=0, REST codigo=128100`.

### 4.2 Investigacion

Se rastreo el codigo `128100` al SP legacy `cob_virtuales__sp_bas_depo2_locrem_sl_rc.sql:283`:

```sql
if (@w_saldo_contable+isnull(@w_efectivo,0)+isnull(@i_loc,0)) > @w_saldo_max
begin
    select @w_return=128100
    ...
    -- @i_num = 128100 -- "La suma del saldo contable + el deposito,excede a lo permitido en la cuenta"
    return 128100
end
```

`@w_saldo_max` se lee de `cobis..cl_parametro` (nemonico `MSCP`, producto `VIR`). Se verifico en
vivo contra Sybase: **`pa_money = 1840.0000`**. Es un tope de negocio real y configurable del
ambiente, no un artefacto de prueba.

`@w_saldo_contable` se calcula llamando a `cob_virtuales..sp_bascalcula_saldo`, que en estas
cuentas de prueba (verificado: `vi_12h=vi_24h=vi_48h=vi_remesas=vi_monto_bloq=0`) resulta
equivalente a `vi_disponible`. Al momento de la falla, las 3 cuentas tenian:

| Cuenta | `vi_disponible` | Margen contra 1840 |
|---|---|---|
| 0924000042 | 1819.25 | 20.75 |
| 0924000054 | 1801.00 | 39.00 |
| 0924000066 | 1800.36 | 39.64 |

Cada corrida de la matriz deposita $100 en estas mismas cuentas via SP + REST + gRPC (3 pasadas
por corrida, sobre cuentas reales compartidas y reutilizadas entre corridas, **sin ningun
reset**). Tras 2-3 corridas sucesivas el margen se agota y el siguiente deposito de $100 excede
el tope — y lo excede **igual en SP y en REST**, por lo que no es una divergencia de equivalencia
real, sino agotamiento de dato de prueba.

**No es un defecto del micro.** El micro y el SP rechazan el mismo deposito por la misma razon de
negocio.

### 4.3 Correccion aplicada — INSTRUCTIVO-PREPARACION-BD.md

El SP `sp_ah_depositosl_rc` **no tenia** `INSTRUCTIVO-PREPARACION-BD.md` (por eso la fase de
reset de BD del motor salia `SKIPPED` en cada corrida). Se creo el archivo en:

```
cpas-mso-depositosl-rc/.claude/docs-qa/inputs/documents/sp_ah_depositosl_rc/auto/INSTRUCTIVO-PREPARACION-BD.md
```

Con un bloque `PASO 1` que normaliza el saldo de las 5 cuentas de prueba compartidas a un
baseline bajo y conocido antes de cada corrida:

```sql
-- Cuentas AHO (sin limite de gate, pero se normalizan para tener baseline reproducible):
UPDATE cob_ahorros..ah_cuenta SET ah_disponible = 1000.0000, ah_saldo_ayer = 1000.0000
WHERE ah_cta_banco IN ('0000617296', '0000837032')
go
-- Cuentas virtuales CNB (con gate MSCP/VIR=1840): reset a 500.00, margen amplio (>1300).
UPDATE cob_virtuales..vi_cuenta SET vi_disponible = 500.0000, vi_saldo_ayer = 500.0000
WHERE vi_cta_banco IN ('0924000042', '0924000054', '0924000066')
```

Se aplico el reset en vivo contra Sybase (verificado por SELECT posterior) y se re-ejecuto la
matriz completa con `run_qa.py` (que ahora corre `FASE 1: Reinicio de BD` en vez de `SKIPPED`).
**Resultado: TC13/14/16 pasan a EQUIVALENTE.** El total subio de 21 a **24 de 27 EQUIVALENTE**.

---

## 5. INCONSISTENCIA PENDIENTE — snapshot de `ah_tran_monet` no aislado entre pasada SP y REST

**Este es el punto que queda abierto para continuar.**

### 5.1 Sintoma (estado actual, corrida `31-07-2026-verifreset`)

3 TCs (TC03, TC04, TC05 — canal CNB, cuentas AHO `0000617296`/`0000837032`) quedan en
**INCONSISTENCIA** con la nota: `"Codigo OK pero DIFFS en: ah_tran_monet"`.

Evidencia detallada de TC04 (cuenta `0000617296`, deposito de `$100` via `i_efe`):

| | SP (pasada 1) | REST (pasada 2) |
|---|---|---|
| `tm_cta_banco` insertado | 617296 | 617296 (misma cuenta) |
| `tm_secuencial` | 950001 | 950001 |
| `tm_valor` (monto de la fila insertada) | 100.0 | 100.0 |
| `tm_saldo_contable` resultante (post) | **1100.0** | **1200.0** |

### 5.2 Causa raiz (ya diagnosticada, no corregida)

El motor ejecuta la pasada SP y la pasada REST **secuencialmente sobre la MISMA cuenta real** en
Sybase, sin aislarlas entre si. Cada pasada inserta una fila real y correcta con el mismo monto
($100), pero como la pasada REST arranca *despues* de que el SP ya deposito, el saldo de la
cuenta ya subio 100 antes de que corra el REST. El incremento que aporta cada canal es
**identico** (+100 en ambos), pero el motor compara los valores **absolutos** resultantes
(1100 vs 1200) en vez del incremento relativo — y esos absolutos nunca van a coincidir mientras
las dos pasadas compartan la misma cuenta mutable.

Razon tecnica de por que el motor no calcula el incremento en este caso: `ah_tran_monet` se
declara en el documento de casos como tabla monitoreada tipo "TOP N filas" (una lista, no una
fila unica indexada). Cuando el PRE de esa tabla no es un `dict` (viene como lista), el motor
trata la comparacion como "sin fila base" y compara transiciones absolutas
`(pre, post)` en vez de magnitudes `(post - pre)`. Para tablas con snapshot de fila unica
(`ah_cuenta`, con clave `ah_cta_banco`) el motor SI compara magnitud correctamente cuando ambos
lados son numericos (`execute_all.py`, bloque de `snapshot_diffs`, rama `isinstance(..., (int,
float))` -> calcula `sp_mag`/`rest_mag`); el problema es especifico de tablas tipo lista.

**No es un defecto del micro** — evidencia: mismo `tm_valor=100.0` insertado por ambos canales,
mismo `tm_cta_banco`, mismo `i_efe` de entrada. El efecto de negocio de cada pasada es idempotente
entre si; el motor de comparacion es el que no aisla el estado compartido.

### 5.3 Opciones de correccion evaluadas (sin implementar — para que el siguiente QA decida)

1. **Excluir `tm_saldo_contable`/`tm_saldo_disponible` de la comparacion** en la tabla
   `ah_tran_monet` (agregarlas a la columna "Campos a ignorar" de `TABLAS MONITOREADAS` en
   `qa_casos_prueba.md`). Son estado acumulado de cuenta, no el efecto directo de la transaccion
   — el resto de columnas de la fila (`tm_valor`, `tm_efectivo`, `tm_cta_banco`, `tm_tipo_tran`)
   ya coinciden y son las que realmente prueban el efecto del deposito.
   - Riesgo: bajo. Cambio de configuracion en el documento, no en el motor.
   - Limitacion: no corrige el patron para otros SPs/tablas con el mismo problema.

2. **Capturar solo la fila nueva de cada pasada** usando el mismo mecanismo del fix #1 de
   JIRA-1047 (filtro de recencia por `tm_secuencial`/`tm_hora`, ver
   `docs-qa/todo/JIRA-1047_analisis_fix1_snapshot.md`) y comparar esa fila puntual SP-vs-REST, en
   vez de comparar el snapshot completo tipo TOP-N.
   - Riesgo: medio. Cambio en el motor (`execute_all.py`), reutiliza codigo ya existente y
     probado para el mismo tipo de problema.
   - Ventaja: corrige el patron de forma generica para cualquier tabla tipo lista con el mismo
     sintoma, no solo `ah_tran_monet`.

3. **Resetear el saldo de la cuenta entre la sub-pasada SP y la sub-pasada REST** (dentro del
   mismo TC, no solo una vez al inicio de la corrida como en §4.3), para que REST arranque del
   mismo baseline que arranco SP.
   - Riesgo: medio-alto. Requiere tocar el flujo de ejecucion por TC en el motor.

4. **Aislar cuentas por canal de pasada** (una cuenta dedicada para la pasada SP, otra clonada
   con el mismo estado para la pasada REST).
   - Riesgo: alto. Requiere datos de ambiente adicionales (mas cuentas de prueba equivalentes) y
     cambios en el documento de casos.

**Recomendacion de esta investigacion:** la opcion 1 es la de menor riesgo e implementacion
inmediata; la opcion 2 es la mas consistente con el patron que el motor ya usa para el problema
analogo de JIRA-1047, y corrige la causa de raiz para cualquier tabla tipo lista, no solo esta.

---

## 6. Archivos tocados en esta investigacion (referencia rapida)

| Archivo | Cambio |
|---|---|
| `claude-setupv2/.claude/docs-qa/inputs/scripts/auto/execute_all.py` | Fix de tipo §3.4 (fuente unica) |
| `cpas-mso-depositosl-rc/.claude/docs-qa/inputs/scripts/auto/execute_all.py` | Copia sincronizada del fix |
| `cpas-mso-retiro-rc/.claude/docs-qa/inputs/scripts/auto/execute_all.py` | Copia sincronizada del fix (verificado no-op) |
| `cpas-mso-consulta-firmante/.claude/docs-qa/inputs/scripts/auto/execute_all.py` | Copia sincronizada del fix (verificado no-op) |
| `cpas-mso-depositosl-rc/.claude/docs-qa/inputs/documents/sp_ah_depositosl_rc/auto/INSTRUCTIVO-PREPARACION-BD.md` | Creado — reset de saldo de las 5 cuentas de prueba (§4.3) |

**Pendiente de propagacion:** `claude-setupv3/.claude/docs-qa/inputs/scripts/auto/execute_all.py`
tiene un hash distinto a la version v2 usada como fuente en esta investigacion (no se confirmo si
v3 ya tiene una version equivalente del parser o si necesita el mismo fix) — validar antes de dar
por cerrada la propagacion a v3.

**Pendiente de decision:** cual de las 4 opciones de §5.3 aplicar para cerrar la INCONSISTENCIA
de `ah_tran_monet`, y si el mismo patron de reset de saldo (§4.3) debe replicarse tambien para
`sp_ah_retiro_rc` y otros SPs con cuentas de prueba compartidas y mutables entre corridas.

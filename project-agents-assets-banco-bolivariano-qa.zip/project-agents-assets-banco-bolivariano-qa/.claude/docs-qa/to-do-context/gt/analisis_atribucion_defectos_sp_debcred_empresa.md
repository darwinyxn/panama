# Analisis de atribucion de defectos — sp_debcred_empresa (NCBE-661)

> **Elaborado por:** QA · **Fecha:** 2026-07-08
> **HU:** NCBE-661 "Debito o Credito empresa Pagos"
> **Fuente:** Jira (descripcion + comentarios de los 116 defectos) + matriz oficial `sp_debcred_empresa-OFICIAL-07-07-2026-2210` (94/94 EQUIVALENTE) + verificacion directa SP/REST/gRPC.
> **Objetivo:** determinar cuales defectos son un error REAL atribuible al micro / SP / gRPC, y cuales se crearon por otras causas (no se probo, version vieja, parametros de ejecucion erroneos, diferencias del arnes de QA, o decision de contrato).

---

## 1. Resumen ejecutivo

De **116 defectos** analizados, agrupados en 3 bloques:

- **BLOQUE 1 — ATRIBUIBLES A NOSOTROS (42):** algo nuestro tuvo que corregirse por ser un error. Se divide en error del microservicio (construccion) y error del arnes/artefacto de QA.
- **BLOQUE 2 — MEJORA DE QA, NO DEFECTO (18):** el banco reporto "diferencia en el tipo de dato" (gRPC enviaba string, REST numero). **NO era un defecto**: el gRPC aceptaba tanto numero como string y la funcionalidad operaba correcto. QA aplico el cambio de tipo como **mejora** para comodidad del banco (paridad literal de tipo), no por una falla.
- **BLOQUE 3 — NO SON DEFECTOS REALES DEL SP/MICRO/gRPC (56):** el SP, el micro y el gRPC funcionan correcto; el defecto se origino por como el banco ejecuto/reporto, o es una decision de contrato pendiente.

| # | Bloque | Categoria | Cant. | ¿Es un defecto real? | Estado |
|---|--------|-----------|-------|----------------------|--------|
| 1 | **ATRIBUIBLE A NOSOTROS** | Error real del **micro/SP/gRPC** (formato salida) | **3** | Si — codigo del micro | Ya corregido |
| 2 | **ATRIBUIBLE A NOSOTROS** | Error del **arnes/artefacto QA** (exec con firma equivocada / falta @o_reg_a_proc) | **39** | Si — arnes/generador QA | Ya corregido |
| | | **Subtotal atribuible a nosotros (defectos)** | **42** | | |
| 3 | **MEJORA QA (NO defecto)** | Tipo de dato gRPC (string vs numero) — gRPC aceptaba ambos y funcionaba; QA lo alineo como mejora | **18** | No — mejora, no falla | Aplicado por QA |
| 4 | **NO ES DEFECTO REAL** | **Banco/ejecucion**: no aplicaron precondiciones, probaron version vieja, o caso que no debia ejecutarse | **48** | No | El micro responde correcto en matriz oficial |
| 5 | **NO ES DEFECTO REAL** | **Decision de contrato** (campo debug, con banco) | **8** | No — no es bug | 3 cerrados de acuerdo, 5 por definir |
| | | **Subtotal NO defecto (mejora + banco + contrato)** | **74** | | |
| | | **TOTAL** | **116** | | |

> Aclaracion "atribuible a nosotros" (42): (a) **micro/SP/gRPC = 3** (error de codigo del microservicio) y (b) **arnes de QA = 39** (exec con firma equivocada de ndc_automatica o sin declarar @o_reg_a_proc). Ambos ya corregidos y EQUIVALENTES en la matriz oficial.
>
> **MEJORA, NO defecto (18):** el tipo de dato en gRPC (string vs numero) NO era una falla — gRPC/proto3 acepta el monto como numero o como string y lo convierte al mismo `double`; la funcionalidad siempre fue correcta y el veredicto EQUIVALENTE. QA modifico el generador de payload para enviar numero (paridad literal con REST) como mejora de comodidad para el banco, no por un defecto.
>
> Los **56 del bloque 3 NO son defectos reales del SP/micro/gRPC**: 48 por la forma en que el banco ejecuto (sin precondiciones, version vieja, casos que no debian correrse) y 8 por decision de contrato del campo debug.

### 1.1 Detalle "QA / arnes" (39) — atribuibles a NOSOTROS pero NO al micro

Son errores del **artefacto de prueba que genera QA** (no del microservicio). En la matriz oficial, con el artefacto corregido, todos dan EQUIVALENTE.

| Causa (QA) | Cant. | Casos |
|------------|-------|-------|
| Exec con firma de otro SP (ndc_automatica) / falta declarar @o_reg_a_proc | 39 | NCBE-720..779, 915 (los que NO reportan 31017) |

> Corregido en la generacion del exec (firma correcta de `sp_debcred_empresa` + @o_reg_a_proc). Verificado: matriz oficial EQUIVALENTE.

### 1.2 Detalle "MEJORA QA — tipo de dato gRPC (NO defecto)" (18)

El banco reporto que en gRPC los montos llegaban como string (`"0.005"`) y en REST como numero (`0.005`). **Esto NO es un defecto:**
- gRPC/proto3 acepta el valor en campos `double` tanto como numero como string, y lo convierte internamente al mismo `double`.
- La funcionalidad siempre fue correcta (mismo debito, mismo `o_error`); el veredicto de equivalencia fue EQUIVALENTE en todas las corridas.
- El .proto del micro ya definia los montos como `double` (correcto).

Como **mejora de comodidad para el banco** (paridad literal de tipo REST/gRPC), QA modifico el generador de payload (`execute_all.py`) para enviar los montos como numero. No fue una correccion de falla.

| Origen del reporte | Cant. | Casos |
|--------------------|-------|-------|
| Tipo de dato string vs numero en payload gRPC | 13 | NCBE-788, 789, 808, 813, 814, 815, 816, 817, 820, 821, 822, 823, 824 |
| Diferencia de tipo (aclarada como no-defecto) | 5 | NCBE-785, 786, 787, 811, 819 |

### 1.3 Detalle "Banco / ejecucion" (48) — NO atribuibles a nosotros

| Causa (banco) | Cant. | Casos |
|---------------|-------|-------|
| Precondiciones NO ejecutadas -> "fondos insuficientes" 31017 | 22 | NCBE-741, 742, 744, 746, 747-764 |
| No pudieron reproducir gRPC / probaron entrega vieja (6/7) | 18 | NCBE-781, 784, 792-810 |
| Caso no se debio ejecutar (ESTADO OBSERVADO) | 8 | NCBE-711-718 |

> Los 22 de codigo 31017 (y el 41033 de NCBE-915) son "FONDOS INSUFICIENTES": aparecen SOLO porque no se aplicaron las precondiciones de saldo. Con las PRE ejecutadas (matriz oficial) dan 22/22 EQUIVALENTE, sin ningun 31017. Nota: 3 casos (719, 795 + 791) son dudas/otros ya verificados; se cuentan aparte del debate de contrato.

**Conclusion:** solo **3 defectos** fueron error real del **microservicio** (formato de salida gRPC/REST), y **los 3 ya estan corregidos**. **39 son atribuibles a NOSOTROS pero al ARNES/artefacto de QA** (no al micro): exec con firma equivocada o sin @o_reg_a_proc — todos ya corregidos y EQUIVALENTES en la matriz oficial. **18 NO eran defectos sino una MEJORA** aplicada por QA (tipo de dato gRPC string->numero; gRPC aceptaba ambos y funcionaba). **48 son del banco** (no aplicaron precondiciones, probaron version vieja o casos que no debian ejecutarse). **8 son decision de contrato** del campo debug (no bug de codigo). En resumen: cero defectos funcionales vigentes del micro; solo 3 fueron errores de codigo del micro (resueltos) y 39 de nuestro arnes (resueltos); el resto (74) son mejora, ejecucion del banco o contrato — no defectos reales.

---

## 2. Defectos con ERROR REAL atribuible al micro (gRPC/REST) — 3 (ya resueltos)

Estos si describieron una divergencia real de comportamiento del micro, no un error de prueba. Ya corregidos.

| Jira | Componente | Descripcion | Estado | Resolucion |
|------|-----------|-------------|--------|-----------|
| NCBE-780 | gRPC | gRPC no mostraba todos los campos de salida con su valor por defecto | Finalizada | Se emiten defaults (`-emit-defaults` + wrappers); corregido |
| NCBE-783 | REST/gRPC | Campos que deben ser `null` se visualizaban en `0` | Finalizada | Wrappers nullable (Int32Value/StringValue); corregido |
| NCBE-924 | REST/gRPC | Cuerpo de respuesta sin envoltura `codigoRetorno`/`mensajeDebug`/`data` | Testing BB | Envoltura ya implementada (verificado hoy via REST/gRPC); pendiente cierre |

---

## 3. Debate de contrato — campo debug (5) — NO es bug de codigo

Discusion sobre si el micro debe exponer `mensajeDebug`/`debug` cuando el SP crudo NO lo devuelve como parametro de salida (el SP solo tiene `@o_error` y `@o_reg_a_proc`). El valor proviene de `cobis..cl_errores` (no esta quemado).

| Jira | TC | Estado | Nota |
|------|----|--------|------|
| NCBE-818 | TC37 | Finalizada | **Cerrado "en acuerdo Banco y proveedor, no genera problema funcional"** |
| NCBE-826 | TC38 | Finalizada | Mismo tema |
| NCBE-1034 | Mensaje debug | Testing BB | "Pendiente por definirse con banco... hasta establecer el correcto estandar" |
| NCBE-1035 | TC182 | Testing BB | Igual — SP no devuelve mensaje_debug pero el JSON si |
| NCBE-1036 | TC184 | Testing BB | Igual |

> Relacionado: NCBE-791 (Zona Revisar) es del mismo debate del campo debug.

---

## 4. Detalle por causa (no son defectos de codigo del micro)

> Nota: los grupos D y F NO son defectos sino la MEJORA de tipo de dato aplicada por QA (ver seccion 1.2). Se listan aqui por trazabilidad del reporte original del banco.

### A. "No se debio ejecutar" / ESTADO OBSERVADO (8) — banco
El defecto indica que el caso no debia ejecutarse (estado observado); se creo el defecto sin corresponder.

NCBE-711, 712, 713, 714, 715, 716, 717, 718
El defecto indica que el caso no debia ejecutarse (estado observado); se creo el defecto sin corresponder.

NCBE-711, 712, 713, 714, 715, 716, 717, 718

### B. Parametros de ejecucion erroneos + fondos insuficientes por PRE no aplicada (61)
Estos defectos traen hasta 3 observaciones, todas de la EJECUCION de la prueba (no del micro):

1. *"Parametros para ejecucion no corresponden, se esta declarando variables de la **ndc_automatica**"* / *"En la exec no se esta declarando la variable @o_reg_a_proc"* — el exec/dato de prueba con el que el banco ejecuto uso una firma que no corresponde. En la matriz oficial, con la firma correcta, estos TCs dan EQUIVALENTE.

2. **Codigo 31017 en el micro** (22 de los 61: NCBE-741, 742, 744, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764). El banco observo *"aparece codigo 31017, no existe en el sp"*. **Verificado:**
   - `31017 = "FONDOS INSUFICIENTES"` (codigo COBIS real de la cadena de cuentas; mismo patron que 41033/NCBE-915).
   - **Causa: el banco NO ejecuto correctamente las precondiciones** (que dejan saldo suficiente en la cuenta). Sin saldo, el debito falla con 31017.
   - **Evidencia:** en la matriz oficial (que SI aplica las PRE) esos 22 TCs dan **22/22 EQUIVALENTE** y **NINGUNO** presenta o_error=31017.
   - **NO atribuible al micro** — es un tema de datos/precondiciones al ejecutar.

NCBE-720, 721, 722, 723, 724, 725, 726, 727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737, 738, 739, 740, 741, 742, 743, 744, 745, 746, 747, 748, 749, 750, 751, 752, 753, 754, 755, 756, 757, 758, 759, 760, 761, 762, 763, 764, 765, 766, 767, 768, 769, 770, 771, 772, 773, 774, 775, 776, 777, 778, 779, 915

### C. No reprodujeron / version vieja (18)
*"Se devuelve a To Do porque en la entrega del 6/7/26 6pm no deja reproducir los casos gRPC"* / *"no se encuentra el caso"*. Se probo una entrega anterior. Comentarios posteriores confirman *"ya fue resuelto / nueva matriz cargada"*.

NCBE-781, 784, 792, 793, 794, 796, 797, 798, 799, 800, 801, 802, 803, 804, 805, 807, 809, 810

### D + F. Tipo de dato gRPC (string vs numero) — MEJORA QA, NO defecto (18)
El banco reporto *"gRPC envia string y REST numero/entero"*. **NO es defecto:** gRPC/proto3 acepta el monto como numero o string en campos `double` y lo convierte igual; la funcionalidad siempre fue correcta (EQUIVALENTE). QA alineo el tipo (payload gRPC como numero) en `execute_all.py` como **mejora de comodidad/paridad para el banco**, no por una falla. Ver seccion 1.2.

NCBE-785, 786, 787, 811, 819, 788, 789, 808, 813, 814, 815, 816, 817, 820, 821, 822, 823, 824

### Zona "Revisar" (3) — verificados, ninguno es error del micro
| Jira | Motivo |
|------|--------|
| NCBE-719 | Pregunta "¿que significa SYBASE_ERROR?" — duda de prueba, sin defecto |
| NCBE-795 | reg_a_proc — EQUIVALENTE en matriz oficial (arnes) |
| NCBE-791 | Campo debug — mismo debate de contrato (ver seccion 3) |

---

## 5. Trazabilidad por componente

| Componente señalado en el reporte | Interpretacion |
|-----------------------------------|----------------|
| SP / prueba (69) | Grupos A+B: errores de ejecucion/params de la prueba (arnes QA) y precondiciones no aplicadas (banco), no del SP en si |
| gRPC (36) | Grupo C (version vieja, banco) + grupos D/F (mejora de tipo QA, no defecto); el gRPC del micro responde correcto en la matriz oficial |
| REST/gRPC formato (3) | NCBE-780/783/924: unicos errores reales de contrato del micro, ya resueltos |

### Codigos de "fondos insuficientes" reportados como del micro (verificados NO atribuibles)

| Codigo | Mensaje | Casos | Causa real | Evidencia |
|--------|---------|-------|------------|-----------|
| 31017 | FONDOS INSUFICIENTES | 22 (NCBE-741..764) | Precondiciones no ejecutadas por el banco (cuenta sin saldo) | Matriz oficial: 22/22 EQUIVALENTE, 0 con 31017 |
| 41033 | FONDOS INSUFICIENTES | 1 (NCBE-915/TC167) | Igual — saldo insuficiente al ejecutar | Comentado en Jira; con PRE da 122002 |

Ambos codigos son de la cadena COBIS de cuentas (SP hijos), legitimos; aparecen SOLO cuando la cuenta no tiene saldo, es decir cuando no se aplican las precondiciones. No son defectos del micro.

---

## 6. Recomendaciones

1. **Cerrar** los 113 que no son defectos de codigo del micro vigentes (39 arnes QA ya corregidos + 18 mejora de tipo + 48 banco + 8 contrato): la matriz oficial (94/94 EQUIVALENTE) y las verificaciones directas SP/REST/gRPC demuestran que el micro responde correcto. Aclarar al banco que el tipo de dato gRPC (18) fue una mejora, no un defecto.
2. **Confirmar cierre** de NCBE-924 (envoltura ya implementada — verificado hoy).
3. **Escalar la definicion** del campo debug (NCBE-1034/1035/1036 + 791): decision de contrato con el banco. Precedente: NCBE-818 se cerro de comun acuerdo por no afectar lo funcional.
4. Para futuras corridas / validaciones del banco, evitar los defectos no atribuibles asegurando:
   - Usar la firma correcta de `sp_debcred_empresa` (no la de ndc_automatica) y declarar `@o_reg_a_proc` en el exec.
   - **Ejecutar las precondiciones** de cada TC (dejan el saldo suficiente en la cuenta). Sin PRE, el debito falla con 31017/41033 "FONDOS INSUFICIENTES" — no es defecto del micro.
   - Ejecutar sobre la version/matriz vigente (no entregas anteriores).

---

## 7. Nota

Analisis basado en lectura de descripcion + comentarios de Jira (modo consulta) y verificacion tecnica contra SP/REST/gRPC y matriz oficial. No se modifico ningun estado ni campo en Jira.

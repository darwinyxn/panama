# Aprendizaje personal piloto gengis-me — ME #14: pa_pag_brpt_billetes_altadeno (NCBE-1346 → NCBE-1619)

Fecha de esta ronda: 2026-10-30. Decimocuarta entrega de la serie (procesada junto con ME #12 y
#13 en el mismo turno). No se hicieron consultas a Sybase/REST/gRPC, no se reejecutó nada, no se
modificó Jira/QMetry/motor/repos/ME.

## 1. Identidad y relación de tickets

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1346 | Story | Padre | Microservicio Reporte Dinero |
| NCBE-1611/1612/1618/1620 | Task | Pipeline (relates to) | Análisis/Consolidación/Creación/Generación de datos |
| **NCBE-1619** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — cob_pagos.pa_pag_brpt_billetes_altadeno** |
| NCBE-2866 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance |

SP: `cob_pagos.pa_pag_brpt_billetes_altadeno`. Micro: `cnb-mso-pag-reporte-billetes`. 16 TCs.
**= M5 de `BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md`**, confirmado por hash: el único JSON
adjunto a NCBE-1619 (80147 bytes, SHA-256
`957571a6809d8c81772255f1f85480922cab1eedcf1aeb26b228cb88074ffee6`) es byte-idéntico a M5.

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

3 `Defecto`:

### NCBE-1853 — "Respuesta data incorrecta" → **QA real, pero causa es contaminación de datos de prueba propia, no defecto del SP/micro**

- Reportado: TC02 devolvía un RUC donde la ME esperaba una cédula; TC04 devolvía un identificador
  claramente incorrecto. **Causa real confirmada por Gengis:** eran valores **temporales de OTROS
  TCs que quedaron aplicados en la BD tras una ejecución parcial** — la cédula de TC02 era en
  realidad el dato temporal de TC07 (valor base real: RUC `0990967946001`); el identificador largo
  de TC04 era el dato temporal del escenario controlado de TC11/TC16 (identificador forzado >19
  caracteres; valor base real: cédula `0908852155`). En la corrida que generó la ME los datos ya
  estaban restaurados y los resultados eran equivalentes — lo que faltaba era restaurar esos
  datos temporales antes de la nueva ejecución de verificación de Banco.
- **Clasificación:** QA real en el sentido de que SÍ requirió investigación y acción (restablecer
  datos), pero la causa es un ciclo de preparación/restauración incompleto entre ejecuciones
  parciales de distintos TCs — no un defecto del SP ni del microservicio. Confirma el patrón P04
  de BB_MINERIA (ciclo de preparación con ownership) con un caso concreto: datos temporales de un
  TC "bleeding" hacia la verificación de otro TC cuando no se restauran entre corridas parciales.

### NCBE-2899 — **NO ES QA — séptima recurrencia confirmada del defecto cross-platform `GrpcTlsConfigTest`**

- Mismo mecanismo exacto (rutas Unix hardcodeadas + cobertura JaCoCo) ya visto 6 veces antes en la
  serie (ME#7/#10/#11/#12 x2/#13). Esta es, hasta ahora, la recurrencia NO-QA más repetida de toda
  la serie.

### NCBE-2962 — **NO ES QA — sexta instancia del cambio cross-cutting de logging "lotes 3+"**

- Mismo fix exacto (`PresenceSerializer.java`/`PresenceModule.java`) que las 5 instancias previas
  en la serie (ME#10, #12, #13 x2).

## 3. Hallazgo principal de los bugs del padre

El único hallazgo con investigación real (NCBE-1853) confirma, con datos concretos, que la fuga de
datos temporales entre ejecuciones parciales de distintos TCs puede producir evidencia que
*parece* un defecto de datos del servicio, cuando en realidad es un problema de secuenciación de
las propias pruebas. El resto es ruido NO-QA ya catalogado extensamente en la serie.

## 4. Contraste con la ME final (NCBE-1619) — 2 particularidades genuinas del motor Sybase ASE

- **Universo:** 16 TCs, **16/16 EQUIVALENTE** (verificado, hash = M5).
- **Corrección de criterio de filtrado (TC01-04, 07-09, 13):** la validación inicial asumía que el
  SP filtraba por `ic_hora`; la revisión contra BD real mostró que filtra funcionalmente por
  **`ic_fecha`** — los datos correlacionados disponibles tienen `ic_fecha=2025-12-01`, así que se
  ajustó `@e_fecha` para alcanzar realmente las transacciones correspondientes. Es una corrección
  de interpretación del propio equipo QA sobre el comportamiento del SP, no un defecto.
- **TC05/TC10:** sin datos naturales para la rama de transacción `120062`; se agregó PRE/POST
  controlado con datos temporales correlacionados (reutilizando información maestra real,
  restaurada/eliminada al finalizar) — mismo patrón de alcanzabilidad ya visto en toda la serie.
- **TC11/TC16 — hallazgo genuino de comportamiento del motor Sybase ASE, confirma y explica a
  BB_MINERIA:** ambos casos buscaban validar el comportamiento ante un identificador de
  beneficiario más largo de lo soportado por el reporte, esperando un **error**. La investigación
  real mostró que **Sybase ASE no genera ningún error ante esa condición — realiza truncamiento
  silencioso**. Esto es exactamente lo que `BB_MINERIA_COMPARATIVA_9_ME` ya había observado para
  M5 ("salida de identificación truncada a 19 caracteres") sin poder explicar la causa; aquí se
  confirma la causa real con el ticket detrás: no es una decisión del SP de negocio, es el
  comportamiento nativo de truncamiento silencioso de Sybase ASE ante un `varchar`/`char` que
  excede su longitud declarada. Los casos se ajustaron con un dataset controlado de 25 caracteres
  para alcanzar realmente la condición de truncamiento, y ambos validaron EQUIVALENTE una vez
  alcanzada la ruta correcta.

## 5. Patrones de esta ronda

No se proponen patrones nuevos — esta ronda aporta **confirmaciones** valiosas:

- **Confirma P04 de BB_MINERIA** (ciclo de preparación/ownership) con un caso concreto de fuga de
  datos temporales entre TCs no restaurados entre ejecuciones parciales (NCBE-1853).
- **Cierra una pregunta abierta de BB_MINERIA para M5:** la causa real del truncamiento de
  identificación a 19 caracteres en TC11/TC16 es el comportamiento nativo de truncamiento silencioso
  de Sybase ASE ante longitud excedida — no una regla de negocio del SP. Útil como conocimiento
  reusable: cualquier TC que intente forzar un error por longitud de campo en Sybase ASE debe
  verificar primero si el motor trunca en silencio en vez de fallar.
- Séptima y sexta recurrencias respectivamente de los 2 ruidos NO-QA más repetidos de la serie
  (`GrpcTlsConfigTest` cross-platform; logging `Presence<T>` "lotes 3+").

## 6. Lo que no se pudo verificar / queda pendiente

- No se verificó el valor exacto de truncamiento (19 caracteres, según BB_MINERIA) directamente en
  el JSON de esta ronda — se acepta la cifra ya documentada en la minería dado que el hash del
  archivo es idéntico.
- `report_sp_structure_templateV2.html` y `reporte_billetes.proto` (adjuntos a NCBE-1619) no se
  inspeccionaron en detalle.

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1346 (campos + 10 subtareas + 6 issuelinks); NCBE-1619
  (campos + 3 adjuntos + 1 comentario); NCBE-1853/2899/2962 (campos + comentarios completos).
- **Verificación de hash:** adjunto único de NCBE-1619 descargado temporalmente a `/tmp` (nunca al
  repo), hash y veredictos verificados (16/16 EQUIVALENTE), confirmado idéntico a M5 de
  `BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md`. Borrado tras el uso.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #14** de la serie (procesada junto con #12 y #13 en el mismo turno). Ver índice
  `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`.

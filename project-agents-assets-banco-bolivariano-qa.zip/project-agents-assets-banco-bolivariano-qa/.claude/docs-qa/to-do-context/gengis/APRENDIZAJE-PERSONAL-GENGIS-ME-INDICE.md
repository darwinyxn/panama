# Índice — aprendizaje personal piloto gengis-me (serie "una ME a la vez")

Cada entrada = una ronda de reconstrucción (ticket padre + bugs enlazados) contrastada contra la ME
final de una HU puntual. No reabre ni modifica MEs cerradas, QMetry ni Jira; solo lectura y síntesis
documental. Formato de entrada: `Padre → HU | SP | fecha ronda | archivo | 1 línea de hallazgo`.

| Padre → HU | SP | Fecha ronda | Archivo | Hallazgo principal |
| --- | --- | --- | --- | --- |
| NCBE-1105 → NCBE-1117 | pa_fir_consulta_firmante | 2026-10-30 | `NCBE-1105-NCBE-1117-pa_fir_consulta_firmante-ME01.md` | 0 bugs de equivalencia enlazados al padre (los 6 "Defecto" son arquitectura/SonarQube/Prisma, todos NO-QA); confirma P02/C02 de BB_MINERIA con el `binary-comparison` ya piloteado en PASS |
| NCBE-1109 → NCBE-1126 | sp_ah_retiro_rc | 2026-10-30 | `NCBE-1109-NCBE-1126-sp_ah_retiro_rc-ME02.md` | 0 bugs de equivalencia enlazados al padre (3 "Defecto" arquitectura/SonarQube/Prisma, mismos patrones que ME#1 en otro SP); TC09 o_ssn SP/REST +1 verificado (campo secuencial, no defecto); ~19 Defectos de texto similar pertenecen a otro padre (Librería), confirmado por `parent` y descartado |
| NCBE-1174 → NCBE-1263 | pa_fir_consulta_con_especial | 2026-10-30 | `NCBE-1174-NCBE-1263-pa_fir_consulta_con_especial-ME03.md` | 0 bugs de equivalencia enlazados al padre; único Defecto (NCBE-4357, dependencias de librería) es ~2 meses POSTERIOR al cierre de la ME; TC09 "fecha límite" devuelve "No existe cuenta" — confirma P11 (rama del título nunca ejercida) con evidencia nueva |
| NCBE-1175 → NCBE-1264 | pa_fir_consulta_condicion | 2026-10-30 | `NCBE-1175-NCBE-1264-pa_fir_consulta_condicion-ME04.md` | PRIMER padre con bugs de QA reales (NCBE-1637 URL localhost, NCBE-1644 decimales money, ambos reportados por Banco en la propia revisión); el JSON/.proto realmente final quedó adjunto al bug hijo NCBE-1644, nunca re-subido a la HU de revisión NCBE-1264; evidencia nueva sobre ambigüedad QMetry TR-14/TR-15 |
| NCBE-1176 → NCBE-1250 | pa_fir_consulta_fir_especial | 2026-10-30 | `NCBE-1176-NCBE-1250-pa_fir_consulta_fir_especial-ME05.md` | 0 bugs de equivalencia; NCBE-1250 tiene un JSON adjunto que es byte-idéntico a M7 (otro SP), error favorecido por título de Story idéntico a NCBE-1174; NCBE-4465 duplica literalmente el fix de NCBE-4363 (ME#4) bajo el padre equivocado; NCBE-4466 revela regresión de CI/CD compartida (workflow ref v2-alpha→main) en 2 micros hermanos; mismo patrón Firma HEX/Base64 de M7 confirmado en este SP |
| NCBE-1177 → NCBE-1705 | sp_ah_retirosl_rc | 2026-10-30 | `NCBE-1177-NCBE-1705-sp_ah_retirosl_rc-ME06.md` | PRIMERA ME de la serie que NO cierra 100% EQUIVALENTE (21 EQ/1 INC/3 NO_EQ, 4 pendientes de Banco, documentados); NCBE-2214 empezó como nota administrativa y destapó un HTTP 200 enmascarando un fallo técnico real en librería compartida (routecore-cobis); segundo caso EXPLÍCITO de adjunto de otro SP en la propia HU (reconocido por los autores); 2 bugs reales del motor QA ya corregidos y regresionados (commit aec64a8, verificado) |
| NCBE-1169 → NCBE-1649 | sp_cnb_consulta_saldo | 2026-10-30 | `NCBE-1169-NCBE-1649-sp_cnb_consulta_saldo-ME07.md` | 2 bugs QA reales confirmados (NCBE-2188 IVA no contabilizado, NCBE-2717 error 500→33005) + 2 falsos positivos bien distinguidos (NCBE-1609, NCBE-1948); 31/31 EQUIVALENTE al cierre pero 2 defectos reales aparecieron DESPUÉS, fuera del universo de TCs; cruce con memoria propia revela un defecto real corregido que NUNCA se filed como Defecto en Jira (límite metodológico de la serie) |
| NCBE-1178 → NCBE-1265 | sp_retefec_transval_rc | 2026-10-30 | `NCBE-1178-NCBE-1265-sp_retefec_transval_rc-ME08.md` | La ronda más intensa de la serie: 11 Defecto reales (sin ruido NO-QA), todos de presentación/captura/reproducibilidad de la propia ME (nunca divergencia funcional real); confirma que el patrón P07 (tipo wire oComision) y el "capturador de mensajería trunca" nacen exactamente de NCBE-2991/2994 y NCBE-2975; 43/43 EQUIVALENTE confirmado = M1 de BB_MINERIA por hash; NCBE-3293 revela regresión entre entregas sucesivas de la misma ME (PR26) |
| NCBE-1380 → NCBE-1499 | sp_tr_deposito_rc | 2026-10-30 | `NCBE-1380-NCBE-1499-sp_tr_deposito_rc-ME09.md` | SP de la sesión que originó el incidente de inmutabilidad del CLAUDE.md del repo (22-sep); 12 bugs reales (8 Defecto + 4 Epic), casi todos QA real; mismo defecto de librería compartida (AbstractCobisAdapter/sp_return) que NCBE-2214 (ME#6) reaparece aquí, diagnosticado independientemente (PR28); 2 instancias confirmadas de datos internos QA filtrándose a la evidencia (engine_exception, "cupos": [] — este último sin confirmar removido antes del cierre) (PR29) |
| NCBE-1340 → NCBE-1518 | pa_cc_cval_catcctecnb | 2026-10-30 | `NCBE-1340-NCBE-1518-pa_cc_cval_catcctecnb-ME10.md` | Ronda liviana (4 Defecto, M9 de BB_MINERIA confirmado por hash, 6/6 EQUIVALENTE); tercera confirmación de PR29 (mensaje_debug/engine_exception interno filtrado, con etiqueta propia de "diagnóstico interno" en el código); tercera recurrencia del defecto cross-platform GrpcTlsConfigTest (ME#7); TC05 requirió ventana DBA para forzar falla de dependencia compartida cobis..sp_error, documentado explícitamente como no-defecto |
| NCBE-1343 → NCBE-1528 | pa_cp_cval_ctacnb | 2026-10-30 | `NCBE-1343-NCBE-1528-pa_cp_cval_ctacnb-ME11.md` | M8 de BB_MINERIA confirmado por hash (31 EQ + 3 NOT_APPLICABLE); NCBE-1768 (21-ago) es el origen cronológico más temprano de PR29 encontrado, con ubicación de código citada ("renderer de la matriz") — el fix no se propagó al motor compartido, reapareció 2 veces después; NCBE-2204 es la 4ª recurrencia del defecto cross-platform GrpcTlsConfigTest; NCBE-1770/TC33 corrobora con ticket real el hallazgo que BB_MINERIA solo había inferido del JSON |
| NCBE-1344 → NCBE-1580 | pa_pag_bconcilia_cnb_imix | 2026-10-30 | `NCBE-1344-NCBE-1580-pa_pag_bconcilia_cnb_imix-ME12.md` | M6 de BB_MINERIA confirmado por hash (45/45 EQ); NCBE-2044/TC43 destapa tabla de trabajo global sin aislamiento de sesión (rec_tmp_concilia_cnb) dando resultados inconsistentes bajo concurrencia, resuelto en ventana controlada (PR30); Banco decide explícitamente "no corregir el SP" para TC21 (Msg 249 antes de RETURN); confirma P09 con pedido real de Banco de ver registros, no solo digests |
| NCBE-1345 → NCBE-1595 | pa_pag_bcubo_cnb | 2026-10-30 | `NCBE-1345-NCBE-1595-pa_pag_bcubo_cnb-ME13.md` | SP sin precedente en BB_MINERIA; 0 bugs QA en el padre (2 Defecto, ambos recurrencias NO-QA); TC52/TC53 quedan NO_EQUIVALENTE en el JSON final por una divergencia INTENCIONAL y autorizada por Seguridad (NCBE-2008) — no se fuerza a EQUIVALENTE (PR31); clasificación extensa de 9 TCs "veneno no reproducible", 1 mismatch de error documentado, 1 limitación de motor QA ya aceptada |
| NCBE-1346 → NCBE-1619 | pa_pag_brpt_billetes_altadeno | 2026-10-30 | `NCBE-1346-NCBE-1619-pa_pag_brpt_billetes_altadeno-ME14.md` | M5 de BB_MINERIA confirmado por hash (16/16 EQ); NCBE-1853 confirma P04 con fuga real de datos temporales entre TCs no restaurados entre ejecuciones parciales; TC11/TC16 cierran una pregunta abierta de BB_MINERIA — el truncamiento a 19 caracteres es comportamiento NATIVO silencioso de Sybase ASE ante longitud excedida, no regla de negocio; 7ª y 6ª recurrencias de los 2 ruidos NO-QA más repetidos de la serie |
| NCBE-1777 → NCBE-1839 | sp_tr_pago_giro_rc | 2026-11-01 | `NCBE-1777-NCBE-1839-sp_tr_pago_giro_rc-ME15.md` | La ronda más extensa de la serie: 34 Defecto reales, 20 versiones de ME en 25 días; sección DICCIONARIO dedicada (o_msg saneado por seguridad NCBE-2335, espacio=vacío en o_mensaje1-3, money comparado por valor decimal con criterio heredado de OTRO SP/lote NCBE-4272, mapeo o_msg/mensajeDebug depende de i_cobis); PR29 con su instancia más grande (85/105 tarjetas, columnas datalength() filtradas); 2 patrones nuevos (PR32 PRE/POST sin "go" entre lotes, PR33 recurso compartido con marca de restauración pendiente); 102 EQ + 3 NOT_APLICABLE confirmado por hash |
| NCBE-1804 → NCBE-2034 | sp_pago_giro | 2026-11-01 | `NCBE-1804-NCBE-2034-sp_pago_giro-ME16.md` | 2 defectos reales de código (fuga de conexión del pool, mensaje distinto vía sp_ccndc_automatica); regla exacta de enmascaramiento al 50% de caracteres del nombre del SP; semántica NULL distinta entre REST (null explícito) y gRPC (campo omitido) para parámetros opcionales; confirma PR26 (regresión PRE/EXEC/POST entre versiones); 31/31 EQ confirmado |
| NCBE-1805 → NCBE-3558 | sp_verificacion_acredita | 2026-11-01 | `NCBE-1805-NCBE-3558-sp_verificacion_acredita-ME17.md` | SP de 200 TCs, el universo más grande de la serie; NCBE-3558 es un Sub-task de la tarea formal de revisión (NCBE-1995, con adjuntos obsoletos) donde vive el artefacto REAL vigente — instancia institucionalizada del patrón "el adjunto vigente no está en la tarea formal"; NCBE-4469 confirma "nunca asumir ANSI NULL en Sybase" citando el mecanismo ansinull explícito; NCBE-4506 es el caso más grande de contaminación de datos entre corridas (22 TCs, separación accidental/deliberado con autorización previa de Banco); NCBE-4484 revela expectativas desactualizadas en el documento de Banco; 200/200 EQ confirmado |
| NCBE-1815 → NCBE-2027 | sp_direccion_dml | 2026-11-01 | `NCBE-1815-NCBE-2027-sp_direccion_dml-ME18.md` | 7 de 16 Defecto comparten un solo root cause (no recrear fixture entre canales) — la confirmación más grande de P04 en la serie; gRPC/protobuf no tiene null para campos repeated, solo vacío; confirma PR29 (mensaje_debug_raw) con reconocimiento explícito del autor; 77/77 EQ confirmado, sin gap de vigencia |
| NCBE-1820 → NCBE-3599 | sp_proc_giros | 2026-11-01 | `NCBE-1820-NCBE-3599-sp_proc_giros-ME19.md` | NCBE-3599 es Sub-task de la tarea formal NCBE-1875 (mismo patrón ME#17); 7 de 11 Defecto son defectos reales de código confirmados, incluido uno sistémico de atomicidad transaccional en 5 puntos (NCBE-4731, destapado por una pregunta de diligencia adicional); el único JSON existente (44/44 EQ, 14-oct) es ANTERIOR a 7 de esos defectos — agrava PR23 con el caso más concreto de la serie (0 adjuntos posteriores en ningún ticket) |
| NCBE-2046 → NCBE-3603 | pa_caj_tconsal_notd | 2026-11-01 | `NCBE-2046-NCBE-3603-pa_caj_tconsal_notd-ME20.md` | Solo 1 Defecto en el padre (confirma el criterio transversal de money NCBE-4272, mismo correo citado por tercera vez en la serie); refuerza fuertemente PR24 — memoria propia revela 3 fixes locales del motor del micro que nunca generaron Defecto en Jira; 49/49 EQ confirmado |
| NCBE-2801 → NCBE-3631 | pa_cash_gconsultamovimien (Lote 9) | 2026-11-05 | `NCBE-2801-NCBE-3631-pa_cash_gconsultamovimien-ME21.md` | 9 Defecto de Banco + impedimento TC06 (NCBE-4725, error del documento de casos, NULL Sybase); 1 defecto real del micro (NCBE-4919, `mensajeDebug` duplicado en la librería, corregido por Migración); 4 de representación QA (montos REST, result set SP, espacio vs NULL — este último corregido también en el motor central `3bbb8cc5`); 2 de datos dinámicos de cuentas reales que exigieron recaptura (Banco aceptó deriva residual de 3 registros); 1 regla de contrato vigente solo desde Lote 10 (NCBE-4770); 1 no demostrado; 6 versiones en 4 días, 34/34 EQ en todas, final verificado por hash; PR34–PR40 |

Patrones nuevos acumulados (para no reproponer los mismos en rondas futuras):
- **PR01** (NCBE-1105): un "Defecto" enlazado a un padre no es automáticamente un hallazgo de
  equivalencia QA — verificar asignado/contenido/referencia a TC antes de profundizar.
- **PR02** (NCBE-1105): defecto de desarrollo ya cerrado, sin tocar comportamiento SP↔microservicio,
  no se convierte en alerta activa de la ME.
- **PR03** (NCBE-1105): confirma P02/C02 de `BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md` con mecanismo
  ya piloteado (`binary-comparison`, PASS 2026-10-05).
- **PR04** (NCBE-1105): la HU formal de una ME se corrobora con evidencia (hash + Jira), no se asume
  por contexto previo.
- **PR06** (NCBE-1109): campos de secuencia/autoincremento (ssn/ticket/consecutivo) no se comparan
  por igualdad estricta entre canales ejecutados en momentos distintos — un desfase pequeño y
  consistente con el orden de ejecución es esperado, no un defecto (evidencia real: TC09).
- **PR07** (NCBE-1109): una búsqueda de texto amplia en Jira trae ruido de otros padres — confirmar
  siempre el campo `parent` real antes de tratar un resultado como enlazado al padre en revisión.
- **PR08** (NCBE-1105/NCBE-1109): el par "clase en capa equivocada + librería reutilizable
  desactualizada" (arquitectura hexagonal) y los defectos colaterales de SonarQube/Prisma
  (mismo `java:S1192`, mismo `commons-logging`/`spring-jcl`, mismas versiones CVE) se repiten casi
  idénticos entre microservicios `cpas-mso-*` distintos — sugiere plantilla base compartida; sigue
  siendo NO-QA, útil solo para anticipar el mismo hallazgo en próximos padres de la serie.
- **PR09** (NCBE-1174): comparar siempre `created`/`resolutiondate` de un bug contra la fecha de
  cierre de la ME antes de tratar su ausencia en ella como un gap — un bug posterior al cierre no
  podía reflejarse (evidencia: NCBE-4357, ~2 meses después de NCBE-1263).
- **PR10** (NCBE-1174): un veredicto EQUIVALENTE por TC certifica coincidencia entre canales, no que
  se ejerció la rama que el título del TC promete — confirma P11 de BB_MINERIA con evidencia nueva
  (TC09 "fecha límite" devuelve "No existe cuenta"; sin el documento Banco original no se puede
  distinguir intención vs. deriva de datos).
- **PR11** (NCBE-1175): el artefacto final de una ME puede quedar adjunto al ticket del BUG hijo, no
  al ticket de revisión (HU) — comparar fechas de adjuntos entre la HU y sus bugs antes de asumir
  que el más reciente está en la HU (evidencia: NCBE-1264 vs NCBE-1644).
- **PR12** (NCBE-1175): un defecto de URL puede quedar corregido a nivel de comando reproducible por
  TC sin corregirse a nivel de metadata de cabecera (`base_url`/`grpc_host`) — revisar ambos niveles.
- **PR13** (NCBE-1175): no tratar una respuesta intermedia de Banco sobre un criterio de
  representación como el contrato definitivo hasta que haya confirmación formal explícita.
- **PR14** (NCBE-1175): verificar que el contenido de una subtarea realmente corresponda a su padre
  declarado antes de usarla como evidencia de ese SP (evidencia: NCBE-4499 archivada en NCBE-1175
  pero habla de otro microservicio).
- **PR15** (NCBE-1175): un fix puntual de ME no implica un fix del motor compartido — revisar el
  registro consolidado (`MOTOR-QA_fixes_sesion_agosto2026.md`) antes de asumir que el mismo síntoma
  en un SP hermano ya está cubierto.
- **PR16** (NCBE-1176): un adjunto de una HU de revisión puede ser de un SP COMPLETAMENTE DISTINTO
  (no solo una versión vieja del mismo SP) — abrir `metadata.sp_objetivo` de cada JSON adjunto antes
  de usarlo; más probable cuando hay Stories hermanas con título idéntico o casi idéntico.
- **PR17** (NCBE-1176): un cambio de referencia de pipeline CI/CD compartido (ej. tag de workflow
  `@v2-alpha`→`@main`) puede romper el deploy de varios micros hermanos a la vez sin error visible —
  extiende PR08 de plantilla de código a plantilla de infraestructura/CI-CD.
- **PR20** (NCBE-1177): una "Novedad de dependencia" administrativa puede esconder un defecto
  funcional real (ej. HTTP 200 enmascarando un fallo técnico) — leer el hilo completo de
  comentarios antes de descartar un ticket como NO-QA solo por su título inicial.
- **PR21** (NCBE-1177): un fix de motor ya confirmado y regresionado (verificar en `git log`) no se
  reabre como alerta — revisar si ya hay un commit posterior a la corrida que explique el síntoma.
- **PR22** (NCBE-1177): dos hilos de investigación independientes (Jira y documento local) pueden
  converger en la misma causa raíz de driver/conexión sin citarse entre sí — buscar coincidencias de
  síntoma (`01S\d+`, OUTPUT perdido, HTTP 200 con datos null) antes de tratarlos como hallazgos
  aislados.
- **PR23** (NCBE-1169): N/N EQUIVALENTE no garantiza ausencia de defectos reales fuera del universo
  de TCs original — buscar bugs creados DESPUÉS de la fecha de cierre de la ME bajo el mismo padre.
- **PR24** (NCBE-1169): la reconstrucción basada solo en Jira tiene un límite real — no todo bug
  confirmado pasa por un "Defecto" formal; cruzar SIEMPRE contra memoria propia/documentación local
  de la sesión de cierre si existe, antes de concluir "no hubo más bugs reales".
- **PR25** (NCBE-1169): un fix de motor que resuelve una colisión de datos para las corridas propias
  de QA no protege las pruebas manuales independientes de Banco sobre el mismo ambiente — mismo
  síntoma reaparecido puede ser dato de prueba reusado, no regresión nueva.
- **PR26** (NCBE-1178): regenerar la ME en rondas iterativas puede regresionar fixes ya aplicados en
  una entrega anterior — diferenciar la nueva versión contra la anterior, no solo contra el
  documento Banco, antes de publicarla.
- **PR27** (NCBE-1178): el capturador de la ME puede truncar mensajería múltiple de Sybase
  (2+ mensajes en una ejecución), aparentando una divergencia de mensaje que no existe en el micro —
  verificar si el SP emite más de un mensaje antes de reportar "pérdida" de mensaje como defecto del
  micro (confirma y precisa P03 de BB_MINERIA).
- **PR28** (NCBE-1380): el defecto de `AbstractCobisAdapter` leyendo solo el primer resultset y
  perdiendo `sp_return` (ya visto en NCBE-2214/ME#6) puede reaparecer en otro microservicio que use
  la misma librería "bifurcadora" — tratarlo como instancia conocida de una clase de defecto, no
  como hallazgo aislado; verificar versión de librería consumida antes de re-diagnosticar.
- **PR29** (NCBE-1380): datos internos del propio proceso QA (diagnóstico, fixture, backup de
  catálogo) pueden filtrarse hacia la evidencia/respuesta que ve Banco pareciendo campos reales del
  servicio — revisar que cada campo de la respuesta tenga correspondencia real con el SP/DTO/proto
  antes de publicar la ME.
- **PR30** (NCBE-1344): una tabla de trabajo global sin aislamiento por sesión (TRUNCATE+carga+
  lectura total) puede dar resultados inconsistentes bajo ejecución concurrente sin ser defecto del
  micro — reejecutar en ventana sin actividad concurrente antes de reportarlo como tal.
- **PR31** (NCBE-1345): una divergencia SP↔micro intencional y autorizada (ej. hardening de
  Seguridad) se documenta como NO_EQUIVALENTE real, nunca se fuerza a EQUIVALENTE — el veredicto
  técnico queda fiel a la comparación, la autorización se documenta aparte.
- **PR32** (NCBE-1777): concatenar los PRE/POST de varios canales en un solo bloque sin separador
  de lote (`go` en Sybase) rompe la compilación por variables redeclaradas — cada bloque necesita
  su propio separador si se van a ejecutar juntos.
- **PR33** (NCBE-1777): un recurso QA compartido entre canales (caja, parámetro de catálogo)
  necesita una marca de restauración rastreable (no solo un ciclo PRE/POST simple) para no bloquear
  casos futuros ni perder ownership entre canales.
- **PR34** (NCBE-2801/4733): un precedente de criterio aplica solo si coincide en el lugar exacto
  del dato — NCBE-4272 (money en OUTPUT, lado SP con 4 decimales aceptado) y NCBE-4686 (money dentro
  de un result set, ME corregida) responden distinto a "ceros a la derecha".
- **PR35** (NCBE-2801/4919): un campo marcado "IGNORAR" en el diccionario es decisión de QA, no
  evidencia de equivalencia; contrastado contra un micro hermano puede destapar una inconsistencia
  real de contrato (aquí, una línea de la librería) — leer el código que produce el campo antes de
  justificar.
- **PR36** (NCBE-2801/4915/4936): casos sobre cuentas reales con `GETDATE()` o "últimos N" no se
  reproducen contra una foto vieja; Banco pidió captura nueva coherente entre canales y aceptó deriva
  residual explicada por la misma cuenta usada en pruebas de otros lotes (extiende PR06/PR25).
- **PR37** (NCBE-2801/4807→4878): reconstruir una representación desde valores ya guardados en la
  ME arrastra los errores del lector que los produjo — reconstruir siempre desde la evidencia cruda
  (relacionado con PR26).
- **PR38** (NCBE-2801): los comentarios a Banco solo deben citar artefactos que Banco tiene; un
  documento interno de observaciones no entregado se reemplaza por una nota adjunta por ticket.
- **PR39** (NCBE-2801/3631): sin permiso de borrar adjuntos, cada versión deja otro JSON con el
  mismo nombre; el visor carga el archivo con ese nombre exacto de su carpeta y Banco puede abrir
  uno viejo — identificar el vigente por id, fecha y tamaño (extiende PR11).
- **PR40** (NCBE-2801/4770): una convención de contrato puede regir por lote (camelCase en columnas
  de result set desde Lote 10); confirmar desde qué lote aplica antes de clasificar el hallazgo.
- **PR41** (NCBE-2092/NCBE-5556, TC32): una diferencia de texto exclusivamente ortográfica o de
  codificación puede aceptarse si conserva el significado y Banco la acepta formalmente; no es
  motivo automático de impedimento. Caso: el SP REF 20 guarda `NO EXISTE TRANSACCIÃ\x93N ORIGINAL`
  (bytes UTF-8 `C3 93` compilados en un servidor `iso_1`) y el micro devuelve `NO EXISTE TRANSACCIÓN
  ORIGINAL`, con el mismo código 18122 en los 3 canales. Banco (comentario 214978, 05-11-2026)
  aceptó que el micro muestre el texto correcto. Se registra como **diferencia aceptada**, no como
  igualdad literal (PR31). Aplica solo al campo y al caso aceptados (PR34). No cubre otras
  diferencias del mismo TC: el `mensajeDebug` de TC32 sigue no equivalente en NCBE-5623. Tampoco es
  autorización general para ignorar diferencias de texto.

**DICCIONARIO — catálogo acumulado (NCBE-1777/ME#15, ver sección 4 de ese documento para detalle):**
`o_msg` se compara por mensaje funcional tras saneamiento de seguridad, no literal (NCBE-2335);
espacio-longitud-1 y `""` son el mismo vacío en Sybase para campos `varchar` asignados vacíos;
valores `money` se comparan por valor decimal, nunca por representación textual — criterio
transversal fijado por Banco en NCBE-4272 (13-oct, otro lote) y citable para cualquier SP nuevo;
qué campo lleva el mensaje (`o_msg` vs `mensajeDebug`) depende de parámetros de negocio como
`i_cobis`, no es un mapeo fijo 1:1.

**DICCIONARIO — agregado por NCBE-2801/ME#21 (ver sección 5 de ese documento):** money del result
set SP como número según el tipo del SP (precedente NCBE-4686, distinto del de OUTPUT); el espacio
que Sybase guarda para `varchar ''` se conserva en result sets y solo `NULL` es `null` (motor
`3bbb8cc5`); `mensajeDebug` en `null` cuando el SP no emite mensaje nativo (corrección de librería
NCBE-4919, coherente con el ejemplo de `tr_pago_giro_rc` — dos SP, no regla escrita de Migración);
result set vacío como `[]` explícito; columnas del result set con alias snake_case hasta Lote 9,
camelCase desde Lote 10 (decisión de Banco por correo, no verificada en sesión).

**DICCIONARIO — agregado por NCBE-2092/NCBE-5556 (TC32, `pa_pg_tpag_reca_varios`, sin ME cerrada
todavía):** un mensaje de dominio (`s_mensaje_respuesta`) con un error ortográfico o de codificación
en el SP, que el micro muestra corregido, se acepta si conserva el significado y el código de
retorno es igual en los 3 canales. Banco lo decidió por escrito en NCBE-5556, comentario 214978:
*"debido que el sp ya presenta el mensaje con ese error ortográfico. Se acepta que el micro lo
muestre correctamente ya que se solicitó que este tipo de casos se corrijan"*.

Cómo aplicarlo:
- En la ME se documenta como diferencia aceptada, citando el ticket.
- El motor compartido no tiene tolerancia de codificación, así que no se "normaliza" el texto para
  forzar la igualdad.
- Ante un caso nuevo se cita este precedente en la ME, sin abrir un impedimento automáticamente.
  Solo se escala si cambia el significado o si el campo es otro (PR34).
- Distinto de NCBE-2335, que trata un saneamiento de seguridad del prefijo `[sp]` en `o_msg`, no
  una corrección ortográfica.
- No aplica a `mensajeDebug`: en este mismo TC sigue pendiente en NCBE-5623 (librería 1.0.11, mismo
  patrón que NCBE-4919).

# Aprendizaje personal piloto gengis-me — ME #12: pa_pag_bconcilia_cnb_imix (NCBE-1344 → NCBE-1580)

Fecha de esta ronda: 2026-10-30. Duodécima entrega de la serie (procesada junto con ME #13 y #14
en el mismo turno, mismo alcance y criterio). No se hicieron consultas a Sybase/REST/gRPC, no se
reejecutó nada, no se modificó Jira/QMetry/motor/repos/ME.

## 1. Identidad y relación de tickets

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1344 | Story | Padre | Conciliación IMIX Banco |
| NCBE-1574/1575/1576/1578 | Task | Pipeline (relates to) | Análisis/Consolidación/Creación/Generación de datos |
| **NCBE-1580** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — cob_pagos.pa_pag_bconcilia_cnb_imix** |
| NCBE-2865 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance |

SP: `cob_pagos.pa_pag_bconcilia_cnb_imix`. Micro: `cnb-mso-concilia-cnb-imix`. 45 TCs. **= M6 de
`BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md`**, confirmado por hash: el último JSON adjunto a
NCBE-1580 (10-sep, 26584861 bytes, SHA-256 `ed51209a89a1a85cfa3798cf50a85cd1df8ec01d216d8e9afc7568bc96217a2d`)
es byte-idéntico a M6.

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

6 `Defecto` con contenido real (el resto, `Sub-task` de checklist).

### NCBE-2044 — "Novedad en respuesta de casos" → **QA real, destapó una condición de carrera genuina del SP (TC43) y motivó una mejora de evidencia**

- Banco reportó formato/datos distintos entre ME y ejecución real. Al investigar, Gengis encontró
  algo más importante: el SP usa `db_general..rec_tmp_concilia_cnb` como **tabla de trabajo
  global** — en cada ejecución hace `TRUNCATE`, carga, y lee TODO el contenido, **sin aislamiento
  por sesión ni filtro por ejecución**. Bajo actividad concurrente, TC43 dio resultados
  inconsistentes entre corridas (SP 5290/REST 6561/gRPC 5290; luego 5290/9180/5290) con filas
  duplicadas en REST. En una ventana sin actividad concurrente, 2 corridas dieron 5290/5290/5290
  estables; en una tercera corrida con la misma entrada, el propio SP retornó código `1`
  ("Error en la informacion Servicio Tarjeta") — comportamiento real del SP bajo contención, no un
  defecto del microservicio.
- **Mejora de evidencia (pedido explícito de Banco, Danny Ríos):** la ME solo mostraba "filas
  compactadas/totales/SHA-256", insuficiente para validar registros/tipos/valores reales. Gengis
  ajustó la generación de la ME para incluir una muestra de registros reales de SP/REST/gRPC,
  conservando también el total y la evidencia completa — confirma con un caso concreto el patrón
  P09/C08 de BB_MINERIA (evidencia masiva sin perder completitud).
- **Resolución final:** reejecutando TC43 en ventana controlada sin concurrencia: SP=REST=gRPC=5290,
  0 duplicados, 0 diferencias de contenido. Regresión completa de 45 TCs: **45/45 EQUIVALENTE**.
- **Clasificación:** QA real — particularidad genuina del SP (tabla de trabajo global sin
  aislamiento), no defecto del microservicio. Ver PR30.

### NCBE-2205 — "Resultado Obtenido" (TC22) → **QA real, resuelto sin detalle adicional documentado**

- 1 comentario de cierre ("se valida el caso TC22 y responde como debe"); sin detalle de causa en
  el ticket. Consistente con el mecanismo de constraint temporal usado para TC22 según el informe
  de NCBE-1580 (sección 4).

### NCBE-2301 — **NO ES QA — quinta recurrencia confirmada del defecto cross-platform `GrpcTlsConfigTest`**

- Mismo patrón exacto (rutas Unix hardcodeadas rompiendo Windows + cobertura JaCoCo) ya visto en
  NCBE-2193 (ME#7), NCBE-2203 (ME#10), NCBE-2204 (ME#11). Quinta instancia, mismo tipo de solución.

### NCBE-2403 — "Novedad prueba de microservicio" → **Falso positivo (uso incorrecto de la prueba por Banco)**

- Error HTTP 400 al enviar `/` en el campo fecha y a una ruta incorrecta (`/conciliar` de más). El
  control de sanitización de entrada (seguridad) rechaza correctamente caracteres no permitidos; el
  formato correcto es ISO 8601 sin `/` y la ruta real es `POST /api/v1/conciliaciones/cnb-imix`.
  Confirmado sin cambio de código.

### NCBE-2908 — "Novedad de login failed microservicio" → **NO ES QA (infra/ops — credencial cacheada en memoria tras rotación)**

- El pod llevaba varios días arriba y mantenía en memoria la contraseña anterior a una rotación;
  al necesitar conexiones nuevas durante una ráfaga de pruebas, Sybase rechazaba la credencial
  vieja (`JZ00L`). Resuelto reiniciando el despliegue (reconstruye el pool con la credencial
  vigente del ConfigMap/framework). No es defecto de código.

### NCBE-2954 — "No se visualiza en el log los parámetros de request" → **NO ES QA (logging, mismo cambio cross-cutting "lotes 3+" ya visto en ME#10)**

- Mismo fix exacto (`PresenceSerializer.java`/`PresenceModule.java`) que NCBE-2952 (ME#10),
  NCBE-2961 (ME#13, ver abajo) y NCBE-2962 (ME#14, ver abajo) — la misma iniciativa transversal
  aplicada repo por repo.

## 3. Hallazgo principal de los bugs del padre

El único hallazgo con sustancia QA real (NCBE-2044) resultó ser una particularidad de concurrencia
genuina del SP (tabla de trabajo global sin aislamiento), no un defecto del microservicio — y
generó además una mejora real y verificable en la calidad de la evidencia de la ME. El resto es
ruido NO-QA ya catalogado (cross-platform, falsos positivos de formato de request, credencial
cacheada).

## 4. Contraste con la ME final (NCBE-1580) — alcanzabilidad extensa y una decisión de "no tocar el SP"

- **Universo:** 45 TCs, **45/45 EQUIVALENTE** (verificado, hash = M6).
- **Análisis inicial de alcanzabilidad (20-ago, Nicolas Rodríguez):** de 45 TCs, solo 15 eran
  ejecutables/verificables directamente contra datos reales; 28 quedaban `NOT_APPLICABLE` + 2
  `PENDIENTE` porque el ambiente no tenía filas reales que ejercieran el escenario — por 2 causas
  concretas: (a) 6 TCs necesitaban una transacción real ejecutada por un usuario del catálogo
  `cc_usuario_cnb` (CNB002-007) y las filas reales disponibles usaban otros usuarios; (b) 3 TCs de
  rama histórica necesitaban una transacción `*_his` con usuario confirmado en catálogo. Jean Oscar
  Larreategui aclaró que varios de esos TCs (TC05-TC30) usan deliberadamente datos no reales — su
  función es validar el comportamiento cuando el dato NO existe en el catálogo CNB, no un gap.
- **2 comportamientos reales del SP que Banco decidió explícitamente NO corregir:** al resolver los
  últimos NOT_APPLICABLE con datos sintéticos reversibles, aparecieron 2 defectos de diseño del
  propio SP/COBIS (no del microservicio): TC21 esperaba `RETURN 300003377` ante un código de
  catálogo no numérico, pero Sybase aborta con `Msg 249` durante el `convert(int, codigo)` **antes**
  de alcanzar ese `RETURN` — el código documentado es, en los hechos, inalcanzable por esa ruta.
  Jean Oscar Larreategui confirmó explícitamente: **"mantener la misma lógica del SP... no se debe
  cambiar ni mejorar el SP... se debe aceptar el comportamiento actual"** — aplicación directa de la
  regla "SP es la fuente de verdad" ya catalogada en memoria propia. El caso se ajustó para validar
  la excepción nativa real, y el microservicio quedó alineado representando el mismo fallo (HTTP 500
  / gRPC INTERNAL, sin código de negocio).
- **Mecanismos de alcanzabilidad documentados explícitamente por categoría** (informe de Nicolas,
  27-ago): siembra sintética reversible en tablas fuente (TC09/39/40), siembra en catálogo
  (TC21), `CHECK` constraint temporal en `rec_tmp_concilia_cnb` activada en PRE y eliminada en POST
  (TC22/23/24/31/32), combinación de ambos (TC25) — todos con limpieza verificada, ninguno afecta
  producción.
- TC43 (sección 2) es la única observación que llegó a publicarse temporalmente como
  `NO_EQUIVALENTE` en una versión intermedia de la ME (44/45) antes de resolverse a 45/45 en la
  versión final — consistente con el patrón ya visto de iteración entre versiones de una misma ME.

## 5. Patrones de esta ronda

### PR30 — Una tabla de trabajo global sin aislamiento por sesión puede dar resultados inconsistentes bajo ejecución concurrente, sin ser un defecto del microservicio (NUEVO)

- **Evidencia:** `db_general..rec_tmp_concilia_cnb` (TRUNCATE + carga + lectura total, sin filtro
  por ejecución) dio conteos distintos entre corridas bajo actividad concurrente (TC43); en una
  ventana controlada sin concurrencia, los 3 canales coincidieron exactamente.
- **Comprobación reusable:** ante un TC que da resultados distintos entre corridas sucesivas con la
  misma entrada (sin cambio de código ni de datos), investigar si el SP usa una tabla de trabajo
  global/compartida sin aislamiento por sesión antes de reportarlo como defecto del micro —
  reejecutar en una ventana sin actividad concurrente observable para confirmar.

### Confirmaciones (sin patrón nuevo)

- **PR29-adjacente / P09 de BB_MINERIA:** el pedido explícito de Banco de ver registros reales en
  vez de solo "filas compactadas/SHA-256" confirma con un caso concreto la necesidad ya catalogada
  de que la evidencia masiva preserve capacidad de inspección, no solo digest de integridad.
  - Cross-platform `GrpcTlsConfigTest`: quinta recurrencia confirmada (NCBE-2301).
  - Logging `Presence<T>`: cuarta instancia del mismo cambio cross-cutting "lotes 3+" (NCBE-2954).

## 6. Lo que no se pudo verificar / queda pendiente

- No se profundizó en NCBE-2205 (TC22) más allá de su cierre de 1 comentario — se infiere
  consistente con el mecanismo de constraint temporal documentado en NCBE-1580, no confirmado
  textualmente en el propio ticket.
- No se inspeccionaron en detalle los archivos de evidencia de TC43 (`exec_tc43_1.txt`,
  `grpc_tc43_1.txt`, `postman_tc43_1.txt`, varios MB cada uno) — el resumen cuantitativo del propio
  comentario de Gengis ya es suficiente y verificable.

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1344 (campos + 13 subtareas + 6 issuelinks); NCBE-1580
  (campos + 14 adjuntos + 10 comentarios); los 6 Defecto (campos + comentarios completos).
- **Verificación de hash:** adjunto final de NCBE-1580 descargado temporalmente a `/tmp` (nunca al
  repo), hash y veredictos verificados (45/45 EQUIVALENTE), confirmado idéntico a M6 de
  `BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md`. Borrado tras el uso.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #12** de la serie (procesada junto con #13 y #14 en el mismo turno). Ver índice
  `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`.

# respuesta-claude

> Auditoría de responsabilidad de los 24 casos no-EQUIVALENTE de la Matriz de Equivalencia de
> `sp_retefec_transval_rc` (NCBE-1178, RUN `sp_retefec_transval_rc-09-09-2026-1004-REV15-44TC`).
> Generada a pedido explícito del usuario para dejar constancia escrita de la respuesta.
>
> Tarea puramente de auditoría/análisis: no se ejecutaron retiros financieros nuevos, no se
> reabrió TC43, no se compensó el incidente pendiente, no se tocó `re_caja`, no se tocó
> QMetry/Jira, no hubo commit/push. Solo lectura (SELECT), inspección de evidencia ya producida,
> código y payloads.

## VEREDICTO_NON_EQUIVALENT_RESPONSIBILITY_NCBE_1178

### 1. ENDPOINTS

`REST_ENDPOINT_OPERATIONAL = YES` — `POST /api/v1/cuentas/retefec-transval/ejecutar`, confirmado
por los 20 EQUIVALENTE con respuestas HTTP 200/422 reales. `GRPC_ENDPOINT_OPERATIONAL = YES` —
`retefectransvalrc.RetefecTransvalRcService/Ejecutar`, confirmado en el canario de TC14 y en la
Fase 1 (los 20 EQUIVALENTE incluyen evidencia gRPC real). `SAME_ENDPOINT_ACROSS_TCS = YES` —
mismo endpoint/método en los 44, solo varía el payload.

### 2. SYBASE_OK_AUDIT

| TC | SP | REST att. | gRPC att. | WHY_NOT_REST/gRPC | PRE_MUTATES_SHARED | FINANCIAL_RISK | CAN_EXEC_REST_GRPC_NOW |
|---|---|---|---|---|---|---|---|
| TC02 | YES, 708153 | NO | NO | PRE hace `UPDATE cobis..cl_parametro` real (ALCNB) — el sandbox lo aísla en la misma transacción SP-directa; REST/gRPC usan otra conexión que no participa en ese rollback | **YES** (catálogo compartido) | NO | NO — requiere ventana coordinada |
| TC03 | YES, 300003178 | NO | NO | Igual — `UPDATE cl_parametro SET pa_char='I'` dentro del sandbox | YES | NO | NO |
| TC06 | YES, 101085 | NO | NO | Backup/mutación de CFN dentro del sandbox | YES | NO | NO |
| TC08 | YES, 201196 | NO | NO | Backup/mutación de DIA | YES | NO | NO |
| TC09 | YES, 201196 | NO | NO | `DELETE FROM cl_parametro WHERE ... DIA` real dentro del sandbox | YES | NO | NO |
| TC34 | YES, 101085 | NO | NO | `UPDATE cl_parametro SET pa_smallint=NULL` (CFN) dentro del sandbox | YES | NO | NO |
| TC35 | YES, 0 | NO | NO | `DELETE FROM cl_parametro WHERE ... DCI` dentro del sandbox | YES | NO | NO |
| TC44 | YES, 1 | NO | NO | **Sin mutación** — PRE es 100% `SELECT` sobre fila real preexistente (`re_aut_monto`, verificado 2026-09-02). Permanencia en sandbox es histórica/vestigial, no por necesidad técnica actual | **NO** | NO | **YES → SAFE_E2E_CANDIDATE** |

"El micro nunca fue llamado" aplica a los 8 — en ningún caso "el micro falló".

### 3. Razón raíz (no genérica)

Para TC02/03/06/08/09/34/35: **categoría B** — el PRE muta un catálogo compartido
(`cobis..cl_parametro`, ALCNB/CFN/DIA/DCI) real, visible a cualquier sesión si se comitea. El
sandbox SP-directo lo resuelve porque mutación+llamada+rollback ocurren en **una sola
transacción/conexión**; REST/gRPC pasan por el microservicio, que abre **su propia conexión** y
no puede unirse a esa transacción — para probarlos habría que comitear el catálogo en un estado
anómalo visible a Banco/otras sesiones concurrentes, aunque sea brevemente. No es una limitación
de tooling QA (D) ni riesgo financiero (C) — es aislamiento de estado compartido (B). Para TC44
la razón real es **D** (tooling/histórica, no re-evaluada tras el cambio a dato literal real del
2026-09-02).

### 4. ENVIRONMENT_BLOCKED_AUDIT

| TC | E2E_ATTEMPTED | BLOCKER_LAYER | Evidencia |
|---|---|---|---|
| TC15,17,18,23,25,28,29,32,33 | REST sí (real, `codigoRetorno=1`); SP/gRPC no reintentados individualmente (mecanismo ya probado 3-vías en TC12/TC31/TC36 de Fase 1) | **SHARED_ENVIRONMENT** | Caja cerrada hoy para jlarreas/oficina120 — precondición operativa real, no específica de Banco/Migración/QA |
| TC16 | REST sí (real, `codigoRetorno=1`, mismo bloqueo de caja alcanzado primero) | **MULTIPLE** (SHARED_ENVIRONMENT primario + BANCO_TEST_DATA secundario) | Caja cerrada (mismo mecanismo) + cuenta `0000601864` ya no existe (drift de dato, nunca se llega a validar por el orden de checks) |
| TC31 | NO — se detuvo antes del EXEC por una ambigüedad de ownership en la preparación de caja hecha por Claude | **QA_EXECUTION_SAFETY** | Fila ajena preexistente + inconsistencia de lectura en el script de preparación — decisión de detenerse, no un bloqueo externo duro |

Ninguno de los 11 alcanzó la rama objetivo por REST/gRPC de forma que pudiera evidenciar una
discrepancia de Migración — confirmado: `MIGRATION_MICRO` no puede ser la causa en ninguno de
estos 11.

### 5. TC30

`TC30_RECOVERABLE_BY_QA = YES` (para el identificador) — generar `@s_ssn`/`@i_tsn` nuevos es una
acción íntegramente controlada por QA. **Pero** el escenario subyacente sigue siendo un
happy-path real (débito de 3000.00) — corregir el ID no elimina el riesgo financiero; solo lo
mueve a la misma categoría que TC15/17/18/etc. (requiere aceptar/autorizar un débito real, no es
"gratis").

### 6. BLOCKED_MANUAL_AUDIT

| TC | MICRO_DEFECT_EVIDENCE |
|---|---|
| TC05 | NO — nunca ejecutado en ningún canal, sin comparación SP-vs-REST/gRPC posible |
| TC19 | NO — idem |
| TC24 | NO — idem |
| TC43 | NO — `TC43_MIGRATION_DEFECT_PROVEN = NO`. Causa raíz: comportamiento **LEGACY** (`sp_ccretiro_efectivo_rc` comitea antes de que el root llame a `sp_upd_totales_rc` — ya existía en el Sybase original, la migración no lo introdujo) + defectos de tooling QA ya identificados y corregidos. Sin evidencia REST/gRPC de divergencia (nunca se alcanzó una comparación válida). |

### 7. GROUP_A_SAFE_TO_COMPLETE_E2E

**TC44** (sin mutación, sin riesgo financiero, listo para SP+REST+gRPC de inmediato) y **TC31**
(recuperable con una re-preparación cuidadosa de caja usando ownership verificado, sin nueva
mutación de riesgo — requiere un intento QA más disciplinado, no autorización externa nueva).

### 8. GROUP_B_NEEDS_BANK_OR_ENVIRONMENT

TC02, TC03, TC06, TC08, TC09, TC34, TC35 (ventana coordinada para mutación de catálogo
compartido); TC15, TC16, TC17, TC18, TC23, TC25, TC28, TC29, TC32, TC33 (aceptación explícita de
débito real + caja abierta); TC30 (ID corregible por QA, pero débito real requiere la misma
aceptación); TC05, TC19, TC24 (decisión de negocio sobre riesgo de canal CNB, no dato faltante).

### 9. GROUP_C_MIGRATION_ISSUE_CANDIDATES

**Vacío.** Ningún caso cumple el criterio (sin comparación SP-vs-REST/gRPC con divergencia real
en ninguno de los 24).

### 10. MIGRATION_DEFECTS_PROVEN

0 — ninguno.

### 11. QA_RECOVERABLE_CASES

2 — TC44, TC31.

### 12. BANK_DEPENDENT_CASES

21 — TC02,03,06,08,09,15,16,17,18,23,25,28,29,30,32,33,34,35,05,19,24.

### 13. UNRESOLVED_CASES

0 — TC43 tiene decisión final tomada (`BLOCKED_MANUAL`, no reabrir).

### 14. CAN_20_EQUIVALENTE_BE_INCREASED

`YES` — mínimo a 22 (con TC44 + TC31), sin nueva autorización de riesgo financiero, solo con
ejecución cuidadosa adicional.

### 15. NEXT_ACTION

`REQUEST_TARGETED_SAFE_E2E_EXECUTION` (TC44 primero — cero riesgo; TC31 después, con
re-preparación de caja disciplinada)

### 16. MUTATIONS_PERFORMED

`NONE`

# Aprendizaje personal piloto gengis-me — ME #8: sp_retefec_transval_rc (NCBE-1178 → NCBE-1265)

Fecha de esta ronda: 2026-10-30. Octava entrega de la serie — **la más intensa hasta ahora**: 11
"Defecto" reales (no placeholders de checklist) y 25 versiones de artefactos (14 JSON, 8 proto, 9
HTML) a lo largo de 3+ semanas de revalidación con Banco. El SP es exactamente **M1** de
`BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md` — esta ronda corrobora con la fuente Jira primaria
buena parte de lo que esa minería ya había inferido del propio archivo JSON. No se hicieron
consultas a Sybase/REST/gRPC, no se reejecutó nada, no se modificó Jira/QMetry/motor/repos/ME.

## 1. Identidad y relación de tickets (OBSERVADO en Jira)

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1178 | Story | Padre | Procesa la recuperación de deuda pendiente en Cuentas Corrientes |
| NCBE-1211 | Task | Pipeline (relates to) | Análisis de Stored procedure — cob_cuentas.sp_retefec_transval_rc |
| NCBE-1212 | Task | Pipeline (relates to) | Creación de casos de prueba funcionales y estructurales |
| NCBE-1213 | Task | Pipeline (relates to) | Consolidación de casos de prueba |
| NCBE-1262 | Task | Pipeline (relates to) | Generación de datos para casos de prueba |
| **NCBE-1265** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — cob_cuentas.sp_retefec_transval_rc** |
| NCBE-2868 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance, no tocado |

SP: `cob_cuentas.sp_retefec_transval_rc`. Micro: `cpas-mso-retefec-transval-rc`.

**Confirmación cruzada (verificada por hash):** el último adjunto de NCBE-1265
(`QA-CASOS-PARSEADOS (7ad09c54-...).json`, 30-sep, 3048475 bytes, SHA-256
`58f4f219595561b7c6b51fb56173aad341cdbfde8dcfd8f2fe662d9907e3b15c`) es **byte-idéntico** a M1 de
`BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md`. La asociación que esa minería dejó como "explícito en
notas" queda confirmada con el trail Jira completo detrás.

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

NCBE-1178 tiene 18 subtareas: 6 son `Sub-task` "Entregable Micro" (checklist, sin contenido de
bug) y 1 más es `Sub-task` de pipeline (NCBE-4475, CI/CD). **Las 11 restantes son `Defecto` con
contenido real** — todas reportadas por el equipo de revisión de Banco (Katherine Murgueytio, Yuri
Sánchez Saquicela, Jose Fernando Plua Avila) durante la propia revisión de la ME, y resueltas por
Gengis Hidalgo (QA). A diferencia de toda la serie hasta ahora, **aquí no hay ruido de
arquitectura/SonarQube/Prisma mezclado** — los 11 son sustancia QA real.

### Grupo A — Mensajería/diagnóstico (NCBE-2940, 2943, 2945, 2882 parcial, 2975) → **QA real, resuelto: defecto del CAPTURADOR de la ME, no del micro**

- **NCBE-2940** (`mensaje_debug_raw: null` visible sin necesidad): campo técnico se mostraba
  siempre, incluso sin captura real de Sybase. Corregido para solo mostrarlo con captura real;
  ronda de ida-vuelta adicional porque la primera corrección ocultó también `mensaje_debug` cuando
  SÍ debía mostrarse como `null`.
- **NCBE-2943/NCBE-2945** (TC02/TC03): el texto "No existe registro" / "HORARIO SELECCIONADO..."
  que aparecía como si fuera mensaje crudo de Sybase en realidad era **derivado internamente por
  catálogo a partir del código de retorno** — no una captura real del motor. Corregido para no
  presentar mensajes derivados como si vinieran directamente del SP.
- **NCBE-2975** (TC08/09/15/17/18/25/28/29/30/36/39/42/43): inconsistencia entre `mensaje_debug` y
  el mensaje visible en `result_set` para el mismo dato; y, más de fondo, **el capturador de la ME
  conservaba solo PARTE de la mensajería cuando Sybase emitía varios mensajes en la misma
  ejecución** (confirmado en TC39: el SP emite 2 mensajes de negocio — "Costo no existe" + "FONDOS
  INSUFICIENTES" — y el micro expone correctamente solo el segundo, que es el relevante; el defecto
  era de PRESENTACIÓN en la ME, no del micro). Corregido y revalidado.
- **Clasificación:** QA real — el defecto vivía en el **mecanismo de captura/presentación de la
  propia ME** (no en el SP ni en el microservicio), confirmado explícitamente por Gengis en varios
  comentarios ("el capturador de la ME estaba conservando únicamente parte de la mensajería").

### Grupo B — Representación de `oComisión` (NCBE-2991, NCBE-2994) → **QA real, confirmado y corregido — origen directo del patrón P07/motor `detect_money_rest_wire_types`**

- Mismo defecto reportado dos veces (TC08/TC19 en 2991, TC36 en 2994): REST serializaba `oComision`
  como **NUMBER** JSON mientras gRPC lo serializaba como **STRING** (`google.protobuf.StringValue`)
  — una divergencia de tipo wire real entre canales del propio microservicio.
- **Corrección de 2 capas, explícita en los comentarios:** (1) el microservicio se corrigió para
  que REST también serialice `oComision` como STRING, igual que gRPC; (2) **"también se corrigió el
  capturador QA para preservar hacia adelante la distinción real del tipo recibido por REST sin
  alterar la evidencia RAW ni la normalización monetaria"** — es decir, un fix de motor/capturador
  además del fix del micro.
- **Cruce directo con BB_MINERIA:** esto es, con nombres y tickets reales, el origen de lo que esa
  minería ya había señalado para M1 como `execute_all.detect_money_rest_wire_types` (patrón P07) —
  antes solo se sabía que existía esa mención; ahora se confirma que nació exactamente de
  NCBE-2991/2994.
- **Clasificación:** QA real — divergencia de tipo wire confirmada y corregida en el micro, con fix
  paralelo en el motor QA para no perder la distinción en futuras capturas.

### Grupo C — Infraestructura de ejecución de la ME (NCBE-2902, NCBE-2947) → **QA real, resuelto: defectos del propio documento/script de pruebas, no del SP**

- **NCBE-2902:** los comandos de ejecución SQL no incluían el nombre de la base de datos
  (`cob_cuentas..sp_retefec_transval_rc`), rompiendo la reproducibilidad manual. Corregido
  completando la nomenclatura en PRE/POST/EXEC y unificando el formato de comentarios SQL.
- **NCBE-2947 (TC04/TC05, 13 comentarios — el hilo más largo de esta ronda):** error de compilación
  Sybase (`Msg 134`, variable redeclarada) en el PRE de TC04/TC05 por declarar las mismas variables
  de salida dos veces en el mismo batch — corregido, y preventivamente aplicado también a TC23. TC04
  cerró rápido; **TC05 se convirtió en una odisea de revalidación de varias rondas** (igual al
  "TC05/TC19" que BB_MINERIA ya documentaba para M1): REST devolvía `130028 POR DUPLICADO` cuando SP
  y gRPC tenían éxito (resuelto aislando mejor los datos de prueba por canal); apareció un mensaje
  técnico Sybase (`substring function` con -1) sin impacto funcional; se detectó que `@i_ref` en la
  ejecución real (`'REF-TC05-SP-20260922'`) no coincidía con el valor esperado documentado
  (`'1|COMERCIO01'`); finalmente se corrigieron variables duplicadas entre canales, bindings de
  salida y preparación de la transacción base distinguiendo `tm_correccion` (transacción base vs.
  su corrección).
- **Clasificación:** QA real — defectos de los propios scripts de prueba (PRE con variables
  duplicadas, aislamiento de datos insuficiente entre canales), no de la lógica de negocio del SP
  ni del microservicio.

### Grupo D — Regresiones de regeneración de la ME (NCBE-3281, NCBE-3293) → **QA real, confirma un patrón propio nuevo (PR26)**

- **NCBE-3281 (TC16):** error de columna de tabla al ejecutar; cerrado agregando una precondición.
  Resolución rápida, 1 comentario.
- **NCBE-3293 ("Novedad con insumos entregados", 10 comentarios):** Banco detectó que **una nueva
  entrega de la ME regresionó varios fixes ya aplicados en la entrega anterior**: TC36 perdió la
  precondición de "apertura de caja" que sí está en el documento Banco; TC19 perdió el formato de
  comisión ya corregido un día antes; TC32 generaba el POST duplicado y el dashboard del SP mostraba
  datos que no correspondían al resultado; apareció un tercer campo nuevo inesperado en TC19/TC32;
  TC42/TC43 perdieron los campos `guard`/`procedencia` que sí estaban en la entrega anterior; TC16
  repetía la postcondición varias veces. Todo corregido en la siguiente entrega (30-sep) y
  confirmado por Banco al día siguiente.
- **Clasificación:** QA real — no defectos del SP/micro, sino regresiones del propio proceso de
  regeneración/entrega de la ME durante un ciclo de revalidación muy iterativo. Ver PR26.

### NCBE-4475 — "Novedades en pipeline para pase" → **NO ES QA (CI/CD, confirma PR08/PR17)**

- Mismo paquete recurrente: `commons-logging` no declarado (unit test), `jackson-bom` 3.1.4→3.1.7
  (CVE Prisma). Commit `4a26a6e`. Sin relación con comportamiento SP↔microservicio.

## 3. Nota de procedencia inusual (NCBE-2947, comentario de Priscila Pincay, 30-sep)

Uno de los comentarios de NCBE-2947 contiene un bloque de **notas técnicas internas pegadas
textualmente** (jerga de procedencia tipo `evidencia_nota`, `procedencia`,
`CHECKPOINT-tc05-ciclo-secuencial-2026-09-29.json`, `verificacion_posterior_2026_09_29`) que
documentan, TC por TC, el estado de TC05/15/16/17/18/19/25/28/29/30/32/36/39/42/43 — incluida la
explicación completa de por qué varios TCs (15/17/25/28/29/30/39) muestran el aviso "Costo no
existe" de forma asimétrica: **no es una inconsistencia, es que la fila de catálogo
`pe_costo` (`co_servicio_per=812`, `co_canal='VEN'`, `co_oficina=999`) existía o no en el ambiente
real según el momento exacto de cada captura** — verificado empíricamente, no inferido. Esto es,
con datos reales, exactamente el tipo de explicación que `BB_MINERIA_COMPARATIVA_9_ME` ya pedía
para distinguir "particularidad del ambiente capturada en momentos distintos" de "inconsistencia
real" (patrón P08). Se registra aquí como nota de procedencia, no como hallazgo nuevo — el
contenido ya es consistente con lo que la minería había señalado para M1.

## 4. Contraste con la ME final (NCBE-1265)

- **Universo:** 43 TCs, 8 grupos, **43/43 EQUIVALENTE**. Coincide exactamente con lo reportado por
  Gengis en los comentarios ("La equivalencia funcional de la matriz se mantiene en 43/43 casos")
  en cada ronda de corrección — el veredicto agregado nunca se vio afectado por ninguno de los 11
  defectos, todos eran de presentación/captura/reproducibilidad, nunca de divergencia funcional real
  entre SP y microservicio.
- **Observación documentada y preservada deliberadamente, no corregida (TC12/TC26):** SP, REST y
  gRPC retornan consistentemente código `1`, mientras el documento de Banco mantiene como esperado
  `31063` — Gengis lo señaló explícitamente como diferencia frente al documento, sin forzar el
  resultado ni alterar el veredicto de equivalencia Legacy↔microservicio. Correcta aplicación de la
  regla "SP es la fuente de verdad" ya catalogada en memoria propia.
- Todos los 11 defectos de la sección 2 SÍ dejan rastro en la ME — a diferencia de todas las rondas
  anteriores de esta serie, aquí los bugs del padre son precisamente las correcciones iterativas que
  explican por qué existen 14 versiones del archivo.

## 5. Patrones agrupados por causa o comprobación reusable (nuevos de esta ronda)

### PR26 — Regenerar la ME en rondas iterativas puede regresionar fixes ya aplicados en una entrega anterior (NUEVO)

- **Evidencia:** NCBE-3293 — 5 regresiones concretas detectadas por Banco entre dos entregas
  consecutivas (precondición perdida, formato de comisión perdido, POST duplicado, campos de
  guard/procedencia perdidos, postcondición repetida).
- **Comprobación reusable:** cuando un ciclo de revalidación genera muchas versiones sucesivas de
  la ME en pocos días, diferenciar explícitamente la nueva versión contra la anterior (no solo
  contra el documento Banco) antes de publicarla — un fix de un TC puede perderse silenciosamente al
  corregir otro si la regeneración no es incremental.

### PR27 — El capturador de la ME puede truncar mensajería múltiple de Sybase, aparentando una divergencia que no existe en el micro (confirma y precisa P03 de BB_MINERIA)

- **Evidencia:** NCBE-2975 — cuando el SP emite 2+ mensajes de negocio en una sola ejecución, el
  capturador conservaba solo parte de ellos, generando una aparente inconsistencia entre
  `mensaje_debug` y `result_set` que en realidad era un defecto de la propia herramienta de
  captura, no del SP ni del microservicio.
- **Comprobación reusable:** ante una discrepancia de mensajería donde el micro parece "perder" un
  mensaje que el SP sí muestra, verificar primero si el SP está emitiendo más de un mensaje en esa
  ejecución y si el capturador los está consolidando todos — antes de reportarlo como defecto del
  micro.

## 6. Lo que no se pudo verificar / queda pendiente

- No se profundizó en el detalle exacto del fix de motor de NCBE-2991/2994 (qué archivo/línea del
  capturador QA se tocó) — los comentarios confirman la existencia del fix pero no citan
  commit/archivo; cruzar con el código del motor queda fuera de alcance de esta ronda (solo Jira).
- No se confirma con certeza si las menciones en memoria propia a "candidato v4 TC42/TC43" y "v10
  gate+writes atómicos" (fixes locales de scripts PRE/POST de este SP, con commits propios no
  reflejados en Jira) corresponden exactamente a los mismos episodios narrados en NCBE-2947/NCBE-3293
  — el mecanismo descrito (`#qa_estado_pre_g_tc32_sp.fallo`, gate condicionado) es consistente, pero
  no hay una cita textual cruzada que lo confirme al 100%. Es, en todo caso, otra instancia del
  límite metodológico ya documentado en PR24 (ME #7): hay trabajo real de cierre que no queda
  reflejado en los tickets Jira del padre.
- No se inspeccionaron en detalle las 9 versiones HTML ni los 8 `.proto` adjuntos a NCBE-1265 más
  allá de confirmar su existencia — la evidencia JSON ya es suficiente para esta reconstrucción.

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1178 (campos + 18 subtareas + 12 issuelinks, 6 "relates to"
  pipeline + 6 "relates to" Defecto); NCBE-1265 (campos + 31 adjuntos listados, 1 descargado y
  verificado); los 11 Defecto + NCBE-4475 (campos + comentarios completos, 2947/2975/3293 con
  especial profundidad por su volumen).
- **Verificación de hash:** el adjunto final de NCBE-1265 (30-sep, 3048475 bytes) descargado
  temporalmente a `/tmp` (nunca al repo), hash confirmado idéntico a M1 de
  `BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md`, veredictos verificados (43/43 EQUIVALENTE). Borrado
  tras el uso.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #8** de la serie. Ver índice `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`. Pendiente:
  el usuario indicará el siguiente ticket padre y su HU.

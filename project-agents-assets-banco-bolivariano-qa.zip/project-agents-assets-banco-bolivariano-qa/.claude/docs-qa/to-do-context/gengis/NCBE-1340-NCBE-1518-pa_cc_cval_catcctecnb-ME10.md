# Aprendizaje personal piloto gengis-me — ME #10: pa_cc_cval_catcctecnb (NCBE-1340 → NCBE-1518)

Fecha de esta ronda: 2026-10-30. Décima entrega de la serie. Ronda comparativamente liviana (4
Defecto, cada uno resuelto en 1-2 intercambios) frente a las ME #8/#9, pero con una tercera
confirmación concreta de un patrón ya catalogado (PR29). No se hicieron consultas a Sybase/REST/
gRPC, no se reejecutó nada, no se modificó Jira/QMetry/motor/repos/ME.

## 1. Identidad y relación de tickets (OBSERVADO en Jira)

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1340 | Story | Padre | Valida Categoria Cuenta CNB |
| NCBE-1514 | Task | Pipeline (relates to) | Análisis de Stored procedure — cob_pagos.pa_cc_cval_catcctecnb |
| NCBE-1515 | Task | Pipeline (relates to) | Creación de casos de prueba funcionales y estructurales |
| NCBE-1516 | Task | Pipeline (relates to) | Consolidación de casos de prueba |
| NCBE-1517 | Task | Pipeline (relates to) | Generación de datos para casos de prueba |
| **NCBE-1518** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — cob_pagos.pa_cc_cval_catcctecnb** |
| NCBE-2863 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance, no tocado |

SP: `cob_pagos.pa_cc_cval_catcctecnb`. Micro: `cnb-mso-pa-cval-catcctecnb`. 6 TCs.

**Confirmación cruzada:** el último adjunto de NCBE-1518 (`QA-CASOS-PARSEADOS (19e41b56-...).json`,
45757 bytes, SHA-256 `336ff8ed040861c27fb6c924f26c8cf481b9d1f8534c1f73f1eef59d184ad7d1`) es
**byte-idéntico** a M9 de `BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md` y coincide con el cierre
"6/6 EQUIVALENTE" ya conocido por memoria propia (`project_pa_cc_cval_catcctecnb_tc_loop`).

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

NCBE-1340 tiene 11 subtareas: 7 son `Sub-task` de checklist (Entregable/Veracode/Prisma/Qualys/
Infra/Pruebas Unitarias/Código) sin contenido de bug; 1 más es `Sub-task` (NCBE-4226, pipeline) con
contenido. Las 4 restantes son `Defecto` con contenido real.

### NCBE-1769 — "Matriz Equivalente refleja línea de mensaje_debug adicional en los TCs - SP" → **QA real, TERCERA confirmación de PR29**

- Reportado: la respuesta del SP en la ME mostraba 2 líneas que Sybase no emite:
  `mensaje_debug [diagnostico interno del motor/wrapper, no es @s_msg]: null` y
  `engine_exception: null`. El propio título del campo ya se auto-etiqueta como "diagnóstico
  interno del motor/wrapper" — es decir, el motor QA sabe que es información propia, y aun así
  terminó mostrándose como si fuera parte de la respuesta real del SP comparada contra Sybase.
  Corregido en 1 día (commit no citado), validado por Banco: "la Matriz Equivalente adjuntada ya no
  muestra línea adicional".
- **Clasificación:** QA real — **tercera instancia confirmada del patrón PR29** (ME #9): datos
  internos del propio proceso QA (`engine_exception`, aquí también `mensaje_debug` interno)
  filtrándose hacia la evidencia que compara contra Sybase, aparentando una divergencia que no
  existe. Aquí el campo incluso llevaba su propia etiqueta de "diagnóstico interno" en el código,
  lo que hace más llamativo que se mostrara igual en la comparación — sugiere que el filtro de
  presentación de la ME no excluye estos campos de forma sistemática en todos los puntos donde
  podría aparecer.

### NCBE-1956 — "Novedad dependencia de microservicio" → **NO ES QA (red/build transitorio)**

- Fallo de Maven al descargar `pa-cc-cval-catcctecnb-utils` ("Remote host terminated the
  handshake") diagnosticado como corte de conexión TLS transitorio contra el registro de
  artefactos, no una dependencia faltante. Resuelto reintentando la compilación.

### NCBE-2203 — "Novedad mvn site no se genera pdf" → **NO ES QA (cross-platform, confirma recurrencia ya vista en ME#7/NCBE-2193)**

- Mismo patrón exacto que NCBE-2193 (ME #7, `sp_cnb_consulta_saldo`): un test (`GrpcTlsConfigTest`)
  validaba rutas de certificados TLS asumiendo convenciones de Linux (`/tmp`, `/run`), rompiendo el
  build en Windows antes de llegar a generar el PDF de `mvn site`. Corregido con validación
  independiente del sistema operativo y directorios temporales de JUnit portables.
- **Clasificación:** NO-QA — build/cross-platform; tercera vez que aparece esta MISMA clase de
  defecto (rutas Unix hardcodeadas en tests TLS) en la serie, ahora en un tercer microservicio.

### NCBE-2952 — "No se visualiza en el log la información del campo Request i_Cuenta" → **NO ES QA (observabilidad/logging, cross-cutting "lotes 3+")**

- El log de traza de request mostraba los campos `Presence<T>` como `{"present":true}` en vez del
  valor real (ej. `e_cuenta`), dificultando la depuración. La descripción cita explícitamente un
  correo "Cambios faltantes en nuevos micros lotes 3+" — es decir, un requerimiento transversal para
  varios microservicios del lote, no específico de este SP. Corregido con un serializador dedicado
  (`PresenceSerializer`/`PresenceModule`).
- **Clasificación:** NO-QA — mejora de observabilidad/logging del microservicio, sin relación con
  el comportamiento SP↔microservicio comparado por la ME, aunque sí ayuda a la depuración futura.

## 3. Hallazgo principal de los bugs del padre

Esta ronda confirma que el ruido NO-QA recurrente de la serie (build cross-platform, red
transitoria, logging) sigue apareciendo en microservicios nuevos, y aporta una tercera confirmación
clara de PR29 — aunque esta vez el campo filtrado ya llevaba su propia etiqueta de "diagnóstico
interno" en el código, lo que sugiere que el filtro de presentación de la ME necesita cubrir estos
campos de forma más sistemática, no solo caso por caso cuando Banco los reporta.

## 4. Contraste con la ME final (NCBE-1518) — particularidad real de alcanzabilidad, no un defecto

- **Universo:** 6 TCs, 2 grupos, **6/6 EQUIVALENTE** (verificado en el adjunto final, hash
  confirmado contra M9).
- **TC05 requería preparación especial de ambiente, documentada explícitamente como NO defecto:**
  TC05 valida el escenario de falla técnica de una dependencia **compartida** (`cobis..sp_error`,
  `RETURN 1011`) que en condiciones normales del ambiente funciona correctamente — no hay dato de
  entrada que la haga fallar. Para ejercer ese escenario se necesitó que **un DBA revocara
  temporalmente el permiso de ejecución** sobre esa dependencia compartida (usada por otros SPs
  también) en una ventana controlada, se ejecutara el caso, y se restaurara el permiso de
  inmediato. Juan Pablo Sanabria lo documentó explícitamente como "pendiente de esa preparación
  manual, no es un defecto del SP ni del microservicio" — Banco habilitó el ambiente (24-ago) y el
  caso se cerró como parte del 6/6 final.
- **Nota de cruce con otro sistema, sin resolver aquí:** memoria propia
  (`project_pa_cc_cval_catcctecnb_tc_loop`) registra que la ejecución en QMetry mostró en algún
  momento `{Pass:5, NotExecuted:1 TC05 deliberado}` — distinto del estado final del JSON de Jira
  (6/6 EQUIVALENTE, incluido TC05). Es consistente con que QMetry capturó un punto en el tiempo
  anterior a que el DBA habilitara la ventana de prueba; no se investiga más a fondo aquí porque no
  cambia el cierre real documentado en esta HU.
- Ninguno de los 4 Defecto de la sección 2 deja rastro funcional en el veredicto — todos son ruido
  NO-QA o un defecto de presentación ya corregido (PR29).

## 5. Patrones de esta ronda

No se proponen patrones nuevos — esta ronda aporta **confirmaciones** de patrones ya catalogados:

- **PR29** (ME #9): tercera instancia confirmada (`mensaje_debug`/`engine_exception` internos
  filtrados a la comparación contra Sybase en NCBE-1769).
- **Recurrencia NO-QA ya vista** (NCBE-2193/ME#7): el defecto de rutas Unix hardcodeadas en
  `GrpcTlsConfigTest` reaparece en un tercer microservicio (NCBE-2203).
- **Particularidad de SP reutilizable:** un escenario que depende de forzar la falla de una
  dependencia compartida (`cobis..sp_error`) requiere coordinación de DBA (revocar/restaurar
  permiso en ventana controlada) — no es exclusivo de este SP, aplica a cualquier TC que dependa de
  hacer fallar una utilidad compartida por diseño.

## 6. Lo que no se pudo verificar / queda pendiente

- No se investigó por qué `metadata.fecha_generacion` del JSON final (21-ago) es anterior a la
  fecha de habilitación del ambiente para TC05 (24-ago) pese a que el archivo sí incluye TC05 como
  EQUIVALENTE — posible timestamp no actualizado en una regeneración parcial; no afecta la
  conclusión de cierre.
- No se resolvió la discrepancia QMetry (`NotExecuted` deliberado) vs. JSON final (EQUIVALENTE)
  para TC05 — darle seguimiento solo si se retoma trabajo de QMetry sobre este SP.
- `cat_cta_cnb.proto` (adjunto a NCBE-1518) no se inspeccionó en detalle.

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1340 (campos + 11 subtareas + 7 issuelinks "relates to");
  NCBE-1518 (campos + 7 adjuntos + 3 comentarios); NCBE-1769/1956/2203/2952 (campos + comentarios
  completos).
- **Verificación de hash:** el último adjunto de NCBE-1518 descargado temporalmente a `/tmp` (nunca
  al repo), hash y veredictos verificados (6/6 EQUIVALENTE, incluido TC05), confirmado idéntico a
  M9 de `BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md`. Borrado tras el uso.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #10** de la serie. Ver índice `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`.
  Pendiente: el usuario indicará el siguiente ticket padre y su HU.

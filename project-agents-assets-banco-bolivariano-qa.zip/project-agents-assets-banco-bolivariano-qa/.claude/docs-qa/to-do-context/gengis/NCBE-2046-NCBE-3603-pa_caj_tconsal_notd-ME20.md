# Aprendizaje personal piloto gengis-me — ME #20: pa_caj_tconsal_notd (NCBE-2046 → NCBE-3603)

Fecha de esta ronda: 2026-11-01. Vigésima entrega (3 de 3 de este turno) — la ronda más liviana en
contenido Jira, pero con memoria propia rica que refuerza el límite metodológico ya catalogado
(PR24). No se hicieron consultas a Sybase/REST/gRPC, no se reejecutó nada, no se modificó Jira/
QMetry/motor/repos/ME.

**Nota de procedencia (mismo patrón de ME #17/#19):** NCBE-3603 es un Sub-task de **NCBE-2202**
("Revisión de matriz de equivalencia", la tarea formal enlazada al padre). Ambos tickets tienen un
JSON de igual tamaño (926075 bytes: NCBE-2202 lo recibió el 29-sep, NCBE-3603 el 06-oct) — copias
equivalentes, el usuario señaló correctamente el ticket vigente.

## 1. Identidad y relación de tickets

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-2046 | Story | Padre | MICRO: cob_atm.pa_caj_tconsal_notd |
| NCBE-2195/2196/2200/2201 | Task | Pipeline (relates to) | Análisis/Creación/Consolidación/Generación de datos |
| NCBE-2202 | Task | Pipeline (relates to) | Revisión de matriz de equivalencia (tarea formal) |
| **NCBE-3603** | Sub-task de NCBE-2202 | **HU de esta ronda** | **Generación de matriz de equivalencia NYXN — cob_atm.pa_caj_tconsal_notd** |
| NCBE-2875 | Task | Pipeline (relates to) | Pruebas de rendimiento — en estado "Construcción", fuera de alcance |

SP: `cob_atm.pa_caj_tconsal_notd`. Micro: `atm-mso-consulta-saldo-quickpay`. 49 TCs —
**49/49 EQUIVALENTE** confirmado por hash en el JSON de NCBE-3603 (06-oct, 926075 bytes).

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

**Solo 1 `Defecto`** (7 `Sub-task` de checklist sin bug). Confirma, otra vez, que para este grupo
de SPs la mayoría del trabajo de cierre vive fuera de Jira (ver sección 3).

### NCBE-4600 — "TC02/TC08 Formato decimal" → **NO ES QA — confirma el criterio transversal de money de NCBE-4272 con el mismo correo citado en ME #15 y #17**

- Observación: `sSaldoDisponible`, `sSaldoContable`, `sSaldiscr` se mostraban como enteros en
  REST/gRPC donde el SP (tipo `money`) muestra decimales.
- Respuesta de Giorgi Torres (con el mismo adjunto **`Correo decimales.pdf`** ya visto citado en
  NCBE-4667/4711 de la ME #15 y en NCBE-4600 aquí mismo — es, literalmente, el mismo correo de
  criterio reutilizado por tercera vez en la serie): el criterio NCBE-4272 dicta que los valores
  sin decimales significativos se muestran sin la parte decimal (`7978.0000`→`7978`), y los que sí
  tienen decimales los conservan sin pérdida (`537.0200`→`537.02`). Confirmado por Roque Ramírez
  Pionce "basados en correo compartido" — cierre sin cambio de código.

## 3. Hallazgo principal — el límite metodológico de reconstruir solo desde Jira, otra vez confirmado

Con un solo Defecto formal, la pregunta inevitable es: ¿dónde está el resto del trabajo de cierre
de 49 TCs? La respuesta, consistente con **PR24** (ME #7): en memoria propia de sesiones previas
sobre este mismo SP (`project_ncbe2046_tconsal_secuencial_regen`) hay registro de **3 fixes
locales del motor QA del micro** (regeneración de secuencial para SP+REST+gRPC, título a 255
caracteres, manejo de `NOT_APPLICABLE` en evidencia) que **no generaron ningún ticket Jira** bajo
este padre — se resolvieron directamente en el motor/tooling local del micro, documentados solo en
memoria propia, con la advertencia explícita de que **se pierden con `sync-harness.sh --pull`**
(el mecanismo de sincronización del motor compartido). Ningún Defecto de Jira los menciona.

## 4. Contraste con la ME final (NCBE-3603)

- **Universo:** 49 TCs, **49/49 EQUIVALENTE**, confirmado por hash. Coincide con memoria propia
  ("19/19 EQ + 15 NA, QMetry NCBE-TR-39") solo parcialmente — la cifra de memoria describe un corte
  distinto (con `NOT_APPLICABLE` explícitos); el JSON de esta ronda, más reciente (06-oct vs. la
  entrega de memoria del 15-oct... la fecha de memoria es posterior), muestra 49/49 sin
  `NOT_APPLICABLE` — consistente con que los 15 `NOT_APPLICABLE` de memoria se resolvieron a
  EQUIVALENTE en una iteración posterior no capturada como Defecto de Jira.
- El único Defecto de Jira (NCBE-4600) no deja rastro de regresión — es un cierre limpio por
  criterio ya establecido.

## 5. Patrones de esta ronda

No se proponen patrones nuevos — refuerza con un ejemplo muy claro 2 ya catalogados:

- **Confirma PR24** (ME #7): el trabajo de cierre real de un SP puede vivir casi enteramente fuera
  de Jira (motor/tooling local del micro), sin generar ningún "Defecto" — reconstruir solo desde
  Jira para este SP daría una imagen muy incompleta si no se cruza con memoria propia.
- **Confirma el criterio transversal de money de NCBE-4272** (ME #15/#17) — tercera cita textual
  del mismo correo (`Correo decimales.pdf`) en la serie, ahora con certeza de que es el mismo
  adjunto reutilizado, no una explicación repetida cada vez.

## 6. Lo que no se pudo verificar / queda pendiente

- No se confirmó si los 3 fixes locales del motor documentados en memoria propia
  (`project_ncbe2046_tconsal_secuencial_regen`) sobrevivieron a algún `sync-harness.sh --pull`
  posterior — la propia memoria advierte que se pierden con ese mecanismo; no se verificó el estado
  actual del repo del micro (fuera de alcance: no se tocan repos de microservicio en esta serie).
- No se reconcilió en detalle la discrepancia de conteo con memoria propia (19/19+15 NA vs. 49/49)
  más allá de la hipótesis razonada en la sección 4.

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-2046 (campos + 9 subtareas + 7 issuelinks); NCBE-2202 y
  NCBE-3603 (campos + adjuntos); NCBE-4600 (campos + comentarios completos).
- **Verificación:** JSON de NCBE-3603 descargado temporalmente a `/tmp` (nunca al repo), veredictos
  verificados (49/49 EQUIVALENTE). Borrado tras el uso.
- **Memoria propia consultada:** `project_ncbe2046_tconsal_secuencial_regen` (sesión previa a esta
  serie) — solo para contrastar el alcance de Jira, no se verificó el estado actual del repo del
  micro.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #20** de la serie (3 de 3 de este turno). Ver índice
  `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`.

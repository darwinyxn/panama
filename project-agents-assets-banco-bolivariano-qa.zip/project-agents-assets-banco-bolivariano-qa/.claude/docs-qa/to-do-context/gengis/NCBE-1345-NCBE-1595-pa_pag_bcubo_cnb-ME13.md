# Aprendizaje personal piloto gengis-me — ME #13: pa_pag_bcubo_cnb (NCBE-1345 → NCBE-1595)

Fecha de esta ronda: 2026-10-30. Decimotercera entrega de la serie (procesada junto con ME #12 y
#14 en el mismo turno). SP sin precedente en `BB_MINERIA_COMPARATIVA_9_ME` — terreno nuevo para la
serie. No se hicieron consultas a Sybase/REST/gRPC, no se reejecutó nada, no se modificó Jira/
QMetry/motor/repos/ME.

## 1. Identidad y relación de tickets

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1345 | Story | Padre | Microservicio Cubo CNB |
| NCBE-1592/1593/1594/1601 | Task | Pipeline (relates to) | Análisis/Consolidación/Creación/Generación de datos |
| **NCBE-1595** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — cob_pagos.pa_pag_bcubo_cnb** |
| NCBE-2870 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance |

SP: `cob_pagos.pa_pag_bcubo_cnb`. Micro: `cnb-mso-pag-cubo-cnb`. 55 TCs.

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

Solo 2 `Defecto`, ambos **NO-QA**, ambos recurrencias ya catalogadas en la serie:

- **NCBE-2328** — sexta recurrencia confirmada del defecto cross-platform `GrpcTlsConfigTest`
  (rutas Unix hardcodeadas + cobertura JaCoCo), mismo mecanismo y solución que en ME#7/#10/#11/#12.
- **NCBE-2961** — quinta instancia del cambio cross-cutting de logging `PresenceSerializer.java`/
  `PresenceModule.java` ("lotes 3+"), mismo patrón que ME#10/#12.

**Hallazgo principal de los bugs del padre: ninguno es QA.** Toda la sustancia de equivalencia
real de este SP vive en los comentarios de la propia HU de revisión (sección 3), no en "Defecto"
formales bajo el padre — reforzando otra vez la lección metodológica ya vista (PR24, ME #7): Jira
solo no basta, hay que leer la HU de revisión con el mismo cuidado que los bugs.

## 3. La HU de revisión (NCBE-1595) concentra el contenido real — clasificación extensa de hallazgos (17-sep, William Nieto Rico)

El comentario de cierre de NCBE-1595 organiza explícitamente los hallazgos por categoría —
ejemplo claro y bien estructurado de cómo separar defecto real, limitación de ambiente y
divergencia autorizada:

- **9 TCs (TC25, 28, 29, 32, 33, 35, 38, 41, 44) — "escenario no reproducible en datos DEV":** el
  SP devolvió éxito (`return=0`) donde el documento esperaba forzar un error técnico
  (`300003377` o `Msg 249`); la condición "veneno" necesaria no está presente en el ambiente DEV
  actual. Reportado a Banco como pendiente de datos/escenario, no reinterpretado ni forzado.
- **TC13 — "el SP falló, pero con un error distinto al documentado":** esperado `300003377`,
  observado `return=-6` ("Arithmetic overflow during implicit conversion of VARCHAR..."). Posible
  mismatch de escenario/datos; se pidió confirmación de Banco sobre cuál es el comportamiento
  correcto esperado, sin asumir ninguno de los dos.
- **TC47/TC48 — documentación a ajustar, no un bug:** el SP lanzó la excepción nativa completa
  (`Msg 249`) en vez del código limpio `-6` que documentaba el caso. Recomendación: actualizar
  "Resultado esperado" a la excepción real observada (mismo tratamiento ya aplicado a TC24),
  pendiente de autorización — explícitamente etiquetado como ajuste de documentación, no defecto.
- **TC24B — "limitación de motor QA, ya aceptada":** requiere bloqueo concurrente real de 2
  sesiones Sybase simultáneas; el motor QA no simula esa concurrencia. Aceptado como límite
  conocido, no reabierto como hallazgo.
- **TC52/TC53 — divergencia INTENCIONAL y AUTORIZADA por Seguridad del Banco, confirmada en el JSON
  final como `NO_EQUIVALENTE` (no forzada a EQUIVALENTE):** el SP legacy acepta cualquier letra en
  `@e_reproceso` (ej. `'a'` minúscula o `'X'` sin significado) y la deja pasar sin quejarse; el
  microservicio fue construido deliberadamente más estricto, rechazando cualquier valor que no sea
  exactamente `'A'`, `'N'` o `'S'` en mayúscula, por un requerimiento explícito de Seguridad
  (ticket **NCBE-2008**). Juan Pablo Sanabria pidió confirmación explícita de Banco antes de cerrar
  estos 2 casos como resueltos — no los cerró unilateralmente asumiendo que la regla más estricta
  era la correcta. Banco confirmó: "el comportamiento del micro-servicio es válido y el SP no
  cuenta con esta lógica". **Verificado en el JSON final: TC52 y TC53 quedan con veredicto
  `NO_EQUIVALENTE`** — la discrepancia técnica entre legacy y micro se preserva honestamente en el
  registro, y la autorización/justificación se documenta por separado, sin maquillar el veredicto.

## 4. Contraste con la ME final (NCBE-1595)

- **Universo:** 55 TCs, 4 grupos, **53 EQUIVALENTE + 2 NO_EQUIVALENTE** (TC52, TC53 — verificado).
- A diferencia de toda la serie hasta ahora, este es el **primer caso donde un `NO_EQUIVALENTE`
  final es una decisión deliberada y autorizada**, no un defecto pendiente ni una limitación de
  alcanzabilidad — y aun así el motor no lo convierte en `EQUIVALENTE` ni en `NOT_APPLICABLE`: el
  veredicto técnico queda fiel a la comparación real (SP≠micro), con la autorización como contexto
  aparte. Ver PR31.

## 5. Patrones de esta ronda

### PR31 — Una divergencia intencional y autorizada (ej. por requerimiento de Seguridad) se documenta como NO_EQUIVALENTE real, no se fuerza a EQUIVALENTE ni se oculta (NUEVO)

- **Evidencia:** TC52/TC53 — el microservicio es deliberadamente más estricto que el SP legacy por
  mandato explícito de Seguridad (NCBE-2008); Banco confirmó por escrito que el comportamiento del
  micro es el válido. El JSON final conserva el veredicto técnico `NO_EQUIVALENTE` para ambos.
- **Comprobación reusable:** cuando una divergencia SP↔micro es intencional (hardening de
  seguridad, nueva regla de negocio autorizada), no cambiar el veredicto técnico a `EQUIVALENTE` —
  mantenerlo como `NO_EQUIVALENTE` (la comparación real lo es) y documentar la autorización/ticket
  de respaldo aparte. Es la aplicación más limpia vista hasta ahora de "no forzar el resultado
  esperado mediante un overlay" (ya señalado en BB_MINERIA para patrones de error) extendida a
  divergencias de validación de entrada.
- Antes de cerrar un caso de divergencia como "correcto porque es más estricto", pedir
  confirmación explícita de Banco — no asumirlo unilateralmente (buena práctica ya aplicada aquí
  por Juan Pablo Sanabria).

## 6. Lo que no se pudo verificar / queda pendiente

- No se confirma el estado final de los 9 TCs "veneno no reproducible" ni de TC13/TC47/TC48 más
  allá de lo reportado el 17-sep — no hay comentarios posteriores en NCBE-1595 que documenten su
  cierre; podrían seguir pendientes de datos/autorización de Banco.
- No se investigó el ticket NCBE-2008 (requerimiento de Seguridad) en detalle — mencionado y
  citado por el propio equipo, no es un bug de este padre ni de la HU de revisión, fuera de
  alcance.
- `pag_cubo_cnb.proto` e imagen adjunta a NCBE-1595 no se inspeccionaron en detalle.

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1345 (campos + 9 subtareas + 6 issuelinks); NCBE-1595 (campos
  + 3 adjuntos + 3 comentarios); NCBE-2328/2961 (campos + comentarios completos).
- **Verificación:** adjunto único de NCBE-1595 descargado temporalmente a `/tmp` (nunca al repo),
  veredictos verificados (53 EQUIVALENTE + 2 NO_EQUIVALENTE, identificados como TC52/TC53).
  Borrado tras el uso.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #13** de la serie (procesada junto con #12 y #14 en el mismo turno). Ver índice
  `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`.

# Aprendizaje personal piloto gengis-me — ME #4: pa_fir_consulta_condicion (NCBE-1175 → NCBE-1264)

Fecha de esta ronda: 2026-10-30. Cuarta entrega de la serie. Mismo alcance y criterio que las
rondas anteriores, con especial atención (pedido explícito del usuario) a bugs de QA reportados
dentro de los propios tickets de la ME. **Este padre rompe el patrón de las 3 rondas anteriores:
tiene 2 bugs de QA reales**, no solo defectos de desarrollo/infra. No se hicieron consultas a
Sybase/REST/gRPC, no se reejecutó nada, no se modificó Jira/QMetry/motor/repos/ME.

## 1. Identidad y relación de tickets (OBSERVADO en Jira)

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1175 | Story | Padre | Consulta de condiciones en base a cuenta |
| NCBE-1224 | Task | Pipeline (relates to) | Análisis de Stored procedure — firmas.pa_fir_consulta_condicion |
| NCBE-1225 | Task | Pipeline (relates to) | Creación de casos de prueba funcionales y estructurales |
| NCBE-1226 | Task | Pipeline (relates to) | Consolidación de casos de prueba |
| NCBE-1261 | Task | Pipeline (relates to) | Generación de datos para casos de prueba |
| **NCBE-1264** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — firmas.pa_fir_consulta_condicion** |
| NCBE-2859 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance, no tocado |

SP: `firmas.pa_fir_consulta_condicion`. Micro: `cpas-mso-fir-consulta-condicion`. Ya conocido de
sesiones previas (ver memoria `project_qmetry_reexec_ncbe1175` y `project_queryplan_ncbe1175_tasks`)
pero reconstruido aquí desde cero contra Jira para esta serie.

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

NCBE-1175 tiene 12 subtareas: 2 **Defecto** que SÍ son de QA (sección 2.1), y 5 más (`Sub-task` tipo
checklist + 3 de dependencias/calidad de código, sección 2.2) que NO lo son.

### 2.1 — Bugs de QA reales (profundizado)

#### NCBE-1637 — URL inválida para ejecución de REST y gRPC → **QA — defecto real de evidencia/herramienta**

- **Reportado por Banco DESDE la propia revisión de la ME** (confirmado leyendo el comentario de
  Yamilet Cisneros en NCBE-1264, 13-ago: "Se valida la MT de equivalencia entregada y presenta url
  inválida... Se crea defecto NCBE-1637"). Evidencia real inspeccionada: el `curl` de REST en la
  ME mostraba `https://localhost:18444/api/v1/firmas/condiciones/consultas`; al reproducirlo
  literalmente en Postman, Banco obtuvo `Error: connect ECONNREFUSED 127.0.0.1:18444` — el puerto
  era un túnel de port-forward local de quien generó la evidencia, no una ruta alcanzable desde
  fuera.
- **Corrección (mismo día, Gengis Hidalgo):** "se regeneró la evidencia... los comandos REST/gRPC
  ahora muestran las rutas correctas del ambiente." **Verificado en esta ronda, no solo citado:** el
  campo `curl_command`/`grpc_command` de cada TC en las versiones posteriores (08-13, 08-14, 08-18)
  sí muestra la ruta real desplegada
  (`https://cpas-mso-fir-consulta-condicion-bb-dev-core.apps.ocpbbdevqantx.desabbol.fin.ec/...`) — el
  síntoma que Banco reportó (comando no reproducible) quedó resuelto.
- **Residual encontrado en esta ronda, nunca reportado por nadie (ver PR12):** el campo de
  **metadata** de cabecera (`metadata.base_url` / `metadata.grpc_host`, no el comando por TC) sigue
  mostrando `localhost` en **todas** las versiones inspeccionadas — `https://localhost:18444` (08-12,
  previo al fix), `https://localhost:18445` (08-13, la versión "ya corregida" que cerró NCBE-1637) y
  `https://localhost:18480` (08-18, la versión final tras el fix de decimales). El número de puerto
  cambia entre corridas (confirma que es un túnel real de esa sesión, no un valor fijo hardcodeado),
  pero el host nunca se corrigió a la ruta real en ningún corte. No rompe reproducibilidad (Banco usa
  el comando por TC, no el metadata), por eso nadie lo marcó — pero es un residual real del mismo
  defecto, nunca cerrado del todo.
- **Clasificación:** QA — defecto de herramienta/evidencia, real, corregido en lo que importaba
  para Banco; con un residual cosmético sin cerrar.

#### NCBE-1644 — No se maneja monto con decimales en REST/gRPC/SP → **QA — defecto real de representación, con cambio de contrato acordado con Banco**

- **Reportado por Banco** (13-ago, con capturas): montos con decimales en BD no se reflejaban en la
  respuesta REST ni en la ejecución del SP; gRPC sí los reflejaba.
- **Investigación real (Gengis, mismo día):** no encontró pérdida de precisión en valores
  distintos de cero (123.45 se conservaba como 123.45, 123.4567 como 123.4567 en REST y gRPC); lo
  que no se conservaba eran los **ceros finales de formato** (0.00 podía verse como 0.0 o 0).
  Preguntó explícitamente si la validación exigía 2 decimales visibles siempre o solo equivalencia
  numérica — **pregunta correcta, no asumió la respuesta.**
- **Ciclo de negociación del contrato con Banco (reconstruido cronológicamente, con giros reales):**
  1. Priscila Pincay (13-ago): los campos son `money`, deben mostrarse a 2 decimales fijos.
  2. Nicolas Rodríguez Mejía carga una ME corregida (14-ago) con REST/gRPC ya a 2 decimales.
  3. Yamilet Cisneros valida REST/gRPC OK, pero **señala que la ejecución del SP seguía con el
     mismo problema** (14-ago) — el fix no había llegado a la captura directa del SP todavía.
  4. Nicolas Rodríguez Mejía (18-ago) anuncia un **cambio de metodología del lado QA**: antes se
     aplicaba "el mismo tipo de parseo" a los resultados leídos de Sybase (causa del síntoma
     reportado); desde ese momento se entregan los numéricos **tal cual los retorna Sybase, sin
     parseos ni ajustes**, y la comparación se hace sobre los decimales que entrega el
     microservicio (2 o 4 según tipo de dato). Comparte una ME nueva.
  5. Priscila Pincay (24-ago) reporta una respuesta de Banco que **parece contradecir lo anterior**:
     "se requiere se muestren todos los decimales que devuelva la BD" (en vez de fijar 2).
  6. Giorgi Torres (27-ago), con un correo formal adjunto ("Correo confirmacion de decimales.pdf"),
     fija el **contrato final por escrito**: Sybase retorna tal cual está guardado (`"0.00"` o
     `"0.0000"`, ambos correctos); REST y gRPC retornan **siempre 2 decimales**, redondeando si hay
     más; las operaciones reales siempre usan el valor completo de Sybase — REST/gRPC es solo
     visual.
  7. Verificado en esta ronda, con datos reales de la ME del 18-ago (antes incluso del correo
     formal del 27-ago, pero ya coincide con el contrato): SP `MontoDesde: "0.0000"` vs REST
     `montoDesde: "0.00"` — exactamente el contrato que se formalizaría 9 días después.
  8. Yamilet Cisneros pide un `.proto` nuevo (27-ago) porque el que usaban no coincidía con los
     datos ya correctos de la ME; Giorgi lo comparte el mismo día; Yamilet valida (28-ago); Priscila
     cierra NCBE-1264 el mismo día.
- **Clasificación:** QA — defecto real de representación/formato, resuelto con un cambio de
  metodología de captura (no parsear/ajustar decimales leídos de Sybase) y un contrato final
  formalizado por correo. Ver PR13 (no tratar una respuesta intermedia de Banco como la regla
  definitiva).
- **Verificado en el registro consolidado de fixes del motor** (`.claude/docs-qa/to-do-context/jp/MOTOR-QA_fixes_sesion_agosto2026.md`,
  solo lectura puntual): **no hay ninguna entrada sobre decimales/money ni sobre localhost/base_url.**
  Ninguno de los dos fixes de esta ronda (NCBE-1637 ni NCBE-1644) quedó registrado como corrección
  genérica del motor compartido — ambos se resolvieron como recaptura puntual de este SP. Ver PR15.

### 2.2 — El resto, NO es QA

- **NCBE-4464** — "Error de compilación al consumir librería pa-fir-consulta-condicion-utils 1.0.1"
  (Sub-task). **Mismo patrón exacto que NCBE-4357 de la ME #3** (SP hermano
  `pa_fir_consulta_con_especial`): la clase `Money` se movió a `pa-fir-consulta-commons-utils` y el
  micro seguía importándola del paquete viejo; corregido actualizando import y versión. Commit
  `20183ef`. Creado 2026-10-12, **2 meses después** del cierre de NCBE-1264 (28-ago) — igual que en
  la ME #3, cronológicamente no podía reflejarse en la ME (PR09).
- **NCBE-4363** — "Novedades en SonarQube" (Sub-task). Mismo defecto `java:S1192` de PR08, corregido
  de una sola vez en **3 microservicios hermanos** (`cpas-mso-fir-consulta-condicion` commit
  `20183ef`, `cpas-mso-fir-consulta-especial` commit `22444c3`, `cpas-mso-fir-consulta-fir-especial`
  commit `8e857c2`) — confirma PR08 con un tercer SP de la misma familia.
- **NCBE-4499** — "Novedades en unit test" (Sub-task). **Atribución dudosa/probable error de
  archivado:** su descripción y el comentario de cierre hablan íntegramente del repo
  `cpas-mso-fir-consulta-fir-especial` (un microservicio DISTINTO, de otra Story hermana), no de
  `cpas-mso-fir-consulta-condicion`. Está archivado como subtarea de NCBE-1175 pero su contenido no
  corresponde a este padre. No se trató como evidencia de este SP — ver PR14.

## 3. Hallazgo principal de esta ronda

**A diferencia de las ME #1-#3, este padre SÍ tiene bugs de equivalencia/evidencia QA reales**
(NCBE-1637, NCBE-1644), ambos reportados por Banco directamente durante la revisión de la propia ME
(NCBE-1264), investigados por el equipo QA con rigor (Gengis pidiendo aclaración antes de asumir,
nunca forzando el resultado), y cerrados con evidencia verificable. El resto de subtareas del padre
siguen el mismo patrón NO-QA ya visto en las rondas anteriores (arquitectura/SonarQube/dependencias
de librería), con una de ellas (NCBE-4499) probablemente mal archivada.

## 4. Contraste con la ME final (NCBE-1264) — hallazgo importante sobre dónde vive el artefacto final

- **El adjunto final de NCBE-1264 está desactualizado respecto al cierre real de la ME.** Los 2
  JSON adjuntos a NCBE-1264 son del 12-ago (90332 bytes, previo a ambos fixes) y del 13-ago (158605
  bytes — URL corregida, pero decimales **todavía rotos**: verificado `MontoDesde: 0.0` tanto en SP
  como en REST, tipo numérico plano, sin preservar ni 2 ni 4 decimales). **El contenido realmente
  final y conforme al contrato de decimales (sección 2.1) nunca se volvió a subir a NCBE-1264** —
  vive como adjunto de **NCBE-1644** (`QA-CASOS-PARSEADOS (6966da95...).json`, 18-ago, 160347 bytes,
  SHA-256 `bab05b0a...`), junto con el `.proto` final (27-ago, también en NCBE-1644). NCBE-1264 se
  cerró el 28-ago citando "se verifica la ejecución y respaldo de los TC's" con 2 capturas de
  pantalla, pero sin re-adjuntar el JSON/proto definitivos al propio ticket de revisión. Ver PR11 —
  es el hallazgo más importante de esta ronda para el aprendizaje del piloto.
- **Universo confirmado desde la versión real final (NCBE-1644, 18-ago):** 7 TCs, 2 grupos, **7/7
  EQUIVALENTE**, 7 STATELESS / 0 STATEFUL.
- **Evidencia de cierre cruzada con QMetry (hallazgo nuevo sobre una ambigüedad ya documentada
  antes):** las 2 capturas de pantalla con las que Priscila cerró NCBE-1264 (28-ago) son de
  **QMetry, cycle `NCBE-TR-15` ("pa_fir_consulta_condicion — Suite Equivalencia BBOL")**, 7/7 `Pass`
  (TC241-247, con adjuntos `TC02.sql`/`TC06.sql` subidos por Yamilet Cisneros Plaza el mismo día).
  Esto es relevante porque mi propia sesión de QMetry de esta misma HU (ver memoria
  `project_qmetry_reexec_ncbe1175`) había señalado `NCBE-TR-15` como **posible duplicado** de
  `NCBE-TR-14` (mismo universo de 7 TC keys, mismo folder, `WARN: DUPLICATE_CYCLE` del
  `execution_checker.py`) y dejó pendiente para el usuario decidir si era un duplicado a limpiar o un
  cycle legítimo con otro propósito. **Esta ronda aporta evidencia a favor de la segunda opción:**
  la propia Banco (Priscila/Yamilet) usó específicamente el cycle "BBOL" (`NCBE-TR-15`) como
  respaldo formal de cierre de la ME — sugiere que es el cycle cara a Banco, mientras `NCBE-TR-14`
  pudo ser la corrida interna de QA. No se resuelve aquí (requiere decisión del usuario, igual que
  antes), pero se deja registrada la evidencia nueva en la memoria correspondiente.

## 5. Patrones agrupados por causa o comprobación reusable (nuevos de esta ronda)

### PR11 — El artefacto final de una ME puede quedar adjunto al ticket del BUG hijo, no al ticket de revisión (NUEVO, el hallazgo más importante de esta ronda)

- **Evidencia:** NCBE-1264 (HU de revisión) quedó con el JSON/proto del 13-ago; el JSON/proto
  realmente final y conforme al contrato quedaron adjuntos solo en NCBE-1644 (18-ago/27-ago).
- **Comprobación reusable:** antes de tomar el adjunto de la HU de revisión como "la ME final", si
  hubo bugs hijos resueltos durante el ciclo, revisar también los adjuntos de **esos bugs** —
  pueden contener una versión más nueva que nunca se re-subió al ticket padre de revisión. Comparar
  fechas de adjuntos entre la HU y sus bugs, no asumir que el más reciente está siempre en la HU.

### PR12 — Un defecto de URL/ruta puede quedar "cerrado" a nivel de síntoma reproducible sin cerrar a nivel de metadata de cabecera (NUEVO)

- **Evidencia:** el `curl_command`/`grpc_command` por TC de NCBE-1637 se corrigió y se mantuvo
  correcto en todas las versiones posteriores; el campo `metadata.base_url`/`metadata.grpc_host`
  nunca se corrigió en ninguna versión inspeccionada (08-12, 08-13, 08-18), solo cambió de número de
  puerto entre corridas.
- **Comprobación reusable:** al revisar el cierre de un defecto de URL/ruta en una ME, verificar
  tanto el nivel de comando reproducible por TC como el nivel de metadata de cabecera — son dos
  lugares distintos donde el mismo dato puede vivir, y uno puede quedar sin corregir sin que nadie
  lo note porque no rompe la reproducibilidad que Banco valida.

### PR13 — No tratar una respuesta intermedia de Banco como el contrato definitivo hasta que haya confirmación formal (NUEVO)

- **Evidencia:** Banco dijo primero "2 decimales fijos" (13-ago), luego aparentemente lo contrario,
  "mostrar todos los decimales de BD" (24-ago), hasta fijar el contrato final por correo formal
  (27-ago): Sybase tal cual, REST/gRPC siempre a 2 decimales (redondeando), operaciones reales sobre
  el valor completo.
- **Comprobación reusable:** cuando Banco da lineamientos sobre un criterio de representación en
  una conversación de ticket, esperar una confirmación marcada explícitamente como conclusión
  (correo adjunto, comentario que cite el acuerdo final) antes de tratarla como el contrato vigente
  — un comentario intermedio puede ser superado por uno posterior sin que se anuncie como corrección
  del anterior.

### PR14 — Verificar que el contenido de una subtarea realmente corresponda a su padre declarado (NUEVO)

- **Evidencia:** NCBE-4499 está archivada bajo NCBE-1175 (`pa_fir_consulta_condicion`) pero su
  contenido completo (descripción y comentario de cierre) habla del repo
  `cpas-mso-fir-consulta-fir-especial`, un microservicio de otra Story hermana.
- **Comprobación reusable:** no asumir que el contenido de una subtarea aplica al SP del padre solo
  porque está archivada ahí — leer el texto y confirmar que el repo/micro mencionado coincide antes
  de usarla como evidencia de ese SP.

### PR15 — Un fix puntual de ME no implica un fix del motor compartido; verificar el registro consolidado antes de asumir cobertura genérica (NUEVO)

- **Evidencia:** ni el defecto de URL/metadata (NCBE-1637/PR12) ni el de decimales (NCBE-1644)
  aparecen en `MOTOR-QA_fixes_sesion_agosto2026.md` — ambos se resolvieron como recaptura puntual
  de este SP, no como cambio de código en los scripts compartidos.
- **Comprobación reusable:** si el mismo síntoma (URL de localhost en evidencia, o decimales/money
  sin preservar) aparece en una ME de un SP hermano de esta familia (`pa_fir_consulta_*`), no asumir
  que ya está resuelto a nivel de motor — revisar el registro consolidado primero; si no está ahí,
  es muy probable que haya que resolverlo otra vez puntualmente para ese SP.

## 6. Lo que no se pudo verificar / queda pendiente

- No se puede determinar desde Jira únicamente si el cambio de metodología de decimales
  ("entregar tal cual Sybase, sin parseos") implicó algún cambio de código en los scripts QA
  compartidos — no hay commit citado en el ticket y el registro consolidado del motor no lo
  menciona (sección 2.1/PR15); requeriría revisar el script de lectura/captura directamente, fuera
  de alcance de esta ronda (solo Jira + adjuntos).
- La ambigüedad `NCBE-TR-14` vs `NCBE-TR-15` en QMetry sigue sin resolución explícita del usuario;
  esta ronda solo aporta evidencia nueva a favor de que `NCBE-TR-15` sea el cycle cara a Banco (ver
  sección 4) — no se tocó QMetry en esta ronda.
- No se descargó/leyó el PDF "Correo confirmacion de decimales.pdf" en detalle — el comentario de
  Giorgi Torres (27-ago) ya resume su contenido de forma suficientemente precisa y verificable contra
  los datos reales de la ME.
- `report_sp_structure_templateV2.html` (adjunto a NCBE-1264) no se inspeccionó en detalle.

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1175 (campos + 12 subtareas + 6 issuelinks "relates to");
  NCBE-1264 (campos + 7 adjuntos + 6 comentarios); NCBE-1637 (campos + 1 comentario + 4 adjuntos,
  2 imágenes abiertas); NCBE-1644 (campos + 10 comentarios + 13 adjuntos); NCBE-4464/4363/4499
  (campos + comentarios).
- **Verificación de hash/contenido:** JSON del 12-ago, 13-ago (NCBE-1264) y 18-ago (NCBE-1644)
  descargados temporalmente a `/tmp` (nunca al repo), comparados campo a campo
  (`metadata.base_url`, `sp_output`/`rest_output` de montos), hash del 18-ago registrado
  (`bab05b0a5dd9eb5dd3a32933caf815fe7f7d46e4a9747aa27ad71ea77ff5cb5d`), todo borrado tras el uso.
  Las 2 capturas de cierre de NCBE-1264 y las 2 capturas originales de NCBE-1637 se visualizaron
  directamente (imágenes), también borradas tras el uso.
- **Consulta puntual fuera de Jira (justificada):** un solo `grep` de palabras clave sobre
  `MOTOR-QA_fixes_sesion_agosto2026.md` (registro ya conocido por memoria previa) para confirmar si
  alguno de los 2 bugs de QA de esta ronda tenía un fix genérico documentado — no lo tenía (PR15).
  No se abrió ningún script del motor.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #4** de la serie. Ver índice `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`. Pendiente:
  el usuario indicará el siguiente ticket padre y su HU.

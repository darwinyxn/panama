# Aprendizaje personal piloto gengis-me — ME #7: sp_cnb_consulta_saldo (NCBE-1169 → NCBE-1649)

Fecha de esta ronda: 2026-10-30. Séptima entrega de la serie. **Esta ronda combina la
reconstrucción vía Jira con memoria propia de una sesión anterior de cierre de este mismo SP**
(`project_sp_cnb_consulta_saldo_tc_loop.md`) — el cruce entre ambas fuentes revela un límite
metodológico real de esta serie (ver PR24). Esta es también la segunda ME que NO se mantiene
100% EQUIVALENTE a lo largo del tiempo (aunque sí lo estaba al momento de su cierre formal). No se
hicieron consultas a Sybase/REST/gRPC, no se reejecutó nada, no se modificó Jira/QMetry/motor/
repos/ME; se verificaron puntualmente 7 commits del motor QA ya citados en memoria propia (`git
log`, solo lectura).

## 1. Identidad y relación de tickets (OBSERVADO en Jira)

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1169 | Story | Padre | Consulta y cobro comisión por el saldo de cuenta |
| NCBE-1646 | Task | Pipeline (relates to) | Análisis de Stored procedure — cob_cuentas.sp_cnb_consulta_saldo |
| NCBE-1647 | Task | Pipeline (relates to) | Consolidación de casos de prueba |
| NCBE-1648 | Task | Pipeline (relates to) | Creación de casos de prueba funcionales y estructurales |
| **NCBE-1649** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — cob_cuentas.sp_cnb_consulta_saldo** |
| NCBE-1650 | Task | Pipeline (relates to) | Generación de datos para casos de prueba |
| NCBE-2862 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance, no tocado |

SP: `cob_cuentas.sp_cnb_consulta_saldo`. Micro: `cnb-mso-sp-consulta-saldo`. SP con 2 hijos
relevantes (de memoria propia, no de Jira): `sp_cnb_consulta_comision` (ruta consulta, `e_tipo='C'`)
y `sp_cnb_pago_comision` (ruta pago, cualquier otro valor de `e_tipo`).

**Confirmación cruzada:** NCBE-1649 es exactamente el ticket que, en la ME #6
(`NCBE-1177-NCBE-1705-...ME06.md`), Giorgi Torres señaló como la "tarea correcta" a donde se movió
el adjunto de `sp_cnb_consulta_saldo` que por error había llegado a NCBE-1705. Confirmado aquí por
hash: el único JSON adjunto a NCBE-1649 (`QA-CASOS-PARSEADOS (9).json`, 525829 bytes, SHA-256
`bd86a5dd752c28c987b875420e12a4a2baf042779a27c3230ab1d6e987a55d4a`) es **byte-idéntico** al que se
había adjuntado por error a NCBE-1705 — cierra ese círculo con evidencia completa en ambos
extremos.

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

NCBE-1169 tiene 15 subtareas; 6 son tipo **Defecto**, todas con contenido real (a diferencia de
rondas anteriores, ninguna es un placeholder vacío). El resto son `Sub-task` de checklist sin
contenido de bug.

### NCBE-1609 — "Novedad en prueba consulta de microservicio" → **FALSO POSITIVO (uso de la prueba, no defecto)**

- Banco envió el request con campos en camelCase (`eSsn`, `eCanal`...); el contrato OpenAPI exige
  snake_case con prefijo (`e_ssn`, `e_canal`...) — el servicio no recibía `@e_ssn` y respondía -6.
  Con los nombres correctos, respuesta exitosa esperada.
- Segunda vuelta: con los nombres corregidos, Banco reportó "fondos insuficientes" cuando esperaba
  éxito — resultó ser que el SP decide internamente consulta vs. pago según `e_tipo`; sin
  `e_tipo='C'`, toma la ruta de pago (que sí puede rechazar por fondos). Con `e_tipo='C'` explícito,
  la respuesta coincidió exactamente con el SP.
- **Clasificación:** falso positivo doble — error de formato de payload, luego de parámetro de
  ruta — ambos resueltos por aclaración, sin ningún cambio de código.

### NCBE-1755 — "Novedad en dependencias del microservicio: jacoco" → **NO ES QA (build/entorno, causa nunca confirmada)**

- El build de Banco fallaba el gate de cobertura JaCoCo (branches 0.93, methods 0.99); el mismo
  commit, corrido limpio del lado de desarrollo, daba 100%. Tras pedir detalles de entorno
  (versión de Java, totales exactos, commit), Banco simplemente reportó que "ya se realiza sin
  novedad" — la causa de fondo nunca se confirmó (candidato: build incremental/artefactos stale del
  lado de Banco, nunca verificado).
- **Clasificación:** NO-QA, entorno de build; cerrado sin diagnóstico definitivo.

### NCBE-1948 — "Novedad de ejecución de casos" → **FALSO POSITIVO, pero síntoma de un problema de fondo real (ver sección 4)**

- Error `Msg 2601`/duplicate key en `cc_tran_servicio` al ejecutar un caso — Juan Pablo Sanabria
  explicó que el `@e_ssn` usado ya estaba registrado de una ejecución previa; la solución fue usar
  un valor nunca probado. Banco aceptó la explicación y cerró.
- **Clasificación superficial (solo con lo que dice el ticket): falso positivo** — dato de prueba
  reusado, no defecto del sistema. **Pero ver sección 4:** esta misma causa de fondo (unicidad de
  secuencial compartida entre ejecuciones) ya había sido diagnosticada y parcialmente corregida por
  el propio equipo QA el día anterior — la reconstrucción completa solo es visible cruzando con
  memoria propia, no con este ticket aislado.

### NCBE-2188 — "Novedad no se registra contabiliza impuesto" → **QA real, confirmado y corregido en 2 rondas**

- **Ronda 1:** la deflactación de IVA (fila en `cob_cuentas..cc_tran_servicio`) se insertaba sin
  control de transacción propio — no se confirmaba en base y se perdía, mientras el débito sí
  quedaba registrado (por un procedimiento que confirma internamente). Corregido encapsulando la
  escritura del IVA en su propia transacción (`sp-cont-impuesto-utils` 1.0.12-snapshot, commit
  `672dfcf`).
- **Ronda 2 (regresión parcial detectada por Banco tras la ronda 1):** la fila de IVA ya se
  persistía, pero con la fecha/hora de **proceso** en el campo `ts_hora` en vez de la hora real del
  servidor — por eso, al consultar por "hoy", el débito aparecía y el registro de IVA no (aunque sí
  existía). Corregido usando `getdate()` para `ts_hora`, igual que el SP (`sp-cont-impuesto-utils`
  1.0.13-snapshot, commit `3a526c3`). Verificado por Banco con capturas de Sybase (cuenta corriente
  y ahorros, ambos movimientos monetario + IVA registrados con la hora correcta).
- **Clasificación:** QA real — defecto financiero confirmado (pérdida silenciosa de registro
  contable de IVA), corregido y verificado con evidencia directa de base de datos.

### NCBE-2193 — "mvn site no genera pdf y versión de package" → **Mayormente NO ES QA (build/registry/red), con 1 fix de código menor**

- Tres hilos distintos bajo el mismo ticket: (1) generación del PDF de `mvn site` — no reproducible
  por desarrollo, resuelto sin causa confirmada; (2) versión de paquete "fantasma" —
  `sp-cnb-consulta-saldo-utils:1.0.6-snapshot` visto en GitHub Packages resultó ser un **paquete
  duplicado publicado por error bajo el groupId equivocado** (`org.apache.commons` en vez de
  `com.bolivariano.cob-cuentas`), que ningún proyecto consume — no era una desalineación real del
  pom; (3) **fix de código real pero menor:** un test (`GrpcTlsConfigTest`) usaba una ruta fija
  estilo Unix (`/tmp/...`) que Windows no reconoce como absoluta, rompiendo el build solo en
  máquinas Windows — corregido aceptando también el directorio temporal del sistema
  (`java.io.tmpdir`); (4) un error transitorio de red/SSL contra el registry, no relacionado con
  código.
- **Clasificación:** NO-QA — build/tooling/registry/red; el único fix de código real es
  cross-platform, sin relación con comportamiento SP↔microservicio.

### NCBE-2717 — "Secuencial repetido no tiene control" → **QA real, confirmado y corregido**

- Al reenviar el mismo secuencial en la ruta de pago, el SP-directo rechaza correctamente con
  código funcional `33005` ("ERROR EN INSERCION DE TRANSACCION DE SERVICIO"); el microservicio, en
  el mismo caso, escalaba a **HTTP 500 genérico** sin el detalle funcional. Dev preguntó
  explícitamente a Banco cuál era el comportamiento esperado (33005 explícito, o éxito silencioso) —
  Banco confirmó que debía ser 33005 igual que el SP. Corregido capturando la excepción de inserción
  duplicada y traduciéndola al código de negocio 33005 (commit `6e2a29d`), verificado por Banco.
- **Clasificación:** QA real — divergencia de canal de error (HTTP 500 vs. código funcional),
  confirmada y corregida. Confirma el patrón P03/C03 de `BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md`
  ("canales de error distintos") con un caso nuevo.

## 3. Hallazgo principal de los bugs del padre

A diferencia de las 6 rondas anteriores, **este padre tiene bugs de QA genuinamente reales (NCBE-2188,
NCBE-2717), más dos falsos positivos bien documentados (NCBE-1609, NCBE-1948) que valen la pena
distinguir explícitamente de los reales** — exactamente la clasificación que esta serie busca
hacer. NCBE-1755/2193 confirman, una vez más, el ruido NO-QA de build/entorno ya visto en toda la
serie.

## 4. Cruce con memoria propia de una sesión de cierre anterior (NCBE-1169, 25/26-ago-2026) — revela un límite metodológico

Al consultar memoria propia (`project_sp_cnb_consulta_saldo_tc_loop.md`, sesión previa a esta
serie) para contrastar, aparecen **hechos verificados que no están, ni podrían estar, en ninguno de
los 6 tickets de la sección 2**:

- **El mismo día de la ME (26-ago), el equipo QA interno ya había diagnosticado y corregido a nivel
  de MOTOR** la causa de fondo detrás de NCBE-1948 (colisión de `@e_ssn`/secuencial entre
  ejecuciones repetidas, en 3 tablas: `cc_tran_servicio`/`ah_tran_servicio` y, descubierta en la
  última vuelta, `cob_cuentas..cc_t_informacion_cnb`). **Verificado en esta ronda:** los 7 commits
  citados en esa memoria (`5b5a47a2`, `37693bd f`, `130586de`, `9c458d94`, `f5f3b5d4`, `92551c70`,
  `e3f693a8`) existen realmente en este repo (`git log`). El fix (`regenerar_session_id_si_aplica`
  + `SESSION_ID_REGENERATE_ALLOWLIST`) resuelve la colisión **solo para las corridas propias del
  motor QA** (regenera `@e_ssn` distinto por canal SP/REST/gRPC) — **no protege pruebas manuales
  independientes de Banco** que reutilicen un `@e_ssn` ya consumido por una corrida de QA. **NCBE-1948,
  creado un día después (27-ago), es exactamente esa situación:** Banco reutilizó manualmente un
  secuencial ya gastado por el motor QA. Ver PR25.
- **Un defecto real, confirmado y corregido, que NUNCA se filed como "Defecto" en Jira bajo
  NCBE-1169:** la misma memoria describe un "Hallazgo 1" (`SpCnbConsultaSaldoLibrary.ramaPago()`
  hardcodeaba `oCodRespuesta=RETURN_OK` en vez de propagar el código real del hijo cuando éste
  retornaba éxito técnico con un código de negocio distinto de 0 — afectaba TC11/TC25) corregido
  por commit `c6744d0` en el repo de la librería (`bb-core-cob-cuentas-utils`), atribuido a "otra
  sesión/el usuario". **Ninguno de los 6 tickets Defecto de la sección 2 lo menciona.** Ver PR24 —
  es el hallazgo metodológico más importante de esta ronda.
- **Un defecto diagnosticado pero NO resuelto en esa sesión interna, que reaparece como NCBE-2717
  casi un mes después:** la misma memoria describe un "Hallazgo 2" (HTTP 500 sin control cuando el
  pago tiene éxito real con dinero, por una excepción de inserción duplicada que cae al catch-all
  genérico) — diagnosticado el 25-ago pero **"no localizada la línea exacta... necesitaría logs
  reales"**, es decir, quedó abierto internamente. El mecanismo es el mismo que describe NCBE-2717
  (17-sep): excepción de inserción duplicada no traducida a código de negocio, HTTP 500 genérico.
  Es razonable que sea el mismo hilo, retomado por Banco de forma independiente casi un mes
  después y finalmente cerrado por dev en esa fecha — no se puede confirmar con 100% de certeza que
  sea EXACTAMENTE el mismo caso (la memoria no cita número de ticket), pero el mecanismo descrito
  coincide.

## 5. Contraste con la ME final (NCBE-1649)

- **Universo:** 31 TCs, 3 grupos, **31/31 EQUIVALENTE** — `fecha_generacion` del JSON:
  `2026-08-26T17:02:30` — coincide EXACTAMENTE con la "8va corrida ('1702'): CIERRE TOTAL 2026-08-26"
  de la memoria propia. Es decir: el archivo adjunto a NCBE-1649 es, confirmado, el snapshot exacto
  del cierre interno de esa sesión — no una versión distinta ni posterior.
- **Lo que la ME NO refleja (porque ocurrió después de su generación):** NCBE-2188 (creado 02-sep,
  6 días después) y NCBE-2717 (creado 14-sep, 19 días después) son defectos reales encontrados por
  Banco en su propia validación posterior a la entrega — **fuera del universo de los 31 TCs
  originales**, no fallos de alguno de esos 31 TCs. Ninguna versión más nueva de la ME fue
  re-adjuntada a NCBE-1649 después de esos fixes (único adjunto: el del 27-ago). El cierre de esos
  2 hallazgos vive solo en los comentarios/capturas de sus propios tickets, nunca en un artefacto
  de ME republicado. Ver PR23 — relacionado con PR11 (ME #4) pero distinto: aquí no hay una versión
  más nueva "perdida" en otro ticket, simplemente nunca se generó una ME nueva que incorporara estos
  2 fixes.

## 6. Patrones agrupados por causa o comprobación reusable (nuevos de esta ronda)

### PR23 — N/N EQUIVALENTE no garantiza ausencia de defectos reales fuera del universo de TCs original (NUEVO)

- **Evidencia:** 31/31 EQUIVALENTE el 26-ago; 2 defectos reales (NCBE-2188, NCBE-2717) encontrados
  por Banco semanas después, en escenarios fuera de los 31 TCs certificados.
- **Comprobación reusable:** al evaluar el estado de una ME ya cerrada, buscar también bugs
  creados DESPUÉS de su fecha de cierre bajo el mismo padre — pueden ser hallazgos reales de
  validación posterior de Banco, no ruido. No asumir que "ya cerró N/N" significa que no hay nada
  más que revisar.

### PR24 — La reconstrucción basada solo en Jira tiene un límite real: no todo bug confirmado pasa por un "Defecto" formal (NUEVO, el hallazgo más importante de esta ronda para la metodología de la serie)

- **Evidencia:** un defecto real, diagnosticado con código exacto y corregido con commit verificable
  (`c6744d0`, `ramaPago()`/`oCodRespuesta`) nunca se filed como "Defecto" bajo NCBE-1169 — solo
  existe en memoria propia de la sesión de cierre, resuelto por coordinación directa QA↔desarrollo.
- **Comprobación reusable:** cuando exista memoria propia o documentación local de una sesión de
  cierre de la ME en cuestión, cruzarla SIEMPRE contra los tickets Jira del padre antes de concluir
  "no hubo más bugs reales" — Jira solo puede subestimar el número real de defectos encontrados y
  corregidos. Esta es una limitación de alcance de toda la serie, no solo de esta ronda.

### PR25 — Un fix de motor que resuelve una colisión de datos para las corridas propias de QA no protege las pruebas manuales independientes de Banco (NUEVO)

- **Evidencia:** el fix de regeneración de `@e_ssn` por canal (25/26-ago) resuelve la colisión
  solo dentro de una corrida de 3 canales del propio motor QA; al día siguiente, Banco reutilizó
  manualmente un secuencial ya consumido y obtuvo el mismo síntoma (NCBE-1948), reportado como bug
  nuevo.
- **Comprobación reusable:** si aparece un reporte de "duplicate key"/secuencial repetido después de
  que el motor QA ya corrió sus propios casos, verificar primero si Banco reusó un valor de prueba
  ya consumido antes de escalarlo como regresión — puede ser el mismo patrón de datos compartidos,
  no un defecto nuevo.

## 7. Lo que no se pudo verificar / queda pendiente

- No se abrió el repo `bb-core-cob-cuentas-utils` para verificar el commit `c6744d0` directamente
  (otro repo, fuera de los artefactos de esta ronda) — se confirma solo por la consistencia interna
  de la memoria propia (síntoma, código citado con archivo/método/línea aproximada, TCs afectados).
- No se encontró ni se buscó a fondo una versión de la ME posterior al 26-ago que incorporara los
  fixes de NCBE-2188/NCBE-2717 — solo se confirmó que NCBE-1649 no tiene más de un adjunto.
- No se confirmó con certeza al 100% que el "Hallazgo 2" de la memoria propia (25-ago, sin línea
  exacta) y NCBE-2717 (17-sep) sean el mismo caso — es una inferencia razonada por coincidencia de
  mecanismo (excepción de inserción duplicada → HTTP 500 sin traducir), no una confirmación textual
  cruzada.
- `consulta_saldo.proto` (adjunto a NCBE-1649) no se inspeccionó en detalle.

## 8. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1169 (campos + 15 subtareas + 6 issuelinks "relates to");
  NCBE-1649 (campos + 2 adjuntos + 1 comentario); NCBE-1609/1755/1948/2188/2193/2717 (campos +
  todos sus comentarios completos).
- **Verificación de hash:** el único JSON de NCBE-1649 descargado temporalmente a `/tmp` (nunca al
  repo), hash y `metadata` verificados (31 TCs, 31/31 EQUIVALENTE, `fecha_generacion`
  `2026-08-26T17:02:30`), confirmado byte-idéntico al adjunto equivocado de NCBE-1705 (ME #6).
  Borrado tras el uso.
- **Memoria propia consultada (fuente explícita, no Jira):** `project_sp_cnb_consulta_saldo_tc_loop.md`
  — sesión de cierre de este mismo SP, 2026-08-25/26, previa a esta serie. Se citan únicamente los
  hechos con commit/archivo/línea ya verificados en esa memoria; **se verificaron puntualmente 7
  commits del motor QA citados ahí con `git log --oneline --all`** (todos existen, confirmados).
  No se verificó el commit `c6744d0` (otro repo).
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central (solo se leyó su historial de commits ya existente, no se modificó nada). No se
  hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #7** de la serie. Ver índice `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`. Pendiente:
  el usuario indicará el siguiente ticket padre y su HU.

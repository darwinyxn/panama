# Aprendizaje personal piloto gengis-me — ME #2: sp_ah_retiro_rc (NCBE-1109 → NCBE-1126)

Fecha de esta ronda: 2026-10-30. Segunda entrega de la serie "una ME a la vez". Mismo alcance y
criterio que la ME #1 (ver `NCBE-1105-NCBE-1117-pa_fir_consulta_firmante-ME01.md`): ticket padre +
bugs directamente enlazados + la HU indicada con su ME final y artefactos. Esta ronda además revisó
explícitamente los comentarios de la propia HU de revisión (NCBE-1126) en busca de reportes de bug
dentro del ciclo de ME, y usó una búsqueda de texto amplia como control de que no quedara ningún
enlace directo sin cubrir. No se hicieron consultas a Sybase/REST/gRPC, no se reejecutó nada, no se
modificó Jira/QMetry/motor/repos/ME.

## 1. Identidad y relación de tickets (OBSERVADO en Jira)

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1109 | Story | Padre | Retiro y Nota débito con libreta |
| NCBE-1110 | Task | Pipeline (relates to) | Análisis de Stored procedure — cob_ahorros.sp_ah_retiro_rc |
| NCBE-1124 | Task | Pipeline (relates to) | Creación de casos de prueba funcionales y estructurales |
| NCBE-1125 | Task | Pipeline (relates to) | Consolidación de casos de prueba |
| NCBE-1141 | Task | Pipeline (relates to) | Generación de datos para casos de prueba |
| **NCBE-1126** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — cob_ahorros.sp_ah_retiro_rc** |
| NCBE-2673 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance, no tocado |

SP: `cob_ahorros.sp_ah_retiro_rc`. Micro: `cpas-mso-retiro-rc`.

**Confirmación cruzada (verificada por hash en esta sesión):** el adjunto final de NCBE-1126
(`QA-CASOS-PARSEADOS (3775a85d-e289-475d-92f2-8a8a9bb2da4a).json`, 539053 bytes, SHA-256
`d477b9a6a2241e798cb67cd72ede00cd081ad1af9c1eff3a804f14a47861b1b0`) es **byte-idéntico** a M4 en
`BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md`. Cierra el PENDIENTE que esa minería dejó abierto para
M4 ("Asociación contextual previa NCBE-1126; falta corroborarla") — pasa de INFERENCIA a OBSERVADO.

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

NCBE-1109 tiene 12 subtareas; 3 son tipo **Defecto**, el resto son `Sub-task` de checklist de
entrega (Sonarqube/Veracode/Qualys/Prisma/Infra/Micro/Pruebas Unitarias/Matriz equivalencia/rendimiento),
sin contenido de bug — no se profundizó en ellas.

### NCBE-1254 — Error Arquitectura Hexagonal → **NO ES QA (desarrollo)**

- **Reportado:** mismo patrón que NCBE-1244 en la ME #1: `RetiroCommand` y `ResultadoRetiro` en
  capas equivocadas; adaptador de salida esperado en `persistence/jdbc/adapter`.
- **Corrección (2 rondas):** `RetiroCommand` movido a `application/dto`; `ResultadoRetiro` ya estaba
  correcto en `domain/model`. Adaptador ubicado en `infrastructure/outbound/library` (no
  `persistence/jdbc`) con la misma justificación que NCBE-1244 (no accede a BD directamente, solo
  invoca la librería reutilizable `sp-ah-retiro-rc-utils`). 128 pruebas, 100% cobertura, commit
  `a7a75b2`. Ronda 2: librería reutilizable confirmada ya publicada en 1.0.26-snapshot, build OK.
- **Por qué NO es QA:** estándar de arquitectura hexagonal de desarrollo, sin relación con
  comportamiento observable SP↔microservicio.
- **Nota de recurrencia:** es el mismo patrón, casi línea por línea, que NCBE-1244 de la ME #1 —
  mismo tipo de hallazgo (clase mal ubicada + librería desactualizada), mismo flujo de corrección,
  distinto SP. Ver PR08.

### NCBE-3296 — Error SonarQube en PR a develop → **NO ES QA (calidad de código)**

- **Causa:** `java:S1192` — literal de texto duplicado (`"warmup"`, 7 usos en datos sintéticos de
  `WarmupRunner`) — extraído a constante. Commit `d9a9432`.
- **Efecto colateral real, mismo patrón que NCBE-3276 de la ME #1:** el step `unit_test` falló con
  `NoClassDefFoundError: org.apache.commons.logging.LogFactory` (mismo motivo: `spring-jcl` no
  publicado en el registry interno). Corregido declarando `commons-logging` como dependencia
  directa. Commit `6b328dd`.
- **Por qué NO es QA:** code smell de estilo + defecto de configuración de dependencias de test, sin
  tocar la lógica del SP ni su traducción REST/gRPC.

### NCBE-3310 — Error Prisma Cloud en PR a develop → **NO ES QA (seguridad de dependencias/CI)**

- **Causa:** mismas dependencias vulnerables que NCBE-3276 de la ME #1 (`spring-framework` → 7.0.9,
  `tomcat-embed-core/el/websocket` → 11.0.25, `jackson-databind` → 3.1.6), mismas versiones exactas
  de parche. Commit `88a6bef`.
- **Nota útil dejada por el desarrollador en el propio ticket:** aclara explícitamente que esto no
  es un defecto de código ni de la entrega — es un escaneo de CVEs conocidos que se re-evalúa con el
  tiempo; los CVE aparecieron después de un escaneo previo limpio sobre el mismo artefacto. Aclaración
  correcta y reutilizable para no escalar como "regresión" cada vez que Prisma vuelve a marcar algo
  en una imagen que no cambió.
- **Por qué NO es QA:** igual que NCBE-3276.

### Due diligence de alcance (por el pedido explícito del usuario de revisar bien los tickets de la ME)

- Se revisaron directamente los 3 comentarios de NCBE-1126: solo "carga de matriz"/"casos v2"/"se
  carga la matriz... en Qmetry" — **ningún reporte de bug dentro de la propia HU de revisión.**
- Se corrió una búsqueda de texto amplia en Jira (`text ~ "sp_ah_retiro_rc"` OR `"cpas-mso-retiro-rc"`)
  como control de que no quedara ningún bug enlazado al padre sin cubrir. Apareció un grupo de ~19
  tickets tipo "Defecto" (NCBE-1158/1159/1160/1187/1188/1190/1191/1203/1206/1208/1209/1230/1238/1242/
  1270/1275/1384/2214/2767) que mencionan el SP o el micro por texto, pero **verificados por su campo
  `parent` real, ninguno pertenece a NCBE-1109** — pertenecen a Stories de "Librería" paralelas
  (NCBE-1102 "Retiro - Librería", NCBE-1133, NCBE-1134, NCBE-1098, NCBE-1136, NCBE-1161, NCBE-1177,
  NCBE-1787). Son bugs de construcción de librerías Java (tipado `Money`, rutas de clases,
  parámetros de entrada/salida, DML mal ubicado) — por su título, también NO-QA funcional, pero
  **fuera de alcance** de esta ronda por instrucción explícita (solo lo directamente enlazado al
  padre indicado). No se profundizó en ellos. Ver PR07.
- El JSON de la ME final no contiene ningún campo de hallazgos/incidencias embebido (`documented_findings`,
  referencias `NCBE-xxxx`, etc.) — a diferencia de M1 en la minería, esta ME no trae historia de bugs
  dentro del propio archivo.

## 3. Hallazgo principal de esta ronda

**Igual que en la ME #1: cero bugs de equivalencia funcional SP↔microservicio están enlazados al
padre NCBE-1109.** Los 3 "Defecto" son arquitectura de código, calidad estática y seguridad de
dependencias — todos resueltos por desarrollo. La búsqueda de control confirmó que no hay ningún
otro bug colgando directamente del padre que se haya pasado por alto.

## 4. Contraste con la ME final (NCBE-1126)

- **Universo:** 19 TCs, 6 grupos, **19/19 EQUIVALENTE**, 10 STATELESS / 9 STATEFUL — coincide
  exactamente con lo ya catalogado para M4 en BB_MINERIA.
- **Historial de versiones real (verificado por hash, no asumido):** `QA-CASOS-PARSEADOS.json`
  (31-jul) y `QA-CASOS-PARSEADOSV2.json` (03-ago) son **byte-idénticos entre sí**
  (`999630e2...`) — la "v2" no cambió contenido, probablemente una re-carga de proceso sin revisión
  real de por medio. El adjunto final (05-ago, Nicolas Rodríguez Mejía, "se carga la matriz... tanto
  aquí como en Qmetry") casi cuadriplica el tamaño (153579 → 539053 bytes): agrega la evidencia de
  ejecución REST/gRPC y snapshots que v1/v2 todavía no tenían completa.
- **Particularidades del SP verificadas directamente en el JSON final (confirman, con datos reales,
  lo que BB_MINERIA ya había señalado para M4):**
  - **TC01** ("Cuenta inexistente retorna 041001"): el RETURN real del SP es `1`, no `041001` — el
    número de mensaje vive en el catálogo de errores, no en el RETURN. Confirma la regla "no
    equiparar número de mensaje al RETURN".
  - **TC13/TC14/TC15** (fronteras monetarias 0.0049 / 0.0050 / 0.0051): las tres ejecuciones
    retornan `31172` sin diferencia entre sí — la ruta termina en ese error de validación antes de
    llegar a cualquier lógica de redondeo. Confirma que estos TCs **no prueban** una política de
    redondeo, solo que las tres fronteras caen en el mismo bloqueo.
  - **TC09 — diferencia real verificada, no solo señalada:** SP `o_ssn = 2142301192` vs REST
    `oSsn = 2142301193` (+1). Es el campo secuencial/autoincremental de la transacción (SSN), que
    avanza con cada ejecución real contra el contador compartido — SP y REST se ejecutaron en
    momentos distintos, cada uno consumió el siguiente valor del contador. El veredicto del TC se
    mantuvo **EQUIVALENTE** (criterio correcto: el desfase es un artefacto de ejecución secuencial,
    no una divergencia funcional) y nunca se escaló como bug — correcto, no es un gap de la ME. Ver
    PR06.
- Ninguno de los 3 bugs del padre deja ni debía dejar rastro en esta ME (igual que en la ME #1).

## 5. Patrones agrupados por causa o comprobación reusable (nuevos de esta ronda)

### PR06 — Campos de secuencia/autoincremento no se comparan por igualdad estricta entre canales (NUEVO, con evidencia real)

- **Evidencia:** TC09 de esta ME, SP `o_ssn=2142301192` vs REST `oSsn=2142301193`.
- **Causa:** el campo es un contador (SSN de transacción) que avanza con cada llamada real; SP y
  REST se ejecutaron como invocaciones separadas sobre el mismo contador compartido, no como la
  misma transacción observada por dos canales.
- **Comprobación reusable:** antes de marcar una diferencia en un campo de secuencia/ticket/consecutivo
  como hallazgo, verificar si el campo es generado por un contador compartido que avanza con cada
  ejecución — si es así, un desfase pequeño y consistente con el orden de ejecución es esperado por
  diseño, no un defecto. El DICCIONARIO/criterio de la ME debe declarar estos campos como
  no-comparables estrictamente, tal como se hizo aquí (veredicto EQUIVALENTE se mantuvo).
- **Clasificación:** aprendizaje reusable confirmado con evidencia; no requiere alerta activa — ya
  fue tratado correctamente en el caso real.

### PR07 — Una búsqueda de texto amplia trae ruido de otros padres; confirmar siempre el campo `parent` real (NUEVO)

- **Evidencia:** ~19 "Defecto" encontrados por texto (`sp_ah_retiro_rc`/`cpas-mso-retiro-rc`) que en
  realidad pertenecen a 8 Stories de "Librería" distintas, ninguna es NCBE-1109.
- **Comprobación reusable:** al usar JQL de texto libre como control de cobertura, siempre leer el
  campo `parent` de cada resultado antes de tratarlo como enlazado al padre en revisión — el texto
  compartido (mismo SP/microservicio mencionado) no implica la misma jerarquía Jira. Útil para
  decidir con evidencia qué queda fuera de alcance, en vez de asumirlo.

### PR08 — El par "clase en capa equivocada + librería reutilizable desactualizada" se repite igual entre SPs distintos (confirma patrón ya visto en PR01/PR02)

- **Evidencia:** NCBE-1244 (ME #1, pa_fir_consulta_firmante) y NCBE-1254 (esta ME, sp_ah_retiro_rc)
  tienen la MISMA estructura de hallazgo y la MISMA secuencia de corrección en dos rondas (mover
  Command/Comando a `application/dto`, confirmar Resultado ya en `domain/model`, justificar el
  adaptador de librería en `outbound/library`, y luego actualizar la versión de la librería
  reutilizable publicada).
- **Útil para anticipar:** si aparece un "Error Arquitectura Hexagonal" en un padre futuro de esta
  serie, es razonable esperar el mismo patrón de 2 rondas (reubicación de clases + versión de
  librería desactualizada) — segunda ronda casi siempre detectada por un revisor distinto al que
  cerró la primera.
- **Mismo patrón también en PR02/NCBE-3276 vs NCBE-3310 (Prisma, mismas 3 dependencias/versiones) y
  NCBE-2929 vs NCBE-3296 (SonarQube, mismo defecto `java:S1192` + mismo colateral de
  `commons-logging`/`spring-jcl`):** sugiere una plantilla base compartida entre microservicios
  `cpas-mso-*`, por lo que el mismo hallazgo probablemente reaparecerá en el resto de la familia.
  Sigue siendo responsabilidad de desarrollo/infra, no de QA — no se promueve a alerta activa.

## 6. Lo que no se pudo verificar / queda pendiente

- No se profundizó en los ~19 "Defecto" de las Stories de Librería paralelas (NCBE-1102 y otras) —
  fuera de alcance explícito; solo se registra su existencia y su padre real (sección 2).
- No se verificó si el patrón "plantilla base compartida" de PR08 tiene una causa raíz documentada
  en algún lugar de desarrollo/infra — es una inferencia razonada a partir de dos casos, no una
  confirmación de código fuente del template.
- `report_sp_structure_templateV2.html` y `retiro_service.proto` (adjuntos a NCBE-1126) no se
  inspeccionaron en detalle — material auxiliar, no la ME misma.

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1109 (campos + 12 subtareas + 6 issuelinks "relates to");
  NCBE-1126 (campos + 5 adjuntos + 3 comentarios); NCBE-1254/3296/3310 (campos + comentarios);
  búsqueda JQL de texto libre (`/rest/api/3/search/jql`, el endpoint `/rest/api/2/search` quedó
  retirado por Atlassian) para control de cobertura, con verificación de `parent` de cada resultado.
- **Verificación de hash:** adjuntos v1/v2/final de NCBE-1126 descargados temporalmente a `/tmp`
  (nunca al repo), hash verificado, comparado contra M4 de `BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md`,
  y borrados tras el uso.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #2** de la serie. Ver índice `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`. Pendiente:
  el usuario indicará el siguiente ticket padre y su HU.

# Aprendizaje personal piloto gengis-me — ME #21: pa_cash_gconsultamovimien (NCBE-2801 → NCBE-3631)

Fecha de esta ronda: 2026-11-05. Primera ronda del **Lote 9** y primera de la serie reconstruida
justo después de un cierre propio (el trabajo lo hizo esta misma sesión entre 22-oct y 30-oct). Por
eso, a diferencia de las rondas ME01–ME20, aquí la fuente principal no es solo Jira: se cruzaron
Jira, el historial Git de la ME en agents-qa, el código real de la librería y del micro, y la
memoria propia de la sesión. No se hicieron consultas a Sybase/REST/gRPC en esta ronda, no se
reejecutó nada, no se modificó Jira/QMetry/motor/repos/ME.

**Nota de procedencia meta:** igual que en ME#15, todos los comentarios de corrección los firma
"Gengis Salvador Hidalgo Guevara". Esta ronda es la traza del propio trabajo, no de un tercero.

## 1. Identidad y relación de tickets

| Ticket | Tipo | Rol | Título / nota |
| --- | --- | --- | --- |
| NCBE-2801 | Story | Padre | MICRO : cob_internet.pa_cash_gconsultamovimien |
| NCBE-3094..3098 | Task | Pipeline (relates to) | Análisis, casos funcionales/estructurales, consolidación, datos (NCBE-3098 = documento de casos de Banco, 34 TCs) |
| NCBE-3101 | Task | Revisión (relates to) | Revisión de ME; Done 05-nov |
| NCBE-3102 / NCBE-3103 | Sub-task | Revisión Lote A / Lote B | NCBE-3102 recibió por error una copia del JSON (ver PR39) |
| **NCBE-3631** | Sub-task | **Entrega oficial de esta ronda** | Generación de matriz de equivalencia NYXN; Done 05-nov |
| NCBE-4725 | Impedimento | Bloquea NCBE-3631 | TC06: RETURN 0 (documento) vs 291745 (SP) |
| NCBE-3104 | Task | Pipeline | Pruebas de rendimiento — TO DO, fuera de alcance |

SP: `cob_internet.pa_cash_gconsultamovimien` (+ 6 SP hijos `pa_cash_gmovimiento{cc,ah,vi}[_ultimos]`).
Micro: `bvi-mso-gconsultamovimien`. Librería: `pa-cash-gconsultamovimien-utils`. 34 TCs.

**Confirmación por hash (05-nov):** el último adjunto JSON de NCBE-3631 (id 246091, 30-oct 15:53,
5571613 bytes) tiene SHA-256 `eec8c13bbf4591daf0dc551403bc90fb0c0619370c85fc8d87197af57f106a8b`,
idéntico al `HEAD` de agents-qa (commit `84d414af`). Contenido: 34 casos, 34 EQUIVALENTE,
`paquete_me.estado = BANK_READY`. HTML V2 (244692) y `.proto` (244693) nunca cambiaron desde la
primera entrega (27-oct).

## 2. Versiones de la ME (6 entregas en 4 días)

| Adjunto 3631 | Fecha | Commit agents-qa | Qué corrigió |
| --- | --- | --- | --- |
| 244691 | 27-oct 16:06 | `c519996c` | Primera entrega, 34/34 EQ (TC06 ya con la decisión de NCBE-4725) |
| 245116 | 28-oct 13:26 | `2cf1f481` | NCBE-4762: montos REST como número |
| 245157 | 28-oct 14:34 | `cb098c48` | NCBE-4807 + NCBE-4733: result set SP como `movimientos`, nombres reales, tipos del SP, vacíos explícitos |
| 245346 | 29-oct 09:07 | `5b4b8ebc` | NCBE-4878: espacio real de `s_ubicacion`/`s_causa` en vez de `null` |
| 246001 | 30-oct 14:45 | `9ff2f919` | NCBE-4915/4936: captura en vivo de TC09–TC12/TC17/TC18 |
| 246091 | 30-oct 15:53 | `84d414af` | NCBE-4919: `mensajeDebug` null tras corrección de la librería |

Antes de la entrega hubo dos versiones internas (`2ffbb9c4` 23-oct, 33 EQ + TC06 pendiente;
`3a838f63` 27-oct). Los veredictos nunca cambiaron entre versiones: todas las correcciones fueron de
representación o de datos, salvo NCBE-4919 (código de la librería).

## 3. Panorama de los tickets del padre — clasificación

### A. NO-QA (9 sub-tasks, registro breve)

SonarQube (3930), Veracode (3931), PrismaCloud (3932), Qualys (3933, **sigue en Bloqueo Banco**),
Código Infra (3934), Pruebas Unitarias (3935), Código Micro (3936), workflow de GitHub faltante
(4459, Done), Entrega de código (4549). Ninguno toca equivalencia.

### B. Impedimento funcional previo a la entrega — NCBE-4725 (TC06)

- El documento de Banco esperaba `RETURN 0` para `e_tipo='OTRO'` en modo movimientos. SP, REST y
  gRPC devolvían `291745` "La opcion de consulta no es valida".
- Causa en el SP (L:370-375): asigna 291745 y luego evalúa `@v_error_interno <> 0` con la variable
  en NULL; en Sybase sin `ansinull` eso es TRUE y retorna. Confirma la regla ya conocida "nunca
  asumir ANSI NULL en Sybase" (ME#17, NCBE-4469).
- QA no cambió el esperado por su cuenta: abrió impedimento con opciones A/B. Banco (Danny Ríos,
  27-oct) eligió A y se comprometió a ajustar TC06 y RN-02 en su documento. Aplicación directa de
  "SP es fuente de verdad" con decisión escrita de Banco.

### C. Defectos reales de la representación QA (4 tickets)

- **NCBE-4762 — montos REST como texto.** El motor guarda decimales REST como string por diseño
  (`parse_float=str`, NCBE-1644, para conservar el literal). En la ME quedaron 2233 montos como
  `"1.79"` mientras el micro envía `1.79`. Corregido solo en el JSON, tomando el tipo de las
  respuestas crudas capturadas, con el original en `.motor.json`, igual que el precedente NCBE-4272.
  El motor no se tocó (cambiarlo afectaba el chequeo de formato de todas las ME).
- **NCBE-4807 — result set vacío no visible + nombres posicionales.** En TC04/TC08/TC25 el SP emite
  encabezados sin filas y la ME no mostraba nada. Además el result set SP figuraba como `set1` con
  `COLUMNA_NO_DEFINIDA_1..38` aunque el SP tiene alias reales. Corregido siguiendo NCBE-4686 y
  NCBE-4713 (Lote 5): lista `movimientos`, vacío explícito `[]`, nombres y tipos reales (tipos
  tomados de `sp_helptext` de los SP hijos, solo lectura).
- **NCBE-4878 — `s_ubicacion` null vs espacio.** Los SP hijos asignan `@v_ubicacion = ''`; Sybase
  lo guarda como un espacio (datalength 1, verificado). El lector de result sets del motor
  convertía la celda en blanco en `None`. 1061 celdas (1050 `s_ubicacion`, 11 `s_causa`). Corregido
  en el JSON desde la salida cruda de tsql, celda por celda, y en el **motor central**
  (`3bbb8cc5`, autorizado por el usuario, 10 tests nuevos) — precedente NCBE-4606 (Lote 5, mismo
  problema en OUTPUT, ya corregido allí por `b36328a0`).
- **NCBE-4733 — montos del result set SP con 4 decimales.** Ver PR34. El comentario `212317`
  (28-oct 13:46) lo justificó como falso positivo citando NCBE-4272/NCBE-4667. La reportante
  escribió por WhatsApp que entendía que ya no aplicaba, pero al revisar NCBE-4686 (Lote 5) se vio
  que ese es el precedente para montos *dentro de un result set*, y que allí sí se corrigió la ME.
  Se corrigió por coherencia (`cb098c48`, adjunto 245157 a las 14:34) y se reescribió el mismo
  comentario con la corrección antes del cierre de Banco (28-oct 15:39, "el caso queda
  equivalente"). La edición del 29-oct solo actualizó el id del adjunto vigente. La corrección fue
  decisión de QA para mantener el criterio de Lote 5, no un pedido escrito de Banco.

### D. Defecto real del micro, corregido por Migración — NCBE-4919 (`mensajeDebug`)

- El micro devolvía `mensajeDebug = sMensajeUsuario` cuando `return_code ≠ 0`; el SP no emite
  RAISERROR/PRINT, así que su `mensaje_debug` siempre es `null`. La ME lo tenía documentado como
  "IGNORAR" en el diccionario y la primera respuesta lo justificó así.
- Banco reabrió con un ejemplo de `tr_pago_giro_rc`, donde `mensajeDebug` queda `null` y el mensaje
  vive solo en el campo de dominio.
- La causa estaba en la librería, no en QA: `PaCashGconsultamovimienLibrary.retornar()` hacía
  `debug = returnCode == 0 ? null : sMensajeUsuario`. Escalado a Migración; corregido en la
  librería (`b1e3a4c`, 1.0.3-snapshot) y repin en el micro (`1a46791`). Revalidados en vivo los 9
  casos con error (TC14–16, TC29–34): único cambio `mensajeDebug` texto → `null`.

### E. Contrato del micro, sin defecto por regla de lote — NCBE-4770 (camelCase / snake_case)

- `data` usa camelCase (OUTPUT, SP-017/API-017) y las filas de `movimientos` usan snake_case
  (columnas del result set con su alias real, API-020). Migración confirmó que es intencional.
- Banco, por correo (comunicado por el usuario; esta sesión no tiene acceso al correo): la
  convención camelCase para columnas de result set **aplica desde el Lote 10 inclusive**, no a
  Lote 9 ni anteriores. NCBE-4770 cerrado por Paola Sarango (29-oct) "conforme lo indicado por
  correo". Ver PR40.

### F. Datos dinámicos — NCBE-4915 (TC10) y NCBE-4936 (TC17)

- TC10 usa `e_mostrar_ultimos_movimie='S'`, que tiene precedencia sobre las fechas (AFUN-TD-002,
  TC18): devuelve los últimos movimientos al momento de ejecutar. TC17 calcula
  `@e_fecha_hasta = GETDATE()`. Ambas cuentas AHO son reales y siguen operando.
- Primera respuesta: justificación. Banco reabrió pidiendo "actualizar el JSON para que los valores
  sean equivalentes al momento de cargar las evidencias". Se recapturaron en vivo SP+REST+gRPC
  casi simultáneos los 6 casos expuestos: solo TC10 (324 → 343) y TC17 (26 → 60) cambiaron.
- Para TC17 se ejecutó en vivo antes de responder (58 en los tres canales a las 10:33) en vez de
  inferir el 41 reportado — corrección pedida por el usuario.
- Cierre de Banco (Viviana, 30-oct): diferencia residual de **3 registros** (343 en la ME vs 346 en
  su validación) atribuida explícitamente a que "se está utilizando el mismo número de cuenta en
  diferentes pruebas de lotes". Aceptado y cerrado. Ver PR36.

### G. Sin defecto demostrado — NCBE-4921 (TC11, "Formato del gRPC")

- La captura era un `curl` REST, no gRPC, y su contenido coincidía con la ME (8 filas, mismos
  valores). Se pidió precisión. Banco cerró "con la nueva ME" sin precisar el reclamo. Queda como
  no demostrado: no se sabe qué vio Banco (ver sección 7).

## 4. Hallazgo principal

De 9 defectos de Banco: 1 era un defecto real del micro (NCBE-4919, librería), 4 eran defectos
reales de representación de la herramienta QA (4762, 4807, 4878, y 4733 por coherencia con Lote 5),
2 eran datos dinámicos de cuentas reales que exigieron recapturar (4915, 4936), 1 era una regla de
contrato vigente solo desde el Lote 10 (4770) y 1 no quedó demostrado (4921). **Ninguno cambió un
veredicto**: 34/34 EQUIVALENTE en las 6 versiones. El impedimento previo (4725) fue un error del
documento de casos de Banco, no del SP ni del micro.

El patrón dominante, igual que ME#8 y ME#15, es "la herramienta QA representa mal un dato que el
micro entrega bien". Lo nuevo es que en esta ronda la misma clase de error (representación del
result set SP) se reportó tres veces seguidas (4733 → 4807 → 4878) porque cada corrección se hizo
sobre la anterior y no desde la evidencia cruda (PR37).

## 5. DICCIONARIO — criterios aplicados en este SP

Específicos de esta ME; no se elevan a regla general salvo donde se indica el precedente.

- **Montos `money`, REST:** número, con el tipo real de la respuesta (no texto). Precedente NCBE-4272.
- **Montos `money`, result set SP:** número según el tipo declarado por el SP; decimales
  significativos se conservan (TC24: `0.005`, `23.555`). Precedente NCBE-4686 (Lote 5). Para
  parámetros OUTPUT el precedente NCBE-4272 aceptó 4 decimales del lado SP — no son el mismo caso.
- **Equivalencia decimal:** `1.00` = `1`, `1.10` = `1.1` (criterio Pablo Ricaurte, 13-oct;
  ratificado en el correo adjunto a NCBE-4667).
- **Espacio vs NULL en result sets:** el espacio que guarda Sybase para `varchar ''` se conserva;
  solo `NULL` es `null`. No es equivalencia universal: en las mismas filas hay NULL reales
  (`s_indicador_detalle`, `s_canal`, `s_tsn`, `s_ctaimg`, `s_tipo_doc`).
- **`mensajeDebug`:** `null` cuando el SP no emite mensaje nativo, coherente con `tr_pago_giro_rc`
  en el ejemplo de Banco. En ME#15/4.4 el mensaje sí aparece en `mensajeDebug` cuando el SP lo emite
  vía `sp_cerror`. Ambos casos son consistentes con "refleja el canal nativo del SP, no se
  sintetiza", pero eso son dos SP; no se confirmó como regla escrita de Migración.
- **Nombres de columnas del result set:** alias real del SP en snake_case para Lote 9 y
  anteriores; camelCase desde Lote 10 (decisión Banco por correo, no verificada en esta sesión).
- **Result set vacío:** lista explícita `[]` cuando el SP emite el encabezado sin filas (API-020);
  cuando el SP termina antes de emitirlo (casos de error), no se muestra.
- **`s_menonico_moneda` / `s_nemonico_moneda`:** el SP hijo VIR/BAS emite el alias legacy con typo y
  el micro publica el nombre corregido. Informado en la entrega; Banco no lo reportó.

## 6. Patrones nuevos (PR34–PR40)

- **PR34** (NCBE-4733): un precedente de criterio aplica solo si coincide en el lugar exacto del
  dato. NCBE-4272 (montos en OUTPUT, lado SP con 4 decimales aceptado) y NCBE-4686 (montos dentro de
  un result set, ME corregida) dan respuestas distintas para "ceros a la derecha". Antes de citar un
  precedente, comprobar si es OUTPUT, result set o cuerpo REST/gRPC.
- **PR35** (NCBE-4919): marcar un campo como "IGNORAR" en el diccionario es una decisión de QA, no
  evidencia de equivalencia. Si Banco lo contrasta contra un micro hermano, puede revelar una
  inconsistencia real de contrato que solo Migración resuelve. Antes de justificar, leer el código
  que produce el campo (aquí, una línea en la librería).
- **PR36** (NCBE-4915/4936): casos sobre cuentas reales con `GETDATE()` o "últimos N" no son
  reproducibles contra una foto vieja. Banco pidió una captura nueva y coherente entre los tres
  canales al momento de la revisión, y aceptó una deriva residual explicada (3 registros) por uso de
  la misma cuenta en pruebas de otros lotes. Extiende PR06/PR25: el ambiente compartido entre lotes
  cambia los datos entre la captura de QA y la validación de Banco.
- **PR37** (NCBE-4807 → NCBE-4878): reconstruir una representación a partir de valores ya guardados
  en la ME arrastra los errores del lector que los produjo. La corrección de 4807 conservó los
  `null` incorrectos de `s_ubicacion`, y eso generó el ticket siguiente. Reconstruir siempre desde
  la evidencia cruda (salida tsql, respuesta HTTP original). Relacionado con PR26.
- **PR38** (NCBE-4915/4919/4936): los comentarios a Banco deben citar artefactos que Banco tiene.
  Se citó `OBSERVACIONES-ME.md`, que por decisión explícita no forma parte del paquete entregado.
  Corregido con una nota adjunta por ticket y edición de los comentarios. Corrección del usuario.
- **PR39** (NCBE-3631/3102): sin permiso para borrar adjuntos (el token no tiene
  `DELETE_OWN_ATTACHMENTS`), cada versión deja otro `QA-CASOS-PARSEADOS.json` con el mismo nombre en
  el ticket. Banco abrió una versión anterior: el visor carga el archivo con ese nombre exacto de su
  carpeta. Identificar la versión vigente en el comentario por id, fecha y tamaño. Además, la ME se
  subió por error al ticket hermano NCBE-3102 y hubo que dejar fe de erratas. Extiende PR11/ME#17.
- **PR40** (NCBE-4770): una convención de contrato puede tener vigencia por lote. "camelCase en
  columnas de result set" es válida desde Lote 10; en Lote 9 el mismo hallazgo no es defecto.
  Antes de clasificar un hallazgo de convención, confirmar desde qué lote rige la regla.

**Confirmaciones de patrones existentes:** semántica NULL de Sybase (TC06, ME#17); PR29
(información interna QA en la evidencia; aquí, la referencia a un documento interno, PR38); PR11
(adjunto vigente fuera de la tarea formal); el ciclo QMetry de Banco con sufijo "BBOL"
(`NCBE-TR-60`, creado por Carla Parrales el 28-oct, mismos 34 casos), coherente con TR-54
(NCBE-1777) y TR-15 (NCBE-1175).

## 7. Lo que no se pudo verificar / queda pendiente

- **NCBE-4921:** Banco cerró sin decir qué formato gRPC le parecía incorrecto. No demostrado.
- **NCBE-4733:** Jira no guarda el texto anterior de un comentario editado. Que el cierre de Banco
  (15:39) se basó en la versión corregida se infiere por el orden de los tiempos, no por una
  mención explícita en su comentario.
- **Columnas `char` con espacios a la derecha** (`s_fecha`, `s_causa`, `s_detalle`, `s_secuencial`):
  verificado con JDBC que el relleno lo agrega jConnect en las ramas CTE/VIR/BAS, no Sybase; AHO no
  lo tiene. Banco no lo reportó y no se consultó a Migración.
- **TC34 (filtro POS):** con cuenta ficticia el SP corta antes de aplicar el filtro; informado en
  la entrega. No hay respuesta registrada de Banco sobre un caso complementario.
- **Latencia AHO (~75 s vía micro vs 2,3 s SP):** informada; no investigada más.
- **Evidencias QMetry:** el encabezado `testCaseExecutionId` del TXT muestra el id de la ejecución
  anterior (el TXT se arma antes de crear la ejecución). Cosmético, conocido, sin corregir.
- **Regla camelCase desde Lote 10:** solo conocida por lo que transmitió el usuario; el correo no
  es accesible desde esta sesión.
- **NCBE-3933 (Qualys)** sigue en Bloqueo Banco; NO-QA, no investigado.
- El archivo de apuntes `biblioteca-gengis-me-lotes-2-7.md` mencionado por el usuario no se
  encontró en el filesystem; se siguieron el índice, el `LEEME.txt` del paquete de cierre Lote 7 y
  la nota de seguimiento de la serie.

## 8. Checkpoint — procedencia

- **Jira (solo lectura, 05-nov):** NCBE-2801 (subtasks + issuelinks), los 9 Defecto (comentarios y
  changelog), NCBE-4725, NCBE-3101/3102/3103/3631 (estados, adjuntos, comentarios).
- **Hash:** adjunto 246091 descargado a `/tmp` y borrado tras el uso; coincide con `HEAD` de
  agents-qa. Historial de la ME: `git log` del JSON en agents-qa (9 commits, 23-oct a 30-oct).
- **Código verificado:** motor `3bbb8cc5` y `b36328a0` (agents-qa); librería `b1e3a4c`
  (`bb-core-cob-internet-utils`); micro `1a46791` (`bvi-mso-gconsultamovimien`).
- **Memoria propia:** `project_ncbe2801_gconsultamovimien.md`, `project_qmetry_ncbe2801_load.md`,
  `feedback_lector_qa_espacio_vs_null.md`.
- **No se tocó:** Jira, QMetry, repos de micro/librería, la ME entregada, el motor QA central.

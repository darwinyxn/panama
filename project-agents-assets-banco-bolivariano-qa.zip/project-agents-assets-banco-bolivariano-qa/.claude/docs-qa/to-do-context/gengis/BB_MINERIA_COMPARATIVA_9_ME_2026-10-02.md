# Banco Bolivariano — Minería comparativa de nueve Matrices de Equivalencia

Fecha: 2026-10-02. Destinatario: Gengis. Estado: investigación, sin implementación ni promoción a canon.

Este informe es un entregable de análisis independiente. No modifica el ZIP, las nueve matrices, los repos técnicos ni el workspace documental de Gengis. No reabre ni reconstruye las MEs cerradas. Describe lo observable en los archivos recibidos y los límites necesarios para reutilizar sus aprendizajes.

## Base de evidencia y reglas de lectura

Fuentes primarias: nueve JSON adjuntos y ZIP documental banco-bolivariano(20261002-175650).zip. Del ZIP se cargaron README, canon transversal 00–10, navegación, canon y patrones de Equivalencia, reglas de prompts y fronteras de QMetry/Query Plan. Para una pregunta concreta de identidad/procedencia se consultó el README del caso NCBE-661; no se leyó history masivamente.

Convenciones:

- OBSERVADO: contenido o estructura verificable en los adjuntos.
- DECLARADO: afirmación de una nota o historial dentro de un adjunto; no equivale a inspeccionar el commit, script o ambiente mencionado.
- INFERENCIA: conclusión razonada a partir de esos datos.
- PENDIENTE: requiere fuente adicional o decisión.

Las referencias M1–M9 identifican exactamente los archivos de esta investigación. Los paths JSON citados son selectores conceptuales; `TCxx` identifica el caso por su campo `id`, no por posición.

| ID | Archivo adjunto | SP |
| --- | --- | --- |
| M1 | QA-CASOS-PARSEADOS(20261002-180914).json | sp_retefec_transval_rc |
| M2 | QA-CASOS-PARSEADOS(20261002-180938).json | sp_pago_giro |
| M3 | QA-CASOS-PARSEADOS(20261002-181001).json | sp_debcred_empresa |
| M4 | QA-CASOS-PARSEADOS(20261002-181026).json | sp_ah_retiro_rc |
| M5 | QA-CASOS-PARSEADOS(20261002-181043).json | pa_pag_brpt_billetes_altadeno |
| M6 | QA-CASOS-PARSEADOS(20261002-181102).json | pa_pag_bconcilia_cnb_imix |
| M7 | QA-CASOS-PARSEADOS(20261002-181114).json | pa_fir_consulta_firmante |
| M8 | QA-CASOS-PARSEADOS(20261002-181130).json | pa_cp_cval_ctacnb |
| M9 | QA-CASOS-PARSEADOS(20261002-181150).json | pa_cc_cval_catcctecnb |

Se inspeccionaron estructura y casos de los nueve archivos, PRE/POST, parámetros, resultados, comandos, diferencias, snapshots y notas de procedencia. Se hicieron verificaciones offline de conteos, representaciones binarias y referencias/digests de datasets. No se ejecutó SQL, transporte ni tooling QA.

## 1. MATRIZ_COMPARATIVA_9_ME

### Identidad y resultados observables

| ME | HU y certeza de asociación | Micro | Universo / grupos | Resultado del archivo | Rasgo dominante |
| --- | --- | --- | --- | --- | --- |
| M1 | NCBE-1178 explícito en notas; contiene tickets adicionales de hallazgos | cpas-mso-retefec-transval-rc | 43 / 8 | 43 EQUIVALENTE | Mutación financiera, dependencias, múltiples revalidaciones y ownership |
| M2 | HU no informada en el JSON | ecu-mso-pago-giro | 31 / 7 | 31 EQUIVALENTE | Operaciones Q/S/C/I/U/D/V, pagos y estado/cupo; resultsets según operación |
| M3 | NCBE-661 asociado por README del caso en ZIP; NCBE-784 aparece en un TC | metadata.microservicio=desconocido; URL/proto apuntan a bem-mso-debito-credito-empresa-pagos | 94 / 10 | 91 EQUIVALENTE + 3 INCONSISTENCIA | Parámetros obligatorios, afectación de órdenes/cuentas y errores por output |
| M4 | Asociación contextual previa NCBE-1126; falta corroborarla en el paquete recibido | metadata.microservicio=desconocido; URL/proto apuntan a cpas-mso-retiro-rc | 19 / 6 | 19 EQUIVALENTE | Wrapper y delegación CAR/RC condicionada por canje/cartola/impresora |
| M5 | NCBE-1346 aparece en marcadores de fixture; confirmar identidad formal con documento Banco | cnb-mso-pag-reporte-billetes | 16 / 6 | 16 EQUIVALENTE | Staging, joins de datos, fechas e identificación de beneficiario |
| M6 | NCBE-1580 aparece en marcador de fixture; confirmar identidad formal con documento Banco | cnb-mso-concilia-cnb-imix | 45 / 14 | 45 EQUIVALENTE | Conciliación masiva, datos online/históricos, padding y fallos inducidos |
| M7 | Asociación contextual previa NCBE-1117; falta corroborarla en el paquete recibido | metadata.microservicio=desconocido; URL/proto apuntan a cpas-mso-consulta-firmante | 15 / 4 | 15 EQUIVALENTE | Dos resultsets, múltiples filas y firma binaria HEX/Base64 |
| M8 | NCBE-1343 explícito en notas | cnb-mso-pa-cval-ctacnb | 34 / 7 | 31 EQUIVALENTE + 3 NOT_APPLICABLE con veredicto null | Delegaciones, caso no provocable, recaptura parcial y adjudicación de excepción |
| M9 | HU no informada en el JSON | cnb-mso-pa-cval-catcctecnb | 6 / 2 | 6 EQUIVALENTE | Validación de categoría, outputs s_cuenta/s_msg |

Total: 303 TCs; 297 EQUIVALENTE, 3 INCONSISTENCIA, 3 NOT_APPLICABLE. No hay prueba de aceptación Banco en esos conteos.

Los nueve archivos incluyen SP, REST y gRPC para los casos ejecutados. M8 conserva tres TCs no ejecutados. En M6/TC21 y M8/TC33 gRPC tiene error nativo de transporte RPC, no un body funcional normal. La existencia de los tres canales no prueba automáticamente igualdad de efectos ni cobertura de cada campo.

### Ejecución y cobertura declarada

| ME | Etiquetas STATELESS / STATEFUL | Snapshot SP/REST observable | gRPC y procedencia | Límite relevante |
| --- | --- | --- | --- | --- |
| M1 | 1 / 42 | Contenedores automáticos vacíos; evidencia manual adicional en algunos TCs | Respuestas y revalidaciones dirigidas; doble ubicación gRPC en algunos casos | No interpretar vacíos como ausencia de efectos; historial y proyección vigente requieren reconciliación |
| M2 | 20 / 11 | No vacíos en 31 TCs; 7 nombres de tablas en la unión del scope | Respuestas en 31 TCs; run_id y hash proto declarados | Algunos PRE de TCs STATELESS mutan; restauración publicada no siempre captura estado previo |
| M3 | 23 / 71 | No vacíos en 94 TCs; 30 nombres de tablas en la unión del scope | 3 diffs funcionales; comandos con path absoluto EC2 | Universo no secuencial; resultado final recibido no es 94/94 EQUIVALENTE |
| M4 | 10 / 9 | No vacíos en 19 TCs; 10 nombres de tablas | Respuestas; comandos con path absoluto EC2 | Algunos snapshots contienen listas vacías; no equivalen a cobertura completa del hijo |
| M5 | 1 / 15 | Contenedores vacíos | Respuestas y comandos de ejecución/entrega separados | POST de varios TCs verifica por SELECT; cleanup efectivo requiere otras fuentes |
| M6 | 40 / 5 | Contenedores vacíos | Respuestas masivas y error INTERNAL en TC21 | Cinco TCs STATELESS tienen ALTER TABLE en PRE; volumen de resultado no demuestra lentitud |
| M7 | 15 / 0 | Contenedores vacíos; PRE/POST de consulta | 15 respuestas; comandos con path absoluto EC2 | El vacío puede ser razonable en consulta, pero no documenta cobertura por sí solo |
| M8 | 33 / 1 | Recaptura TC18 con antes/después; restantes vacíos | TC18 tiene snapshots originales REST/gRPC y SP recapturado; TC33 INTERNAL | Un TC usa ISOLATED_CONTROLLED_DUAL_CHANNEL aunque conserva gRPC; semántica del modo debe auditarse |
| M9 | 6 / 0 | No vacíos en 6 TCs; cc_ctacte/ah_cuenta | Respuestas y comandos portables | TC05 falla dependencia, pero PRE vacío no explica cómo se provocó |

Los números de tablas describen keys del JSON, no un inventario completo ni prueba de capturas exitosas. En M8/TC18 el snapshot es una proyección de campos, no un diccionario de tablas.

### M1 — sp_retefec_transval_rc

**Particularidades.** CTE/AHO, VEN/CNB, corrección vinculada a operación base, identidades por canal, datos CFN/ALCNB/MXEECC/DCI, costos, caja y autorizaciones. `metadata.pre_post_session_requirement` exige misma sesión cuando PRE/POST usan `#qa_*`. Hay `run_baseline`, verificaciones de precondición efectiva, cleanup y campos de normalización monetaria. La metadata espera SYBASE02/cob_cuentas.

**Problemas y soluciones reconstruibles.**

- TC05/TC19: `i_ref` pasó de referencias sintéticas a `1|COMERCIO01`; se invalidó evidencia previa y se declararon revalidaciones reales. TC05 necesita base+corrección por canal. Se referencian `tc05_sp_sesion_completa.sql`, helpers REST/gRPC y checkpoints. SP_CUSTOM para la gramática y relación base/main; posible REUSABLE_CUSTOM para coherencia de identidades y ciclo de fixture.
- TC19: notas y outputs muestran reparación de binding/captura de campos contractuales, además de completar inputs en revalidaciones. No afirmar que el micro estaba defectuoso por cada payload incorrecto. Falta el script preciso de cada cambio.
- TC18/TC36: `documented_findings` declara dos causas distintas: serialización REST del micro y pérdida de tipo wire por `parse_float=str` en captura QA. Se menciona `execute_all.detect_money_rest_wire_types`, dirigido por DICCIONARIO. El fix del micro y el fix de captura son cambios distintos. La ubicación/commit del fix QA queda NO_DETERMINABLE hasta inspección.
- TC42/TC43: historial declara colisión de catálogo 999999 con mensaje curado, fix Java bb5da86 y verificación desplegada. El mensaje del catálogo no es el RETURN: el hijo emite mensaje 999999 y retorna 1. La reparación Java pertenece al producto migrado; su verificación QA puede reutilizar criterios, nunca forzar el resultado esperado mediante un overlay.
- TCs financieros: historial declara guard atomizado, comparación de saldo esperado, DELETE con identidad/valor/signo/tipo/canal, y restauración transaccional. También conserva restauración fallida seguida de recuperación posterior. Un guard que se abstiene no equivale a cleanup exitoso.
- Publicación: varias rondas separan corrección de SQL publicado, corrección de fixture y reejecución real. Se referencian `productor/build_delivery.py`, `validar_coherencia_ncbe1178.py` y scripts de corrección por TC. Estos scripts son, provisionalmente, LOCAL_ONLY/TEMPORAL; no son capacidades durables solo por existir.

**Límites.** El run_id raíz no describe por sí solo todas las recapturas. Tres casos publican outputs SP en forma plana frente a 40 con `output_params`. Algunos gRPC se repiten bajo `resultado_ejecucion` y en raíz del TC. Notas históricas permanecen junto a capturas nuevas; por ejemplo, `monetary_normalized` puede provenir de una captura distinta al SP vigente. Hay notas de TC05 sobre diferencias de fecha/sesión frente a Banco. No decidir precedencia ni comparabilidad por la última fecha sin inspeccionar el alcance.

**Evidencia que falta.** Helpers reales y sus versiones, DICCIONARIO, productor, checkpoints por ronda/canal, commits QA, código Java y relación con despliegue. La ME es rica en procedencia declarada, no sustituye esas fuentes.

### M2 — sp_pago_giro

**Particularidades.** 31 TCs, operaciones de consulta e inserción/actualización/eliminación, estado de pago/giro, punto de pago y cupo. `Presence<String>` en dos entradas, nulls en otros campos, fecha Sybase textual frente a ISO y monto `390.0000` frente a `390.00`. Resultsets de consulta bajo `set1` y columnas sin alias como `COLUMNA_NO_DEFINIDA_7/9`, expuestas como campos de negocio en REST.

**Soluciones observables.** PRE/POST preparan y limpian filas de `cg_pago`/`ts_pago`, restauran `cg_giro` y en TC019 publican restauración de cupo. Snapshots SP/REST cubren tablas de giros y, en TC031, cuenta/bloqueo. Metadata declara servidor legacy=micro=SYBASE02, hash proto, run_id y commit de evidencia 5647b3bad2ed196e9a2a2618f9e89609372e4303. No contiene historia suficiente para saber si hubo fix central, adaptación Java o script manual.

**Problemas visibles.** TC010, TC014 y TC029 están STATELESS pese a DELETE/UPDATE en PRE. POSTs con estados o importes absolutos y DELETE después de `INSERT ... WHERE NOT EXISTS` no prueban ownership de la fila borrada. No se concluye que hubo daño: se detecta una precondición de reutilización pendiente. El JSON no publica snapshots gRPC genéricos.

**Clasificación provisional.** SQL de estados/cupo y mapeo de operaciones: SP_CUSTOM. Mecánica de ownership/ciclo y mapeo de columnas/fechas: REUSABLE_CUSTOM si ya existe y puede parametrizarse. Attestation de ambiente/portabilidad: contrato BASELINE documentado, implementación NO_DETERMINABLE. Falta HU y vínculo entre commit, producer y captura.

### M3 — sp_debcred_empresa

**Particularidades.** 94 TCs con IDs no consecutivos hasta TC199. Ramas de órdenes online/históricas, opciones/canales/formas de pago, tipos de cuenta, comisiones y rollback. Amplio mapa de nombres SP→REST que elimina prefijos. Outputs `o_error` y `o_reg_a_proc`, además de RETURN.

**Problemas y soluciones observables.** La ausencia de parámetros obligatorios se expresa por falta de la key, no necesariamente por un literal `OMITIR`. TC25 conserva -6 y mensaje de parámetro no enviado en los tres canales. En TC39/40/41 SP y REST conservan -6, mientras gRPC devuelve 0 y diffs de `codigoRetorno`, `data.oError`, `mensajeDebug`. Hipótesis: semántica de presencia/default de campos numéricos; no se puede atribuir al proto, mapper o harness sin código.

TC199 observa RETURN 0 y `o_error=122004` en los canales, mientras el expected contiene `return_code=122004` y `result_field=o_error`. Eso obliga a separar paridad entre canales de conformidad al expected y a auditar precedencia del diccionario. No autoriza cambiar el expected ni asumir fallo funcional global.

TC167 induce fallo con constraint temporal sobre `bp_movimiento` y publica DROP posterior. Los snapshots contienen 30 nombres de tablas, con before/after y deltas de registros en distintos productos. No hay historia del mecanismo de snapshot/comparación ni del cleanup por canal.

**Procedencia histórica.** El README NCBE-661 del ZIP conserva 94/94 de `sp_debcred_empresa-09-07-2026-2207` y declara no reinterpretarlo frente a corridas posteriores no reconciliadas. El adjunto fue generado el 22 de julio y contiene 91/3. Son cortes distintos; no sobrescribir el hito histórico con este conteo ni llamar al adjunto 94/94.

**Clasificación provisional.** Negocio de órdenes/comisiones: SP_CUSTOM. Presencia y códigos por output: REUSABLE_CUSTOM conceptual. Comparación multicanal/snapshots: comportamiento existente, implementación NO_DETERMINABLE. Constraint TC167: workaround LOCAL_ONLY de riesgo compartido; no promover a recipe automática. Comandos gRPC absolutos y metadata desconocida: candidatos de auditoría de entrega/procedencia.

### M4 — sp_ah_retiro_rc

**Particularidades.** Tabla de verdad canje/cartola/impresora determina delegación CAR/RC. Metadata contiene tipos `Presence<T>` y ordinarios. Inputs, outputs y errores del wrapper y sus hijos tienen roles diferentes. Ejemplo TC01: el nombre menciona 041001 pero se observa RETURN 1 y mensaje de cuenta inexistente; no equiparar número de mensaje al RETURN.

**Soluciones observables.** PRE de ruta CAR prepara disponible/config/costos y POST publica restauración. Rama RC devuelve 31172 por contabilización. TC13/14/15 son fronteras monetarias 0.0049/0.0050/0.0051, pero los tres retornan 31172: no demuestran por sí solos la política de redondeo porque la ruta termina en ese error. TC09 muestra diferencia en `o_ssn` SP/REST, ambos funcionalmente exitosos. Hay snapshots antes/después de cuenta, movimientos y deltas.

**Límites.** POSTs absolutos y cambios de catálogo no son automáticamente restauración con protección de concurrencia. Tipos money salen como números en este corte histórico; no juzgarlos retroactivamente sin versión contractual. No hay explicación de qué script implementó normalización de mensajes ni exclusión de identidad.

**Clasificación provisional.** Selección de rama y parámetros del hijo: SP_CUSTOM. Prueba de alcanzabilidad, proyección de identidad y conservación de mensajes nativos: candidatos REUSABLE_CUSTOM. El fix histórico de QMetry/execution_checker conocido en contexto no se atribuye al motor de ME sin evidencia específica.

### M5 — pa_pag_brpt_billetes_altadeno

**Particularidades.** Fecha, ventana, staging `rec_o_rpt_altadeno`, correlación por autorización/secuencial/fecha/valor, datos de corrientes/ahorros/básica y clasificación CEDULA/RUC/PASAPORTE. 15 TCs con fixture mutante y uno read-only. Outputs bajo `output_params.result_sets[].rows` → `data.filas`.

**Soluciones observables.** TC05/TC10 publican fixture sintético correlacionado para tipo 120062 y limpieza de las tres fuentes. TC11/TC16 alteran identificación, conservan backup en `#bk_*` y restauran; salida de identificación truncada a 19 caracteres. TC15 usa fecha textual inconsistente y deja beneficiario null en todos los canales. PRE incluye predicción del join/CASE en algunos TCs: no es mero cambio de expected.

**Límites.** `SELECT COUNT ... clave_libre` no es un gate efectivo por sí solo. Los mismos IDs se reutilizan entre TCs; no habilitan ejecución paralela sin coordinación. En varios casos el POST solo consulta el staging: no demuestra retiro del fixture ni restitución final. Los snapshots automáticos están vacíos. El JSON deja 16 estados `PENDIENTE_EJECUCION` pese a outputs y veredictos. Los montos de reporte mantienen cuatro decimales; el diccionario debe determinar si son campos sometidos al criterio monetario vigente o texto de un contrato distinto.

**Clasificación provisional.** Join, fecha, truncamiento y reglas de identificación: SP_CUSTOM. Mecánica de fixture correlacionado, backup de sesión y prueba de alcanzabilidad: REUSABLE_CUSTOM conceptual, no copiar SQL específico. Estado de entrega y cobertura: auditoría candidata. Falta producer, cleanup real y topología de sesión.

### M6 — pa_pag_bconcilia_cnb_imix

**Particularidades.** Online/histórico, ventana horaria, catálogos de servicio, comisiones, enmascaramiento, montos de ancho fijo, campos sin alias `col_3/14/16`, padding y múltiples miles de filas. El JSON ocupa 26.6 MB en bytes decimales; eso demuestra volumen, no tiempos ni performance.

**Soluciones observables.** `datasets` contiene 19 datasets completos; los resultados por canal guardan muestra, total y SHA-256. Hay datasets de 0, 1, 8, 10, 5290, 5335 y 5336 filas. Se localizaron 126 referencias `filas_sha256`; ninguna apunta a un dataset ausente. Los 19 digests concuerdan con SHA-256 de la lista serializada con keys ordenadas, UTF-8/ensure_ascii=False y separadores compactos. Esto verifica integridad interna del paquete, no que la captura provino del SP live.

SP y micro tienen digests raw distintos porque nombres y padding difieren. No comparar hashes raw de representaciones distintas para dictaminar equivalencia. El DICCIONARIO debe decidir la comparación y si los espacios son contractuales. La diferencia de padding se observa junto a un veredicto EQUIVALENTE; la justificación y transformación reales no están adjuntas.

**Fallos controlados.** TC21 publica conversión CHAR 'ABC'→INT, Msg 249, sin RETURN; REST HTTP 500 y gRPC INTERNAL. TC22/23/24/25/31/32 publican constraints temporales para inducir errores en staging; cinco están STATELESS. El mecanismo es observable, su autorización y aislamiento histórico no. TC25 conserva RETURN 1 con mensaje SP pero `mensajeDebug=null` en micro: no imponer comparación de debug hasta ver DICCIONARIO/contrato.

**Clasificación provisional.** Representación de conciliación/ventana/PCI: SP_CUSTOM. Dataset completo con deduplicación y proyección de muestra: candidato REUSABLE_CUSTOM con evidencia estructural fuerte, disponibilidad del helper pendiente. DDL de fault injection: workaround LOCAL_ONLY y riesgo a estudiar, no capability automática. Taxonomía de excepción sin RETURN: candidato reusable; no equiparar cualquier 500 al fallo esperado.

### M7 — pa_fir_consulta_firmante

**Particularidades.** Consulta CTE/AHO activa/cerrada, existencia/multiplicidad de firmantes, pasaporte, null, vacío y truncamiento a varchar(10). Dos resultsets: encabezado registros/mensaje y filas Identificacion/Nombre/Firma. REST/gRPC exponen `data.firmantes`.

**Solución verificable.** Firma SP es hexadecimal y firma REST es Base64. Se verificó offline igualdad exacta de bytes SP/REST/gRPC en las 22 filas presentes en los 15 TCs; las cardinalidades también coinciden por TC. Ese chequeo muestra una equivalencia de encoding real; no prueba qué helper la comparó históricamente. TC12 envía null REST y omite la key en el comando gRPC; hacen falta proto/mapper para sostener equivalencia de presencia en general.

**Problemas/reutilización.** La captura de todas las filas y el mapeo de múltiples resultsets son reutilizables. La selección de fuente de firmantes y precedencia entre identificación/pasaporte pertenecen al SP. El sanitizer de firma mencionado en contexto histórico pertenece a un consumidor downstream hasta demostrar su rol en ME. No reusar un sanitizer de evidencia para alterar respuestas funcionales. gRPC de entrega conserva path absoluto EC2 en los 15 TCs.

**Clasificación provisional.** Transformación reversible HEX/Base64: REUSABLE_CUSTOM conceptual. Mapeo del DTO y fuentes: SP_CUSTOM. Sanitización histórica: NO_DETERMINABLE para ME; inventario separado de QMetry. Ejecución read-only no elimina riesgo de exposición de datos ni la obligación de preservar evidencia raw.

### M8 — pa_cp_cval_ctacnb

**Particularidades.** Tipos de cuenta, identificación, empresa, montos/comisión/subtotal/total y delegaciones. Hay inputs que inicialmente se describían con stubs y después se declararon alcanzables mediante datos reales. El output `s_msg` no siempre aparece en el data del micro: puede estar en mensajeDebug; manda el DICCIONARIO.

**Soluciones observables.** TC04/09/10 permanecen NOT_APPLICABLE por ausencia de mecanismo autorizado para provocar fallos de dependencia; no tienen ejecución ni outputs inventados. TC18 conserva scripts/resultados REST/gRPC `tc18_*_controlled_run.py`/`*_result.json`, snapshots originales y recaptura SP del 25 de agosto. Esa composición es explícita, no una corrida simultánea nueva.

TC33 conserva automático `NO_EQUIVALENTE` y adjudicación manual `EQUIVALENTE`: Msg 249 por conversión VARCHAR→INT, REST ProblemDetail 500 de DataAccessException y gRPC INTERNAL con mensaje de acceso a BD. Se argumenta que el fallo ocurrió después de procesar la request y no por TLS/auth/conectividad. Es una política semántica documentada por caso; hace falta contrato y reviewer, no un override que convierta cualquier error en PASS.

**Clasificación provisional.** Validaciones/cuenta/empresa: SP_CUSTOM. Recaptura con lineage, assessment de excepción y estado no provocable: REUSABLE_CUSTOM conceptual. Scripts de TC18: LOCAL_ONLY hasta separar mecanismo genérico de valores particulares. La corrección de expected/ruta de TC17 necesita documento Banco y versión: el nombre indica ajuste a 1011 por empresa inexistente; la intención original no se reconstruye desde el final.

### M9 — pa_cc_cval_catcctecnb

**Particularidades.** Un input principal Presence<String>, dos outputs y seis TCs. PRE/POST vacíos; snapshots cc_ctacte/ah_cuenta. Error de categoría aparece en `s_msg` y `mensajeDebug` con prefijo 37507, mientras RETURN es 31004. TC05 observa 1011 con outputs null; TC06 inexistencia con 31004.

**Límites y soluciones.** El resultado de TC05 no demuestra cómo se indujo fallo de `sp_error` ni por qué esa cuenta lo provoca. No completar esa explicación por el título. `estado=PENDIENTE_EJECUCION` en los seis casos es inconsistencia de presentación frente a evidencia ejecutada, no prueba de falta de ejecución. No hay historia de cambios de motor o micro.

**Clasificación provisional.** Regla de categoría/cuentas y significado de outputs: SP_CUSTOM. Captura read-only es candidata a piloto de baja complejidad futura, después de inventario. Separación mensaje/RETURN y coherencia de estado: aprendizaje reusable; implementación histórica NO_DETERMINABLE.

## 2. PATRONES_REPETIDOS

Estas fichas describen patrones aprendidos. `SOLUCIONES_HISTORICAS` solo afirma los mecanismos observables o declarados; no prueba que todos existieran como módulo reusable.

### P01 — Presencia semántica y payload por canal

PATTERN_ID = P01

CASOS_DONDE_APARECE = M3/TC25 y TC39–41; M7/TC12; M2/TC003, TC012, TC019; M4 y M1 con nulls/identidades por canal.

PROBLEMA = Ausencia, null, vacío y cero pueden ejercer rutas distintas; gRPC omite campos que REST publica null. El mapa de nombres tampoco define defaults.

SOLUCIONES_HISTORICAS = `sp_to_rest_map`, `sp_to_rest_types` con Presence<T>, comandos gRPC filtrados y payloads específicos; en M3 persisten tres inconsistencias. No se ha demostrado un resolvedor general correcto.

PARTE_CONFIGURABLE = Binding del campo, tipo, presencia soportada, default, conversión de fecha, contrato del proto/DTO y reglas por operación.

PARTE_NO_CONFIGURABLE = Preservar intención semántica y declarar estados no representables; no convertir ausencia a cero por comodidad.

RIESGO_DE_HARDCODE = Excluir o rellenar parámetros por nombre global, eliminar todos los nulls indiscriminadamente.

REUSABILITY_CONFIDENCE = Alta para el problema; media para una implementación reusable aún no inventariada.

DESTINO_PROVISIONAL = REUSABLE_CUSTOM; corrección genérica de bug del serializer, si se prueba, CANDIDATE_BASELINE_IMPROVEMENT.

### P02 — Binding de resultsets, columnas y encodings

PATTERN_ID = P02

CASOS_DONDE_APARECE = M7 dos resultsets/firma; M5 filas; M6 columnas sin alias; M2 set1/columnas no definidas; M1 outputs planos frente a anidados.

PROBLEMA = La misma información llega en formas físicas distintas; comparar sin contrato puede perder filas, alias, bytes o distinguir falsamente los canales.

SOLUCIONES_HISTORICAS = Mapeos observables en DTO/resultados, HEX→Base64 de M7 verificable por bytes, proyecciones data.filas/data.firmantes; falta el código del comparator.

PARTE_CONFIGURABLE = Índice/rol del resultset, ruta de campos, encoding, claves de filas y política de orden.

PARTE_NO_CONFIGURABLE = Conservación de datos, cardinalidad y raw; una transformación reversible no autoriza borrar diferencias.

RIESGO_DE_HARDCODE = Mapear `col_3` universalmente a comercio o asumir que resultset 2 siempre son firmantes.

REUSABILITY_CONFIDENCE = Alta para binding/encoding; media para comparación histórica completa.

DESTINO_PROVISIONAL = REUSABLE_CUSTOM para estrategia; SP_CUSTOM para bindings concretos.

### P03 — Canales de error distintos

PATTERN_ID = P03

CASOS_DONDE_APARECE = M6/TC21, M8/TC33, M3/TC199, M4/TC01, M1/TC42–43, M9/TC02/06.

PROBLEMA = RETURN, output de error, número de catálogo, mensaje nativo y excepción de motor no son intercambiables. HTTP 500/INTERNAL no basta para adjudicar equivalencia.

SOLUCIONES_HISTORICAS = `result_field=o_error`, mensajes y raw separados, `expected_exception`, adjudicación manual preservando automático en M8, fix Java de mensaje en M1.

PARTE_CONFIGURABLE = Fuente del resultado funcional, mapping del error y exposición contractual de mensajes.

PARTE_NO_CONFIGURABLE = No fabricar RETURN; separar error técnico, funcional y QA guard; conservar juicio automático y adjudicación.

RIESGO_DE_HARDCODE = Tratar return=1 como placeholder; traducir 999999 globalmente; convertir cualquier 500 en EQUIVALENTE.

REUSABILITY_CONFIDENCE = Alta para taxonomía; media para assessment automatizable.

DESTINO_PROVISIONAL = REUSABLE_CUSTOM para análisis; eventual mejora de representación del motor como candidatura independiente.

### P04 — Ciclo de preparación con ownership y sesión

PATTERN_ID = P04

CASOS_DONDE_APARECE = M1 ciclos base/main y guard; M5 backup #bk; M8/TC18; M2 pagos/cupo; M3/M4 PRE/POST mutantes.

PROBLEMA = PRE prepara estado, pero POST puede borrar filas ajenas, restaurar un valor ya desactualizado o perder el backup al cambiar de sesión.

SOLUCIONES_HISTORICAS = Sesión persistente y tracking temporal en M1/M5; recaptura controlada M8; limpieza por claves y restauraciones absolutas en varias MEs; guard y recuperación posterior declarados en M1.

PARTE_CONFIGURABLE = Recursos, key completa, valores previos/temporales, huella propia, topología de sesión y unidad por canal.

PARTE_NO_CONFIGURABLE = Ownership demostrado antes de borrar; detectar conflicto; abstenerse y conservar tracking si no es seguro restaurar.

RIESGO_DE_HARDCODE = Cuentas/saldos/IDs fijos, restauración genérica por suma/resta, confiar en `IF NOT EXISTS` sin recordar si se insertó.

REUSABILITY_CONFIDENCE = Alta para necesidad; media para extraer un mecanismo compatible con harness real.

DESTINO_PROVISIONAL = REUSABLE_CUSTOM para lifecycle; SP_CUSTOM para recetas SQL y recursos.

### P05 — Huella operativa mayor que mutation_profile

PATTERN_ID = P05

CASOS_DONDE_APARECE = M1/TC22; M2/TC010/014/029; M6/TC22/23/24/31/32; M3/TC167 para DDL explícito.

PROBLEMA = STATELESS/READ_ONLY puede describir el cuerpo o clasificación original, mientras la preparación altera datos o schema compartido.

SOLUCIONES_HISTORICAS = Separación de fases en resumen; constraints para fallos; guards recientes M1. No existe evidencia adjunta de un clasificador completo de efectos.

PARTE_CONFIGURABLE = Efectos PRE/SP/POST, scope de tabla/global, tipo DML/DDL, sesiones y dependencia de otros usuarios.

PARTE_NO_CONFIGURABLE = La etiqueta no otorga permiso ni habilita paralelismo; ausencia de SQL detectado no prueba read-only.

RIESGO_DE_HARDCODE = Autorizar toda la familia por `READ_ONLY`; ignorar shared staging o ALTER TABLE.

REUSABILITY_CONFIDENCE = Alta para el gap; media para detection estática.

DESTINO_PROVISIONAL = REUSABLE_CUSTOM para preflight; DDL de inducción permanece LOCAL_ONLY y no autoejecutable.

### P06 — Snapshots con cobertura explícita

PATTERN_ID = P06

CASOS_DONDE_APARECE = M2/M3/M4/M9 snapshots; M8/TC18 custom; M1/M5/M6 contenedores vacíos y evidencia alternativa.

PROBLEMA = Contenedor existente, lista vacía, fallo de captura y tabla fuera de scope pueden parecer iguales. Igual código no prueba igualdad de efectos.

SOLUCIONES_HISTORICAS = Before/after, count_delta y proyecciones controladas; comprobaciones manuales de restoration en M1/M8.

PARTE_CONFIGURABLE = Tablas/campos/queries, filtros propios, claves, canales observados y relaciones hijas.

PARTE_NO_CONFIGURABLE = No inferir cobertura; observar efectos es distinto de restaurar; count_delta no sustituye valores.

RIESGO_DE_HARDCODE = Allowlists globales de tablas específicas; asumir gRPC cubierto porque REST lo está.

REUSABILITY_CONFIDENCE = Alta para necesidad; media para compatibilidad entre formatos históricos.

DESTINO_PROVISIONAL = REUSABLE_CUSTOM para observabilidad adicional; baseline existente no se duplica.

### P07 — Representación monetaria y tipo wire

PATTERN_ID = P07

CASOS_DONDE_APARECE = M1/TC18/36 y findings; M2/TC001; M4 money numérico; M5 reporte a cuatro decimales; M6 monto textual de ancho fijo.

PROBLEMA = Valor, escala, tipo wire y formato de archivo son ejes distintos; el parser puede borrar NUMBER vs STRING.

SOLUCIONES_HISTORICAS = M1 declara `detect_money_rest_wire_types`, monetary_normalized y fix micro writeString; M2 transforma 390.0000→390.00; otros contratos conservan formas distintas.

PARTE_CONFIGURABLE = Campos monetarios con fuente, escala aplicable, tipo wire, normalización y reglas de archivo.

PARTE_NO_CONFIGURABLE = Preservar raw; no inferir ROUNDING_MODE ni extender money a todo campo con números.

RIESGO_DE_HARDCODE = Forzar todos los outputs a String/2 decimales; tratar padding como cosmética.

REUSABILITY_CONFIDENCE = Alta para separar ejes; implementación/transversalidad por verificar.

DESTINO_PROVISIONAL = REUSABLE_CUSTOM para selección/validación contractual; captura genérica preservando tipos, CANDIDATE_BASELINE_IMPROVEMENT si falta o es defectuosa.

### P08 — Recaptura parcial y evidencia compuesta

PATTERN_ID = P08

CASOS_DONDE_APARECE = M1 múltiples rondas/SP-only/REST-gRPC; M8/TC18 SP nuevo con REST/gRPC históricos; M3 diferencia entre corte histórico y adjunto.

PROBLEMA = Un run_id/fecha global puede ocultar que los canales y campos provienen de corridas distintas.

SOLUCIONES_HISTORICAS = Antecedentes `_estado_*`, notas de alcance, checkpoints, `supplemental_validations`, scripts de consolidación y adjudicación preservada.

PARTE_CONFIGURABLE = Scope TC/canal/campo, fuente exacta, versiones, condiciones de comparabilidad y política de invalidación.

PARTE_NO_CONFIGURABLE = No copiar expected como observed; no marcar reejecutado lo recuperado; no elegir `latest` como autoridad automática.

RIESGO_DE_HARDCODE = Rutas y tickets incrustados en producer; copiar bloques históricos completos sin precedencia.

REUSABILITY_CONFIDENCE = Alta; implementación existente por inventariar.

DESTINO_PROVISIONAL = REUSABLE_CUSTOM; fallos genéricos de identidad/estado pueden ser candidaturas separadas.

### P09 — Evidencia masiva sin perder completitud

PATTERN_ID = P09

CASOS_DONDE_APARECE = M6 datasets/muestras/digests; M3 volumen de snapshots como presión adicional, sin mismo mecanismo demostrado.

PROBLEMA = Resultados grandes repetidos inflan JSON y una muestra sola no sostiene cobertura total.

SOLUCIONES_HISTORICAS = 19 datasets completos compartidos por digest, 126 referencias resolubles y muestras de hasta 10 filas en M6.

PARTE_CONFIGURABLE = Tamaño de muestra, serialización, orden/claves, materialización y versión de schema.

PARTE_NO_CONFIGURABLE = Diferenciar digest de integridad raw de comparación semántica; conservar total/completitud.

RIESGO_DE_HARDCODE = Normalización de espacios global; asumir todos los datasets son conciliación.

REUSABILITY_CONFIDENCE = Alta para mecanismo observable en M6; media para reutilización entre SPs porque solo uno lo demuestra.

DESTINO_PROVISIONAL = REUSABLE_CUSTOM candidata; no clasificar todavía como baseline ni estrategia de performance.

### P10 — Entrega portable, estado y procedencia

PATTERN_ID = P10

CASOS_DONDE_APARECE = M3/M4/M7 comandos gRPC absolutos; M5/M6/M9 estado pendiente; M3/M4/M7 micro desconocido; M1/M2 attestation más rica.

PROBLEMA = Artefacto funcionalmente útil puede conservar residuos de schema/estado o comandos no portables. Cierre externo y evidencia interna no son el mismo atributo.

SOLUCIONES_HISTORICAS = Comandos execution/delivery separados en varias MEs; deployment_* y hash proto en cortes recientes; notas manuales y visores data-driven definidos por canon.

PARTE_CONFIGURABLE = Endpoints/procedencia, proto, campos de estado/schema y reglas vigentes de entrega.

PARTE_NO_CONFIGURABLE = No inventar host ni aceptación; entregar mismo proto productivo; preservar comandos reales.

RIESGO_DE_HARDCODE = URL/puerto fijo global, patches específicos al HTML, calcular estado por ausencia de diffs.

REUSABILITY_CONFIDENCE = Alta para gap; implementación actual requiere inventario.

DESTINO_PROVISIONAL = Contrato BASELINE documentado; auditoría opt-in REUSABLE_CUSTOM; bugs generales candidatos independientes.

### P11 — Alcanzabilidad y límites de inducción

PATTERN_ID = P11

CASOS_DONDE_APARECE = M8/TC04/09/10 y casos que abandonan supuesto de stub; M4 fronteras detenidas en 31172; M5 fixtures de join; M6 constraints; M9/TC05 sin mecanismo publicado.

PROBLEMA = Nombre del TC y código obtenido no prueban que se ejerció la rama pretendida ni que el mecanismo para inducir el fallo sea legítimo.

SOLUCIONES_HISTORICAS = Queries que prueban joins/datos, inspección de ramas, fixtures correlacionados, NOT_APPLICABLE específico y fallos controlados.

PARTE_CONFIGURABLE = Predicados de ruta, dependencias, fuente del expected y mecanismo real permitido.

PARTE_NO_CONFIGURABLE = Mantener universo/intención; no forzar vía DDL compartido ni sustituir escenario para conseguir PASS.

RIESGO_DE_HARDCODE = Devolver siempre expected por TC; transformar cada caso difícil en NOT_APPLICABLE.

REUSABILITY_CONFIDENCE = Alta para metodología; automatización parcial, dependiente de contrato.

DESTINO_PROVISIONAL = Pattern estable ya presente en canon; orquestación REUSABLE_CUSTOM posible sin reemplazar juicio funcional.

## 3. VARIABILIDAD_REAL

### Lo común demostrado

Las nueve MEs comparten metadata/resumen/casos, IDs, escenario, input, payload REST, expected, veredicto/justificación, salida SP, salida REST y evidencia gRPC cuando se ejecutó. CONFIG se refleja parcialmente en metadata; DICCIONARIO se refleja indirectamente en bindings y formas de comparar. Los documentos fuente y el diccionario íntegro no están adjuntos.

Hay tres preguntas independientes que el flujo debe sostener: (a) qué escenario se ejerció y si corresponde a Banco; (b) si los canales fueron equivalentes dentro del scope observado; (c) si el paquete es completo, coherente y reproducible. Un EQUIVALENTE no resuelve automáticamente las otras dos.

### Ejes observables que explican variación

| Eje | Valores emergentes en la muestra | Consecuencia operativa |
| --- | --- | --- |
| Semántica de entrada | Ausente/null/vacío/cero, Presence<T>, nombres mapeados, fechas | Adaptación de payload con contrato y evidencia |
| Forma de salida | Outputs, dos resultsets, set1, filas, columnas sin alias, HEX/Base64 | Binding explícito y comparación por representación |
| Semántica de fallo | RETURN, o_error, catálogo, nativo sin RETURN, RPC INTERNAL | Estrategia de evaluación distinta, no código único |
| Efectos del escenario | Solo consulta, DML en PRE, mutación financiera, DDL de inducción | Permisos y concurrencia por footprint completo |
| Topología | Sesión persistente, backup temporal, canal externo | Compatibilidad de lifecycle antes de ejecutar |
| Datos | Naturales, fixture correlacionado, catálogo compartido, staging | Ownership y alcanzabilidad específicos |
| Contrato monetario | Valor/escala/tipo wire, texto de ancho fijo | Criterio por campo, fuente y versión |
| Evidencia | Una corrida, canales recapturados, dataset deduplicado, adjudicación | Lineage y scope de cierre explícitos |
| Entrega | Comandos absolutos o portables, proto, estado stale | Gate independiente de paridad |

No emerge una clasificación exclusiva “SP simple / SP pesado / SP mutante”. M5 tiene un input y exige fixtures complejos; M8 es mayormente consulta y tiene un TC mutante y una excepción nativa; M6 parece stateless por etiquetas y requiere DDL en varios PREs. La clasificación útil debe ser multidimensional y admitir diferencias por TC/canal.

### Particularidades que no deben abstraerse como negocio general

La gramática i_ref, la base/corrección de transval, reglas de cupos/caja, CAR/RC, joins de billetes, categorías de cuenta, estados de giro, comisiones de órdenes, tipos de transacción, campos/padding del archivo de conciliación y precedencias de identificación permanecen SP_CUSTOM. Puede reutilizarse la mecánica de ejecutar/observar esas reglas; no su semántica.

No hay evidencia suficiente para diseñar retries o timeouts especiales, estrategia de SP lento, caching de ejecución, recovery de transporte o scheduling por duración. Ningún adjunto ofrece un registro estructurado de duración/retries/timeout. M6 tiene mucho output, pero no se mide lentitud. Sanitización tiene señales de datos/encoding y antecedentes, pero no contrato/implementación ME completo.

## 4. CAPABILITIES_CANDIDATAS

Son unidades conceptuales opt-in. No implican crear nueve scripts ni nueve módulos: el inventario puede revelar capacidades existentes que solo necesiten configuración/orquestación. LIKELY_STORAGE y LIKELY_OWNER son hipótesis, no ubicaciones ni responsables autorizados.

### C01 — Presencia y payload contractual

| Campo | Contrato conceptual |
| --- | --- |
| CAPABILITY | Validar estados semánticos de input y binding por canal |
| PROBLEMA | Null/omisión/default pueden cambiar la ruta |
| APPLIES_WHEN | Contrato distingue presencia o cambia nombres/tipos entre canales |
| DOES_NOT_APPLY_WHEN | Se pretende inferir defaults sin SP/DTO/proto o corregir un bug del micro ocultándolo |
| INPUTS | Documento Banco, firma SP/defaults, DTO/Presence, proto, mapper y config |
| OUTPUTS | Payload propuesto por canal, matriz de presencia y diferencias no representables |
| CONFIGURABLE_FIELDS | Bindings, tipos, estados soportados, formato fecha, default probado |
| FORBIDDEN_HARDCODES | SP/HU/TC como selector, campos excluidos globalmente, valores de cuentas/endpoint |
| ORIGIN_CASES | P01: M3, M7, M2, M4, M1 |
| DEPENDENCIES | Adaptadores o builders existentes; versión del contrato desplegado |
| RISKS | Borrar nulls, activar cero implícito, asumir wrappers; inventar igualdad de rutas |
| LIKELY_STORAGE | Implementación reusable aislada; binding/versiones en profile del SP |
| LIKELY_OWNER | Gengis en criterio; owner técnico designado para implementación; Claude como ejecutor autorizado |

### C02 — Binding observable de outputs y encodings

| Campo | Contrato conceptual |
| --- | --- |
| CAPABILITY | Describir/probar resultsets, rutas de outputs, columnas y transformaciones reversibles |
| PROBLEMA | Distintas formas físicas ocultan datos o producen comparación incorrecta |
| APPLIES_WHEN | Resultsets múltiples, aliases faltantes, output plano/anidado, HEX/Base64 |
| DOES_NOT_APPLY_WHEN | La transformación pierde información o borra una diferencia contractual |
| INPUTS | DICCIONARIO, outputs raw, DTO/proto, cardinalidad/orden declarado |
| OUTPUTS | Binding validado, diferencias y prueba de bytes/filas/campos |
| CONFIGURABLE_FIELDS | Ruta, ordinal, encoding, key de fila, policy de orden y proyección de identidad |
| FORBIDDEN_HARDCODES | col_3 universal, resultset 2 universal, ignorar campos por nombre sin fuente |
| ORIGIN_CASES | P02: M7, M5, M6, M2, M1 |
| DEPENDENCIES | Capture/comparator existente y raw íntegro |
| RISKS | Perder duplicados/filas, confundir cantidad con contenido, normalización excesiva |
| LIKELY_STORAGE | Estrategias reusables aisladas; mappings contractuales junto al SP |
| LIKELY_OWNER | Gengis + owner de QA/comparación que se confirme en inventario |

### C03 — Evaluación de fallos observables

| Campo | Contrato conceptual |
| --- | --- |
| CAPABILITY | Separar retorno, output de error, mensaje, abort nativo y fallo de transporte; preparar adjudicación |
| PROBLEMA | Un único código o cualquier 500 puede generar falso veredicto |
| APPLIES_WHEN | Errores por outputs/dependencias, nativo sin RETURN o contrato de mensaje |
| DOES_NOT_APPLY_WHEN | No existe prueba de causa o se busca declarar equivalencia por igualdad de status |
| INPUTS | Raw SP/REST/gRPC, contrato, code path, diagnóstico y expected con fuente |
| OUTPUTS | Clasificación, evidencias comparables, automático preservado y assessment razonado |
| CONFIGURABLE_FIELDS | Fuente de resultado, error mapping, mensajes expuestos, reglas de comparación autorizadas |
| FORBIDDEN_HARDCODES | RETURN ficticio, código 1 “inválido”, mensaje de catálogo por SP global, PASS por TC |
| ORIGIN_CASES | P03: M6/TC21, M8/TC33, M3/TC199, M1/TC42–43, M4/M9 |
| DEPENDENCIES | Captura nativa y handler/mapper del micro; revisión funcional cuando corresponda |
| RISKS | Confundir auth/TLS con SQL, encubrir excepción genérica, reemplazar mensaje genuino |
| LIKELY_STORAGE | Estrategia de assessment aislada y contrato específico; evidencia en corrida |
| LIKELY_OWNER | QA técnico para clasificación; Banco para criterio funcional ambiguo; micro para defectos del producto |

### C04 — Lifecycle de recursos y restauración con ownership

| Campo | Contrato conceptual |
| --- | --- |
| CAPABILITY | Coordinar PRE/ejecución/POST y pruebas de ownership/restauración por canal |
| PROBLEMA | Filas ajenas, estado contaminado, pérdida de sesión y restauración insegura |
| APPLIES_WHEN | Fixture/DML/recursos compartidos o backup acoplado a sesión |
| DOES_NOT_APPLY_WHEN | Falta autorización live, scope/keys, mecanismo de ownership o continuidad requerida |
| INPUTS | Profile de recursos, baseline probado, fixture, topología, identidad de corrida/canal y permisos |
| OUTPUTS | Preflight, tracking propio, resultado de cleanup y recuperación pendiente separada |
| CONFIGURABLE_FIELDS | Keys, recursos, consultas, valores temporales, deltas propios, postcondición y sesión |
| FORBIDDEN_HARDCODES | Cuenta/saldo compartido fijo, borrar por prefijo de TC, reconstruir baseline del expected |
| ORIGIN_CASES | P04/P05: M1, M5, M8/TC18, M2, M3, M4 |
| DEPENDENCIES | Harness compatible; mecanismo de sesión/atomicidad inventariado; scope externo autorizado |
| RISKS | Check seguido de write con carrera, sesión QA confundida con sesión del micro, cleanup ajeno, tracking perdido |
| LIKELY_STORAGE | Mecánica reusable aislada; SQL/fixture/profile SP local; tracking temporal por corrida |
| LIKELY_OWNER | Gengis orquesta; owner técnico valida; Claude opera; owners de datos/ambiente autorizan scope |

Para REST/gRPC, “misma sesión” se refiere a la sesión QA que conserva PRE/POST; no demuestra que el micro use esa conexión. Una tabla temporal QA no debe asumirse visible desde la conexión Java. La topología es una condición de compatibilidad, no un detalle implementativo menor.

### C05 — Observabilidad de efectos con cobertura declarada

| Campo | Contrato conceptual |
| --- | --- |
| CAPABILITY | Validar snapshots/deltas/evidencia adicional por scope |
| PROBLEMA | Snapshots vacíos, parciales o fallidos se confunden con ausencia de efectos |
| APPLIES_WHEN | Hay efectos relevantes o tablas/hijos/canales cuya observación importa |
| DOES_NOT_APPLY_WHEN | Se busca preparar/restaurar datos o declarar una cobertura no capturada |
| INPUTS | Scope de recursos, claves, queries/fuentes, before/after y canales |
| OUTPUTS | Cobertura observada/no observada/fallida, diferencias y límites del veredicto |
| CONFIGURABLE_FIELDS | Proyección de campos, tablas, filtros, key, hijo y policy de comparación |
| FORBIDDEN_HARDCODES | Allowlist global por HU, equivalencia automática de listas vacías, exclusión global de identidades |
| ORIGIN_CASES | P06: M2/M3/M4/M9, M8/TC18, M1/M5/M6 |
| DEPENDENCIES | Snapshots actuales y formatos; acceso de ejecución se autoriza separadamente |
| RISKS | Conteo sin contenido, colisiones de datos, síntomas de captura confundidos con efectos reales |
| LIKELY_STORAGE | Capa de validación reusable; scope SP; evidencia por corrida |
| LIKELY_OWNER | QA técnico; Gengis conserva límites de cobertura |

### C06 — Validación de representación monetaria

| Campo | Contrato conceptual |
| --- | --- |
| CAPABILITY | Contrastar valor, escala, tipo wire y formato contractual sin alterar raw |
| PROBLEMA | Captura o serialización puede borrar distinciones observables |
| APPLIES_WHEN | DICCIONARIO identifica campo monetario y fuente de representación |
| DOES_NOT_APPLY_WHEN | Campo numérico cualquiera, ID, texto fixed-width o criterio de redondeo no decidido |
| INPUTS | Raw wire, dato SP, DICCIONARIO y versión/fuente Banco |
| OUTPUTS | Tipos y representaciones observados, normalización trazable y divergencias |
| CONFIGURABLE_FIELDS | Binding, escala aplicable, tipo wire, policy probada y excepciones contractuales |
| FORBIDDEN_HARDCODES | Todos los campos a String/scale2, HALF_UP global, equivalencia por float solamente |
| ORIGIN_CASES | P07: M1/TC18/36, M2, M4/M5/M6 como límites |
| DEPENDENCIES | `detect_money_rest_wire_types` y serializer/comparator si existen; su ubicación se audita |
| RISKS | Ocultar bug del micro, perder precision, aplicar criterio nuevo retroactivamente |
| LIKELY_STORAGE | Configuración contractual SP y validación opt-in; reusar captura baseline si ya cumple |
| LIKELY_OWNER | Owner QA para capture; micro para serializer; Banco para política funcional |

### C07 — Lineage y consolidación de evidencia acotada

| Campo | Contrato conceptual |
| --- | --- |
| CAPABILITY | Verificar procedencia y comparabilidad antes de componer recapturas |
| PROBLEMA | Mezcla de run_id/canal/inputs/versiones y doble proyección actual/histórica |
| APPLIES_WHEN | Recaptura parcial, recovery histórico, actualización de inputs o producer de entrega |
| DOES_NOT_APPLY_WHEN | Falta fuente inequívoca o se quiere rellenar observed desde expected |
| INPUTS | Evidencias raw, hash/versión de Banco/CONFIG/DICCIONARIO/proto/micro, scope e historial |
| OUTPUTS | Proyección vigente trazable, antecedentes preservados, invalidaciones y gaps |
| CONFIGURABLE_FIELDS | Scope por TC/canal/campo, reglas de comparabilidad y referencias de corrida |
| FORBIDDEN_HARDCODES | Ruta personal global, escoger latest, sobrescribir automático sin registrar adjudicación |
| ORIGIN_CASES | P08/P10: M1, M8/TC18, M3 cortes históricos |
| DEPENDENCIES | Producer existente, logs/checkpoints y versión de schema/visor |
| RISKS | Adjudicación convertida en ejecución, inputs publicados distintos a ejecutados, inconsistencias duplicadas |
| LIKELY_STORAGE | Herramienta de validación/consolidación aislada; evidencia temporal/final separada |
| LIKELY_OWNER | Gengis en criterio; owner del producer/comparación en implementación |

### C08 — Datasets completos y proyección acotada

| Campo | Contrato conceptual |
| --- | --- |
| CAPABILITY | Conservar resultados completos con referencias por digest y muestras de presentación |
| PROBLEMA | Volumen y duplicación; muestra presentada como cobertura total |
| APPLIES_WHEN | Outputs grandes/repetidos y consumidor compatible con formato |
| DOES_NOT_APPLY_WHEN | Se pierde dataset completo, se desconoce canonicalización o visor no soporta referencias |
| INPUTS | Raw completo, row_count, canonicalización y schema/visor |
| OUTPUTS | Dataset íntegro, digest, referencia resoluble y muestra explícita |
| CONFIGURABLE_FIELDS | Tamaño muestra, serialización, orden y layout permitido |
| FORBIDDEN_HARDCODES | Mapeo col_3 fijo, trimming universal, digest raw de formatos distintos como igualdad semántica |
| ORIGIN_CASES | P09: M6; presión de volumen adicional M3 |
| DEPENDENCIES | Helper/productor existente, template estándar y consumidores downstream |
| RISKS | Hash válido de datos incompletos, filas duplicadas perdidas, sample confundida con totalidad |
| LIKELY_STORAGE | Implementación aislada o capacidad baseline ya existente; datasets en evidencia de corrida |
| LIKELY_OWNER | Owner del producer; Gengis decide adopción opt-in |

### C09 — Preflight de contrato/alcanzabilidad y delivery

| Campo | Contrato conceptual |
| --- | --- |
| CAPABILITY | Preparar revisión reproducible de características, procedencia, footprint y portabilidad |
| PROBLEMA | Selección basada en títulos/etiquetas y cierre sin fuentes suficientes |
| APPLIES_WHEN | Nueva ME, corrección de input o preparación del paquete final |
| DOES_NOT_APPLY_WHEN | Se pretende otorgar permisos, decidir reglas Banco o sustituir gates del baseline |
| INPUTS | Contratos, metadata, PRE/POST, evidencia existente y políticas de canon |
| OUTPUTS | Hechos/dudas, capabilities propuestas, contradicciones y checklist de entrega |
| CONFIGURABLE_FIELDS | Fuentes, endpoint/proto, scope, restricciones y checks vigentes |
| FORBIDDEN_HARDCODES | Perfil por nombre SP, host por convención, NOT_APPLICABLE automático, estado por diffs={} |
| ORIGIN_CASES | P05/P10/P11, en varias de las nueve MEs |
| DEPENDENCIES | Discovery/gates ya existentes; evidencia autorizada de despliegue |
| RISKS | Otro motor QA paralelo, checklist que cambia semántica o habilita writes |
| LIKELY_STORAGE | Orquestación declarativa y documentación; solo helpers faltantes tras inventario |
| LIKELY_OWNER | Gengis/ChatGPT en selección; Claude confirma realidad; Banco/owners deciden ambigüedades |

## 5. CLASIFICACION PROVISIONAL

Una capacidad tiene dos atributos independientes: naturaleza reusable y ubicación/implementación histórica. La segunda puede ser NO_DETERMINABLE aunque el problema reusable esté probado.

| Categoría | Qué entra con esta evidencia | Qué no demuestra |
| --- | --- | --- |
| BASELINE | Contratos genéricos ya documentados: flujo 01–05, parser/scaffold, CONFIG/DICCIONARIO, comparación, gates y visor único | Que cada comportamiento actual cumpla el contrato o que todo código mencionado resida en central |
| REUSABLE_CUSTOM | Candidatas C01–C09 opt-in para el flujo Gengis, con config/estrategias separadas | Que deban ingresar al baseline o que deban crearse desde cero |
| SP_CUSTOM | Bindings, rutas, fixtures/SQL de negocio, dependencias, schemas, mensajes y reglas de cada SP | Que sean defectos o que se deban generalizar |
| LOCAL_ONLY | Diagnóstico por TC, constraints de inducción histórica, reparaciones ad hoc de publicación | Contrato durable ni autorización para repetir el experimento |
| TEMPORAL | Identidades, snapshots de baseline de una sesión, tracking, checkpoints, residuos, logs/rondas | Persistencia como tooling ni promoción automática a canon |
| CANDIDATE_BASELINE_IMPROVEMENT | Si el inventario confirma bugs generales: captura wire que conserva tipos, estado/identidad incoherente, representación de abort sin RETURN, referencias completas/schema | Cambio autorizado. Se tramita aparte, con pruebas y owner |
| NO_DETERMINABLE | Localización y origen de mayoría de fixes, retries/performance, cobertura completa, sanitizer ME, varios HUs | No es permiso para inventar ni sinónimo de inexistencia |

Los cambios Java de M1 son arreglos del micro/producto migrado; no son por sí solos “capabilities de personalización QA”. Deben conservar su ownership y despliegue. La capa QA puede verificar esos defectos, no emular su corrección.

## 6. EVIDENCIA_FALTANTE

| ID | EVIDENCIA_FALTANTE | FUENTE_PROBABLE | POR_QUE_LA_NECESITAMOS |
| --- | --- | --- | --- |
| E01 | HU formal, versión Banco, identidad micro en cada corrida | Inputs Banco, CONFIG, results/handoff, metadatos de entrega | Evitar deducir HU de URL o marcador de fixture |
| E02 | Baseline exacto utilizado y diff local BASELINE/CUSTOM/DRIFT | Git history QA y copias .claude del micro | Distinguir cambio central real de copia vieja o custom deliberado |
| E03 | DICCIONARIO íntegro y lógica comparator | Inputs por SP, agentes 04/05, scripts | Saber qué se comparó y qué se excluyó; explicar TC199, padding, debug e identidades |
| E04 | Proto productivo y mapper/DTO desplegados por corrida | Repo micro y evidencias ya guardadas de build/despliegue | Resolver omisión/default gRPC y probar hash de contrato; no inferir Presence de metadata |
| E05 | Implementación/commit de execute_all.detect_money_rest_wire_types y NCBE-1644 | Repo QA/micro, git log y results M1 | Saber si el fix era central, local, genérico, activo y probado |
| E06 | Scripts transval y producer/build_delivery.py; evolución y tests existentes | Results M1 y .claude local micro; historial dirigido | Extraer mecánicas sin arrastrar TC/HU/paths ni reproducir bugs anteriores |
| E07 | Checkpoints/logs de recaptura y precedencia por campo/canal | Results M1/M8, tc18_*_result.json | Verificar composición y que no se usó expected como observado |
| E08 | Gates reales, continuidad de sesión, ownership, cleanup y recuperación | Harness actual, helpers, logs ya existentes | No reusar #temp ni POST absolutos bajo topología incompatible |
| E09 | Autorización, aislamiento y alcance de fault injection DDL | Planes de corrida, handoffs, history puntual M3/TC167 y M6 | Definir límites sin convertir SQL de experimento en acción automática |
| E10 | Captura de resultsets y canonicalización/comparación de dataset | Helpers de M6/M7/M2 y tests ya existentes | Confirmar tratamiento de todas las filas, duplicados, espacios, bytes y aliases |
| E11 | Cleanup final staging/fixtures de billetes y snapshots fallidos/no configurados | Results M5, SP fuente, harness, notas de operación | POST SELECT y snapshots vacíos no prueban restitución |
| E12 | Mecanismo real TC05 categoría y cambios de ruta/expected TC17 validación | Banco, SP/hijos, DICCIONARIO, evidencia puntual | Evitar adjudicar una intención solo desde título/return |
| E13 | Métricas duración, intentos, timeout, estrategias pesadas | Logs/heartbeat/plan ya existentes | No diseñar performance/retries a partir del tamaño de JSON |
| E14 | Tooling abandonado/duplicado, hooks configurables y APIs actuales | Inventario QA/micros y git history dirigido | Reutilizar primero y evitar un segundo motor |
| E15 | Commit de evidencia 5647b3... y correspondencia con M2 | Git history de repos presentes, carpeta results | Corroborar lineage declarado, fuente y HU |
| E16 | Contrato/materialización real de to-do-context/gengis, ignores y backup | Archivos de contrato y gitignored/untracked acotados | Decidir storage durable sin violar temporalidad |
| E17 | Selección de input Banco y protocolo de correcciones central/micro | Harness/discovery, contratos y cases concretos | Evitar dos fuentes operativas y sincronización bidireccional implícita |
| E18 | Fronteras de sanitizer y consumidores QMetry/visor | Scripts existentes y tests de esos consumidores, solo dependencias relevantes | Evitar aplicar sanitización downstream a equivalencia raw |

No se necesita localizar primero las 18 fuentes para pedir auditoría: identificar y encontrar esas fuentes es precisamente su alcance. Sí deben resolverse las dependencias críticas de una capability antes de implementarla o pilotarla.

## 7. HIPOTESIS_ARQUITECTURALES Y SELECCIÓN

### Hipótesis principales

H1. La capa personal debe aportar selección explícita, configuración y coordinación de capacidades existentes. No duplicar ejecución/comparación/render de Agents QA.

H2. La unidad de variabilidad no es solo SP: es SP + operación/TC + canal + versión contractual + huella de recursos + procedencia de evidencia. Un profile por SP necesita excepciones declarativas legítimas por escenario, no branches de código `if TC==...`.

H3. Conviene separar los hechos observados del profile resuelto. Detection propone hechos con fuente y certeza; una decisión explícita conserva selección/overrides y sus razones. El LLM ayuda a interpretar, pero su memoria no es storage ni autoridad.

H4. Un runtime overlay seguro requiere fronteras de integración compatibles con el baseline actual. No está demostrado que existan hooks/plugins/comparators externos. Si no existen, se pueden evaluar helpers externos de preflight/captura/validación o custom local acotado, sin inventar una API ni editar central para habilitarla.

H5. Scope y permisos son independientes de selección. Detectar DDL, saber construir fixture o seleccionar lifecycle no autoriza mutar datos/schema. Los controles viven antes de la ejecución y conservan evidencia de abstención.

H6. Las MEs históricas se usan como corpus de aprendizaje compatible con sus versiones. No reescribir las nueve a un nuevo schema ni certificar que todas cumplen el gate vigente hoy.

### Comparación de selección

| Alternativa | Ventaja | Riesgo demostrado o plausible | Papel provisional |
| --- | --- | --- | --- |
| A. Automática | Detecta Presence, resultsets, DML/DDL, volúmenes, paths y shape | No resuelve intención ni semántica; comentarios/SQL dinámico pueden engañar | Discovery de hechos; nunca autoautoriza writes |
| B. Metadata explícita | Reproducible y revisable | Etiquetas STATELESS/states/metadata desconocida pueden estar stale | Hechos declarados con fuente y versión, contrastados |
| C. Profile declarativo | Composición/versionado por características | Puede convertirse en mega config con IDs y defaults tácitos | Candidato para decisión resuelta, formato aún abierto |
| D. Detection + overrides | Une discovery y decisiones trazables | Override arbitrario puede ocultar divergencia | Hipótesis más fuerte, condicionada al inventario |
| E. LLM asistido | Interpreta SP/DTO/historial y anomalías | No determinista; puede inventar provenance o copiar workaround | Proponer/explicar; no guardar la única decisión en chat |
| F. Contrato + preflight + revisión por scope | Separa hechos, selección, compatibilidad y permisos | Exceso de proceso si duplica gates | Combinación de D/E con validación existente, no nuevo motor |

Secuencia conceptual: recolectar hechos → marcar desconocidos/contradicciones → resolver profile y capabilities compatibles → validar dependencias/recursos/permisos → agente 04/05 según contrato → verificar evidencia/entrega. Nada se elige por el nombre del SP.

Características útiles: representación de presencia; tipo de output/encoding; fuente de error; efectos PRE/SP/POST; dependencia de sesión; recursos exclusivos/compartidos; contrato monetario; volumen y completitud; necesidad de recaptura. Los nombres concretos del SP/TC sirven como trazabilidad y scope, no como dispatch global.

Ejemplos de composición, sin adoptar taxonomía definitiva:

- M7: baseline + binding de dos resultsets + encoding binario + presencia + configuración de consulta.
- M1: baseline + lifecycle/ownership + observación de efectos + representación monetaria + lineage + configuración financiera.
- M6: baseline + binding/representación de filas + datasets + assessment de excepción + configuración de conciliación. Fault injection DDL queda fuera de una ejecución automática normal.

## 8. OPCIONES_DE_STORAGE

| Opción | Qué podría alojar | Ventajas | Riesgos / condición | Evaluación provisional |
| --- | --- | --- | --- | --- |
| to-do-context/gengis | Checkpoints, índice temporal de hallazgos y handoff | Continúa contrato vigente | Es temporal, debe limpiarse/promoverse; no versiona tooling durable por ese contrato | Descartada como hogar permanente de scripts/capabilities |
| Namespace dentro de docs-qa central | Catálogo opt-in o herramientas separadas | Accesible a repos existentes | Escribir allí modifica repo compartido; naming no garantiza no ejecución ni ownership/índice aislado | Posible solo tras gobierno explícito; no supuesto inocuo |
| custom/gengis en central | Distribución namespaced | Visibilidad y revisión | Puede mezclarse con sync/discovery, defaults o ramas de otros | Menor aislamiento; no recomendación actual |
| Tooling versionado separado | Implementación reusable y tests propios | Ownership/release opt-in; no altera default central | Nuevo repositorio/dependencias/distribución; costo de mantenimiento; autorización pendiente | Candidato fuerte a evaluar después del inventario |
| Repo del micro | Config, binding, fixtures y CUSTOM SP | Coincide con fuente operativa actual | .claude ignorado, pérdidas, duplicados y drift; código del micro no debe alterarse por esto | Necesario para lo específico; durability sin resolver |
| Workspace documental Gengis | Contrato, selección, gobernanza e índice a capacidades | Memoria durable y lectura GPT/Codex | No convertir documentación en repo de ejecución ni duplicar implementaciones | Adecuado para criterios/enlaces, no runtime |
| Combinación | Distribución reusable + instanciación SP + evidencia de corrida + canon local | Separa cinco responsabilidades | Debe resolver versiones, instalación y compatibilidad sin sync inverso | Hipótesis fuerte; ubicación concreta abierta |

Representación candidata: metadata/manifest pequeño para campos consumibles por herramientas (identidad, versión, entradas, compatibilidad, dependencias, requisitos de recursos); documentación breve para sentido, límites y ejemplos; profile para bindings/valores del SP; tests/evidencia para validación. No imponer YAML/JSON/directorios todavía. No copiar estos tres contenidos en dos documentos vivos.

Instalación/distribución debe ser opt-in, fijar versión/digest y declarar archivos tocados. Un catálogo no debe activar automáticamente capacidad ni escribir en micro/central al abrir una ME. Los secretos siguen fuera del catálogo/config durable y de los paquetes de evidencia.

## 9. OPCIONES_DE_AISLAMIENTO

### Git, rama experimental y canon

El canon actual exige usar rama/worktree compartidos actuales de EC2 y prohíbe crear ramas/worktrees alternos para el frente. No hay autorización en esta fase para hacer checkout, branch, clone ni experimento.

| Alternativa futura | Aislamiento real | Compatibilidad con estado vigente |
| --- | --- | --- |
| Cambiar el clon compartido a experiment/me-capabilities-gengis | Ninguno para otros usuarios del mismo checkout/índice | Incompatible; no hacerlo |
| Crear rama sin checkout en ese clon | No aísla working tree ni índice; facilita confusiones | No resuelve el problema y crea rama bajo política actual |
| Worktree adicional | Archivos/índice separados, metadatos Git parcialmente compartidos | Canon lo prohíbe actualmente; requiere decisión explícita separada |
| Clon realmente aislado con rama experimental | Archivos/índice/HEAD separados | Técnicamente viable como propuesta; implica excepción explícita al canon actual y autorización de ubicación/repos |
| Experimento en tooling separado con baseline de consulta | Motor central sin cambios; distribución personal opt-in | Candidato a aislamiento mayor; creación de repo/tooling no autorizada todavía |
| Solo análisis de copias/evidencia existentes | Sin ejecución ni cambios | Compatible con la fase actual y el prompt de auditoría |

Una rama es una referencia Git; no una frontera de aislamiento. Un clon o repo separado tampoco aísla Sybase/OpenShift. Aún con Git separado, shared staging, catálogos, cuentas o constraints requieren coordinación y permisos por recurso.

### Eventual integración, sin autorizarla

Si se elige después un clon aislado, los cambios personales no deben depender de merge a master para ser utilizables. Promover a master solo candidatos realmente genéricos, por un cambio independiente con owner, diff limpio, ausencia de hardcodes, compatibilidad y pruebas, revisión explícita y `BASELINE_CHANGE_AUTHORIZED`. Auditar qué contiene el branch completo; no merge de toda la capa personal por conveniencia.

La inspección del índice inmediatamente antes de commit reduce riesgos, pero no elimina la carrera entre sesiones en un checkout compartido. Se debe diseñar coordinación de stage/commit/publicación o evitar writes al repo compartido para la capa personal. El procedimiento concreto queda abierto; no presuponer un lock eficaz que otros usuarios no respetan.

## 10. RIESGOS Y GOBERNANZA PROPUESTA

| Riesgo | Evidencia / razón | Defensa de diseño |
| --- | --- | --- |
| Confundir cierre con paridad completa | M3 91/3; M8 31+3NA | Scope de cierre y fuentes explícitos, sin reescribir historia |
| Copiar receta DDL al ambiente compartido | M3/TC167, M6 constraints | Excluir autoejecución; mecanismo controlado solo con aislamiento/permiso demostrados |
| Clasificación read-only incorrecta | STATELESS con DML/DDL en PRE | Footprint PRE/SP/POST por TC/canal |
| Cleanup ajeno o pérdida de actualización | DELETE tras IF NOT EXISTS; POST absoluto | Ownership y compare-before-restore; conflicto explícito y tracking |
| Checks sin enforcement | SELECT clave_libre, PRINT/nota | Probar gate efectivo y atomicidad; observar no es impedir |
| Segundo motor QA | Capabilities que reimplementan parser/comparator/render | Inventariar y reusar; fronteras acotadas, opt-in |
| Reusable tratado como central | Problema reusable no prueba universalidad | Dos decisiones independientes: reusable personal y promoción baseline |
| Diffs confundidos con CUSTOM | Copias antiguas/harness y .claude ignorado | BASELINE/CUSTOM/DRIFT con evidencia y versión |
| Sanitización altera verdad | Firmas/identificación/evidencia downstream | Raw separado; sanitizer por consumidor, nunca función de equivalencia sin contrato |
| Normalización oculta contrato | Padding, money wire, null/omitir | Policy por campo, fuente y versión; no trimming/global casts |
| Snapshot vacío interpretado como no mutación | M1/M5/M6 vacíos | Status de captura y cobertura, evidencia adicional |
| Mezcla de corridas | M1/M8 recapturas | Lineage por TC/canal/campo y comparabilidad explícita |
| Fixtures no observan rama | M4 frontera detenida, M9 TC05 incierto | Prueba de ruta y mecanismo; no solo return |
| Conflicto Git pese a paths propios | Índice compartido | Aislar o coordinar tramo de publicación; no stash/reset/rebase/force |
| Contrato obsoleto por fecha | M4 money numérico, M5 scale4 | Evaluar por versión contractual; no aplicar reglas retroactivas sin fuente |
| Profile autoriza acciones por accidente | Selección capability con DML | Permisos y compatibilidad separados del dispatch |

Lifecycle conceptual: OBSERVADO → CLASIFICADO → reusable personal candidato → VALIDADO_EN_SCOPE → disponible opt-in → reevaluado por cambio de baseline/contrato → deprecado o retirado. Una ruta separada conduce a `CANDIDATE_BASELINE_IMPROVEMENT` y solo luego, con revisión/autorización, `BASELINE_CHANGE_AUTHORIZED`. Esta propuesta no crea nuevos estados oficiales del motor.

Roles: Gengis decide alcance y adopción personal; ChatGPT compara/clasifica/produce prompts; Codex audita clones locales read-only y actualiza solo documentación autorizada; Claude inventaría/implementa/opera en EC2 únicamente en fases autorizadas; owners conservan control del baseline/producto/datos; Banco conserva criterio funcional final.

## 11. CAMBIOS_DOCUMENTALES_PROPUESTOS

No se escribe ninguno en esta fase. El inventario debe preceder a fijar ubicaciones/tooling.

| Documento existente | Cambio propuesto posterior | Qué evitar |
| --- | --- | --- |
| equivalencia/canon/modelo-personalizacion-agentica.md | Incorporar REUSABLE_CUSTOM separado de baseline; ownership, selección, lifecycle, compatibilidad, distribution/storage elegidos y promoción | Otro documento vivo que replique toda la arquitectura |
| canon/04-seguridad-operativa.md | Explicitar carrera del índice; política aprobada de aislamiento/experimento y coordinación | Instruir branch/worktree alterno sin decidir excepción al canon |
| canon/05-gobierno-documental.md | Mantener temporalidad de to-do; distinguir catálogo durable/implementación/evidencia; reglas de promoción | Scripts permanentes en to-do, doble fuente documental |
| canon/03-workspaces-y-herramientas.md | Añadir solo rutas/autoridades nuevas que realmente se aprueben | Inventar repo/ruta o relajar read-only Codex |
| equivalencia/canon/contrato-matriz-equivalencia.md | Scope de recapturas/adjudicación, distinción estados/evidencia, cobertura de snapshots y precedencia de campos | Fijar nuevo schema o corregir nueve JSON históricos |
| equivalencia/canon/estandar-generacion-casos-y-matriz.md | Punto de selección/preflight y gates por compatibilidad, sin repetir contratos | Nuevo pipeline paralelo |
| equivalencia/patrones/aislamiento-pre-post-y-snapshots.md | Footprint completo, sesión QA vs micro, ownership, conflictos y recuperación como evento separado | Cookbook con cuentas/TCs y SQL de producción |
| equivalencia/patrones/diagnostico-de-falso-equivalente.md | Distinguir paridad/expected/alcanzabilidad; límites de frontera detenida y error por output | Políticas funcionales por intuición |
| equivalencia/patrones/representacion-de-montos-y-escala-contractual.md | Separar raw/wire/escala/formato de archivo y compatibilidad histórica | ROUNDING_MODE inferido o String universal |
| frentes/qa/canon/backlog-qa.md | Agregar pendientes encontrados y cerrar únicamente los probados por inventario | Cierre de snapshot/dry-run/reuse por existencia de una nota |
| conocimiento-compartido/prompts/reglas-para-prompts-tecnicos.md | Exigir baseline/profile/versiones, scope y permiso separados; outputs de inventory antes de implementar | Repetir todo canon en prompts largos |
| equivalencia/README.md | Navegación corta al modelo/selección elegidos | Convertirlo en segundo catálogo completo |

Documento nuevo posible: un único índice de capacidades, si el catálogo elegido no tiene representación autoritativa legible. Debe enlazar metadata/versiones/evidencia, no copiar contratos. Patrones nuevos solo si no caben claramente en los existentes: binding/encoding y lineage podrían justificar uno o dos después del inventario. No crear todavía.

Cases/history conservan origen SP, commits/rondas, SQL concreto, fallos de guards y autorizaciones históricas. Canon conserva método estable. Backlog conserva decisiones/fuentes no resueltas. El nuevo modelo no permite borrar antecedentes difíciles ni mantenerlos como estado vigente por defecto.

No hay backlog que pueda declararse cerrado con estos nueve JSON solamente: reutilización, versionado `.claude`, enforcement dry-run, snapshots gRPC, selection/TC sync y retention requieren fuentes adicionales.

## 12. DECISIÓN Y SIGUIENTE FASE

READY_FOR_CLAUDE_AUDIT = SI

READY_FOR_IMPLEMENTATION = NO

La muestra ya permite preguntas dirigidas, candidatos y anti-patrones. La auditoría es necesaria para comprobar qué mecanismos existen, dónde viven, cuáles fueron centrales/locales, cuáles se perdieron y qué fronteras admiten composición. No se autoriza construir tooling, hacer piloto live ni cambiar repos/documentación.

Prioridad de auditoría:

1. Baseline/entry points/sync y diferencias BASELINE/CUSTOM/DRIFT.
2. Presence/payload, comparator/DICCIONARIO, excepciones y wire type.
3. Lifecycle/sesión/ownership/footprint y snapshots.
4. Producer/lineage/datasets/portabilidad y consumidores.
5. Inventario de helpers abandonados/duplicados, HUs/commits y decisiones de storage/aislamiento.

Pilotos solo como candidatos para decidir después: M7 para binding/encoding/presencia sin mutación; M8/TC18 para lineage/fixture controlado si se confirma topología y ownership. M1 es fuente rica de aprendizaje pero tiene demasiado historial y riesgo financiero para convertirlo automáticamente en primer piloto. M6 aporta datasets; su DDL de inducción no es punto de partida automático.

Criterios futuros de éxito que el inventario debe hacer medibles: cero modificación central por instanciación SP; cero cambio de default compartido; selección reproducible desde hechos/profile; menos repairs/handoffs manuales repetidos; ninguna pérdida de raw/provenance; cleanup probado y abstención segura ante conflicto; compatibilidad de consumidores y rollback local de instalación; trazabilidad de cada capacidad a versión, tests y evidencia real. No prometer reducción porcentual sin baseline de métricas.

El prompt adjunto `BB_PROMPT_CLAUDE_AUDITORIA_CAPABILITIES_2026-10-02.txt` limita el siguiente trabajo a lectura e inventario. Esta entrega no inicia esa auditoría.

## Apéndice — Identidad de los adjuntos examinados

| ME | Bytes | SHA-256 |
| --- | --- | --- |
| M1 | 3048475 | 58f4f219595561b7c6b51fb56173aad341cdbfde8dcfd8f2fe662d9907e3b15c |
| M2 | 648310 | b4828d08367075854e7ede7338f092cba9031dc4326c68f6f6636ae2e1157a13 |
| M3 | 9701204 | c2bf81abab778df64ffc9bc868ab19968950a5f3ff8330ad19c331fd61deaf9f |
| M4 | 539053 | d477b9a6a2241e798cb67cd72ede00cd081ad1af9c1eff3a804f14a47861b1b0 |
| M5 | 80147 | 957571a6809d8c81772255f1f85480922cab1eedcf1aeb26b228cb88074ffee6 |
| M6 | 26584861 | ed51209a89a1a85cfa3798cf50a85cd1df8ec01d216d8e9afc7568bc96217a2d |
| M7 | 117516 | a6a9f60b7f5ccc62538e865fb93f2420e37c63243ad2110504ac4c3573ab342f |
| M8 | 246975 | 58f32f723cc5c111f7993923b4f986790c3a6f8079250006ee06df5f6008b651 |
| M9 | 45757 | 336ff8ed040861c27fb6c924f26c8cf481b9d1f8534c1f73f1eef59d184ad7d1 |

Los digests fijan qué se leyó; no certifican cierre Banco, ejecución live ni identidad con una entrega que exista en EC2. El auditor debe comparar los artefactos encontrados y explicar cualquier diferencia de corte.

# Aprendizaje personal piloto gengis-me — ME #11: pa_cp_cval_ctacnb (NCBE-1343 → NCBE-1528)

Fecha de esta ronda: 2026-10-30. Undécima entrega de la serie. Ronda moderada (7 Defecto, la
mayoría resueltos el mismo día o al siguiente) que aporta el **origen cronológico más temprano**
encontrado hasta ahora del patrón PR29. No se hicieron consultas a Sybase/REST/gRPC, no se
reejecutó nada, no se modificó Jira/QMetry/motor/repos/ME.

## 1. Identidad y relación de tickets (OBSERVADO en Jira)

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1343 | Story | Padre | Validar Cuenta para débito y crédito CNB (estado Jira: `Testing BB`) |
| NCBE-1523 | Task | Pipeline (relates to) | Análisis de Stored procedure — cob_pagos.pa_cp_cval_ctacnb |
| NCBE-1525 | Task | Pipeline (relates to) | Creación de casos de prueba funcionales y estructurales |
| NCBE-1526 | Task | Pipeline (relates to) | Consolidación de casos de prueba |
| NCBE-1527 | Task | Pipeline (relates to) | Generación de datos para casos de prueba |
| **NCBE-1528** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — cob_pagos.pa_cp_cval_ctacnb** |
| NCBE-2864 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance, no tocado |

SP: `cob_pagos.pa_cp_cval_ctacnb`. Micro: `cnb-mso-pa-cval-ctacnb`. 34 TCs.

**Confirmación cruzada:** el adjunto final de NCBE-1528 (`QA-CASOS-PARSEADOS (30150245-...).json`,
246975 bytes, SHA-256 `58f32f723cc5c111f7993923b4f986790c3a6f8079250006ee06df5f6008b651`) es
**byte-idéntico** a M8 de `BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md`.

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

NCBE-1343 tiene 15 subtareas: 8 son `Sub-task` de checklist sin bug; 7 son `Defecto` con
contenido real.

### NCBE-1768 — "Línea de mensaje_debug adicional en respuesta de SP" → **QA real, origen cronológico más temprano de PR29 encontrado hasta ahora**

- Mismo patrón exacto de PR29 (ME #9/#10): `mensaje_debug [diagnostico interno del motor/wrapper]`
  + `engine_exception: null` mostrados como si fueran parte de la respuesta real del SP. **Creado
  2026-08-21 — antes que NCBE-1769 (ME #10, 24-ago) y NCBE-2248 (ME #9, 07-sep).** Es el primer
  caso documentado de esta serie, cronológicamente.
- **Corrección confirmada con ubicación de código:** "el ajuste se realizó en el **renderer de la
  matriz**" — se regeneró el HTML para que "RESULTADOS OBTENIDOS → SP (Sybase)" muestre únicamente
  los outputs funcionales reales (`Return_Code`, `s_cuenta`, `s_msg`).
- **Clasificación:** QA real. **El hecho de que el mismo tipo de fuga reaparezca 3 y 17 días
  después en otros 2 SPs (ME #10, ME #9) a pesar de esta corrección temprana en el renderer sugiere
  que el fix no se generalizó al motor compartido** — cada ME puede estar regenerando su propio
  render sin heredar la corrección de otra. Ver PR29 (reforzado).

### NCBE-1770 — TC33, Msg 249 (conversión VARCHAR→INT) → **QA real, corrobora con fuente Jira el hallazgo ya inferido en BB_MINERIA para M8**

- El SP interrumpe su ejecución con la excepción nativa `Msg 249... Syntax error during explicit
  conversion of VARCHAR value 'ABC' to a INT field` — sin llegar a un `RETURN` normal. La matriz se
  ajustó para reflejar correctamente esta excepción nativa de Sybase (no inventar un RETURN que no
  existe) y el caso se mantiene **EQUIVALENTE** frente al manejo de error del microservicio.
  Confirmado en el JSON final: `TC33` → `EQUIVALENTE`.
- **Esto es, con el ticket real detrás, exactamente lo que `BB_MINERIA_COMPARATIVA_9_ME` ya había
  señalado para M8** ("TC33 conserva automático NO_EQUIVALENTE y adjudicación manual EQUIVALENTE:
  Msg 249 por conversión VARCHAR→INT") — la minería lo infirió solo del JSON; aquí se confirma el
  ticket y la cronología real detrás (reportado 24-ago, resuelto y validado 25-ago).

### NCBE-1807 — TC16, nombre de columna incorrecto en precondición → **QA real, error de la propia herramienta, no del SP/micro**

- La consulta de precondición de la ME usaba `cc_cuenta` (columna inexistente en
  `cob_cuentas..cc_ctacte`); el nombre correcto es `cc_cta_banco`. Corregido en la precondición
  SQL de la propia ME; el caso mantiene `RETURN 31088` con equivalencia SP/REST/gRPC.

### NCBE-1826 — TC18, comandos de ejecución no reflejados → **QA real, gap de reproducibilidad, resuelto**

- La evidencia de TC18 no mostraba los comandos usados para la comprobación (SP Sybase, REST cURL,
  gRPC). Corregido agregando los 3 comandos; el caso mantiene EQUIVALENTE con código `31008`.

### NCBE-2042 — "Novedad dependencia de microservicio" → **NO ES QA (red/TLS transitorio, mismo patrón ya visto)**

- Mismo patrón de otras rondas: corte TLS transitorio contra `maven.pkg.github.com` durante la
  descarga, no dependencia ausente. Resuelto reintentando.

### NCBE-2204 — "Novedad mvn site no se genera pdf" → **NO ES QA — CUARTA recurrencia confirmada del defecto cross-platform `GrpcTlsConfigTest`**

- Mismo defecto exacto que NCBE-2193 (ME #7) y NCBE-2203 (ME #10): validación de ruta de
  certificados TLS asumiendo convención Unix (`/tmp`, `/run`), rompiendo el build en Windows.
  Corregido con la misma estrategia (validación independiente de SO, directorios temporales de
  JUnit portables). Cuarta instancia de la misma clase de defecto en la serie, ahora en un cuarto
  microservicio.

### NCBE-2843 — "Error Microservicio no se encuentra en openshift" → **Ticket vacío, sin contenido reconstruible**

- Descripción literal: `"ds"` (placeholder/typo). **0 comentarios.** Estado `Done` sin ninguna
  evidencia de qué se reportó ni cómo se resolvió. Se registra como no reconstruible, no se asume
  contenido.

## 3. Hallazgo principal de los bugs del padre

El hallazgo más valioso de esta ronda es cronológico: **NCBE-1768 (21-ago) es, de los 3 casos de
PR29 vistos hasta ahora en la serie, el primero en el tiempo** — y aun con una corrección aplicada
("en el renderer de la matriz") volvió a aparecer en 2 SPs distintos semanas después. Esto
refuerza la hipótesis de que el fix de presentación de 21-ago fue específico de ese documento/ME,
no una corrección propagada al motor compartido.

## 4. Contraste con la ME final (NCBE-1528)

- **Universo:** 34 TCs, 7 grupos, **31 EQUIVALENTE + 3 con veredicto `null`** — coincide
  exactamente con BB_MINERIA para M8.
- **Los 3 veredicto `null` son `NOT_APPLICABLE` explícitamente justificados, citando el propio
  padre de esta ronda en el campo `motivo_bloqueo`:** TC04 y TC09 requieren un doble de prueba
  (stub) que fuerce simultáneamente un error de negocio en el SP hijo (`pa_cc_cval_cctecnb`/
  `pa_cc_cval_ahovi_cnb`) Y un stub de `sp_error` forzando `@@error<>0`; TC10 requiere un stub de
  `pa_cc_cval_ahovi_cnb` forzando directamente un error técnico. Los 3 están marcados
  explícitamente como `(NCBE-1343)` en su propio `motivo_bloqueo`, con la fuente del valor
  documentada como `supuesto_controlado` en el documento Banco — "no reproducible sin dobles de
  prueba en este entorno, nunca ejecutado, nunca convertido a otra ruta". Es una clasificación
  legítima de alcanzabilidad (confirma P11 de BB_MINERIA), no un defecto ni un gap de evidencia.
- Todos los 6 Defecto con contenido real de la sección 2 dejan rastro directo y verificable en el
  estado final de sus TCs respectivos (TC16, TC18, TC33 todos EQUIVALENTE tras su corrección).

## 5. Patrones de esta ronda

No se propone ningún patrón nuevo — esta ronda **refuerza** 2 ya catalogados:

- **PR29:** NCBE-1768 es el origen cronológico más temprano encontrado (21-ago), con ubicación de
  código citada ("renderer de la matriz") — útil para entender por qué el mismo problema reapareció
  después: el fix no viajó al motor compartido, quedó local a ese documento.
- **Recurrencia cross-platform `GrpcTlsConfigTest`** (NCBE-2193/ME#7, NCBE-2203/ME#10): cuarta
  instancia confirmada (NCBE-2204), mismo mecanismo y misma solución cada vez.

## 6. Lo que no se pudo verificar / queda pendiente

- NCBE-2843 no tiene contenido reconstruible (descripción `"ds"`, 0 comentarios) — se deja
  registrado como vacío, no se especula sobre su contenido real.
- No se confirma si el fix de PR29 llegó finalmente a un punto compartido del motor en algún
  momento posterior a esta serie de 3 instancias (21-ago, 24-ago, 07-sep) — requeriría revisar el
  código del renderer directamente, fuera de alcance de esta ronda (solo Jira).
- `cp_cval_ctacnb.proto` y `report_sp_structure_templateV2.html` (adjuntos a NCBE-1528) no se
  inspeccionaron en detalle más allá de lo citado en los comentarios.

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1343 (campos + 15 subtareas + 6 issuelinks "relates to");
  NCBE-1528 (campos + 6 adjuntos); NCBE-1768/1770/1807/1826/2042/2204/2843 (campos + comentarios
  completos).
- **Verificación de hash:** el adjunto final de NCBE-1528 descargado temporalmente a `/tmp` (nunca
  al repo), hash y veredictos verificados (34 TCs, 31 EQUIVALENTE + 3 NOT_APPLICABLE), confirmado
  idéntico a M8 de `BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md`. Se verificó puntualmente el estado
  final de TC33 (EQUIVALENTE) y el `motivo_bloqueo` exacto de TC04/TC09/TC10. Borrado tras el uso.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #11** de la serie. Ver índice `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`.
  Pendiente: el usuario indicará el siguiente ticket padre y su HU.

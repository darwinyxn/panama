# Aprendizaje personal piloto gengis-me — ME #3: pa_fir_consulta_con_especial (NCBE-1174 → NCBE-1263)

Fecha de esta ronda: 2026-10-30. Tercera entrega de la serie "una ME a la vez". Mismo alcance y
criterio que las rondas anteriores. No se hicieron consultas a Sybase/REST/gRPC, no se reejecutó
nada, no se modificó Jira/QMetry/motor/repos/ME.

## 1. Identidad y relación de tickets (OBSERVADO en Jira)

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1174 | Story | Padre | Consulta de firmantes especial en base a cuenta |
| NCBE-1219 | Task | Pipeline (relates to) | Análisis de Stored procedure — firmas.pa_fir_consulta_con_especial |
| NCBE-1220 | Task | Pipeline (relates to) | Creación de casos de prueba funcionales y estructurales |
| NCBE-1221 | Task | Pipeline (relates to) | Consolidación de casos de prueba |
| NCBE-1260 | Task | Pipeline (relates to) | Generación de datos para casos de prueba |
| **NCBE-1263** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — firmas.pa_fir_consulta_con_especial** |
| NCBE-2769 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance, no tocado |

SP: `firmas.pa_fir_consulta_con_especial`. Micro: `cpas-mso-fir-consulta-especial`. Este SP no
estaba entre los 9 ya minados en `BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md` — es la primera ME de
esta serie sin precedente de minería previa.

**Verificación de artefacto (hash, en esta sesión):** adjunto final de NCBE-1263
(`QA-CASOS-PARSEADOS.json`, 823017 bytes, SHA-256
`6be2abe99abd6f6c6d23ac9df4c7750b8b5bad3cb0635df56a9706b84961f24b`). Única carga — a diferencia de
las ME #1 y #2, aquí no hubo v1/v2/v3; se cargó una sola corrida completa SP+REST+gRPC ya cerrada.

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

NCBE-1174 tiene 8 subtareas; 7 son `Sub-task` de checklist de entrega (SonarQube/Veracode/Prisma/
Qualys/Pruebas Unitarias/Código Microservicio/Código Infra), sin contenido de bug. Solo **1** es tipo
**Defecto**.

### NCBE-4357 — Error de compilación al consumir librería `pa-fir-consulta-con-especial-utils` 1.0.2 → **NO ES QA (build/dependencias de librería)**

- **Reportado** (2026-10-08): al subir la dependencia de `1.0.2-SNAPSHOT` a la versión liberada
  `1.0.2`, el pipeline de GitHub Actions falla compilando `cpas-mso-fir-consulta-especial`:
  `package com.bolivariano.firmas.pafirconsultaconespecial.utils.domain.model.valueobject does not
  exist`. El paquete referenciado en `ConsultaConEspecialLibraryAdapter` no existe en la librería
  publicada 1.0.2.
- **Causa real (comentario único, Kenneth Barrios, 2026-10-12):** la clase `Money` se movió a un
  módulo nuevo compartido, `pa-fir-consulta-commons-utils`, pero el micro seguía importándola desde
  el paquete viejo de `pa-fir-consulta-con-especial-utils`. Es un refactor de consolidación de
  librerías (extraer tipos compartidos a un módulo `commons`) que no se propagó al consumidor antes
  de cortar la versión liberada.
- **Corrección:** import corregido a
  `com.bolivariano.firmas.pafirconsultacommons.utils.domain.model.valueobject`; se publicaron
  `pa-fir-consulta-con-especial-utils 1.0.3-snapshot` y `pa-fir-consulta-commons-utils
  1.0.0-snapshot`; el micro se actualizó a esas versiones (commit `22444c3`). Para la versión
  liberada se requieren `1.0.3`/`1.0.0` (la `1.0.2` no incluye el ajuste).
- **Por qué NO es QA:** es un defecto de versionado/dependencias entre librerías Java, sin relación
  con el comportamiento observable SP↔microservicio.
- **Dato cronológico relevante (NUEVO, ver PR09):** la ME de NCBE-1263 se cerró el **2026-08-13**;
  este defecto se reportó el **2026-10-08**, casi 2 meses después. Es estructuralmente imposible que
  aparezca en la ME — no es un gap de evidencia, es un hallazgo posterior a la foto que la ME
  certificó.

### Due diligence de alcance (búsqueda de control)

- Comentarios de NCBE-1263 revisados directamente (sección 4): solo carga de corrida + validación
  del equipo Banco, sin reporte de bug dentro de la propia HU.
- Búsqueda JQL de texto amplia (`pa_fir_consulta_con_especial` / `cpas-mso-fir-consulta-especial` /
  `pa-fir-consulta-con-especial-utils`) devolvió 65 tickets. Verificados por `parent` real: **ninguno
  adicional pertenece a NCBE-1174** más allá de sus 8 subtareas ya cubiertas. El resto son de Stories
  distintas de la misma familia de "firmantes" (NCBE-1171 "Consulta especial de firmantes", NCBE-1175,
  NCBE-1176, NCBE-1178, NCBE-1663 "Librería" con 4 Defecto propios de tipado/parámetros) — confirmado
  fuera de alcance, no se profundizó.

## 3. Hallazgo principal de esta ronda (bugs del padre)

Igual que en las ME #1 y #2: **0 bugs de equivalencia funcional SP↔microservicio enlazados al
padre.** El único "Defecto" (NCBE-4357) es de dependencias de librería, y además es cronológicamente
posterior al cierre de la ME — no podía ni debía reflejarse en ella.

## 4. Contraste con la ME final (NCBE-1263)

- **Universo:** 9 TCs, 4 grupos, **9/9 EQUIVALENTE**, 9 STATELESS / 0 STATEFUL.
- **Ciclo de revisión real (3 comentarios + 1 cierre):** corrida completa SP+REST+gRPC cargada de una
  sola vez por Juan Pablo Sanabria Moscoso (12-ago, "resultado final 9/9 EQUIVALENTE, sin
  inconsistencias"), `.proto` cargado el mismo día, Priscila Pincay Baquerizo confirma inicio de
  revisión y al día siguiente (13-ago) cierra: "Se ha validado los escenarios... se finaliza la
  actividad." Sin rondas de corrección como en las ME #1/#2 — ciclo más simple y corto (9 días desde
  creación de la Task hasta carga, 1 día de revisión).
- **Forma de salida confirmada:** el SP ya usa el formato limpio `result_sets` (dos objetos: resumen
  `{registros, mensaje}` + `{rows: [...]}`) — el mismo formato al que migró la ME #1 tras la
  corrección de presentación, aquí ya nativo desde el origen (generada 2026-08-12, después del fix).
  `grpc_output` vive en la raíz del caso (no anidado en `resultado_ejecucion`) — mismo patrón
  estructural que el piloto `gengis-me-pilot` ya documentó para M7; se confirma que generaliza a otro
  SP distinto.
- **Sin campo binario (HEX/Base64) en este SP** — el resultado es `condicionesEspeciales[]` con
  campos de negocio (fechas, montos, identificación, descripción), no una firma. La capacidad
  `binary-comparison` del piloto no aplica aquí; no hay nada que piloter en esa dimensión para esta
  ME.
- **Hallazgo verificado, confirma P11 de BB_MINERIA con evidencia nueva (ver PR10):** 4 de los 9 TCs
  (`TC06`, `TC07`, `TC08`, `TC09`) devuelven `registros=0` con mensajes de "no existe"/"no tiene
  firmantes". De esos, **TC09 es el caso más revelador**: su nombre declara
  `@e_cta_banco='0005170342' — fecha límite/extremo (ce_fecha_fin='2027-03-01') en detalle de
  condiciones especiales`, pero el resultado real de los tres canales es `"No existe cuenta"`
  (`registros=0`) — la cuenta usada ni siquiera llega a tener un registro de condición especial que
  evaluar, así que la frontera de fecha que el título promete probar **nunca se ejerció**. El campo
  `resultado_esperado` del TC solo documenta `{return_code: 0}` (sin mensaje ni conteo esperado), así
  que no hay cómo confirmar desde la propia ME si ese resultado era la intención original o una
  deriva de datos — **NO_DETERMINABLE sin el documento Banco original**, no se asumió ninguna
  alternativa. El veredicto `EQUIVALENTE` es correcto en lo que certifica (los 3 canales coinciden),
  pero no certifica cobertura de la rama que el título anuncia.

## 5. Patrones agrupados por causa o comprobación reusable (nuevos de esta ronda)

### PR09 — Comparar siempre la fecha del bug contra la fecha de cierre de la ME antes de tratar su ausencia como un gap (NUEVO)

- **Evidencia:** NCBE-4357 (creado 2026-10-08) vs cierre de NCBE-1263 (2026-08-13) — casi 2 meses de
  diferencia.
- **Comprobación reusable:** antes de preguntarse "¿por qué este bug no aparece en la ME?", comparar
  `created`/`resolutiondate` del bug contra la fecha de cierre de la ME. Si el bug es posterior, su
  ausencia es esperada, no un hallazgo de proceso ni un gap de evidencia.

### PR10 — Un veredicto EQUIVALENTE por TC certifica coincidencia entre canales, no que se ejerció la rama que el título promete (confirma P11 con evidencia nueva)

- **Evidencia:** TC09 de esta ME ("fecha límite/extremo... en detalle de condiciones especiales" →
  resultado real "No existe cuenta"); TC08 ("join inconsistente en dependencias externas" → "Cuenta
  no tiene firmantes", intención tampoco confirmable desde la propia ME).
- **Comprobación reusable:** cuando un TC con nombre de frontera/caso especial devuelve un resultado
  "vacío"/"no existe" genérico, verificar si el `resultado_esperado` documentado describe el mensaje
  o conteo específico de esa frontera. Si solo documenta el `return_code`, no hay forma de distinguir
  desde la ME sola si el escenario se alcanzó de verdad o si hay deriva de datos — requiere el
  documento Banco original para resolverlo, no se debe inferir intención por el nombre del TC (mismo
  principio que P11 de la minería, ahora confirmado en un SP distinto).
- **Clasificación:** no es un defecto reportable por sí solo (los 3 canales concuerdan, veredicto
  correcto); es una nota de calidad de cobertura a vigilar si se revisa este SP de nuevo.

## 6. Lo que no se pudo verificar / queda pendiente

- No se tiene acceso en esta ronda al documento Banco original (`casos_prueba_...md`) para
  `pa_fir_consulta_con_especial`, necesario para resolver si TC08/TC09 ejercieron la rama prevista o
  hay deriva de datos (sección 4/PR10) — fuera de alcance de esta ronda (solo Jira + ME + bugs del
  padre).
- No se profundizó en los 4 Defecto de la Story "Librería" paralela (NCBE-1663) ni en las Stories
  hermanas de la familia "firmantes" (NCBE-1171/1175/1176/1178) — confirmadas fuera de alcance por
  `parent` real, no enlazadas a NCBE-1174.
- `report_sp_structure_templateV2.html` y `consulta_con_especial.proto` (adjuntos a NCBE-1263) no se
  inspeccionaron en detalle.

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1174 (campos + 8 subtareas + 6 issuelinks "relates to");
  NCBE-1263 (campos + 3 adjuntos + 4 comentarios); NCBE-4357 (campos + 1 comentario); búsqueda JQL de
  texto libre (`/rest/api/3/search/jql`) con verificación de `parent` de cada resultado (65
  coincidencias, 0 adicionales enlazadas al padre).
- **Verificación de hash:** adjunto final de NCBE-1263 descargado temporalmente a `/tmp` (nunca al
  repo), hash verificado, estructura inspeccionada (metadata/resumen/9 casos/result_sets), borrado
  tras el uso.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #3** de la serie. Ver índice `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`. Pendiente:
  el usuario indicará el siguiente ticket padre y su HU.

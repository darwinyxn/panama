# Aprendizaje personal piloto gengis-me — ME #1: pa_fir_consulta_firmante (NCBE-1105 → NCBE-1117)

Fecha de esta ronda: 2026-10-30. Primera entrega de una serie "una ME a la vez" para ampliar
documentalmente el aprendizaje personal de Gengis. Alcance explícitamente limitado a: el ticket
padre NCBE-1105, los bugs directamente enlazados a él, y la HU NCBE-1117 con la ME final y sus
artefactos. No se recorrieron otros lotes, otros SP, ni tickets enlazados desde los bugs. No se
hicieron consultas a Sybase/REST/gRPC ni reejecuciones. No se modificó el motor, agentes, repos de
micro, la ME entregada, QMetry ni Jira.

## 1. Identidad y relación de tickets (OBSERVADO en Jira)

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1105 | Story | Padre | Consulta de firmantes por cuenta |
| NCBE-1107 | Task | Pipeline (relates to) | Análisis de Stored procedure — firmas.pa_fir_consulta_firmante |
| NCBE-1112 | Task | Pipeline (relates to) | Creación de casos de prueba funcionales y estructurales |
| NCBE-1116 | Task | Pipeline (relates to) | Consolidación de casos de prueba |
| NCBE-1138 | Task | Pipeline (relates to) | Generación de datos para casos de prueba |
| **NCBE-1117** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — firmas.pa_fir_consulta_firmante** |
| NCBE-2672 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance, no tocado |

SP: `firmas.pa_fir_consulta_firmante`. Micro: `cpas-mso-consulta-firmante`.

**Confirmación cruzada (verificada por hash en esta sesión, no asumida):** el adjunto final de
NCBE-1117 (`QA-CASOS-PARSEADOS (9fc3e260-6ec8-4b77-994f-e99e6aded39f).json`, 117516 bytes,
SHA-256 `a6a9f60b7f5ccc62538e865fb93f2420e37c63243ad2110504ac4c3573ab342f`) es **byte-idéntico** a:
- M7 en `BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md` (mismo tamaño/hash declarado en ese documento).
- El archivo fuente que usa el profile `m7-pa-fir-consulta-firmante.json` del piloto
  `gengis-me-pilot` (`results/pa_fir_consulta_firmante-04-08-2026-2136/QA-CASOS-PARSEADOS.json`,
  mismo hash, confirmado también en `reports/run_resolution.json` de esa corrida).

Esto cierra un PENDIENTE que la minería había dejado abierto para M7 ("Asociación contextual previa
NCBE-1117; falta corroborarla en el paquete recibido") — pasa de INFERENCIA a OBSERVADO: NCBE-1105 es
el padre y NCBE-1117 es, en efecto, la HU donde se cargó y revisó esa ME exacta.

## 2. Bugs enlazados al padre — reconstrucción y clasificación

NCBE-1105 tiene 15 subtareas; de ellas, 6 son tipo **Defecto** (el tipo que este Jira reserva para
"errores de cada historia de usuario"). Las otras 9 son `Sub-task` de checklist de entrega
(Sonarqube/Qualys/Veracode/Prisma/Código Infra/Código Micro/Pruebas Unitarias/Matriz de equivalencia)
sin contenido de bug — no se profundizó en ellas, están fuera del alcance ("bugs", no entregables).

### NCBE-1244 — Error Arquitectura Hexagonal → **NO ES QA (desarrollo)**

- **Reportado:** `ConsultaFirmanteComando` y `ConsultaFirmanteResultado` en capas equivocadas
  (domain/model vs application/dto); el adaptador de salida debía ir en
  `infrastructure/outbound/persistence/jdbc/adapter`.
- **Investigación/corrección (2 rondas, por el equipo de desarrollo):** Ronda 1 — se movió
  `ConsultaFirmanteComando` a `application/dto`; `ConsultaFirmanteResultado` ya estaba en
  `domain/model` (correcto, sin cambio). El adaptador se ubicó en
  `infrastructure/outbound/library` (no en `persistence/jdbc`) con justificación explícita: no
  accede a BD directamente, solo invoca la librería reutilizable `pa-fir-consulta-firmante-utils`,
  siguiendo el mismo patrón que el micro de referencia ya aprobado
  (`bem-mso-debito-credito-empresa-pagos`). 109 pruebas, 100% cobertura, commit `dd7912d`.
  Ronda 2 — el revisor detectó que la librería reutilizable seguía en versión vieja
  (`1.0.5-snapshot`); se actualizó a `1.0.6-snapshot`, se ajustó el adaptador a la interfaz pública
  de esa versión y se realineó su prueba unitaria. Commit `05a719d`, desplegado en OpenShift
  (`bb-dev-core`), pods 1/1 Running.
- **Por qué NO es QA:** estándar de arquitectura hexagonal de desarrollo (ports/adapters), sin
  relación con equivalencia funcional SP↔microservicio. No referencia ningún TC ni comportamiento
  observable. No deja ni debe dejar rastro en la ME.

### NCBE-1474 / NCBE-1480 / NCBE-1481 — "Entregable" Sonarqube / Pruebas Unitarias / Veracode → **NO ES QA (checklist administrativo)**

- Los tres: creados y resueltos el mismo día (2026-08-07), en 5-9 minutos, **sin asignado y sin
  comentarios**. El cuerpo es solo una tabla con nombre de micro/SP y un link a una página de
  Confluence ("Core Pasivos Entregables S1 - Gestión y Mejora Continua"). No hay investigación que
  reconstruir: son marcadores de checklist de entrega, no defectos reportados ni corregidos.
- **Por qué NO es QA:** no describen ningún hallazgo; son puntos de control de entrega del micro.

### NCBE-2929 — Error SonarQube en PR a develop → **NO ES QA (calidad de código)**

- **Reportado** (2026-09-23): el quality gate del pipeline CI rompe en el PR a develop.
- **Causa real:** regla `java:S1192` — literal `"Solicitud invalida"` duplicado 3 veces en
  `GlobalExceptionHandler` del micro.
- **Corrección:** extraído a constante `TITLE_SOLICITUD_INVALIDA`, referenciada en los 3 puntos,
  sin cambio de comportamiento. 17/17 pruebas del handler OK. Commit `a56d23e`. Gate quedó en PASS
  (0 code smells, 0 issues abiertos).
- **Por qué NO es QA:** code smell de estilo; no altera ningún RETURN, mensaje ni payload observable
  por SP/REST/gRPC.

### NCBE-3276 — Error Prisma Cloud en PR a develop → **NO ES QA (seguridad de dependencias/CI)**

- **Reportado** (2026-09-28): Prisma Cloud reporta vulnerabilidades en la imagen del pipeline.
- **Corrección:** se actualizaron las dependencias vulnerables (`spring-framework` → 7.0.9,
  `tomcat-embed-core/el/websocket` → 11.0.25, `jackson-databind` → 3.1.6), manteniendo Spring Boot
  en 4.0.6 para no degradar el stack. Commits `ba99d55`/`c0af5d5`.
- **Efecto colateral real encontrado y corregido en la misma ronda:** tras el bump, el step
  `unit_test` empezó a fallar con `NoClassDefFoundError: org.apache.commons.logging.LogFactory`
  (`spring-jcl` no está publicado en el registry interno, y Spring usa `commons-logging` como
  puente). Se declaró `commons-logging` como dependencia directa del classpath de pruebas. Commit
  `ef1c2eb`. Pipeline completo (`unit_test`, `sonarqube`, `prisma`, `veracode`) quedó en verde.
- **Por qué NO es QA:** vulnerabilidades de librerías/imagen base y un efecto secundario de
  dependencias en CI; no toca la lógica del SP ni su traducción REST/gRPC.

## 3. Hallazgo principal de esta ronda

**Cero bugs de equivalencia funcional SP↔microservicio están enlazados al padre NCBE-1105.** Los 6
"Defecto" directamente ligados son, sin excepción, de arquitectura de código, calidad estática
(SonarQube) o seguridad de dependencias/imagen (Prisma Cloud), todos resueltos por el equipo de
desarrollo — ninguno por QA, ninguno referencia un TC. Ninguno aparece ni debía aparecer en la ME
(sección 4 lo confirma).

Esto es en sí mismo el aprendizaje más importante de esta ronda — ver patrón PR01 abajo.

## 4. Contraste con la ME final (NCBE-1117)

- **Identidad:** SP `pa_fir_consulta_firmante` / BD `firmas`, micro `cpas-mso-consulta-firmante`,
  `metadata.microservicio` del JSON permanece `"desconocido"` (campo nunca completado — consistente
  con lo ya observado en BB_MINERIA para M7).
- **Universo:** 15 TCs (`TC01`–`TC15`), 4 grupos, **15/15 EQUIVALENTE**, 15 STATELESS / 0 STATEFUL.
- **Ciclo de revisión reconstruido de los 7 comentarios de NCBE-1117:**
  1. v1 cargada (31-jul-2026, William Nieto Rico).
  2. v2 cargada (03-ago-2026).
  3. Pedido explícito de un archivo `.proto` para habilitar pruebas gRPC (Priscila Pincay Baquerizo,
     03-ago-2026) — el `.proto` quedó adjunto a NCBE-1117.
  4. Versión final cargada (04-ago-2026, Nicolas Rodríguez Mejía): "ya el formato de firmantes es un
     JSON como quedamos en la reunión del día de hoy" — decisión de equipo, no un defecto reportado
     por Banco.
  5. Banco valida por lotes, todos OK: Yamilet Cisneros Plaza → TC01-TC05; Katherine Murgueytio →
     TC06-TC10; Yuri Sánchez Saquicela → TC11-TC15 (05-ago-2026).
- **Cambio real verificado entre v3 y la versión final** (diff de estructura hecho en esta sesión,
  no inferido): `resultado_ejecucion.sp_output.output_params` pasó de claves planas con punto
  (`RS1.count`, `RS1.rows`, `RS2.rows`, más `RS2.Identificacion`/`RS2.Nombre`/`RS2.Firma` repitiendo
  como escalares sueltos los valores de la *primera* fila del segundo resultset) a un arreglo limpio
  `result_sets: [ {registros, mensaje}, {rows: [...]} ]` — un objeto por resultset del SP. Es una
  corrección de **presentación** del artefacto (el "formato JSON" que pidió el equipo), no un cambio
  de veredicto (EQUIVALENTE en ambas versiones) ni de dato capturado — las filas y valores de
  `firmantes` son idénticos antes y después.
- Ninguno de los 6 bugs de NCBE-1105 deja rastro en la ME, consistente con la sección 3: no había
  nada funcional de esos bugs que debiera reflejarse aquí.
- **Ya existe una capacidad piloteada (no solo propuesta) sobre esta ME exacta:** `gengis-me-pilot`
  corrió `binary-comparison` (STATUS=IMPLEMENTED, experimental, solo lectura, offline) contra este
  mismo archivo — hash verificado idéntico antes y después de leerlo — y confirmó mecánicamente
  **22/22 filas y 66/66 comparaciones `bytes_equal=true`** entre la firma SP (hex), REST (base64) y
  gRPC (base64) (`reports/m7_result.json` / `run_resolution.json`, corrida 2026-10-05). Esto gradúa
  el patrón P02/C02 de BB_MINERIA ("binding de resultsets, columnas y encodings") de *verificación
  manual del analista* a *mecanismo reproducible verificado*. El piloto registró además un drift
  documental sin corregir: al momento de esa corrida, el DICCIONARIO del repo primario para este SP
  figuraba como "Pendiente", mientras un repo fallback sí tenía la sección llena — ambos describían
  la fila `(Identificacion, Nombre, Firma)` de igual forma, así que no afectó el resultado, pero el
  drift en sí sigue sin resolver.

## 5. Patrones agrupados por causa o comprobación reusable

### PR01 — Un "Defecto" enlazado al padre no es automáticamente un hallazgo de equivalencia QA (NUEVO)

- **Evidencia:** NCBE-1244, 1474, 1480, 1481, 2929, 3276 — los 6 "Defecto" de NCBE-1105.
- **Causa:** este Jira usa el tipo "Defecto" para *cualquier* hallazgo contra una historia —
  arquitectura, SonarQube, Veracode, Prisma — no exclusivamente divergencias SP↔microservicio.
- **Comprobación reusable para la próxima ME:** antes de tratar un "Defecto" enlazado como insumo
  para la ME, verificar (a) asignado — ¿es alguien de desarrollo o de QA?; (b) contenido — ¿habla de
  código/infra/seguridad o de un comportamiento observable del SP/REST/gRPC?; (c) ¿referencia algún
  TC? Si no referencia TC ni comportamiento, es candidato fuerte a clasificar NO-QA sin profundizar
  más.
- **Clasificación:** hábito de lectura a aplicar en próximas rondas; no es un hallazgo del motor ni
  requiere alerta activa.

### PR02 — Defecto de desarrollo ya cerrado no se convierte en alerta activa de la ME (confirmación de regla)

- NCBE-1244/2929/3276 son defectos reales, investigados y corregidos por desarrollo — pero ya
  **cerrados antes de esta revisión** y nunca tocaron la capa de comportamiento que la ME certifica.
  Quedan documentados aquí como antecedente histórico, explícitamente **no** como pendiente ni como
  alerta activa (instrucción explícita del usuario: motor/engine ya corregido ≠ alerta).

### PR03 — Confirma P02 (binding de resultsets) de BB_MINERIA, ahora con mecanismo piloteado

- El cambio v3→final de la sección 4 es la instancia concreta — con evidencia byte a byte dentro del
  propio ciclo de revisión Banco, no solo inferida de un corte único — del patrón P02 ya catalogado
  ("la misma información llega en formas físicas distintas; comparar sin contrato puede perder
  filas"). Y la capacidad `binary-comparison` de `gengis-me-pilot` es la primera implementación
  concreta (no solo candidata opt-in) de parte del patrón C02 para esta ME específica.

### PR04 — La HU formal se corrobora con evidencia, no se asume (cierra un PENDIENTE de BB_MINERIA)

- BB_MINERIA dejó "M7 … Asociación contextual previa NCBE-1117; falta corroborarla" como abierto.
  Esta ronda lo corrobora con evidencia directa de Jira + hash de archivo: dato pasa de INFERENCIA a
  OBSERVADO (sección 1).

## 6. Lo que no se pudo verificar / queda pendiente

- No se leyeron los adjuntos de imagen (`.jpg`/`.png`, As-is/To-be de arquitectura) de NCBE-1244 —
  es evidencia visual de un hallazgo ya clasificado NO-QA; no se consideró necesaria para el
  aprendizaje de la ME.
- No se verificó si el drift de DICCIONARIO detectado por el piloto (repo primario "Pendiente" vs
  repo fallback completo, al 2026-10-05) sigue vigente hoy — podría haber cambiado desde esa fecha;
  esta ronda no tocó Sybase ni repos del micro para confirmarlo.
- NCBE-2672 ("Pruebas de rendimiento") y NCBE-1548 ("Matriz equivalencia SP vs microservicio",
  sub-task separada del mismo padre, probablemente el lado "entrega" frente a NCBE-1117 "revisión")
  existen pero quedaron deliberadamente fuera de esta ronda por alcance explícito.
- `report_sp_structure_templateV2.html` (adjunto a NCBE-1117, también presente en los resultados
  locales) no se inspeccionó en detalle — es un reporte estructural auxiliar, no la ME misma.

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas** (API REST v2, credenciales ya exportadas en el entorno, sin
  almacenarlas): NCBE-1105 (campos summary/description/issuetype/status/parent/issuelinks/subtasks,
  15 subtareas + 6 issuelinks "relates to"); NCBE-1117 (campos + 7 adjuntos + 7 comentarios);
  NCBE-1244/1474/1480/1481/2929/3276 (campos + comentarios).
- **Verificación de hash:** el adjunto final de NCBE-1117 se descargó una sola vez a `/tmp` (nunca al
  repo), se verificó su SHA-256/tamaño, se comparó contra M7 de
  `BB_MINERIA_COMPARATIVA_9_ME_2026-10-02.md` y contra el profile `m7-pa-fir-consulta-firmante.json`
  de `gengis-me-pilot` (los tres coinciden: `a6a9f60b7f5ccc62538e865fb93f2420e37c63243ad2110504ac4c3573ab342f`,
  117516 bytes), y se borró del filesystem temporal tras el uso. También se descargaron v1/v2/v3
  temporalmente para el diff de la sección 4, igualmente borradas tras el uso.
- **Piloto `gengis-me-pilot` consultado solo en modo lectura:** `README.md`,
  `contracts/binary-comparison.md`, `profiles/m7-pa-fir-consulta-firmante.json`,
  `reports/m7_report.md`, `reports/run_resolution.json`. No se ejecutó ningún script del piloto, no
  se modificó nada allí.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #1** de la serie de aprendizaje documental solicitada por el usuario. Ver también
  el índice `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md` en esta misma carpeta. Pendiente: el usuario
  indicará el siguiente ticket padre y su HU.

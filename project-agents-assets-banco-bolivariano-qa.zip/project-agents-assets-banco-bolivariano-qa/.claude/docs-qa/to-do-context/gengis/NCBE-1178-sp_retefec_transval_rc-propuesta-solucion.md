# VEREDICTO_PROPUESTA_SOLUCION_TRANSVAL_NCBE_1178

> Auditoría técnica de solución, READ-ONLY. Sin modificaciones de código, sin ejecución.
> Fecha: 2026-09-03.
> Repo librería auditado: `/home/ssm-user/bb-core-cob-cuentas-utils-develop-dvp-ncbe1169/sp-retefec-transval-rc-utils`
> (el repo `bb-core-cob-cuentas-utils` original estaba en otra rama ajena, `feature/NCBE-1167...`, sin el
> módulo; se usó la copia `develop-dvp`, verificada byte a byte idéntica contra `cob-cuentas-l8-recovery`,
> mismo último commit `73bcb6c` del 12-ago).
> Micro auditado: `/home/ssm-user/cpas-mso-retefec_transval_rc`.

## 1. ROOT_CAUSE_CIRCUITBREAKER

**Flujo real confirmado** (código leído, no inferido):

```
cob_remesas..sp_verifica_cupos_rc (u otro SP hijo)
  → en cierta condición de negocio, hace RAISERROR/sp_cerror con codigo>=20000
  → JDBC/Spring lo traduce a DataAccessException (envolviendo un SQLException con getErrorCode()=codigo)
  → SpVerificaCuposLegacyAdapter.ejecutar(): catch (DataAccessException e) { throw new PersistenceException(OP, e.getMessage(), true); }
  → @CircuitBreaker(name=CB_NAME) ve PersistenceException como failure (config default: sin recordExceptions/ignoreExceptions)
  → tras N fallas "funcionales" repetidas se abre el breaker → ejecutarFallback() → PersistenceException.operacionNoDisponible(...)
  → sube sin traducción específica hasta GlobalExceptionHandler/gRPC service
```

**Archivos/clases exactas** (las 4 mencionadas, confirmado idéntico patrón en las 4):
- `infrastructure/outbound/legacy/SpVerificaCuposLegacyAdapter.java` (`catch (DataAccessException e) { ...; throw new PersistenceException(OP, e.getMessage(), true); }`)
- `SpCcRetiroEfectivoLegacyAdapter.java` — idéntico
- `SpAhRetiroEfectivoLegacyAdapter.java` — idéntico
- `SpUpdTotalesLegacyAdapter.java` — idéntico

**Punto exacto donde se pierde la semántica funcional:** el `catch (DataAccessException e)` de cada adapter no distingue nada — cualquier `DataAccessException` (RAISERROR de negocio o timeout real) se convierte en el mismo `PersistenceException`, y `resilience4j.circuitbreaker.configs.default` (en `application.properties`, sin `record-exceptions`/`ignore-exceptions`) cuenta **cualquier excepción** del método decorado como failure.

**Hallazgo adicional importante (verificado con evidencia real, no supuesto):** se revisó `GlobalExceptionHandler` (REST) y `RetefecTransvalRcGrpcService` (gRPC) del micro completos. **No existe ningún handler específico para `PersistenceException`** — cae en `@ExceptionHandler(Exception.class)` → **HTTP 500**, y en gRPC en el `catch (Exception e)` genérico → **`Status.INTERNAL`**, no 503/UNAVAILABLE como se documentó históricamente. Se revisó también `bolivariano-commons-2.0.0.jar` (única dependencia común compartida) — no contiene ningún handler de excepciones ni relación con CircuitBreaker. Se marca esto como discrepancia a reconciliar: o el síntoma 503/UNAVAILABLE viene de evidencia de ejecución real no reproducible estáticamente, o el código actual realmente devuelve 500/INTERNAL. No cambia el diagnóstico de fondo (clasificación ausente), solo el código de estado final observado.

## 2. ROOT_CAUSE_O_COMISION

**Flujo real confirmado, con DOS causas distintas (no una sola):**

**(a) Ruta AHORROS — pérdida total, no solo de NULL:**
```
SpAhRetiroEfectivoLegacyAdapter.leerResultado() → new ResultadoRetiroEfectivo(ret, ..., null, ...)   // oComision hardcodeado a null, correcto (sp_ahretiro_efectivo_rc no tiene o_comision)
SpRetefecTransvalRcLibrary.aplicarResultadoAho(ctx, ah) → NUNCA copia ah.oComision() a ctx.oComision
ctx.oComision queda en su default de campo: Money.zero()  ← BUG
```

**(b) Ruta CORRIENTE y todas las rutas de rechazo temprano (parámetro ausente, canal CNB, cupos excedidos, totales, etc.):**
```
Contexto.oComision (linea 141): private Money oComision = Money.zero();   ← BUG (default incorrecto)
```
`aplicarResultadoCte()` SÍ copia correctamente (`ctx.oComision = cc.oComision();`, y `SpCcRetiroEfectivoLegacyAdapter` YA preserva null correctamente vía `rs.wasNull() ? null : Money.of(comision)`). Pero **cualquier camino que no llegue a `aplicarResultadoCte`** (early-return de `validarControlesYCaja`, `verificarCuposPrevio`, `verificarCuposSupervisor`, `actualizarTotales` con error, y toda la rama AHO) nunca sobrescribe el default → siempre 0.00.

**Archivo/línea exacta del bug:** `SpRetefecTransvalRcLibrary.java:141` (`Contexto.oComision`) + `SpRetefecTransvalRcLibrary.java:400-411` (`aplicarResultadoAho`, no copia `oComision`).

**El resto de la cadena está limpio** (verificado, no supuesto):
- `ResultadoRetiroEfectivo` (record) — sin coerción.
- `RetefecTransvalRcResult.Builder` — sin coerción, pasa `Money` tal cual (null incluido).
- **gRPC mapper** (`RetefecTransvalRcGrpcMapper.java:93-94`): `if (o.oComision() != null) { d.setOComision(DoubleValue.of(...)); }` — **ya usa correctamente el wrapper `DoubleValue` del proto** para representar ausencia.
- **REST mapper**: pass-through simple, sin coerción visible en la línea (no se alcanzó a verificar el tipo exacto del DTO, pero no hay lógica de default ahí).

## 3. EXISTING_BANK_PATTERNS

| Patrón | Módulo/clase/método | Por qué es relevante |
|---|---|---|
| **Clasificador de código de negocio** | `bb-core-cob-ahorros-utils/sp-ah-retirond-rc-utils/.../legacy/LegacyErrorClassifier.java` (idéntico en 9 módulos: `sp-ah-depositosl-rc-utils`, `sp-ah-retirond-cl(-car)-utils`, `sp-dir-est-cta-utils`, `sp-telefono-utils`, `pa-pag-bcubo-cnb-utils`, `sp-pr-cobros(-coninfo)-utils`, etc.) | `codigoNegocio(Throwable)` recorre `getCause()`+`SQLException.getNextException()` y devuelve el `getErrorCode()` vendor si es `>= 20000` (umbral **idéntico en las 9 copias**, convención real del banco). Es exactamente el discriminante que hace falta. |
| **Aplicación directa a la MISMA SP que llama Transval** | `bb-core-cob-ahorros-utils/sp-ah-retirond-rc-utils/.../SpVerificaCuposLegacyAdapter.java:65-77` | Llama al **mismo** `cob_remesas..sp_verifica_cupos_rc` que Transval. `catch(RuntimeException e) { return desdeRaiserror(e); }` → si hay código de negocio, **retorna normalmente** un resultado con ese código (no lanza); si no, relanza. Prueba directa de que este SP concreto ya le dio este problema a otro equipo del banco, y así lo resolvieron. |
| **Nullability preservada en adapter JDBC** | `SpCcRetiroEfectivoLegacyAdapter.java` (el mismo módulo Transval) y `AbstractLegacyExecAdapter.getDoubleOrNull/getIntOrNull` (`sp-ah-depositosl-rc-utils`) | `rs.wasNull() ? null : Money.of(x)` / `rs.wasNull() ? null : v` — patrón nullable ya usado y correcto; confirma que el problema NO está en el acceso JDBC. |
| **gRPC wrapper para ausencia** | `RetefecTransvalRcGrpcMapper.java:93-94` (el mismo micro) | `if (o.oComision()!=null) d.setOComision(DoubleValue.of(...))` — ya implementado correctamente, no requiere cambio de proto. |

**Clasificación: EXISTING_GOOD_PATTERN** (ambos casos — CircuitBreaker y nullability — tienen patrón bancario ya probado y reutilizable, no hace falta inventar nada).

## 4. PATTERN_SCOPE

- **CircuitBreaker sin clasificación:** 213 archivos con `@CircuitBreaker` en `outbound/legacy/` **sin** `LegacyErrorClassifier` en su carpeta, contra 94 que **sí** lo tienen, repartidos en 25+ módulos de al menos 8 repos (`cob-giros`, `db-biz-pagos`, `cob-internet`, `cob-cuentas`, `cob-atm`, `db-biz-cobros`, `cob-remesas`, `db-biz-admempresa`). Transval aporta 6 de esos 213.

**CIRCUITBREAKER_PATTERN_SCOPE = REPEATED_IN_MULTIPLE_MODULES** (con evidencia de que ~1/3 del código YA migró al patrón correcto — esto es "ponerse al día con una convención interna ya probada", no una idea nueva).

- **`Money.zero()` como default de output que debería ser nullable:** encontrado en `sp-cnb-consulta-comision-utils`, `sp-cnb-pago-comision-utils`, `sp-reactivacion-cc-utils` además de Transval — mismo family de módulos `cob_cuentas`.

**MONEY_ZERO_PATTERN_SCOPE = REPEATED_IN_MULTIPLE_MODULES** (alcance menor que el de CircuitBreaker, pero no aislado).

## 5. FIX_CIRCUITBREAKER

**A. Dónde clasificar:** dentro del propio adapter, en el `catch`, **antes** de que cualquier excepción llegue al método decorado con `@CircuitBreaker` — exactamente como en `sp-ah-retirond-rc-utils`. No en el use case, no en un exception-translator central: así lo hace el único ejemplo bancario que llama al mismo SP.

**B. Con qué discriminar:** `SQLException.getErrorCode()` (vendor code) `>= 20000`, recorriendo `getCause()` y `getNextException()`. Es lo único que el driver expone de forma confiable aquí (no hay SQLState custom, ni columna de error en el resultset de estos 4 SPs).

**C. Categorías:** `BUSINESS_ERROR` (código>=20000) / `TECHNICAL_ERROR` (cualquier otra `DataAccessException`) / `UNKNOWN_ERROR` = tratar como `TECHNICAL_ERROR` (fail-safe: si no se puede probar que es negocio, que cuente para el breaker — es más seguro subestimar disponibilidad que enmascarar una caída real).

**D/E. Comportamiento y config Resilience4j:** **no tocar `application.properties`.** El patrón bancario de referencia resuelve esto sin `recordExceptions`/`ignoreExceptions`: convierte el `BUSINESS_ERROR` en un **retorno normal** (no una excepción) dentro del propio `catch`, así el CircuitBreaker nunca lo ve. Es más simple y menos propenso a error que mantener una lista de tipos de excepción a ignorar.

**Pseudocódigo (basado 1:1 en `sp-ah-retirond-rc-utils`, adaptado a la firma real de Transval):**
```java
// nuevo archivo: infrastructure/outbound/legacy/LegacyErrorClassifier.java (copiar el de sp-ah-retirond-rc-utils)

// SpVerificaCuposLegacyAdapter.java — cambio del catch:
} catch (DataAccessException e) {
    OptionalInt negocio = LegacyErrorClassifier.codigoNegocio(e);
    if (negocio.isPresent()) {
        return negocio.getAsInt();          // <- return normal, NO exception; CB no lo cuenta
    }
    log.error(...);
    throw new PersistenceException(OP, e.getMessage(), true);   // solo error tecnico real
}

// SpCcRetiroEfectivoLegacyAdapter / SpAhRetiroEfectivoLegacyAdapter (retornan ResultadoRetiroEfectivo):
} catch (DataAccessException e) {
    OptionalInt negocio = LegacyErrorClassifier.codigoNegocio(e);
    if (negocio.isPresent()) {
        return ResultadoRetiroEfectivo.deErrorNegocio(negocio.getAsInt());  // construir con los demas campos null
    }
    throw new PersistenceException(...);
}
```

**Clases a modificar:** 4 adapters + 1 clase nueva (`LegacyErrorClassifier`, copiada del patrón existente) = 5 archivos.
**Complejidad: LOW.** Sin cambio de API pública, sin cambio de contrato REST/gRPC, sin nueva versión de proto.
**Riesgo:** bajo — el cambio es aditivo (agrega un `if` antes del `throw` ya existente); el camino técnico real queda intacto.

## 6. FIX_O_COMISION

**Cambio mínimo (2 líneas, 1 archivo):**
```java
// SpRetefecTransvalRcLibrary.java, linea 141:
private Money oComision = Money.zero();   →   private Money oComision;   // default null

// aplicarResultadoAho(), agregar la linea que falta (paralelo a aplicarResultadoCte):
ctx.oComision = ah.oComision();
```
`Money` **ya** admite null como referencia (no requiere `Optional<Money>`, ni cambiar la clase) — el bug nunca estuvo en `Money`, estuvo en el valor con el que se inicializaba el campo.

**Comportamiento resultante (los 3 estados quedan distinguibles, probado a nivel de tipo):**
- Legacy NULL → adapter devuelve `null` (ya correcto) → `ctx.oComision=null` (con el fix) → REST: campo ausente/null en el DTO (según su tipo actual) → gRPC: `hasOComision()=false` (ya correcto, sin tocar el mapper).
- Legacy 0.00 → adapter devuelve `Money.of(0)` → se propaga como 0.00 en REST y gRPC (`DoubleValue.of(0.0)`, con `hasOComision()=true`).
- Legacy >0 → sin cambios, ya funciona hoy.

**Clases a modificar:** 1 (`SpRetefecTransvalRcLibrary.java`).
**Complejidad: LOW.** Sin cambio de API pública ni de proto/DTO (el REST mapper y el gRPC mapper no se tocan — ya están preparados para recibir null).
**Riesgo:** bajo — verificar que ningún consumidor downstream (REST DTO) asuma no-null sin chequeo (revisar el tipo del campo en `DatosRetefecTransvalRcDto` antes de mergear, ya que no se llegó a confirmar con certeza en esta sesión).

## 7. TEST_PLAN

**A. Unitarios CircuitBreaker/clasificación** (sobre `LegacyErrorClassifier` + cada adapter, mockeando `SQLException` con `getErrorCode()` controlado):
1. `SQLException(errorCode=31017)` (negocio conocido, análogo al que ya usa `sp-ah-retirond-rc-utils`) → adapter retorna normal, **no** lanza `PersistenceException`.
2. Timeout real (`getErrorCode()=0` o código fuera de rango de negocio, ej. driver timeout) → `PersistenceException` lanzada, CB cuenta failure.
3. Conexión caída (SQLException genuina de infraestructura) → fallback invocado tras abrir breaker.
4. Código desconocido (ni negocio ni catalogado como técnico específico) → tratado como técnico (documentar explícitamente esta decisión en el test).
5. 10 llamadas seguidas con código de negocio (>= `minimum-number-of-calls=5`) → breaker permanece `CLOSED` (assert vía `CircuitBreakerRegistry`).

**B. Unitarios o_comision** (sobre `SpRetefecTransvalRcLibrary.ejecutar`, mockeando los ports):
1. `ccRetiroEfectivoPort` retorna `oComision=null` → `RetefecTransvalRcResult.oComision()==null`.
2. `oComision=Money.of(0)` → resultado `0.00`, no null.
3. `oComision=Money.of(15.5)` → resultado `15.5`.
4. Repetir 1-3 para la ruta AHORROS (`ahRetiroEfectivoPort`), que hoy no tiene ningún test que lo cubra porque el campo nunca se copiaba.

**C. Integración — canarios:**
- **CircuitBreaker:** **TC13** y **TC37** (elegir 2 con distinta rama: si TC13 es la más simple/aislada de `sp_verifica_cupos_rc` y TC37 corresponde a retiro corriente/ahorros con causa distinta, cubren los dos adapters con evidencia directa de RAISERROR conocido). Objetivo: confirmar `RETURN` funcional real, no 500/503.
- **Nullability:** **TC01** (si corresponde a un rechazo temprano, valida el fix del default de `Contexto`) y **TC26** o **TC42** si corresponde a un caso AHORROS real (valida el fix de `aplicarResultadoAho`). Elegir uno de cada familia de causa para no dejar ninguna de las dos causas sin canario.

*(No se tenía en esta sesión el documento de 44 TCs para confirmar cuál TC exacto corresponde a cuál rama — se recomienda confirmar contra `LEGACY_EVIDENCE_COMPLETE=44/44` antes de fijar los canarios definitivos.)*

## 8. ANTI_PATTERNS

| Propuesta | Por qué NO |
|---|---|
| Hardcodear 31017/41033/etc. individualmente en cada adapter | Frágil: cada SP nuevo o código nuevo de negocio requiere tocar código; el clasificador por rango (`>=20000`) ya es la convención bancaria y escala sin mantenimiento. |
| Desactivar CircuitBreaker completamente | Elimina la protección real contra caídas de infraestructura (que sí existen y son el propósito legítimo del breaker). |
| Devolver siempre HTTP 200 | Oculta errores de negocio reales al consumidor; rompe el contrato (el legacy sí distingue códigos). |
| Atrapar `Throwable`/`Exception` genérico | Ya es lo que pasa hoy en el nivel REST/gRPC (`catch(Exception e)`) y es parte del problema de diagnóstico (todo se ve igual); no hay que ampliarlo, hay que reducirlo con la clasificación aguas abajo. |
| Convertir cualquier `DataAccessException` en error funcional | El extremo opuesto al bug actual: ocultaría caídas reales de Sybase como si fueran rechazos de negocio. |
| Mantener `Money.zero()` y "arreglarlo" en el mapper | Ya es tarde ahí: el mapper (gRPC) ya distingue null correctamente; el defecto está aguas arriba. Arreglarlo en el mapper sería un parche sobre un dato ya corrompido, y dejaría el defecto abierto para el REST mapper y cualquier otro consumidor de `RetefecTransvalRcResult`. |
| Modificar expected de QA para aceptar 503 o 0 | Invierte la responsabilidad: el contrato legacy (RETURN funcional / NULL) es la fuente de verdad; adaptar QA al bug lo convertiría en "comportamiento esperado" permanentemente. |
| Crear excepciones distintas por cada TC | Sobre-ingeniería; el patrón de 3 categorías (BUSINESS/TECHNICAL/UNKNOWN) ya cubre todos los casos sin explosión combinatoria. |

## 9. IMPLEMENTATION_ORDER

1. Copiar `LegacyErrorClassifier.java` de `sp-ah-retirond-rc-utils` al mismo paquete `infrastructure.outbound.legacy` de `sp-retefec-transval-rc-utils` (ajustar `package`).
2. Escribir los 5 unit tests de clasificación (A.1-A.5) contra el classifier + un adapter, en rojo.
3. Aplicar el cambio de `catch` en `SpVerificaCuposLegacyAdapter` (el que tiene prueba directa vía el módulo hermano) → verde.
4. Repetir 3 para `SpCcRetiroEfectivoLegacyAdapter`, `SpAhRetiroEfectivoLegacyAdapter`, `SpUpdTotalesLegacyAdapter`.
5. Fix de `o_comision`: quitar `= Money.zero()` en `Contexto` + agregar la línea faltante en `aplicarResultadoAho`.
6. Escribir/correr los unit tests B.1-B.4.
7. Correr toda la suite unitaria existente del módulo (regresión).
8. Publicar nueva versión de librería (ej. `1.0.6-snapshot` o la que corresponda a convención del banco).
9. Actualizar el micro a la nueva versión, rebuild, ejecutar los canarios de integración (C) contra un ambiente controlado.
10. Solo si los canarios pasan: redeploy del micro en `bb-dev-core`, y recién ahí notificar a QA para reejecutar la Matriz de Equivalencia completa.

## 10. DEFINITION_OF_DONE

- [ ] Error funcional Legacy (código>=20000) no produce 503/UNAVAILABLE (ni el 500/INTERNAL actual) — produce el `RETURN`/mensaje funcional esperado.
- [ ] Error técnico real (timeout, conexión caída) conserva la protección del CircuitBreaker sin cambios.
- [ ] Errores funcionales repetidos (≥5, ≥50% del sliding window) **no** abren el breaker.
- [ ] `o_comision` NULL en Legacy permanece ausencia (null) en el resultado, incluida la ruta AHORROS.
- [ ] `o_comision` 0.00 en Legacy permanece 0.00 explícito (no confundido con ausencia).
- [ ] Los tests unitarios de las secciones A y B pasan (100%).
- [ ] Los canarios de integración elegidos pasan.
- [ ] Nueva versión de `sp-retefec-transval-rc-utils` publicada.
- [ ] Micro `cpas-mso-retefec_transval_rc` reconstruido contra esa versión.
- [ ] Nueva imagen desplegada en `bb-dev-core` (digest distinto de `sha256:c0eba0dd...`, verificable vía ImageStream).
- [ ] Solo entonces: QA reejecuta la Matriz de Equivalencia de los 44 TCs.

## 11. MENSAJE_TECNICO_PARA_DESARROLLADOR

> Hola — revisando NCBE-1178 encontramos dos causas puntuales, ambas con solución acotada. (1) En los 4 adapters legacy de retiro/cupos, `catch(DataAccessException)` envuelve *todo* en `PersistenceException`, y el CircuitBreaker cuenta hasta los rechazos de negocio (ej. cupo excedido) como caídas técnicas — por eso el breaker se abre. La buena noticia: `sp-ah-retirond-rc-utils` ya resolvió esto mismo para el mismo SP (`sp_verifica_cupos_rc`) con un `LegacyErrorClassifier` (código vendor `>=20000` = negocio, retorna normal en vez de lanzar). Es copiar ese patrón, no inventar uno. (2) `o_comision` sale siempre en 0.00 porque el campo de contexto en `SpRetefecTransvalRcLibrary` línea 141 inicializa en `Money.zero()` y la rama de ahorros nunca lo sobrescribe — quitar ese default y agregar una línea en `aplicarResultadoAho` resuelve ambos casos; el resto de la cadena (JDBC, gRPC) ya maneja null bien. Puedo mostrarte los archivos exactos si te sirve.

---

**No se modificó ni ejecutó nada durante esta auditoría.**

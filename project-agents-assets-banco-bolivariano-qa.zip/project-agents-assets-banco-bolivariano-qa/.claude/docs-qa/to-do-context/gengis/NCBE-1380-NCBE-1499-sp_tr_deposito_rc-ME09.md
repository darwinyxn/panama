# Aprendizaje personal piloto gengis-me — ME #9: sp_tr_deposito_rc (NCBE-1380 → NCBE-1499)

Fecha de esta ronda: 2026-10-30. Novena entrega de la serie. Este SP es, literalmente, el de la
**sesión que originó la regla de inmutabilidad documentada en el `CLAUDE.md` de este repo**: "El
2026-09-22 (sesión `sp_tr_deposito_rc`), un intento de sincronizar un fix del motor hacia este
repo casi sobrescribió trabajo real sin commitear de otra persona." El 22-sep es, exactamente, el
día más intenso de este hilo (ver sección 4) — no se investiga más ese incidente aquí porque ya es
contexto canónico documentado del propio repo; solo se señala la coincidencia. No se hicieron
consultas a Sybase/REST/gRPC, no se reejecutó nada, no se modificó Jira/QMetry/motor/repos/ME.

## 1. Identidad y relación de tickets (OBSERVADO en Jira)

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1380 | Story | Padre | Microservicio Depósito Cta Corriente |
| NCBE-1495 | Task | Pipeline (relates to) | Análisis de Stored procedure — cob_cuentas.sp_tr_deposito_rc |
| NCBE-1496 | Task | Pipeline (relates to) | Creación de casos de prueba funcionales y estructurales |
| NCBE-1497 | Task | Pipeline (relates to) | Consolidación de casos de prueba |
| NCBE-1498 | Task | Pipeline (relates to) | Generación de datos para casos de prueba |
| **NCBE-1499** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — cob_cuentas.sp_tr_deposito_rc** |
| NCBE-2869 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance, no tocado |

SP: `cob_cuentas.sp_tr_deposito_rc`. Micro: `cpas-mso-tr-depositos-rc`. 21 TCs.

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

NCBE-1380 tiene 15 subtareas: 6 `Sub-task` de checklist sin bug; 8 `Defecto` con contenido real; y
4 tickets tipo **Epic** enlazados como "relates to" (NCBE-2722/2723/2725/2726) que, pese al tipo
inusual, son hallazgos de equivalencia reales por TC, no contenedores de trabajo mayor.

### Grupo A — Mensajería/campos espurios en la evidencia (NCBE-2245, 2248) → **QA real, confirma un patrón nuevo (PR29)**

- **NCBE-2245** (TC17-21): el SP mostraba `mensaje_debug` con contenido real mientras REST/gRPC
  daban `null`. Al corregirlo, apareció un efecto colateral: el campo pasó a un `result_set` con un
  valor **hasheado** (`filas_sha256`) que Banco no entendía ("esta encriptada y no se sabe a que
  hace referencia") — quedó sin resolución explícita documentada, aceptado tácitamente.
- **NCBE-2248:** el campo `engine_exception` (valor `null`) aparecía en la respuesta compartida con
  Banco sin pertenecer a la estructura real del servicio. Causa confirmada: **"correspondía a un
  dato de evidencia interna de nuestro proceso de pruebas incluido por error en la evidencia
  compartida"** — no era un campo real del microservicio, era un artefacto de la propia herramienta
  QA filtrado hacia la evidencia que se le muestra a Banco.
- **Clasificación:** QA real — en ambos casos la causa no es el microservicio, sino que el proceso
  de captura/evidencia de la ME filtró datos internos de la propia herramienta hacia la evidencia
  visible. Ver PR29 — este patrón se repite con el campo `"cupos"` en la sección 4.
- **Bloqueo transitorio de ambiente, sin atribución clara:** durante la resolución de ambos, las 3
  conexiones a Sybase reportaron `Stored procedure 'cob_cuentas..sp_deposito_completo' not found`
  — un SP distinto al de este caso, bloqueando toda la matriz por un rato. Se resolvió sin que el
  hilo documente quién ni cómo exactamente; no se investiga más, queda como bloqueo de ambiente
  transitorio.

### Grupo B — Representación de datos (NCBE-2246, NCBE-2300) → **1 real confirmado, 1 explicado y cerrado sin cambio**

- **NCBE-2246** (TC18): REST truncaba/redondeaba `oNeto` (enviado `i_efe=100.05`, respuesta
  `oNeto="100.00"`) aunque la BD sí guardaba el valor exacto. Confirmado como defecto real del
  microservicio (redondeo indebido) y corregido por Migración; verificado 21/21 EQUIVALENTE.
- **NCBE-2300** (TC01): diferencia de decimales en el dashboard (`o_impuesto`/`o_neto` mostrados a
  4 decimales vs. 2 en BD) — **explicado y cerrado sin cambio de código**, citando explícitamente
  el contrato ya acordado en **NCBE-1644 (ME #4)**: el motor usa `tsql`/FreeTDS (Linux), que
  renderiza `money` con 4 decimales por defecto; el cliente de Banco usa ISQL/w (Windows nativo),
  que renderiza el mismo valor con 2. Mismo valor interno, dos formatos de presentación de cliente
  distintos — no es pérdida de precisión. Banco aceptó la explicación y cerró. Confirma que el
  criterio de NCBE-1644 se está reutilizando correctamente en otro SP, no reinterpretado.

### Grupo C — Defecto real de librería compartida, mismo mecanismo que NCBE-2214 de la ME #6 (ver sección 4) → **QA real, el hallazgo más importante de esta ronda**

Documentado íntegramente dentro de los comentarios de la propia HU NCBE-1499 — ver sección 4.

### Grupo D — Fixture/aislamiento (NCBE-2279, NCBE-2377) → **QA real, resuelto, de los propios scripts de prueba**

- **NCBE-2279** (TC21): 18 TCs comparten la misma clave `tm_secuencial=100001`; el documento Banco
  ya traía limpieza defensiva para TC01/16/17/19 pero no para TC21 — se agregó el mismo mecanismo
  (no un patrón nuevo). Resuelto.
- **NCBE-2377** (TC03): el dashboard mostraba `130028` mientras Sybase devolvía `300003178` —
  vinculado a reinicios/alteraciones de BD del lado Banco que invalidan PRE/POST entre entregas (un
  riesgo de falso positivo ya advertido explícitamente por el equipo QA). Resuelto tras ajustes,
  confirmado 100% equivalencia y validado en REST y gRPC.

### Grupo E — Autorización y diseño de `result_set` (NCBE-2753, NCBE-2818) → **decisión de gobierno + fix real, bien razonado**

- **NCBE-2753** ("Obtener OK para agregar resultsets en las respuestas", Sub-task): agregar
  resultsets a las respuestas **requirió autorización formal de Arquitectura y DevOps** antes de
  poder implementarse — un gate organizacional, no solo técnico, para cambiar el contrato de
  respuesta. Cerrado con el OK adjunto.
- **NCBE-2818:** una vez autorizado, se analizó con cuidado QUÉ datos del SP debían incluirse en
  `result_set`: de los 3 `SELECT` sin alias del SP, solo `NoTrn` es un valor genuinamente nuevo (no
  existe como OUTPUT formal); los otros 2 (`@o_nombre`, `@o_impuesto`/`@o_neto`) nunca se
  reasignaban después de esos SELECT, así que ya viajaban idénticos en `output_params` — duplicarlos
  en `result_set` no aportaría información nueva. Decisión verificada leyendo el código fuente del
  SP (líneas citadas). Cerrado con evidencia.
- **Clasificación:** QA real con una capa de gobierno de cambio de contrato — útil distinguir que
  no todo "fix de equivalencia" es puramente técnico; algunos requieren aprobación organizacional
  previa porque cambian la forma pública de la respuesta.

### NCBE-2855 — "Actualización de reporte veracode" → **NO ES QA (seguridad/checklist administrativo, confirma patrón ya visto)**

- Mismo patrón recurrente de toda la serie: actualizar el reporte de Veracode, 1 iteración por un
  hallazgo de Code Quality, cerrado con el OK de Seguridad Informática (ticket externo `RDV-1068`).

### Grupo F — 4 "Epic" de equivalencia de mensajes (NCBE-2722, 2723, 2725, 2726) → **QA real, confirmados y corregidos**

- **NCBE-2722** (TC11): mensaje de rechazo distinto entre SP ("ESTE ORIGEN DE CTA NO PERMITE USAR
  ESTE CODIGO") y REST/gRPC. Se detectó como error introducido por una entrega posterior al 10-sep;
  corregido, confirmado 100% equivalencia funcional entre los 3 canales.
- **NCBE-2723** (TC11, obligatoriedad de `i_cta`): el SP exige el parámetro (`Msg 201` nativo si se
  omite) pero REST/gRPC no lo exigían de la misma forma. Corregido y verificado en vivo: gRPC
  omitiendo `i_cta` responde `-6` con el mensaje literal del motor Sybase, igual que REST — paridad
  confirmada.
- **NCBE-2725** (TC12) y **NCBE-2726** (TC13/TC14): mismo patrón — mensaje de negocio del SP no
  coincidía textualmente con el de REST/gRPC ("ESTE ORIGEN DE CTA NO ESTA ASOCIADO A ESTE CODIGO",
  "ESTA TRANSACCION DEBE HACERLA POR DEPOSITO ESPECIAL"). Ambos corregidos y confirmados con
  equivalencia funcional verificada en los 3 canales.
- **Clasificación:** QA real — divergencia de texto de mensaje de negocio entre canales, el mismo
  tipo de hallazgo que P03/C03 de BB_MINERIA, aquí con 4 instancias concretas más.

## 3. Hallazgo principal de los bugs del padre

Igual que en la ME #8, este padre tiene bugs de QA genuinamente reales en casi todos sus 12
tickets de contenido (8 Defecto + 4 Epic), con solo 1 excepción NO-QA (Veracode). La mayoría son
defectos reales del microservicio o de la propia herramienta de captura de evidencia — no ruido de
arquitectura/CI.

## 4. El hallazgo más importante: defecto de librería compartida, mismo mecanismo que NCBE-2214 (ME #6), y el episodio del 22-sep

Documentado íntegramente en los 23 comentarios de NCBE-1499:

- **25-ago:** corrida inicial 21 TC — el SP está 100% sano, pero el microservicio falla en 18/21 con
  2 patrones: **Patrón A** (`codigoRetorno` colapsa a `-1` genérico en vez de propagar el código de
  rechazo real del SP) y **Patrón B** (`S0022: Invalid column name 'sp_return'` en caminos
  exitosos, con `data=null`).
- **28-ago:** librería `cpas-bb-routecore-cobis`/`cpas-bb-contentbased-router-core` actualizada a
  1.0.1 — resuelve el Patrón A.
- **03-sep:** tras redespliegue con librería 1.0.4, persiste el Patrón B
  (`DepositoCteAdapter.depositar()`/`AbstractCobisAdapter`, afecta TC01/15/16/17/18/19). **Causa
  diagnosticada: `executeSelectProcedure` lee solo el PRIMER resultset con `executeQuery()` y busca
  `sp_return` ahí; si el SP emite resultsets intermedios antes del resultset envoltorio, falla.**
  **Esto es, mecánicamente, el MISMO defecto que NCBE-2214 (ME #6, `cpas-mso-ah-retirosl`)
  diagnosticó para la misma familia de librería compartida** — aquí ocurre en un microservicio
  distinto, consumiendo la misma librería, diagnosticado de forma independiente. Ver PR28.
- **07-sep al 10-sep:** varias cargas de ME alcanzando "100% 21/21", con ajustes de precondición
  (apertura de cajas en TC11-TC16) tras reinicios de BD del lado Banco.
- **14-sep:** nueva ronda de alteraciones por reinicios de BD — 4 TCs (TC03, TC18, TC20, TC21)
  fallan por ausencia de datos base, no por lógica de negocio. QA reporta el detalle exacto y pide
  guía; Banco ajusta cuentas en el ambiente.
- **16-sep — autogestión QA completa, sin requerir a Banco:** tras la restauración de Banco, 7 TCs
  seguían fallando por un hallazgo propio: el cupo transaccional (`cobis..cl_cupos_clientes`) de los
  clientes de prueba estaba casi agotado en el ambiente restaurado. **QA extendió su propio patrón
  de respaldo/restauración dinámica (ya usado para ALCNB/cc_moneda) para cubrir también
  `cu_utilizado`** — cada TC respalda el valor real, lo libera para el EXEC, y lo restaura exacto en
  el POST. Resuelto 100% por QA, verificado sin fuga de dato real (valores de cupo idénticos antes/
  después).
- **22-sep (coincide con el incidente del `CLAUDE.md`):** tras la autorización de NCBE-2753, se
  aplican mejoras "tanto al micro como al motor qa" para el formato de `result_set`. El mismo día,
  Priscila detecta una etiqueta `"cupos": []` en la respuesta REST que no corresponde a ninguno de
  los 3 `result_set` reales del SP y pide que se retire. **Verificado en esta ronda: el último JSON
  adjunto a NCBE-1499 (22-sep, 1214993 bytes, SHA-256 `f6b7c8e58cfddfe78165ee57aeaf38fe7e640fa3cab92a002cd36c6d663f302f`)
  SÍ sigue conteniendo `"cupos": []` en TC01, y no hay ningún adjunto posterior** — la observación de
  Priscila (13:35) es posterior a la subida de ese archivo (10:59) y la ME nunca se volvió a cargar
  antes del cierre (23-sep). El campo `"cupos"` muy probablemente es un residuo visible del propio
  mecanismo de respaldo/restauración de cupo del punto anterior, filtrado hacia la respuesta REST
  real — **segunda instancia del mismo patrón de PR29** (datos internos de la operación QA
  filtrándose hacia la evidencia que ve Banco), ahora en el propio cuerpo de la respuesta, no solo
  en un campo de diagnóstico.
- **23-sep:** cierre formal de la revisión ("se Finaliza la revisión del micro"), sin evidencia en
  Jira de que el campo `"cupos"` fuera removido antes del cierre.

## 5. Contraste con la ME final (NCBE-1499)

- **Universo:** 21 TCs, 9 grupos, **21/21 EQUIVALENTE** en el último adjunto verificado.
- **Residuo sin cerrar explícitamente:** el campo `"cupos": []` señalado por Priscila el mismo día
  del cierre sigue presente en el último archivo adjunto — no se puede confirmar desde Jira si se
  corrigió en una entrega no adjuntada o si simplemente no se volvió a revisar antes de cerrar.
- Los 8 Defecto + 4 Epic de la sección 2 sí dejan rastro directo en la evolución de la ME (igual que
  en la ME #8) — ninguno es ruido ajeno a la revisión.

## 6. Patrones agrupados por causa o comprobación reusable (nuevos de esta ronda)

### PR28 — El mismo defecto de lectura de resultset de la librería compartida de "bifurcación" reaparece en un segundo microservicio, diagnosticado independientemente (confirma y extiende PR08)

- **Evidencia:** `AbstractCobisAdapter`/`executeSelectProcedure` leyendo solo el primer resultset y
  buscando `sp_return` ahí — diagnosticado en NCBE-2214 (ME #6, `cpas-mso-ah-retirosl`) y de nuevo
  aquí (NCBE-1499, `cpas-mso-tr-depositos-rc`), sin que ningún comentario cite el caso anterior.
- **Comprobación reusable:** si aparece `S0022: Invalid column name 'sp_return'` (u otro síntoma de
  resultset incompleto) en CUALQUIER microservicio que use la librería "bifurcadora"
  (`cpas-bb-routecore-cobis`), tratarlo como una instancia conocida de este defecto de clase, no
  como un hallazgo aislado — y verificar la versión de la librería consumida antes de re-diagnosticar
  desde cero.

### PR29 — Datos internos del propio proceso QA pueden filtrarse hacia la evidencia que ve Banco, pareciendo campos reales del servicio (NUEVO, 2 instancias confirmadas en esta ronda)

- **Evidencia:** `engine_exception` (NCBE-2248, campo de diagnóstico interno de pruebas) y
  `"cupos": []` (sección 4, probable residuo del mecanismo de respaldo/restauración de cupo)
  aparecieron en la evidencia/respuesta mostrada a Banco sin ser parte real del contrato del
  servicio.
- **Comprobación reusable:** antes de publicar una ME, revisar si algún campo de la respuesta no
  tiene correspondencia con ningún `OUTPUT`/resultset documentado del SP ni con el DTO/proto real
  del microservicio — puede ser un artefacto de la propia instrumentación QA (fixture, backup de
  catálogo, diagnóstico interno) que se filtró por error hacia la evidencia compartida.

## 7. Lo que no se pudo verificar / queda pendiente

- No se confirma si el campo `"cupos": []` fue removido antes del cierre formal de NCBE-1499 — el
  único adjunto JSON que existe todavía lo contiene; no hay evidencia Jira de una corrección
  posterior.
- No se profundizó en el bloqueo transitorio `Stored procedure 'cob_cuentas..sp_deposito_completo'
  not found` (sección 2, Grupo A) — se resolvió sin que el hilo documente el mecanismo exacto.
- No se investigó la coincidencia de fecha con el incidente de propagación del motor documentado en
  el `CLAUDE.md` del repo más allá de señalarla — ese incidente ya está descrito como contexto
  canónico del propio proyecto, no requiere re-investigación aquí.
- No se inspeccionaron en detalle las 9 versiones de `.proto`/`qa_casos_prueba.md` adjuntas a
  NCBE-1499 más allá de las citadas explícitamente en los comentarios.

## 8. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1380 (campos + 15 subtareas + 10 issuelinks: 6 "relates to"
  pipeline/Task + 4 "relates to" Epic); NCBE-1499 (campos + 23 adjuntos listados, 1 descargado y
  verificado + 23 comentarios completos); los 8 Defecto + 4 Epic (campos + comentarios completos).
- **Verificación de hash:** el último adjunto JSON de NCBE-1499 (22-sep, 1214993 bytes) descargado
  temporalmente a `/tmp` (nunca al repo), hash confirmado (`f6b7c8e5...`), veredictos verificados
  (21/21 EQUIVALENTE), y confirmado por `grep` que el campo `"cupos"` sigue presente en TC01.
  Borrado tras el uso.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #9** de la serie. Ver índice `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`. Pendiente:
  el usuario indicará el siguiente ticket padre y su HU.

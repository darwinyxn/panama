# Aprendizaje personal piloto gengis-me — ME #15: sp_tr_pago_giro_rc (NCBE-1777 → NCBE-1839)

Fecha de esta ronda: 2026-11-01. Decimoquinta entrega de la serie, y la más extensa hasta ahora
por pedido explícito del usuario: **34 tickets "Defecto" reales** (contra 0-11 de las rondas
anteriores) y **20 versiones del JSON** de la ME en poco más de 3 semanas (28-sep a 23-oct). El
usuario pidió énfasis especial en el **DICCIONARIO** (sección 4) — esta ronda produjo el catálogo
de reglas de comparación más rico de toda la serie. No se hicieron consultas a Sybase/REST/gRPC,
no se reejecutó nada, no se modificó Jira/QMetry/motor/repos/ME.

**Nota de procedencia meta:** casi todos los comentarios de corrección en este padre y en su HU de
revisión están firmados por "Gengis Salvador Hidalgo Guevara" — la misma persona para quien esta
serie construye aprendizaje documental. Buena parte de esta ronda coincide con memoria propia de
sesiones previas de esta misma SP (`project_ncbe1777_*`, `project_qmetry_ncbe1777_load`) — es decir,
esta reconstrucción Jira **es la traza visible del propio trabajo de "gengis-me"** en su SP más
intenso, no un tercero reportando contra un trabajo ajeno. Cierra el círculo de la serie.

## 1. Identidad y relación de tickets

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1777 | Story | Padre | Procesar pago y reverso de giros y remesas |
| NCBE-1835/1836/1837/1838 | Task | Pipeline (relates to) | Análisis/Creación/Consolidación/Generación de datos |
| **NCBE-1839** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — cob_giros.sp_tr_pago_giro_rc** |
| NCBE-2871 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance |

SP: `cob_giros.sp_tr_pago_giro_rc`. Micro: `ecu-mso-tr-pago-giro-rc`. 105 TCs.

**Confirmación cruzada:** el adjunto final de NCBE-1839 (23-oct 13:24, `QA-CASOS-PARSEADOS.json`,
4299220 bytes, SHA-256 `1a0df2401a412d687c807edcfa8d86fa26020a99ae3c9593c0b7a4aea5f44919`, id
243670) coincide exactamente con memoria propia ("JSON vigente NCBE-1839 243670, HTML 243414") —
confirma por hash lo que antes era referencia de archivo.

## 2. Panorama de los 34 Defecto — clasificación agrupada

A diferencia de toda la serie anterior, **prácticamente ninguno de los 34 es ruido NO-QA puro**
(no hay SonarQube/Veracode/Prisma/build genéricos salvo 2 excepciones). Casi todos son hallazgos
reales de la revisión de equivalencia, reportados principalmente por el equipo "Testing BB" de
Banco (Viviana Intriago, Derick Delgado, Jose Fernando Plua Avila, Carla Parrales, Paola Sarango,
Priscila Pincay) y resueltos por Gengis Hidalgo directamente sobre la ME (no sobre el micro, salvo
3 casos tempranos). Se agrupan por causa, no uno por uno:

### A. Defectos reales de código, corregidos por Migración (3 tickets, septiembre)

- **NCBE-2857:** el micro trataba "sin indicador de corrección/reverso" como reverso (debía ser
  pago normal, igual que el default del SP). `o_retorno_ws` salía en `0` en vez de `null` donde el
  SP no lo asigna. Corregido en la librería, commit `b2f9d4d`.
- **NCBE-2904:** `sp_verifica_caja_rc` exponía un texto genérico ("Error al verificar caja") en vez
  del mensaje real del catálogo `cl_errores`. Confirma la regla ya conocida "no equiparar número de
  mensaje con RETURN" (31063 es el número del mensaje, no el código de retorno, que es `1`).
- **NCBE-2963:** un HTTP 500 se producía porque un error de motor (`Msg 515`, NULL en columna
  NOT NULL) que el SP traduce a código funcional se propagaba como error técnico sin clasificar.
  Corregido en los adapters de ejecución.

### B. Scaffold/captura de la ME — gaps de reproducibilidad (NCBE-3308, 3349, 3352, 3353, 3360)

- **NCBE-3308:** EXEC vacíos y placeholder `<URL>` en la ME; también faltaban Comandos/Resultados
  gRPC. Corregido en la entrega del 01-oct.
- **NCBE-3349:** el Dashboard no mostraba todos los parámetros de salida del SP en **19 TCs**
  (TC14,21,33,38,54,55,64,65,73,74,76,81,82,83,85,86,96,97,105).
- **NCBE-3352:** TC85 sin evidencia REST/cURL — resuelto con la entrega del 30-sep.
- **NCBE-3353 (TC83):** diferencia de `mensajeDebug` entre REST/gRPC — resuelto; Banco aclaró que el
  comportamiento esperado SÍ es mostrar el mensaje funcional ("CUPO REQUIERE DE AUTORIZACION...") en
  `mensajeDebug`, porque el cliente necesita saber el motivo del rechazo — una aclaración de
  contrato, no solo un bug.
- **NCBE-3360 (TC62):** la respuesta gRPC mostraba ahora campos array vacíos (`organiza`, `riesgo`,
  `controlCreditoInactivo`, `reverso`, `autorizacionBuzon`) que antes no aparecían en el dashboard —
  confirmado como esquema completo de la respuesta real, no un defecto.

### C. Mal archivados / NO-QA puro (2 tickets)

- **NCBE-4601:** reporte SonarQube/Prisma — NO-QA, build/calidad de código.
- **NCBE-4974:** "Actualizar nuevo package" — build/publicación de artefacto, NO-QA.

### D. Enmascaramiento PII/seguridad (NCBE-4514) — diligencia de evidencia, no equivalencia

- A pedido de Seguridad (Qualys), se debían enmascarar nombres de SP en la evidencia. Gengis
  encontró que la respuesta REST/gRPC ya no mostraba nombres completos, pero la **salida directa
  del SP en la propia ME** sí los mostraba sin enmascarar (25 casos: 20 en `o_msg`, 5 en mensaje
  nativo) — corregido. No es un hallazgo de equivalencia SP↔micro, es higiene de la evidencia que
  QA publica.

### E. Instrumentación propia de QA filtrándose a la evidencia — PR29 reforzado 3 veces más (NCBE-4607, 4608, 4653/TC96)

Ver sección 5, PR29 — esta ronda aporta la instancia más grande encontrada en toda la serie.

### F. Concatenación de PRE/POST sin separador de lote — nuevo patrón (NCBE-4611, 4657, 4664, 4666, y generalizado en 4623)

Ver sección 5, PR32.

### G. Recursos compartidos entre canales / marca de restauración pendiente (NCBE-4623)

Ver sección 5, PR33.

### H. Hallazgos resueltos por re-ejecución con datos frescos, no por cambio de código (NCBE-4667, 4669, 4670, y buena parte de 4657/4663/4666)

Un patrón recurrente: "Sybase da 1, la ME dice 0" en TC39/47/49 y variantes — en los tres casos la
causa real era que el giro/SSN de la captura **ya había sido consumido en una corrida anterior**
("Giro ya cancelado"), no un defecto de código ni de la ME. Reejecutando con un ciclo PRE que
reinicia el giro/SSN propio del canal, los 3 canales coinciden en `RETURN 0`. Mismo mecanismo en
TC17/19/20/22/23/24/25 (NCBE-4657, 4663, 4666): "duplicate key"/"giro ya cancelado"/mensajes de
rechazo que en realidad vienen de ejecutar el caso sobre un giro/SSN ya usado.

### I. Precisión de catálogo de mensajes — varios mensajes posibles para el mismo escenario (NCBE-4653/TC84, 4668/TC97, 4657/TC17, 4666/TC24)

Ver sección 4 (DICCIONARIO) — estos son, en esencia, hallazgos de DICCIONARIO: qué mensaje/campo es
"el" esperado depende de la rama de negocio exacta alcanzada (`i_cobis`, `i_cod_agente`, orden con/
sin SAT, etc.), no de un bug de comparación.

## 3. Hallazgo principal de los bugs del padre

Esta ronda no tiene equivalente previo en la serie: la gran mayoría de los 34 "Defecto" son
hallazgos de equivalencia reales y sustantivos, trabajados con un rigor metodológico alto (cada
corrección se revalida contra Sybase, REST y gRPC con datos frescos antes de cerrarse, y cada duda
de criterio se escala explícitamente a Banco en vez de decidirse unilateralmente). El patrón
dominante NO es "defecto del microservicio" sino "defecto o límite de la propia herramienta/
proceso de captura de la ME" — confirmado una y otra vez.

## 4. DICCIONARIO — catálogo de reglas de comparación aprendidas en esta ronda (énfasis pedido por el usuario)

Esta sección reúne, con ticket y evidencia, las decisiones de **qué significa "equivalente"** para
campos concretos de este SP — el contenido más reusable de toda la ronda.

### 4.1 — `o_msg`: comparar el mensaje funcional después del saneamiento de seguridad, no el texto literal (NCBE-3354, NCBE-4606, NCBE-4514)

- El SP antepone `[nombre_del_procedimiento]` al mensaje en `o_msg`/mensaje nativo. REST y gRPC
  **retiran ese prefijo por requerimiento de Seguridad del Banco** (NCBE-2335, reglas COB-008/
  NCBE-1892/NCBE-1815, originadas en un hallazgo de Qualys). Gengis escaló explícitamente la
  decisión a Banco en vez de asumirla: "¿consideramos equivalente el mensaje funcional después del
  saneamiento, o se solicita una excepción para exigir igualdad literal?" Banco confirmó la primera
  opción por escrito.
- **Regla DICCIONARIO resultante:** comparar `o_msg` por su contenido funcional (sin el prefijo del
  nombre del SP), conservando en la evidencia tanto el valor original del SP como el saneado de
  REST/gRPC. Nunca exigir igualdad literal byte a byte en este campo.

### 4.2 — `o_mensaje1/o_mensaje2/o_mensaje3`: una cadena vacía en Sybase puede leerse como un espacio; tratar espacio y `""` como el mismo vacío (NCBE-3691, NCBE-4583)

- El SP asigna cadena vacía a estos `varchar` OUTPUT; Sybase representa esa asignación como **un
  carácter espacio** (longitud 1) al leerlo, mientras REST/gRPC muestran `""` (longitud 0). Son el
  mismo "vacío" por diseño del SP, no una divergencia real.
- Un bug del lector de la ME agravaba esto: 23 capturas antiguas registraban `NULL` en vez de
  "vacío interpretado" al procesar ese espacio — corregido para distinguir NULL real de vacío
  interpretado, con la medición (longitud 1 vs 0) visible en la evidencia, nunca oculta.
- **Regla DICCIONARIO resultante:** para estos 3 campos, normalizar espacio-de-longitud-1 y
  cadena-vacía como equivalentes; nunca colapsarlos a NULL sin dejar constancia de que es una
  interpretación, no una medición directa de cada captura.

### 4.3 — Valores `money`/decimal: comparar por valor numérico, no por representación textual — criterio transversal heredado de OTRO SP (NCBE-4686, NCBE-4711, NCBE-4667)

- El mismo valor de `result_set.riesgo.w_total_en` (`money` en el SP, `DoubleValue` en el proto) se
  observa como `20.00` en el cliente ISQL, `20.0000` en la herramienta de QA, `20.0` en REST y `20`
  en gRPC. **Ninguna de esas diferencias es real** — son formatos de presentación de distintos
  clientes sobre el mismo valor interno.
- **El criterio no se inventó para este SP: viene de un ticket de OTRO lote** (NCBE-4272, SP
  `cob_internet.pa_cash_cdetalle_cuenta`, Lote 7), donde Pablo Ricaurte (Banco) fijó el 13-oct la
  regla general: *"si el SP debiera devolver 1.00, está bien que el micro devuelva 1; si debiera
  devolver 1.10, está bien 1.1; si debiera devolver 1.15, está bien 1.15"* — comparación por valor
  decimal, no por cantidad de ceros. Gengis la aplicó explícitamente aquí, citando el hilo de
  origen, y la documentó como definición general para "los lotes siguientes".
- **Esto es la evidencia Jira más clara de toda la serie de cómo una regla de DICCIONARIO nace en
  un SP y se convierte en política transversal para todos los SPs posteriores** — vale la pena
  recordar este mecanismo (una decisión de criterio documentada en un ticket se vuelve referencia
  citable, no se repite el debate en cada SP nuevo).

### 4.4 — Qué campo lleva el mensaje depende de un parámetro de negocio (`i_cobis`), no es un mapeo fijo 1:1 (NCBE-4668/TC97, NCBE-4657/TC17, NCBE-4666/TC24)

- Con `i_cobis='S'`, el SP emite su mensaje vía `sp_cerror` y **no asigna `@o_msg`** — el mensaje
  correcto aparece en `mensajeDebug`, no en `o_msg`. Con `i_cobis='N'`, es al revés. Comparar
  "o_msg" sin saber qué valor de `i_cobis` se usó produce un falso defecto.
- De forma similar, con `i_cod_agente` informado (ej. `'BNF'`) el SP toma la ruta de "agente web
  service" y nunca llega a evaluar la validación "PERTENECE A AGENTE PAGADOR SFTP" — esa validación
  solo se alcanza con `i_cod_agente=''`. El DICCIONARIO/MD debe fijar la combinación exacta de
  parámetros que alcanza la rama que el TC pretende probar, no solo el resultado esperado.
- **Regla DICCIONARIO resultante:** el mapeo "campo de salida ↔ fuente del mensaje" depende de la
  rama de negocio ejercida; documentar esa dependencia explícitamente en vez de asumir un mapeo
  fijo por nombre de campo.

### 4.5 — `codigoRetorno` y `oRetornoWs` son dos campos de retorno distintos; una discrepancia entre ellos puede ser dato de prueba viejo, no ambigüedad de DICCIONARIO (NCBE-4624/TC33)

- Inicialmente parecía una inconsistencia de qué campo es "el" retorno. Resuelto reejecutando con
  fixture propio por canal: los 3 canales coinciden en ambos campos (`899005`). La causa real era
  aislamiento de datos insuficiente entre canales, no una ambigüedad de mapeo.

### 4.6 — Catálogo de mensajes con varias ramas posibles para el mismo TC — no asumir cuál es "la" variante sin verificar la ruta exacta (NCBE-4653/TC84, TC87)

- TC84: la observación reportó "No existe registro a eliminar"/"No se anular la orden en el SAT",
  pero esa combinación corresponde a una RAMA DISTINTA (reverso sin orden SAT asociada) de la que
  el caso pretende probar (reverso con orden, mensaje "No se encontraron datos de la orden para el
  reverso"). Ambas ramas son reales y ambas están corregidas en el microservicio 1.0.54; el caso
  documentado reproduce la rama correcta con los datos publicados.
- TC87: el mensaje `31097` "VALOR DEL DEBITO DEBE SER MAYOR A CERO" lo emite el **sensor de
  órdenes** (`sp_cerror`), no es el RETURN del SP (`1`). La ME reporta lo que el SP realmente
  retorna; se escaló a Banco si el MD debía ajustarse al mensaje del sensor en vez de al RETURN.

## 5. Patrones de esta ronda (nuevos y reforzados)

### PR29 reforzado — la instancia más grande de la serie (NCBE-4608: 85 de 105 tarjetas afectadas)

- La herramienta de QA agregaba columnas auxiliares de medición (`datalength(@o_...) AS dl_o_...`)
  al `SELECT` de salida publicado en el comando SP de la ME, para medir longitudes de texto. Esas
  columnas terminaron visibles en el comando que Banco copiaba y ejecutaba — **85 de 105 tarjetas
  afectadas**, la instancia más grande de este patrón en toda la serie. Corregido retirándolas del
  comando publicado, conservando la medición solo en evidencia interna.
- Dos instancias más del mismo patrón en esta misma ronda: una sonda interna `BEGIN TRAN`/
  `ROLLBACK` de verificación filtrada a las precondiciones de 40 casos (NCBE-4607); una columna de
  control `gate_estado` (de un gate `IF (SELECT mutacion_propia FROM #tc96_tracking)`) filtrada al
  resultado del SP de TC96 (NCBE-4653).

### PR32 — Concatenar los PRE/POST de 3 canales en un solo bloque sin separador de lote rompe la compilación por variables redeclaradas (NUEVO)

- **Evidencia:** el campo `precondiciones_sql` del JSON reunía los PRE de SP/REST/gRPC en una sola
  lista; cada PRE individual compila bien, pero al pegarlos y ejecutarlos como un solo lote (sin
  `go` entre bloques), una variable declarada en los 3 (`@e`) queda redeclarada y Sybase aborta con
  `Msg 134`. Afectó decenas de TCs identificados en NCBE-4657, 4664, 4666 y la lista que creció en
  NCBE-4623 (más de 30 casos reportados por el equipo de Testing BB en cadena).
- **Corrección:** cada bloque de `precondiciones_sql`/`postcondiciones_sql` termina ahora en `go`,
  de forma que ejecutarlos juntos no colisiona.
- **Comprobación reusable:** cuando un documento de ME expone PRE/POST de varios canales como texto
  concatenado para copiar-y-pegar, verificar que cada bloque tenga su propio separador de lote
  (`go` en Sybase) — de lo contrario, el usuario que ejecuta "todo de una vez" se encuentra con
  errores de compilación que no reflejan ningún problema real del SP.

### PR33 — Un recurso QA compartido entre canales (caja, parámetro) necesita una marca de restauración rastreable, no solo un ciclo PRE/POST simple (NCBE-4623/TC68,76,85)

- **Evidencia:** la apertura de caja QA era una sola fila compartida por los 3 canales; el POST de
  REST la borraba antes de que gRPC la necesitara (TC68/76). Para un parámetro compartido
  (`426/ROLPAGO/DEBCREMAN`, TC85), un PRE ejecutado sin su POST dejaba una "marca de restauración
  pendiente" que bloqueaba correctamente una segunda modificación — pero el POST no podía limpiar
  esa marca si el valor ya había vuelto solo a su estado original, dejando el caso atascado.
- **Corrección:** cada caso/canal obtiene su propio recurso (fila de caja propia); el mecanismo de
  marca pendiente se corrigió para que el POST pueda retirarla con `YA_RESTAURADO` cuando el valor
  ya coincide con el original, y para que el bloqueo (`Msg 21780`) muestre explícitamente qué
  caso/canal dejó la restauración pendiente y desde cuándo.
- **Comprobación reusable:** cuando un TC modifica un parámetro o recurso compartido entre canales,
  diseñar el ciclo PRE/POST para que (a) cada canal tenga su propio recurso siempre que sea posible,
  y (b) si debe compartirse un parámetro de catálogo, la marca de "modificación pendiente de
  restaurar" sea visible y recuperable, no solo un bloqueo opaco.

## 6. Contraste con la ME final (NCBE-1839)

- **Universo:** 105 TCs, **102 EQUIVALENTE + 3 NO_APLICABLE** (TC54, TC55, TC64) — verificado por
  hash contra el adjunto del 23-oct 13:24 (el último de 20 versiones).
- **TC54/TC55:** figuraban como `EJECUTADO_CON_DIFERENCIA` en una entrega intermedia (19-oct);
  Gengis los reclasificó a `NO_APLICABLE` **"conforme a lo acordado con Banco"** — no por decisión
  unilateral. TC64 ya era NO_APLICABLE desde antes (confirma memoria propia sobre semántica NULL en
  Sybase, TC64/65 de esta misma SP).
- **Evolución documentada de versión a versión** (20 JSON en 25 días): cada entrega lista
  explícitamente qué cambió respecto a la anterior y por qué ticket — un patrón de trazabilidad
  mucho más disciplinado que el visto en rondas previas de la serie (compárese con PR26/ME#8, donde
  las regresiones entre versiones NO se anunciaban).
- Ninguno de los 34 bugs del padre afectó el veredicto agregado final — todos eran de presentación,
  captura, instrumentación filtrada o datos de prueba consumidos, nunca una divergencia funcional
  real no resuelta entre SP y microservicio.

## 7. Lo que no se pudo verificar / queda pendiente

- No se leyeron las ~10 primeras versiones intermedias de la ME (28-sep a 19-oct) en detalle más
  allá de los resúmenes citados en los propios comentarios — dado el volumen (20 versiones, hasta
  4.3 MB cada una), se verificó por hash solo la versión final.
- No se profundizó en el adjunto `RE_ Novedad ticket NCBE-4606.msg` (correo citado como definición
  de criterio monetario) — su contenido ya está resumido con precisión en los comentarios de
  NCBE-4667/4711 por el propio Gengis, con cita del hilo de origen (NCBE-4272, 13-oct).
- No se verificó si las reglas de DICCIONARIO documentadas aquí (sección 4) quedaron escritas en
  algún documento canónico de la serie de patrones (`equivalencia/patrones/...` mencionado en
  `BB_MINERIA_COMPARATIVA_9_ME`) — esa minería es de un repo externo no confirmado como accesible
  desde esta sesión; se deja como posible trabajo futuro si el usuario lo pide.
- `tr_pago_giro_service.proto` (vigente desde el 19-oct) no se inspeccionó en detalle.

## 8. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1777 (campos + 42 subtareas + 6 issuelinks); NCBE-1839
  (campos + 42 adjuntos listados + 25 comentarios completos); los 34 Defecto (campos completos +
  comentarios completos de 32 de ellos; 2 — NCBE-4601/4974 — solo campos, por ser NO-QA evidente).
- **Verificación de hash:** adjunto final de NCBE-1839 (23-oct 13:24, 4299220 bytes) descargado
  temporalmente a `/tmp` (nunca al repo), hash y veredictos verificados (105 TCs, 102 EQUIVALENTE +
  3 NO_APLICABLE). Borrado tras el uso.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #15** de la serie — la más extensa hasta ahora. Ver índice
  `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`. Pendiente: el usuario indicará el siguiente ticket
  padre y su HU (recordar que mencionó enviar 3 MEs juntas; solo llegó esta).

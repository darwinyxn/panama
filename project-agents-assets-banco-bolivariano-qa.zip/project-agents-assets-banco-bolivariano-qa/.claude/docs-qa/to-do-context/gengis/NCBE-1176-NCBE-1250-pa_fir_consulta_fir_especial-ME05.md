# Aprendizaje personal piloto gengis-me — ME #5: pa_fir_consulta_fir_especial (NCBE-1176 → NCBE-1250)

Fecha de esta ronda: 2026-10-30. Quinta entrega de la serie. Mismo alcance y criterio que las
rondas anteriores. No se hicieron consultas a Sybase/REST/gRPC, no se reejecutó nada, no se
modificó Jira/QMetry/motor/repos/ME.

## 1. Identidad y relación de tickets (OBSERVADO en Jira)

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1176 | Story | Padre | Consulta de firmantes especial en base a cuenta |
| NCBE-1247 | Task | Pipeline (relates to) | Análisis de Stored procedure — firmas.pa_fir_consulta_fir_especial |
| NCBE-1248 | Task | Pipeline (relates to) | Consolidación de casos de prueba |
| NCBE-1249 | Task | Pipeline (relates to) | Creación de casos de prueba funcionales y estructurales |
| NCBE-1251 | Task | Pipeline (relates to) | Generación de datos para casos de prueba |
| **NCBE-1250** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — firmas.pa_fir_consulta_fir_especial** |
| NCBE-2860 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance, no tocado |

SP: `firmas.pa_fir_consulta_fir_especial`. Micro: `cpas-mso-fir-consulta-fir-especial`.

**Particularidad de nomenclatura detectada (relevante para la sección 4):** el título de NCBE-1176
("Consulta de firmantes especial en base a cuenta") es **textualmente idéntico** al de NCBE-1174
(ME #3, SP `pa_fir_consulta_con_especial`). Dos Stories hermanas distintas, con SP distinto, mismo
texto exacto de resumen — una colisión de nomenclatura real en Jira, no una coincidencia menor.

**Descripción con plantilla inconsistente (nota menor):** la descripción de NCBE-1176 dice "...quiero
usar IA para generar de forma asistida **la librería**..." (plantilla de Story de Librería), aunque
el padre tiene enlazado el pipeline completo de microservicio (análisis SP, casos de prueba,
generación de datos, revisión de matriz, rendimiento) igual que los demás padres de esta serie. No
se investigó más — es un detalle de plantilla, no cambia el alcance real observado.

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

NCBE-1176 tiene 13 subtareas. 3 son tareas de analisis/consolidacion de casos con títulos no
relacionados a simple vista ("Proceso depósito completo" — NCBE-1237/1245/1246) pero **verificado
por su descripción real**, NCBE-1237 sí habla de "flujo funcional del proceso de **firma
especial**" — son plantillas de título reutilizadas, no tickets fuera de tema; no se profundizó más
(no son "Defecto"). El resto son `Sub-task` de checklist (SonarQube/Veracode/Prisma/Qualys/Pruebas
Unitarias/Código) salvo las 2 de abajo.

### NCBE-4465 — "Novedades en Sonarqube" (Defecto) → **NO ES QA, y además mal atribuido (confirma PR14 de la ME #4 con un segundo caso)**

- El cuerpo de la única respuesta (Kenneth Barrios, 13-oct) dice textualmente: "En
  **cpas-mso-fir-consulta-condicion** el literal 'Solicitud invalida'... se extrajo a una
  constante... commit `20183ef`." **Es el mismo repo, el mismo defecto `java:S1192` y el mismo
  commit `20183ef` ya documentados como NCBE-4363 bajo el padre NCBE-1175 en la ME #4** — no el
  micro de este padre (`cpas-mso-fir-consulta-fir-especial`).
- **Clasificación:** NO-QA (calidad de código), y además es un reporte duplicado archivado bajo el
  padre equivocado — el mismo fix ya está contado en la ME #4. No se vuelve a contar como hallazgo
  nuevo aquí.

### NCBE-4466 — "Novedades en prisma cloud y Unit test" (Sub-task) → **NO ES QA, pero revela un defecto de infraestructura compartida real (NUEVO)**

- **Hallazgo real, cross-repo:** un merge de `develop` a `develop-dvp` (12-oct, ~22:40) en
  `cpas-mso-fir-consulta-condicion` y `cpas-mso-fir-consulta-especial` cambió en
  `.github/workflows/openshift-workflow.yml` la referencia del pipeline compartido de
  `bb-devops-pipelines-center@v2-alpha` a `@main`. Con `@main`, el push a `develop-dvp` solo corría
  el job `initialization` y **omitía silenciosamente** el job `develop` (compile/deploy) — el pod
  de desarrollo dejaba de actualizarse sin ningún error visible.
- **Corrección:** `cpas-mso-fir-consulta-condicion` restaurado a `@v2-alpha` (commit `7ef8f1d`,
  Kenneth Barrios); `cpas-mso-fir-consulta-especial` restaurado por Emily Lino Martinez (el bot de
  Kenneth no tenía permiso de scope `workflow` para tocarlo él mismo).
- **Contenido adicional mezclado en el mismo ticket:** fix de Unit Test en `cpas-mso-fir-consulta-condicion`
  (mismo defecto recurrente `commons-logging` no declarado, visto ya en varias rondas anteriores) y
  bump de `jackson-bom` 3.1.4→3.1.7 en `cpas-mso-fir-consulta-fir-especial` (este SÍ es el micro de
  este padre) por CVEs de Prisma.
- **Por qué NO es QA:** es infraestructura de CI/CD (referencia de pipeline compartido) y
  dependencias — no toca comportamiento SP↔microservicio. Pero es un hallazgo real y nuevo de esta
  ronda: ver PR17 (defecto de plantilla de CI/CD compartida entre varios micros de la familia
  `firmas`, análogo a PR08 pero a nivel de infraestructura, no de código).

## 3. Hallazgo principal de esta ronda (bugs del padre)

Cero bugs de equivalencia funcional SP↔microservicio enlazados al padre. De los 2 "hallazgos" con
contenido real, uno es un reporte duplicado mal archivado (confirma PR14 con un segundo caso) y el
otro es un defecto de infraestructura de CI/CD compartida, nuevo para esta serie (PR17).

## 4. Contraste con la ME final (NCBE-1250) — hallazgo importante: un adjunto de OTRO SP completo

- **NCBE-1250 tiene 2 archivos JSON adjuntos, y uno de ellos NO es de este SP en absoluto —
  verificado por hash, no solo por tamaño:**
  - `QA-CASOS-PARSEADOS.json` (220155, subido 11-ago 15:15:21) — **117516 bytes, SHA-256
    `a6a9f60b7f5ccc62538e865fb93f2420e37c63243ad2110504ac4c3573ab342f`.** Es **byte-idéntico** al
    archivo de la ME #1 (M7, `pa_fir_consulta_firmante`, HU NCBE-1117) — confirmado con
    `metadata.sp_objetivo: "pa_fir_consulta_firmante"` dentro del propio archivo. **Es el archivo
    equivocado, de otro SP distinto, adjuntado a esta HU por error.**
  - `QA-CASOS-PARSEADOS (5530cb8b-...).json` (220165, subido 5 minutos después, 15:20:28) — 2393131
    bytes, SHA-256 `890ea4f7...`, `metadata.sp_objetivo: "pa_fir_consulta_fir_especial"` — **este sí
    es el archivo correcto** de este SP, y es el que el comentario de Nicolas Rodríguez Mejía cita
    explícitamente por nombre ("Adjunto JSON para la matriz de equivalencia para esta
    funcionalidad").
  - **Causa probable del error (reconstrucción razonada, no confirmada por el autor):** 5 minutos
    antes de subir el archivo equivocado, el propio Nicolas comentó en este mismo ticket "esta
    funcionalidad ya dio 15/15... corrigiendo un tema visual similar al de firmantes 'normal'" — 15
    es exactamente el número de TCs de M7 (`pa_fir_consulta_firmante`, "firmantes normal"). Es
    razonable que estuviera trabajando ambos SPs en paralelo y haya adjuntado el archivo de la
    ventana/carpeta equivocada. Esto se ve favorecido por la **colisión de título** de la sección 1
    (NCBE-1174 y NCBE-1176 comparten el mismo texto de resumen) — un entorno fácil para confundir
    cuál ticket corresponde a cuál SP. Nadie comentó ni corrigió el adjunto equivocado después (sigue
    ahí); no bloqueó nada porque el comentario y el flujo de revisión posterior usaron el archivo
    correcto.
  - Ver PR16 — es el hallazgo más importante de esta ronda.
- **Universo real (del archivo correcto, verificado):** 12 TCs, 3 grupos, **12/12 EQUIVALENTE**,
  **1 STATELESS / 11 STATEFUL** — perfil de mutación mucho más alto que sus SPs hermanos de la
  familia "firmantes" (M7 era 15 STATELESS/0 STATEFUL); consistente con que la mayoría de TCs
  preparan fixture (PRE mutante) para alcanzar el escenario de consulta, no con que el SP en sí
  escriba — no se verificó el detalle PRE/SP/POST de cada TC en esta ronda (fuera de alcance,
  requeriría leer el SQL real).
- **Mismo patrón binario de M7, confirmado en un segundo SP:** el resultset 2 de este SP también
  es `(Identificacion, Nombre, Firma)`, con `Firma` en **HEX** en el SP y **Base64** en REST/gRPC —
  estructuralmente idéntico al patrón de M7/NCBE-1117 que ya tiene la capacidad `binary-comparison`
  piloteada en PASS (ver ME #1). Es un segundo candidato real, no solo teórico, para extender ese
  piloto — no se ejecutó nada aquí, solo se deja registrada la coincidencia de forma.
- Ninguno de los 2 hallazgos del padre (sección 2) deja ni debía dejar rastro en la ME.

## 5. Patrones agrupados por causa o comprobación reusable (nuevos de esta ronda)

### PR16 — Un adjunto de una HU de revisión puede ser de un SP COMPLETAMENTE DISTINTO, no solo una versión vieja del mismo SP (NUEVO)

- **Evidencia:** el primer JSON adjunto a NCBE-1250 es byte-idéntico al de M7/NCBE-1117
  (`pa_fir_consulta_firmante`), un SP diferente — confirmado por `metadata.sp_objetivo` y hash.
- **Comprobación reusable:** cuando una HU de revisión tiene más de un archivo `QA-CASOS-PARSEADOS*.json`,
  no asumir que todos son versiones del mismo SP — abrir `metadata.sp_objetivo` de **cada uno**
  antes de tratarlo como evidencia de la ME en revisión. Es más probable que ocurra cuando existen
  Stories hermanas con **título idéntico o casi idéntico** (ver sección 1) — ese es justamente el
  contexto donde un reviewer/QA puede confundir de cuál ticket se trata.

### PR17 — Un cambio de referencia de pipeline CI/CD compartido puede romper el deploy de varios micros hermanos a la vez, sin error visible (NUEVO, extiende PR08 a infraestructura)

- **Evidencia:** merge `develop`→`develop-dvp` cambió `@v2-alpha` a `@main` en el workflow de
  GitHub Actions de 2 micros de la familia `firmas` simultáneamente; el pipeline seguía "pasando"
  (corría `initialization`) pero omitía silenciosamente compile/deploy.
- **Comprobación reusable:** igual que PR08 (plantilla de código compartida entre `cpas-mso-*`),
  ahora confirmado también a nivel de plantilla de **infraestructura/CI-CD** — si un micro de esta
  familia reporta "no se refleja el cambio en el pod" sin error de compilación visible, vale la pena
  preguntar por la referencia de versión del workflow compartido antes de asumir un problema de
  código.
- **Confirma PR14 con un segundo caso concreto:** NCBE-4465 (archivado bajo NCBE-1176) es,
  literalmente, el mismo commit (`20183ef`) y el mismo hallazgo que NCBE-4363 (archivado bajo
  NCBE-1175, ME #4) — mismo fix, dos padres distintos. Refuerza la regla de PR14: verificar siempre
  qué repo/micro menciona el contenido antes de contarlo como evidencia del padre donde está
  archivado.

## 6. Lo que no se pudo verificar / queda pendiente

- No se confirmó con el autor (Nicolas Rodríguez Mejía) la causa exacta del adjunto equivocado de la
  sección 4/PR16 — es una reconstrucción razonada a partir de la cercanía temporal de su propio
  comentario sobre "firmantes normal", no una confirmación directa.
- No se verificó el detalle PRE/SP/POST de los 11 TCs `STATEFUL` para confirmar si la mutación es
  solo de fixture de entrada o si el SP mismo escribe — requeriría leer el `.sql` real, fuera de
  alcance de esta ronda (solo Jira + adjuntos de la ME).
- No se revisó el contenido completo de NCBE-1237/1245/1246 más allá de confirmar que su
  descripción corresponde al SP correcto pese al título reutilizado — no son "Defecto", no se
  profundizó más.
- `report_sp_structure_templateV2.html` y el `.proto` (adjuntos a NCBE-1250) no se inspeccionaron en
  detalle.

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1176 (campos + 13 subtareas + 6 issuelinks "relates to");
  NCBE-1250 (campos + 4 adjuntos + 4 comentarios); NCBE-4465/4466 (campos + comentarios);
  NCBE-1237/1245/1246 (campos, solo para confirmar que su contenido correspondía al SP).
- **Verificación de hash:** ambos JSON de NCBE-1250 descargados temporalmente a `/tmp` (nunca al
  repo), hash y `metadata.sp_objetivo` verificados — uno resultó ser de otro SP (M7, confirmado
  idéntico byte a byte a la ME #1), el otro es el correcto de `pa_fir_consulta_fir_especial`
  (SHA-256 `890ea4f723b96f19c4db4c202679ed4ef6333a11ddccd608b74cad32db827377`). Ambos borrados tras
  el uso.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #5** de la serie. Ver índice `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`. Pendiente:
  el usuario indicará el siguiente ticket padre y su HU.

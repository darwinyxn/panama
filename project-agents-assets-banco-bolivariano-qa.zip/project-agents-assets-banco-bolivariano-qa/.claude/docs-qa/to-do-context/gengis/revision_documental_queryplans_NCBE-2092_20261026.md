# Revisión documental independiente (no oficial) — Query Plan NCBE-2092, Lote 8

**Alcance:** exclusivamente los 8 ZIP y el manifiesto consolidado recibidos el 26/10/2026. No incluye acceso a SYBASE02, repositorios, tooling canónico, ni ejecuciones en vivo. **Claude debe corroborar** toda sospecha, inferencia y aplicabilidad de los criterios antes de cualquier cambio o comunicación externa.

## Resultado de verificaciones estáticas
- 8/8 ZIP legibles y con prueba interna `ZipFile.testzip` sin errores.
- 8/8 SHA-256 del ZIP coinciden exactamente con `zip_sha256` del manifiesto consolidado.
- 8/8 conteos individuales coinciden con el consolidado: QP, observaciones, DML protegido, errores SQL, HU.
- 48/48 QP tienen `plan.present=true`, `exit_code=0`, `error_sql=null` y SHA-256 correcto de `sql.ejecutado.texto` respecto de `text_sha256`. Esto comprueba consistencia **interna del artefacto**, no la ejecución independiente sobre la BD.
- El consolidado declara `delivery_ready=true`, 8 paquetes, 48 QP, 4 observaciones, 5 ejecuciones con `noexec`, 0 errores SQL. Sin reemplazar el veredicto canónico `BANK_READY (PASS_CON_OBSERVACIONES)` informado por Claude.
- 34 entradas de hijos, 37 call sites y 26 procedimientos hijos únicos declarados. Sus 34 entradas figuran `ejecutado=false` por BARRERA_3; es una cobertura de inventario, no ejecución de hijos.

## Tabla de paquetes
| HU | SP | QP | Observaciones | SQL NOEXEC | Estado declarado | SHA ZIP |
|---|---|---:|---:|---:|---|---|
| NCBE-2094 | `pa_pg_tpag_reca_varios` | 14 | 1 | 0 | PASS_CON_OBSERVACIONES | `a5cd401c5bfeba34…` |
| NCBE-2095 | `pa_pg_cpag_notificacion` | 7 | 0 | 0 | PASS | `b38d1a2a7d61500f…` |
| NCBE-2096 | `pa_pg_tpag_deb_cre` | 1 | 0 | 0 | PASS | `86d0fe03039032e3…` |
| NCBE-2097 | `pa_pg_tpag_comision` | 5 | 1 | 0 | PASS_CON_OBSERVACIONES | `39b37b289d4e6709…` |
| NCBE-2098 | `pa_pg_ivalor_comcal` | 3 | 1 | 0 | PASS_CON_OBSERVACIONES | `e0104dbd85d22a3e…` |
| NCBE-2099 | `sp_cobro_comision_rc` | 3 | 0 | 2 | PASS | `a2ab7283ba5b06c2…` |
| NCBE-2101 | `pa_cc_ifactura_cnb` | 4 | 1 | 0 | PASS_CON_OBSERVACIONES | `2fe3104daccd392c…` |
| NCBE-2102 | `sp_factura_recaudacion` | 11 | 0 | 3 | PASS | `070801af6e1496e7…` |

## Observaciones registradas en los paquetes
Las cuatro observaciones son `A_TABLE_SCAN`; ninguno de los QP observados excede umbrales lógicos/físicos por los totales capturados. Un `Table Scan` sobre una tabla pequeña no demuestra por sí solo un problema de rendimiento.

| HU | QP | Tabla | Lecturas lógicas capturadas | Físicas |
|---|---|---|---:|---:|
| NCBE-2101 | QP-01 | `cobis..ba_fecha_proceso` | 1 | 0 |
| NCBE-2098 | QP-03 | `cob_pagos..pg_p_rubro_ser_dam` | 1 | 0 |
| NCBE-2097 | QP-05 | `cob_pagos..pg_p_rubro_ser_dam` | 1 | 0 |
| NCBE-2094 | QP-09 | `cobis..ba_fecha_proceso` | 1 | 0 |

## Precisión de terminología sobre NOEXEC
Son **5 ejecuciones protegidas**, de las que **3 tienen tipo `INSERT`/`UPDATE`** y **2 son `BATCH` que invocan `cobis..sp_cerror`**. Todos llevan `ejecucion.noexec.aplica=true` y `protegido=true`. En los 2 ZIP que contienen esas cinco ejecuciones se muestran instrucciones `set noexec on/off` en `detalle_ejecucion.qp`. La ejecución y ausencia de efectos reales en SYBASE02 solo la corrobora Claude.
- NCBE-2099 — `sp_cobro_comision_rc` QP-01: `BATCH`
- NCBE-2099 — `sp_cobro_comision_rc` QP-02: `INSERT`
- NCBE-2102 — `sp_factura_recaudacion` QP-01: `BATCH`
- NCBE-2102 — `sp_factura_recaudacion` QP-04: `INSERT`
- NCBE-2102 — `sp_factura_recaudacion` QP-06: `UPDATE`

## Señales que ameritan revisión por Claude (sin calificación de defecto)

### S1. Fuente REF 20 y baseline de repositorios
Los manifiestos individuales apuntan a `origen.sp_fuente = lote-08/sybase-local/_bosque/sps/<sp>.sql`, sin declarar explícitamente REF 20 ni un hash/commit del SP Legacy. En NCBE-2094 el path del SP no acredita por sí mismo cuál revisión contiene. También se observaron fuentes Java en carpetas locales con sufijos de branches (`bb-core-cob-remesas-utils-ncbe4662`, `bb-core-cob-cuentas-utils-develop-dvp-ncbe1169`). **Claude debe comparar el contenido y SHA reales** de los archivos fuente con REF 20, con las versiones correspondientes de Java y, cuando aplique, con lo desplegado. Que el motor de SYBASE02 haya generado un plan no demuestra automáticamente que el SQL de origen de la librería coincida con REF 20.

### S2. Correspondencia Legacy incompleta en QP concretos
En 10/48 QP `sql.legacy=null`; dentro de ellos, 5 declaran explícitamente `LEGACY_EXTRACTION_FAILED` por ambigüedad o ausencia de coincidencia con candidatos Legacy. El paquete puede ser válido según el pipeline, pero **no equivale a haber reconciliado cada SQL contra Legacy**. Claude debe clasificar y buscar fuentes válidas, sin inventar emparejamientos ni alterar el pipeline.

| HU | SP | QP | Causa declarada (resumida) |
|---|---|---|---|
| NCBE-2098 | `pa_pg_ivalor_comcal` | QP-03 | el literal resuelto de evidencia ['555', 'CNB'] no aparece en ninguno de los 2 candidatos legacy estructuralmente compatibles -- la evidencia contradice la estructura, no se elige ninguno |
| NCBE-2097 | `pa_pg_tpag_comision` | QP-02 | el literal resuelto de evidencia ['9999', 'causa_nd_comision_servaho'] no aparece en ninguno de los 2 candidatos legacy estructuralmente compatibles -- la evidencia contradice la estructura, no se elige ninguno |
| NCBE-2097 | `pa_pg_tpag_comision` | QP-03 | el literal resuelto de evidencia ['3497', '9999', 'causa_nd_comision_servaho'] aparece en 5 candidatos legacy distintos -- la evidencia narrows pero no decide por si sola |
| NCBE-2094 | `pa_pg_tpag_reca_varios` | QP-04 | el literal resuelto de evidencia ['1', 'sv_horario_serv'] aparece en 5 candidatos legacy distintos -- la evidencia narrows pero no decide por si sola |
| NCBE-2102 | `sp_factura_recaudacion` | QP-02 | el literal resuelto de evidencia ['CTE', 'IVA'] aparece en 2 candidatos legacy distintos -- la evidencia narrows pero no decide por si sola |

Los otros `sql.legacy=null` están en: `pa_pg_tpag_deb_cre:QP-01`, `pa_pg_tpag_reca_varios:QP-03`, `pa_pg_tpag_reca_varios:QP-14`, `sp_cobro_comision_rc:QP-01`, `sp_factura_recaudacion:QP-01`. No se presupone que sean faltas.

### S3. Metadatos de tiempo, motor y microservicio
- Los 48 QP declaran `ejecucion.timing.timing_status=NOT_CAPTURED`; cada paquete tiene `fechas.run_completed_at_utc=null`. La fecha `ejecucion_sybase` es la misma para todos y se identifica como `fuente=parametro_corrida`. Preguntar si esto está previsto en el esquema canónico.
- `sybase.ase_version` y `sybase.ase_ebf` están `null` en los ocho paquetes. Preguntar si son opcionales o requeridos como trazabilidad de entorno.
- El campo `microservicio` de los manifiestos identifica cada módulo `*-utils` y no `rec-mso-pago-reverso-core`, mientras `hu_cono=NCBE-2092`. Verificar la semántica contractual del campo antes de proponer modificaciones.
- En todos los QP, `plan.tipo_query_motor=null`, incluso cuando `plan.present=true`. Consultar si ese campo se omite legítimamente para esta clase de SQL/driver.

### S4. Evidencia y verificabilidad externa
- Los tres ficheros de cada ZIP existen y no están corruptos; el consolidado valida los 8 SHA. No se incluyeron los registros brutos de sesión SYBASE02 ni el código fuente completo. Por ello, esta revisión no acredita por sí sola el histórico del servidor, la exactitud de los hashes `stdout_sha256` respecto al transporte original ni la ausencia de side effects de ejecución.
- La marca de carpeta `2026-07-09-statistics-io` es el criterio del Banco reportado en el manifiesto, no la fecha de la ejecución que declara `2026-10-26T18:05:03Z`.

## Inventario de los 48 QP según manifiesto

### NCBE-2094 — cob_pagos..pa_pg_tpag_reca_varios
| QP | Tipo | Plan presente | IO | Obs | NOEXEC | Legacy SQL | Template micro |
|---|---|---|---|---|---|---|---|
| QP-01 | SELECT | Sí | 6/0 | — | No | Presente | Presente |
| QP-02 | SELECT | Sí | 6/0 | — | No | Presente | Presente |
| QP-03 | SELECT | Sí | 6/0 | — | No | NULL | Presente |
| QP-04 | SELECT | Sí | 6/0 | — | No | NULL | Presente |
| QP-05 | SELECT | Sí | 3/0 | — | No | Presente | Presente |
| QP-06 | SELECT | Sí | 3/0 | — | No | Presente | Presente |
| QP-07 | SELECT | Sí | 2/0 | — | No | Presente | Presente |
| QP-08 | SELECT | Sí | 3/0 | — | No | Presente | NULL |
| QP-09 | SELECT | Sí | 1/0 | A_TABLE_SCAN | No | Presente | NULL |
| QP-10 | SELECT | Sí | 2/0 | — | No | Presente | Presente |
| QP-11 | SELECT | Sí | 3/0 | — | No | Presente | Presente |
| QP-12 | SELECT | Sí | 3/0 | — | No | Presente | Presente |
| QP-13 | SELECT | Sí | 3/0 | — | No | Presente | Presente |
| QP-14 | SELECT | Sí | NO_TABLE_IO | — | No | NULL | NULL |

### NCBE-2095 — cob_pagos..pa_pg_cpag_notificacion
| QP | Tipo | Plan presente | IO | Obs | NOEXEC | Legacy SQL | Template micro |
|---|---|---|---|---|---|---|---|
| QP-01 | SELECT | Sí | 6/0 | — | No | Presente | Presente |
| QP-02 | SELECT | Sí | 6/0 | — | No | Presente | Presente |
| QP-03 | SELECT | Sí | 6/0 | — | No | Presente | Presente |
| QP-04 | SELECT | Sí | 6/0 | — | No | Presente | Presente |
| QP-05 | SELECT | Sí | 3/0 | — | No | Presente | Presente |
| QP-06 | SELECT | Sí | 3/0 | — | No | Presente | Presente |
| QP-07 | SELECT | Sí | 3/0 | — | No | Presente | Presente |

### NCBE-2096 — cob_pagos..pa_pg_tpag_deb_cre
| QP | Tipo | Plan presente | IO | Obs | NOEXEC | Legacy SQL | Template micro |
|---|---|---|---|---|---|---|---|
| QP-01 | SELECT | Sí | 6/0 | — | No | NULL | Presente |

### NCBE-2097 — cob_pagos..pa_pg_tpag_comision
| QP | Tipo | Plan presente | IO | Obs | NOEXEC | Legacy SQL | Template micro |
|---|---|---|---|---|---|---|---|
| QP-01 | SELECT | Sí | 6/0 | — | No | Presente | Presente |
| QP-02 | SELECT | Sí | 6/0 | — | No | NULL | Presente |
| QP-03 | SELECT | Sí | 6/0 | — | No | NULL | Presente |
| QP-04 | SELECT | Sí | 3/0 | — | No | Presente | Presente |
| QP-05 | SELECT | Sí | 1/0 | A_TABLE_SCAN | No | Presente | Presente |

### NCBE-2098 — cob_pagos..pa_pg_ivalor_comcal
| QP | Tipo | Plan presente | IO | Obs | NOEXEC | Legacy SQL | Template micro |
|---|---|---|---|---|---|---|---|
| QP-01 | SELECT | Sí | 6/0 | — | No | Presente | Presente |
| QP-02 | SELECT | Sí | 2/0 | — | No | Presente | Presente |
| QP-03 | SELECT | Sí | 1/0 | A_TABLE_SCAN | No | NULL | Presente |

### NCBE-2099 — cob_remesas..sp_cobro_comision_rc
| QP | Tipo | Plan presente | IO | Obs | NOEXEC | Legacy SQL | Template micro |
|---|---|---|---|---|---|---|---|
| QP-01 | BATCH | Sí | NOEXEC | — | Sí | NULL | Presente |
| QP-02 | INSERT | Sí | NOEXEC | — | Sí | Presente | Presente |
| QP-03 | SELECT | Sí | 3/0 | — | No | Presente | Presente |

### NCBE-2101 — cob_cuentas..pa_cc_ifactura_cnb
| QP | Tipo | Plan presente | IO | Obs | NOEXEC | Legacy SQL | Template micro |
|---|---|---|---|---|---|---|---|
| QP-01 | SELECT | Sí | 1/0 | A_TABLE_SCAN | No | Presente | NULL |
| QP-02 | SELECT | Sí | 2/0 | — | No | Presente | Presente |
| QP-03 | SELECT | Sí | 2/0 | — | No | Presente | Presente |
| QP-04 | SELECT | Sí | 2/0 | — | No | Presente | Presente |

### NCBE-2102 — cob_cuentas..sp_factura_recaudacion
| QP | Tipo | Plan presente | IO | Obs | NOEXEC | Legacy SQL | Template micro |
|---|---|---|---|---|---|---|---|
| QP-01 | BATCH | Sí | NOEXEC | — | Sí | NULL | Presente |
| QP-02 | SELECT | Sí | 2/0 | — | No | NULL | Presente |
| QP-03 | SELECT | Sí | 2/0 | — | No | Presente | Presente |
| QP-04 | INSERT | Sí | NOEXEC | — | Sí | Presente | Presente |
| QP-05 | SELECT | Sí | 4/0 | — | No | Presente | Presente |
| QP-06 | UPDATE | Sí | NOEXEC | — | Sí | Presente | Presente |
| QP-07 | SELECT | Sí | 6/0 | — | No | Presente | Presente |
| QP-08 | SELECT | Sí | 2/0 | — | No | Presente | Presente |
| QP-09 | SELECT | Sí | 2/0 | — | No | Presente | Presente |
| QP-10 | SELECT | Sí | 3/0 | — | No | Presente | Presente |
| QP-11 | SELECT | Sí | 2/0 | — | No | Presente | Presente |

## Propuesta de verificación para Claude
1. Comparar SHA/contenido de fuentes `sp_fuente` contra REF 13/REF 20, el snapshot SYBASE02 y la versión Java efectivamente usada; documentar la cadena de procedencia.
2. Resolver o justificar de forma trazable los cinco `LEGACY_EXTRACTION_FAILED`, clasificando los 10 `sql.legacy=null` sin matches inventados. Evaluar impacto contractual antes de tocar una entrega BANK_READY.
3. Reconfirmar que 5 protegidos = 2 BATCH + 2 INSERT + 1 UPDATE, y verificar el guard de noexec con evidencia canónica, sin ejecutar DML real.
4. Confirmar si `run_completed_at_utc=null`, `NOT_CAPTURED`, `ase_version=null`, `plan.tipo_query_motor=null` y denominación del campo `microservicio` son convenciones del tooling o inconsistencias a corregir.
5. Valorar las cuatro alertas `A_TABLE_SCAN` conforme a criterios A/B/C, sin inferir degradación productiva por 1 lectura lógica y 0 físicas.
6. Si detecta un defecto reproducible, separar diagnóstico y decisión de regenerar/commitear: no modificar automáticamente entregas BANK_READY, QMetry, ME o Jira.

**Advertencia:** este informe describe señales a corroborar, **no** invalida el resultado `BANK_READY` ni sustituye los controles del pipeline, la evidencia de Claude o la aprobación de Banco.

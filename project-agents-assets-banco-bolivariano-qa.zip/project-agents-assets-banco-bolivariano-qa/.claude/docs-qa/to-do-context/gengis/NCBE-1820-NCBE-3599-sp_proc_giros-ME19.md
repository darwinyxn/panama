# Aprendizaje personal piloto gengis-me — ME #19: sp_proc_giros (NCBE-1820 → NCBE-3599)

Fecha de esta ronda: 2026-11-01. Decimonovena entrega (2 de 3 de este turno). No se hicieron
consultas a Sybase/REST/gRPC, no se reejecutó nada, no se modificó Jira/QMetry/motor/repos/ME.

**Nota de procedencia (mismo patrón ya visto en ME #17):** NCBE-3599 no es la tarea formal de
revisión enlazada al padre (esa es **NCBE-1875**) — es un Sub-task de NCBE-1875 ("Generación de
matriz de equivalencia NYXN"). Ambos tickets tienen el mismo JSON (1987585 bytes, 14 y 15-oct
respectivamente) — son copias idénticas, no una desactualizada frente a la otra. El usuario señaló
correctamente el ticket con el adjunto.

**Hallazgo importante de esta ronda, verificado por fecha:** varios de los Defecto del padre
(NCBE-4635, 4723, 4724, 4726, 4731, 4748, 4877) se crearon y resolvieron **entre el 20 y el 29 de
octubre — después del 14/15-oct**, que es la fecha del único JSON que existe tanto en NCBE-1875
como en NCBE-3599. **No existe ningún adjunto posterior a esas fechas en ninguno de los dos
tickets.** Es decir: la ME formalmente "vigente" (44/44 EQUIVALENTE) es anterior a varios defectos
reales confirmados y corregidos después, incluyendo uno serio de atomicidad transaccional
(NCBE-4731). Ver sección 4.

## 1. Identidad y relación de tickets

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1820 | Story | Padre | Procesar operaciones de giros asegurando la correcta ejecución del flujo transaccional |
| NCBE-1866/1872/1873/1874 | Task | Pipeline (relates to) | Análisis/Creación/Consolidación/Generación de datos |
| NCBE-1875 | Task | Pipeline (relates to) | Revisión de matriz de equivalencia (tarea formal) |
| **NCBE-3599** | Sub-task de NCBE-1875 | **HU de esta ronda** | **Generación de matriz de equivalencia NYXN — cob_giros.sp_proc_giros** |
| NCBE-2874 | Task | Pipeline (relates to) | Pruebas de rendimiento — en estado "Construcción", fuera de alcance |

SP: `cob_giros.sp_proc_giros`. Micro: `ecu-mso-proc-giros`. 44 TCs en el único JSON existente:
**44/44 EQUIVALENTE** (14-oct — ver nota de procedencia arriba sobre su vigencia parcial).

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

11 `Defecto`. A diferencia de ME #18, aquí la mayoría SÍ son defectos reales de código, no de
metodología de prueba.

### Ambiente/datos compartidos, NO defectos (NCBE-4495/4496, NCBE-4748)

- **NCBE-4495/4496 (TC37-40):** 2 causas de ambiente distintas, ninguna de código: (a) clave
  duplicada en `cg_giro` por datos ya existentes del ambiente compartido; (b) un `TC37` falló por
  un **bloqueo real en SYBASE02**: una sesión ISQL/w de un tester quedó con una transacción abierta
  sin `COMMIT`/`ROLLBACK`, bloqueando `cg_giro`/`cg_pago`/etc.; el micro esperó el lock, agotó su
  timeout de 5s y devolvió 500. Resuelto pidiendo cerrar esa sesión. Un `TC39` adicional se bloqueó
  porque el **motor de riesgo del propio SP** acumula el monto de giros por courier
  (`gr_ingresados`) y un courier de pruebas (108) quedó con margen negativo tras 73 giros de otro
  equipo QA en 4 días — comportamiento esperado del SP, no un bug.
- **NCBE-4748:** el identificador (`identity`) de `cob_giros..cg_s_cg_giro` en el ambiente de QA
  estaba DETRÁS de los códigos de giro ya existentes (`2260088110`), generando colisión de clave en
  cada INSERT — sugerido ajuste de DBA (subir la identidad por encima del máximo existente), no
  defecto de código ("el SP original fallaría igual en ese ambiente").

### NCBE-4497 — enmascaramiento 50% → **NO ES QA (confirma familia ya vista 4 veces)**

### NCBE-4635 — real, 2 defectos distintos confirmados y corregidos

- Un error de negocio de `sp_inserta_persona` (101172) se devolvía como error interno genérico en
  vez de error funcional — corregido. Además se ajustó la validación del pool de conexiones para
  que no entregue conexiones ya cerradas por la base de datos.

### NCBE-4723 — real, confirmado y corregido

- `mensajeDebug` no incluía el mensaje del SP HIJO antes del de `sp_proc_giros`, en el mismo orden
  que Sybase — corregido para concatenar ambos mensajes con `" | "` en el orden correcto,
  conservando el enmascaramiento del nombre del SP.

### NCBE-4724 — investigado a fondo, NO era un defecto

- El reportante comparó 2 ejecuciones con **parámetros distintos** (una sin `@i_servicio` en
  Sybase, otra sin `i_rem_nombre1/2` por el micro) — cada una cae en una rama de negocio distinta
  del SP (falla de inserción vs. envío a `cg_giros_swiftnok` por remitente incompleto). Confirmado
  con el payload completo que el micro replica exactamente la misma lógica.

### NCBE-4726 — real, confirmado y corregido

- `oIndAnula` se devolvía `null` en vez del valor `"N"` que el SP ya asigna antes de la
  verificación automática — corregido.

### NCBE-4731 — real, el hallazgo más serio de esta ronda: defecto transaccional sistémico

- **Causa:** `pa_ecu_tmatch_spi` se ejecutaba en una **conexión separada**, fuera de la transacción
  que `sp_proc_giros` abre al grabar el pago — esa conexión quedaba esperando el propio bloqueo del
  registro, se cortaba por timeout, y grababa un motivo de error genérico en vez del real.
- **Diligencia adicional pedida por QA, que destapó más instancias del mismo defecto:** Karla Pazan
  Mera pidió explícitamente verificar que **toda** la transacción de `sp_proc_giros` fuera atómica.
  Al auditar, se encontraron **4 llamadas más** (`sp_valida_telefono`, `sp_con_parametroconf`,
  `sp_cerror`, `sp_valida_motivo_nc`) también ejecutándose en conexiones separadas — corregidas
  todas para usar la misma conexión/transacción que el SP, con una prueba automatizada nueva que
  verifica que todo el flujo usa una sola conexión.
- **Lección reusable:** una pregunta de diligencia general ("¿todo lo demás también es atómico?")
  destapó 4 instancias adicionales del mismo defecto arquitectónico que el reporte original solo
  había detectado en 1 punto.

### NCBE-4877 — real, confirmado y corregido, con buena disciplina de despliegue

- La librería componía el código de giro con prefijo `'2'`, mientras el SP vigente en Sybase usa
  prefijo `'7'` (tras un cambio de esquema, "REF 57") — colisión de clave, giro desviado a
  `cg_giros_swiftnok`. Corregido para usar el prefijo correcto.
- **Nota de proceso:** el equipo de desarrollo desplegó primero en `bb-dev-core` y **pidió
  confirmación explícita antes de desplegar en `bb-qa-core`**, para no afectar pruebas en curso de
  Banco — buena práctica de coordinación de entornos compartidos, ya vista en otras rondas.

## 3. Hallazgo principal de los bugs del padre

A diferencia de rondas anteriores con mucho ruido de ambiente/metodología, aquí **7 de 11 Defecto
son defectos reales de código confirmados y corregidos**, incluyendo uno sistémico de atomicidad
transaccional (NCBE-4731) descubierto en 5 puntos distintos del flujo gracias a una pregunta de
diligencia adicional, no solo al reporte original.

## 4. Contraste con la ME final (NCBE-3599) — la vigencia es parcial

- **Universo del único JSON existente:** 44 TCs, **44/44 EQUIVALENTE**, generado 14-oct.
- **Los defectos NCBE-4635, 4723, 4724, 4726, 4731, 4748 y 4877 se crearon y cerraron entre el
  20-oct y el 29-oct — después de la fecha del único JSON que existe.** No hay ningún adjunto
  posterior en NCBE-1875 ni en NCBE-3599 que incorpore esas correcciones. El "44/44 EQUIVALENTE"
  formal de esta HU certifica un estado **anterior** a varios defectos reales ya corregidos en
  código, incluyendo el de atomicidad transaccional de 5 puntos (NCBE-4731) — uno de los hallazgos
  más serios de todo el conjunto de MEs #16-#19.
- **Comprobación reusable (extiende PR23, ME #7):** antes de citar el veredicto de una ME como
  vigente, comparar su fecha de generación contra las fechas de creación/resolución de los bugs del
  padre — un veredicto "N/N EQUIVALENTE" puede certificar un estado de código que ya no es el
  actual, sin que exista ningún artefacto posterior que lo refleje (a diferencia de ME #7, donde al
  menos el gap estaba implícito; aquí es concreto y verificable: 7 defectos post-fecha, 0 adjuntos
  post-fecha).

## 5. Patrones de esta ronda

- **Confirma y agrava PR23** (ME #7: N/N EQUIVALENTE no garantiza ausencia de defectos posteriores)
  con el caso más concreto de la serie: 7 defectos reales posteriores, 0 artefactos de ME
  posteriores en ningún ticket relacionado.
- **Lección reusable nueva (sin ascender a patrón propio):** una pregunta de diligencia general
  sobre un defecto puntual ("¿el resto del flujo tiene el mismo problema?") puede destapar más
  instancias del mismo defecto arquitectónico de las que el reporte original detectó — vale la
  pena hacerla explícitamente al cerrar un defecto de clase arquitectónica (ej. atomicidad,
  aislamiento, conexión compartida), no solo conformarse con el punto reportado.

## 6. Lo que no se pudo verificar / queda pendiente

- No se confirma si existe, fuera de Jira, una ME más reciente que incorpore los 7 defectos de
  octubre tardío — no se encontró ningún adjunto posterior en los tickets consultados.
- No se profundizó en los adjuntos `.proto`/`qa_casos_prueba.md` más allá de lo citado.

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1820 (campos + 18 subtareas + 7 issuelinks); NCBE-1875 y
  NCBE-3599 (campos + adjuntos completos, para confirmar la vigencia parcial); los 11 Defecto
  (campos + comentarios completos).
- **Verificación:** único JSON existente (14-oct, 1987585 bytes) descargado temporalmente a `/tmp`
  (nunca al repo), veredictos verificados (44/44 EQUIVALENTE). Borrado tras el uso. Se comparó
  explícitamente su fecha contra las fechas de creación/resolución de los 11 Defecto.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #19** de la serie (2 de 3 de este turno). Ver índice
  `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`.

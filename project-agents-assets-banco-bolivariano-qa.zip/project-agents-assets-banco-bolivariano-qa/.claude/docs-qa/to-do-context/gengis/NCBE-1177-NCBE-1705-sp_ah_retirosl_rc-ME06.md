# Aprendizaje personal piloto gengis-me — ME #6: sp_ah_retirosl_rc (NCBE-1177 → NCBE-1705)

Fecha de esta ronda: 2026-10-30. Sexta entrega de la serie. **Esta es la ME más rica de la serie
hasta ahora y la PRIMERA que no cierra 100% EQUIVALENTE** — tiene bugs de QA reales en el padre,
un segundo caso explícito de adjunto de SP equivocado, y un documento local (NCBE-1168) que
reconstruye un ciclo completo de diagnóstico con 3 responsables distintos (QA, Migración, Banco) y
un fix real del motor QA. No se hicieron consultas a Sybase/REST/gRPC, no se reejecutó nada, no se
modificó Jira/QMetry/motor/repos/ME — toda la evidencia del motor/engine se tomó de un documento ya
existente en el repo, con verificación puntual del commit citado (`git log`, solo lectura).

## 1. Identidad y relación de tickets (OBSERVADO en Jira)

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1177 | Story | Padre | Procesa la transacción de Nota de Débito sin libreta |
| NCBE-1702 | Task | Pipeline (relates to) | Análisis de Stored procedure — cob_ahorros.sp_ah_retirosl_rc |
| NCBE-1703 | Task | Pipeline (relates to) | Consolidación de casos de prueba |
| NCBE-1704 | Task | Pipeline (relates to) | Creación de casos de prueba funcionales y estructurales |
| NCBE-1706 | Task | Pipeline (relates to) | Generación de datos para casos de prueba |
| **NCBE-1705** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — cob_ahorros.sp_ah_retirosl_rc** |
| NCBE-2867 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance, no tocado |

SP: `cob_ahorros.sp_ah_retirosl_rc`. Micro: `cpas-mso-ah-retirosl`.

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

NCBE-1177 tiene 10 subtareas: 7 son `Sub-task` de checklist sin contenido de bug (SonarQube/Veracode/
Prisma/Qualys/Pruebas Unitarias/Código) salvo las 3 de abajo.

### NCBE-2214 — "Novedad en versión de dependencia cpas-bb-routecore-cobis" → **QA real, aunque empezó como nota administrativa (profundizado, ver PR20)**

- **Arranque administrativo:** la descripción original solo pedía actualizar
  `cpas-bb-routecore-cobis` de `1.0.0` a la versión del "lote 3" por correo — no era, en su origen,
  un reporte de defecto funcional.
- **Lo que realmente ocurrió (14 comentarios, 15 días, 4 versiones de librería, reconstrucción
  cronológica verificada):**
  1. **1.0.0 → 1.0.4** (07-sep): corrige el error visible `S0022: Invalid column name 'sp_return'`
     en transacciones de un solo resultset, pero el camino `t_trn=4263` (retiro con intermediario
     remoto) seguía fallando. Diagnóstico propio: `AbstractCobisAdapter.readSelectResponse` en la
     librería "bifurcadora" solo leía el **primer** resultset con `executeQuery()` y buscaba
     `sp_return` ahí — cuando el SP emite resultsets intermedios (p. ej. nombre del beneficiario)
     antes del estado final, ese primer resultset no tiene `sp_return` y jConnect lanza el error.
     **Hallazgo grave confirmado:** como ese error de cliente tenía `errorCode 0`, la respuesta
     salía como **HTTP 200 con `codigoRetorno=0` y `data=null`** — un fallo técnico real enmascarado
     como éxito, en una operación financiera.
  2. **1.0.4 → 1.0.5** (09-sep): la librería adopta su propio método correcto
     (`readMultiResultResponse`) para recorrer resultsets. Corrige el camino de rechazo, pero el
     camino de **retiro efectivo** (escritura exitosa) seguía devolviendo `codigoRetorno=-1` con
     `mensajeDebug="01S12: Unable to continue with HOMOGENEOUS_BATCH protocol..."` — un warning
     benigno del driver jConnect, no un error de negocio, pero que en ese camino específico se
     quedaba sin `sp_return` real.
  3. **1.0.5 → 1.0.7** (22-sep): la librería reescribe la invocación como **llamada RPC nativa con
     parámetros de salida registrados explícitamente**, en vez del patrón de texto anterior que
     perdía el estado de retorno bajo el aviso de batching. Confirmado en vivo: el camino de retiro
     efectivo ya no da `-1`, entrega el código funcional real.
  4. **Residual, corregido aparte (commit `eceb855`, 22-sep):** `mensajeDebug` seguía filtrando el
     warning benigno del driver como si fuera un error incluso en éxito real (`sp_return=0`).
     Corregido en `RetiroslRcLibraryAdapter.resolverMensajeDebug` para propagar ese texto solo
     cuando el retorno NO es exitoso. 184 pruebas unitarias en verde, verificado en vivo.
- **Por qué es QA real:** la secuencia completa fue impulsada por pruebas de equivalencia reales
  (Emily Lino Martinez probando el micro, contrastando con lo esperado del SP) — no por un reporte
  de arquitectura o CI. El hallazgo del HTTP 200 enmascarando un fallo técnico es exactamente el
  tipo de divergencia SP↔microservicio que la ME existe para detectar, aunque la causa viva en una
  librería compartida (`cpas-bb-routecore-cobis`, el "bifurcador" que usan varios micros del banco),
  no en el SP ni en el código propio del microservicio.
- **Riesgo colateral para otros consumidores (no verificado aquí, solo señalado):** cualquier otro
  microservicio que consuma `cpas-bb-routecore-cobis` en una versión anterior a 1.0.7 para invocar
  un SP que emite resultsets intermedios podría tener el mismo enmascaramiento. No se investigó cuál
  otro micro la usa — fuera de alcance de esta ronda.

### NCBE-2920 — "Actualización de reporte Veracode" → **NO ES QA (seguridad/checklist administrativo)**

- Pedido de refrescar un reporte Veracode con fecha vieja (26 de agosto); se actualizó y se acordó
  un SLA de 7 días con Seguridad Informática antes de que el desarrollador deba correr el escaneo
  él mismo. Puramente administrativo, sin relación con comportamiento SP↔microservicio.

### NCBE-4471 — "Novedades en pipeline para pase" → **NO ES QA (CI/CD, dependencias, SonarQube — confirma PR08/PR17)**

- Mismo paquete de hallazgos recurrentes ya visto en otras rondas: `commons-logging` no declarado
  (unit test), `jackson-bom` 3.1.4→3.1.7 (CVE Prisma), bump de `cpas-bb-routecore-cobis` 1.0.9→1.0.10
  (versión intermedia inexistente en el registry), y 3 hallazgos SonarQube (`java:S1192` literal
  duplicado, `java:S125` código comentado, `java:S5852` regex marcada como hotspot ReDoS). Confirma
  el patrón de plantilla compartida entre micros `cpas-mso-*` ya catalogado (PR08/PR17).

## 3. Due diligence dentro de la propia HU de revisión (NCBE-1705) — segundo caso confirmado de adjunto equivocado

Los propios comentarios de NCBE-1705 narran, con reconocimiento EXPLÍCITO de los participantes, el
mismo patrón de la ME #5 (PR16):

1. Juan Pablo Sanabria Moscoso (26-ago): "Matriz Consulta Saldo Cargada" — adjunta
   `QA-CASOS-PARSEADOS.json` (525829 bytes).
2. Giorgi Torres Martelo (27-ago), al día siguiente: **"Por favor no tener en cuenta
   'consulta_saldo' y el QA-CASOS-PARSEADOS.json de 514 KB subida el 26 ago... todos estos casos
   fueron movidos a su correcta task: NCBE-1649"**.
3. Jean Oscar Larreategui (31-ago), de nuevo: "la cargada es por otro sp."
4. William Nieto Rico (29-sep, más de un mes después): recién ahí carga los archivos correctos.

**Verificado por hash en esta ronda (no solo por el reconocimiento de los participantes):** el
primer JSON es, en efecto, byte-idéntico al de `sp_cnb_consulta_saldo` (SHA-256
`bd86a5dd752c28c987b875420e12a4a2baf042779a27c3230ab1d6e987a55d4a`, `metadata.sp_objetivo:
"sp_cnb_consulta_saldo"`, 31 TCs) — coincide con el cierre ya conocido de ese SP en memoria propia
(31/31 EQUIVALENTE, 2026-08-26, mismo día del adjunto equivocado). El segundo JSON (29-sep,
1298276 bytes, SHA-256 `350583ea91a493a2373928b33c7a4ec4a72ae418edf37429472323c03cede9b4`) sí es
`sp_ah_retirosl_rc`, 25 TCs — el correcto.

Esto es evidencia aún más fuerte que la de la ME #5 para **PR16**: aquí los propios autores lo
reconocen por escrito en el momento, no es solo una reconstrucción mía por hash/fecha.

## 4. Contraste con la ME final — la PRIMERA ME de la serie que no cierra 100% EQUIVALENTE

- **Universo (del JSON correcto, 29-sep):** 25 TCs, 6 grupos, **21 EQUIVALENTE / 1 INCONSISTENCIA
  (TC07) / 3 NO_EQUIVALENTE (TC08, TC10, TC14)**, 0 STATELESS / 25 STATEFUL.
- **Dato llamativo del propio Jira:** NCBE-1705 está en estado `Done` pero **sin
  `resolutiondate`** — consistente con que, al cierre administrativo del ticket, seguían 4 TCs
  abiertos esperando acción de Banco (ver abajo), no con un gap de evidencia.
- **Reconstrucción del cierre real de los 4 TCs pendientes, vía documento local
  `reporte-resultado-ncbe1168-2026-09-28-validacion-y-fix.md`** (repo propio, `cpas-mso-ah-retirosl/`,
  trabajo fechado 28/29-sep — coincide exactamente con la fecha del JSON correcto subido a
  NCBE-1705). **Nota de procedencia:** este documento usa el rótulo `NCBE-1168` — una Story distinta,
  más vieja (creada 2026-07-29), sin relación estructural con NCBE-1177 en Jira (no es subtarea, no
  es "relates to"). Es decir, el trabajo de cierre real de esta ME se etiquetó internamente con un
  número de ticket diferente al padre oficial de esta ronda — una particularidad de procedencia a
  tener en cuenta (ver sección 6), no una inconsistencia que haya bloqueado nada.
  - **Bug propio de QA, encontrado y corregido por QA misma:** TC01/TC02 dependían de una fila en
    `cob_remesas..re_tran_contable` que debía dejar TC05 (que corre *después* en la secuencia) — un
    error de diseño de fixture, no del SP ni del micro. Corregido dándole a TC01/TC02 su propio
    ciclo insertar-en-PRE/borrar-en-POST, sin tocar motor ni código de nadie. Pasaron de
    NO_EQUIVALENTE a EQUIVALENTE.
  - **3 defectos reales de Migración (código del adaptador `RetiroslRcLibraryAdapter`), todos
    corregidos:** `mensajeDebug` filtraba el warning crudo del driver en códigos de negocio reales;
    campos `CHAR` de salida llegaban como bytes nulos (`\0\0\0...`) en vez de `null`; campos enteros
    (`o_ssn`/`o_control`) llegaban en `0` en vez de `NULL` porque el SP declara el parámetro OUTPUT
    con default `0` y la librería `routecore-cobis` no enviaba `NULL` explícito antes del `EXEC`
    (causa raíz corregida por Migración republicando la librería).
  - **2 defectos reales del MOTOR QA (`execute_all.py`), encontrados y corregidos por el propio
    equipo QA, commit `aec64a8` verificado en `git log` — ver PR21, NO es alerta activa:**
    1. `_compare_scalar()`, rama `exacta-tolera-vacio`: comparaba el valor money del SP-directo
       (entregado como **string** `"0.0000"`) con `== 0` crudo de Python — nunca coincidía.
       Corregido usando `_as_number()` (ya existente en el motor). Causaba diffs falsos de
       `o_comision`/`o_impuesto`/`o_base_imp` en TC03/04/05/07.
    2. `extract_engine_message()`: capturaba un `select 'Nombre' = @o_nombre` (patrón real de varios
       SP hijos del banco) como si fuera un mensaje genuino de motor. Corregido con
       `_next_is_known_value()`, mismo criterio estructural ya usado por el motor (nunca por
       contenido/texto).
    Ambos fixes se probaron contra evidencia real y se regresionaron explícitamente contra
    `sp_tr_pago_giro_rc` (la única otra SP que usa el mismo modo `tolera-vacio`), sin diferencias.
    Resultado: TC01-TC05 pasaron de INCONSISTENCIA a EQUIVALENTE.
  - **4 TCs que siguen pendientes de Banco, documentados y con owner explícito, no un gap:**
    - **TC08, TC10** — bug confirmado en `sp_bas_retndsl_locrem_rc` (Sybase legacy, Msg 536); datos
      de reproducción ya entregados a Banco.
    - **TC07, TC14** — misma causa de fondo: la configuración de conexión jConnect del
      microservicio (`SYBASE_JDBC_URL`) no tiene propiedades de jConnect configuradas, lo que
      dispara el fallback `01S12/HOMOGENEOUS_BATCH` del driver en ciertas rutas — y en esas rutas se
      pierden montos (`o_comision` etc., TC14) o el nombre del titular (`o_nombre`, TC07, en la
      ruta de rechazo por fondos insuficientes `41033`, donde se **verificó leyendo el código real**
      de `sp_ah_retndsl_locrem_rc` que no hay resultset alternativo del que recuperar el nombre —
      limitación genuina, no un fix barato posible en el micro).
- **Cruce relevante no documentado explícitamente en ninguno de los dos hilos, encontrado en esta
  ronda:** la causa raíz de TC07/TC14 (jConnect cayendo a `01S12/HOMOGENEOUS_BATCH` y perdiendo
  parámetros OUTPUT) es **el mismo síntoma exacto** que investigó NCBE-2214 (sección 2) para el
  camino `t_trn=4263` de la librería "bifurcadora" — con la diferencia de que NCBE-2214 lo resolvió
  reescribiendo esa librería como RPC nativo (versión 1.0.7), mientras que TC07/TC14 viven en una
  ruta distinta (el adaptador propio del micro, no el bifurcador) y siguen esperando que Banco
  corrija la configuración de conexión de raíz. Dos hilos de investigación independientes
  (Jira NCBE-2214 vs. documento local NCBE-1168) llegaron al mismo diagnóstico de fondo sin citarse
  entre sí — ver PR22.

## 5. Patrones agrupados por causa o comprobación reusable (nuevos de esta ronda)

### PR20 — Una "Novedad de dependencia" administrativa puede esconder un defecto funcional real; leer el hilo completo antes de descartarla (NUEVO)

- **Evidencia:** NCBE-2214 empezó como un pedido de actualizar una versión de librería y terminó
  destapando un enmascaramiento real de fallo técnico como HTTP 200 éxito.
- **Comprobación reusable:** no clasificar un ticket como NO-QA solo por su título/descripción
  inicial ("actualizar dependencia", "novedad en versión") — leer los comentarios posteriores; si
  aparece evidencia de ejecución real (curls, códigos de retorno, comparación SP vs REST), es
  candidato a QA real aunque la causa viva en una librería de terceros.

### PR21 — Un fix de motor ya confirmado y regresionado no se reabre como alerta (confirmación de regla, con el caso más completo de la serie)

- **Evidencia:** los 2 bugs reales de `execute_all.py` (sección 4) están ya commiteados
  (`aec64a8`, verificado en `git log` en esta misma sesión) y regresionados contra el único otro SP
  afectado por el mismo modo de comparación.
- **Comprobación reusable:** antes de investigar por qué un campo monetario o un mensaje de motor
  se ve raro en una ME histórica, revisar si ya hay un fix de motor fechado después de esa corrida
  — en este caso, el mismo día. Si el fix ya está en `origin/master` y regresionado, no es un
  hallazgo nuevo ni una alerta: es historia ya cerrada.

### PR22 — Dos hilos de investigación independientes (Jira y documento local) pueden converger en la misma causa raíz sin citarse entre sí; reconciliarlos antes de tratarlos como hallazgos separados (NUEVO)

- **Evidencia:** NCBE-2214 (Jira, librería bifurcadora) y el H6 del reporte local NCBE-1168 (TC07)
  diagnostican el mismo mecanismo (`01S12/HOMOGENEOUS_BATCH` de jConnect perdiendo parámetros
  OUTPUT) para el mismo SP/micro, por rutas de código distintas, sin mencionarse entre sí.
- **Comprobación reusable:** cuando aparece un síntoma de driver/conexión (warnings `01S\d+`,
  pérdida de OUTPUT params, HTTP 200 con datos nulos) en un SP, buscar si ya hay otro hilo
  (Jira o documento local) con el mismo síntoma antes de tratarlo como un hallazgo aislado — puede
  ya tener diagnóstico de causa raíz útil, aunque la vía de fix sea distinta.

### Nota de procedencia (no es un patrón, es una observación puntual)

- El trabajo de cierre real de los 4 TCs pendientes de esta ME se documentó bajo el rótulo
  `NCBE-1168` (una Story distinta y más antigua, sin relación Jira con NCBE-1177/NCBE-1705). Al
  buscar evidencia de cierre de una ME, no asumir que solo existe bajo el número del padre/HU
  oficiales de la serie — puede estar etiquetada con un ticket de trabajo interno distinto.

## 6. Lo que no se pudo verificar / queda pendiente

- No se leyeron en detalle `bitacora-sesion-ncbe1168-2026-09-25-completa.md`,
  `correo-ncbe1168-2026-09-27-estado-final.md`, ni los JSON de datos entregados a Banco
  (`ncbe1168-tc08-tc10-datos-banco.json`, `ncbe1168-tc14-datos-banco.json`) — el reporte de
  resultado (sección 7 del documento) ya resume su contenido de forma suficiente y verificable
  (commit real confirmado).
- No se investigó qué otros microservicios del banco consumen `cpas-bb-routecore-cobis` ni si
  siguen en una versión anterior a 1.0.7 con el mismo riesgo de enmascaramiento — señalado como
  riesgo colateral, no verificado (sección 2).
- No se confirmó por qué NCBE-1705 quedó en `Done` sin `resolutiondate` — es consistente con 4 TCs
  aún pendientes de Banco, pero no hay un comentario que lo explicite así.
- `retirosl_rc_service.proto` (adjunto a NCBE-1705) no se inspeccionó en detalle.

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1177 (campos + 10 subtareas + 6 issuelinks "relates to");
  NCBE-1705 (campos + 4 adjuntos + 4 comentarios); NCBE-2214 (campos + 14 comentarios);
  NCBE-2920/4471 (campos + comentarios); NCBE-1168 (solo campos básicos: summary/status/parent/
  fechas, para entender su relación — confirmado que es una Story distinta, sin relación
  estructural con NCBE-1177).
- **Verificación de hash:** los 2 JSON de NCBE-1705 descargados temporalmente a `/tmp` (nunca al
  repo), hash y `metadata.sp_objetivo` verificados — uno resultó ser de otro SP
  (`sp_cnb_consulta_saldo`, confirmado por los propios participantes en los comentarios), el otro es
  el correcto (`sp_ah_retirosl_rc`, SHA-256
  `350583ea91a493a2373928b33c7a4ec4a72ae418edf37429472323c03cede9b4`). Ambos borrados tras el uso.
- **Consulta puntual fuera de Jira (justificada y dentro del propio repo, ya en el working tree):**
  lectura completa de `reporte-resultado-ncbe1168-2026-09-28-validacion-y-fix.md` (ya existente en
  `.claude/docs-qa/inputs/documents/cpas-mso-ah-retirosl/`, no descargado de ningún lado), porque es
  imprescindible para entender cómo se resolvieron los 4 TCs pendientes que la ME de NCBE-1705
  refleja — citado explícitamente aquí por esa razón. Verificación puntual del commit `aec64a8`
  citado ahí con `git log`/`git show --stat` (solo lectura, sin tocar el árbol de trabajo).
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central (solo se leyó su historial de commits, no se modificó nada). No se hicieron consultas
  a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #6** de la serie. Ver índice `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`. Pendiente:
  el usuario indicará el siguiente ticket padre y su HU.

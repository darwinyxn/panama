# Aprendizaje personal piloto gengis-me — ME #16: sp_pago_giro (NCBE-1804 → NCBE-2034)

Fecha de esta ronda: 2026-11-01. Decimosexta entrega de la serie (de las 2 que llegaron este
turno). No se hicieron consultas a Sybase/REST/gRPC, no se reejecutó nada, no se modificó Jira/
QMetry/motor/repos/ME.

## 1. Identidad y relación de tickets

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1804 | Story | Padre | Microservicio: sp_pago_giro |
| NCBE-2029/2032/2033/2184 | Task | Pipeline (relates to) | Análisis/Consolidación/Generación de datos/Creación de casos |
| **NCBE-2034** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — cob_giros.sp_pago_giro** |
| NCBE-2035 | Task | Pipeline (relates to) | Pruebas de rendimiento — fuera de alcance |

SP: `cob_giros.sp_pago_giro`. Micro: `ecu-mso-pago-giro`. 31 TCs (final). Confirmado por el último
JSON adjunto a NCBE-2034 (09-oct, 646453 bytes): **31/31 EQUIVALENTE**.

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

7 `Defecto`, todos con contenido real (8 `Sub-task` de checklist sin bug).

### QA real

- **NCBE-2884:** la ME tenía configurados como endpoints PRINCIPALES los valores `localhost` del
  túnel de port-forward usado durante la certificación — corregido para usar las rutas reales de
  OpenShift, conservando el localhost solo como trazabilidad interna. Hallazgo adicional: una fila
  de evidencia reportada como "diferente" correspondía a un registro que SÍ existía al momento de
  la certificación (15-sep) y ya no existe en el ambiente — deriva de datos, no defecto.
- **NCBE-2941 — defecto real de código, confirmado y corregido:** fuga de conexión del pool: cuando
  una operación no confirmaba (código de retorno distinto de cero o excepción), la conexión no se
  descartaba correctamente y quedaba contaminando peticiones siguientes. Corregido con rollback
  defensivo + descarte físico de la conexión en vez de devolverla al pool (commit `aace86b`).
- **NCBE-3356 (TC29):** mismo síntoma de fondo que NCBE-2941 (`PoolExhaustedException`,
  `CannotGetJdbcConnectionException`, HTTP 500, gRPC `Unavailable`/`EOF`) — revalidado tras el fix
  del pool, 10/10 ejecuciones correctas en REST y gRPC, pod estable sin reinicios. Confirma que el
  fix de NCBE-2941 resolvió la causa raíz compartida.
- **NCBE-4457 (TC31) — defecto real de mensajería, confirmado y corregido:** cuando la ejecución
  pasa por la librería `sp_ccndc_automatica`, el mensaje de negocio llegaba distinto por canal
  (REST/gRPC devolvían "CUENTA BLOQUEADA PARA MOVIMIENTOS" en vez de "Cuenta bloqueada: CONTRA
  DEPOSITO Y RETIRO" que da el SP). Corregido y revalidado en los 3 canales, sin regresión en
  TC026/TC027.

### NO-QA

- **NCBE-4040:** observabilidad/logging — el log no mostraba el error técnico completo cuando el SP
  lo traducía a código funcional; corregido para loguearlo a nivel WARN sin exponerlo en la
  respuesta de la API. Seguimiento: se agregó una bandera de ConfigMap
  (`LOG_REQUEST_RESPONSE_COMPLETO_LEVEL`, INFO=enmascarado/TRACE=completo) para depuración, sin
  tocar la respuesta del API. Útil, pero no es un hallazgo de equivalencia.
- **NCBE-4584:** error de despliegue por alias de certificado gRPC distinto entre namespaces
  (`bb-dev-core` vs `bb-dev-giros`) — configuración de infraestructura, no código. Un segundo
  intento de arreglo chocó con un límite de descargas (429) del registro público de imágenes Docker
  — transitorio, resuelto relanzando el job.
- **NCBE-4610:** SonarQube (regex con riesgo de desbordamiento de pila, clase de caracteres) +
  Prisma (CVE de Jackson) — calidad de código, sin relación con comportamiento SP↔micro.

## 3. Hallazgos adicionales en la propia HU de revisión (no capturados como Defecto)

- **Regresiones de entrega entre versiones de la ME (confirma PR26, ME #8):** al menos 2 veces
  durante este ciclo (15-sep y 24-sep) el equipo de Banco (Jean Oscar Larreategui, Michael Tomala)
  reportó que una nueva versión de la ME **ya no incluía los apartados PRE/EXEC/POST** que una
  versión anterior sí tenía, o que los datos de la ME no correspondían a los del documento del SP
  — obligando a recapturar. Mismo patrón de regeneración-sin-diff-contra-la-versión-anterior ya
  visto en la ME #8.
- **Enmascaramiento parcial del nombre del SP — regla concreta de "50%" (nueva, relacionada con
  NCBE-4514/ME#15 y NCBE-2335):** `sp_pago_giro` (12 caracteres) se enmascara mostrando solo 6 de
  los 12 — formato confirmado por Banco: `[******o_giro]`. Es la primera vez en la serie que se ve
  la REGLA NUMÉRICA exacta del enmascaramiento (50% de los caracteres), no solo "se enmascara el
  nombre".
- **Tipo de dato `double` vs entero en campos de monto (`detalleGiro.gpMontoPagar`,
  `pagosPorServicio.montoPagar`, `pagosParaModificar.montoPagar`):** el `.proto` ya declaraba
  `google.protobuf.DoubleValue`, pero el valor se exponía como entero — corregido para los 3
  campos; confirma la familia de hallazgos de tipo wire monetario ya vista en varias rondas.
- **Semántica NULL distinta entre REST y gRPC para parámetros opcionales (hallazgo DICCIONARIO
  nuevo, TC31):** en REST, un parámetro opcional sin valor se envía explícitamente como `null` en
  el JSON. En gRPC, para el mismo contrato, ese campo debe **omitirse del request por completo**
  — si se incluye explícitamente como `null`, el mapper lo propaga igual, pero el comando de
  evidencia con `null` explícito en gRPC fallaba antes de invocar el servicio (error de
  `grpcurl`, no del microservicio). **Regla DICCIONARIO:** la ausencia de un valor opcional se
  representa distinto por protocolo — `null` explícito en REST, campo omitido en gRPC — y la
  evidencia/comando debe seguir esa convención por canal, no una convención única.
- **TC024 — deriva de datos/ambiente entre cortes de tiempo:** el mismo caso, con los mismos datos,
  retornaba `RETURN 0` limpio en una captura certificada del 01-sep y `35001`/`Msg 515` (NULL en
  `ah_promedio1`) en una ejecución posterior. Gengis trazó la cadena de causas hasta
  `cobis..cl_moneda`/`cobis..cl_parametro` (DCI/CTE) — quedó como validación pendiente con el
  equipo, sin que el hilo capturado confirme la resolución final. Ver sección 5.

## 4. Patrones de esta ronda

No se proponen patrones nuevos de fondo — refuerza y precisa patrones ya catalogados:

- **Confirma PR26** (ME #8): regresión de PRE/EXEC/POST entre versiones sucesivas de la misma ME.
- **Confirma la familia de hallazgos de tipo wire monetario** (P07/varias rondas): `double` vs
  entero en campos de monto.
- **Nuevo detalle reusable (sin ascender a patrón propio todavía):** la regla de enmascaramiento al
  "50% de los caracteres del nombre del SP" es la primera cifra exacta documentada en la serie para
  este requerimiento de Seguridad — útil como referencia si aparece de nuevo en otro SP.
- **Nuevo detalle reusable:** la semántica de "campo opcional ausente" difiere por protocolo (REST:
  `null` explícito; gRPC: campo omitido) — revisar esta distinción antes de dar por sentado que un
  comando de evidencia gRPC con `null` explícito es equivalente a uno sin el campo.

## 5. Lo que no se pudo verificar / queda pendiente

- No se confirma la resolución final de TC024 (deriva de `cl_moneda`/`cl_parametro` DCI/CTE) — el
  comentario de Gengis corta antes de la conclusión y no hay comentario posterior en NCBE-2034 que
  lo retome explícitamente; el JSON final (31/31 EQUIVALENTE) sugiere que se resolvió, pero no se
  verificó el mecanismo exacto.
- No se inspeccionaron en detalle los 28 adjuntos de NCBE-2034 (9 versiones de JSON/proto/html) más
  allá de los citados en los comentarios.

## 6. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1804 (campos + 15 subtareas + 6 issuelinks); NCBE-2034
  (campos + 28 adjuntos + 18 comentarios completos); los 7 Defecto (campos + comentarios
  completos).
- **Verificación:** último adjunto JSON de NCBE-2034 (09-oct, 646453 bytes) descargado
  temporalmente a `/tmp` (nunca al repo), veredictos verificados (31/31 EQUIVALENTE). Borrado tras
  el uso.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #16** de la serie. Ver índice `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`.

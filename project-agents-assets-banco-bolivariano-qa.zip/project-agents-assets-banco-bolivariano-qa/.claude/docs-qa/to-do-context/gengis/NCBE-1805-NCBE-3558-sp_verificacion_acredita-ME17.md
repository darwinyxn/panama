# Aprendizaje personal piloto gengis-me — ME #17: sp_verificacion_acredita (NCBE-1805 → NCBE-3558)

Fecha de esta ronda: 2026-11-01. Decimoséptima entrega de la serie — SP de 200 TCs, el universo
más grande de toda la serie. No se hicieron consultas a Sybase/REST/gRPC, no se reejecutó nada, no
se modificó Jira/QMetry/motor/repos/ME.

**Nota de procedencia importante:** el usuario indicó NCBE-3558 como "HU de revisión donde está
adjunta la ME". **Verificado:** NCBE-3558 no es la tarea formal de revisión enlazada al padre — es
un **Sub-task de NCBE-1995** ("Revisión de matriz de equivalencia - cob_giros.sp_verificacion_acredita",
la que realmente aparece en los issuelinks de NCBE-1805), creado el 02-oct específicamente para
"Generación de matriz de equivalencia NYXN". **Los adjuntos de NCBE-1995 quedaron desactualizados
en el 08-oct (2 archivos); los adjuntos REALES y más recientes (hasta el 21-oct, 200/200
EQUIVALENTE) viven en NCBE-3558.** El usuario señaló correctamente dónde está el artefacto vigente
— es una instancia institucionalizada (no accidental) del patrón ya visto de "el adjunto vigente
puede no estar en la tarea formal de revisión".

## 1. Identidad y relación de tickets

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1805 | Story | Padre | Microservicio: Verifica Acreditación |
| NCBE-1991/1992/1993/1994 | Task | Pipeline (relates to) | Análisis/Creación/Consolidación/Generación de datos |
| NCBE-1995 | Task | Pipeline (relates to) | Revisión de matriz de equivalencia (tarea formal, adjuntos obsoletos) |
| **NCBE-3558** | Sub-task de NCBE-1995 | **HU de esta ronda** | **Generación de matriz de equivalencia NYXN — cob_giros.sp_verificacion_acredita** |
| NCBE-2872 | Task | Pipeline (relates to) | Pruebas de rendimiento — en estado "Construcción", fuera de alcance |

SP: `cob_giros.sp_verificacion_acredita`. Micro: `ecu-mso-verificacion-acredita`. **200 TCs** —
confirmado por el último JSON adjunto a NCBE-3558 (21-oct, 5928269 bytes): **200/200 EQUIVALENTE**.

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

8 `Defecto`, todos con contenido real y sustancial. El equipo "Testing BB" (Yamilet Cisneros, Carla
Parrales, Michael Tomala) reportó decenas de TCs adicionales dentro de cada ticket a medida que
encontraban el mismo patrón repetido — por eso cada ticket termina cubriendo muchos más TCs que el
que aparece en su título original.

### NCBE-4467 — "Diferencia en campos entre SP y REST/gRPC" → **QA real, creció a ~90 TCs**

- Causa: los `result_set` sin nombre de columna que emite el SP (`organiza`, `riesgo`) no se
  reflejaban igual en REST/gRPC. Se fue ampliando TC por TC (TC22, 23, 24, 26-70, 73-80, 85-87, 92,
  93, 99, 171-176, 195-200...) a medida que el equipo de Banco encontraba el mismo síntoma.
  Solventado y cerrado el 20-oct.

### NCBE-4469 — "Validación del nombre del beneficiario falla con NULL" → **QA real, confirma la regla "nunca asumir ANSI NULL en Sybase" (memoria propia) con un caso nuevo**

- Con `@i_nombre_beneficiario = NULL` e `@i_cobis = 'S'`, el resultado depende de la **opción de
  sesión `ansinull`**: con `ansinull off` (default de `isql` y de las sesiones COBIS), la
  comparación con NULL de la línea 685 del SP evalúa VERDADERO y el SP retorna `1`/`101077` ("El
  nombre del beneficiario cambió antes de enviar el pago"); con `ansinull on` (default de
  jConnect), la misma comparación es "desconocida" y el SP sigue de largo (el TO-BE que Banco
  esperaba). La librería reproduce fielmente el comportamiento real de COBIS (`ansinull off`), así
  que **no se agregó un guard de nulidad** — en vez de "corregir" para que coincida con el TO-BE,
  se preguntó a Banco con qué configuración de sesión se obtuvo esa expectativa. Banco aceptó la
  explicación.
- **Esta es la tercera instancia documentada en la serie de la regla ya catalogada en memoria
  propia ("Semántica NULL en Sybase — nunca asumir ANSI NULL")** — aquí con el mecanismo exacto
  (`ansinull`) nombrado explícitamente por el desarrollador, no solo inferido.

### NCBE-4470 — "Nombre de SP faltante, debe enmascararse al 50%" → **NO ES QA (seguridad/presentación, confirma familia NCBE-4514/NCBE-2335)**

### NCBE-4484 — "REST/gRPC no muestra el mensaje de error esperado" → **QA real, reveló que el documento de Banco tenía expectativas desactualizadas en varios TCs**

- Creció a decenas de TCs (TC25, 71, 72, 94, 95, 105, 140, 147, 178-193...). El hallazgo más
  importante lo trajo Juan Pablo Sanabria (19-oct): en **al menos 7 TCs** (TC02/03/122, TC102,
  TC142, TC121, TC136, TC138, TC162) **el documento de casos de Banco esperaba un resultado que el
  SP real, en su definición vigente, ya no produce** — por ejemplo, el documento esperaba la
  excepción `31048` pero el SP devuelve `RETURN 1` con mensaje; o esperaba "Giro cancelado o
  anulado" pero el SP real devuelve `105020` con un mensaje distinto. En vez de ajustar la ME para
  que "pasara", se solicitó explícitamente autorización de Banco para corregir el documento de
  casos con el comportamiento real verificado.
- **TC147** es el ejemplo más elaborado: requirió 5+ rondas de ajuste de PRE/fixture (colisión de
  secuenciales, SSN no liberados, moneda incorrecta) hasta aislar que el escenario real que el
  título pedía ("Acreditación en moneda extranjera") necesitaba un giro en moneda distinta de 1 con
  cotización cargada — dato que no existía en el caso original (que estaba en moneda 1). Se
  documentó la brecha en vez de forzar un resultado.

### NCBE-4498 — "mensaje_debug no equivalente (TC14)" → **QA real, resuelto por consulta directa al desarrollador del SP**

- Se envió una consulta formal por correo al desarrollador responsable del SP sobre el
  comportamiento de los mensajes debug; la siguiente ejecución ya mostró el comportamiento
  correcto. Cerrado.

### NCBE-4500 — "Decimales no equivalentes (tipo de dato)" → **QA real, confirma el criterio transversal de money ya documentado en la ME #15**

- Mismo criterio de NCBE-4272/Pablo Ricaurte (ME #15, sección DICCIONARIO): comparar por valor
  decimal, no por representación textual. Creció a TC73, 76, 83, 84, 88-90, 195, 196. Solventado.

### NCBE-4506 — "Código de retorno y mensaje difieren de lo esperado en Resultado Obtenido" → **QA real, el hallazgo de alcanzabilidad más grande y mejor explicado de toda la serie**

- Creció a docenas de TCs. Causa raíz identificada por Juan Pablo Sanabria (19-oct) con una
  analogía muy clara: **en 22 TCs, el resultado esperado era "llave duplicada" (`Msg 2601` en
  `cg_tran_servicio`), pero esa colisión NO venía de la lógica del SP que el caso pretendía
  probar — venía de que la base todavía tenía una fila de una ejecución QA anterior con el mismo
  `@s_ssn`.** Cita textual: *"es como intentar guardar un archivo con un nombre que ya existe: el
  SP se frena al inicio, al guardar su registro, y nunca llega a hacer lo que el caso quiere
  probar."* De los 22, **solo 3 (TC68, TC70, TC107) prueban deliberadamente ese error de llave
  duplicada** y deben CONSERVAR la fila repetida; los otros 19 necesitan un `@s_ssn` nuevo para
  alcanzar su rama real. Propuesta explícita a Banco antes de aplicar el cambio masivo; autorizada
  y ejecutada el 19-oct, confirmando que los 19 casos "libres" dan `RETURN 0` y los 3 deliberados
  siguen dando el error de llave duplicada como deben.
- **Es el ejemplo más grande de la serie del patrón P11/P08** (BB_MINERIA: alcanzabilidad y
  recaptura parcial) — 22 TCs de una sola vez, con metodología explícita (separar "accidental" de
  "deliberado" antes de tocar nada) y autorización previa de Banco.

### NCBE-4529 — "REST/gRPC no equivalentes" → **QA real, mayormente resuelto por actualización del .proto**

- Varios TCs (TC138, TC141, TC142) resueltos actualizando el `.proto` vigente; TC138 confirmado
  equivalente en los 3 canales tras el ajuste.

## 3. Hallazgo principal de los bugs del padre

A diferencia de ME #16 (donde los defectos reales eran de código), **la mayoría de la sustancia
aquí es de alcanzabilidad y vigencia del documento de casos**: datos de prueba contaminados entre
corridas (NCBE-4506, el caso más grande), semántica NULL dependiente de configuración de sesión
(NCBE-4469), y expectativas del documento de Banco desactualizadas frente al comportamiento real
vigente del SP (NCBE-4484). En los 3 casos, la respuesta correcta no fue "ajustar la ME para que
pase", sino escalar a Banco con evidencia y pedir autorización antes de cambiar nada — un patrón
metodológico consistente y ya maduro en esta ronda.

## 4. Contraste con la ME final (NCBE-3558)

- **Universo:** 200 TCs, **200/200 EQUIVALENTE** — el universo más grande de toda la serie,
  confirmado por el último JSON (21-oct, 5928269 bytes).
- Nota de memoria propia: una entrega previa (14/21-oct) había dejado items pendientes de Banco
  (TC13/23/136/148 según memoria de sesiones anteriores); el estado final verificado en esta ronda
  no muestra pendientes — consistente con que esos puntos se resolvieron antes del cierre del
  21-oct (no se investigó el mecanismo exacto, ver sección 6).
- Los 8 Defecto de la sección 2 dejan rastro directo en la evolución: cada ronda de corrección
  (result_sets, NULL/ansinull, mensajes, decimales, alcanzabilidad de 22 TCs, proto) se refleja en
  una nueva versión de la ME, documentada explícitamente por Juan Pablo Sanabria en cada entrega.

## 5. Patrones de esta ronda

No se proponen patrones nuevos — esta ronda aporta **confirmaciones** de alto valor:

- **Confirma la regla "nunca asumir ANSI NULL en Sybase"** (memoria propia) con el mecanismo
  `ansinull` nombrado explícitamente (NCBE-4469) — tercera instancia documentada en la serie.
- **Confirma y lleva a máxima escala el patrón de contaminación de datos entre corridas** (P04/P11
  de BB_MINERIA) — 22 TCs de una sola vez, con metodología de separación accidental/deliberado y
  autorización previa (NCBE-4506).
- **Confirma que el documento de casos de Banco puede tener expectativas desactualizadas frente al
  comportamiento real vigente del SP** (NCBE-4484) — la respuesta correcta es escalar con evidencia,
  nunca ajustar la ME unilateralmente para que "pase".
- **Confirma el criterio transversal de comparación de `money` por valor decimal** (NCBE-4500,
  mismo criterio de NCBE-4272 documentado en la ME #15).

## 6. Lo que no se pudo verificar / queda pendiente

- No se confirmó el mecanismo exacto por el cual los 4 pendientes de Banco que memoria propia
  registraba (TC13/23/136/148) quedaron resueltos para el cierre 200/200 del 21-oct — el JSON final
  no los muestra como pendientes, pero no se rastreó el comentario puntual de cierre de cada uno.
- No se profundizó en los adjuntos `.proto` intermedios (al menos 3 versiones) más allá de
  confirmar que su actualización resolvió NCBE-4529.
- No se verificó si NCBE-1995 (la tarea formal, con adjuntos obsoletos del 08-oct) debería
  formalmente redirigir a NCBE-3558, o si es una inconsistencia de proceso a señalar — se deja
  solo registrada la observación en la nota de procedencia (sección inicial).

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1805 (campos + 17 subtareas + 6 issuelinks); NCBE-1995 y
  NCBE-3558 (campos + adjuntos, para aclarar la discrepancia de procedencia); los 8 Defecto (campos
  + comentarios completos).
- **Verificación:** último adjunto JSON de NCBE-3558 (21-oct, 5928269 bytes) descargado
  temporalmente a `/tmp` (nunca al repo), veredictos verificados (200/200 EQUIVALENTE). Borrado
  tras el uso.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #17** de la serie. Ver índice `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`.

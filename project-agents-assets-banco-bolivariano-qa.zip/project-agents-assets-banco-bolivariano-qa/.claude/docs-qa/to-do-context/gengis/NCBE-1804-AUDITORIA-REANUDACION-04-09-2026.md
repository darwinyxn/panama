# NCBE-1804 — cob_giros.sp_pago_giro — AUDITORÍA DE REANUDACIÓN (04-09-2026)

> Fase: DISCOVERY + AUDITORÍA. NO se ejecutó la Matriz de Equivalencia ni los 30 TCs contra el micro.
> No se hizo commit ni push de artefactos de trabajo (aparte de este documento).
> Punto de partida: handoff `NCBE-1804-sp_pago_giro.md` (cierre legacy 2026-09-01), retomado tras
> confirmación de Migración de que el micro/librería del lote 5 ya están disponibles.

## VEREDICTO_AUDITORIA_REANUDACION_NCBE_1804 = MIXTO

Todos los prerrequisitos técnicos para la Matriz están cumplidos; quedan dos correcciones QA
cosméticas y un hallazgo de seguridad no bloqueantes. Resultado final: **MATRIZ_PUEDE_INICIAR = SI**.

---

**1. HEAD repo QA**
`master` @ `78b7163`. Working tree con cambios ajenos preexistentes no tocados por esta auditoría:
`casos_prueba_sp_pago_giro.md` (modificado) y los 5 directorios de `results/sp_pago_giro-*` + el
handoff de `to-do-context/gengis/` (untracked). No se agregó, modificó ni commiteó nada de eso.

**2. Handoff leído y estado recuperado**
Leído completo. Cierre legacy 2026-09-01, `MATRIZ_EQUIVALENCIA = PENDIENTE_SOLO_DE_JAVA`. El "punto
exacto de reanudación" del handoff se siguió al pie de la letra en esta auditoría (verificar HEAD
Java → mapear SP→lib→micro → DTO/nulls → hijas → REST/gRPC → proto).

**3. Insumo 30/30 validado**
`casos_prueba_sp_pago_giro.md` íntegro: 30 `### TC0xx` (TC001–TC030), 30 `TCO-CON-0xx`, 26 menciones
de teardown. No se regeneró.

**4. Evidencia legacy definitiva localizada**
- `sp_pago_giro-01-09-2026-1948-LEGACYRUN/`: existe, `resumen_final.json` → `n_pass=30, n_fail=0,
  n_blocked=0, total=30`, `final_baseline_diff_vs_golden={}` (limpio).
- `sp_pago_giro-01-09-2026-2008-VALIDACION-TEARDOWN/`: existe, evidencia consistente con 7/7.
- Las 3 corridas 1833/1906/1942 existen y están correctamente clasificadas como diagnósticas.
- **Hallazgo QA menor:** el texto de `casos_prueba_sp_pago_giro.md` para **TC019** y **TC026** dice
  "pendiente de re-verificacion", pero el log/JSON de la corrida 1948 confirma que **ambos SÍ se
  ejecutaron con el escenario corregido y dieron PASS** (TC019: `return=0, coalesce_ok=True`; TC026:
  `return=0, unchanged_ok=True`). El documento quedó desactualizado tras la corrida definitiva. No
  requiere volver a tocar Sybase — solo actualizar el texto observado en el .md.

**5. HEAD/branch micro**
`ecu-mso-pago-giro`, branch `develop-dvp`, HEAD `b65480b "NCBE-1804: microservicio ecu-mso-pago-giro
(facade REST+gRPC de cob_giros..sp_pago_giro)"`, 1 commit local por encima de `origin/develop-dvp`
(no pusheado). Esto **contradice** el "sin código Java utilizable" del handoff — confirma lo que
informó Migración: el micro ya tiene implementación real. `target/ecu-mso-pago-giro-1.0.0.jar` ya
compilado presente.
**Nota de seguridad:** el remote `origin` de este repo tiene un **PAT de GitHub embebido en texto
plano** en `.git/config`. No se reproduce aquí; se recomienda rotarlo.

**6. HEAD/branch librería**
`bb-core-cob-giros-utils`, branch `develop-dvp`, HEAD `0e06152` (NCBE-1857, otro HU), 62 commits por
encima de origin. El módulo relevante `sp-pago-giro-utils` fue construido en
`9b935ee`→`db8e6f4`→`a06b453`→`1cd83d3`→`b3f52b1` (NCBE-1798). El working tree tiene cambios sin
commitear, pero **ninguno toca `sp-pago-giro-utils/`** (afectan pa-ecu-tvalidaspi-utils,
pa-ecu-tverf-cupoemp-utils, sp-proc-giros-utils, sp-verificacion-automatica-utils — otros HUs).

**7. Confirmación de código Java real**
Ambos repos tienen código Java real y compilable, no scaffolds:
- Micro: arquitectura hexagonal completa (dominio, usecases, inbound REST+gRPC, outbound library
  adapter, filtros de seguridad, resilience4j), 56 archivos fuente + 56 de test.
- Librería: `verification/build-result.json` → `compilation=SUCCESS, tests_run=365, tests_failed=0,
  coverage=100% en todas las capas, mvn_install=SUCCESS`, jar instalado en `.m2` como
  `sp-pago-giro-utils-1.0.0-snapshot.jar` — versión que coincide exactamente con la que el micro fija
  en su `pom.xml` (`sp-pago-giro-utils.library.version=1.0.0-snapshot`).

**8. Mapa SP → librería → micro**
`cob_giros.sp_pago_giro` → `SpPagoGiroLibrary` (bb-core-cob-giros-utils/sp-pago-giro-utils) →
consumida vía `SpPagoGiroLibraryAdapter` en el micro → `PagoGiroUseCaseImpl` → `PagoGiroController`
(REST) / `PagoGiroGrpcService` (gRPC).

**9. Mapa Q/I/U/D/S/C/V/X**
Dispatcher real en `SpPagoGiroLibrary.ejecutar()` (switch sobre `OperacionPagoGiro.fromSybase`):

| Op | Método Java |
|---|---|
| Q | `ejecutarConsultaDetalle` |
| I | `ejecutarInsercion` |
| U | `ejecutarActualizacion` |
| D | `ejecutarEliminacion` |
| S | `ejecutarConsultaPorServicio` |
| C | `ejecutarConsultaParaModificar` |
| V | `ejecutarVerificacionAcreditacion` |
| X/default | `NO_RECONOCIDA → RETURN_OK` sin efectos (no-op), igual que legacy |

**10. Dependencias hijas y equivalentes Java**

| SP legacy | Tratamiento en Java | Tipo |
|---|---|---|
| `sp_cta_vigente` | `CtaVigenteLegacyAdapter`: EXEC JDBC directo del SP legacy (`cob_cuentas..sp_cta_vigente`), async + CircuitBreaker/TimeLimiter, `NOT_SUPPORTED` | **Sigue siendo llamada SP**, no reimplementada |
| `sp_ccndc_automatica` | `CcndcAutomaticaLegacyAdapter`: EXEC JDBC directo, síncrono (comparte conexión ligada del scope transaccional) | **Sigue siendo llamada SP**, no reimplementada |
| `sp_ctah_vigente` | `SpCtahVigenteSiblingAdapter`: delega a `SpCtahVigenteLibrary` (librería hermana ya migrada, `com.bolivariano.cobahorros.spctahvigente.utils`) | **Reimplementada** (librería Java sibling, in-process) |
| `sp_ahndc_automatica` | `SpAhndcAutomaticaBancoAdapter`: delega a `AcreditarAhoUseCase` de `cpas-fw-bb-core-cta` (framework corporativo Banco, versión fija 1.0.0, sin `-snapshot`) | **Reimplementada vía framework externo preexistente** — solo bytecode disponible (sin fuentes), no decompilado en esta auditoría |

Propagación de error: en las 4, el `returnCode!=0` del hijo se traduce como retorno funcional normal
(`SpPagoGiroResult.soloCodigo(...)`), no como excepción — **salvo** que el propio hijo (vía JDBC
directo, casos 1 y 2) lance `SQLException` real de Sybase, en cuyo caso no hay try/catch alrededor de
esas llamadas en `ejecutarVerificacionAcreditacion` y la excepción se propaga sin control.
Transaccionalidad: `TransaccionScopePort`/`JdbcTransaccionScopeAdapter` abre `begin tran` real y
garantiza `commit`/`rollback tran` explícito en `finally` para I/U/D/V (S03/S04/S05/S08) —
comportamiento **más estricto** que el SP legacy (que no hace rollback propio, ver punto 17).

**11. Contrato REST**
`POST /api/v1/giros/pagos/pagar` confirmado exacto en `PagoGiroController`. `PagoGiroRequestDto`
mapea 1:1 los 24 parámetros de entrada del SP (`@JsonProperty` snake_case). Solo `i_operacion` e
`i_cod_giro` (los dos OBLIGATORIOS del dispatcher) usan el wrapper `Presence<T>` para distinguir
"omitido" de "null explícito"; el resto de opcionales son tipos nullable planos, donde
omitido==null==null de Sybase (coherente, porque a nivel de SP no hay una tercera distinción real).
Errores → `GlobalExceptionHandler` con RFC7807 (`ProblemDetail`): validación→400,
circuit-breaker/timeout→503, rate-limit→429, `DataAccessException`/genérico→500.

**12. Contrato gRPC**
`pagogiro.PagoGiroService/PagarGiro` confirmado exacto en `PagoGiroGrpcService extends
PagoGiroServiceGrpc.PagoGiroServiceImplBase`. **Diferencia REST vs gRPC a vigilar en Matriz:** el
`.proto` declara `optional` en los 29 campos de `PagoGiroRequest` (proto3 explicit presence nativo
para todos), mientras que el DTO REST solo tiene presencia explícita para 2 campos. Si el mapper
gRPC no propaga esa granularidad al `PagoGiroCommand` interno igual que el mapper REST, podría haber
asimetría de comportamiento entre canales para TCs de opcionales (tipo TC019) ejecutados por gRPC.

**13. Proto productivo**
- Repo: `ecu-mso-pago-giro` (checkout local)
- Ruta: `src/main/proto/pago_giro_service.proto`
- HEAD/commit que lo introdujo: `b65480b` (único commit que lo toca)
- SHA256: `a31c1df08b5bc934cf14896d90505fbf56e480973087892a6ef494830567466b`
No se modificó.

**14. Revisión TC019**
Legacy: NULL→COALESCE preserva valor previo, confirmado PASS en corrida 1948 (ver punto 4). Java:
`SpPagoGiroParamsTruncator` no interviene aquí (solo trunca longitud); la preservación de valores es
responsabilidad de la lógica de `ejecutarActualizacion`/adapters de persistencia (no auditada línea
por línea en esta fase). Java distingue NULL/omitido explícitamente solo para 2 campos (Presence);
para los campos que TC019 ejercita (`i_fecha_pago`, `i_servicio`, `i_beneficiario`, `i_tipo_cta`,
`i_num_cuenta`, `i_monto_pagar`, `i_direccion_entrega`) no hay distinción NULL-vs-omitido en Java, lo
cual es consistente con que tampoco existe esa distinción real en Sybase para ese TC.

**15. Revisión TC025**
Confirmado en código: `tipoCta=9` → ni `corriente` ni `ahorros` se activan en
`ejecutarVerificacionAcreditacion` (ambos flags `false`) → sin delegación a hija → sigue directo a
`actualizarNotaCreditoYAcreditar` dentro de la transacción → `RETURN_OK`. Coincide con "sin hija
aplicable → RETURN 0" del legacy.

**16. Revisión TC026**
Confirmado PASS en corrida 1948 con el escenario corregido (cuenta válida, servicio VM≠C, giro sin
cambios). Nota: el texto del .md sigue con "pendiente de re-verificacion" (mismo hallazgo del
punto 4).

**17. Revisión TC027/28/29**
Java delega la validación de vigencia (`sp_cta_vigente`/`sp_ctah_vigente`) y la acreditación
(`sp_ahndc_automatica`) exactamente como en el punto 10. Para TC027/028, si Sybase lanza un error
duro (no un `RETURN` limpio) dentro del EXEC anidado — como observó el legacy (`SQLException` en vez
de `RETURN 31004/41001`) — el mismo patrón de JDBC directo en Java (`CtaVigenteLegacyAdapter`) está
expuesto a la misma clase de excepción, sin try/catch específico alrededor de esa llamada; propagaría
como `CompletionException`/`DataAccessException` hasta `GlobalExceptionHandler` → probablemente HTTP
500 genérico en vez de un código funcional. Esto es **inferencia basada en código**, no confirmado
por ejecución — corresponde verificarlo empíricamente en la Matriz (no se ejecutó nada aquí). Para
TC029, el comportamiento transaccional legacy (`@@trancount=1` tras el error, sin rollback propio del
SP) contrasta con Java, que **sí** garantiza rollback explícito vía
`JdbcTransaccionScopeAdapter.cerrarSiActiva()` en el `finally`. El estado final de datos sería
equivalente (ambos acaban limpios), pero el mecanismo es distinto — no juzgado como equivalencia
aquí, solo reportado.

**18. Revisión TC030**
Confirmado en código: `OperacionPagoGiro.fromSybase('X')` → `NO_RECONOCIDA` → `RETURN_OK` inmediato
sin ningún acceso a puertos de datos. Coincide exactamente con "operación X → no-op → RETURN 0" del
legacy.

**19. Hallazgos Java**
- El módulo `sp-pago-giro-utils/verification/` tiene 4 de 8 archivos de auto-verificación de
  equivalencia (`equivalence-S01/S04/S05/S07.json`) marcados `FAIL`, pero son **snapshots
  anteriores** (mtimes 02:53–03:07 UTC del 2026-09-02) al commit `db8e6f4` (04:02:51 UTC) que
  corrigió exactamente esos defectos (truncado SP-013, scope transaccional SP-005/RES-010,
  NPE-guard en `revertirCupoSiCorresponde`). Se verificó por grep directo sobre el código actual que
  **las 3 correcciones están presentes y activas** (`SpPagoGiroParamsTruncator` invocado en
  `ejecutar()`; `transaccionScopePort.abrirTransaccion()/confirmar()/cerrarSiActiva()` en
  `ejecutarInsercion/Actualizacion/Eliminacion/VerificacionAcreditacion`; null-guard en
  `revertirCupoSiCorresponde` línea 357). Recomendación: regenerar esos 4 JSON para que el rastro de
  auditoría de la librería quede consistente (no bloqueante).
- `AcreditarAhoUseCase` (dependencia externa `cpas-fw-bb-core-cta`) solo disponible como bytecode,
  sin fuentes — su semántica exacta de propagación de error para TC029 no pudo confirmarse por
  código, solo por inferencia.

**20. Hallazgos QA**
- TC019 y TC026: texto "pendiente de re-verificacion" desactualizado; la corrida definitiva 1948 ya
  los confirma PASS (punto 4).
- Sin otros hallazgos sobre el insumo — 30/30 íntegro.

**21. Hallazgos ambiente**
- OCP: confirmado por config-as-code (Helm charts en
  `int-infra-integracion-ecgiros/openshift/bb-core/ecu-mso-pago-giro/develop-dvp`) que
  `route.yaml`/`route-grpc.yaml`/`service.yaml`/`values.yaml` coinciden **exactamente** con lo
  informado por Migración: host REST
  `ecu-mso-pago-giro-bb-dev-core.apps.ocpbbdevqantx.desabbol.fin.ec`, targetPort `8443-tcp`, TLS
  passthrough; host gRPC `ecu-mso-pago-giro-grpc-bb-dev-core...`, targetPort `grpc-9090`, TLS
  passthrough; namespace `bb-dev-core`. Clasificación: `HECHO_CONFIRMADO` (config estática, no se
  consultó el clúster en vivo).
- Seguridad: PAT de GitHub embebido en el remote `origin` del repo `ecu-mso-pago-giro`
  (`.git/config`). Se recomienda rotarlo; no se reproduce el valor en este documento.

**22. Preguntas Banco realmente necesarias**
Ninguna. No se identificó ambigüedad funcional que documento+SP+Java+contrato+evidencia no puedan
resolver. `REQUIERE_BANCO_ANTES_DE_MATRIZ` se mantiene en `NO`.

**23. Bloqueos restantes**
Ninguno técnico. Solo las correcciones cosméticas de los puntos 4/19/20 (no bloqueantes) y la nota de
seguridad del punto 21.

---

```
LEGACY_REUTILIZABLE = SI
JAVA_MICRO_LISTO = SI
JAVA_LIBRERIA_LISTA = SI
REST_LISTO = SI
GRPC_LISTO = SI
PROTO_PRODUCTIVO_LOCALIZADO = SI
REQUIERE_BANCO = NO

MATRIZ_PUEDE_INICIAR = SI

SIGUIENTE_ACCION = EJECUTAR_MATRIZ_EQUIVALENCIA_NCBE_1804
```

No se ejecutó la Matriz ni los 30 TCs contra el micro. No se hizo commit ni push de artefactos de
trabajo (solo de este documento de auditoría, a pedido explícito).

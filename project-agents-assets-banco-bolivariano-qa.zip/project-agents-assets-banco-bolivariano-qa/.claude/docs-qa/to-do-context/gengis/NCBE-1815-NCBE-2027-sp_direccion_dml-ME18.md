# Aprendizaje personal piloto gengis-me — ME #18: sp_direccion_dml (NCBE-1815 → NCBE-2027)

Fecha de esta ronda: 2026-11-01. Decimoctava entrega (primera de 3 de este turno). No se hicieron
consultas a Sybase/REST/gRPC, no se reejecutó nada, no se modificó Jira/QMetry/motor/repos/ME.

## 1. Identidad y relación de tickets

| Ticket | Tipo | Rol | Título |
| --- | --- | --- | --- |
| NCBE-1815 | Story | Padre | Gestionar el mantenimiento de direcciones de clientes |
| NCBE-2021/2022/2023/2024 | Task | Pipeline (relates to) | Análisis/Creación/Consolidación/Generación de datos |
| **NCBE-2027** | Task | **HU de esta ronda** | **Revisión de matriz de equivalencia — cobis.sp_direccion_dml** |
| NCBE-2873 | Task | Pipeline (relates to) | Pruebas de rendimiento — en estado "Construcción", fuera de alcance |

SP: `cobis.sp_direccion_dml`. Micro: `ccal-mso-direccion-dml`. 77 TCs. Confirmado por el último de
6 JSON adjuntos a NCBE-2027 (07-oct, 2082401 bytes): **77/77 EQUIVALENTE**.

## 2. Bugs enlazados directamente al padre — reconstrucción y clasificación

16 `Defecto`. El hallazgo dominante de esta ronda es metodológico, no de código.

### A. Seis tickets, un solo root cause: reutilizar un fixture ya consumido entre canales (NCBE-2701, 2702, 2703, 2711, 2712, 2713, 2714) → **NO ES QA real — confirma P04 a gran escala**

- TC56/67-72 (eliminación de dirección/teléfono): todos reportaban que, tras el SP eliminar
  correctamente el registro (`return_code=0`), REST y gRPC respondían `"No existe dato solicitado"`.
- **Causa confirmada en cada uno:** el revisor probaba los 3 canales **secuencialmente sobre el
  mismo registro**, sin recrearlo entre canal y canal — el SP lo eliminaba primero, y REST/gRPC se
  probaban después sobre un registro que ya no existía. Confirmado explícitamente: *"para solucionarlo
  en sus pruebas manuales, deben volver a crear la dirección... antes de probar cada canal por
  separado, en lugar de reutilizar el mismo registro ya eliminado."*
- **7 tickets con el mismo síntoma, la misma causa, cerrados el mismo día (17-sep) tras explicar el
  ciclo PRE/POST correcto** — es la confirmación más grande y limpia de la serie del patrón P04
  (ciclo de preparación con ownership) de `BB_MINERIA_COMPARATIVA_9_ME`.

### B. NCBE-2700 — error de columna en precondición propia de QA → **NO ES QA (error de la herramienta)**

- `di_canton` no existe en `cobis..cl_canton_ciudad` (prefijo real `cc_`); corregido a `cc_canton`.

### C. NCBE-2715 — dos hallazgos distintos en un mismo ticket

- **o_direccion:** mismo patrón que el grupo A — valor de secuencia auto-asignada que depende del
  estado de datos; al no limpiar entre canales, cada uno calculó un slot distinto. No es defecto.
- **`cuentasNotificacion` (DICCIONARIO, hallazgo nuevo):** gRPC/protobuf **no tiene representación
  de `null` para campos de tipo lista/`repeated`** — una lista vacía siempre serializa como `[]`,
  nunca como `null`; REST/JSON sí puede mostrar `null` explícito. Además, este campo no es un
  OUTPUT del SP, lo agrega el propio microservicio — no hay comportamiento legado de Sybase contra
  el cual homologarlo. **Regla reusable:** no esperar que un campo de tipo lista tenga una
  representación "null" equivalente entre REST y gRPC — en gRPC, "ausente" y "vacío" son lo mismo.

### D. NCBE-2922 — investigado leyendo el código real del SP, sin acción necesaria

- El SP repite `o_direccion` en un segundo resultset al final (líneas 848-849: `select @o_direccion`),
  pero es el MISMO valor ya calculado antes (líneas 641-653) y ya expuesto como OUTPUT — no hay dato
  nuevo. Confirmado por correo del equipo de desarrollo del SP; cerrado sin cambios.

### E. NCBE-2923 — contrato fijo de API vs resultset condicional del SP, ambos correctos

- El SP solo genera el resultset de notificación cuando la lógica de negocio lo requiere (ej.
  `i_envio_notifica='S'`); el microservicio, en cambio, **siempre** serializa `notificacion`/
  `cuentasNotificacion` en su contrato (con `null`/`[]` cuando el SP no los genera). Conclusión
  explícita: *"ambos comportamientos son correctos y esperados en sus respectivos contextos."*

### F. NCBE-3307 — defecto real de código, corregido

- El campo `notificacion.canal` en la respuesta no correspondía a ninguna columna del `SELECT` de
  notificación del SP — defecto confirmado y corregido en el micro.

### G. NCBE-3348 — `mensaje_debug_raw: null` en los 77 TCs → **confirma PR29 con reconocimiento explícito del autor**

- *"error mío, es una variable que utiliza el motor de pruebas, no debería estar en la entrega de
  la ME, ya se eliminó"* — Juan Pablo Sanabria. Instancia adicional (ya la quinta+ en la serie) del
  patrón de datos internos de la propia herramienta filtrándose a la evidencia publicada.

### H. NCBE-3842 — enmascaramiento del nombre del SP al 50% → **NO ES QA (confirma familia de seguridad ya vista 3+ veces)**

### I. NCBE-3854/3859 — error de compilación en Windows → **NO ES QA, 2 causas distintas en la misma familia**

- 3854: el mismo defecto cross-platform `GrpcTlsConfig` ya visto muchas veces en la serie (9 de 10
  fallos corregidos); 1 prueba (`DireccionDmlContextLoadsTest.contextLoads`) quedó sin diagnosticar
  por falta de logs completos del reportante externo.
- 3859 ("Continuación"): causa distinta — una dependencia transitoria (`tomcat-jdbc`, vía
  `bolivariano-commons`) cuya versión quedó fijada explícitamente en vez de depender de la
  resolución automática de Maven, más limpieza de caché local recomendada. Resuelto.

## 3. Hallazgo principal de los bugs del padre

El 44% de los Defecto de este padre (7 de 16) comparten exactamente la misma causa raíz
metodológica: no restaurar/recrear el fixture entre canales. Es el ejemplo más grande y limpio de
toda la serie de por qué el ciclo PRE/POST por canal no es opcional — reutilizar un registro ya
consumido por el canal anterior produce un falso defecto indistinguible, a simple vista, de una
divergencia real.

## 4. Contraste con la ME final (NCBE-2027)

- **Universo:** 77 TCs, **77/77 EQUIVALENTE**, confirmado en el último de 6 JSON (07-oct).
- A diferencia de ME #16/#17, aquí no se detectó ningún artefacto con fecha posterior al cierre sin
  reflejar en la ME — los 16 Defecto fueron resueltos y la ME se regeneró en consecuencia dentro de
  la misma ventana (31-ago a 08-oct).

## 5. Patrones de esta ronda

No se proponen patrones nuevos de fondo — refuerza 2 ya catalogados y aporta un detalle reusable:

- **Confirma P04 de BB_MINERIA a la mayor escala vista en la serie** (7 tickets, un solo root
  cause): no recrear el fixture entre canales produce falsos defectos sistemáticos.
- **Confirma PR29** (NCBE-3348, con reconocimiento explícito del autor).
- **Detalle reusable nuevo (sin ascender a patrón propio):** los campos de tipo lista/`repeated`
  en gRPC no tienen equivalente de `null` — solo vacío (`[]`) — no comparar esto como divergencia
  frente a un `null` explícito de REST.

## 6. Lo que no se pudo verificar / queda pendiente

- `DireccionDmlContextLoadsTest.contextLoads` (NCBE-3854) quedó sin diagnóstico definitivo por
  falta de logs — no se confirma si NCBE-3859 lo resolvió como efecto colateral o si sigue latente.
- No se inspeccionaron en detalle los 6 JSON intermedios más allá de lo citado en comentarios.

## 7. Checkpoint personal — procedencia

- **Fuentes Jira consultadas:** NCBE-1815 (campos + 25 subtareas + 6 issuelinks); NCBE-2027
  (campos + 10 adjuntos); los 16 Defecto (campos + comentarios completos).
- **Verificación:** último adjunto JSON de NCBE-2027 descargado temporalmente a `/tmp` (nunca al
  repo), veredictos verificados (77/77 EQUIVALENTE). Borrado tras el uso.
- **No se tocó:** Jira (solo lectura), QMetry, repos de microservicio, la ME entregada, ni el motor
  QA central. No se hicieron consultas a Sybase/REST/gRPC ni reejecuciones.
- Esta es la **ME #18** de la serie (1 de 3 de este turno). Ver índice
  `APRENDIZAJE-PERSONAL-GENGIS-ME-INDICE.md`.

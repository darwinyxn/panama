# NCBE-1804 — cob_giros.sp_pago_giro — HANDOFF / TO-DO CONTEXT

> Documento de traspaso. Lado legacy/QA CERRADO desde 2026-09-01. Java/REST/gRPC/proto quedaron
> LISTOS (auditoría 2026-09-04, ver `NCBE-1804-AUDITORIA-REANUDACION-04-09-2026.md` en esta misma
> carpeta). Pausado de nuevo desde 2026-09-07/08 por concurrencia de fixtures QA compartidos —
> ver "Checkpoint 2026-09-08" más abajo, que es el estado vigente. NO seguir las secciones
> anteriores de este documento como plan de acción; quedan como histórico del cierre legacy.

## Contexto

**MICRO**
- HU: NCBE-1804
- Nombre: `ecu-mso-pago-giro`
- SP legacy: `cob_giros.sp_pago_giro`
- Repo: https://github.com/bb-ecuagiros/ecu-mso-pago-giro.git
- Project OCP esperado: `bb-dev-core`
- Estado informado por Migración: desarrollo todavía en ajustes / aún no disponible para iniciar Matriz de Equivalencia.

**LIBRERÍA**
- HU: NCBE-1798
- SP: `cob_giros.sp_pago_giro`
- Repo: https://github.com/bb-artifacts-registry-core/bb-core-cob-giros-utils.git

**INSUMO QA**
- `.claude/docs-qa/inputs/documents/sp_pago_giro/test-cases-banco/casos_prueba_sp_pago_giro.md`
- 30/30 TCs, `TC001`–`TC030`, `TCO-CON-001`–`TCO-CON-030`

## Estado de cierre legacy

```
VEREDICTO_LEGACY_NCBE_1804 = CERRADO

LEGACY_FUNCIONAL_30_30_VERIFICADO = SI
TEARDOWNS_DOCUMENTALES_VERIFICADOS = SI
BASELINE_FINAL_LIMPIO = SI
REQUIERE_BANCO_ANTES_DE_MATRIZ = NO
INSUMO_LEGACY_CERRADO = SI

MATRIZ_EQUIVALENCIA = PENDIENTE_SOLO_DE_JAVA
```

La ausencia actual de Java **no** es una incidencia funcional ni un bloqueo Banco. Es una dependencia temporal de construcción/migración.

## Correcciones QA ya incorporadas al documento vigente

- **TC015**: PRE/efecto/teardown de cupo corregidos con evidencia real. `ga_cupo='S'`. Efecto confirmado `10000/10000 → 9960/9960` para monto 40.00. Teardown vuelve a baseline `10000/0`. Teardown explícito de campos modificados de G3.
- **TC016**: INSERT `secuencial=9` duplicado reducido a uno. Teardown explícito de `cg_pago` temporal y restauración de `cg_giro`.
- **TC019**: rediseñado (secuencial=8 aislado) para probar correctamente opcionales NULL sin caer accidentalmente en la rama anulativa.
- **TC021**: corregido teardown de G1. Baseline persistido confirmado: `gp_fecha_pago='2026-01-30 00:00:00'`, `gp_direccion_entrega='5015016727'`. **Importante:** `@i_fecha_pago='2026-01-30 10:00:00'` sigue siendo INPUT del TC y no debe confundirse con el baseline persistido.
- **TC026**: preservada la intención de "servicio distinto de C" usando cuenta válida, evitando el falso solapamiento con TC027.
- **TC029**: monto corregido a `-1.00`. `SQLException` observable conservada separada del `RETURN 141011` interno.
- **TC015/TC017/TC018**: teardowns explícitos de los campos realmente modificados en G3 (`gp_fecha_pago`, `gp_tipo_cta`, `gp_num_cuenta`, `gp_direccion_entrega`).
- **TC023/TC024/TC025**: teardowns explícitos de `gp_fecha_pago` en G1/G2.

## Comportamiento legacy importante (TC029)

La ejecución real contra Sybase confirmó:
- `sp_ahndc_automatica` produce error funcional.
- Observable por cliente: `java.sql.SQLException`.
- Código interno legacy: `141011`.
- Después del error: `@@trancount = 1`.
- `sp_pago_giro` **no** ejecuta rollback explícito en esa ruta.
- El harness ejecuta `ROLLBACK TRAN` únicamente como medida de seguridad/cleanup (no es comportamiento del SP).
- Después del cleanup: `@@trancount = 0`.

Clasificación: `COMPORTAMIENTO_LEGACY_CONFIRMADO`. No implica por sí mismo `REQUIERE_BANCO`. Cuando exista Java, debe compararse contra su semántica transaccional y su traducción de error.

## Evidencia principal

**Evidencia funcional definitiva:**

1. `RUN_ID: LEGACY-NCBE1804-01-09-2026-1948`
   Ruta: `.claude/docs-qa/results/sp_pago_giro-01-09-2026-1948-LEGACYRUN/`
   Resultado: PASS 30/30, FAIL 0, BLOCKED 0, baseline final == golden.

2. `RUN_ID: VALIDACION-TEARDOWN-NCBE1804-01-09-2026-2008`
   Ruta: `.claude/docs-qa/results/sp_pago_giro-01-09-2026-2008-VALIDACION-TEARDOWN/`
   Resultado: PASS 7/7, FAIL 0, BLOCKED 0, teardowns documentales verificados, baseline final limpio.

**Corridas diagnósticas/históricas (NO evidencia final):**

- `sp_pago_giro-01-09-2026-1833-LEGACYRUN` — bloqueada por lock ajeno en `cg_pago` antes de TC001.
- `sp_pago_giro-01-09-2026-1906-LEGACYRUN` — detenida por baseline dirty detectado en TC021.
- `sp_pago_giro-01-09-2026-1942-LEGACYRUN` — 29/30 por un literal viejo hardcodeado en el script de ejecución (no un problema de ambiente).

No confundir estas tres con las dos corridas definitivas.

## Hallazgo tooling (nota pendiente independiente)

`sybase_tsql_wrapper.py::_parse_tsql_output_multi` puede descartar filas cuando la última columna viene vacía/espacio, debido al tratamiento del delimitador tras `.strip()`. **No fue corregido** dentro de NCBE-1804. No convertir este hallazgo en bloqueo del caso: las evidencias críticas se contrastaron contra salida raw/directa de Sybase.

## Banco

```
REQUIERE_BANCO_ANTES_DE_MATRIZ = NO
```

No hay pregunta funcional pendiente actualmente. Los comportamientos extraños del legacy quedaron resueltos mediante documento + código SP + Sybase real + evidencia.

## Estado Java

**MICRO `ecu-mso-pago-giro`:** en la última verificación disponible, repositorio existente; refs remotas consultadas apuntaban al Initial commit; sin código Java utilizable para matriz. Migración confirmó externamente que todavía están haciendo ajustes y que el micro aún no está disponible.

**LIBRERÍA `bb-core-cob-giros-utils`:** checkout disponible solo con README/Initial commit en la última revisión; estado remoto completo quedó no determinable por permisos; reevaluar cuando Migración confirme disponibilidad.

No seguir haciendo discovery periódico mientras Migración no confirme que terminó.

## Punto exacto de reanudación

Cuando Gengis confirme que el micro/librería Java ya están disponibles, **no repetir la auditoría legacy completa**. Retomar desde:

1. Verificar HEAD/repos Java actuales.
2. Inspeccionar implementación real de `ecu-mso-pago-giro` y `bb-core-cob-giros-utils`.
3. Mapear SP legacy → librería → micro.
4. Identificar DTO/request/response, validaciones, null/defaults, errores y transacciones.
5. Identificar equivalentes Java de:
   - `sp_cta_vigente`
   - `sp_ccndc_automatica`
   - `sp_ctah_vigente`
   - `sp_ahndc_automatica`
6. Determinar REST/gRPC real.
7. Ubicar proto productivo si aplica.
8. Ejecutar el flujo vigente de Matriz de Equivalencia sobre los 30 TCs ya cerrados.

Solo reabrir el lado legacy si la comparación Java descubre una contradicción concreta que lo justifique.

## Estado para reanudar (HISTÓRICO — superado por el checkpoint de abajo)

```
ESTADO_NCBE_1804 = PAUSADO_ESPERANDO_JAVA

LEGACY = CERRADO
QA_TCS = 30_30_VERIFICADOS
BASELINE = LIMPIO
REQUIERE_BANCO = NO

SIGUIENTE_GATE = JAVA_DISPONIBLE_PARA_MATRIZ
SIGUIENTE_ACCION = AUDITORIA_JAVA_Y_MATRIZ_EQUIVALENCIA
```

## Checkpoint 2026-09-08 — PAUSADO POR CONCURRENCIA DE FIXTURES QA (estado vigente)

Desde que Java quedó disponible (auditoría 2026-09-04) se completaron, en orden: auditoría
Java/librería/REST/gRPC/proto (LISTOS), gate de trazabilidad de versión (source↔deployment
ALINEADO), gate de seguridad pre-Matriz (restauración G1/G2/G3, modo `stored` en el tooling,
discovery de reversión oficial para TC023/24/26), y un probe empírico de reversión que detectó
concurrencia real sobre los fixtures y forzó este STOP. Detalle completo de cada gate en el
historial de conversación de esa sesión (no duplicado aquí).

```
VEREDICTO_FORENSE_AMBIENTE_NCBE_1804 = REQUIERE_COORDINACION_QA

MOVIMIENTO_390 = LOCALIZADO
MOVIMIENTO_390_TABLA = cob_cuentas..cc_tran_monet
DRIFT_PROVENANCE = OTRA_PRUEBA_QA_CONFIRMADA
FIXTURE_EXCLUSIVITY = COMPARTIDO_CONFIRMADO

LEGACY = CERRADO_30_30
STORED_LEGACY_MODE = LISTO
JAVA = LISTO
REST = LISTO
GRPC = LISTO
PROTO = LISTO

REVERSAL_CORRIENTE = t_corr='S' / OFICIAL_CONFIRMADO
REVERSAL_AHORROS   = t_corr='S' / OFICIAL_CONFIRMADO

BASELINE_G1 = REQUIERE_REVALIDACION_AL_REANUDAR
BASELINE_G2 = LIMPIO
BASELINE_G3 = LIMPIO

AMBIENTE_APTO_PARA_MATRIZ = NO
REQUIERE_BANCO = NO

BLOQUEO_ACTUAL = FIXTURES_COMPARTIDOS_SIN_VENTANA_EXCLUSIVA
```

**Nota importante — no hay golden económico absoluto para la cuenta `5015016727`:** el saldo lleva
acumulando créditos QA sin reversar desde antes del cierre legacy (mínimo desde 2026-08-27), todos
con `tm_correccion='N'`. No definir un golden absoluto para esa cuenta. Al reanudar, usar como
baseline económico el estado PRE capturado inmediatamente antes de cada canal (REST/gRPC) y exigir
retorno exacto a ese PRE después de la reversión oficial (`t_corr='S'`) — no un valor histórico.

**Nota tooling — camino corriente (`t_trn=3048`):** el movimiento relevante para `sp_ccndc_automatica`
queda registrado en `cob_cuentas..cc_tran_monet` (columnas `tm_correccion`/`tm_sec_correccion`
alimentadas con `@t_corr`/`@t_ssn_corr` reales), **no** en `cc_tran_servicio` (esa tabla solo recibe
INSERT para `@t_trn=3750`, un escenario distinto). No repetir la búsqueda en `cc_tran_servicio`.

### Punto exacto de reanudación

1. Confirmar que terminó la actividad concurrente o que existe ventana/pool exclusivo (ver sesiones
   activas relevantes al momento de la pausa: `isolate-cte-account-parallel-batches`,
   `problema-verificacion-acredita`, `problema ccal-mso-direccion-dml`).
2. Revalidar read-only G1/G2/G3 y cuentas `5015016727`/`0011243553` (no reutilizar snapshots viejos
   ciegamente).
3. Restaurar únicamente el drift de `cg_pago` atribuible a QA si todavía existe (mismo patrón usado
   para G2/G3: lock-check → SELECT raw → confirmar procedencia → UPDATE acotado → verificar).
4. Ejecutar probe controlado por REST: TC023 (`t_corr='N'` → validar → `t_corr='S'` → validar retorno
   exacto al PRE) y TC024 (mismo patrón, cuenta `0011243553`).
5. Si ambos PASS, TC026 reutiliza la estrategia de reversión corriente ya demostrada por TC023 (no
   requiere un tercer probe separado).
6. Si los probes PASS: ejecutar agente-05 / Matriz completa NCBE-1804 30/30, usando
   `LEGACY_SOURCE=STORED_CANONICAL_EVIDENCE` (`LEGACY-NCBE1804-01-09-2026-1948`, sin reejecutar SP
   legacy) y solo canales REST/gRPC en vivo.

```
ESTADO_NCBE_1804 = PAUSADO_POR_CONCURRENCIA_FIXTURES
SIGUIENTE_GATE = VENTANA_EXCLUSIVA_FIXTURES
```

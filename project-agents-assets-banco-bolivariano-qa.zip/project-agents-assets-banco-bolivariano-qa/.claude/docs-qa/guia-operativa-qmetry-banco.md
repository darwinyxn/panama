# Guía operativa QMetry — Banco Bolivariano (reusable para cualquier SP/HU)

Flujo canónico para publicar y refrescar evidencia QA en QMetry sobre el Test Cycle proveedor de una HU/SP. Aplica a cualquier `sp_*` / HU; **no** contiene datos de un caso concreto — todo se parametriza por `qmetry_config.json` (ver `inputs/documents/qmetry_config.example.json`) o por CLI.

## Principios (regla de Banco)

1. **Un Test Cycle por HU/SP/funcionalidad.** No se crea un cycle nuevo por cada JSON/corrida. El cycle "canónico" (proveedor) representa la funcionalidad y persiste entre corridas.
2. **TCs nuevos se agregan al mismo cycle canónico.** Si una corrida trae casos nuevos, se crean como Test Case, se linkean a la HU y se añaden al cycle existente.
3. **Correcciones o refresco de evidencia = New Execution.** Si un TC cambió/se corrigió, o QA pide refrescar la evidencia, se crea una **nueva ejecución** de ese TC dentro del mismo cycle. La(s) ejecución(es) anterior(es) quedan como histórico.
4. **Si un TC no cambió, no se toca** su ejecución ni su evidencia (salvo refresco total explícito).
5. **No usar refresh/sync** sobre ejecuciones viejas salvo autorización explícita.
6. **Los bugs los gestiona Banco** desde su cycle/HU. Los scripts NO crean/cierran/vinculan bugs.
7. **Cycles externos/Banco están fuera de alcance operativo.** No se tocan, no se mutan, no se diagnostican como error propio. Se registran en `forbiddenCycleIds` para que los scripts aborten si se los apunta por error.

## Conceptos clave

- **Conteo general de Test Cases ≠ conteo del Test Cycle.** El módulo general de Test Cases cuenta por folder/proyecto e incluye TCs que pueden pertenecer a otros cycles. Para validar el cierre, contar **por cycle** (`testCycleId`), no por folder.
- **`cloneFrom` copia los attachments históricos** a la nueva ejecución. Para evidencia limpia (1 solo TXT nuevo por ejecución), usar **Start Execution SIN `cloneFrom`**. Usar `cloneFrom` solo si se quiere arrastrar la evidencia previa.
- **La evidencia (TXT) va en la ejecución**, no en el Test Case base. Cada nueva ejecución recibe su propio TXT.
- **La respuesta de Start Execution es 204 (sin body)**: el nuevo `testCaseExecutionId` se detecta comparando las ejecuciones del `testCycleTestCaseMapId` antes/después.
- **Indexación de attachments es asíncrona** (S3): tras subir, verificar con reintentos/backoff.
- **Anti-ráfaga (409)**: en lotes usar `--batch-size 1`, `--sleep-between-posts >= 15`, `--verify-after-each`.

## Tooling (scripts parametrizados)

Todos leen valores de `--config <qmetry_config.json>` o CLI (CLI gana). Requieren `QMETRY_BASE_URL` y `QMETRY_API_KEY` en entorno. Dry-run por defecto; mutan solo con `--execute`.

| Script | Rol |
|---|---|
| `qmetry_context.py` | Helper: carga config, resuelve CLI>config, guard genérico de cycle, env/headers. |
| `execution_discovery.py` | READ-ONLY: mapea los TCs del cycle (key, mapId, execId, result, attachment). |
| `execution_checker.py` | READ-ONLY: distribución de resultados + detección de cycle duplicado. |
| `cycle_requirement_linker.py` | Relaciona el cycle con la HU/requirement. |
| `evidence_builder.py` | LOCAL, sin LLM: genera 1 TXT determinístico por TC desde el JSON parseado. |
| `evidence_uploader.py` | Sube TXT a la ejecución (soporta subir a la nueva ejecución de MODIFICADO). |
| `execution_updater.py` | Marca ejecuciones como Pass. |
| `new_execution_starter.py` | Start Execution (nueva ejecución) de TCs MODIFICADO dentro del cycle. |
| `step_updater.py` | Actualiza los test steps de TCs existentes (`PUT .../teststeps`); `sender.py` en ACTUALIZAR no los toca. |
| `reexec_all_runner.py` | Re-ejecución total (refresco): Start Execution SIN cloneFrom + Pass + TXT, con checkpoint. |

## Guards de seguridad (genéricos)

- `canonicalCycleId` (o `--expected-cycle-id`): **requerido**. Los scripts abortan si `--cycle-id` no coincide, salvo `--i-know-what-im-doing`.
- `forbiddenCycleIds` (o `--forbidden-cycle-id`): lista de cycles externos/Banco; abortan si se los apunta.
- Sin valores obligatorios → **abortan con mensaje claro** (no hay defaults peligrosos).
- **Post-hardening QMT-21/22/23** (`cycle_requirement_linker.py`, `linker.py`, `issue_linker.py`,
  `traceability_checker.py`): fail-closed completo — verificación posterior a cada POST 2xx
  SIEMPRE obligatoria (`acceptedByHttp` != `verifiedLinked`), `--batch-size 1` obligatorio en
  `--execute`, cero candidatos nunca es éxito, identidad Requirement validada con AND
  (id+key), universo canónico explícito exigido en el checker de trazabilidad. Ver
  `INSTRUCTIVO_QMETRY_PIPELINE.md` para el contrato CLI vigente de cada script.
- **Identidad exacta de ejecución (`execution_updater.py`/`evidence_uploader.py`)**: `--plan-file`
  es obligatorio a nivel CLI (argparse) para cualquier invocación, dry-run o `--execute`. El TC
  objetivo de cada candidato debe aparecer **exactamente una vez** en `tabla_por_caso` — ausente
  o duplicado bloquea antes de cualquier red; "ausente del plan" nunca se interpreta como "no
  requiere nueva ejecución". Si el plan clasifica ese TC como MODIFICADO,
  `--execution-start-result-file` con identidad `START_VERIFIED`+`newExecutionId` pasa a ser
  obligatorio y debe coincidir en `testCycleTestCaseMapId` con el plan — ausencia, `state`
  distinto, o discrepancia bloquean antes de mutar/subir. TCs con otra clasificación siguen
  resolviendo por `execution_discovery.py` sin cambios, salvo el backstop: si
  `execution_discovery.py` reporta `observedExecutionsCount` > 1 para ese TC sin identidad
  verificada, también bloquea (nunca elige una ejecución arbitrariamente).
- **Universo del plan vs universo funcional (`evidence_builder.py`, modo incremental, y
  `new_execution_starter.py`)**: un id_local que el plan clasifica como candidato accionable
  (MODIFICADO en `new_execution_starter.py`; NUEVO/MODIFICADO o la clase pedida via
  `--incremental-class` en `evidence_builder.py`) debe existir en `--parsed`
  (QA-CASOS-PARSEADOS) — ausente, duplicado en el plan, id duplicado en `--parsed`, o (solo en
  `evidence_builder.py`) con `qmetry_key_anterior` que discrepa de la key real ya resuelta por
  `--sender-result-file`, bloquean ANTES de cualquier red (en `new_execution_starter.py`, antes
  del primer POST de Start Execution — nunca se crea una ejecución nueva sobre un candidato que
  el universo real no demuestra) en vez de generar un universo parcial silenciosamente.
  `--parsed` puede tener id_local adicionales aún no clasificados por ese plan (no bloquea); el
  plan puede omitir filas SIN_CAMBIO/ELIMINADO (subconjunto válido) — solo se exige cobertura
  para lo que el plan mismo declara accionable. `--parsed` es obligatorio (argparse) en ambos
  scripts.
- **Identidad de attachment preexistente y confinamiento local (`evidence_uploader.py`)**: un
  attachment preexistente (`total==1`) solo se acepta como `ALREADY_UPLOADED_VERIFIED` si el
  único item de `data[]` confirma `name`+`size` iguales al TXT local esperado (forma
  documentada en el OpenAPI local revisado por Gengis, no confirmada en vivo contra esta
  instancia) — si no coincide, o si `data[]` no expone esos campos, bloquea como
  `AMBIGUOUS_ATTACHMENT_MATCH` en vez de asumir verificado por el conteo solo. `--evidence-dir`
  es obligatorio (argparse): todo `path` del manifest debe quedar confinado (realpath) dentro
  de ese directorio — traversal `../`, path absoluto externo o symlink que resuelva afuera
  bloquean (`BLOCKED_PATH_NOT_CONFINED`) antes de leer/subir el archivo.

## Flujo por corrida (resumen)

1. **Config**: crear `inputs/documents/<sp>/qmetry_config.json` desde el example, con los IDs reales del caso (proyecto, HU, requirement, cycle canónico, environment, passResultId, forbidden).
2. **Descubrir/clasificar** (READ-ONLY): comparar el nuevo JSON contra el estado del cycle → SIN_CAMBIO / NUEVO / MODIFICADO / ELIMINADO.
3. **Smoke primero, nunca masivo a ciegas**: validar el flujo con 1 caso NUEVO y 1 MODIFICADO antes de procesar el universo.
4. **NUEVO**: `sender` (crear TC) → `cycle_requirement_linker`/`issue_linker` (HU) → agregar al cycle → `execution_updater --plan-file <qmetry_incremental_scope_plan.json>` (Pass) → `evidence_uploader --plan-file <mismo plan>` (TXT). `--plan-file` es obligatorio (argparse) en ambos aunque el TC este clasificado NUEVO/SIN_CAMBIO — el TC debe aparecer exactamente una vez ahi.
5. **MODIFICADO**: `new_execution_starter --plan-file <qmetry_incremental_scope_plan.json> --parsed <QA-CASOS-PARSEADOS.json>` (Start Execution, sin cloneFrom si se quiere evidencia limpia; produce `qmetry_new_execution_starter_result.json`) → `execution_updater --plan-file <mismo plan> --execution-start-result-file <resultado del paso anterior>` → `evidence_uploader` con esos mismos dos flags. `--plan-file` es obligatorio siempre (argparse) en los tres; `--parsed` es obligatorio en `new_execution_starter.py` (bloquea antes del primer POST si el candidato MODIFICADO no existe ahí); `--execution-start-result-file` pasa a ser obligatorio para cualquier TC clasificado MODIFICADO en el plan: `execution_updater.py`/`evidence_uploader.py` bloquean antes de mutar si el TC no aparece exactamente una vez en el plan, si falta el start-result, su `state` no es `START_VERIFIED`, falta `newExecutionId`, o su `testCycleTestCaseMapId` no coincide con el del plan — nunca sustituyen esa identidad por la ejecución que resuelva `execution_discovery.py`.
5b. **Definicion del TC cambiada (ACTUALIZAR en sync_checker)**: `sender.py` actualiza summary/description/precondition y `step_updater.py` los steps (QMetry ignora `steps` en el PUT del TC). Cerrar con `sync_checker.py` en SIN_CAMBIO para todos.
6. **SIN_CAMBIO**: no tocar.
7. **Refresco total**: `reexec_all_runner` (Start Execution SIN cloneFrom para los N TCs) + `evidence_builder` con sufijo de corrida.
8. **Verificar** (READ-ONLY): conteo por cycle, todos Pass, cada nueva ejecución con su TXT, históricas conservadas, cycles externos intactos.

## Reglas de oro

- No crear nuevo Test Cycle para la misma HU/SP.
- No borrar ejecuciones ni attachments históricos.
- No tocar cycles fuera de `canonicalCycleId`.
- No gestionar bugs por script.
- Siempre dry-run → smoke → lote, con verify-after-each.
- Los reportes/JSON/TXT específicos de una corrida son artefactos operativos (viven en `results/<run>/qmetry/`), **no** parte del flujo canónico del repo.

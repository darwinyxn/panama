# Informe: Proceso de Generación de Casos de Prueba

---

# PARTE 1 — PARA CLIENTE

## 1.1 ¿Qué hacemos?

Generamos casos de prueba técnicos para cada Stored Procedure (SP) de forma **determinística y trazable**. Cada caso de prueba que producimos:

- Se deriva EXCLUSIVAMENTE del código fuente del SP
- Tiene una referencia exacta a la línea del código que valida
- No se inventa ni se supone lógica que no exista en el SP
- Se puede reproducir: el mismo SP siempre genera los mismos casos

## 1.2 ¿Cómo funciona el proceso?

El proceso tiene 2 etapas:

### Etapa 1 — Análisis automático (sin intervención humana ni IA)

Un conjunto de scripts de Python lee el archivo `.sql` del SP y extrae todo de forma mecánica:

1. **Lee el código** — Elimina comentarios, normaliza formato, identifica cada elemento
2. **Identifica qué hace el SP** — Parámetros de entrada/salida, tablas que toca (INSERT/UPDATE/DELETE), bifurcaciones (IF/ELSE), llamadas a otros SPs, códigos de retorno
3. **Genera un inventario de reglas (BRI)** — Cada hallazgo se numera y se asocia a una línea del SP
4. **Aplica técnicas de diseño de pruebas** — Partición de Equivalencia, Valores Límite, Cobertura de Ramas, Tablas de Decisión
5. **Optimiza** — Elimina casos redundantes aplicando las reglas de la estrategia de pruebas

### Etapa 2 — Enriquecimiento (con IA supervisada)

Un agente de IA lee el resultado de la Etapa 1 y SOLO agrega:

- Descripción en español de cada caso (qué se prueba en términos de negocio)
- Evaluación de criticidad del SP (D6)
- Máximo 5 casos de Suposición de Errores (Error Guessing)

El agente NO puede:
- Inventar casos que no estén en el inventario
- Eliminar casos del inventario
- Modificar datos que ya calcularon los scripts

## 1.3 ¿Qué técnicas aplicamos?

Todas las técnicas están alineadas con el estándar ISTQB y la Estrategia de Pruebas del proyecto:

| Técnica | Qué hace | Ejemplo |
|---|---|---|
| **Partición de Equivalencia (EP)** | Divide los datos de entrada en clases que el SP trata igual | Monto > 0, Monto = 0, Monto < 0 |
| **Valores Límite (BVA)** | Prueba los bordes exactos donde cambia el comportamiento | Si el SP rechaza cuando monto > saldo, probar con monto = saldo y monto = saldo + 0.01 |
| **Cobertura de Ramas** | Cada decisión IF/ELSE se ejecuta al menos por TRUE y por FALSE | IF cuenta bloqueada → probar con cuenta bloqueada y sin bloquear |
| **Tablas de Decisión** | Cuando 2+ condiciones se combinan, genera las combinaciones que producen resultados diferentes | transacción=ND AND corrección=Sí → genera las 4 combinaciones |
| **Control Transaccional** | Prueba atomicidad del SP (commit/rollback) | Verificar que el rollback revierte todos los efectos cuando hay error |
| **CASE WHEN** | Cada valor WHEN tiene su propio caso | Si CASE @tipo WHEN 'DIR' WHEN 'SAT' → 1 TC por WHEN + 1 para ELSE |
| **Suposición de Errores** | Casos propensos a fallas basados en conocimiento bancario | Doble ejecución, transacción anidada, concurrencia sobre saldo |
| **Fracción de Centavo** | OBLIGATORIA para campos monetarios | Monto/3 para verificar que el redondeo Sybase (4 decimales) es igual al de Java |
| **Parámetro obligatorio: NULL vs Omisión** | Distingue 2 escenarios diferentes que el banco señaló | Enviar el parámetro con valor NULL (valor permitido que fluye al SP hijo) ≠ omitir el parámetro de la llamada (rechazo por "no suministrado"). Son 2 pruebas distintas con resultados distintos |

## 1.4 ¿Cómo se optimizan los casos?

Del análisis bruto salen muchos casos (300-400 para un SP grande). Se reducen aplicando estas reglas:

| Regla de optimización | Qué elimina | Criterio |
|---|---|---|
| **Regla de Oro** | Casos que prueban lo mismo que otro | 1 caso = 1 objetivo único. Si 2 casos prueban exactamente lo mismo, queda 1 |
| **Partición de Equivalencia Estructural** | Valores que recorren la misma ruta | Si `@t_trn in (4253, 4229, 16637)` todos hacen lo mismo → 1 solo caso representativo |
| **BVA Mínimo** | Valores genéricos cuando hay un borde real | Si el código dice `IF @val > @saldo`, solo necesito 2 casos (borde y cruce), no 5 valores arbitrarios |
| **Redundancia por mismo resultado** | Branches que terminan en el mismo error | Si 3 condiciones diferentes producen RETURN 041001, probar 1 y los otros 2 son redundantes |
| **Branches sin efecto observable** | Bifurcaciones que solo asignan variables internas | Si un IF solo hace `select @w_flag = 1` sin DML ni RETURN, no es verificable desde fuera |

**Resultado típico:**
- SP de 1493 líneas: de 393 casos brutos → 155 casos optimizados (reducción 60%)
- SP de 377 líneas: de 80 casos brutos → 61 casos optimizados (reducción 24%)

## 1.5 ¿Cómo se evalúa la complejidad?

Cada SP se evalúa en 6 dimensiones:

| Dimensión | Qué mide | Cómo se calcula |
|---|---|---|
| D1 | Volumen de código | Líneas efectivas: <500=BAJA, 501-800=MEDIA, >800=ALTA |
| D2 | Estructuras de control | Puntos: IF=0.5, IF/ELSE=1.0, AND/OR=1.5, Cursor=3.0. Si >12 → ALTA |
| D3 | Dependencias externas | >5 tablas o ≥3 SPs hijos → ALTA |
| D4 | Comportamiento transaccional | Si tiene BEGIN TRAN multinivel → ALTA |
| D5 | Lógica financiera | Si tiene campos MONEY o cursores → escala |
| D6 | Criticidad de negocio | Evaluada por el agente: ¿afecta saldos? ¿regulatorio? ¿frecuencia? |

## 1.6 ¿Qué garantiza la trazabilidad?

Cada caso de prueba en el entregable final tiene:
- `rule_id`: identificador de la regla del inventario que cubre
- `line`: línea exacta del código fuente del SP
- `type`: técnica que lo generó (EP, BVA, Branch, DT, EG)
- `descripcion`: qué se prueba en lenguaje de negocio
- `expected_result`: resultado esperado trazado al código (ver 1.6.1)

Esto permite a cualquier persona ir al código del SP, buscar la línea, y verificar que el caso corresponde a lo que dice.

## 1.6.1 Resultado esperado — trazado al código, nunca inventado

Cada caso de prueba lleva un **resultado esperado** (`expected_result`) que indica qué debe devolver el SP. La regla de oro es: **el resultado esperado se deriva del código del SP; si el SP padre no lo determina, NO se inventa un código** — se declara de dónde proviene.

| `source` (origen del resultado) | Significado | `return_code` |
|---|---|---|
| **parent_path** | El resultado está escrito en el SP padre (RETURN, rama, DML) | Valor real + línea exacta (ej. `0`, `@o_error`, `39003`) |
| **param_dependent** | Es una prueba del valor de un parámetro; el resultado depende de cómo se use | `DEPENDS_ON_USAGE` |
| **untraceable** | El padre no valida (ej. NULL); el resultado lo decide un SP hijo | `DEPENDS_ON_CHILD` |
| **engine** | Lo decide el motor de base de datos (ej. parámetro obligatorio omitido) | `PARAM_NOT_SUPPLIED` |

**Por qué importa:** esto responde directamente a la observación del banco sobre resultados esperados con códigos de error que no correspondían al flujo. Ahora, cuando el resultado no se puede afirmar desde el SP padre, el caso lo declara explícitamente en vez de asignar un código plausible pero incorrecto. El resultado esperado se valida en dos niveles:
- **Estático:** el código declarado coincide con el texto del SP (verificable contra el `.sql`).
- **Dinámico:** el valor concreto se confirma al ejecutar el SP en la corrida QA.

## 1.7 ¿Qué NO hacemos?

- No inventamos escenarios que no estén en el código
- No suponemos comportamiento que no se pueda derivar del SP
- No agrupamos casos independientes en uno solo
- No eliminamos casos que tengan un objetivo único verificable
- No generamos casos para SPs utilitarios (sp_gen_sec, sp_gen_sec2)

---

# PARTE 2 — PARA EQUIPO QA TÉCNICO

## 2.1 Pipeline paso a paso

```bash
# Ejecución completa (1 comando)
cd .claude/docs-qa/inputs/scripts/sp_tc_gen
python3 main.py <ruta_al_sp.sql>
```

El `main.py` ejecuta 12 pasos en secuencia:

### Paso 1: Tokenizer + Extractors (`core/analyzer.py`)
- **Qué hace:** Lee el .sql, elimina comentarios, junta líneas partidas por sp_helptext (line-wrap a ~80 chars), tokeniza y ejecuta **7 extractores** independientes:
  - `parameters.py` — Parámetros IN/OUT del CREATE PROC
  - `variables.py` — DECLARE con múltiples variables
  - `dml.py` — INSERT, UPDATE, DELETE, SELECT INTO
  - `branches.py` — IF/ELSE con profundidad real
  - `sp_calls.py` — EXEC/EXECUTE
  - `returns.py` — RETURN N (valor + tipo)
  - `case_when.py` — CASE WHEN simple y searched (1 item por WHEN + ELSE)
- **Output:** `raw_analyzed.json`

### Paso 2: BRI Builder (`scorers/bri_builder.py`)
- **Qué hace:** Numera cada hallazgo como regla con ID único
  - DML-001, DML-002... | BR-001, BR-002... | RET-001... | SPC-001... | PAR-001...
  - CW-001-W01, CW-001-W02, CW-001-ELSE... (por cada CASE WHEN)
- **Criterio:** `testable: true` para DML, Branch, Return, Param, Case When. `testable: false` para SP calls.
- **Output:** `raw_bri.json`

### Paso 3: TC Raw (`generators/tc_raw.py`)
- **Qué hace:** Genera 1 TC por cada regla testable
  - DML → TC de verificación (pre/post en tabla)
  - Branch → TC TRUE + TC FALSE (si tiene ELSE)
  - Return → TC que alcanza ese RETURN
  - Param obligatorio → TC con NULL explícito (`parameter_negative`, resultado `DEPENDS_ON_CHILD`)
  - Param obligatorio → 1 TC representativo de OMISIÓN por SP (`parameter_omitted` / `PAR-OMIT-001`, resultado `PARAM_NOT_SUPPLIED`) — escenario distinto del NULL
  - Case When → TC por cada WHEN + TC para ELSE
- Cada TC generado lleva la llave `expected_result` (resultado esperado trazado, ver 1.6.1)
- **Criterio ISTQB:** Cobertura de Ramas (Branch Coverage)
- **Output:** `raw_test_cases.json`

### Paso 4: TC ISTQB (`generators/tc_istqb.py`)
- **Qué hace:** Genera TCs por tipo de dato de los parámetros
  - MONEY → positivo, cero, negativo, NULL, fracción centavo (monto/3)
  - CHAR/VARCHAR → válido, vacío, overflow, NULL
  - INT → válido, cero, NULL
  - BVA → para condiciones con comparaciones numéricas explícitas
- **Criterio ISTQB:** Partición de Equivalencia + Análisis de Valores Límite
- **Output:** `raw_istqb.json`

### Paso 5: TC Transaccional (`generators/tc_transactional.py`)
- **Qué hace:** Detecta patrones BEGIN TRAN, SAVE TRAN, COMMIT, ROLLBACK y genera TCs de atomicidad:
  - TC commit exitoso (flujo completo sin error)
  - TC rollback completo (error provoca reversión total)
  - TC rollback parcial a savepoint (1 por cada SAVE TRAN distinto)
- **Criterio:** Control transaccional — prueba que la migración Sybase→Java preserve atomicidad
- **Output:** `raw_transactional.json`

### Paso 6: Complexity Scorer (`scorers/complexity_scorer.py`)
- **Qué hace:** Calcula D1-D5 automáticamente
  - D1: LOC | D2: Puntos ponderados | D3: Dependencias | D4: Transaccionalidad | D5: Lógica financiera
- **Escalamientos automáticos:** cursor→ALTA, D2>12→ALTA, >5 tablas→ALTA, @@trancount multinivel→ALTA
- **Output:** `raw_complexity.json`

### Paso 7: Hardcoded Extractor (`optimizers/hardcoded_extractor.py`)
- **Qué hace:** Extrae valores literales: listas IN, return codes, string comparisons, error codes sp_cerror (con mensaje desde catálogo local `data/cl_errores.json`)
- **Output:** `raw_hardcoded.json`

### Paso 8: Branch-DML Linker (`optimizers/branch_dml_linker.py`)
- **Qué hace:** Conecta causa (condición IF) con efecto (DML/RETURN dentro del bloque)
- **Output:** `raw_linked.json`

### Paso 9: Decision Table (`optimizers/decision_table.py`)
- **Qué hace:** Detecta condiciones AND/OR compuestas → genera matriz combinatoria
- **Criterio ISTQB:** Tablas de Decisión
- **Output:** `raw_dt.json`

### Paso 10: Dedup Optimizer (`optimizers/dedup_optimizer.py`)
- **Qué hace:** Reduce los TCs brutos aplicando 8 reglas de optimización:
  1. **Mismo RETURN** → queda 1 representativo
  2. **Sin efecto directo** → branches que solo asignan variables
  3. **Overlap ISTQB/Branch** → no duplicar
  4. **EP Estructural** → lista IN misma ruta → 1 TC
  5. **BVA Mínimo** → solo bordes reales (2 TCs: borde + cruce)
  6. **EP Diferenciado** → valores IN con IF interno → TC individual
  7. **Excluir BVA @@rowcount** → incluye aliases (`set @var = @@rowcount`)
  8. **Excluir return duplicados** → mismo (return_code, line) → 1
- **Protección:** Fracción centavo NUNCA se elimina
- **Suma:** TCs transaccionales se agregan directamente (sin dedup)
- **Output:** `raw_optimized.json`

### Paso 11: Coverage Formula (`scorers/coverage_formula.py`)
- **Qué hace:** Calcula fórmula F1-F6 como métrica INFORMATIVA (no recorta TCs)
- **Output:** `raw_coverage.json`

### Paso 12: Consolidate (`output/consolidate.py`)
- **Qué hace:** Empaqueta todo en 2 archivos finales:
  - `<sp>.test_cases.json` — principal: analysis + complexity + hardcoded + links + test_cases (consume el agente)
  - `<sp>.raw_metadata.json` — auditoría: bri.rules + coverage + optimization + transactional info
- **Elimina intermediarios:** Los 11 archivos raw_*.json se borran
- **Output directo a:** `documents/<sp>/tc_gen/`

### Agente Enriquecedor (post-pipeline)
- **Invocación:** `/agent agente-qa-tc-enricher sp_name=<sp>`
- **Input:** `<sp>.test_cases.json` + `<sp>.raw_metadata.json`
- **Qué hace:**
  - Agrega `descripcion` en español a cada TC
  - Evalúa D6 (criticidad negocio)
  - Agrega máximo 5 TCs de Error Guessing (justificados)
  - Calcula cobertura directa
  - **Sobrescribe** `<sp>.test_cases.json` in-place (mismo archivo, mismo lugar)
- **Qué NO hace:** No deduplica, no combina, no elimina, no inventa reglas, no renombra archivos
- **Output:** `<sp>.test_cases.json` (ENTREGABLE FINAL, mismo archivo enriquecido)

## 2.2 Reglas de descarte — detalle técnico

| # | Regla | Implementación | Cantidad descartada (sp_ahndc) |
|---|---|---|---|
| 1 | Branches que llevan al mismo RETURN | `group_branches_by_return()` agrupa por return code. Si >1 branch lleva al mismo → el primero queda, el resto se marca `exclusion_reason: redundant_same_return` | 38 |
| 2 | Branches sin efecto directo | `identify_no_effect_branches()` cruza con `linked.dml_links` y `linked.return_links`. Si un branch no aparece en ninguno → `exclusion_reason: no_direct_effect` | 102 |
| 3 | Overlap ISTQB que ya cubre branch | `merge_istqb_with_branches()` busca si el param de un TC ISTQB aparece en la condición de un branch → `exclusion_reason: already_covers_branch` | 113 |
| 4 | EP structural reemplaza genéricos | `apply_ep_structural()` busca listas IN en hardcoded. Si >1 valor → genera 1 TC representativo y excluye los ISTQB de esa variable → `exclusion_reason: replaced_by_ep_structural` | 2 |
| 5 | BVA mínimo reemplaza genéricos | `apply_bva_minimal()` detecta comparaciones numéricas en branches. Genera 2 TCs (borde+cruce) y excluye BVA genéricos del param → `exclusion_reason: replaced_by_bva_minimal` | 0 |

**Protección fracción centavo:** En el paso de exclusión ISTQB, cualquier TC con `particion == "fraccion_centavo_obligatoria"` se marca como `protected: true` y NUNCA se elimina.

## 2.3 Fórmula de cobertura — cálculo real

Para `sp_ahndc_automatica`:

```
F1 (EP) = 36 params × 2 + 59 string_comparisons = 131
F2 (BVA) = 14 params numéricos × 3 = 42
F3 (Ramas) = 135 branches × 2 + 26 compuestas = 296
F4 (Errores) = 19 returns no-cero = 19
F5 (Transacciones) = 3 (simple con BEGIN TRAN)
F6 (Especiales) = 0 cursores + 4 EG = 4

Casos_brutos = 131 + 42 + 296 + 19 + 3 + 4 = 461 (valor calculado real: 461)
Coeficiente ALTA = 0.50
Casos_netos = 461 × 0.50 = 231
Recargo riesgo (+10% por saldos) = 24
Casos_final_referencial = 255

Rango referencial: [55-100] para ALTA
Nosotros generamos: 155 optimizados → DENTRO del rango extendido
```

## 2.4 Estructura del entregable final

El pipeline genera 2 archivos directamente en `documents/<sp>/tc_gen/`:

**Archivo principal** (`<sp>.test_cases.json`) — consume el agente enricher:
```json
{
  "sp_name": "sp_ahndc_automatica",
  "database": "cob_ahorros",
  "generated_by": "sp_tc_gen pipeline",

  "analysis": { /* params, DML, sp_calls, variables_count */ },
  "complexity": { /* D1-D5, clasificacion_final, escalamientos */ },
  "hardcoded": { /* in_lists, string_comparisons, error_codes_cerror, unique_return_codes */ },
  "links": { /* dml_links, return_links */ },

  "test_cases": [
    {
      "tc_id": "BR-001-TRUE",
      "rule_id": "BR-001",
      "type": "branch_coverage",
      "line": 146,
      "objective": "Cubrir rama TRUE: ...",
      "expected_return": "39003",
      "linked_returns": [{"value": "39003", "line": 160}]
    },
    {
      "tc_id": "TRAN-001-COMMIT",
      "rule_id": "TRAN-001",
      "type": "transactional",
      "subtype": "commit_success",
      "line": 564,
      "objective": "Verificar commit exitoso..."
    }
  ]
}
```

**Archivo metadata** (`<sp>.raw_metadata.json`) — auditoría:
```json
{
  "bri": { "summary": {}, "rules": [] },
  "transactional": { "has_begin_tran": true, "savepoints": ["pndcca"], "commit_count": 12 },
  "coverage": { "casos_netos": 148, "factores": {} },
  "optimization": { "input": {}, "output_total": 78, "excluded": {}, "added": {} }
}
```

**Después del agente enricher**, el archivo principal se sobrescribe in-place con campos adicionales: `descripcion`, `d6`, `cobertura_funcional`, y hasta 5 TCs de Error Guessing.

## 2.5 Gaps de cobertura — estado

| # | Gap | Estado | Implementación |
|---|---|---|---|
| 1 | CASE WHEN como branches | ✅ IMPLEMENTADO | `extractors/case_when.py` — 1 TC por WHEN + 1 ELSE |
| 2 | TC falla SP hijo | ❌ DESCARTADO | Solo probamos el padre; falla de hijo es integración |
| 3 | EP valores diferenciados | ✅ IMPLEMENTADO | `apply_ep_differentiated()` en dedup_optimizer.py |
| 4 | Control transaccional | ✅ IMPLEMENTADO | `generators/tc_transactional.py` — commit + rollback + savepoint |

---

## 2.6 Mapeo criterios estrategia → implementación

| Criterio de la estrategia | Script/módulo que lo implementa | Evidencia |
|---|---|---|
| Regla de Oro (1 TC = 1 objetivo) | `dedup_optimizer.py` — no colapsa TCs con objetivos diferentes | Cada TC tiene tc_id único + rule_id único |
| Fidelidad al código | Regla anti-invención del agente + scripts solo leen .sql | Todo TC tiene `line` trazable |
| EP por tipo (MONEY, CHAR, Enums) | `generators/tc_istqb.py` función `generate_ep_by_type()` | TCs con type="EP" |
| BVA bordes | `generators/tc_istqb.py` función `generate_bva_from_branches()` | TCs con type="BVA" |
| BVA mínimo (solo borde real) | `optimizers/dedup_optimizer.py` función `apply_bva_minimal()` | TCs con tecnica="BVA_minimal" |
| Fracción centavo obligatoria | `generators/tc_istqb.py` genera + `dedup_optimizer.py` protege con `protected: true` | TCs con particion="fraccion_centavo_obligatoria" |
| Branch Coverage (TRUE/FALSE) | `generators/tc_raw.py` genera TC por path | TCs con type="branch_coverage" |
| Tablas de Decisión (AND/OR) | `optimizers/decision_table.py` detecta y genera matriz | TCs con tecnica="Decision_Table" |
| Error Guessing | Agente: máximo 5 justificados | TCs con type="error_guessing", rule_id=null |
| EP estructural (misma ruta → 1 TC) | `optimizers/dedup_optimizer.py` función `apply_ep_structural()` | TCs con tecnica="EP_structural" |
| Optimización por redundancia | `dedup_optimizer.py` colapsa mismo RETURN | Campo `exclusion_reason` en excluidos |
| D1-D5 complejidad | `scorers/complexity_scorer.py` | Llave `complexity` en JSON |
| D6 criticidad | Agente evalúa | Llave `d6` en JSON |
| Fórmula F1-F6 | `scorers/coverage_formula.py` | Llave `coverage` en JSON |
| Pesos D2 exactos | `complexity_scorer.py` (IF=0.5, IF/ELSE=1.0, AND/OR=1.5, cursor=3.0) | `complexity.D2.puntos` |
| Escalamientos obligatorios | `complexity_scorer.py` aplica automáticamente | `complexity.escalamientos` |
| CASE WHEN como branches | `extractors/case_when.py` + `bri_builder.py` (CW-*) + `tc_raw.py` | TCs con type="case_when_coverage" |
| Control transaccional | `generators/tc_transactional.py` detecta BEGIN/SAVE/COMMIT/ROLLBACK | TCs con type="transactional" |
| EP diferenciado (valores IN con IF) | `dedup_optimizer.py` función `apply_ep_differentiated()` | TCs con tecnica="EP_differentiated" |
| Excluir BVA @@rowcount + aliases | `dedup_optimizer.py` función `exclude_bva_system_variables()` | Detecta `set @var = @@rowcount` |
| Excluir return duplicados | `dedup_optimizer.py` función `exclude_duplicate_returns()` | Mismo (return, line) → 1 |
| Exclusión sp_gen_sec | `extractors/sp_calls.py` lo detecta pero `bri_builder.py` marca `testable: false` | No genera TC para sp_calls |
| Coeficiente solapamiento | `coverage_formula.py` calcula como métrica informativa | `coverage.coeficiente` — NO recorta TCs |
| Recargo riesgo financiero | `coverage_formula.py` (+5-10% si MONEY + >3 DML) | `coverage.recargo_riesgo_percent` |

---

## 2.7 Decisiones de estrategia — Observaciones del cliente (2026-06-16)

Contexto: El cliente revisó los TCs generados para `sp_debcred_empresa` (179 TCs) y señaló posibles redundancias y combinaciones faltantes. A continuación se documenta cada observación, el análisis técnico, la decisión tomada y su justificación desde la estrategia de pruebas.

---

### OBS-1: "Faltan combinaciones para @i_tipcta_emp in (3,4,12), forma de pago, @i_servicio"

**Hallazgo del cliente:** Los valores dentro de listas IN no tienen TC individual cuando el SP los trata de forma diferente internamente.

**Regla de estrategia que aplica:**
- §2.1 EP Códigos/Enums: "1 clase válida por valor con tratamiento diferenciado"
- Regla de Oro: "cada combinación única de condiciones = 1 TC independiente"

**Diagnóstico técnico:**
Nuestro `apply_ep_structural()` en `dedup_optimizer.py` asume que una lista IN siempre recorre la misma ruta. Eso es correcto cuando todos los valores del IN producen el mismo efecto (ejemplo: `@t_trn in (4253, 4229, 16637)` todos asignan el mismo factor). Pero es INCORRECTO cuando dentro del bloque hay un IF que diferencia valores específicos.

Caso real detectado: `sp_debcred_empresa` L:414 colapsa `('DIR','SAT')` como misma ruta, pero SAT tiene IF interno diferenciado (L:416). BNK e IBK tampoco tienen TC individual cuando sí tienen tratamiento distinto (L:421-424).

**Decisión:** IMPLEMENTAR — Agregar verificación post-EP-structural que detecte IFs internos que referencian la misma variable de la lista IN.

**Justificación:**
- ISTQB §4.2.1: "Si un valor dentro de una partición produce un comportamiento diferente, constituye su propia partición"
- La estrategia del banco dice "cada literal debe tener su propio caso que lo active y valide"
- No afecta la estructura del JSON — solo genera más TCs donde corresponde

**Impacto en pipeline:** Nuevo paso en `dedup_optimizer.py` o script adicional `ep_differentiated.py` que cruce `hardcoded.in_lists` + `hardcoded.string_comparisons` + `branches` para detectar valores con tratamiento interno diferente.

**Estado:** IMPLEMENTADO (2026-06-16) — `apply_ep_differentiated()` en dedup_optimizer.py

---

### OBS-2: "Considerar redundante cuando mismos datos para diferentes parámetros"

**Hallazgo del cliente:** BR-02, BR-04, BR-05 marcan como redundantes con DML-01 porque validan lo mismo (que la operación INSERT se ejecute correctamente) pero desde perspectivas diferentes.

**Regla de estrategia que aplica:**
- Regla de Oro del banco: "cada combinación única de condiciones = 1 caso de prueba independiente"
- Banco prefiere: "Es preferible 130 casos separados y correctos que 50 casos agrupados"
- Regla de Optimización §1: "misma ruta → 1 TC representativo"

**Diagnóstico técnico:**
El `dedup_optimizer.py` actualmente cruza redundancia DENTRO de cada categoría:
- Branches entre sí (mismo RETURN → queda 1)
- BVA contra EP del mismo param

Pero NO cruza ENTRE categorías: un branch TC que produce un DML no se compara contra el DML TC que cubre ese mismo INSERT.

**Análisis de alineamiento con banco:**
Un branch TC verifica que la CONDICIÓN se evalúe correctamente (perspectiva de decisión). Un DML TC verifica que el INSERT/UPDATE se ejecute (perspectiva de efecto). Aunque cubren la misma ruta, sus OBJETIVOS de verificación son distintos:
- Branch TC: "¿La condición @w_abrir_tran = 1 se evalúa bien?"
- DML TC: "¿El INSERT en ah_tran_monet se ejecuta con los campos correctos?"

El banco dice "cada combinación ÚNICA de condiciones = 1 TC". Estos TCs tienen condiciones/objetivos diferentes.

**Decisión:** NO FUSIONAR AUTOMÁTICAMENTE — Mantener ambos TCs porque el banco prioriza casos separados sobre agrupados. Solo INFORMAR solapamiento para que el QA tenga visibilidad.

**Justificación:**
- El banco explícitamente prefiere más TCs separados que pocos agrupados
- Branch TC y DML TC verifican cosas diferentes (condición vs efecto)
- Eliminar automáticamente puede violar la Regla de Oro si la condición no se cubre por otro medio

**Impacto en pipeline:** Sin cambio de código. Se documenta como solapamiento conocido pero NO se elimina.

**Estado:** CERRADO — REQUIERE CONFIRMACIÓN CON BANCO si quieren reducir este tipo de casos. Mientras tanto: se mantienen ambos.

---

### OBS-3: "No especifica resultado esperado" (TC-PAR-03 a PAR-06, TC-EP-01 a EP-09)

**Hallazgo del cliente:** Algunos TCs no dicen qué debería pasar (qué RETURN esperar, qué error debería dar).

**Regla de estrategia que aplica:**
- Buena práctica ISTQB: Todo TC debe tener resultado esperado explícito

**Diagnóstico técnico:**
Los branch TCs que tienen `linked_returns` ya traen la info, pero estaba anidada en un array. Los TCs de tipo EP/BVA/Param no tenían forma de saber qué RETURN producen porque no estaban vinculados a una rama específica.

**Decisión:** IMPLEMENTADO en dos fases:
- (2026-06-16) Campo `expected_return` promovido a primer nivel en branch TCs con `linked_returns`.
- (2026-06-24) **Llave `expected_result` añadida al 100% de los TCs** (ver 1.6.1). Resuelve de raíz el caso EP/Param: en vez de dejar el resultado vacío (que invitaba a que el agente downstream inventara un código — origen del falso `@o_error=122004` que el banco marcó), ahora cada TC declara su resultado esperado **trazado al SP** o **explícitamente dependiente** (`DEPENDS_ON_CHILD`, `DEPENDS_ON_USAGE`, `PARAM_NOT_SUPPLIED`).

**Justificación:**
- Simplifica el parsing del agente downstream (Nico punto 4)
- El agente TC puede construir assertions directas cuando el resultado es trazable: "espero RETURN 39003"
- Cuando el resultado NO es determinístico desde el padre, se declara la dependencia en vez de inventar — esto es lo que evita los códigos de error incorrectos

**Impacto en pipeline:** `tc_raw.py`, `tc_istqb.py`, `tc_transactional.py` y `dedup_optimizer.py` añaden `expected_result` a cada TC. Verificado con test de regresión (`sp_tc_gen/tests/test_regression.py`): 100% de cobertura, 0 TCs perdidos, 0 códigos inventados.

**Estado:** COMPLETADO (ampliado 2026-06-24)

---

### OBS-4: Redundancias detectadas por cliente — Análisis por categoría

**Hallazgo del cliente:** Múltiples TCs señalados como DUPLICADO CRÍTICO, REDUNDANTE FUNCIONAL o SOLAPAMIENTO.

#### OBS-4A: BVA vs Branch en @@rowcount/@@trancount (BVA-44 a BVA-53)

**Regla que aplica:** Regla de Oro — si 2 TCs prueban exactamente lo mismo, queda 1.

**Diagnóstico:** `tc_istqb.py` genera BVA para la condición `@@rowcount > 0` (borde: 0, cruce: 1) y `tc_raw.py` genera branch TC para el IF que contiene esa condición. Ambos prueban la misma decisión. El `dedup_optimizer` no cruza BVA contra branch cuando la condición es `@@rowcount` o `@@trancount`.

**Decisión:** IMPLEMENTAR — Nueva regla en dedup: BVA que referencia `@@rowcount` o `@@trancount` se excluye si ya existe un branch TC para esa misma línea. Razón: `@@rowcount` no es un parámetro de entrada (es un efecto colateral del DML anterior), por lo que el BVA no agrega información que el branch TC no cubra.

**Justificación:**
- @@rowcount no es input controlable → BVA sobre @@rowcount no aporta dato de prueba adicional
- El branch TC ya cubre la decisión (TRUE/FALSE)
- Eliminar los BVA de @@rowcount reduce ~10 TCs sin perder cobertura real

**Estado:** IMPLEMENTADO (2026-06-16) — `exclude_bva_system_variables()` en dedup_optimizer.py

---

#### OBS-4B: EP money isnull(x,0)>0 patrón repetido (EP-55/58/61/64/67)

**Regla que aplica:** EP Estructural — si el efecto es el mismo → 1 TC representativo.

**Diagnóstico:** Cada variable money (`@w_valor_ordenado`, `@w_valor_debito`, `@w_comision`, etc.) tiene un IF `isnull(x,0) > 0` que controla si se ejecuta cierto DML. El patrón lógico es idéntico pero:
- Si cada variable controla un DML DIFERENTE → son TCs independientes (cada uno verifica un INSERT/UPDATE distinto)
- Si controlan el MISMO DML → son redundantes

**Decisión:** MANTENER CON CONDICIÓN — Se mantienen como TCs independientes SOLO si cada `isnull(variable,0) > 0` controla un DML diferente (verificable vía `linked_dmls`). Si 2+ variables controlan el mismo DML → colapsar a 1 representativo.

**Justificación:**
- ISTQB §4.2.1: "Particiones diferentes si producen comportamiento observable diferente"
- Si el INSERT es diferente, el resultado observable es diferente → mantener
- Si el INSERT es el mismo, el resultado observable es idéntico → colapsar

**Estado:** IMPLEMENTADO (2026-06-16) — `exclude_ep_same_dml()` en dedup_optimizer.py. Colapsa automáticamente EP TCs que apuntan al mismo DML.

---

#### OBS-4C: Fracción centavo repetida (BVA-17 a BVA-21)

**Regla que aplica:** §2.2 BVA del banco: "Regla especial MONEY: Incluir caso de fracción de centavo (100.00 / 3 = 33.3333) para validar redondeo Sybase → Java"

**Diagnóstico — TENSIÓN:**
- El cliente dice: "son redundantes, es el mismo test de precisión money con parámetro diferente"
- El banco pide: fracción centavo para campos monetarios (parece incluir cada parámetro MONEY)
- Nuestra regla actual: TODO param MONEY de entrada tiene fracción centavo protegida (`protected: true`, NUNCA se elimina)

La tensión es real: si el SP tiene 8 parámetros MONEY, generamos 8 TCs de fracción centavo. El cliente ve 5 como redundantes porque "todos prueban lo mismo" (que Java/Sybase redondeen igual).

**Análisis de alineamiento con banco:**
El banco en su F6 dice: "Operación MONEY → Fracción de centavo (monto / 3) → validar redondeo". Y en F2 BVA dice que la regla especial aplica a parámetros MONEY. NO distingue entre params de entrada que persisten vs params que solo se comparan internamente. El texto es general.

**Decisión:** NO TOCAR — Mantener TODAS las fracciones centavo de parámetros de entrada MONEY tal como están. Es la interpretación más conservadora y segura del lineamiento del banco.

**Justificación:**
- El banco pide "fracción centavo para campos monetarios" sin distinguir entre los que persisten y los que no
- Cada param MONEY puede tener comportamiento de redondeo diferente en Java (depende de cómo se mapea internamente)
- Eliminar sin confirmación del banco es riesgo de no-conformidad
- 5 TCs extra (de ~160 totales) es un costo menor comparado con el riesgo de que banco reclame cobertura faltante

**Pregunta pendiente al banco:** "¿La fracción de centavo debe aplicarse a TODOS los parámetros MONEY de entrada, o solo a los que persisten directamente en INSERT/UPDATE?"

**Impacto en pipeline:** Sin cambio de código. Se mantiene la protección actual.

**Estado:** CERRADO TEMPORALMENTE — Se mantiene comportamiento actual (proteger todas). Revisar con banco en próxima reunión.

---

#### OBS-4D: BVA mismo patrón en contextos diferentes (BVA-26/27/32/33/38/39)

**Regla que aplica:** Regla de Oro — mismo patrón ≠ mismo objetivo si los DMLs son diferentes.

**Diagnóstico:** Son BVA de la misma condición numérica (`valor > 0`) pero en RAMAS diferentes del SP, cada una con DMLs distintos (una controla INSERT en tabla A, otra controla UPDATE en tabla B).

**Decisión:** MANTENER — No son redundantes. Mismo patrón de condición pero efecto observable diferente.

**Justificación:**
- Si falla la rama de tabla A, no afecta la rama de tabla B
- Necesitan datos de prueba diferentes (un contexto activa una rama, otro contexto activa la otra)
- El cliente puede ver "mismo test" pero técnicamente validan operaciones independientes

**Estado:** CERRADO — Sin cambio

---

#### OBS-4E: TC-RET-06 vs TC-RET-03

**Regla que aplica:** Regla de Oro — mismo escenario, mismo efecto → fusionar.

**Diagnóstico:** Ambos prueban falla de comisión SWIFT con propagación de error. El resultado esperado es idéntico.

**Decisión:** IMPLEMENTAR — El dedup debe detectar TCs de tipo `return_verification` con mismo `expected_return` + misma condición semántica y colapsar.

**Justificación:** Dos TCs que activan la misma línea de RETURN con la misma precondición son literalmente el mismo test.

**Estado:** IMPLEMENTADO (2026-06-16) — `exclude_duplicate_returns()` en dedup_optimizer.py

---

### Resumen de decisiones

| Obs | Decisión | Justificación estratégica | Estado |
|-----|----------|---------------------------|--------|
| OBS-1 (EP diferenciado) | IMPLEMENTAR — generar TC por valor con tratamiento distinto | Banco: "generar independientes cuando activa diferentes DMLs" | ✅ IMPLEMENTADO |
| OBS-2 (branch vs DML) | NO FUSIONAR — mantener ambos | Banco: "preferible 130 separados que 50 agrupados" | ⏸️ Consultar banco |
| OBS-3 (expected_return) | Promover a primer nivel | Buena práctica ISTQB resultado esperado explícito | ✅ IMPLEMENTADO |
| OBS-4A (BVA @@rowcount) | ELIMINAR — no es input controlable | BVA aplica a params de entrada, no a variables del sistema | ✅ IMPLEMENTADO |
| OBS-4B (EP money isnull) | MANTENER si DML diferente, COLAPSAR si mismo DML | EP distingue por efecto observable | ✅ IMPLEMENTADO |
| OBS-4C (Fracción centavo) | NO TOCAR — mantener todas protegidas | Banco pide "fracción centavo para campos monetarios" sin excepción | ⏸️ Consultar banco |
| OBS-4D (BVA contextos) | MANTENER — no son redundantes | Rutas diferentes = objetivos diferentes | ✅ CERRADO |
| OBS-4E (RET duplicados) | FUSIONAR — mismo escenario, mismo efecto | Regla de Oro: misma ruta → 1 TC | ✅ IMPLEMENTADO |

---

### Impacto consolidado en el pipeline

| Script | Cambio | Estado |
|--------|--------|--------|
| `dedup_optimizer.py` | `exclude_bva_system_variables()` — excluye BVA de @@rowcount/@@trancount | ✅ IMPLEMENTADO |
| `dedup_optimizer.py` | `exclude_duplicate_returns()` — fusiona return_verification duplicados | ✅ IMPLEMENTADO |
| `dedup_optimizer.py` | `exclude_ep_same_dml()` — colapsa EP money si controlan mismo DML | ✅ IMPLEMENTADO |
| `dedup_optimizer.py` | `apply_ep_differentiated()` — genera TCs para valores IN con IF interno | ✅ IMPLEMENTADO |
| `dedup_optimizer.py` — fracción centavo | Sin cambio (mantener protección actual) | ⏸️ Espera banco |
| `dedup_optimizer.py` — cross-category | Sin cambio (no fusionar branch↔DML) | ⏸️ Espera banco |
| `consolidate.py` | Separó metadata en archivo aparte | ✅ IMPLEMENTADO |
| `tc_istqb.py` | Sin cambio estructural | SIN CAMBIO |

---

### Preguntas pendientes para banco (próxima reunión)

1. **Fracción centavo:** "¿La fracción de centavo debe aplicarse a TODOS los parámetros MONEY de entrada, o solo a los que persisten directamente en INSERT/UPDATE?"
2. **Branch vs DML:** "Cuando un branch TC y un DML TC cubren la misma ruta pero desde perspectivas diferentes (condición vs efecto), ¿deben mantenerse ambos o se considera redundante?"

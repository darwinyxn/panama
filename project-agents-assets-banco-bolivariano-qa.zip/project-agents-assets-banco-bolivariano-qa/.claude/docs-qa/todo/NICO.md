# TODO QA — NICO

## Estado actual por SP

| SP | Repo | TCs | Estado |
|---|---|---|---|
| sp_ahndc_automatica | cpas-mso | 58 | ✅ Completa (58/58 EQUIV, corrida 1846) |
| sp_debcred_empresa | bem-mso-debito-credito-empresa-pagos | 94 | ✅ CERRADO. SP↔REST 94/94 EQUIVALENTE (paridad exacta). REST↔gRPC 91/94: TC39/40/41 divergen por DECISION DE ARQUITECTURA DEL BANCO (proto sin wrappers en inputs -> proto3 no distingue escalar numerico OMITIDO de cero; gRPC no reproduce el -6 de param faltante que da REST). ACEPTADO como consecuencia de decision banco, sin accion QA. Contrato NCBE-784 envelope data. Corridas JUL-17 1423 (commit 74860a2) y JUL-22 1510 (commit 57ae11e): 91/94 reproducible. |
| pa_reca_bcobro_comi_diario | rec-mso | 30 | ⏳ Pendiente validar TC22-32 + corrida |
| pa_fir_consulta_firmante | cpas-mso-consulta-firmante | 15 | 🟢 DOC FINALIZADO (JUL-28). Cuentas propias (10+TC11 inexistente), dry-run 15/15 SYBASE_OK, CONFIG+DICCIONARIO completos (micro ya existe, 30 clases). Diccionario: SP solo-lectura, resultado por result sets (7 filas). Solo falta base_url/grpc_host reales (despliegue) para corrida real REST/gRPC. |
| sp_ah_depositosl_rc | cpas-mso-depositosl-rc | 27 | 🟢 **2026-08-05: TC11 y TC19 RESUELTOS (RETURN 0) con bloque ATOMICO de priming (3ra iteracion, ver PENDIENTES), TC12 documentado con nuevo esperado (RETURN 901421) — no requiere mas trabajo.** Diagnostico previo ("solo mensaje_debug cosmetico") quedo descartado: el documento del banco espera que estos 3 reversos se completen con EXITO ("nueva fila... registrada"), pero el PRE usaba `@t_ssn_corr` sintetico (888003/NULL) sin transaccion original real. Iteracion 1 (DECLARE/EXEC sin marcador ATOMIC): nunca se ejecutaba en la corrida real (el motor no reconocia el bloque). Iteracion 2 (INSERT minimo en `ah_tran_monet`): pasaba el gate de fecha pero el reverso caia en `RETURN 35000` (cupo) porque un INSERT directo no carga `cl_cupos_clientes.cu_utilizado`, efecto colateral que SOLO ocurre via `sp_maneja_cupo_mis1` dentro de un EXEC real. Iteracion 3 (FINAL, verificada end-to-end con el codigo real del motor): TC11 (AHO, cuenta 0000819100, RUC 13 digitos) y TC19 (virtual, cuenta 0004000548) ahora ejecutan un bloque `DECLARE...EXEC...OUTPUT` marcado `-- ATOMIC-BEGIN`/`-- ATOMIC-END` que hace un DEPOSITO ORIGINAL REAL en el PRE (carga el cupo real) y reversan usando su secuencial real -> `RETURN 0`, `o_neto=100.00`, cupo/saldo netean exactamente al baseline. TC12 (AHO) sigue siendo un caso DISTINTO: usa `@t_ssn_corr=NULL` explicitamente -> gate de fecha de reverso en `sp_ah_depo2_locrem_sl_rc` L:595-600 corta el flujo ANTES de la logica de duplicado, de forma 100% deterministica -> `RETURN 901421` es el UNICO resultado posible. Sincronizado a los 5 repos. 0 problemas de MICRO en deposito. Corrida de confirmacion (27/27 con estos 3 fixes) AUN NO relanzada — pendiente antes de considerar el SP totalmente cerrado. |
| sp_ah_retiro_rc | cpas-mso-retiro-rc | 19 | 🟡 **2026-08-05: 3 fixes de motor/PRE (QA-side) CERRADOS; corrida de confirmacion (18:13) dio 10/19 EQUIVALENTE — los 9 restantes son 2 bugs REALES DE JAVA (no de motor), escalados a migracion, ver PENDIENTES-MIGRACION.** Los 3 fixes QA-side confirmados con la corrida 18:13: TC01-08,11,12 (10 TCs que fallaban por `[init-cero]`) -> EQUIVALENTE; TC09/16/19 (bug de re_caja) -> sin el 31063 de antes. Los 9 NO-equivalente restantes (TC09,10,13-19) NO son de motor: son 2 defectos reales en `bb-core-cob-ahorros-utils` que dejan `oComision`/`oBaseImp` en `0.0` cuando el SP real da NULL (verificado en vivo contra Sybase, sin tocar Java) — ver detalle completo en PENDIENTES-MIGRACION. Motor QA queda LIMPIO del lado retiro: no hay ningun fix de motor pendiente, solo esperar correccion de migracion y re-confirmar. |

---

## 📌 RESUMEN ACTUALIZADO 2026-08-04 (checklist ejecutivo vigente)

Estado real al cierre de la sesion del 2026-08-04. El checklist del JUL-31 (mas abajo) queda como HISTORICO —
sus items 1-3 (deposito) ya estan resueltos, ver items nuevos abajo.

**DEPOSITO (sp_ah_depositosl_rc) — CERRADO del lado QA:**
1. ✅ Corrida final 2026-08-04 2325: 24 EQUIVALENTE + 3 INCONSISTENCIA benigna (TC11/TC12/TC19, solo
   `mensaje_debug` cosmetico). Regresion TC10/TC18 del JUL-31 CONFIRMADA RESUELTA por migracion.
2. ✅ TC05 (fallo nuevo `45004` por fila residual sin guard en PRE) detectado y corregido en el documento.
3. ⏳ Pendiente: decidir si publicar/sincronizar la corrida final a project-agents-assets-banco-bolivariano
   y -qa (no se ha hecho, a la espera de revision).
4. ⏳ Pendiente menor (heredado del JUL-31, sin cambios): actualizar Gestor QA (Supabase) al estado final.

**RETIRO (sp_ah_retiro_rc) — 2 problemas abiertos, ninguno de logica migrada:**
5. 🔴 **ABIERTO — fix de motor QA pendiente de implementar.** El pre-seed `SELECT @o_x=0` (fix JUL-31,
   pensado solo para `@o_comision`) se aplica a TODOS los output params numericos de retiro, causando 16
   falsos INCONSISTENCIA (verificado en vivo: el SP real da NULL igual que el micro). Ver item QA detallado
   mas abajo ("fix de motor — el pre-seed... inicializa TODOS los output params").
6. 🔴 **ABIERTO — reportar a deploy/plataforma.** Micro con 500 en los 3 health checks y en toda ruta de
   escritura real (verificado independiente con curl directo, reproducible, no es problema de reset entre
   pasadas). Ver item nuevo mas abajo ("reportar a deploy/plataforma"). Mensaje ya redactado para el equipo
   correspondiente.
7. Los items 4-10 del checklist JUL-31 (mas abajo) sobre `@t_trn=4261 vs 4264`, TC10/13-15/17/18 bloqueados
   por catalogo del banco, e informe `informe_banco_sp_ah_retiro_rc_catalogo.md` SIGUEN VIGENTES sin cambios
   esta sesion — no se tocaron.

---

## 📌 HISTORICO — checklist ejecutivo sesion JUL-31 (SUPERADO por el resumen 2026-08-04 arriba)

Indice de lo que quedo abierto al cierre de JUL-31, ya resuelto/superado en entradas posteriores de
este documento: deposito (regresion TC10/TC18, TC05 residual) y retiro (catalogo re_tran_contable con
duplicados para 4263 + oficina 999 sin perfil de cupo -- diagnostico ORIGINAL de JUL-31; la causa real
que finalmente explico la mayoria de los NO-equivalente de retiro resulto ser 2 bugs de Java NULL-vs-
0.0, ver PENDIENTES-MIGRACION/BANCO, no la contradiccion de catalogo). Detalle forense completo en
git log de los commits de esa sesion si se necesita en el futuro.

---

## PENDIENTES — QA (accionables por nosotros)

- **`sp_tr_deposito_rc` / `cpas-mso-tr-depositos-rc` (lote NCBE-lote-04, HU NCBE-1380, JIRA
  NCBE-1498) — CERRADO del lado QA (2026-08-19 a 2026-08-27), arco completo resumido:**
  1. SP "libreria banco" (cuerpo solo via `syscomments` en vivo, sin `.sql` local). Repo del micro
     estuvo vacio hasta 2026-08-21 (no confundir con `cpas-mso-depositosl-rc` / `sp_ah_depositosl_rc`,
     que es lote-2, un SP DISTINTO).
  2. **TC10 — bloqueo de permisos `cob_dstoffline` reportado por Banco era FALSO**: el error real
     pertenecia a una sesion ajena (suid 306 = login `ycisnerp`, no nuestro `operadorPas` suid 295);
     el SP ni siquiera referencia esa base. Ejecutado real (autorizado): `RETURN 30018` confirmado,
     reversion exacta en 6 tablas.
  3. Banco entrego 2 rondas de correcciones a su documento (24 TCs, luego 23 TCs tras retirar el
     rango MDDP/MMDP por ser codigo muerto confirmado desde 2001) y confirmo/amplio 4 hallazgos
     propios (brechas de caja en TC15/TC21-viejo cerradas por Banco con ejecucion real; defecto real
     de 16 parametros desalineados en la rama `@s_org='S'`, ampliado por Banco desde nuestro hallazgo
     inicial de 3).
  4. **⭐ HALLAZGO DE PROCESO (aplica a CUALQUIER SP futuro): regenerar el scaffold via agente-01 desde
     un doc de Banco actualizado PIERDE ejecuciones reales que nosotros ya confirmamos si Banco nunca
     las incorporo a su propio documento** (detectado cuando 3 TCs volvieron a mostrar narrativas
     viejas ya desmentidas). **Regla:** antes de regenerar, listar los TCs con `ejecutado_real` de la
     version anterior y re-inyectar esa evidencia si el doc nuevo de Banco no los tocó.
  5. **Dry-run completo del motor QA (`execute_all.py`/`run_qa.py`/`parse_test_cases.py`) encontro y
     corrigio 5 bugs REALES DEL MOTOR** (genericos, no especificos de este SP): serializacion de
     `GETDATE()` como string literal; falta de declaracion de params OUTPUT cuando el DICCIONARIO
     dice "Pendiente"; bug de descubrimiento de ruta (`sp_doc_path`/`sp_auto_dir` usaban `sp_name` en
     vez de la carpeta del microservicio, para SPs libreria-banco); vista `cc_tscierre_cta` tratada
     como tabla; regex de header POST/PRE demasiado estricto; colision de secuencial `@s_ssn` entre
     TCs que no lo sobreescriben (indice unico global, no por cuenta) resuelta con PRE de limpieza
     individual por TC. Resultado final: 21/21 (maximo posible tras retirar TC22/TC23, ver #6).
  6. **TC22 (defecto real, 16 params) y TC23 (codigo inalcanzable por diseno) retirados formalmente
     del scaffold ejecutable, autorizado por Banco (2026-08-24)** — quedan 21 TCs (TC01-TC21), sin
     renumerar. Historial completo preservado en el documento fuente de Banco y en git.
  7. **Correccion de atribucion (memoria `feedback_defecto_sp_es_de_banco.md`): un defecto DENTRO del
     codigo del SP se reporta a Banco (COB-001, dueno del Sybase/COBIS), nunca a Migracion** (que solo
     construye el equivalente Java). Se encontro este error en el propio documento y en una tarea de
     Gestor QA, corregido.
  8. **Migracion entrego el codigo Java (commit `2978d31`, 2026-08-21):** microservicio facade que
     consume via Maven la libreria del banco `com.bolivariano.package.core:cpas-bb-routecore-cobis`
     (repo `cpas-bb-contentbased-router`, modulo `cpas-bb-routecore-cobis`) — exec real del SP, 100%
     wireado (`SpTrDepositoRcNormalizer`, `DepositoCteUseCase/Port/Adapter`). agente-04 corrio con
     `base_url`/`grpc_host` confirmados en vivo via `oc get routes -n bb-dev-core` (la doc de rutas-
     openshift lote-04 decia "NO desplegado", estaba stale) — CONFIG+DICCIONARIO completos, 0 IGNORAR.
  9. **Matriz de equivalencia real (agente-05) — resultado final: 2 EQUIVALENTE, 1 INCONSISTENCIA, 18
     NO_EQUIVALENTE, 0 SYBASE_FAIL.** Lado SP 21/21 sano (tras corregir 3 bugs propios del motor
     encontrados en esta corrida: `GETDATE()` no traducido en payloads REST via `generate_payloads.py`,
     colision de secuencial SP-pass/REST-pass en TC01/15/18/20, caja/cajero faltante para la fecha real
     en TC16/18/21 — los 3 corregidos con el mismo patron PRE auto-reparable). **Defecto real y
     confirmado en el MICROSERVICIO** (no en el SP, no de motor): (A) `codigoRetorno` colapsa a `-1`
     en varios rechazos de negocio del SP en vez de propagar el codigo real; (B) error SQL
     `Invalid column name 'sp_return'` en casi todos los caminos exitosos `RETURN 0` (excepto TC09,
     que si responde bien — revisar que lo diferencia). Reporte de defecto redactado para Jira.
  **Estado final: CERRADO del lado QA.** Pendiente de terceros: Migracion (corregir el mapeo del
  RETURN status) y Banco (decision sobre el defecto de TC22). Gestor QA: 2 `spMigrations` creadas
  (`02c7a805` deposito_rc/NCBE-1498, `98ca6263` imix/NCBE-1580) con las tareas vinculadas via
  `spMigrationId`.

- **`pa_pag_bconcilia_cnb_imix` / `cnb-mso-concilia-cnb-imix` (lote NCBE-lote-04, HU NCBE-1344,
  JIRA NCBE-1580) — CERRADO 45/45 del lado QA (2026-08-27). Arco completo:**
  Particularidad del SP: READ-ONLY sobre sus tablas fuente (solo TRUNCATE+INSERT sobre su propia
  `db_general..rec_tmp_concilia_cnb`) — los TCs no llevan PRE/POST parametrizado tradicional, llevan
  "Datos de referencia" informativos; correcto para este SP, no un hueco.
  1. Scaffold inicial (45 TCs) + loop 0 FAIL ronda 1 (validador obtuvo catalogo COMPLETO real de
     `cc_usuario_cnb`=`CNB002..CNB007,cnb001`, resolviendo ambiguedades del doc Banco).
  2. Banco respondio (doc actualizado 2026-08-26) con validaciones whole-batch reales y confirmo
     14 TCs mas como VERIFICADO (TC02,05,12,13,19,27,28,29,30,34,35,36,42,43) — para TC05/27/28/29/30
     la estrategia de Banco NO fue buscar fila con usuario de catalogo especifico, fue correr el SP
     completo y confirmar el comportamiento en la salida general (whole-batch). Scaffold regenerado
     (commit `33a21bc`), loop 0 FAIL ronda 1 de nuevo (32 PASS, 10 NOT_APPLICABLE).
  3. Reclasificados en 10 NOT_APPLICABLE: fácil-resolvibles con dato sintetico reversible (TC09,
     TC21, TC39, TC40) vs dificiles que requieren constraint/lock temporal en la tabla compartida
     `rec_tmp_concilia_cnb` o en `cc_t_punto_cnb` (TC22,23,24,25,31,32 — misma tecnica ya aceptada
     historicamente por Banco, PENDIENTE de disenar/ejecutar, ver PENDIENTES).
  4. **Ejecutados los 4 faciles (2026-08-27, commit `a3b2d31`), siembra sintetica reversible
     (insertar-correr-verificar-borrar, mismo patron de TC10 de `sp_tr_deposito_rc`):**
     - TC09 (basica 120064+comision 120061, 2 filas correlacionadas) y TC39 (ahorro monto cero):
       `RETURN 0` limpio, comportamiento correcto → **VERIFICADO/EJECUTABLE**, sin hallazgos.
     - **TC40 (corriente monto negativo -50.00) — DEFECTO REAL DE SP:** el signo NO se pierde pero
       queda INCRUSTADO dentro del campo numerico de ancho fijo 13 posiciones
       (`re_monto_trx='00000000-5000'`) — cualquier parser de ancho fijo aguas abajo leeria un valor
       corrupto/no numerico. Formula de formateo L:148-150. Defecto de Banco (COB-001), no de
       Migracion.
     - **TC21 (forzar codigo no-numerico en catalogo `cl_trx_servcnb_imix`) — RESULTADO DOCUMENTADO
       ES INALCANZABLE:** `convert(int,'ABC')` genera `Msg 249` que ABORTA el batch completo ANTES
       del guard `if @@error<>0 return 300003377` (L:116-120) — el SP nunca llega a emitir ese
       codigo por esta via, propaga el error crudo de Sybase en vez de capturarlo. Defecto/
       discrepancia real de Banco, no de Migracion.
     Limpieza confirmada sin residuos en las 6 tablas tocadas + `cc_t_informacion_cnb`.
  5. **Resueltos los 6 "dificiles" (2026-08-27, commit `16ea8f8`), CHECK constraint temporal sobre
     `rec_tmp_concilia_cnb`** (activado justo antes del `exec`, removido de inmediato despues —
     verificado 0 locks/constraints antes y despues de cada uno): TC22, TC23 (necesito
     `@e_fecha='2026-08-26'`, la fecha original no tenia datos reales en ventana), TC24, TC31, TC32
     -> los 5 confirmados `RETURN 1` real con el mensaje de error tecnico correspondiente.
  6. **TC25 (ultimo pendiente) resuelto combinando ambas tecnicas** (siembra sintetica en
     `vi_tran_monet`+`cc_t_informacion_cnb`, tipo 120062, + el mismo CHECK constraint) — no existia
     ninguna fila real en ninguna fecha para ese patron, asi que el constraint solo no bastaba.
     `RETURN 1` real confirmado, limpieza total verificada. Commit `206f275`.
  **Estado final: 45/45 ejecutado/verificado, 0 NOT_APPLICABLE.** Pendiente unico: redactar y enviar
  a Banco el comentario de Jira con los 2 hallazgos de defecto real (TC21/TC40, ver PENDIENTES —
  MIGRACION/BANCO) -- ninguno bloquea el cierre QA, son hallazgos a comunicar, no trabajo nuestro.

- [ ] ⭐ **NUEVO (2026-08-19): agente-04 debe recibir `lote` + `funcionalidad` como parametros de
  entrada y resolver la busqueda de CONFIG (base_url/grpc_host) de forma DINAMICA, en vez de
  requerir inyeccion manual cada vez.**
  Hallazgo (durante el arranque de `sp_tr_deposito_rc` / `cpas-mso-tr-depositos-rc`, lote NCBE-lote-04):
  `agente-qa-auto-04-test-cases-config.md` (seccion "0b.3 Completar base_url") todavia dice
  literalmente "buscar en `/etc/hosts`" -- NO tiene la correccion ya vigente desde NCBE-1251
  (siempre preguntar a Migracion primero; `project-agents-assets-banco-bolivariano/rutas-openshift/
  lotes/lote-<N>/...md` es solo un EJEMPLO de donde puede vivir esa info, nunca garantizado). Esa
  correccion solo vive en el instructivo general (`1.INSTRUCCIONES-USO-AGENTES-QA.md` §1.3) y en
  este mismo NICO.md -- nunca se propago al archivo del propio agente. Resultado: cada vez que se
  corre agente-04 para un SP nuevo, alguien (yo, manualmente) tiene que inyectar la ruta correcta
  a mano en vez de que el agente la resuelva solo.
  **Propuesta:** el orquestador invoca a agente-04 pasandole explicitamente `lote` (ej. `lote-04`)
  y `funcionalidad`/microservicio (ej. `cpas-mso-tr-depositos-rc`) como parametros del prompt.
  Con esos 2 datos, agente-04 deberia:
  1. Buscar primero en `project-agents-assets-banco-bolivariano/rutas-openshift/lotes/lote-<N>/
     rutas-openshift-lote-<N>.md` (si existe) la entrada de esa funcionalidad especifica.
  2. Si no existe el archivo o no aparece la funcionalidad ahi, activar el protocolo ya vigente
     (preguntar a Migracion explicitamente vs `oc get routes`, nunca inferir por convencion de
     nombres ni por `/etc/hosts`).
  Esto requiere actualizar el archivo del agente (`agente-qa-auto-04-test-cases-config.md`), no
  solo el instructivo general -- ver `PROPAGATION.md` para el protocolo de cambios a `.claude/`.
  Tarea creada en Gestor QA para darle seguimiento (ver Gestor QA, kind=Automatizacion).

- [x] Historial forense completo `pa_fir_consulta_fir_especial`/`sp_ah_depositosl_rc`/
  `sp_ah_retiro_rc` (lote-2/lote-3, JUL-30 a AGO-11), TODO CERRADO — detalle completo en git log de
  esos commits, no repetido aqui: matriz `pa_fir_consulta_fir_especial` 12/12 EQUIVALENTE (commit
  `9503768`); soporte de `result_sets` en el motor; eliminacion del hardcode `[init-cero]` (Sybase
  no aplica el default `=0 out` de la firma cuando el param se pasa por OUTPUT — afecta a CUALQUIER
  SP, no solo retiro); soporte de bloques ATOMICOS `DECLARE...EXEC...OUTPUT` en PRE/POST (necesario
  cuando un reverso/efecto colateral real, ej. cupo, solo se carga via EXEC real, nunca via INSERT
  reconstruido); auditoria de fidelidad profunda de deposito (mutaciones reales verificadas, 3
  hallazgos corregidos); fix de `mensaje_debug` para no sobrescribir el mensaje propio del SP; fix
  de 3 tablas monitoreadas que nunca se snapshoteaban (subquery con parentesis sin balancear); TC10/
  TC18/TC05/TC09/TC17 de deposito corregidos (regresion mensajeDebug, residuo sin guard en PRE);
  TC11/TC19 de deposito reconstruidos con transaccion original REAL antes del reverso (TC12 quedo
  como caso estructuralmente distinto, `RETURN 901421` deterministico e inevitable); retiro TC09/
  TC10 llevados a debito real end-to-end (la "contradiccion irresoluble de catalogo del banco"
  reportada originalmente resulto ser un bug de motor -- output params no inicializados -- no una
  limitacion real de datos); reclasificados 9 TC de retiro como "de exito" (no 2); fix del extractor
  de output_params (`run_qa.py`, regex ciega sobre firma real vs comentarios); fix de `@o_ssn`
  comparado `exacta` (falso positivo estructural, cambiado a `presencia`); fix de duplicados
  historicos de `re_caja` que causaban 31063 falso en TC09/16/19 de retiro.
  **2 lecciones de proceso vigentes (generalizables, preservadas explicitamente):**
  1. Un commit que cambia muchas lineas (600+) puede REVERTIR SIN QUERER un fix de otra funcion en
     el mismo archivo aunque su mensaje de commit no lo mencione — pasó con la regresion de 5 dias
     de `result_sets` (un commit de retiro reviirtio sin querer el redesign de firmante). Revisar
     el diff completo de un commit grande, no solo el area que se cree estar tocando.
  2. Si se necesita diagnosticar en vivo una tabla que el PRE/POST de un TC toca, primero DETENER
     cualquier corrida activa de ESE SP sobre la misma BD antes de investigar — ejecutar SQL manual
     sobre una tabla que el motor esta leyendo/escribiendo a mitad de una corrida real puede alterar
     el resultado de esa corrida.

- [ ] **PENDIENTE (baja prioridad, retiro lote-2): 8 TC (TC10, TC13-19) requieren el mismo tratamiento
  que TC09** (`@t_trn=4264`, overrides de caja/libreta/control/servidor propios por cuenta) para
  ejercitar su logica real de negocio en vez de solo el rechazo contable temprano. No investigado a
  este nivel de detalle todavia.

- [ ] **PENDIENTE (baja prioridad, deposito lote-2): re-ejecutar TC24/25/26** (grupo BVA) — dieron
  REST_ERROR transitorio de red en la ultima corrida, evidencia de que es transitorio (TC27 inmediato
  despues SI respondio bien), no funcional.

- [x] Firmante (lote-3): fixes cosmeticos de la auditoria de fidelidad ya cerrados (TC04 dato
  incorrecto en doc, fallback `@s_srv` eliminado); 1 edge-case opcional sin cobertura (precedencia
  multi-tabla), no priorizado.

---

## PENDIENTES — MIGRACION / BANCO (bloqueados por terceros)

- [ ] ⭐ **NUEVO (2026-08-27): reportar a Banco 2 defectos reales de `pa_pag_bconcilia_cnb_imix`
  encontrados al resolver TC21/TC40 con datos sinteticos** (ver entrada completa de imix mas
  arriba en PENDIENTES-QA): (1) TC40 — el signo de un monto negativo queda incrustado dentro del
  campo numerico de ancho fijo en vez de perderse o manejarse aparte (formula L:148-150); (2) TC21
  — el `RETURN 300003377` documentado es inalcanzable porque `convert(int,...)` aborta el batch
  completo antes del guard `@@error<>0` del SP. Ambos son codigo Sybase/COBIS de Banco (COB-001),
  no de Migracion. Comentario de Jira aun no redactado/enviado.

- [x] ✅ **RESUELTO 2026-08-27: los 6 NOT_APPLICABLE "dificiles" de `pa_pag_bconcilia_cnb_imix`
  (TC22,23,24,25,31,32).** CHECK constraint temporal sobre `rec_tmp_concilia_cnb` (activado justo
  antes del `exec`, removido de inmediato), acotado por rama para no afectar los demas TCs (cada TC
  = 1 corrida completa e independiente del SP, que trunca la tabla al inicio -- sin riesgo de
  interferencia entre TCs). TC25 requirio combinar con siembra sintetica (no existia fila real para
  ese patron en ninguna fecha). Commits `16ea8f8`/`206f275`. SP queda 45/45.

- [ ] ⭐ **NUEVO (2026-08-14): decision pendiente — estandar de decimales para campos tipo money
  (REST/gRPC), reunion agendada MARTES 2026-08-18.**
  Hallazgo (NCBE-1644, ver entrada "FIX MOTOR PARTE 2" arriba): Sybase (tipo `money` nativo)
  retorna los montos con **4 decimales** (`0.0000`, `5000.0000`), confirmado con consumo directo
  (tsql crudo, sin motor) de `pa_fir_consulta_condicion` TC01/TC04/TC06. Los microservicios ya
  migrados (`cpas-mso-fir-consulta-condicion`, `cpas-mso-fir-consulta-especial`,
  `cpas-mso-genera-nd-nc-automatica-aho`) exponen money con **2 decimales fijos** en REST/gRPC
  (`0.00`), consistente con la lectura actual de API-008 (precision interna != precision expuesta).
  **Pregunta abierta para Migracion, sin resolver todavia:** ¿el estandar correcto es 2 decimales
  (como esta hoy) o el/los micro deben exponer los 4 decimales nativos de Sybase para paridad
  estricta con el SP? Ninguna decision tomada aun — no cambiar el comportamiento de ningun micro
  hasta que se defina en la reunion. Tarea creada en Gestor QA: "Estandar para campos tipo money
  QA/Migracion" (asignada a Nicolas, vence 2026-08-18).
  ~~Tambien sigue pendiente (de la misma intervencion): re-ejecutar la matriz completa de
  `pa_fir_consulta_condicion`...~~ **CERRADO 2026-08-18** (ver entrada dedicada mas abajo,
  "CORRIDA FINAL — pa_fir_consulta_condicion, post-decision de decimales").

  **ALCANCE REAL AMPLIADO (2026-08-18, mismo dia de la reunion):** auditoria completa contra
  codigo fuente real (.sql de sybase-local + .proto + *Dto.java de cada micro, NO solo el
  DICCIONARIO de QA) de TODOS los SPs en nuestro alcance con campos `money` expuestos en su
  RESPUESTA (result-set column u OUTPUT param — se excluyen los que solo tienen `money` como
  INPUT, ej. `sp_debcred_empresa`/`sp_cont_impuesto`, que nunca lo devuelven). El mismo patron sin
  corregir (`Double` plano en REST + `google.protobuf.DoubleValue` en gRPC) existe en 4 micros
  MAS, no solo en `pa_fir_consulta_condicion`/`con_especial`:
  - `cpas-mso-depositosl-rc` (`sp_ah_depositosl_rc`): `oImpuesto`, `oNeto` — **YA CERRADO Y
    ENTREGADO (27/27 EQUIVALENTE)**.
  - `cpas-mso-retiro-rc` (`sp_ah_retiro_rc`): `oImpuesto`, `oIntCap`, `oSldlib`, `oComision`,
    `oBaseImp` — **YA CERRADO Y ENTREGADO (19/19 EQUIVALENTE)**.
  - `cpas-mso-retefec_transval_rc` (`sp_retefec_transval_rc`): `oComision` — ya migrado.
  - `cnb-mso-sp-consulta_saldo` (`sp_cnb_consulta_saldo`, JP, NCBE-1169): `oDisponible`,
    `oComision` — EN PROGRESO, aun no cerrado (a tiempo, sin necesidad de retrabajar evidencia ya
    publicada si se corrige antes de agente-04/05).
  **Hallazgo de proceso:** en `sp_ah_depositosl_rc`/`sp_ah_retiro_rc` el DICCIONARIO de QA etiqueto
  estos campos como `tipo=double` (no `tipo=money`) — por eso el chequeo de formato agregado hoy
  en `_compare_grpc_rest_scalar` (gateado por `tipo=='money'`) nunca los marco como sospechosos;
  el defecto de representacion esta ahi tambien, simplemente nadie lo habia mirado porque la
  documentacion QA no lo clasifico correctamente desde el origen.
  Informe enviado a Migracion con esta tabla completa (2026-08-18). Ningun micro se toco todavia
  — la correccion de estos 4 (y la re-verificacion de los 2 ya cerrados) queda supeditada a la
  misma decision de estandar (2 vs 4 decimales) de la reunion de hoy.

## RESUELTO (continuacion) — 2026-08-18, cierre del dia de la reunion

- **CERRADO (NCBE-1644, decimales money):** decision de Migracion 2026-08-18: 2 decimales es el
  estandar PERMANENTE para `money` en REST/gRPC; 4 decimales reservado solo a tasa/alicuota (0 SPs
  en alcance usan ese tipo hoy). Motor generalizado por TIPO DECLARADO (`DECIMAL_TARGET_SCALE`,
  commit `dc19857`) en vez de inferir del dato observado — evita enmascarar un bug real de
  precision. Corrida final `pa_fir_consulta_condicion-18-08-2026-1520`: 7/7 EQUIVALENTE, `sp_output`
  ya muestra el literal fiel de Sybase (4 decimales) sin afectar el veredicto. Tarea Gestor QA
  `dd692494` cerrada.

- [ ] ⭐ **NUEVO (2026-08-05): 2 bugs REALES DE JAVA en `sp_ah_retiro_rc` — `oComision`/`oBaseImp` con default 0.0
  en vez de null. Afecta 9/19 TCs (TC09, TC10, TC13, TC14, TC15, TC16, TC17, TC18, TC19). NO tocado por QA —
  solo diagnosticado, con evidencia en vivo contra Sybase real, sin editar ningun archivo Java.**

  **Bug A — ruta CAR (afecta TC09, TC16): `oBaseImp` con default incorrecto.**
  Archivo: `bb-core-cob-ahorros-utils/sp-ah-retndcl-locrem-car-utils/src/main/java/com/bolivariano/cobahorros/
  spahretndcllocremcar/utils/application/usecases/SpAhRetndclLocremCarLibrary.java:387`
  ```java
  private Double oBaseImp = 0.0;   // deberia ser null
  ```
  El campo se inicializa en `0.0` y SOLO se sobrescribe si `t_trn==4262` (solo ahi se llama
  `procesarImpuesto(ctx)`). Para `t_trn=4261` (TC09, TC16), el SP real (`sp_ah_retndcl_locrem_car.sql`, el
  bloque que asigna `@o_base_imp` vive dentro de `if @t_trn = 4262`) deja el parametro OUTPUT en NULL (pasado
  por referencia, mismo mecanismo que ya se verifico en general en el fix de motor `[init-cero]` de arriba —
  Sybase NO aplica el default `=0 out` de la firma cuando el param se pasa via OUTPUT). Java nunca actualiza el
  campo para 4261 y devuelve `0.0` en vez de `null`.

  **Bug B — ruta RC (afecta TC10, TC13, TC14, TC15, TC17, TC18): `conCabecera` hardcodea 0.0.**
  Archivo: `bb-core-cob-ahorros-utils/sp-ah-retirond-rc-utils/src/main/java/com/bolivariano/cobahorros/
  spahretirondrc/utils/application/usecases/SpAhRetirondRcLibrary.java:543-547`
  ```java
  private RetirondRcResult conCabecera(Contexto ctx, int returnCode) {
      return new RetirondRcResult(
              returnCode, ctx.oLineas, null, null, null, null, null, null,
              ctx.oSsn, ctx.oDestra, Money.of(0.0), Money.of(0.0));   // oComision, oBaseImp hardcodeados
  }
  ```
  `conCabecera` se usa en TODOS los early-returns del SP (incluida la salida por codigo 31172 "causa sin
  contabilizacion" en `validacionesEntrada`, linea 191), construyendo SIEMPRE `Money.of(0.0)` para ambos campos
  sin importar si el hijo real los toco. Verificado en vivo reproduciendo los parametros exactos de TC10 contra
  `cob_ahorros..sp_ah_retiro_rc` (delega a `sp_ah_retirond_rc`): `return status = 31172`, `o_comision = NULL`,
  `o_base_imp = NULL` — el SP real nunca los toca antes del RETURN. Mismo patron explica TC13/14/15 (fronteras
  monetarias) y TC17/TC18 (tabla de verdad canje/impresora/cartola): todos pasan por la misma linea de
  `conCabecera` en rutas de error distintas.

  Ambos son bugs reales del microservicio, no problemas del documento QA (el documento predice correctamente
  NULL porque refleja el comportamiento verificado del SP real). Estaban enmascarados hasta hoy por el bug de
  motor `[init-cero]` (que forzaba 0.0 tambien del lado SP, ocultando la divergencia real contra el micro).
  ACCION QA: ninguna adicional — reportar a migracion. Al corregirse, relanzar la corrida de retiro para
  confirmar 19/19 EQUIVALENTE.

- [x] Cerrados (debcred, confirmados con Migracion o por decision de Banco): TC167/TC97 (rollback +
  gRPC error/debug) corregidos por Migracion; transacciones idle-in-transaction resueltas por
  Migracion; TC39/40/41 divergencia REST↔gRPC aceptada como consecuencia de decision de arquitectura
  del banco (proto sin wrappers en inputs numericos), no un defecto corregible.

---

## DEUDA MENOR (opcional, no prioritaria)

- [ ] **Concurrencia LITERAL sobre el mismo dato** (motor) — no prioritario. El paralelismo ENTRE LOTES ya existe.
  Lo que NO existe es lanzar N ejecuciones sobre la MISMA orden/cuenta en el mismo instante (race conditions).
  Para la equivalencia SP-vs-micro el resultado secuencial es suficiente. Abordar solo si se pide un escenario de carrera.

---

## RESUELTO — referencia rapida

**Historial completo `sp_debcred_empresa` (JUL-02 a JUL-22), TODO CERRADO — detalle forense en
git log de esos commits, no repetido aqui:** aislamiento cross-lote, catalogo cl_errores persistente,
comparacion 100% por diccionario, paridad literal gRPC (`-emit-defaults`), reporte HTML data-driven,
contrato nuevo NCBE-784 (envelope `data` + espanol), tolerancia acotada a defaults proto3, fix de
snapshot de 31 tablas, validacion de PRE fallido (`PRE_FAILED`), varias corridas completas hasta
94/94 EQUIVALENTE SP↔REST (91/94 REST↔gRPC por decision de banco en TC39/40/41, ver seccion
MIGRACION/BANCO). **Estado final: CERRADO, sin pendientes QA** (ver tabla "Estado actual por SP").

---

## Backups (checkpoints de seguridad)

| Ubicacion | Contenido |
|-----------|-----------|
| `project-agents/setupv2/.../sp_debcred_empresa/auto/qa_casos_pruebas_validacion_banco.md` | 198 TCs (pre-reduccion banco) |
| `project-agents/setupv2/.../pa_reca_bcobro_comi_diario_backup/` | 30 TCs validados |
| `project-agents/setupv2/.../pa_pag_brecau_bi_backup/` | 17 TCs validados |

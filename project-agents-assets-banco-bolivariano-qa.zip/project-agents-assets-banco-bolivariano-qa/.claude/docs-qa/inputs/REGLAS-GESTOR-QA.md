# Reglas del Gestor QA (Supabase)

> **Proposito:** Definir las reglas de negocio, estructura y valores permitidos de las entidades del Gestor QA (SP Migrations, Casos de Uso, Casos de Prueba, Errores/Bugs) almacenadas en Supabase.
>
> **REGLA MAESTRA (OBLIGATORIA):** Antes de realizar CUALQUIER modificacion (INSERT/UPDATE/DELETE) sobre las tablas del Gestor QA en Supabase, se DEBE leer y validar este documento. Ninguna escritura procede si viola una de estas reglas. Si una operacion solicitada contradice una regla, se detiene y se reporta al usuario en vez de ejecutar.

---

## 0. Conexion

| Variable | Descripcion |
|----------|-------------|
| `SUPABASE_PROJECT_ID` | ID del proyecto (`vquawdojjgqfzonjyhxu`) |
| `SUPABASE_URL` | `https://<project_id>.supabase.co` |
| `SUPABASE_ANON_KEY` | Key publica (lectura sujeta a RLS) |
| `SUPABASE_SERVICE_ROLE_KEY` | Key de servicio (acceso total, ignora RLS) — solo para operaciones autorizadas |

- Acceso via PostgREST: `${SUPABASE_URL}/rest/v1/<tabla>`.
- Headers obligatorios: `apikey` + `Authorization: Bearer`.
- **CONN-01:** Escrituras usan `SERVICE_ROLE_KEY` SOLO cuando el usuario lo autorizo explicitamente para esa operacion.
- **CONN-02:** Nunca exponer las keys en logs, commits ni output. El `PROJECT_ID` y la `URL` no son secretos; las keys si.

---

## 1. Modelo de datos (patron comun)

Todas las tablas siguen el mismo patron de almacenamiento:

| Columna | Tipo | Descripcion |
|---------|------|-------------|
| `id` | uuid | PK; identico a `payload.id` |
| `payload` | jsonb | Objeto de negocio completo (todos los campos funcionales) |
| `created_at` | timestamptz | Auditoria (fila) |
| `updated_at` | timestamptz | Auditoria (fila) |

- **MOD-01:** Los datos de negocio viven DENTRO de `payload` (JSONB), no en columnas planas. Toda lectura/escritura de campos funcionales se hace sobre `payload`.
- **MOD-02:** `payload.id` DEBE ser igual a la columna `id` de la fila.
- **MOD-03:** `payload.createdAt` / `payload.updatedAt` (camelCase, dentro del JSON) son los timestamps de negocio; `created_at`/`updated_at` (snake_case, columna) son de auditoria de la fila. En cada UPDATE se refresca `payload.updatedAt`.
- **MOD-04:** Los nombres de tabla son **camelCase** y sensibles a mayusculas en PostgREST: `useCases`, `testCases`, `spMigrations`. Consultar `usecases`/`use_cases` devuelve 404.

### Tablas existentes

| Tabla | Descripcion | Filas de referencia |
|-------|-------------|---------------------|
| `spMigrations` | Migraciones de SP en proceso de QA | 1 |
| `useCases` | Casos de uso | 14 |
| `testCases` | Casos de prueba | 93 |
| `bugs` | Errores/defectos | 69 |
| `members` | Equipo QA | 5 |
| `tasks` | Tareas del proyecto | 6 |
| `catalogs` | Catalogos de valores para dropdowns de la app | 2 |

> Conteos vigentes al 2026-07-02 (snapshot). Ver seccion 9 para el estado actual de valores.

---

## 2. spMigrations (SP en migracion)

**Campos de `payload`:** `id`, `spName`, `devName`, `qaId`, `status`, `notes`, `jiraKey`, `numeroLote`, `funcionalidad`, `nombreMicroservicio`, `sqlReceived`, `sqlReceivedDate`, `grpcReceived`, `grpcReceivedDate`, `restReceived`, `restReceivedDate`, `qmetryEvidenceReady`, `equivalenceMatrixReady`, `createdAt`, `updatedAt`. `jiraKey` es opcional (ej. `NCBE-1140`). `numeroLote`/`funcionalidad`/`nombreMicroservicio` son texto libre, sin catalogo ni validacion de formato en el cliente actual (ver SPM-08).

Reglas:
- **SPM-01:** `spName` es unico y corresponde al nombre real del SP Sybase (ej. `sp_debcred_empresa`).
- **SPM-02:** `qaId` DEBE referenciar un `members.id` existente.
- **SPM-03:** Campos `*Received` son boolean; si es `true`, su `*ReceivedDate` (formato `YYYY-MM-DD`) deberia estar poblado. **Observado (2026-08-11):** en `sp_ah_retiro_rc` los tres `*Received=true` tienen su `*ReceivedDate` vacio — inconsistencia real en produccion, no un valor permitido; al escribir, poblar siempre la fecha junto con el boolean.
- **SPM-04:** `status` usa el catalogo real `store=spMigrations, field=status` (ver CAT-02): `SQL recibido` | `REST/gRPC recibido` | `En QA` (label "En construccion ME") | `Matriz lista` | `Evidencia QMetry` (label "En construccion QMetry") | `En revision por banco` | `Finalizado`. Cambios de estado se coordinan con el avance real de la migracion.
- **SPM-05:** `equivalenceMatrixReady` / `qmetryEvidenceReady` son boolean y solo se marcan `true` cuando existe el artefacto real (corrida de matriz / evidencias Qmetry).
- **SPM-06 (regla de motor, agregada 2026-08-12, no viene del banco):** un `spMigrations` NO puede pasar a `equivalenceMatrixReady=true`, `qmetryEvidenceReady=true`, ni a `status` en `Matriz lista` | `Evidencia QMetry` | `En revision por banco` | `Finalizado` si tiene **0 filas en `testCases` con ese `spMigrationId`**. El motor (`gestor_qa_client.py update-sp-migration` y, desde 2026-08-13, tambien `create-sp-migration`) valida esto y bloquea la escritura; el objetivo es que la UI nunca muestre un microservicio "listo" sin ningun caso de prueba cargado. Cargar los `testCases` reales (`create-testcase`) es prerrequisito de estos hitos.
- **SPM-07 (agregada 2026-08-13):** existe `gestor_qa_client.py create-sp-migration` para registrar una fila NUEVA (antes solo se podia `update-sp-migration` sobre una fila ya existente). Valida `spName` unico (SPM-01), `qaId` existente (SPM-02) y aplica SPM-06 tambien en creacion (el `--status` inicial no puede ser uno que exija testCases, porque una fila nueva siempre tiene 0). No fabrica `*ReceivedDate` cuando no hay evidencia dura de la fecha real — quedan vacios explicitamente en vez de inventarse (ver caso real `pa_fir_consulta_condicion`/NCBE-1175).
- **SPM-08 (CORRECCION 2026-09-06, confirmada por el Manual de Usuario real fechado 2026-09-03):** `numeroLote` y `funcionalidad` son campos VIGENTES, no un cambio futuro. El Manual real muestra la seccion "Lotes y Funcionalidades" ya en produccion (17 filas reales, con filtros por lote/funcionalidad/microservicio tambien en la pestana Indicadores). La nota que antes clasificaba esto como "aun no vigente" (ver §10) estaba desactualizada y queda corregida. Alcance real de lo vigente: `numeroLote`/`funcionalidad`/`nombreMicroservicio` son atributos planos de `spMigrations`, fijables SOLO en la creacion (`create-sp-migration --numero-lote/--funcionalidad/--nombre-microservicio`); `update-sp-migration` no ofrece manera de corregirlos despues (deuda tecnica, ver §10.1). No confundir esto con la reestructuracion completa de modelo (Lote/Funcionalidad como entidades propias, jerarquia `Lote > Funcionalidad > Microservicio > SP` reemplazando las FKs de la seccion 7) — ESA si sigue sin implementarse (ver §10.2).
- **SPM-09 (aclaracion, no cambia comportamiento):** `status` y `sqlReceived`/`grpcReceived`/`restReceived` son trackers INDEPENDIENTES en el modelo actual — uno no se infiere del otro. El default de creacion (`status="SQL recibido"` con los tres `*Received=false` y sin fechas) es tecnicamente valido pese a que el nombre del status puede leerse como si implicara `sqlReceived=true`; no lo implica. Ya hay evidencia real de la independencia inversa (SPM-03: `sp_ah_retiro_rc` con los tres `*Received=true` mientras su `status` seguia en `"SQL recibido"`). No escribir codigo ni instruir al agente para que derive uno del otro.
- **SPM-10:** la app web trata `microservicio`/"Microservicio" como un valor controlado/seleccionable (dropdown poblado con los microservicios reales de "Lotes y Funcionalidades"); el cliente (`--microservicio` en `tasks`, `--nombre-microservicio` en `spMigrations`) los acepta como string libre sin cruzarlos contra los valores ya existentes. Hasta que el cliente valide esto (deuda tecnica, ver §10.1), es responsabilidad operativa del agente no inventar/normalizar esos nombres (ver TSK-11).
- **SPM-11 (CONFIRMADA por evidencia real, 2026-09-27):** `spName` se almacena SIEMPRE en formato **canonico = nombre base del procedimiento, sin prefijo de base de datos/esquema**. Verificado por lectura real de las 20 filas de `spMigrations` existentes al 2026-09-27: ninguna usa un prefijo `<base>.<owner>.<proc>`/`<base>..<proc>` — todas son el nombre bare (ej. `sp_ah_retiro_rc`, `pa_fir_consulta_firmante`, `sp_retefec_transval_rc`). Esto NO es una convencion nueva que se este proponiendo: es la convencion ya vigente, ahora documentada explicitamente. Regla de normalizacion (usada por GESTOR-QA-SPM-RESOLVE-01, §13): dado un nombre de SP en cualquier notacion Sybase (`sp_x`, `base.sp_x`, `base..sp_x`, `base.owner.sp_x`), el valor canonico es el ULTIMO componente no vacio tras separar por `.` (ej. `cob_cuentas.sp_retefec_transval_rc` -> `sp_retefec_transval_rc`; `cob_cuentas..sp_retefec_transval_rc` -> `sp_retefec_transval_rc`). La comparacion de identidad SIEMPRE se hace sobre el valor canonico, nunca sobre el string crudo de entrada. Si en el futuro aparece una fila con un valor que no siga esta convencion (ej. con prefijo real guardado), NO asumir que la convencion cambio: reportar la excepcion y pedir confirmacion antes de normalizar automaticamente ese caso.

---

## 3. useCases (Casos de Uso)

**Campos de `payload`:** `id`, `code`, `name`, `actor`, `goal`, `flow`, `observation`, `priority`, `status`, `spMigrationId`, `createdAt`, `updatedAt`.

Valores permitidos:
- `status`: **`Activo`** (unico valor observado). Otros estados requieren aprobacion del usuario antes de introducirse.
- `priority`: **`Alta` | `Media` | `Baja`**.

Reglas:
- **UC-01:** `code` sigue el patron `CU-XX` (ej. `CU-01`). Codigo sintetico permitido: `CU-ADIC` para casos adicionales sin CU formal.
- **UC-02:** `spMigrationId` DEBE referenciar un `spMigrations.id` existente.
- **UC-03:** `code` es unico dentro del mismo `spMigrationId`.
- **UC-04:** `name`, `goal` y `actor` son obligatorios (no vacios).

---

## 4. testCases (Casos de Prueba)

**Campos de `payload`:** `id`, `code`, `name`, `steps`, `expected`, `observation`, `priority`, `status`, `executionStatus`, `matrixVerdict`, `bankApproval`, `useCaseId`, `spMigrationId`, `createdAt`, `updatedAt`.

Valores permitidos:
- `status` (campo **estado** del caso): **`Borrador` | `Ejecutado` | `Listo` | `Pendiente` | `Bloqueado`**.
- `executionStatus` (campo **Ejecucion** / resultado de ejecucion): **`Exitoso` | `Fallido`** (se puebla al correr la matriz; ver TC-04/TC-06).
- `bankApproval`: **`Aprobado` | `Pendiente` | `Rechazado`**.
- `matrixVerdict` (veredicto de la matriz de equivalencia): **`EQUIVALENTE` | `NO_EQUIVALENTE` | `INCONSISTENCIA` | `SYBASE_FAIL`**.
- `priority`: **`Alta` | `Media` | `Baja`**.

### Regla de matriz de equivalencia (resumen consolidado)

Tras cada corrida de la matriz de equivalencia, por cada TC se aplica segun su veredicto:

| Veredicto matriz | estado (`status`) | Ejecucion (`executionStatus`) | Bugs del TC (`status`) |
|------------------|-------------------|-------------------------------|------------------------|
| **EQUIVALENTE** | `Listo` | `Exitoso` | `Resuelto` |
| **Distinto de EQUIVALENTE** (`NO_EQUIVALENTE` / `INCONSISTENCIA` / `SYBASE_FAIL`) | `Pendiente` | `Fallido` | `Abierto` |

Reglas:
- **TC-01:** `code` sigue el patron `TCxx` (ej. `TC25`). Unico dentro del mismo `spMigrationId`.
- **TC-02:** `spMigrationId` DEBE referenciar un `spMigrations.id` existente.
- **TC-03:** `useCaseId` DEBE referenciar un `useCases.id` existente (o el CU sintetico `CU-ADIC` para adicionales).
- **TC-04:** **Mapeo veredicto -> estado (matriz de equivalencia):**
  - `EQUIVALENTE` -> `status (estado) = "Listo"` **y** `executionStatus (Ejecucion) = "Exitoso"`. Ademas, TODOS los bugs relacionados a ese TC pasan a `status = "Resuelto"` (ver BUG-04).
  - **Cualquier veredicto distinto de `EQUIVALENTE`** (`NO_EQUIVALENTE`, `INCONSISTENCIA`, `SYBASE_FAIL`) -> `status (estado) = "Pendiente"` **y** `executionStatus (Ejecucion) = "Fallido"`. Ademas, el/los bug(s) relacionados a ese TC deben quedar en `status = "Abierto"` (ver BUG-04).
- **TC-05:** Al actualizar `status` desde una corrida de matriz, poblar `matrixVerdict` con el veredicto real de esa corrida para trazabilidad.
- **TC-06:** **Coherencia `status` (estado) vs `executionStatus` (Ejecucion):** ambos deben ser consistentes. Un TC EQUIVALENTE es `estado=Listo` + `Ejecucion=Exitoso`; un TC no equivalente es `estado=Pendiente` + `Ejecucion=Fallido`. No puede haber contradiccion (ej. `estado=Listo` con `Ejecucion=Fallido`).
- **TC-07:** Un caso `Bloqueado` (BLOCKED-INFRA) NO se marca `Exitoso`/`Fallido` hasta que la dependencia de infra este resuelta.

---

## 5. bugs (Errores / Defectos)

**Campos de `payload`:** `id`, `title`, `description`, `steps`, `severity`, `status`, `resolutionNote`, `testCaseId`, `memberId`, `spMigrationId`, `createdAt`, `updatedAt`.

Valores permitidos:
- `status`: **`Abierto` | `Resuelto` | `Cerrado`** (los tres ya en uso real en produccion). Otros estados (`En progreso`, `Rechazado`) siguen requiriendo aprobacion antes de usarse.
- `severity`: **`Alta` | `Media` | `Baja`**.

Reglas:
- **BUG-01:** `testCaseId` DEBE referenciar un `testCases.id` existente.
- **BUG-02:** `spMigrationId` DEBE referenciar un `spMigrations.id` existente.
- **BUG-03:** `memberId` DEBE referenciar un `members.id` existente (responsable del hallazgo/correccion).
- **BUG-04:** **Cierre/apertura automatica por matriz:** cuando el caso de prueba asociado queda `EQUIVALENTE` (`estado=Listo`, `Ejecucion=Exitoso`) en la ultima corrida de matriz, TODOS los bugs relacionados a ese `testCaseId` se cierran (`status = "Resuelto"`). Cuando el TC queda con veredicto distinto de EQUIVALENTE (`estado=Pendiente`, `Ejecucion=Fallido`), sus bugs deben quedar `Abierto`.
- **BUG-05:** Al cerrar (`Resuelto`) poblar `resolutionNote` indicando la corrida/matriz que lo valida (ej. `"Cerrado tras corrida ...-DD-MM-YYYY-HHMM: TC EQUIVALENTE"`).
- **BUG-06:** `title` obligatorio; convencion recomendada: iniciar con el codigo del TC afectado (ej. `TC25 - ...`).
- **BUG-07:** **Ambiguedad sin resolver (2026-08-11):** la diferencia semantica entre `Resuelto` y `Cerrado` NO esta definida formalmente en este documento. Observado: los 12 bugs con `status=Cerrado` (defectos repetitivos de paridad gRPC/REST, ej. `NCBE-785`, `NCBE-814`...) tienen `resolutionNote` vacio, violando BUG-05. No asumir un significado; si el usuario pide escribir `Cerrado`, preguntar el criterio antes de aplicar masivamente.
- **BUG-08 (soportado en el cliente desde 2026-10-21):** la app web guarda el origen de la incidencia en `payload.attributableTo` (label "Atribuible a"; valores: `Banco Bolivariano` | `Migracion Dev NYXN` | `Tester`). `create-bug` lo escribe con `--attributable-to` (validado contra esos valores), junto con `--microservicio` y `--jira-key` (mismos nombres de campo que usa la app). Completarlo siempre que se conozca el responsable. `update-bug-status` sigue sin modificarlo.
- **BUG-09 (agregada 2026-10-21):** un defecto transversal a todo el SP (ej. libreria del banco, documento de casos) se crea con `create-bug --transversal`: sin `testCaseId`, con `--sp-migration-id` obligatorio. Es excluyente con `--test-case-id`. Para defectos de UN caso concreto se mantiene BUG-01. No elegir un TC arbitrario para "encajar" un defecto transversal.

---

## 6. members / tasks / catalogs (soporte)

- **MEM-01:** `members.role` valores observados: `QA Lead`, `QA Automation`, `QA Manual`, `Analista QA`, `Project Manager`. `capacity` numerico (0-100); roles de coordinacion (`Project Manager`, `Analista QA`) pueden tener `capacity=0` legitimamente (no es un error de dato).
- **TSK-01:** `tasks.status` usa los valores del catalogo `store=tasks, field=status`: **`backlog` | `active` | `review` | `done`**. `kind` usa el catalogo `store=tasks, field=kind`: **`Prueba` | `Documentacion` | `Automatizacion` | `Correccion`** (verificado en catalogo real 2026-09-03; NO existe un valor `Tarea` pese a que algun prompt externo lo mencione como ejemplo generico — usar siempre el catalogo real, CAT-01). Campos de `payload` confirmados en BD (2026-09-03): `id`, `title`, `description`, `kind`, `status`, `priority`, `dueDate`, `memberId`, `spMigrationId`, `microservicio`, `personaAsignadaBb`, `jiraLink`, `devolucionesBb`, `devolucionesBbDescriptions`, `reviewEnteredAt`, `completedAt`, `statusHistory`, `createdAt`, `updatedAt`.
- **TSK-02:** `tasks.spMigrationId` y `tasks.memberId` deben referenciar filas existentes.
- **TSK-03 (OBLIGATORIA, vigente desde 2026-07-30):** Todo cambio de `tasks.status` DEBE registrar un comentario explicando el porque del cambio, en `payload.statusHistory` (array; cada entrada `{at: ISO-8601, from: <status previo>, to: <status nuevo>, comment: <texto obligatorio>}`). Se agrega una entrada por transicion, nunca se sobreescribe el historial previo. Se implemento a partir de la tarea `aedafc27-5fdf-4c34-9350-e15b4b021f30` ("Ajustes al gestor QA - Tablero de tareas"). No hacer un UPDATE de `status` sin agregar la entrada correspondiente a `statusHistory`.
- **TSK-04 (SUPERSEDIDA 2026-09-03 por TSK-06):** El campo pedido originalmente se llamaba `iteraciones`/`iterations`. Se renombro y se implemento como `devolucionesBb` — ver TSK-06. No usar `iterations` en ningun lugar nuevo.
- **TSK-05 (OBLIGATORIA, agregada 2026-09-02 por instruccion explicita del usuario; corregida 2026-09-27 tras caso real NCBE-1178 — ver TSK-14):** Cuando se decide crear las tareas de seguimiento de un microservicio/SP en Gestor QA — por orden explicita del usuario, o por propuesta del agente confirmada por el usuario (ver TSK-12/GESTOR-QA-HUMAN-01 en §11: registrar un `spMigrations` NO dispara esto automaticamente) — el set tiene **4 tareas base, siempre aplicables al flujo QA**, y **1 tarea condicional** (numero 5), una por microservicio:

  | # | Titulo (patron) | `kind` | `priority` | Link requerido (campo `jiraLink`) | Aplicabilidad |
  |---|---|---|---|---|---|
  | 1 | Validacion de TCs - `<microservicio>` | `Prueba` | `Alta` | URL de la **subtarea** Jira | Siempre aplicable |
  | 2 | Generacion de ME - `<microservicio>` | `Prueba` | `Alta` | URL de la **subtarea** Jira | Siempre aplicable |
  | 3 | Generacion de QMetry - `<microservicio>` | `Documentacion` | `Media` | URL de la **tarea principal** Jira | Siempre aplicable |
  | 4 | Cargar TCs en Gestor QA - `<microservicio>` | `Automatizacion` | `Media` | URL de la **tarea principal** Jira | Siempre aplicable |
  | 5 | Generacion de Queryplan - `<microservicio>` | `Documentacion` | `Media` | Confluence (manual, sin ticket Jira) | **CONDICIONAL — ver TSK-14** |

  **No renombrar "TSK-05" por compatibilidad documental**, pero el nombre ya NO implica "siempre 5 tareas idénticas": implica "1-4 siempre aplicables + 5 solo cuando corresponda". Cualquier tarea adicional/complementaria a las aplicables (correcciones puntuales, seguimientos, etc.) usa `priority=Baja` salvo que el usuario indique otra cosa explicitamente para ese caso.

  **Actualizado 2026-09-03:** ya existe el campo estructurado `jiraLink` en `tasks.payload` (confirmado en produccion, ver TSK-01) — usarlo para los items 1-4 en vez de la convencion de texto `Link: <url>` en `description` que se documento el 2026-09-02 (obsoleta). **Pendiente sin resolver:** `jiraLink` es especifico de Jira; el item 5 (Queryplan) usa Confluence y no tiene campo estructurado propio todavia — hasta que se cree uno, seguir usando `Link: <url>` en la primera linea de `description` solo para ese caso, y preguntarle al usuario si prefiere otro tratamiento.

  **Informacion minima obligatoria en cada tarea aplicable que se cree (aplica tambien como buena practica a cualquier tarea nueva):**
  1. **Link** de la tarea: campo `jiraLink` para items 1-4; `Link: <url>` en `description` para el item 5 (Confluence, ver nota arriba) — SOLO si el item 5 aplica (ver TSK-14).
  2. **`dueDate`** (fecha de planeacion o finalizacion estimada) — sigue aplicando AGENTE-01: si el usuario no la da, se pregunta antes de crear, nunca se deja vacia por asuncion propia.
  3. **Descripcion real** de la tarea: que se esta validando/generando/cargando y para que SP/microservicio (no un texto generico).

  Si al crear alguna tarea aplicable falta el link, se pregunta explicitamente antes de crear (mismo tratamiento que la fecha de AGENTE-01) — nunca se crea la tarea con el link vacio o inventado.
- **TSK-06 (OBLIGATORIA, implementada en produccion 2026-09-03, valida por instruccion explicita del usuario):** `devolucionesBb` (entero) reemplaza a `iterations`/`iteraciones` (TSK-04, superseded). Representa cuantas veces Banco devolvio el entregable de esa tarea. **Regla dura:** si `devolucionesBb > 0`, `devolucionesBbDescriptions` (array de strings) DEBE tener exactamente esa cantidad de elementos, uno por cada devolucion, cada uno con texto real (no vacio) — sin eso la tarea NO se puede guardar. El script (`gestor_qa_client.py`) valida esto en `create-task`/`update-task` y bloquea si no coincide. Nunca inventar el texto de una devolucion que no se conoce; si falta, preguntar al usuario o dejar la tarea sin crear/actualizar ese campo.
- **TSK-07 (OBLIGATORIA, implementada en produccion 2026-09-03, valida contra datos reales — ver tarea `50c3458b-...` "Implementar pestaña KPIs...", `reviewEnteredAt`="completedAt"=2026-09-03T20:48:37.946Z tras `active->review`):** Al pasar `tasks.status` a `review`, se registra `reviewEnteredAt` (fecha/hora real de entrada a revision) y `completedAt` toma el mismo valor. **Eficiencia NO se mide por `status=done`/`updatedAt`: se mide desde `reviewEnteredAt`.** "A tiempo" = `reviewEnteredAt <= dueDate`. Una tarea que nunca pasa por `review` (va directo a `done`) no tiene `reviewEnteredAt` y por tanto no cuenta como entregada a tiempo para Eficiencia, aunque su `status` sea `done` — esto es intencional (formaliza el hallazgo de proceso ya documentado en `KPIs_Agosto_QA.md`/`KPIs_QA_Simplificado.md` sobre tareas que se saltan `review`). El script auto-popula estos 2 campos en `update-task-status --to review`; no se escriben a mano ni se backdatean. **Confirmado por el Manual de Usuario real (2026-09-03):** la formula oficial de la app es `Eficiencia (%) = (tareas que entraron a "En revision" a tiempo / tareas planeadas del periodo) x 100`, y las formulas de `Calidad`/`Eficacia` de esa misma app dependen directamente de las tareas `kind="Correccion"` del periodo (ver §12, KPI Safety).
- **TSK-08 (ESTANDAR OPERATIVO, agregada 2026-09-06; ajustada 2026-09-27 para tareas condicionales — mitiga la ausencia de deduplicacion en `create-task`, ver deuda tecnica §10.1):** antes de crear cualquiera de las tareas APLICABLES de TSK-05 (ver TSK-14 para determinar si la tarea 5 aplica), seguir siempre el protocolo `READ -> DECIDE -> CREATE`:
  1. Resolver el `spMigrations` correspondiente aplicando **GESTOR-QA-SPM-RESOLVE-01** (ver §13): usar `find-sp-migration` solo para descubrir candidatos y verificar `spName` EXACTO (case-insensitive) antes de reutilizar cualquier `spMigrationId`; crear uno nuevo (`create-sp-migration`) solo si 0 candidatos coinciden exacto y la creacion esta autorizada (GESTOR-QA-HUMAN-01); si hay mas de 1 candidato exacto o la resolucion es ambigua, detenerse aqui y reportar para revision humana antes de continuar con los pasos siguientes.
  2. Consultar las `tasks` ya vinculadas a ese `spMigrationId` (`get tasks --filter "payload->>spMigrationId=eq.<id>"`).
  3. Comparar por `spMigrationId` + titulo canonico EXACTO (los titulos de la tabla de TSK-05 con `<microservicio>` ya sustituido, solo para las tareas que correspondan segun TSK-14/TSK-15). El mismo titulo bajo otro `spMigrationId` NO cuenta como existente.
  4. Decidir segun el resultado, aplicando el conteo generalizado de TSK-15 (`TAREAS_APLICABLES_ESPERADAS` vs `TAREAS_APLICABLES_EXISTENTES`, NO un conteo rigido "sobre 5"):
     - 0 de las aplicables encontradas -> crear todas las aplicables.
     - Algunas aplicables encontradas -> crear UNICAMENTE las aplicables faltantes; nunca recrear las que ya existen.
     - Todas las aplicables encontradas -> no crear nada; reportar al usuario que TSK-05 ya esta completa para ese SP (dentro del universo aplicable determinado).
     - Mas de una coincidencia para el mismo titulo canonico -> NO mutar nada; reportar el posible duplicado para revision humana (ver TSK-13 — nunca usar `delete-task` para resolverlo por cuenta propia).
     - Antes de declarar una tarea "faltante", revisar si existe una `LEGACY_EQUIVALENT_TASK` (TSK-16) para esa misma actividad bajo el mismo `spMigrationId`; si existe evidencia fuerte, no crear una segunda tarea solo para normalizar el titulo — reportar para decision humana.

  Esta regla es una mitigacion operativa mientras `gestor_qa_client.py` no ofrezca deduplicacion en codigo; no sustituye una futura validacion tecnica.
- **TSK-09 (ESTANDAR OPERATIVO, no CONTRATO_TECNICO):** el contrato generico de `tasks` permite `spMigrationId` vacio (TSK-02 solo exige que, SI se pasa, sea valido). El ESTANDAR OPERATIVO de TSK-05 exige, ademas, vincular las tareas APLICABLES al `spMigrationId` real del microservicio/SP — por trazabilidad, aislamiento entre SPs, soporte del preflight de idempotencia (TSK-08) y para evitar mezclar lotes/funcionalidades distintos. Esto NO cambia el contrato tecnico de `create-task`/`update-task` (el flag sigue siendo opcional a nivel de codigo); es una obligacion de proceso que el agente debe cumplir siempre al ejecutar TSK-05.
- **TSK-10 (ESTANDAR OPERATIVO, no CONTRATO_TECNICO):** toda tarea de TSK-05 debe tener un responsable QA (`memberId`) valido, resuelto con `find-member` antes de crear. El contrato tecnico actual NO exige `--member-id` (el script no lo marca `required` ni bloquea su ausencia, ver SPM-02/TSK-02 sobre la misma brecha en `qaId`) — no documentar ni asumir lo contrario. La obligacion de tener responsable es de proceso, no una validacion que el cliente aplique hoy.
- **TSK-11 (ESTANDAR OPERATIVO, ver SPM-10):** hasta que el cliente valide `microservicio` contra los valores reales de "Lotes y Funcionalidades" (deuda tecnica §10.1), el agente NO debe inventar, abreviar ni normalizar por su cuenta el nombre de un microservicio. Debe obtenerlo de una fuente verificable: el `spMigrations` ya registrado (`nombreMicroservicio`/`spName`), un dato explicito del usuario, un contexto Jira inequivoco, u otra fuente tecnica verificable. Si hay mas de un candidato razonable, preguntar en vez de elegir.
- **TSK-12 (ESTANDAR OPERATIVO — human-in-the-loop, ver GESTOR-QA-HUMAN-01 en §11):** que exista un `spMigrations` nuevo NO autoriza al agente a inferir por si solo que debe crear sus 5 tareas de TSK-05. Debe crearlas solo cuando el usuario lo ordena explicitamente ("crea las TSK-05 para X") o cuando el agente detecta la oportunidad, la propone brevemente, y el usuario confirma. Una vez hay orden u confirmacion, el agente ejecuta el preflight TSK-08 sin volver a preguntar los datos ya suministrados.
- **TSK-13 (ESTANDAR OPERATIVO):** `delete-task` esta fuera del alcance de autonomia del agente (su propio `--help` ya lo indica: "MANUAL/humano-en-el-loop, no expuesto a la autonomia del agente"). El agente nunca debe borrar una tarea por decision propia. Un duplicado detectado (TSK-08) se reporta para revision humana; nunca se resuelve borrando.
- **TSK-14 (OBLIGATORIA, agregada 2026-09-27 tras caso real NCBE-1178):** la tarea 5 (`Generacion de Queryplan - <microservicio>`) es **CONDICIONAL**, no universal. Query Plan pertenece conceptualmente a la unidad/libreria elegible sobre la que corre el pipeline de Query Plan — no a cualquier microservicio por el solo hecho de tener un `spMigrations`/una Matriz/una HU. Casos reales conocidos donde NO aplica al microservicio como tarea independiente: el microservicio es un micro de libreria y Query Plan pertenece a la libreria subyacente (ej. NCBE-1178/`cpas-mso-retefec_transval_rc` — Query Plan = `NO_APLICA` para este alcance). Reglas:
  - NO se infiere aplicabilidad solo porque exista un microservicio, un SP, una Matriz o una HU.
  - Si el alcance es un micro de libreria y Query Plan pertenece a la libreria subyacente: NO crear la tarea 5 para el micro.
  - Si la aplicabilidad no puede determinarse con evidencia (ej. no se sabe si el micro es standalone o pertenece a una libreria con Query Plan propio): preguntar a Gengis/al usuario. Nunca crearla "por si acaso".
  - Cuando se determina `NO_APLICA`: la tarea 5 NO debe crearse, NO debe quedar pendiente, NO requiere `dueDate`, y su ausencia NO debe reportarse como bloqueo para completar las tareas 1-4 del microservicio ni como "TSK-05 incompleta".
  - Cuando se determina aplicable: sigue el contrato normal de TSK-05 (titulo, `kind=Documentacion`, `priority=Media`, link Confluence o `PENDIENTE`).
- **TSK-15 (OBLIGATORIA, agregada 2026-09-27):** el preflight de TSK-08 NO debe depender rigidamente de un conteo fijo "sobre 5" (`0/5`, `1-4/5`, `5/5`). Debe evaluar conceptualmente:
  - `TAREAS_APLICABLES_ESPERADAS`: las tareas base 1-4 siempre, mas la tarea 5 SOLO si TSK-14 determino que aplica a esa unidad concreta.
  - `TAREAS_APLICABLES_EXISTENTES`: las que ya existen (canonicas o `LEGACY_EQUIVALENT_TASK` confirmadas, ver TSK-16) para ese `spMigrationId`.
  - La ausencia de una tarea marcada `NO_APLICA` (tipicamente la 5) nunca cuenta como faltante ni como "TSK-05 incompleta" — el universo esperado para ese alcance simplemente tiene menos de 5 elementos.
- **TSK-16 (OBLIGATORIA, agregada 2026-09-27 — evita KPI pollution por matching difuso):** una tarea con titulo distinto al patron canonico de TSK-05 puede ser una `LEGACY_EQUIVALENT_TASK` (creada antes de que TSK-05 estandarizara los titulos, 2026-09-02) que representa en sustancia la misma actividad que uno de los items canonicos (ej. "Generar Matriz de Equivalencia - `<sp>`" vs "Generacion de ME - `<microservicio>`"). Reglas:
  - Reconocerla como equivalente exige **evidencia fuerte**, no solo "se parece": mismo `spMigrationId`, mismo `kind` esperado para ese item, y el titulo/descripcion referencian inequivocamente la misma actividad (ej. contiene "Matriz de Equivalencia"/"ME" para el item 2), idealmente creada antes de 2026-09-02.
  - El agente **NUNCA decide por si solo** que una tarea legacy satisface un item canonico y por tanto omite reportarla: siempre debe reportarla como `LEGACY_EQUIVALENT_CANDIDATE` para confirmacion humana antes de tratarla como "existente" a efectos de KPI/preflight.
  - Prohibido generalizar esto a matching difuso sin control (ej. comparar por similitud de texto entre cualquier par de titulos) — el criterio de evidencia fuerte de arriba es la unica base aceptada.
  - Mientras no haya confirmacion humana, NO crear una segunda tarea canonica solo para "normalizar" el titulo (evita duplicar en sustancia el mismo trabajo, ver GESTOR-QA-KPI-01), y tampoco renombrar la legacy por cuenta propia.
- **TSK-17 (OBLIGATORIA, agregada 2026-09-27 tras caso real NCBE-1178 — ver tambien §14 "Devoluciones BB"):** el estado general de un microservicio/SP ("esta en revision", "esta en revalidacion") es independiente de `devolucionesBb`. Un bug/Defecto Jira, un comentario, una observacion, una correccion, una revalidacion, o un estado Jira `Testing BB`/`Done` **NO son, por si mismos, una Devolucion BB**. Ver §14 para el criterio completo.
- **CAT-01:** `catalogs` define los valores validos que la app muestra en dropdowns (`store` = tabla destino, `field` = campo, `items[]` = `{label,value}`). Si se agrega un nuevo valor de enum a una entidad, debe reflejarse tambien en el `catalog` correspondiente para que la UI lo reconozca.
- **CAT-02:** Catalogos existentes en la BD (5, verificado 2026-08-11):
  - `store=tasks, field=status`: `backlog` (Pendiente) | `active` (En progreso) | `review` (En revision) | `done` (Finalizado).
  - `store=tasks, field=kind`: `Prueba` | `Documentacion` | `Automatizacion` | `Correccion`.
  - `store=testCases, field=status`: `Listo` (Listo) | `Bloqueado` (etiqueta mostrada "Pendiente"). **Nota:** en este catalogo el `value` guardado para un TC no equivalente es `Bloqueado` mientras que su `label` visible es "Pendiente". La regla TC-04 usa el termino de negocio "Pendiente"; al escribir en BD validar contra el catalogo real de `testCases.status` para no romper la UI.
  - `store=members, field=role`: `QA Manual` | `QA Automation` | `QA Lead` | `Analista QA` | `Project Manager`.
  - `store=spMigrations, field=status`: ver SPM-04 (7 valores, incluye labels distintos al `value` guardado en 2 casos: `En QA`->"En construccion ME", `Evidencia QMetry`->"En construccion QMetry").

---

## 7. Integridad referencial (resumen)

```
spMigrations (1) ──< useCases      (spMigrationId)
spMigrations (1) ──< testCases     (spMigrationId)
spMigrations (1) ──< bugs          (spMigrationId)
spMigrations (1) ──< tasks         (spMigrationId)
useCases     (1) ──< testCases     (useCaseId)
testCases    (1) ──< bugs          (testCaseId)
members      (1) ──< bugs          (memberId)
members      (1) ──< tasks         (memberId)
members      (1) ──< spMigrations  (qaId)
```

- **REF-01:** Ninguna escritura puede dejar un FK apuntando a un id inexistente.
- **REF-02:** No borrar una fila padre si tiene hijos que la referencian (borrar/reasignar hijos primero).

---

## 8. Protocolo de escritura (checklist obligatorio)

Antes de cualquier INSERT/UPDATE/DELETE en el Gestor QA:

1. **Leer este documento** (REGLA MAESTRA).
2. Verificar que el usuario **autorizo** la escritura para esa operacion concreta.
3. Validar **valores de enum** (`status`, `severity`, `priority`, `bankApproval`, `matrixVerdict`) contra las secciones 3-6.
4. Validar **integridad referencial** (seccion 7): todo `*Id` apunta a una fila existente.
5. Validar **coherencia de estados** (TC-04, TC-06, BUG-04).
6. Preservar el patron `payload` (MOD-01..MOD-04) y refrescar `payload.updatedAt`.
7. Tras escribir, **verificar** el resultado con una lectura de control.
8. Si algo contradice una regla: **detener y reportar**, no forzar.

---

## 9. Snapshot del estado actual en BD (2026-08-11)

Valores realmente presentes en Supabase a la fecha (para referencia; no reemplazan a las secciones 2-6, que definen los valores permitidos). Snapshot anterior (2026-07-02) quedo obsoleto en varios puntos — ver diffs marcados en las secciones 2, 5 y 6.

**spMigrations (5):** `sp_debcred_empresa` (Finalizado), `pa_fir_consulta_fir_especial` (SQL recibido), `pa_fir_consulta_firmante` (SQL recibido), `sp_ah_retiro_rc` (SQL recibido), `sp_ah_depositosl_rc` (SQL recibido).

**useCases (33):**
- `status`: `Activo` (33).

**testCases (154)** — distribuidas entre 4 de los 5 SPs (`pa_fir_consulta_fir_especial` aun sin TCs en esta tabla):
- `status` (estado): `Listo` (151), `Bloqueado` (3).
- `executionStatus` (Ejecucion): `Exitoso` (151), `Fallido` (3).
- `matrixVerdict`: `EQUIVALENTE` (151), `INCONSISTENCIA` (3).
- `bankApproval`: `Aprobado` (151), `Pendiente` (3).

**bugs (125):**
- `status`: `Resuelto` (113), `Cerrado` (12) — ver BUG-07 (ambiguedad sin resolver).
- `severity`: `Media` (102), `Alta` (22), `Baja` (1).

**members (7):**
- `role`: `QA Automation` (3), `QA Lead` (1), `QA Manual` (1), `Analista QA` (1), `Project Manager` (1).
- `status`: `Disponible` (7).

**tasks (51):**
- `status`: `done` (28), `backlog` (14), `review` (5), `active` (4).
- `kind`: `Documentacion` (24), `Prueba` (20), `Automatizacion` (7), `Correccion` (0, definido en catalogo pero sin uso aun).
- `statusHistory` con comentario (TSK-03): presente en 15/51 tareas (las creadas/actualizadas desde 2026-07-30 en adelante).
- `iteraciones` (TSK-04): 0/51 — campo aun no implementado.

**catalogs (5):** `tasks.status`, `tasks.kind`, `testCases.status`, `members.role`, `spMigrations.status` (ver CAT-02).

---

## 10. Deuda tecnica y cambios pendientes conocidos

Estos puntos se registran para trazabilidad; **ninguno se implementa junto con esta actualizacion** (es documentacion, no tooling). No se tratan como bugs urgentes ni como excusa para incumplir una regla vigente — son la base para tareas tecnicas separadas cuando se decida abordarlas.

### 10.1 Deuda tecnica del cliente (`gestor_qa_client.py`)

| Item | Clasificacion | Detalle |
|---|---|---|
| Deduplicacion de `create-task` | TOOLING_GAP | no existe chequeo de titulo/spMigrationId repetido (a diferencia de SPM-01 en `create-sp-migration` y TC-01 en `create-testcase`); mitigado hoy solo por el protocolo operativo TSK-08. |
| Actualizacion posterior de `sqlReceived` | TOOLING_GAP | `update-sp-migration` no tiene `--sql-received` (si tiene `--grpc-received`/`--rest-received`); una vez creado, `sqlReceived` queda congelado. |
| Soporte de `atribuibleA` en bugs | RESUELTO 2026-10-21 | `create-bug --attributable-to` escribe `attributableTo` (BUG-08). |
| Validacion de `microservicio` contra valores reales | CONTRACT_GAP | la app web usa un selector controlado; el cliente acepta string libre sin cruzarlo contra `spMigrations` existentes (ver SPM-10/TSK-11). |
| Mutabilidad de `spMigrations` post-creacion | TOOLING_GAP | `spName`, `qaId`, `devName`, `jiraKey`, `numeroLote`, `funcionalidad`, `nombreMicroservicio` no son actualizables hoy via `update-sp-migration`. |
| Trazabilidad de reasignaciones (`memberId` en `tasks`) | DATA_GOVERNANCE_RISK | `update-task --member-id` reasigna sin dejar rastro historico (`statusHistory` solo cubre `status`, TSK-03); la atribucion de KPI usa el `memberId` actual, no el original (ver GESTOR-QA-KPI-04 en §12). |
| Tests automatizados de `gestor_qa_client.py` | TOOLING_GAP | no existe carpeta `tests/` para este cliente, a diferencia de otros modulos del repo (qmetry, queryplan, uml_gen, etc.). |
| Bugs que afectan multiples TCs o son transversales (todos los TCs de un SP) | PARCIAL 2026-10-21 | transversal resuelto con `create-bug --transversal` (BUG-09); multi-TC nombrado (subconjunto de TCs) sigue sin modelo. |

### 10.2 Cambios de modelo de datos aun pendientes (backlog en `tasks` del propio Gestor QA)

**Correccion 2026-09-06:** el Manual de Usuario real (fechado 2026-09-03) confirma que la seccion "Lotes y Funcionalidades" y los campos `numeroLote`/`funcionalidad` de `spMigrations` **ya estan vigentes en produccion** (ver SPM-08) — la nota que antes clasificaba esto como "aun no vigente" estaba desactualizada y queda corregida por este documento. Lo que **si sigue pendiente** es la reestructuracion completa de modelo (Lote/Funcionalidad como entidades propias, con jerarquia `Lote > Funcionalidad > Microservicio > SP` reemplazando las FKs de la seccion 7) — eso continua en `backlog` (tarea `b41cbae9...`).

Otros pendientes sin cambios frente al snapshot anterior (ninguno activo hoy; confirmar en Supabase que la tarea correspondiente paso a `status=done` antes de tratarlos como regla vigente):

- **Eliminar campos** `sqlReceived`/`grpcReceived`/`restReceived` (+ sus `*ReceivedDate`) de `spMigrations` (tarea `6356fb3b...`, status `backlog`) — consecuencia de la reestructuracion de la seccion anterior, aun no aplica.
- **Reasignar `tasks`/`testCases`/`bugs` a Microservicio** en vez de a SP (tarea `f18d98cc...`, status `backlog`).
- **Eliminar el modulo de Casos de Uso** (`useCases`) de la app por completo (tarea `a4ffe6f5...`, status `backlog`).
- **Deprecar la sustitucion de datos propios** por datos de banco en `agente-qa-auto-02-test-cases-validator` y `agente-qa-auto-03-test-cases-corrector` (tarea `8dd7a62d...`, status `backlog`) — cambio de estandar del banco, no afecta al Gestor QA en si pero si al pipeline que alimenta `testCases`.

---

## 11. Autonomia y confirmacion humana (agente)

**GESTOR-QA-HUMAN-01 (OBLIGATORIA, agregada 2026-09-06):** detectar que un evento tecnico PODRIA justificar una mutacion en Gestor QA (crear una tarea, cambiar su estado, convertirla en bug, actualizar un hito de `spMigrations`, etc.) NO autoriza automaticamente esa mutacion. El agente debe distinguir siempre entre:

- **A. Solicitud explicita de mutacion:** el usuario ya pidio la accion concreta y dio (o el agente ya resolvio) todos los datos necesarios. La orden explicita autoriza la mutacion solicitada y las operaciones auxiliares estrictamente necesarias para ejecutarla de forma segura (resolver referencias, preflights read-only, etc.) — el agente NO debe volver a preguntar lo que ya fue suministrado explicitamente. **Esa autorizacion NO se extiende a otras mutaciones descubiertas durante la operacion**: cualquier mutacion distinta a la pedida (aunque parezca util o relacionada) vuelve a ser tipo B y exige su propia confirmacion.
- **B. Oportunidad detectada de actualizar Gestor QA:** el agente nota, por iniciativa propia, que algo en el trabajo en curso (una Matriz cerrada, un Query Plan BANK_READY, un hallazgo tecnico, un duplicado encontrado, un registro que "de paso" convendria corregir) podria justificar crear/actualizar algo en Gestor QA, pero el usuario no lo pidio explicitamente para ese caso puntual. Aqui el agente NUNCA muta directamente: informa brevemente la oportunidad y pide confirmacion.

Ejemplo de alcance de una orden explicita (A) — "Crea las TSK-05 para `<microservicio>`":

- **SI autoriza:** resolver `member`; resolver o reutilizar el `spMigrations`; ejecutar el preflight read-only (TSK-08); crear UNICAMENTE las tareas faltantes de TSK-05; reportar el resultado.
- **NO autoriza por si sola:** borrar duplicados (`delete-task`, ver TSK-13); modificar tareas existentes no solicitadas; cambiar `dueDate` de una tarea ya creada; reasignar responsables (`--member-id`); cambiar `kind`/`priority` de algo ya existente; corregir otros registros que el agente encuentre de paso. Cualquiera de estas acciones, aunque parezca una consecuencia natural de la orden, requiere su propia confirmacion (tipo B).

Otros ejemplos de B (no exhaustivos):
- "La Matriz quedo cerrada y existe una tarea relacionada en Gestor QA. ¿Quieres que revise/actualice esa tarea?"
- "Query Plan quedo BANK_READY y hay una tarea 'Generacion de Queryplan'. ¿Quieres que la revise y, si corresponde, la pase al siguiente estado?"
- Que exista un `spMigrations` nuevo no implica crear sus 5 tareas de TSK-05 automaticamente (ver TSK-12).
- Leer un ticket/HU de Jira para completar contexto NO autoriza por si solo crear/modificar nada en Gestor QA — la lectura es libre, la escritura sigue exigiendo la distincion A/B de arriba (ver detalle operativo en `agente-gestor-qa.md`, seccion "Jira como fuente operativa").

Una vez el usuario confirma una accion de tipo B, esa mutacion puntual queda autorizada igual que una de tipo A — se ejecuta con sus operaciones auxiliares estrictamente necesarias, sin volver a preguntar lo ya confirmado —, y la misma restriccion aplica: la confirmacion no se extiende a mutaciones distintas a la confirmada.

---

## 12. KPI Safety (agente)

El Manual de Usuario real (2026-09-03) confirma que los KPIs mensuales de la app (Eficiencia/Calidad/Eficacia) se calculan sobre `tasks` cuyo `dueDate` cae en el periodo seleccionado, que Eficiencia depende de `reviewEnteredAt` vs `dueDate` (TSK-07), y que las tareas `kind="Correccion"` descuentan Calidad y Eficacia directamente en esas formulas (puntos por prioridad: Alta=3, Media=2, Baja=1). Por tanto, toda escritura del agente sobre `tasks` debe respetar:

- **GESTOR-QA-KPI-01:** nunca crear tareas duplicadas (ver TSK-08), incluyendo duplicados en sustancia bajo un titulo no canonico (ver TSK-16, `LEGACY_EQUIVALENT_TASK`). Un duplicado infla el denominador "tareas planeadas del periodo" de las 3 formulas para quien tenga asignada la tarea.
- **GESTOR-QA-KPI-02:** nunca cambiar `dueDate`, `memberId`, `kind`, `priority` o `status` como efecto colateral de otra operacion. Cada uno de estos campos solo se modifica cuando es exactamente lo que el usuario pidio.
- **GESTOR-QA-KPI-03:** usar `kind="Correccion"` unicamente cuando la tarea represente una correccion real (un entregable devuelto/rechazado). No usarlo por conveniencia de clasificacion.
- **GESTOR-QA-KPI-04:** antes de reasignar una tarea existente (`update-task --member-id`), avisar al usuario que la reasignacion puede alterar la atribucion operativa/KPI historica de esa tarea (la app atribuye KPI al `memberId` ACTUAL, no al autor original — ver deuda tecnica §10.1) y pedir confirmacion explicita antes de ejecutar.

---

## 13. Resolucion segura de spMigrationId (agente)

**GESTOR-QA-SPM-RESOLVE-01 (OBLIGATORIA, agregada 2026-09-06; corregida 2026-09-27 tras caso real NCBE-1178 — endurece TSK-08/TSK-09):** `find-sp-migration --sp-name` hace busqueda por SUBSTRING case-insensitive (confirmado en el codigo de `gestor_qa_client.py`), no por igualdad — dos SPs con nombres parecidos (ej. `sp_ah_retiro_rc` vs `sp_ah_retiro_rc_v2`, o cualquier nombre que comparta el substring buscado) pueden aparecer juntos en el resultado. Ademas, el SP solicitado puede llegar en notacion Sybase con prefijo de base/esquema (ej. `cob_cuentas.sp_retefec_transval_rc`) mientras que `spMigrations.spName` se guarda siempre en formato canonico sin prefijo (ver SPM-11) — comparar el string crudo de entrada contra el string crudo almacenado produce falsos "0 exactas" incluso cuando es inequivocamente el mismo SP. El procedimiento correcto:

1. Recibir el SP solicitado (en cualquier notacion).
2. Normalizarlo al formato canonico de SPM-11 (ultimo componente no vacio tras separar por `.`).
3. Usar `find-sp-migration` UNICAMENTE para descubrir candidatos; nunca para resolver directamente un `spMigrationId` a reutilizar.
4. Normalizar tambien el `payload.spName` de cada candidato devuelto (defensivo — hoy deberia ya venir canonico segun SPM-11, pero no asumirlo sin verificar).
5. Comparar **igualdad EXACTA case-insensitive** entre el valor canonico solicitado y el valor canonico de cada candidato. Prohibido comparar substrings o valores no normalizados.
6. Cuando haya cualquier duda o mas de un candidato con el mismo valor canonico, validar contexto adicional disponible (`jiraKey`, `nombreMicroservicio`, `numeroLote`, `funcionalidad`, `notes`) para robustecer o desambiguar la decision — nunca para sustituir la comparacion exacta del paso 5.
7. **0 coincidencias exactas (sobre el valor canonico)** entre los candidatos: seguir el flujo vigente de creacion (`create-sp-migration`), UNICAMENTE si esta autorizado (orden explicita del usuario o propuesta+confirmacion, ver GESTOR-QA-HUMAN-01).
8. **1 coincidencia exacta (sobre el valor canonico):** reutilizar ese `spMigrationId`.
9. **Mas de 1 coincidencia exacta, o resolucion ambigua incluso despues de revisar el contexto del paso 6:** NO mutar nada; reportar la ambiguedad y pedir resolucion humana.

Prohibido en cualquier paso: elegir la primera coincidencia sin verificar; aceptar substring como identidad; considerar dos procedimientos distintos equivalentes solo porque comparten una parte del nombre; comparar el string crudo de entrada sin normalizar contra `spName` cuando ambos podrian estar en notaciones distintas.

**Si la normalizacion de SPM-11 no puede aplicarse con confianza** (ej. aparece una notacion Sybase no contemplada, o una fila real que no sigue la convencion documentada): NO inventar una regla de normalizacion ad-hoc para ese caso — reportar el bloqueo y pedir resolucion humana, igual que con cualquier otra ambiguedad de esta regla.

Esta regla se aplica en cualquier punto donde el agente resuelva un `spMigrationId` a partir de un nombre en lenguaje natural — en particular, es parte obligatoria del paso 1 del preflight `READ -> DECIDE -> CREATE` de TSK-08 (no un paso adicional aparte), y sostiene la garantia de aislamiento entre SPs que exige TSK-09.

---

## 14. Devoluciones BB (criterio de evento real)

**Motivador:** durante la carga real de NCBE-1178, se identifico un patron recurrente en los "Defecto" de Jira asociados al SP: alguien reporta una novedad sobre un caso de prueba, el QA responsable investiga/ajusta/explica, el reportante revalida, y el ticket se cierra (`Done`) o queda `Testing BB`. Ese patron, por si solo, **no es evidencia de una Devolucion BB** — confundirlo con una lo seria habria inflado artificialmente `devolucionesBb` sin una base real.

- **DEV-01 (OBLIGATORIA):** una Devolucion BB es un **evento real y demostrable** donde, DESPUES de una entrega/revision del trabajo QA, **Banco** (no un integrante del propio equipo QA/migracion, ni un ida-y-vuelta normal de validacion interna) devuelve, rechaza, o solicita explicitamente correccion/retrabajo, o exige una nueva entrega por incumplimiento observado. El conteo es **por evento real de devolucion**, nunca "1 bug = 1 devolucion", "1 comentario = 1 devolucion", ni "1 cambio de estado = 1 devolucion".
- **DEV-02 (OBLIGATORIA):** los siguientes hechos, POR SI SOLOS, **NUNCA** constituyen evidencia de Devolucion BB: la existencia de un bug/Defecto Jira; un comentario; una observacion; una correccion aplicada; una revalidacion; un estado Jira `Testing BB`; un estado Jira `Done`; cualquier intercambio de mensajes entre QA y quien reporto. Estos hechos pueden coexistir con "Devoluciones BB = 0" para el mismo ciclo, y de hecho es el caso normal de un ciclo QA sano (reportar -> corregir -> validar -> cerrar, sin que Banco haya rechazado nada todavia).
- **DEV-03 (OBLIGATORIA):** para poder registrar `devolucionesBb > 0` con evidencia (no solo para decidir no tocarlo), el agente necesita poder responder que si a esta pregunta especifica: **"¿existio, DESPUES de una entrega/revision, un evento explicito posterior donde Banco devolvio/rechazo/solicito correccion?"** — no "¿el actor que reporto pertenece a Banco?" (esa pregunta de afiliacion es insuficiente por si sola y no hace falta resolverla si la respuesta a la pregunta principal ya es claramente "no", como confirmo Gengis para NCBE-1178 el 2026-09-27: bugs ya atendidos, Matriz disponible para revision, Banco aun no ha devuelto nada tras esa entrega).
- **DEV-04 (aclaracion, evita otra confusion real):** el estado general de un microservicio/SP en el proceso (ej. "esta en revision", "esta en revalidacion") es independiente del `status` de los bugs Jira asociados. Un SP puede estar "en revision" con bugs en `Done`/`Testing BB`/cualquier otro status de Jira sin contradiccion — no crear una regla automatica de mapeo `bug.status -> devolucion` ni `bug.status -> estado del proceso`. Gestor QA usa su propio catalogo/contrato (`tasks.status`, `bugs.status`) para eso, no el status de Jira.
- **Como reportar cuando no hay certeza:** si la evidencia no permite responder DEV-03 con seguridad, el agente NO modifica `devolucionesBb` y reporta la situacion como candidata (Jira, fecha, evidencia, motivo de duda) para que un humano decida — igual tratamiento que cualquier otra ambiguedad de este documento (REGLA MAESTRA, §8).

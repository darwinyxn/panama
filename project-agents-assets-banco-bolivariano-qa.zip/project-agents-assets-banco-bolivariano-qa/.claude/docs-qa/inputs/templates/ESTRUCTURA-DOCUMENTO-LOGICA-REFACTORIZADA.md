# Estructura del Documento de Logica del Codigo Refactorizado (Documento B)

> **document_type canonico:** `REFACTORED_CODE_LOGIC`
> **schema_version:** `1.0`
> **Escribe este documento:** el futuro `agente-qa-doclogica-01-refactored-library` (NO existe aun).
> **Fuente de verdad del render:** el modelo JSON validado contra
> `scripts/doclogica-refactorizada/schema/documento-logica-refactorizada-v1.schema.json`.
> El Markdown final se deriva del JSON; **nunca al reves** (ver G12, G11).

Esta plantilla define el contrato del segundo documento del banco, el que alimenta la columna
**"Documentacion de la logica del codigo refactorizado"**. Es el hermano del Documento A
(`ESTRUCTURA-DOCUMENTO-LOGICA.md`, columna "Descripcion en lenguaje natural del SP") pero tiene
pipeline propio y fuente propia.

---

## Proposito

Responder con evidencia la pregunta: **"Como quedo implementada en Java la logica que antes estaba
en el SP?"** (el Documento A responde "que hace el SP realmente").

- Describe la libreria Java refactorizada real: arquitectura, capas, use cases, ports, adapters,
  DTO/modelos, excepciones, transacciones.
- Establece la **correspondencia SP -> Java** (que se replico, absorbio, delego o transformo).
- Deja **visibles** los elementos no encontrados o no implementados; no los disimula con prosa.

---

## Principios obligatorios (leer antes de redactar)

1. **No copiar el Documento A.** El Documento A es un *mapa/seed*: dice que buscar en Java, no que
   afirmar. Copiar una seccion del Documento A y presentarla como evidencia Java **bloquea** (G12).
2. **No inferir Java desde el SP.** Que una regla exista en el SP no prueba que exista en Java.
   Toda afirmacion sustantiva sobre la implementacion cita un archivo/simbolo Java real (G06, G07).
3. **Toda afirmacion es trazable** a un objeto de evidencia con `source_path` relativo + simbolo o
   clase/metodo + rango de lineas cuando sea posible.
4. **Una seccion sin evidencia NO se rellena con prosa generica.** Se marca con un estado explicito
   (`NOT_FOUND`, `NOT_APPLICABLE`, `DYNAMIC_UNRESOLVED`, `CONFLICT`) y su razon (G11, G19).
5. **El documento no declara equivalencia funcional ni aprobacion del Banco.** Eso lo decide un
   verificador/humano posterior, no este documento (G20).
6. **Sin hardcodes** de SP, HU, repositorio ni cantidad de librerias en la logica del pipeline (G15).
7. **Sin secretos ni rutas locales** en ningun campo (`github_pat_`, `ghp_`, `Bearer `, `/home/...`,
   `/tmp/`, URLs con credenciales) (G05).

---

## Objeto de evidencia canonico (usado por casi todas las secciones)

Cada afirmacion sustantiva se respalda con uno o mas objetos de evidencia con esta forma:

| Campo | Obligatorio | Descripcion |
|-------|-------------|-------------|
| `source_type` | Si | Origen: `JAVA`, `SP_SQL`, `TC_GEN`, `DOC_A`, `POM`, `MANIFEST`, `OTHER` |
| `source_path` | Si (salvo estado `NOT_APPLICABLE`/`DYNAMIC_UNRESOLVED`) | Ruta **relativa** y portable al artefacto |
| `line_start` | Cuando aplique | Linea inicial (1-based) |
| `line_end` | Cuando aplique | Linea final |
| `symbol` | — | Simbolo generico (constante, campo, endpoint) |
| `class_name` | Java: recomendado | Clase Java |
| `method_name` | Java: recomendado | Metodo Java |
| `evidence_status` | Si | Uno de los estados de evidencia (ver abajo) |
| `evidence_note` | Si | Nota breve accionable; **sin secretos** |
| `content_sha256` | Opcional | Hash del fragmento citado |

> **Regla G07:** una evidencia con `source_type=JAVA` y `evidence_status` in
> {`FOUND_EXACT`,`DERIVED_FROM_EXACT`} DEBE traer `source_path` y (`symbol` o `class_name`/`method_name`),
> y rango de lineas cuando el artefacto lo permita.

### Estados de evidencia permitidos (enum cerrado)

| Estado | Cuando usarlo |
|--------|---------------|
| `FOUND_EXACT` | El hecho esta literalmente en el codigo citado. |
| `DERIVED_FROM_EXACT` | Se deduce de codigo citado (varias piezas), sin inventar. |
| `NOT_FOUND` | Se busco y no existe evidencia; el elemento del SP no aparece en Java. |
| `NOT_APPLICABLE` | El concepto no aplica a esta libreria (ej. sin transacciones). |
| `DYNAMIC_UNRESOLVED` | Existe pero se resuelve en runtime/config y no es trazable estaticamente. |
| `CONFLICT` | La evidencia Java contradice al SP o hay dos evidencias incompatibles. |

Cualquier otro string en `evidence_status` **falla** (G10).

### Clasificacion de correspondencia SP -> Java (enum cerrado)

| Clasificacion | Significado |
|---------------|-------------|
| `REPLICATED` | La logica del SP se reimplemento equivalente en Java. |
| `ABSORBED` | La logica quedo embebida en otra pieza (no hay 1:1, pero esta). |
| `DELEGATED` | Se delega a otra libreria/microservicio/adapter legacy. |
| `TRANSFORMED` | Se implemento con enfoque distinto (decision consciente). |
| `NOT_IMPLEMENTED` | La logica del SP no esta en Java (gap visible). |
| `NOT_APPLICABLE` | El elemento del SP no debia migrarse (ej. debug COBIS). |
| `UNRESOLVED` | No se pudo determinar aun. |
| `CONFLICT` | SP y Java se contradicen. |

### Estado final permitido (enum cerrado)

| final_status | Cuando |
|--------------|--------|
| `PASS` | Todas las secciones con evidencia o estado justificado; sin gaps bloqueantes. |
| `PASS_WITH_GAPS` | Hay `NOT_FOUND`/`UNRESOLVED` visibles pero **no bloqueantes**. |
| `BLOCKED_SOURCE_MISSING` | Falta la fuente Java/SP necesaria. |
| `BLOCKED_UNTRACEABLE_CLAIM` | Hay una afirmacion Java sin evidencia. |
| `BLOCKED_SP_JAVA_CONFLICT` | Hay al menos un `CONFLICT` en mapping/evidencia. |
| `BLOCKED_RENDER_VALIDATION` | El modelo no valida contra schema/linter. |

> **Regla G08:** `PASS` es ilegal si existe cualquier gap bloqueante (conflicto, claim sin evidencia,
> fuente faltante). En ese caso el estado debe ser el `BLOCKED_*` correspondiente.

---

## Indice de secciones (20) y contrato por seccion

Para cada seccion: **objetivo**, **fuente SP reutilizable** (solo como mapa), **fuente Java
obligatoria**, **campos requeridos**, cuando `NOT_APPLICABLE`, cuando `NOT_FOUND`, **que bloquea**,
**ejemplo breve** y **anti-patrones**.

### 1. Identificacion
- **Objetivo:** identificar el documento y su libreria.
- **Fuente SP reutilizable:** nombre del SP (`sp_name`, `sp_full`) del Documento A / manifest.
- **Fuente Java obligatoria:** `artifact`, `repository`, `module` desde `pom.xml` / estructura de paquetes.
- **Campos requeridos (modelo `identity`):** `sp_name`, `version`, `document_type`; el resto lleva
  estado+razon si es `null`.
- **NOT_APPLICABLE:** —. **NOT_FOUND:** —.
- **Bloquea:** identidad minima ausente (G03); `repository=null` sin resolution status (G13).
- **Ejemplo:** `sp_name=sp_grb_comision`, `artifact=sp-grb-comision-utils`, `module=Pagos`.
- **Anti-patron:** poner la ruta absoluta del repo local; inventar el artifact.

### 2. Relacion SP/PA, HU y libreria
- **Objetivo:** vincular la libreria con su SP padre, HU individual y HU del cono.
- **Fuente SP reutilizable:** `parent_sp`, HU (Documento A / manifest — sin abrir archivos con secretos).
- **Fuente Java obligatoria:** coordenadas Maven (`group_id`/`artifact`) del `pom.xml`.
- **NOT_APPLICABLE:** libreria sin SP padre (SP raiz). **NOT_FOUND:** HU no declarada -> estado, no invento.
- **Bloquea:** —. **Anti-patron:** hardcodear `NCBE-661` o la lista de HUs en el pipeline (G15).

### 3. Responsabilidad funcional
- **Campo canonico del modelo:** `functional_responsibility` (objeto `section`, mismo tipo que las
  demas secciones documentales). Va justo despues de `sources` y antes de `architecture`.
- **Objetivo:** que hace la libreria, en una frase, confirmada por el use case principal.
- **Fuente SP reutilizable:** Documento A seccion 2 (seed) — orienta, no es evidencia Java.
- **Fuente Java obligatoria:** use case / servicio principal (clase + metodo).
- **Estados:** `FOUND_EXACT`/`DERIVED_FROM_EXACT` con evidencia Java; `NOT_FOUND` visible si no hay
  use case que la exprese; `NOT_APPLICABLE` (con razon) si la libreria es utilitaria pura sin
  responsabilidad de negocio; `CONFLICT` si SP y Java describen responsabilidades distintas.
- **Bloquea:** afirmar responsabilidad sin evidencia Java (G06); `CONFLICT` bloquea (G09).
  **Anti-patron:** copiar el parrafo del Documento A como evidencia (G12).

### 4. Arquitectura y componentes Java
- **Objetivo:** describir capas reales (domain / application / infrastructure / bootstrap) y componentes.
- **Fuente Java obligatoria:** arbol de paquetes + clases por capa (evidencia por componente).
- **NOT_APPLICABLE:** capa inexistente en esa libreria (se marca, no se inventa).
- **Bloquea:** listar una capa/clase que no existe (seria claim sin evidencia).

### 5. Entradas y salidas
- **Objetivo:** parametros de entrada/salida reales del punto de entrada Java (DTO/records/params).
- **Fuente SP reutilizable:** Documento A secciones 3-4 (paridad SP-007 como checklist).
- **Fuente Java obligatoria:** DTO/record/firma del use case.
- **NOT_FOUND:** parametro del SP ausente en Java -> se registra y se refleja en el mapping.

### 6. Flujo logico implementado
- **Objetivo:** el flujo real del metodo Java (orden, decisiones), citando lineas.
- **Fuente SP reutilizable:** Documento A seccion 5.1 (guia de orden).
- **Fuente Java obligatoria:** cuerpo del use case (lineas).
- **Anti-patron:** describir el flujo del SP como si fuera el de Java.

### 7. Validaciones
- **Fuente Java obligatoria:** validators / domain services / guard clauses.
- **NOT_FOUND:** validacion del SP no presente -> visible + mapping `NOT_IMPLEMENTED`.

### 8. Reglas de negocio
- **Fuente Java obligatoria:** domain (services, value objects).
- **Bloquea:** afirmar una regla en Java sin clase que la contenga (G06).

### 9. Calculos y transformaciones
- **Fuente Java obligatoria:** VOs/formulas (`Money`, calculadoras).
- **DYNAMIC_UNRESOLVED:** factor que viene de config/catalogo en runtime.

### 10. Acceso a datos
- **Fuente Java obligatoria:** adapters `infrastructure/outbound/data` (JDBC), marcas `// DML`.
- **NOT_APPLICABLE:** libreria sin acceso a datos propio (todo delegado).

### 11. Adapters, ports y dependencias
- **Fuente Java obligatoria:** `application/ports/out`, adapters legacy, dependencias Maven declaradas.
- **Nota:** describir dependencias por coordenadas, **nunca** abrir/repetir tokens (G05).

### 12. SP o librerias invocadas
- **Objetivo:** SPs/librerias que la libreria invoca (delegaciones).
- **Fuente SP reutilizable:** Documento A seccion 7 (SPs dependientes).
- **Fuente Java obligatoria:** adapters exec / stubs de librerias / ports.
- **Clasificacion tipica:** `DELEGATED`.

### 13. Excepciones y codigos de error
- **Fuente Java obligatoria:** `domain/exception`, catalogo de errores en codigo.
- **DYNAMIC_UNRESOLVED:** codigos propagados de SPs hijos en runtime.

### 14. Transacciones y rollback
- **Fuente Java obligatoria:** `@Transactional`, `Propagation.NOT_SUPPORTED` (RES-006), scope adapters.
- **NOT_APPLICABLE:** libreria sin transaccion propia.

### 15. Matriz de correspondencia SP -> Java
- **Objetivo:** por cada elemento relevante del SP, su destino en Java con `classification`.
- **Fuente SP reutilizable:** Documento A (universo de elementos SP).
- **Fuente Java obligatoria:** clase/metodo que lo implementa (o su ausencia).
- **Campos por fila:** `sp_element`, `sp_evidence`, `java_evidence`, `classification`, `note`.
- **Bloquea:** una fila con `classification=CONFLICT` (G09); mappings contradictorios (G18).

### 16. Logica replicada, absorbida o delegada
- **Objetivo:** resumen agregado derivado de la matriz (no se escribe a mano; ver coverage).
- **Fuente:** derivado de la seccion 15.

### 17. Diferencias conscientes
- **Objetivo:** desviaciones intencionales (ADR-like) con su justificacion y evidencia.
- **NOT_APPLICABLE:** sin diferencias conscientes.

### 18. Elementos no encontrados
- **Objetivo:** lista explicita de lo buscado y no hallado (`NOT_FOUND`), visible (G19).
- **Anti-patron:** omitir un gap para que el documento "se vea completo".

### 19. Fuentes y trazabilidad
- **Objetivo:** inventario de fuentes usadas (Java y SP) con rutas relativas.
- **Bloquea:** ruta absoluta o con secreto (G04, G05).

### 20. Estado y resumen de cobertura
- **Objetivo:** `coverage_summary` + `final_status`, ambos **derivados** por el modelo (G14).
- **Anti-patron:** declarar `final_status=PASS` de entrada; confiar conteos del input (G14, G17).

---

## Relacion con el Documento A

| Aspecto | Documento A (SP) | Documento B (codigo refactorizado) |
|---------|------------------|-------------------------------------|
| Pregunta | Que hace el SP | Como quedo en Java |
| Fuente principal | SQL del SP + tc_gen | Codigo Java de la libreria |
| Documento A | — | se usa como **seed/mapa**, no como evidencia |
| Agente | `agente-qa-doclogica-00-generador` | `agente-qa-doclogica-01-...` (futuro) |
| Plantilla | `ESTRUCTURA-DOCUMENTO-LOGICA.md` | este archivo |

---

## Nota de proceso

`No hand-edit generated artifacts. Fix the pipeline, then regenerate.`

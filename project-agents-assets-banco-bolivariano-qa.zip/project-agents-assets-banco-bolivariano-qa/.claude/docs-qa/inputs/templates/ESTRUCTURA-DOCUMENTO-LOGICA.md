# Estructura del Documento de Logica del SP

Plantilla estandar que debe generar el agente `agente-qa-doclogica-00-generador`.
Basada en la estructura oficial del banco (`ESTRUCTURA DEL DOCUMENTO DE LOGICA DEL SP v1.0.1`).

> **Proposito del documento:**
> - Entender que hace el SP realmente (flujo dominante del codigo, no "flujo feliz").
> - Descubrir reglas de negocio ocultas.
> - Documentar condiciones tecnicas que afectan la funcionalidad.
> - Servir de base para CU, HU, API Contract y pruebas de integracion.

> **Principios (heredados del agente de casos de uso):**
> - **Lenguaje funcional, no SQL:** las condiciones/variables internas (`@w_cod_errord != 0`) se explican
>   en lenguaje natural; el codigo queda como referencia entre parentesis, no como texto principal.
> - **Comportamiento trazable, no siglas inventadas:** para codigos de dominio describir QUE HACE el SP
>   con ese valor (trazable a linea Lnnn del SP). Si se infiere una sigla, marcar "(interpretado: ...)".
> - **Todo dato es trazable** a tc_gen (analysis, links, hardcoded, raw_metadata) o al `.sql` real (Lnnn).
>   PROHIBIDO afirmar hechos que no esten en las fuentes.

---

## 1. Identificacion

| Campo | Valor | Fuente |
|-------|-------|--------|
| Nombre del SP | nombre_sp | `test_cases.json.sp_name` |
| Base / esquema | base_principal | `test_cases.json.database` |
| Modulo | Ahorros / Cuentas / Pagos / ... | inferido de la base |
| Metodo | Extraido por IA (interpretacion del `.sql` + tc_gen) | fijo |
| Fecha de documento | AAAA-MM-DD | fecha de ejecucion |
| Version | X.Y.Z | control del documento |

---

## 2. Descripcion General del SP

Parrafo funcional: que operacion realiza (debito/credito/ambos), sobre que modulo, y sus
responsabilidades clave observadas en el codigo (validaciones, impuestos, comisiones, notificacion de
eventos, UAF). No inventar; describir lo observable en el `.sql` + tc_gen.

---

## 3. Parametros de Entrada (E) y Significado

Incluye todos los parametros relevantes con dos dimensiones: uso funcional y uso tecnico.

| Parametro | Tipo | Uso Funcional | Uso Tecnico | Obligatorio |
|-----------|------|---------------|-------------|-------------|
| @i_cta | cuenta | Cuenta origen | Se usa para lookups en tablas clave | Si |

> Fuente: `analysis.parameters.input` (name, type, default, line) + BRI `parameter_required` (obligatoriedad).
> El "uso funcional" y "uso tecnico" se interpretan del `.sql` (donde se lee/compara el parametro).
> Parametros tecnicos de plataforma/debug (@s_srv, @t_debug...) se marcan como tecnicos (COB-007).

---

## 4. Parametros de Salida (S)

| Salida | Tipo | Significado Funcional |
|--------|------|-----------------------|
| @o_error | int | Codigo de resultado de la operacion |

> Fuente: `analysis.parameters.output`.

---

## 5. Traduccion Explicita de la Logica del SP

### 5.1 Flujo logico principal del SP

Traduccion del flujo REAL del codigo a lenguaje humano, respetando orden de ejecucion, dependencias
y decisiones. NO es el flujo feliz: es el flujo dominante del codigo. Cada paso cita la linea (Lnnn).

### 5.2 Traduccion de validaciones tecnicas que afectan funcionalidad

Lista de las condiciones que el SP evalua para continuar / rechazar / desviar logica, redactadas en
lenguaje funcional (la condicion SQL entre parentesis como referencia).

> Fuente: BRI `branch` (rule_id, condition, line) + `hardcoded.string_comparisons`/`in_lists`.

### 5.3 Traduccion de calculos tecnicos y reglas internas

Formulas, factores, signos, redondeos, acumuladores. El core matematico/financiero del SP.

> Fuente: interpretacion del `.sql` (secciones de calculo). Trazar cada formula a su linea.

---

## 6. Matriz de Condiciones y Efecto en Datos (OBLIGATORIA)

Seccion mas importante para migracion a microservicios. Cada condicion relevante con su impacto exacto
en tablas. Un bloque por condicion.

> Fuente PRINCIPAL: `links.dml_links` (branch_line, condition, true_dmls, else_dmls) y
> `links.return_links` (branch_line, condition, true_returns, else_returns). La condicion sale literal
> del link; las tablas/operaciones salen de true_dmls/else_dmls; el resultado de true_returns.

### COND-XX

**Condicion / Regla:** descripcion funcional de la condicion evaluada (`condicion SQL` como referencia).

**Regla del SP:** explicacion de la decision que toma el SP.

**Tablas consultadas (SELECT):**

| Tabla | Campo clave | Proposito |
|-------|-------------|-----------|

**Tablas modificadas:**

INSERT:

| Tabla | Descripcion del registro |
|-------|--------------------------|

UPDATE:

| Tabla | Campos actualizados | Motivo |
|-------|---------------------|--------|

DELETE:

| Tabla | Condicion |
|-------|-----------|

**Resultado Funcional:** Exito / Error devuelto (codigo) / Continuacion / rechazo.

**Impacto para MS:** Logica debe replicarse / Logica se absorbe / Logica se delega a otro MS.

---

## 7. SPs Dependientes / SPs Invocados (OBLIGATORIA)

Documenta todos los SPs llamados por el SP principal. Su logica es parte del comportamiento que el MS
debe replicar.

### 7.1 Listado de Stored Procedures Invocados

| SP llamado | Proposito funcional | Momento de invocacion | Impacto en el flujo | Decide continuar? |
|------------|---------------------|-----------------------|---------------------|-------------------|
| sp_con_comision | Consulta la comision configurada de la empresa | Inicio del proceso | Determina si genera movimiento de comision | Si |

> Fuente: `analysis.sp_calls` (name, database, line) + BRI `sp_call`. El "para que" y "momento" se
> interpretan del branch donde aparece la llamada en el `.sql` (contexto). Reutilizar la seccion §1.1
> de `qa_casos_uso.md` si existe (ya trae contexto + obligatoriedad).

### 7.2 Responsabilidad de Cada SP Dependiente

Para cada SP: que valida/calcula, que regla de negocio implementa, que error retorna si falla, que
efecto produce en el resultado final.

---

## 8. Validaciones Especiales (codigo quemado)

Valores literales que el SP compara o usa como catalogo embebido (listas IN, comparaciones de string).

> Fuente: `hardcoded.in_lists` (variable, values, line) y `hardcoded.string_comparisons`.
> Describir el comportamiento observable de cada valor (trazable). Marcar siglas con "(interpretado: ...)".

---

## 9. Catalogos Consultados

Tablas de catalogo/parametrizacion que el SP consulta (no transaccionales): configuracion de comision,
control de funcionalidad, codigos, alicuotas.

> Fuente: interpretacion del `.sql` (SELECT sobre tablas de catalogo) + tablas en `analysis.dml_operations`
> con operacion SELECT/lectura.

---

## 10. Codigos de Error

| Codigo | Motivo | Resultado |
|--------|--------|-----------|
| 141011 | Monto invalido | Rechazo |

> Fuente: `links.return_links` (condition -> value), `hardcoded.error_codes_cerror` (codigos de sp_cerror),
> `hardcoded.unique_return_codes` (todos los RETURN). Si el SP solo retorna 0/variable dinamica, documentar
> los dinamicos (propagados de SPs hijos) y marcarlo.

---

## 11. Excepciones Tecnicas

- Rollback por error en inserts.
- SPs auxiliares que fallan.
- Errores al generar secuenciales.
- Inconsistencias SQL.

> Fuente: interpretacion del `.sql` (IF @@error, rollback, manejo de secuenciales).

---

## 12. Manejo de Transacciones y Excepciones

Describe commit, rollback, fallos tecnicos, inconsistencias SQL. Importante para equivalencia
transaccional del MS.

> Fuente: `links.return_links` con condiciones sobre `@@trancount`/`rollback` + interpretacion del `.sql`
> (BEGIN TRAN / COMMIT / ROLLBACK). Indicar si el SP controla su propia transaccion (SP-005 / RES-006).

---

## Criterio de Cierre

**Estado: PASS / BLOCKED**

Verificaciones:
- VL01 Identificacion completa (SP, base, modulo).
- VL02 Todos los parametros E/S documentados (== analysis.parameters).
- VL03 Matriz COND-XX cubre todos los dml_links + return_links (0 sin documentar).
- VL04 Todos los sp_calls documentados en seccion 7.
- VL05 Sin condiciones SQL crudas como texto principal (solo entre parentesis como referencia).
- VL06 Todo dato trazable a tc_gen o a linea del `.sql` (Lnnn).

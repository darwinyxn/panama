# Estructura del Documento de Casos de Uso por SP

Esta es la estructura estandar que debe generar el agente CU.

> **Mejoras del banco (2026-07-09) — principios:**
> - **Lenguaje funcional, no SQL:** condiciones/variables internas (`@wRowdbBiz <= 0`) se explican en
>   lenguaje natural; el codigo queda como referencia entre parentesis, no como texto principal.
> - **Comportamiento trazable, no siglas inventadas:** para codigos de dominio (formas de pago, servicios,
>   opciones), describir QUE HACE el SP con ese codigo (trazable a linea del SP). Si se infiere el
>   significado de una sigla, marcarlo "(interpretado: ...)". PROHIBIDO afirmar significados no trazables.
> - **Cobertura completa:** todo servicio/escenario que el SP maneje (branches `@i_servicio='X'`) debe
>   tener CU o escenario. No omitir servicios (ej. PAGOPRV, IMPADUAN, CORPEI).

---

## Indice

| CU | Nombre | Prioridad | Nivel Riesgo |
|----|--------|-----------|--------------|
| CU-01 | Nombre descriptivo del caso de uso | P1 | CRITICO |
| CU-02 | ... | P2 | ALTO |

---

## 1. Introduccion del SP (una sola vez)

| Campo | Valor |
|-------|-------|
| SP objetivo | nombre_sp |
| Base de datos | base_principal |
| Microservicio | nombre-microservicio |
| Descripcion general | Breve descripcion funcional del SP |
| Sistemas involucrados | bases y sistemas con los que interactua |
| Endpoint REST | URL o GAP_FUNCIONAL |
| Endpoint gRPC | URL o GAP_FUNCIONAL |

### 1.1 SPs dependientes

> v2 (OBS-CU-1): no basta el rol de una linea. Explicar el CONTEXTO funcional: para que se invoca,
> que decision de negocio habilita, y si es OBLIGATORIA (siempre en el flujo) o COMPLEMENTARIA
> (solo bajo cierta condicion/servicio). El "para que" se interpreta del branch donde se llama en el SP.

| Base | SP | Rol funcional (contexto: para que se invoca + que decision habilita) | Obligatoriedad | Linea SP |
|------|-----|--------------------------------------------------------------------|----------------|----------|
| base..sp | sp_nombre | Ej: "consulta la comision configurada de la empresa para decidir si debe generarse un movimiento financiero adicional de comision" | Obligatoria / Complementaria (condicion) | L### |

---

## 2. Casos de Uso

---

### CU-XX — Nombre del caso de uso

#### a. Proposito

Que verifica este CU. Una oracion concisa.

#### b. Nivel de riesgo y prioridad

| Nivel | Prioridad | Justificacion |
|-------|-----------|---------------|
| CRITICO/ALTO/MEDIO/BAJO | P1/P2/P3 | Razon del nivel asignado |

#### c. Alcance

> v2 (OBS-CU-5): redaccion FUNCIONAL completa, no un fragmento tecnico. Debe leerse como una regla de
> negocio: que condicion dispara el comportamiento, que hace el sistema, y que ocurre si falla parcialmente
> (queda parcial / requiere regularizacion manual / debe reversarse).

- **Incluye:** Descripcion funcional del comportamiento que cubre este CU. Ejemplo esperado:
  "Cuando la operacion empresarial tiene comision configurada y el valor de comision es mayor que cero,
  el sistema registra un movimiento financiero separado para la comision. Si el debito principal fue
  exitoso pero la comision falla, [indicar: queda parcialmente aplicada / requiere regularizacion / reverso]."
- **Excluye:** Que se cubre en otros CUs (referenciar CU-XX) y por que se separa.

#### d. Actores

| Actor | Tipo | Descripcion |
|-------|------|-------------|
| Sistema/Usuario | Principal/Sistema | Rol en el flujo |

#### e. Entradas funcionales

> v2 (OBS-CU-3/4): si el parametro toma codigos de dominio (forma de pago, servicio, opcion, tipo cuenta),
> la descripcion debe explicar QUE HACE el SP con cada valor (trazable), no listar el codigo crudo.
> Si se infiere el significado de una sigla, marcarlo "(interpretado: ...)".

| Parametro | Tipo Sybase | Descripcion funcional (que representa + que hace el SP con sus valores) |
|-----------|-------------|--------------------------------------------------------------------------|
| @i_param | tipo | Ej: "@i_opcion (char 2): selecciona el conjunto de formas de pago a actualizar en bp_total_orden. '01'=canal directo (L1012); '02'=CUE/EFE/CHL (L1038); '03'=CUE/EFE/CHE (L1067). Diferencia 02 vs 03: CHL vs CHE." |

Solo parametros que afectan comportamiento funcional de ESTE CU.
Parametros tecnicos (@s_srv, @s_ssn, @t_debug, etc.) NO deben aparecer.

**Codigos de dominio del CU (v2, OBS-CU-4):** cuando el CU use codigos crudos (CHL, CUE, PAGOPRV, COB...),
incluir una mini-tabla que describa el comportamiento observable de cada uno:

| Codigo | Aparece en | Comportamiento observable en el SP (trazable) | Interpretacion (si aplica) |
|--------|-----------|-----------------------------------------------|----------------------------|
| CHL | @i_frm_pagcob opcion 02 | El SP lo incluye en el UPDATE de bp_total_orden para opcion 02 (L1038) | (interpretado: cheque local) |

#### f. Precondiciones

> v2 (OBS-CU-2): redactar en LENGUAJE NATURAL. La condicion SQL/variable interna va como referencia
> entre parentesis, NO como texto principal.

- Condiciones especificas de este CU en lenguaje funcional. Ej: "La orden de pago existe en estado
  pendiente de procesar (te_estado_proceso='I' en bp_total_orden)."
- Datos que deben existir en BD para que el flujo se ejecute.

#### g. Postcondiciones de exito

- Resultado funcional cuando el CU se ejecuta exitosamente, en lenguaje natural.
- Tablas modificadas (con el efecto de negocio, no solo el nombre), valores de retorno, efectos secundarios.

#### h. Postcondiciones de fallo

- Que sucede funcionalmente cuando el flujo falla: si la operacion queda parcial, si hay reverso
  (rollback), si se registra el error (sp_cerror), y que codigo se devuelve.

#### i. Flujo principal

> v2: cada paso es una accion funcional observable en lenguaje natural (no SQL). Puede citar la linea
> del SP o el SP hijo entre parentesis para trazabilidad.

1. Paso a paso del camino feliz, en lenguaje funcional.
2. Ej: "El sistema consulta la comision configurada de la empresa (sp_con_comision, L112)."
3. Cada paso es una accion verificable.

#### j. Flujos alternos

> v2 (OBS-CU-2): la columna Condicion se redacta en LENGUAJE FUNCIONAL; la expresion SQL/variable va
> como referencia entre parentesis. La Accion describe el efecto de negocio, no la sentencia.
> Ejemplo del defecto (v1): `@wRowdbBiz <= 0 | UPDATE en ...his | -`
> Correcto (v2): "La orden no esta en la tabla operativa; el sistema la busca en el historico
> (@wRowdbBiz <= 0) | Actualiza la cabecera en la tabla historica bp_total_orden_his | - (continua)"

| ID | Condicion (funcional; SQL entre parentesis) | Accion (efecto de negocio) | Codigo error |
|----|---------------------------------------------|----------------------------|--------------|
| FA-01 | Descripcion funcional de la condicion de desvio (`condicion SQL`) | Que sucede en terminos de negocio | Codigo o - |

#### k. Escenarios Gherkin (QMetry)

```gherkin
Feature: CU-XX Nombre del caso de uso
  Como <actor>
  Quiero <accion>
  Para <resultado de negocio>

  Background:
    Given precondiciones compartidas por todos los escenarios

  @CU-XX @prioridad-alta @smoke @regression
  Scenario: Nombre descriptivo del escenario
    Given <contexto especifico>
    And <condicion adicional>
    When <accion unica que dispara el flujo>
    Then <resultado esperado>
    And <efecto secundario verificable>
```

**Reglas de escenarios Gherkin:**
- Cada escenario tiene exactamente 1 `When`.
- Tags obligatorios: `@CU-XX` y `@prioridad-{alta|media|baja}`.
- Tags opcionales: `@smoke`, `@regression`, `@entorno-controlado`.
- No usar numeros de cuenta reales en pasos Given — usar aliases del DATA_CATALOG.
- Usar `Scenario Outline` con `Examples` cuando el mismo flujo aplica a multiples valores.

---

## 3. Catalogo de datos de prueba (DATA_CATALOG)

| Alias | Tipo Cuenta | Estado | Caracteristica | CUs que lo usan | Condicion SP |
|-------|-------------|--------|----------------|-----------------|--------------|
| `<alias-descriptivo>` | Tipo | Estado | Que lo hace especial | CU-XX, CU-YY | Condicion en el SP |

> Los aliases se usan en los pasos `Given` de los escenarios Gherkin.
> Los valores concretos se asignan en la fase de preparacion de datos (data_discovery).

---

## 4. Matriz de trazabilidad Flujos SP → CU

| Flow ID | Condicion SP / Tipo | CU asignado | Tipo | Codigo error |
|---------|---------------------|-------------|------|--------------|
| FE-01 | Descripcion del flujo | CU-XX | happy_path/error_path/alternative_path | Codigo o - |
| FE-28 a FE-51 | Descripcion agrupada (rangos permitidos) | CU-XX | tipo | Codigo o - |

**Resumen:**
```
Total flujos identificados : N
Flujos asignados a CU      : N
Flujos sin CU              : 0 (DEBE ser 0)
```

---

## 5. Codigos de error

| Codigo | Mensaje | Condicion que lo dispara | CU | Tipo | Tiene rollback |
|--------|---------|--------------------------|-----|------|----------------|
| Numero o "Dinamico" | Texto del mensaje | Condicion del SP | CU-XX | Dependencia/Sistema/Validacion | Si/No |

> Nota: Si el SP no tiene codigos estaticos (error_codes_cerror=[]), documentar los dinamicos
> (propagados de SPs hijos o calculados en runtime).

---

## 6. Gaps funcionales

| ID | Tipo | Descripcion | CU afectados | Impacto | Accion correctiva | Estado | Responsable |
|----|------|-------------|--------------|---------|-------------------|--------|-------------|
| GAP_FUNCIONAL-XX | Implementacion/Contrato/Analisis/Entorno/Datos | Que falta | CU-XX | ALTO/MEDIO/BAJO | Como resolverlo | Abierto | Por asignar |

---

## 7. Criterios de entrada y salida (IEEE 829)

### Criterios de entrada al ciclo de pruebas

1. Ambiente QA con Sybase accesible (listar bases requeridas).
2. Cuentas de prueba provisionadas segun DATA_CATALOG.
3. Configuraciones funcionales completas (comisiones, contable, etc.).
4. SPs hijos desplegados y funcionales.
5. Microservicio desplegado (cuando java_source disponible).

### Criterios de salida

1. Todos los escenarios `@smoke` ejecutados con resultado documentado.
2. Todos los gaps tienen Responsable asignado y plan de accion.
3. Ningun escenario `@smoke` en estado FALLIDO sin defecto registrado.
4. Escenarios `@entorno-controlado` tienen plan de ejecucion.

---

## 8. Resumen de cobertura

| Metrica | Valor |
|---------|-------|
| Total CUs generados | N |
| Total escenarios Gherkin | N |
| Escenarios @smoke | N |
| Escenarios @entorno-controlado | N |
| Flujos del SP cubiertos | N de N |
| Codigos de error cubiertos | N |
| Gaps documentados | N |
| CUs nivel CRITICO | N |
| CUs nivel ALTO | N |
| CUs nivel MEDIO | N |
| Aliases de datos requeridos | N |

---

## 9. Criterio de cierre

**Estado: PASS/BLOCKED**

Verificaciones ejecutadas:
- V01 Cobertura de flujos: N/N flujos asignados a CU.
- V02 Feature blocks: N/N CUs con bloque Feature.
- V03 When unico: Todos los escenarios con un solo When.
- V04 Tags minimos: Todos los escenarios con @CU-XX y @prioridad-XX.
- V05 Cuentas reales: Ningun numero de cuenta real en pasos Gherkin.

# PLANTILLA - Documento de Casos de Prueba

Este archivo define el formato estandar que DEBE seguir cualquier documento de casos de prueba para que `parse_test_cases.py` y `execute_all.py` lo procesen correctamente.

---

## Estructura del documento

### Encabezado (obligatorio)

```markdown
# Casos de Prueba - SP `<nombre_sp>`

**Base de datos:** `<database>` (Sybase)
**Proposito:** <descripcion>
```

### CONFIG (obligatorio — despues del encabezado)

```markdown
## CONFIG

| Parametro | Valor |
|-----------|-------|
| sp_name | <nombre_sp> |
| microservice | <nombre_microservicio> |
| environment | <QA/UAT/DEV> |
| base_url | <url_completa_del_microservicio> |
| endpoint | <ruta_del_endpoint_rest> |
| grpc_host | <host_grpc:puerto> (omitir si no tiene gRPC) |
| grpc_proto_path | <ruta_relativa_al_proto> (omitir si no tiene gRPC) |
| grpc_proto_file | <nombre_archivo.proto> (omitir si no tiene gRPC) |
| grpc_service_method | <package.Service/Method> (omitir si no tiene gRPC) |
| expected_sybase_server | <SYBASE01/SYBASE02/...> (omitir si no se verifico via discover_sybase_datasource.py) |
| expected_sybase_db | <nombre_base_datos> (omitir si no se verifico) |
```

El script `execute_all.py` lee esta seccion para obtener base_url, endpoint y config gRPC.
`expected_sybase_server`/`expected_sybase_db` (NCBE-1804) activan un guard fail-closed en
`connect_sybase()`: si la conexion real no coincide, la corrida aborta antes de ejecutar
PRE/SP/POST. Se completan con `discover_sybase_datasource.py` + verificacion real
(`SELECT @@servername`), nunca a mano/adivinados.
Si no tiene gRPC, simplemente no incluir esos campos — el script lo omite sin error.
Los campos gRPC se agregan cuando la ruta este expuesta en el ambiente.

### Convenciones (opcional)

```markdown
## CONVENCIONES

| Simbolo | Significado |
|---------|-------------|
| PRE | Precondicion: estado de BD antes de ejecutar |
| POST | Postcondicion: estado de BD despues de ejecutar |
```

### Parametros de sesion por defecto (obligatorio)

```markdown
## PARAMETROS DE SESION POR DEFECTO

| Parametro | Valor por defecto | Descripcion |
|-----------|-------------------|-------------|
| **@<param>** | <valor> | <descripcion> |
```

El parser lee CUALQUIER parametro con formato `**@nombre**` de esta tabla.
No hay lista fija de parametros — se adapta al SP.

---

## Formato de Caso de Prueba

### TC con PRE/POST (valores absolutos obligatorios)

```markdown
### TCxx — Titulo del caso

| Campo | Detalle |
|-------|---------|
| **@param** | valor |

**PRE — Estado requerido en BD:**
` ` `sql
UPDATE <base>..<tabla> SET <campo> = <valor_absoluto> WHERE <condicion>
` ` `

**POST — Validaciones en BD:**
` ` `sql
UPDATE <base>..<tabla> SET <campo> = <valor_absoluto> WHERE <condicion>
` ` `

**Resultado esperado:** `RETURN xxxxx`

**Trazabilidad por DB:**
- `<tabla>` INSERT/UPDATE (L:<linea>):
  - campo = valor (L:<linea> razon)
- `<tabla>`: NINGUNO (razon)
```

### TC sin PRE/POST (la mayoria de TCs de error)

```markdown
### TCxx — Titulo del caso

| Campo | Detalle |
|-------|---------|
| **@param** | valor |

**Resultado esperado:** `RETURN xxxxx`

**Trazabilidad por DB:**
- NINGUNO — SP retorna <codigo> en L:<linea> antes de BEGIN TRANSACTION
```

### TC con resolucion dinamica de parametros

```markdown
**PRE — Estado requerido en BD:**
` ` `sql
SELECT MAX(<campo_seq>) as <param_sp> FROM <base>..<tabla> WHERE <condicion>
` ` `
```

El alias (`as <param_sp>`) debe coincidir con el nombre del parametro SP. El script inyecta el resultado automaticamente.

### TC con CHECK constraint (simular fallo BD)

```markdown
**PRE — Estado requerido en BD:**
` ` `sql
ALTER TABLE <base>..<tabla> ADD CONSTRAINT ck_tcNN_block CHECK (<campo> != <valor> OR 1=0)
` ` `

**POST — Validaciones en BD:**
` ` `sql
ALTER TABLE <base>..<tabla> DROP CONSTRAINT ck_tcNN_block
` ` `
```

---

## Reglas de formato

### Titulo del TC (solo parametros de entrada)
- El titulo `### TCxx — <titulo>` describe UNICAMENTE los parametros de entrada (opcion, canal,
  identificadores, valores). PROHIBIDO: nombres de tabla, variables internas del SP (`@w_*`, `@v_*`,
  `@@rowcount`), verbos de efecto en BD (inserta, actualiza, genera, UPDATE, INSERT).
- El efecto (tabla que muta, return) va en Resultado esperado y Trazabilidad, NO en el titulo.
- Ejemplo: ❌ `### TC01 — Verifica UPDATE en bp_total_orden` → ✅ `### TC01 — Opcion 01, canal DIR, forma CUE`.
- El titulo y el resultado esperado deben contar la MISMA historia (titulo "exito" ⇒ resultado exito).

### Tabla de parametros
- Cada fila: `| **@nombre_param** | valor |`
- Valores numericos sin comillas: `100.00`, `1`, `9999`
- Valores string con comillas simples: `'0001'`, `'N'`, `'AHO'`
- **PROHIBIDO valores descriptivos**: todo valor debe ser literal
- Parametros en PARAMETROS DE SESION POR DEFECTO no necesitan repetirse
- **`null` vs `OMITIR` — dos escenarios DISTINTOS de parametro obligatorio:**
  - `null` → el parametro SE ENVIA con valor NULL. El SP corre; el efecto depende de donde se
    usa el param (si es llave de un lookup como confcontable, suele dar el error de ese lookup;
    si el SP lo tolera, puede dar exito). Usar cuando se quiere probar el comportamiento ante NULL.
  - `OMITIR` → el parametro NO SE ENVIA en la llamada (el motor lo excluye del EXEC y del payload REST).
    Para un param sin default en la firma del SP, Sybase rechaza la llamada con **return -6**
    ("expects parameter @X, which was not supplied"). Es el escenario que valida la OBLIGATORIEDAD real.
  - Regla: si el objetivo del TC es "validar que @X es obligatorio", el escenario correcto suele ser
    `OMITIR` (resultado -6), NO `null` — porque muchos params el SP los tolera en NULL y no fallan.
    Verificar contra el SP/Sybase cual de los dos aplica antes de fijar el resultado esperado.
  - El motor reconoce `OMITIR` (tambien `OMIT`/`NO_ENVIAR`) y lo traduce al sentinel interno `__OMIT__`.

### PRE y POST SQL — REGLAS CRITICAS
- Solo queries mutantes: UPDATE, INSERT, DELETE, ALTER
- **NO incluir SELECTs validadores** — el snapshot automatico los reemplaza
- Excepcion: SELECTs con alias dinamico (`as <nombre_param_sp>`) se ejecutan para resolver parametros
- PRE precedido por: `**PRE — Estado requerido en BD:**`
- POST precedido por: `**POST — Validaciones en BD:**`
- Si un TC no tiene PRE ni POST, omitir ambas secciones
- **VALORES ABSOLUTOS OBLIGATORIOS**: nunca usar operaciones relativas (`campo = campo + 1`). Siempre fijar valor exacto (`campo = 5`)
- El POST debe restaurar la cuenta al MISMO estado que el PRE configuro, para que la fase REST parta del mismo punto
- **ECOSISTEMA — coherencia con los parametros del TC (lo audita V-ECOSISTEMA-01):** los datos que operan el
  PRE y el POST (cuenta, orden, empresa, servicio, etc.) DEBEN ser los MISMOS que el TC declara en su tabla de
  parametros. El PRE prepara el escenario del PROPIO TC -> filtra/opera por sus datos, nunca por una cuenta/orden
  ajena. El POST puede fijar en su `SET` un valor distinto SOLO para RESTAURAR el estado original (ej. devolver
  un servicio a su valor previo), pero su `WHERE` debe filtrar por el dato declarado del TC. El TC es un
  ecosistema autoconsistente: si declara `@i_numcta_emp=X` y `@i_orden=Y`, su PRE/POST operan sobre X e Y.

### Resultado esperado
- Formato: `**Resultado esperado:** \`RETURN xxxxx\``

### Trazabilidad por DB (obligatoria)
- Documenta que tablas modifica el SP para este TC
- Para error: `NINGUNO — SP retorna <codigo> en L:<linea>`
- Para exitoso: lista de tablas con campos y valores esperados
- Referenciar lineas del SP (L:XXX)

### Separadores
- Cada TC termina con `---`
- Cada GRUPO empieza con `## GRUPO N — Nombre`

---

## Secciones finales (obligatorias)

### TABLAS MONITOREADAS

```markdown
## TABLAS MONITOREADAS

| Tabla | Base | Operacion | Campo cuenta | Top | Campos a ignorar | Filtro contenido |
|-------|------|-----------|--------------|-----|------------------|------------------|
| <tabla> | <base> | UPDATE | <campo> = @<param_cuenta> | N/A | <campos_fecha> | — |
| <tabla> | <base> | INSERT | <campo> = @<param_cuenta> | TOP 5 <col_hora> DESC | <seq>, <hora> | — |
| <tabla> | <base> | INSERT | <subquery> | TOP 10 <col_fecha> DESC | <seq>, <hora> | — |
| <tabla> | <base> | UPDATE | <enlace> = @<param> | N/A | <campos_fecha> | <clave_fina> = @<param> |
```

La 7a columna `Filtro contenido` es OPCIONAL y retrocompatible: docs con solo 6 columnas siguen
operando (filtro vacio = `—`). El motor lee `cols[6]` si existe.

**Columna Top:**
- `N/A` — para tablas UPDATE (1 fila) o tablas donde no aplica limitar
- `TOP N <columna_orden> DESC` — para tablas INSERT multi-fila. N=5 para datetime (ms), N=10 para smalldatetime (precision 1 min)
- La columna de orden DEBE ser datetime o smalldatetime (cronologica)
- El script hace COUNT separado (total real) + SELECT TOP N para contenido

**Columna Campo cuenta (clave de enlace — resuelta dinamicamente por el motor):**
- Formato simple: `<campo> = @<param>`
- Multi-condicion: `<campo1> = @<param1> AND <campo2> = @<param2>` (cuando una tabla no se filtra
  por cuenta/orden sino por otra combinacion, ej: `el_empresa = @i_empresa AND el_servicio = @i_servicio`)
- Subquery: `<campo> = (SELECT <col> FROM <tabla> WHERE <col2> = @<param>)`
- `N/A` si la tabla no se filtra por cuenta NI se muta por esta cadena (el motor la salta)
- **Multi-clave:** cada fila declara SU PROPIO `@param`. Una tabla puede enlazar por `@i_orden`
  (via `*_orden_banco`) y otra por `@i_numcta_emp` (via `*_cta_banco`). El motor resuelve cada
  `@param` desde los parametros_entrada del TC — NUNCA hardcodear valores, NUNCA asumir una sola clave global.
- **Notas informativas permitidas pero NO ejecutables:** todo texto tras ` — `, ` (`, `;` se trata
  como comentario y el motor lo descarta del WHERE. Ej: `cf_cuenta = @i_numcta_emp` puede llevar nota
  `(UPDATE solo cf_fecha_ing)` sin afectar la query. Lo ejecutable es SIEMPRE la parte `col = @param`.
- **Filtro literal de fecha (optimizacion de snapshot — solo cuando V-COL-02 lo indique):** ademas del
  enlace por `@param`, una fila puede anteponer una condicion literal SIN `@param` que el motor pasa
  verbatim al WHERE. Su unico uso valido hoy es acotar tablas historicas grandes (millones de filas)
  sin indice por la clave de enlace, forzando el indice por fecha:
  `<col_fecha> >= dateadd(day,-7,getdate()) AND <clave> = @<param>`
  - El enlace por `@param` NUNCA se quita; el filtro se SUMA. El motor exige al menos un enlace por
    parametro (un filtro solo-literal matchearia toda la tabla → invalido).
  - **SEGURO unicamente si la tabla es INSERT-only y el SP estampa la fila nueva con la fecha de hoy**
    (`getdate()`): asi la fila a detectar cae dentro de la ventana y el delta PRE/POST la captura.
    PROHIBIDO en tablas UPDATE (la fila preexiste con fecha antigua → el filtro la ocultaria) y en
    tablas que copian una fecha historica. El margen de 7 dias cubre corridas que crucen fin de semana.
  - NO se aplica por defecto: la inmensa mayoria de tablas tienen indice por la clave y son rapidas.
    El validador (V-COL-02) mide tamaño + indice y SOLO propone el filtro donde realmente aplica.
  - Ejemplo real (debcred): `fp_fecha_mov >= dateadd(day,-7,getdate()) AND fp_orden_banco = @i_orden`
    en `bp_forma_pagcob_his` bajo 95s→0.2s sin perder deteccion (INSERT-only, fecha de hoy).

**Columna Filtro contenido (7a, OPCIONAL — acota el peso del snapshot sin perder deteccion):**
- Predicado adicional `<col> = @<param>` que el motor aplica SOLO al SELECT de filas (contenido),
  NO al COUNT. El COUNT sigue sobre el "Campo cuenta" completo (detecta anomalia de volumen: filas
  que aparecen/desaparecen). El contenido se acota a la(s) fila(s) que el SP realmente muta.
- **Cuando usarlo:** el "Campo cuenta" (enlace por orden/cuenta) matchea MUCHAS filas (N>>1), pero el
  SP solo MUTA una fila identificada por una clave fina adicional. Sin acotar, el snapshot serializa
  todas las filas ×4 capturas/TC → JSON de cientos de MB que el reporte HTML no puede renderizar.
- **Valor:** el predicado fino EXACTO del UPDATE en el SP (verificar en el SP que muta la tabla).
- **Diferencia con el Filtro literal de fecha:** aquel acota COUNT y contenido por performance (table
  scan); este acota SOLO el contenido por peso/legibilidad, dejando el COUNT amplio. Son ortogonales.
- **A diferencia del filtro de fecha, SI aplica a tablas UPDATE** (su proposito es justo acotar el
  contenido de un UPDATE cuyo enlace matchea muchas filas). NO ocultar la fila mutada: el predicado
  fino debe ser EL MISMO que usa el UPDATE del SP, asi captura exactamente la fila afectada.
- Dejar `—` cuando no aplica. La inmensa mayoria de tablas no lo necesita.
- Ejemplo real (debcred): `bp_detalle`/`bp_detalle_his` enlazan por `dt_orden_banco = @i_orden`
  (una orden SPI agrupa 6000+ detalles), pero el UPDATE de `sp_grb_mov_y_frmpgo` afecta una fila por
  `dt_orden_banco = @i_orden AND dt_secuencial = @i_secuencial`. Filtro contenido = `dt_secuencial =
  @i_secuencial` → COUNT sobre toda la orden, contenido a 1 fila. JSON de 278MB → ~10MB.

**Cobertura por niveles (SP con hijos/nietos que mutan):**
- Si el SP raiz invoca SPs hijos/nietos que mutan tablas, la seccion debe listar TODAS las tablas
  de la cadena (no solo las del SP padre), agrupadas en subsecciones `### Nivel padre`,
  `### Nivel hijos`, `### Nivel nietos`. El motor lee toda la seccion `## TABLAS MONITOREADAS`
  (los `###` son informativos y no la cortan; solo un `## ` nuevo la termina).
- Sin esto, una discrepancia micro-vs-SP en una tabla mutada por un hijo pasaria como EQUIVALENTE
  sin detectarse (punto ciego de evidencia).

### DICCIONARIO SP-REST (placeholder — se genera post-desarrollo Java)

```markdown
## DICCIONARIO SP-REST

Pendiente: se generara con agente-qa-auto-04-test-cases-config una vez exista el codigo Java del microservicio.
```

**NOTA:** Esta seccion es OBLIGATORIA para ejecutar `execute_all.py`. Si no existe con el formato completo, el script se detiene. Se genera DESPUES de que el Java existe, antes de la primera corrida.

Formato final (generado por agente diccionario):

```markdown
## DICCIONARIO SP-REST

| Variable SP | Campo REST (jsonpath) | Campo gRPC | Tipo | Comparacion | Notas |
|-------------|----------------------|------------|------|-------------|-------|
| return_code | <path> | — | int | exacta | — |
| @<output_param> | <path> | <campo_proto> | <tipo> | <modo> | <nota> |
| mensaje_debug | <path> | <campo_proto> | string | contenido | Mensaje del SP: motor Sybase (rechazo -6) o traduccion canonica de cl_errores en errores de negocio (ver abajo) |
```

**Columna Campo gRPC:**
- Nombre del campo en el message Response del .proto
- `—` si no tiene equivalente gRPC (ej: return_code que proto3 omite cuando es 0)
- El script compara gRPC vs REST usando esta columna
- Proto3 omite campos con valor default (0, "", false) — el script lo maneja

**Variable especial `mensaje_debug` (opcional, generica para cualquier SP):**
- NO es un output param formal del SP. Es el mensaje asociado al resultado del SP. El script lo captura y
  lo expone en `sp_output.mensaje_debug`, con dos fuentes segun el tipo de codigo:
  1. **Codigo de MOTOR Sybase** (no esta en cl_errores, ej. rechazo `-6` "expects parameter @X, which was
     not supplied"): se toma el TEXTO CRUDO que emite el motor en la ejecucion real (raiserror/print/validacion).
     El micro reproduce el mismo texto del motor -> coinciden.
  2. **Codigo de NEGOCIO** (existe en cl_errores, ej. 122002, 122004, 120000): el motor SOBRESCRIBE
     mensaje_debug con el TEXTO CANONICO del catalogo `inputs/catalogos/cl_errores.json`. Como el micro
     tambien traduce el codigo con el mismo catalogo cl_errores, ambos traen el MISMO texto -> coinciden.
- Se mapea al campo donde el micro expone ese mensaje (ej. `debug` en body REST y Response gRPC).
- El discriminador (motor vs negocio) es la PRESENCIA del codigo en cl_errores: si el effective_result del SP
  esta en el catalogo -> se usa el texto canonico; si no (motor) -> se conserva el crudo. Esto NO es inventar
  un dato (el codigo de negocio SI tiene ese mensaje canonico en produccion) ni es tautologia (compara el texto
  que un consumidor real veria). El codigo (@o_error / return_code) tambien se compara aparte por su fila.

**Tipos de comparacion (aplican tanto para REST como para gRPC):**
- `exacta` — valores deben ser iguales (null==null, 0==0, valor==valor)
- `exacta-veredicto` — igual que `exacta` para la comparacion REST/gRPC, PERO ademas MARCA cual es el campo
  que DECIDE EL VEREDICTO SP (SYBASE_OK/FAIL). Debe haber EXACTAMENTE UNA fila con esta marca. El motor lee de
  ahi cual output param lleva el "resultado de negocio" del SP, sin asumir un nombre fijo:
    - SPs con `aplcobis='N'` que comunican el resultado por un output param (ej. debcred -> `@o_error`): marcar
      esa fila con `exacta-veredicto`.
    - SPs que comunican el resultado por el RETURN status (ej. ahndc/pa_*/cont_impuesto): marcar la fila
      `return_code` con `exacta-veredicto`.
  Si NINGUNA fila lleva la marca (docs previos a esta convencion), el motor cae al comportamiento legado
  (@o_error si existe, sino return_code) — retrocompatible.
- `contenido` — para strings: compara texto sin prefijo `[sp_name]`, tolerando ambos-null (si SP y micro son
  null/vacio, coincide). Es el modo para `mensaje_debug`: el motor ya garantiza que el SP traiga el texto
  correcto (crudo del motor para codigos de motor, o canonico de cl_errores para codigos de negocio), asi que
  ambos lados coinciden por texto real.
- `contenido-si-sp` — **DEPRECADO** (retrocompatible: si un doc aun lo declara, el motor lo trata como
  `contenido`). Antes NO comparaba cuando el SP no emitia el valor, para tolerar que el micro tradujera el
  codigo mientras el SP solo devolvia el codigo. Quedo OBSOLETO al usar cl_errores como fuente canonica del
  mensaje_debug del SP (ahora SP y micro traen el mismo texto y coinciden con `contenido`). Ademas ENMASCARABA
  un riesgo real: si el SP no emite mensaje pero el micro SI devuelve texto, eso es una DIVERGENCIA que debe
  marcarse, no ocultarse. USAR `contenido` en su lugar.
- `presencia` — verifica que ambos sean null o ambos tengan valor (no compara el valor exacto)
- `IGNORAR` — no se compara (excluido del analisis)

**Nota gRPC:** Los campos `grpc_*` se incluyen directamente en la tabla `## CONFIG` principal (lineas 30-33 de esta plantilla). NO crear seccion separada `## CONFIG gRPC`. Si el micro no tiene gRPC, simplemente omitir esos campos.

---

## Reglas de asignacion de cuentas y aislamiento

- TCs de error (no mutan BD) pueden compartir cuenta/orden.
- TCs que mutan BD en LOTES DISTINTOS (paralelos) NO deben compartir valores de los campos de
  aislamiento (orden, cuenta). Dentro del MISMO lote SI pueden compartir (se ejecutan secuencialmente
  y el POST restaura el estado). Esto lo audita V-GRP-01.
- TCs con constraints (CHECK) deben tener cuenta propia.
- Cada TC que muta BD DEBE tener POST que restaure al estado exacto del PRE.

---

## EJECUCION POR GRUPOS (opcional — habilita modo paralelo)

Si esta seccion existe en el documento, el script `run_qa.py` ejecuta los grupos
en lotes paralelos. Si NO existe, ejecuta GROUP-1..N secuencialmente.

```markdown
## EJECUCION POR GRUPOS

Define cómo se ejecutan los grupos cuando se usa modo paralelo.
Si esta sección NO existe, la ejecución es secuencial (GROUP-1, GROUP-2, ..., GROUP-N en orden del documento).

| Lote | Grupos |
|------|--------|
| 1 | <grupos_lote_1> |
| 2 | <grupos_lote_2> |
```

**Modo:** Los lotes se ejecutan en paralelo entre sí. Dentro de cada lote, los grupos se ejecutan secuencialmente en el orden listado.

**Requisito de aislamiento:** Los TCs de lotes paralelos distintos NO deben compartir valores en los campos de filtro declarados en TABLAS MONITOREADAS (responsabilidad del generador de TCs y validado por V-GRP-01).

---

## TABLAS MONITOREADAS POR SPs HIJOS (obligatoria si SP tiene hijos que mutan)

```markdown
**SPs hijos y tablas que mutan:**
- `<sp_hijo_1>` (filtro: <campo>): <tabla_1>, <tabla_2>

**Aislamiento para ejecucion paralela:**
- Tablas <X>: aisladas por @<param_1> (cada lote usa valor distinto)
```

Esta informacion la genera el agente generador analizando los SPs hijos en sybase-local/.

---

## Flujo de ejecucion del script (execute_all.py)

El script ejecuta SECUENCIALMENTE por TC:
```
TC01: PRE → snapshot_pre → SP → snapshot_post → POST → PRE → snapshot_pre → REST → snapshot_post → POST → PRE → gRPC → POST
TC02: PRE → snapshot_pre → SP → snapshot_post → POST → PRE → snapshot_pre → REST → snapshot_post → POST → PRE → gRPC → POST
...
```

Cada TC es independiente. No hay RESET BD intermedio.
El POST restaura la cuenta entre cada fase (SP, REST, gRPC).
gRPC no tiene snapshots — solo valida paridad de contrato vs REST.

**Como se compara el efecto en BD (SP vs REST):**
- **Cantidad de filas** (cuantas se insertaron/borraron por tabla): la gobierna el **COUNT** real
  (`count_delta` = COUNT_post − COUNT_pre), que no tiene tope y es la fuente confiable. Si el SP y el
  REST no coinciden en count_delta de alguna tabla → INCONSISTENCIA.
- **Contenido de filas** (valores de columnas): se compara sobre el snapshot. Para tablas de UNA fila
  (dict, ej. saldo de cuenta) se compara campo por campo la transicion pre→post (respetando `campos_ignorar`).
- REGLA CRITICA: la cantidad de filas NUNCA se infiere por `len()` del snapshot de tablas tipo LISTA. El
  snapshot de contenido usa `TOP N` (ej. TOP 5); si la tabla ya viene topada, una insercion adicional no
  cambia el `len` → daria un falso "0 filas nuevas". El conteo lo hace el COUNT (arriba), no el `len`.

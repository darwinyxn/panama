# QMetry API Reference — QTM4J Cloud

Referencia operativa basada en pruebas reales contra la instancia del banco.

---

## Autenticacion

| Header | Valor | Requerido |
|--------|-------|-----------|
| `apiKey` | API key de QMetry | Siempre |
| `Content-Type` | `application/json` | Para POST/PUT |
| `Authorization` | Jira auth (Basic o Bearer) | Solo en `discovery.py`, opcional (via `JIRA_AUTHORIZATION`). CONFIRMADO POR CODIGO que `transform.py`/`cycle_creator.py`/`sync_checker.py`/`sender.py` nunca lo envian ni lo requieren. |

Variables de entorno:
```bash
export QMETRY_BASE_URL="https://qtmcloud.qmetry.com"
export QMETRY_API_KEY="<tu_api_key>"
export JIRA_AUTHORIZATION="<si_es_necesario>"
```

---

## Base URL

```
https://qtmcloud.qmetry.com
```

---

## Endpoints probados

> Cada endpoint indica su nivel de evidencia: **CONFIRMADO POR CODIGO/TESTS** (implementado y
> cubierto por tests unitarios con mocks en el repo actual), **INFERIDO POR CONVENCION LOCAL**
> (sigue el mismo patron que otro endpoint ya confirmado contra esta instancia, pero no tiene
> test/ejecucion propia), o **NO CONFIRMADO SIN RED LIVE** (documentado historicamente, sin
> verificacion reciente contra la instancia real).

### 1. Listar proyectos habilitados — CONFIRMADO POR CODIGO/TESTS

```
POST /rest/api/latest/projects
Body: {}
```

Es una BUSQUEDA read-only (verbo POST, sin efecto de mutacion) — no crea nada.

**Response 200 (shape dict{total,data} confirmado):**
```json
{
  "total": 56,
  "data": [
    {"id": 10105, "key": "PC", "name": "Pruebas Continuas", "qmetryEnabled": true}
  ]
}
```

Script activo: `discovery.py --list-projects`. Pagina completamente con `startAt`/`maxResults`
sobre este shape (bounded por `--max-pages`, default 1000); nunca declara universo completo
sobre una pagina parcial.

---

### 2. Listar folders de test cases — CONFIRMADO POR CODIGO/TESTS

```
GET /rest/api/latest/projects/{projectId}/testcase-folders
```

**Response 200 (shape dict{total,data} confirmado):**
```json
{
  "total": 24,
  "data": [
    {
      "id": 668578,
      "name": "IP_INTERNACIONAL",
      "seqNo": 1,
      "children": [{"id": 1343801, "parentId": 668578, "name": "Sprint45"}],
      "folderIdStr": "668578"
    }
  ]
}
```

Script activo: `discovery.py --list-folders <projectId>`. Mismo comportamiento de paginacion
bounded que el listado de proyectos.

---

### 3. Buscar folder por nombre — CONFIRMADO POR CODIGO/TESTS

```
GET /rest/api/latest/projects/{projectId}/testcase-folders/search?folderName=<texto>
```

El parametro real es `folderName` (no `query`). Script activo:
`discovery.py --search-folder <projectId> <nombre>` (opcionalmente con `--parent-id <id>` para
desambiguar). Clasifica la respuesta en `NO_MATCH`/`UNIQUE_MATCH`/`AMBIGUOUS_RESULTS` — nunca
selecciona automaticamente el primer resultado. Si 2+ resultados comparten el mismo `name` bajo
`parentId` distintos, marca `AMBIGUOUS_NAME` explicitamente.

---

### 3b. Buscar Test Cycles por identidad exacta — CONFIRMADO POR CODIGO/TESTS

```
POST /rest/api/latest/testcycles/search
Body: {"filter": {"projectId": <int>, "folderId": <int>, "summary": <str>}}
Query: startAt, maxResults, fields=summary,folder,projectId (OBLIGATORIO)
```

Sin `fields` explicito, la respuesta omite `summary`/`folder` (bug real detectado en
investigacion previa: producia un falso "0 coincidencias" tras una creacion real con HTTP 201).
A diferencia de `/testcases/search` (que expone `folders` en PLURAL, array), este endpoint
expone `folder` en SINGULAR (objeto `{id, name}`) — un Test Cycle vive en un solo folder.

Script activo: `cycle_creator.py` (interno; no es una herramienta CLI de consulta libre).
Identidad exacta: `projectId + folderId + summary`. Pagina completamente (bounded por
`max_pages`, default 1000); bloquea si el `total` reportado cambia entre paginas o si aparece
un `id` repetido entre paginas.

---

### 4. Crear folder de test cases — NO CONFIRMADO SIN RED LIVE (ver limitacion abajo)

```
POST /rest/api/latest/projects/{projectId}/testcase-folders
```

**Limitacion conocida:** no existe hoy un script canonico activo del Lote 2 que ejecute esta
creacion (no hay caller confirmado en `discovery.py`/`cycle_creator.py`). La informacion de esta
seccion proviene de investigacion historica, no de un test/ejecucion reciente contra el codigo
actual.

**Body:**
```json
{
  "folderName": "nombre del folder",
  "parentId": -1
}
```

| Campo | Tipo | Requerido | Nota |
|-------|------|-----------|------|
| `folderName` | string | Si | NO es `name` — la API rechaza `name` con error "Folder name can not be empty" |
| `parentId` | int | Si | `-1` para raiz, ID de folder padre para sub-folder |

**Response 201:**
```json
{
  "id": 2525771,
  "name": "migracion nyxn",
  "created": {"createdOn": "03/Jun/2026 22:07", "createdBy": "630540d255894b7fbddce707"}
}
```

**Errores comunes:**
- 400 `"Folder name can not be empty"` → usaste `name` en vez de `folderName`
- 400 `"Parent folder ID is not valid"` → falta `parentId` o no existe

---

### 5. Crear test case — CONFIRMADO POR CODIGO/TESTS (payload); shape de respuesta inferido

```
POST /rest/api/latest/testcases
```

**Body (campos obligatorios):**
```json
{
  "projectId": 10105,
  "summary": "[TC01] Nombre del test case",
  "steps": [
    {
      "stepDetails": "Descripcion del paso (obligatorio)",
      "expectedResult": "Resultado esperado (opcional)",
      "testData": "Datos de prueba (opcional)"
    }
  ]
}
```

**Body (campos opcionales):**
```json
{
  "description": "Descripcion larga del TC",
  "precondition": "Precondiciones SQL o funcionales",
  "folderId": 2525772,
  "priority": null,
  "status": null,
  "labels": [],
  "components": [],
  "fixVersions": [],
  "sprint": null,
  "assignee": null,
  "reporter": null,
  "estimatedTime": null,
  "isAutomated": false,
  "customFields": []
}
```

**`aiGenerated` PROHIBIDO en el body real** — `sender.py` lo filtra explicitamente
(`FORBIDDEN_CREATE_FIELDS`) antes de cada POST/PUT; la API lo rechaza con 400 "AI operation not
allowed". Nunca viaja, sin importar el contenido del payload local.

**Tipos de dato por campo:**

| Campo | Tipo | Obligatorio | Nota |
|-------|------|-------------|------|
| `projectId` | int | Si | ID numerico del proyecto QMetry |
| `summary` | string | Si | Titulo del TC, no vacio |
| `description` | string | No | Descripcion larga |
| `precondition` | string | No | Precondiciones |
| `steps` | array | Si | Al menos 1 step |
| `steps[].stepDetails` | string | Si | Descripcion del paso, no vacio |
| `steps[].expectedResult` | string | No | Resultado esperado |
| `steps[].testData` | string | No | Datos de prueba |
| `folderId` | int | No | Folder destino dentro del proyecto |
| `priority` | int | No | ID de prioridad QMetry |
| `status` | int | No | ID de estado QMetry |
| `labels` | int[] | No | Array de IDs de labels |
| `components` | int[] | No | Array de IDs de componentes |
| `fixVersions` | int[] | No | Array de IDs de versiones |
| `sprint` | int | No | ID del sprint |
| `assignee` | string | No | Account ID del asignado |
| `reporter` | string | No | Account ID del reporter |
| `estimatedTime` | string | No | Tiempo estimado |
| `isAutomated` | bool | No | Si el TC es automatizado |
| `aiGenerated` | bool | No | Si fue generado por IA |
| `customFields` | array | No | Campos personalizados |
| `customFields[].id` | string | Si (si existe) | ID del custom field |

**Headers requeridos (CONFIRMADO POR CODIGO/TESTS):**
```
apiKey: <QMETRY_API_KEY>
Content-Type: application/json
```
`sender.py` NUNCA envia `Authorization`/`JIRA_AUTHORIZATION` para este endpoint — solo
`discovery.py` soporta ese header opcional (para otros endpoints de consulta), y nunca lo
imprime.

**Response esperada:** 200/201/204 con `id`+`key` del TC creado — **CONFIRMADO POR CODIGO**: un
2xx sin `id`/`key` en el body NUNCA se interpreta como exito (`sender.py` reconcilia read-only
en vez de asumir creacion). El shape exacto de la respuesta 2xx no tiene test de contrato
dedicado — inferido por convencion local (mismo patron que `/testcycles`, que si tiene
evidencia directa via `cycle_creator.py`).

Script activo: `sender.py --payload <payload_qmetry_listo.json> --sync-plan <qmetry_sync_plan.json> --output <dir> [--execute]`.

---

## Trazabilidad TC<->Historia de Usuario (requirements)

> Investigacion 2026-06-19. Hallazgos confirmados contra la instancia del banco.

### Verificador (READ-ONLY, CONFIRMADO)

```
GET /rest/api/latest/testcases/{tcKey}/requirements
```
Devuelve las historias/requirements vinculados a un TC:
```json
{ "total": 1, "data": [ { "id": 292672, "key": "PC-246", "summary": "...",
                          "issueType": {...}, "status": {...} } ] }
```
- `total: 0` / `data: []` => el TC NO esta vinculado a ninguna historia.
- Header: solo `apiKey`. Es el verificador OFICIAL de trazabilidad (usado por `traceability_checker.py`).
- Se consulta **por `key`** (PC-TC-XXX), no por id. En re-corridas idempotentes los items
  `SKIP` de `sender.py` deben conservar la `key` (se propaga desde el sync_plan); si falta,
  el checker marca `UNRESOLVED_KEY` y el gate falla como `INCOMPLETE_INPUT` (exit 1), no PASS.

### Resolver requirementId numerico desde issueKey -- MODELO CORREGIDO (QMT-24)

> **Auditoria QMT-24 (2026-08-21):** `{requirementId}` NO es un id interno que
> QMetry asigne por separado del issue de Jira. El propio contrato oficial de
> QMetry (`qmetry-openapi.latest.json`) documenta el parametro `id` de
> `POST /rest/api/latest/requirements/{id}/testcases/link` y de
> `POST /rest/api/latest/testcycles/{id}/requirements/link` literalmente como
> **"Jira Issue Id, get this from Jira"**. Confirmado ademas empiricamente 4/4
> sobre HUs reales del banco (NCBE-1174/1175/1176/1343): el `requirementId`
> usado en cada `qmetry_config.json` coincide digito a digito con el `id`
> numerico que devuelve `GET /rest/api/2/issue/{key}?fields=id` de Jira.
>
> **Fuente PRIMARIA de identidad: Jira directo**, no QMetry. `resolve_jira_issue`
> (en `requirement_id_resolver.py`) hace `GET {JIRA_URL}/rest/api/2/issue/{key}`
> (Basic Auth con `JIRA_EMAIL`/`JIRA_API_TOKEN`) y confirma issueKey + numeric
> issue id directo, sin depender de que QMetry ya "conozca" ese issue.

```
GET /rest/api/latest/requirements?maxResults=200&startAt=N
```
- Los filtros por query (`?key=`, `?issueKey=`) son IGNORADOS: devuelve la lista completa.
- Hay que PAGINAR y hacer match exacto por el campo `key`. Confirmado: PC-246 -> id 292672.
- Lo sigue haciendo `resolve_requirement()` en `requirement_id_resolver.py`, pero ahora es
  **cross-check SECUNDARIO best-effort** (via `resolve_requirement_identity`), NO gate
  obligatorio de existencia. Semantica real observada de este listado (comportamiento
  observado, NO garantizado por el OpenAPI, que solo documenta parametros de
  paginacion/filtro/orden): parece ser un listado/cache cross-proyecto de issues de Jira
  que QMetry ya vinculo/toco alguna vez, ordenado por `linkUpdatedOn` descendente -- es una
  HIPOTESIS OPERACIONAL, no un hecho contractual. Un `MISSING` aqui (el issue nunca fue
  tocado desde QMetry) **no bloquea** la resolucion de identidad si Jira ya confirmo
  key+id; una contradiccion real (misma key, id distinto) SI bloquea (fail-closed).
- `resolve_requirement_identity(...)` en `requirement_id_resolver.py` es el punto de entrada
  unico usado por `issue_linker.py`/`traceability_checker.py` (ver su docstring para el
  contrato completo de outcomes: `CONFIRMED_BY_JIRA`, `CONFIRMED_BY_JIRA_AND_QMETRY`,
  `JIRA_NOT_FOUND`, `JIRA_ERROR`, `JIRA_IDENTITY_MISMATCH`, `QMETRY_IDENTITY_MISMATCH`).
  `cycle_requirement_linker.py` nunca tuvo el gate obligatorio (toma `requirementId` directo
  de config/CLI) y no necesito ningun cambio funcional en esta auditoria.

### Escritura del vinculo (Track 2 - endpoint Open API)

> Actualizacion: el Swagger oficial de QMetry Open API expone un endpoint publico (apiKey)
> para vincular TC<->Requirement. Implementado en `issue_linker.py` (dry-run por defecto).

**Endpoint principal (usado por `issue_linker.py`):**
```
POST /rest/api/latest/requirements/{requirementId}/testcases/link
Headers: apiKey + Content-Type: application/json
Body: {"testcases": [ {"id": "<testcase_internal_id>", "versionNo": 1} ]}
Exito: HTTP 200 o 204.
```
- `{requirementId}` es el id NUMERICO de la HU -- es el **Jira Issue Id**, obtenible directo
  de Jira (`GET /rest/api/2/issue/{key}?fields=id`; PC-246 -> 292672) y validado por
  `resolve_requirement_identity()` en `requirement_id_resolver.py` (QMT-24; ver seccion
  anterior).
- El `id` de cada testcase es el id interno alfanumerico (ej. PC-TC-352 -> boY2f9DntlYy1p).
- `issue_linker.py` es **dry-run por defecto**; solo muta con `--execute`. Solo Open API, nunca `/rest/api/ui`.

> **RACE CONDITION 409 (confirmado en PC-246):** disparar N POST seguidos contra el mismo
> `{requirementId}` provoca HTTP **409 "Requirement is already [linked]"** fantasma — la API
> rechaza pero NO crea el vinculo (el verificador `GET /testcases/{key}/requirements` lo ve MISSING).
> Mitigacion implementada en `issue_linker.py` (version historica de esta investigacion): en
> `--execute` con `planned > 1` exigia `--sleep-between-posts > 0` (default 0 ->
> `ABORTED_UNSAFE_BULK`), y `--verify-after-each` (GET post-POST, exigia `--batch-size 1`)
> detenia la corrida si un vinculo no se materializo. PC-246 se cerro 58/58 con
> `--batch-size 1 --sleep-between-posts 15 --verify-after-each`.
>
> **Nota (post-hardening QMT-22):** el contrato actual de `issue_linker.py` reemplazo estos
> guards por preflight inmediato + reconciliacion bounded ante 409/timeout/5xx (nunca
> reintenta el POST) y `--batch-size 1` obligatorio en `--execute` (sin excepcion). Ver
> `INSTRUCTIVO_QMETRY_PIPELINE.md` para el contrato vigente completo.

**Endpoint alternativo (no implementado aun):**
```
POST /rest/api/latest/testcases/{id}/version/{no}/requirements/link
Body: {"requirementIds": [292672]}
```

### Historico de intentos previos (antes de hallar el endpoint Open API)

| Endpoint | Metodo | Resultado observado |
|----------|--------|---------------------|
| `/rest/api/latest/requirements/{id}/testcases` | POST | no-op: HTTP 200 con `data:[]` con todos los bodies probados (`{testCases:[{id,versionNo}]}`, `{testCaseIds:[...]}`); 400 si el `{id}` del path es la key textual (espera `Long`) |
| `/rest/api/ui/testcases/{tcId}/version/{v}/requirements/link` body `{"filter":{"jql":"id IN (292672)"}}` | POST | **HTTP 401 "JWT token was not sent"**: endpoint interno de UI, requiere sesion Atlassian (JWT), NO apiKey. **NO usar cookies/JWT de navegador en produccion.** |
| `/rest/api/automation/importresult` (sin `/latest/`) | POST | Existe (OPTIONS POST). Automation Import; los `.feature` de QMetry usan tags `@storykey=<HU>` y `@testcasekey=<TC>`. Contrato exacto/dedup/side-effect de ejecucion SIN confirmar. Plugin `com.qmetry:automation:1.0.3` es privado (no en Maven Central). |

**Estado:** el vinculo manual por UI SI funciona (verificado: PC-TC-351 -> PC-246, detectado por el GET).
El writer backend automatizable queda pendiente de confirmar UNA via soportada: (a) endpoint publico
con apiKey + body exacto, (b) JWT/service account automatizable, o (c) Automation Import reutilizando
TCs por `@testcasekey` sin duplicar.

---

## Validaciones locales antes de enviar

`transform.py` valida antes de escribir el payload (`validate_test_case`, CONFIRMADO POR
CODIGO/TESTS):

- `projectId`: obligatorio, entero
- `summary`: obligatorio, string no vacio
- `steps`: obligatorio, array no vacio
- `steps[].stepDetails`: obligatorio por step, string no vacio

`sender.py` filtra el body antes de cada POST/PUT (`sanitize_create_body`/`sanitize_update_body`,
`ALLOWED_CREATE_FIELDS`/`FORBIDDEN_CREATE_FIELDS`): solo viajan los campos del schema oficial;
`issueKey`, `_qmetry_status` y `aiGenerated` se descartan siempre, nunca llegan a la API.

---

## Estructura de folders creada para pruebas

```
Proyecto: 10105 (PC - Pruebas Continuas)

migracion nyxn (2525771) — parentId: -1 (raiz)
  └── sp_ahndc_automatica - cob_ahorros (2525772) — parentId: 2525771
```

---

## Notas operativas

- `JIRA_AUTHORIZATION` es exclusiva de `discovery.py` (opcional; agrega `Authorization` a los
  headers de sus 3 endpoints de consulta si esta definida). Ninguno de los otros 4 scripts del
  Lote 2 (`transform.py`, `cycle_creator.py`, `sync_checker.py`, `sender.py`) la lee ni la
  requiere — CONFIRMADO POR CODIGO.
- El campo para crear folders es `folderName`, NO `name` — NO CONFIRMADO SIN RED LIVE (ver
  limitacion en la seccion 4: sin caller activo del Lote 2 que ejecute esta creacion hoy).
- `parentId: -1` crea en la raiz del proyecto — misma limitacion que el punto anterior.
- La API no tiene rate limiting observado hasta 56 requests (listar proyectos) — historico, no
  reverificado recientemente.
- Timestamps en formato `dd/MMM/yyyy HH:mm` — historico.
- Identidad de Test Cycle: `projectId + folderId + summary` EXACTO — CONFIRMADO POR
  CODIGO/TESTS (`cycle_creator.py`, ver seccion 3b).

# INSTRUCTIVO DE PREPARACION BD - `<sp_name>`

## 1. OBJETIVO

Reiniciar el estado de las cuentas de prueba a valores conocidos antes de cada corrida QA.
Garantiza que los TCs de la pasada SP y la pasada REST operen con el mismo estado base.

## 2. PREREQUISITOS

- Conectividad a Sybase (`SYBASE_SERVER`, `SYBASE_USER`, `SYBASE_PASS`)
- Permisos de UPDATE en las tablas de cuentas del SP objetivo
- Base de datos: `<database>`

## 3. SCRIPT DE REINICIO

El script se ejecuta automaticamente por `run_qa.py`. El bloque entre `-- === PASO 1` y `ENDSCRIPT` es parseado y ejecutado.

```sql
-- === PASO 1: REINICIO DE CUENTAS ===

-- Restaurar saldos y contadores de cuentas de prueba
UPDATE <tabla_principal> SET <campo_saldo> = <valor_base>, <campo_contador> = <valor_base> WHERE <campo_cuenta> = '<cuenta_tc01>'
go
UPDATE <tabla_principal> SET <campo_saldo> = <valor_base> WHERE <campo_cuenta> = '<cuenta_tc02>'
go

-- Restaurar configuracion global si aplica (parametros, catalogos)
-- DELETE/INSERT de registros de configuracion que los TCs modifican

-- Restaurar parametros criticos del SP
-- INSERT INTO <tabla_parametros> (...) VALUES (...) si algun TC los elimina

ENDSCRIPT
```

## 4. VERIFICACION POST-RESET

```sql
SELECT <campo_cuenta>, <campo_saldo>, <campo_estado>
FROM <tabla_principal>
WHERE <campo_cuenta> IN ('<cuenta_tc01>', '<cuenta_tc02>', ...)
ORDER BY <campo_cuenta>
go
```

## 5. MAPEO DE CUENTAS POR TC

| TC | Cuenta | Proposito |
|----|--------|-----------|
| TC01 | <cuenta> | <escenario> |
| TC02 | <cuenta> | <escenario> |

## REGLAS

- Cada cuenta debe quedar en un estado que permita ejecutar su TC sin PRE adicional
- TCs que comparten cuenta no deben interferir entre si
- El reset debe ser idempotente (ejecutar N veces produce el mismo resultado)
- Si un TC modifica configuracion global, el instructivo debe restaurarla

## AISLAMIENTO PARA EJECUCION PARALELA (orden + cuenta)

- El aislamiento entre lotes paralelos aplica a TODOS los campos de estado que el SP muta, no solo al saldo
  de la cuenta. En particular, el **estado de la ORDEN** (ej. `te_estado_proceso`) es compartido: si N TCs
  usan la misma orden, uno puede dejarla procesada ('T') y el siguiente no la halla en estado inicial ('I')
  → error espurio (ej. "no encontrada"). Por eso un TC de debito exitoso que corra en paralelo con otros debe
  tener **orden dedicada** (no compartida con TCs de otro lote), ademas de cuenta con saldo.
- Cuando un TC necesite aislamiento total, asignarle **orden Y cuenta exclusivas** (ninguna otra TC las usa)
  del tipo/servicio que el TC valida, verificadas contra la BD. El PRE prepara ambas (estado de orden + saldo)
  y el POST las restaura.
- La cuenta a debitar (`@i_numcta_emp` o equivalente) es un PARAMETRO DE ENTRADA del SP: el SP debita esa
  cuenta, no la deriva de la orden. Por tanto, para el dato de prueba basta que la cuenta sea VALIDA/autorizada
  para la empresa (con saldo preparado por el PRE); NO se exige que coincida con la cuenta de debito historica
  de la orden (ej. bp_forma_pagcob). Verificar la fuente real del SP antes de acoplar cuenta y orden.

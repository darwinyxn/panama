# Instructivo — Pipeline QMetry (QA → QTM4J Cloud)

---

## Que es este pipeline?

Un sistema automatizado que toma los resultados de las corridas de equivalencia QA (SP vs Microservicio) y los sube a QMetry para gestion de pruebas. Crea Test Cases, los organiza en folders, los agrupa en un Test Cycle y los vincula a una historia de usuario en Jira.

---

## Que problema resuelve?

Antes: un QA tenia que crear manualmente cada caso de prueba en QMetry, copiar datos, organizar en folders y linkear. Con 58 TCs por SP, eso es trabajo repetitivo y propenso a errores.

Ahora: el pipeline lee el JSON que ya genera el pipeline QA existente (`QA-CASOS-PARSEADOS.json`) y en 5 pasos automaticos deja todo organizado en QMetry.

---

## Componentes del pipeline

### Scripts (en `claude-setupv2/.claude/docs-qa/inputs/scripts/qmetry/`)

| Script | Que hace | Input | Output |
|--------|----------|-------|--------|
| `discovery.py` | Herramienta MANUAL, read-only: lista proyectos/folders o busca un folder por nombre. No forma parte obligatoria del flujo automatico — solo se usa cuando hace falta resolver/verificar un `projectId`/`folderId` a mano | env vars + CLI | stdout (tabla + `OUTCOME`/`COUNT`/`COMPLETE`) |
| `transform.py` | Convierte QA-CASOS-PARSEADOS.json al formato QTM4J Cloud (READ-ONLY hacia QMetry; no muta nada remoto) | QA-CASOS-PARSEADOS.json + qmetry_config.json | payload_qmetry_listo.json |
| `cycle_creator.py` | Localiza (o crea, en `--execute`) UN Test Cycle por identidad `projectId+folderId+summary` exacta. NO crea folders, NO linkea a ninguna issue | qmetry_config.json + `--summary` (obligatorio) | qmetry_cycle_mapping.json |
| `sync_checker.py` | Consulta QMetry (read-only) para clasificar cada TC local en NUEVO/SIN_CAMBIO/ACTUALIZAR/DEPRECATED | payload + config | qmetry_sync_plan.json |
| `sender.py` | Crea (POST) o actualiza (PUT) TCs en QMetry segun el plan (`--sync-plan` obligatorio). En ACTUALIZAR solo cambia summary/description/precondition: **QMetry ignora `steps` en ese PUT** | payload + sync_plan (obligatorio) | qmetry_envio_resultado.json |
| `step_updater.py` | Actualiza los **test steps** de TCs existentes (`PUT /testcases/{id}/versions/{no}/teststeps`). Dry-run por defecto, preflight, solo steps existentes por seqNo, verificacion posterior obligatoria, `--batch-size 1` en `--execute` | payload + sync_plan (obligatorio) | qmetry_steps_update_resultado.json |
| `linker.py` | Vincula los TCs creados al Test Cycle (Lote 1, fuera de este documento salvo el paso 8 del flujo) | envio_resultado + cycle_mapping | qmetry_link_resultado.json |

> **Nota historica (no operativa):** documentacion anterior de este pipeline mencionaba
> `scope_classifier.py` y `validate_qmetry_config.py` como pasos del flujo. Ambos aparecen en
> documentacion historica, pero actualmente **no existen como fuentes `.py` trackeadas** en el
> repositorio y **no forman parte del flujo ejecutable**. No se presentan como opcionales,
> pendientes ni bloqueantes — simplemente no se invocan.

### Agentes (en `claude-setupv2/.claude/agents/`)

| Agente | Responsabilidad unica | Script que ejecuta |
|--------|----------------------|-------------------|
| `qmetry-agente-qa-orquestador` | Coordina los 5 pasos en secuencia, valida entre pasos | Ninguno (solo delega) |
| `qmetry-agente-qa-cycle-creator` | Crear cycle y folder | cycle_creator.py |
| `qmetry-agente-qa-traductor` | Transformar TCs | transform.py |
| `qmetry-agente-qa-sync-checker` | Comparar local vs QMetry | sync_checker.py |
| `qmetry-agente-qa-inyector` | Enviar TCs a QMetry | sender.py |
| `qmetry-agente-qa-linker` | Linkear TCs al cycle | linker.py |

### Archivos de configuracion

| Archivo | Donde | Para que |
|---------|-------|---------|
| `qmetry_config.json` | `inputs/documents/{sp_name}/` | Configuracion por SP: projectId, folderId, issueKey |
| `qmetry_config_template.json` | `inputs/templates/` | Template vacio para copiar cuando se agrega un SP nuevo |
| `qmetry_api_reference.md` | `inputs/templates/` | Referencia de endpoints probados de la API QMetry |

---

## Estructura en QMetry

```
Proyecto 10105 (Pruebas Continuas)
│
├── testcase-folders/
│     └── migracion nyxn/
│           └── sp_ahndc_automatica - cob_ahorros/   ← folderId en config
│                 ├── PC-TC-351 [TC01]
│                 ├── PC-TC-352 [TC02]
│                 └── ... (58 TCs)
│
└── testcycle-folders/
      └── migracion nyxn/
            └── sp_ahndc_automatica/
                  └── Test Cycle PC-TR-133            ← linked to PC-246
                        └── contiene: 58 TCs linkeados
```

---

## Flujo canonico de ejecucion

```
Paso 0: Validar insumos (QA-CASOS-PARSEADOS.json + qmetry_config.json existen)
   │
Paso 0b (OPCIONAL): DISCOVERY → solo si hace falta resolver/verificar projectId/folderId
   │     a mano. Herramienta manual read-only; NO es un paso obligatorio del pipeline.
   │
Paso 1: CYCLE CREATOR → Localiza (o crea, con --execute) UN Test Cycle por identidad
   │     projectId+folderId+summary EXACTA. NO crea folders, NO linkea a ninguna issue.
   │     Output: qmetry_cycle_mapping.json
   │
Paso 2: TRANSFORM → Convierte los TCs al formato QTM4J (READ-ONLY hacia QMetry)
   │     Output: payload_qmetry_listo.json
   │
Paso 3: SYNC CHECKER → Consulta QMetry (read-only), clasifica cada TC
   │     (NUEVO/SIN_CAMBIO/ACTUALIZAR/DEPRECATED)
   │     Output: qmetry_sync_plan.json
   │
Paso 4: REVISION HUMANA del plan (nuevo/sin_cambio/actualizar/deprecated) antes de mutar.
   │
Paso 5: SENDER (DRY-RUN) → Reporta que haria (WOULD_CREATE/WOULD_UPDATE) sin mutar nada.
   │
Paso 6: SENDER (--execute) → SOLO con autorizacion humana explicita. Crea (POST) o
   │     actualiza (PUT) los candidatos; verificacion posterior siempre obligatoria.
   │     Output: qmetry_envio_resultado.json
   │
Paso 7: VALIDACION del resultado (created/updated/would_create/would_update/failed,
   │     revisar `verified`/`outcome` por candidato, nunca asumir exito solo por exit 0).
   │
Paso 8: LINKING/TRAZABILIDAD (Lote 1, fuera de este documento) → linker.py vincula los
         TCs al cycle; traceability_checker.py/issue_linker.py vinculan a la Historia de
         Usuario. Ver agentes/docs propios de ese frente para el contrato completo.
```

> **IMPORTANTE — vinculo TC<->Historia (trazabilidad), contrato real post-hardening QMT-22/23:**
> Pasar `issueKey` en el body de creacion de TC/cycle **NO** crea el vinculo visible en
> Jira (la API lo ignora para el linking). El unico verificador confiable es:
> `GET /rest/api/latest/testcases/{key}/requirements` (devuelve las historias vinculadas).
> Scripts Track 1: `requirement_id_resolver.py` y `traceability_checker.py` (gate, READ-ONLY).
> `issue_linker.py` (Track 2) es el writer real del vinculo — YA NO es placeholder, esta
> implementado y endurecido fail-closed.
>
> **Modelo de identidad del Requirement (QMT-24, corrige documentacion anterior):**
> `requirementId` NO es un id interno que QMetry asigne por separado — es literalmente el
> **Jira Issue Id** (asi lo documenta el contrato oficial de QMetry,
> `.claude/docs-qa/to-do-context/gengis/qmetry-openapi.latest.json`, parametro `id` de
> `/requirements/{id}/...` y `/testcycles/{id}/requirements/link`: "Jira Issue Id, get this
> from Jira"; confirmado ademas 4/4 empiricamente sobre HUs reales del banco). Por eso Jira
> (`GET /rest/api/2/issue/{key}?fields=id`) es la **fuente PRIMARIA** de identidad
> (`resolve_requirement_identity()`/`resolve_jira_issue()` en `requirement_id_resolver.py`).
> `GET /rest/api/latest/requirements` de QMetry sigue existiendo como **cross-check
> SECUNDARIO best-effort** (comportamiento observado, no garantizado por el OpenAPI): un
> `MISSING` ahi (el issue nunca fue tocado/vinculado antes en QMetry) NO bloquea la
> resolucion de identidad si Jira ya confirmo; una contradiccion real de id para la misma
> key SI bloquea (fail-closed). `traceability_checker.py`/`issue_linker.py` usan este
> mecanismo unificado internamente; `cycle_requirement_linker.py` nunca dependio de este
> cross-check (toma `requirementId` directo de config/CLI) y no necesito cambios.
>
> **`traceability_checker.py` — `--requirement-id` es OBLIGATORIO** (antes opcional): exige
> coincidencia AND estricta entre `id` y `key` del Requirement resuelto, nunca OR. Ademas
> exige un universo canonico explicito via `--expected-count` o `--expected-testcases-file`
> (si ambos se pasan, deben ser mutuamente consistentes) — sin uno de los dos, el gate puede
> dar `PASS` sobre un subconjunto accidental del universo real. Identidad por
> `local_id`/`key`/`id`: dos casos sin key pero con id distinto NUNCA colapsan en un solo
> `UNRESOLVED_KEY`; conflictos de identidad entre fuentes bloquean explicitamente
> (`DUPLICATE_KEY_CONFLICT`/`DUPLICATE_ID_CONFLICT`/`LOCAL_ID_CONFLICT`/`VERSION_CONFLICT`).
> Ejemplo (100% read-only, seguro siempre):
> ```
> python3 traceability_checker.py --issue-key PC-246 --requirement-id 292672 \
>   --testcases-file <results>/qmetry/qmetry_envio_resultado.json \
>   --expected-count <N_esperado> \
>   --output <results>/qmetry/qmetry_traceability_check.json
> ```
> Result/exit code: `PASS` (0) / `MISSING_LINKS` (1) / `INCOMPLETE_INPUT`/`ERROR` (1) /
> `UNIVERSE_EMPTY`/`UNIVERSE_MISMATCH`/`IDENTITY_CONFLICT`/`REQUIREMENT_IDENTITY_MISMATCH`/
> `REQUIREMENT_IDENTITY_UNRESOLVED` (2). Nunca asumir `PASS` sin revisar el `result` completo.
>
> **`issue_linker.py` — writer del vinculo TC<->Historia**, endpoint Open API
> `POST /rest/api/latest/requirements/{id}/testcases/link`, body
> `{"testcases":[{"id":"<internal_id>","versionNo":N}]}`. Reglas fail-closed:
> - **Dry-run POR DEFECTO**: sin `--execute` NO hace ningun POST (solo planea; incluso la
>   resolucion AND del Requirement corre siempre, por ser read-only).
> - Solo Open API; NUNCA `/rest/api/ui` (ese exige JWT de sesion).
> - Trabaja SOLO sobre `status=MISSING` del checker. `LINKED` se salta (`SKIP_ALREADY_LINKED`);
>   `ERROR`/`UNRESOLVED_KEY` bloquean (`BLOCKED`); **cualquier status desconocido/typo bloquea**
>   (`UNKNOWN_STATUS_BLOCKED`) — nunca se convierte silenciosamente en candidato.
> - **Preflight inmediato por candidato**: justo antes de cada POST se relee el estado remoto
>   real (el traceability file puede estar obsoleto). Si ya aparece vinculado -> cero POST.
> - **Reconciliacion bounded** (nunca reintenta el POST) ante 409/timeout/5xx: hasta
>   `--reconciliation-max-reads` lecturas (default 3) o `--reconciliation-max-seconds` (default
>   60s). Un 409 seguido de reconciliacion que confirma el vinculo -> exito
>   (`LINKED_RECONCILED_AFTER_409`); si sigue MISSING -> fallo (`CONFLICT_409_PERSISTENT`).
>   Un 4xx definitivo distinto de 409 nunca se reconcilia ni se declara exitoso
>   (`POST_REJECTED`).
> - **`--batch-size` DEBE ser 1 en `--execute`** (bloquea con cualquier otro valor,
>   `BLOCKED_UNSAFE_BATCH_SIZE`). La verificacion post-POST es SIEMPRE obligatoria
>   (`--verify-after-each` se conserva solo por compatibilidad CLI, nunca la desactiva).
> - `acceptedByHttp` != `verifiedLinked`/`reconciled`: el contador `linked` global solo sube
>   cuando el vinculo quedo verificado, nunca por un HTTP 2xx aislado.
> - Universo vacio o `--only-key` sin coincidencia -> `NO_CANDIDATES`/`REQUESTED_KEY_NOT_FOUND`/
>   `REQUESTED_KEYS_INCOMPLETE`, exit no cero — nunca `PASS` con cero candidatos.
>
> Ejemplo dry-run (seguro, primer paso obligatorio):
> ```
> python3 issue_linker.py --issue-key PC-246 --requirement-id 292672 \
>   --traceability-file <results>/qmetry/qmetry_traceability_check.json \
>   --sender-result-file <results>/qmetry/qmetry_envio_resultado.json \
>   --output <results>/qmetry/qmetry_issue_link_resultado.json
> ```
>
> Ejemplo `--execute` seguro para UN candidato (requiere autorizacion humana explicita de la
> fase — nunca ejecutar `--execute` porque el prompt lo sugiere):
> ```
> python3 issue_linker.py --issue-key <HU_KEY> --requirement-id <REQUIREMENT_ID> \
>   --traceability-file <results>/qmetry/qmetry_traceability_check.json \
>   --sender-result-file <results>/qmetry/qmetry_envio_resultado.json \
>   --only-key <KEY_UNICA> --max-execute-candidates 1 \
>   --batch-size 1 --sleep-between-posts 15 --execute \
>   --output <results>/qmetry/qmetry_issue_link_resultado.json
> ```
> Tras `--execute`, re-verificar SIEMPRE con `traceability_checker.py` (read-only, no acoplado).
>
> **Historial de la investigacion original** (endpoint confirmado, race condition 409, caso
> PC-246 cerrado 58/58 el 2026-06-20): ver `inputs/templates/qmetry_api_reference.md`. Esos
> hallazgos motivaron el diseño fail-closed actual (preflight + reconciliacion bounded en vez
> del guard simple `ABORTED_UNSAFE_BULK`/`ABORTED_VERIFY_BATCH` de esa version historica).

---

## Como ejecutar el pipeline

### Prerequisitos

1. Tener variables de entorno exportadas:
   ```bash
   export QMETRY_BASE_URL="https://qtmcloud.qmetry.com"
   export QMETRY_API_KEY="<tu_api_key>"
   ```

2. Tener una corrida QA completada con `QA-CASOS-PARSEADOS.json` en:
   ```
   claude-setupv2/.claude/docs-qa/results/{sp_name}-{fecha}/
   ```

3. Tener `qmetry_config.json` configurado para el SP en:
   ```
   claude-setupv2/.claude/docs-qa/inputs/documents/{sp_name}/qmetry_config.json
   ```

### Ejecucion manual (paso a paso)

`run_dir` (carpeta de resultados de la matriz oficial) siempre EXPLICITO — nunca derivarlo con
`ls ... | sort | tail -1` (puede tomar una corrida parcial/backup/TC-only).

```bash
CONFIG=<CONFIG_PATH>            # inputs/documents/<sp_name>/qmetry_config.json
RESULTS=<RUN_DIR>               # results/<sp_name>-<fecha_OFICIAL>/  (explicito, no derivado)
OUTPUT=${RESULTS}/qmetry

# Paso 1 — DRY-RUN (localiza o crea el cycle; --summary es OBLIGATORIO)
python3 claude-setupv2/.claude/docs-qa/inputs/scripts/qmetry/cycle_creator.py \
  --config $CONFIG --summary <SUMMARY_SP> --output $OUTPUT

# Paso 1b — MUTATING — REQUIRES EXPLICIT AUTHORIZATION (solo si el paso 1 dio WOULD_CREATE
# y se autorizo crear el cycle)
python3 claude-setupv2/.claude/docs-qa/inputs/scripts/qmetry/cycle_creator.py \
  --config $CONFIG --summary <SUMMARY_SP> --output $OUTPUT --execute

# Paso 2 — READ-ONLY hacia QMetry (transforma localmente; no muta nada remoto)
python3 claude-setupv2/.claude/docs-qa/inputs/scripts/qmetry/transform.py \
  --parsed ${RESULTS}/QA-CASOS-PARSEADOS.json --config $CONFIG --mode full

# Paso 3 — READ-ONLY (consulta y clasifica; no muta nada remoto)
python3 claude-setupv2/.claude/docs-qa/inputs/scripts/qmetry/sync_checker.py \
  --payload ${OUTPUT}/payload_qmetry_listo.json --config $CONFIG --output $OUTPUT

# Paso 4 — revision humana de ${OUTPUT}/qmetry_sync_plan.json antes de continuar.

# Paso 5 — DRY-RUN (--sync-plan es OBLIGATORIO; sin --execute no muta nada)
python3 claude-setupv2/.claude/docs-qa/inputs/scripts/qmetry/sender.py \
  --payload ${OUTPUT}/payload_qmetry_listo.json \
  --sync-plan ${OUTPUT}/qmetry_sync_plan.json --output $OUTPUT

# Paso 6 — MUTATING — REQUIRES EXPLICIT AUTHORIZATION
python3 claude-setupv2/.claude/docs-qa/inputs/scripts/qmetry/sender.py \
  --payload ${OUTPUT}/payload_qmetry_listo.json \
  --sync-plan ${OUTPUT}/qmetry_sync_plan.json --output $OUTPUT --execute

# Paso 6b — Steps de TCs ACTUALIZAR (sender.py NO los actualiza). DRY-RUN primero; luego
# smoke con --only-local-id y despues el lote. Re-correr sync_checker.py al final: debe dar SIN_CAMBIO.
python3 claude-setupv2/.claude/docs-qa/inputs/scripts/qmetry/step_updater.py \
  --payload ${OUTPUT}/payload_qmetry_listo.json \
  --sync-plan ${OUTPUT}/qmetry_sync_plan.json --output $OUTPUT [--only-local-id TCxx] [--execute --batch-size 1]

# Paso 8 — Linking al cycle (Lote 1). DRY-RUN por defecto; --execute requiere autorizacion
# humana explicita — ver qmetry-agente-qa-linker.md para el contrato completo.
python3 claude-setupv2/.claude/docs-qa/inputs/scripts/qmetry/linker.py \
  --sender-result ${OUTPUT}/qmetry_envio_resultado.json \
  --cycle-mapping ${OUTPUT}/qmetry_cycle_mapping.json \
  --expected-cycle-id <CANONICAL_CYCLE_ID> \
  --output $OUTPUT
```

### Ejecucion via agente setup (RECOMENDADO — punto de entrada unico)

```
Ejecutar pipeline QMetry:
- sp_name: sp_ahndc_automatica
- projectId: 10105
- issueKey: PC-246
- base_datos: cob_ahorros

Modo: --mode full.
Variables de entorno ya exportadas.
```

El agente setup valida los 4 datos, crea config/folder si es la primera vez, y ejecuta el pipeline completo.
Si falta algun dato, el agente preguntara antes de continuar.

---

## Modos de operacion

| Modo | Que sube | Cuando usarlo |
|------|----------|---------------|
| `--mode full` | Todos los TCs (pass + fail) | Primera carga o quieres cobertura completa en QMetry |
| `--mode pass-only` | Solo TCs con veredicto EQUIVALENTE | Solo quieres los que ya pasaron |

---

## Que pasa en corridas sucesivas?

| Situacion | Que hace el pipeline |
|-----------|---------------------|
| Primera corrida | Crea todo desde cero (cycle + 58 TCs + links) |
| Segunda corrida, nada cambio | Sync checker detecta 58 SIN_CAMBIO → skip todos |
| Corrida nueva, 3 TCs cambiaron | 3 ACTUALIZAR: `sender.py` (summary/description/precondition) + `step_updater.py` (steps) + 55 SKIP |
| Corrida con TC nuevo que antes no existia | 1 NUEVO (POST) + resto SKIP |
| TC que antes fallaba, ahora pasa | Se actualiza su contenido/status |

---

## Como agregar un SP nuevo

1. Copiar template:
   ```bash
   cp claude-setupv2/.claude/docs-qa/inputs/templates/qmetry_config_template.json \
      claude-setupv2/.claude/docs-qa/inputs/documents/{nuevo_sp}/qmetry_config.json
   ```

2. Editar `qmetry_config.json`:
   ```json
   {
     "projectId": <PROJECT_ID>,
     "folderId": null,
     "issueKey": "<ISSUE_KEY>",
     "boardId": <BOARD_ID>
   }
   ```

3. Resolver el `folderId` (READ-ONLY, herramienta manual):
   ```bash
   python3 claude-setupv2/.claude/docs-qa/inputs/scripts/qmetry/discovery.py \
     --search-folder <PROJECT_ID> "<NOMBRE_DEL_FOLDER>"
   ```
   Interpretar el `OUTCOME` final: `UNIQUE_MATCH` da el `folderId` a usar; `NO_MATCH` significa
   que el folder aun no existe. `cycle_creator.py` **NO crea folders** (solo localiza/crea el
   Test Cycle sobre un `folderId` ya resuelto) — si el folder no existe, crearlo manualmente en
   QMetry o via la API directa (no hay un script canonico activo de creacion de folder en este
   flujo).

4. Actualizar `folderId` en el config con el ID resuelto.

5. Ejecutar el pipeline normalmente (ver "Flujo canonico de ejecucion").

---

## Archivos de output (por corrida)

Todos los artefactos QMetry quedan en:
```
results/{sp}-{fecha}/qmetry/
  qmetry_cycle_mapping.json    — cycle_id, cycle_key, folder_id
  payload_qmetry_listo.json    — 58 TCs en formato QTM4J
  qmetry_sync_plan.json        — clasificacion NUEVO/SKIP/ACTUALIZAR
  qmetry_envio_resultado.json  — id, key, versionNo por cada TC creado
  qmetry_link_resultado.json   — confirmacion de links al cycle
```

---

## Restricciones tecnicas importantes

| Restriccion | Razon |
|-------------|-------|
| `aiGenerated: true` PROHIBIDO | La API lo rechaza con 400 "AI operation not allowed" |
| `JIRA_AUTHORIZATION` no requerido | Solo el header `apiKey` es necesario |
| El link TC→cycle usa `{id, versionNo}` | No acepta keys tipo PC-TC-XXX para linkear |
| No hay endpoint para verificar link issue↔TC por API | Verificar manualmente en Jira UI |
| `folderName` para crear folders (no `name`) | La API rechaza el campo `name` |
| `parentId: -1` para folders raiz | Obligatorio, no se puede omitir |
| Anti-duplicado de cycle es por busqueda remota exacta (`projectId+folderId+summary`), no solo el mapping local | `cycle_creator.py` hace preflight inmediato contra `/testcycles/search` antes de cada POST |

---

## Preguntas frecuentes

**P: Puedo correr el pipeline sin haber ejecutado la corrida QA?**
R: No. Necesitas `QA-CASOS-PARSEADOS.json` que genera `parse_test_cases.py` del pipeline QA.

**P: Si corro 2 veces por accidente, crea duplicados?**
R: No. El sync_checker detecta que ya existen y los clasifica como SIN_CAMBIO (skip).

**P: Puedo subir solo los que pasan?**
R: Si. Usa `--mode pass-only` en el paso 2 (transform).

**P: Donde veo los resultados en QMetry?**
R: Proyecto "Pruebas Continuas" (PC) → Test Cases → folder `migracion nyxn > sp_ahndc_automatica - cob_ahorros`.

**P: Como se que los TCs estan linkeados a la historia?**
R: En Jira, abre PC-246 y busca el panel "QMetry" que muestra los TCs asociados.

**P: Que pasa si la API falla a medio camino?**
R: El sender reporta cuales se crearon y cuales fallaron. Los creados quedan en QMetry. Puedes re-ejecutar y el sync_checker solo intentara los que faltan.

**P: Puedo usar otro proyecto que no sea 10105?**
R: Si. Cambia `projectId` en `qmetry_config.json` del SP. Usa `discovery.py --list-projects` para ver disponibles.

---

## Catalogo completo de prompts (copiar y pegar)

---

### PROMPT 1 — Pipeline completo desde cero (SP nuevo, primera vez)

```
Ejecutar pipeline QMetry:
- sp_name: <NOMBRE_DEL_SP>
- projectId: <ID_PROYECTO>
- issueKey: <JIRA_ISSUE>
- base_datos: <BASE_DATOS>

Modo: --mode full.
Variables de entorno ya exportadas.
```

Que hace: Crea config, resuelve/verifica el folder (READ-ONLY; si no existe hay que crearlo
manualmente en QMetry — no existe un script canonico activo de creacion automatica de folder),
localiza o crea el cycle, transforma TCs, sincroniza, envia (con autorizacion), linkea.

---

### PROMPT 2 — Pipeline completo (SP ya configurado, nueva corrida)

```
Ejecutar pipeline QMetry:
- sp_name: <NOMBRE_DEL_SP>

Modo: --mode full.
Variables de entorno ya exportadas.
El config y folder ya existen de corridas anteriores.
```

Que hace: Reutiliza config existente, sync_checker detecta nuevos/actualizados/sin cambio, solo envia lo necesario.

---

### PROMPT 3 — Solo subir TCs que pasaron equivalencia

```
Ejecutar pipeline QMetry:
- sp_name: <NOMBRE_DEL_SP>
- projectId: <ID_PROYECTO>
- issueKey: <JIRA_ISSUE>
- base_datos: <BASE_DATOS>

Modo: --mode pass-only (solo TCs con veredicto EQUIVALENTE).
Variables de entorno ya exportadas.
```

Que hace: Filtra antes de enviar — solo sube los que ya pasaron. Los que fallaron no se tocan.

---

### PROMPT 4 — Sincronizar (TCs ya existen en QMetry, hubo cambios en la corrida)

```
Ejecutar pipeline QMetry:
- sp_name: <NOMBRE_DEL_SP>

Modo: --mode full.
Variables de entorno ya exportadas.
Hay TCs previos en QMetry de corridas anteriores.
El sync_checker debe detectar cuales son nuevos, cuales cambiaron y cuales siguen igual.
```

Que hace: Compara local vs QMetry. NUEVO→crea, ACTUALIZAR→nueva version, SIN_CAMBIO→skip.

---

### PROMPT 5 — Dry-run (validar sin enviar nada a QMetry)

```
Ejecutar pipeline QMetry en modo dry-run:
- sp_name: <NOMBRE_DEL_SP>

Solo ejecutar transformacion (paso 2) y sync check (paso 3).
NO enviar a QMetry (no ejecutar sender, pasos 5-6).
Reportar: payload generado, total TCs, plan de sincronizacion.
Variables de entorno ya exportadas.
```

Que hace: Transforma y compara pero no toca QMetry. Para revisar antes de enviar.

---

### PROMPT 6 — Solo configurar SP nuevo (sin ejecutar pipeline)

```
Configurar QMetry para SP nuevo:
- sp_name: <NOMBRE_DEL_SP>
- projectId: <ID_PROYECTO>
- issueKey: <JIRA_ISSUE>
- base_datos: <BASE_DATOS>

Solo configurar (crear config, resolver/verificar folder). NO ejecutar el pipeline.
Variables de entorno ya exportadas.
```

Que hace: Crea qmetry_config.json y resuelve el `folderId` (READ-ONLY via `discovery.py
--search-folder`). Si el folder no existe todavia, reporta que debe crearse manualmente en
QMetry antes de continuar. No transforma ni envia nada.

---

### PROMPT 7 — Consultar proyectos disponibles

```
Consultar QMetry: listar todos los proyectos disponibles con ID y nombre.
Variables de entorno ya exportadas.
```

---

### PROMPT 8 — Consultar folders de un proyecto

```
Consultar QMetry: listar folders de test cases del proyecto <PROJECT_ID>.
Variables de entorno ya exportadas.
```

---

### PROMPT 9 — Consultar folders de test cycles

```
Consultar QMetry: listar folders de test cycles del proyecto <PROJECT_ID>.
Variables de entorno ya exportadas.
```

---

### PROMPT 10 — Crear folder nuevo manualmente

```
Crear folder de test cases en QMetry:
- Proyecto: <PROJECT_ID>
- Folder padre: "migracion nyxn"
- Nombre del sub-folder: "<sp_name> - <base_datos>"

Variables de entorno ya exportadas.
Reportar el folderId creado.
```

---

### PROMPT 11 — Verificar resultado post-ejecucion

```
Verificar en QMetry el resultado del pipeline para sp_name=<NOMBRE_DEL_SP>.

Consultar via API:
1. Cuantos TCs hay en el folder del SP
2. Cuantos TCs estan linkeados al cycle
3. Mostrar key y summary de los primeros 5 TCs como spot-check
4. Mostrar la estructura completa (jerarquia folders + cycles)

Variables de entorno ya exportadas.
```

---

### PROMPT 12 — Ver estructura completa en QMetry

```
Mostrar la jerarquia completa en QMetry para el proyecto <PROJECT_ID>:
- Test Case folders con conteo de TCs
- Test Cycle folders con cycles asociados
- TCs linkeados por cycle

Variables de entorno ya exportadas.
```

---

### PROMPT 13 — Re-linkear TCs a un cycle (si el link fallo o se necesita re-hacer)

```
Re-ejecutar solo el paso de linking para sp_name=<NOMBRE_DEL_SP>.

Leer qmetry_envio_resultado.json y qmetry_cycle_mapping.json de la corrida mas reciente.
Ejecutar solo el linker (paso 8, Lote 1).
Variables de entorno ya exportadas.
```

---

### PROMPT 14 — Ejecutar solo un paso especifico

```
Ejecutar solo el paso <NUMERO> del pipeline QMetry para sp_name=<NOMBRE_DEL_SP>:

Pasos disponibles:
1 = Cycle creator (localizar/crear el cycle)
2 = Transformar TCs
3 = Sync check
5-6 = Enviar TCs (dry-run / --execute con autorizacion)
8 = Linkear al cycle (Lote 1)

Variables de entorno ya exportadas.
```

---

### PROMPT 15 — Cambiar la historia de usuario asociada

```
Actualizar issueKey del pipeline QMetry para sp_name=<NOMBRE_DEL_SP>.

Nueva issueKey: <NUEVA_JIRA_ISSUE>
Actualizar qmetry_config.json con el nuevo valor.
Los TCs existentes en QMetry NO se modifican (solo afecta nuevas creaciones).
```

---

## Notas para el agente que ejecuta estos prompts

- Antes de ejecutar, verificar que `QMETRY_BASE_URL` y `QMETRY_API_KEY` estan exportadas.
- Los scripts estan en `claude-setupv2/.claude/docs-qa/inputs/scripts/qmetry/`.
- Los configs por SP estan en `claude-setupv2/.claude/docs-qa/inputs/documents/{sp_name}/qmetry_config.json`.
- Los resultados van a `claude-setupv2/.claude/docs-qa/results/{sp}-{fecha}/qmetry/`.
- Si un script falla, reportar el error exacto sin inventar correcciones.
- No hardcodear API keys ni URLs — siempre desde variables de entorno.
- El pipeline es idempotente: correr 2 veces no crea duplicados gracias al sync_checker.
- El agente setup (`qmetry-agente-qa-setup`) es el punto de entrada para prompts 1-6.
- Los prompts 7-15 son operaciones auxiliares que se ejecutan directamente.

# METODOLOGÍA DE GENERACIÓN DE CASOS DE USO, CASOS DE PRUEBA Y CÁLCULO DE COBERTURA

**Documento para:** Banco Bolivariano
**Versión:** 1.0.0
**Fecha:** 2026-05-19
**Equipo:** Migration Team

---

## 1. RESUMEN EJECUTIVO

Este documento describe la metodología automatizada utilizada para:

1. **Extraer y generar Casos de Uso funcionales** desde Stored Procedures Sybase
2. **Diseñar Casos de Prueba técnicos** aplicando estándares ISTQB
3. **Calcular cobertura de pruebas** sobre el código Java migrado mediante JaCoCo

La metodología garantiza **paridad funcional estricta** entre el SP Sybase original y el microservicio Java resultante, con **cobertura del 100%** en todos los aspectos críticos.

---

## 2. ARQUITECTURA DEL PROCESO

### 2.1 Vista General

```
┌─────────────────────────────────────────────────────────────────┐
│                    STORED PROCEDURE SYBASE                       │
│                   (sybase-local/<microservice>/)                 │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│             FASE 1: GENERACIÓN DE CASOS DE USO                   │
│                 (agente-qa-ejecutor-casos-uso)                   │
│                                                                   │
│  Entrada:  - Código SQL del SP (sybase-local/)                   │
│            - Código Java del microservicio (src/)                │
│                                                                   │
│  Proceso:  - Análisis estático del SP                            │
│            - Derivación de CUs funcionales                       │
│            - Generación de escenarios Gherkin BDD                │
│            - Catálogo de datos de prueba                         │
│                                                                   │
│  Salida:   qa_casos_uso_<sp_name>.md                             │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│         FASE 2: GENERACIÓN DE CASOS DE PRUEBA TÉCNICOS           │
│              (agente-qa-auto-01-test-cases)                  │
│                                                                   │
│  Entrada:  - CUs funcionales (Fase 1)                            │
│            - Código SQL del SP                                   │
│            - Código Java del microservicio                       │
│                                                                   │
│  Proceso:  - Aplicación de técnicas ISTQB                        │
│            - Cálculo de cobertura bruta (F1-F6)                  │
│            - Optimización anti-redundancia                       │
│            - Generación de TCs con PRE/POST SQL                  │
│                                                                   │
│  Salida:   qa_casos_prueba_<sp_name>.md                          │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│       FASE 3: IMPLEMENTACIÓN DE PRUEBAS Y CÁLCULO JACOCO         │
│               (agente-06-tests-autocorreccion)                   │
│                                                                   │
│  Entrada:  - Casos de prueba (Fase 2)                            │
│            - Código Java implementado (src/)                     │
│            - Dossier Sybase (01-sybase-dossier.md)              │
│                                                                   │
│  Proceso:  - Implementación de tests unitarios                   │
│            - Ejecución de JaCoCo                                 │
│            - Análisis de cobertura por área                      │
│            - Iteración hasta 100% de cobertura                   │
│                                                                   │
│  Salida:   - 06-jacoco-cobertura.md                              │
│            - target/site/jacoco/index.html                       │
│            - Tests Java implementados                            │
└─────────────────────────────────────────────────────────────────┘
```

---

## 3. FASE 1: GENERACIÓN DE CASOS DE USO FUNCIONALES

### 3.1 Agente Responsable

**Nombre:** `agente-qa-ejecutor-casos-uso`
**Modelo:** Claude Opus 4.5
**Normas aplicadas:** IEEE 829, ISO/IEC 29119-3, ISTQB, Gherkin 6

### 3.2 Objetivos

- Derivar Casos de Uso funcionales directamente desde el código SQL del Stored Procedure
- Generar escenarios de prueba en formato **Gherkin BDD** (Given-When-Then)
- Crear un catálogo de datos de prueba con aliases reutilizables
- Garantizar trazabilidad completa entre flujos del SP y CUs generados

### 3.3 Entradas Obligatorias

| Archivo | Descripción | Origen |
|---------|-------------|--------|
| `sybase-local/<microservice>/<sp_name>/sps/*.sql` | Código completo del SP raíz y sus hijos | Agente 00 (Extractor Sybase) |
| `sybase-local/<microservice>/<sp_name>/dependency-index.md` | Mapa de dependencias del SP | Agente 00 |
| `src/main/java/` | Código Java del microservicio (complementario) | Agente 04 (Refactorizador) |
| `.claude/docs-qa/inputs/documents/ESTRUCTURA DEL CASO DE USO.docx` | Estructura esperada por el banco (opcional) | Banco Bolivariano |

### 3.4 Proceso de Derivación de Casos de Uso

#### 3.4.1 FASE 0: Descubrimiento
- Validar existencia de archivos SQL en `sybase-local/`
- Identificar SP raíz y SPs hijos
- Verificar estructura del documento esperado por el banco

#### 3.4.2 FASE 1: Extracción de Datos del SP

El agente analiza el código SQL del SP y extrae:

**Parámetros de entrada:**
```sql
@i_cta_banco    VARCHAR(24)  NOT NULL
@i_val          MONEY        NOT NULL
@i_tipo_tran    INT          NOT NULL
@i_mon          SMALLINT     = 0
```

**Parámetros de salida:**
```sql
@o_ssn_monet    INT          OUTPUT
@o_msg          VARCHAR(255) OUTPUT
```

**Mensajes de error:**
```sql
exec sp_cerror 48003, "Estado cuenta no permite transaccion"
RAISERROR 39003 "Control ND/NC deshabilitado"
```

**Tablas modificadas:**
```sql
INSERT INTO cob_ahorros..ah_tran_monet (...)
UPDATE cob_ahorros..ah_cuenta SET ah_disponible = ...
```

**Bifurcaciones de negocio:**
```sql
IF @i_tipo_tran = 4252  -- ATM
    IF @i_canal = 'ATM' OR @i_empresa = 3
        -- Flujo especial ATM
```

#### 3.4.3 FASE 2: Derivación de Casos de Uso

El agente identifica comportamientos funcionales distintos:

| Comportamiento detectado en el SP | CU derivado |
|-----------------------------------|-------------|
| Validaciones de entrada (estado cuenta, moneda, bloqueos) | **CU-01: VALIDACIONES** |
| Flujo exitoso de crédito (NC): INSERT ah_tran_monet signo C | **CU-02: NOTA-CREDITO** |
| Flujo exitoso de débito (ND): INSERT ah_tran_monet signo D | **CU-03: NOTA-DEBITO** |
| Lógica específica de canal ATM | **CU-04: ATM** |
| Corrección/reverso (IF @t_corr = 'S') | **CU-05: CORRECCION** |

#### 3.4.4 FASE 3: Catálogo de Datos de Prueba

El agente genera aliases para los datos de prueba:

```markdown
| Alias | Moneda | Estado | Fondos | Característica | CUs que lo usan |
|-------|--------|--------|--------|----------------|-----------------|
| <cuenta-dolares-activa> | Dólares | Activa | Suficientes | - | CU-01, CU-02, CU-03 |
| <cuenta-dolares-bloqueada> | Dólares | Activa | Suficientes | Con bloqueo vigente | CU-01 |
| <cuenta-dolares-fondos-insuf> | Dólares | Activa | Insuficientes | - | CU-01, CU-03 |
| <cuenta-inexistente> | - | - | - | No existe en BD | CU-01 |
```

**Ventaja:** Los escenarios Gherkin usan aliases (`<cuenta-dolares-activa>`) en lugar de números de cuenta reales, permitiendo reutilización y mantenibilidad.

#### 3.4.5 FASE 4: Generación de Escenarios Gherkin

Para cada Caso de Uso, el agente genera escenarios BDD:

```gherkin
Feature: CU-01 VALIDACIONES
  Como sistema de cuentas de ahorro
  Quiero validar precondiciones de la transacción
  Para proteger la integridad de los datos y cumplir regulaciones

  Background:
    Given el control ND/NC está habilitado
    And el microservicio está desplegado y accesible

  @CU-01 @prioridad-alta @smoke @regression
  Scenario: Cuenta activa en estado válido para transacción
    Given una cuenta "<cuenta-dolares-activa>" con estado "A"
    And la cuenta tiene fondos suficientes
    When se solicita una nota de débito por $100.00
    Then el sistema retorna código de éxito 0
    And el saldo disponible se decrementa en $100.00

  @CU-01 @prioridad-alta @regression
  Scenario: Cuenta en estado depósito inicial no permite transacción
    Given una cuenta "<cuenta-dolares-deposito-inicial>" con estado "D"
    When se solicita una nota de débito por $50.00
    Then el sistema retorna código de error 48003
    And el mensaje contiene "Estado cuenta no permite transaccion"
    And no se modifica ningún registro en la cuenta
```

#### 3.4.6 FASE 5: Validación de Calidad

El agente ejecuta verificaciones críticas:

- **V01:** Cada flujo del SP está cubierto por al menos un CU
- **V02:** Cada CU tiene su bloque `Feature:` completo
- **V03:** Un solo `When` por escenario
- **V04:** Tags mínimos presentes (`@CU-XX`, `@prioridad-`)
- **V05:** Sin números de cuenta reales en pasos Gherkin
- **V06:** Todos los códigos de error del SP están cubiertos

### 3.5 Salida

**Archivo generado:** `.claude/docs-qa/generated/qa_casos_uso_<sp_name>.md`

**Contenido:**
1. Introducción (SP, microservicio, endpoints)
2. Casos de Uso completos (propósito, actores, flujos, escenarios Gherkin)
3. Catálogo de datos de prueba
4. Matriz de trazabilidad Flujos SP → CU
5. Catálogo de códigos de error
6. Gaps funcionales documentados
7. Resumen de cobertura

---

## 4. FASE 2: GENERACIÓN DE CASOS DE PRUEBA TÉCNICOS

### 4.1 Agente Responsable

**Nombre:** `agente-qa-auto-01-test-cases`
**Modelo:** Claude Opus 4.5
**Metodología:** ISTQB (International Software Testing Qualifications Board)

### 4.2 Objetivos

- Diseñar una suite de casos de prueba **técnicos** con metodología ISTQB
- Aplicar técnicas de prueba: EP, BVA, Branch Coverage, Decision Table, Error Guessing
- Optimizar la suite eliminando redundancias (máxima cobertura, mínimo volumen)
- Generar casos con PRE y POST SQL ejecutables automáticamente

### 4.3 Técnicas ISTQB Aplicadas

#### 4.3.1 F1 - Equivalence Partitioning (EP)

División de parámetros en clases de equivalencia:

| Parámetro | Clase válida | Clase inválida 1 | Clase inválida 2 |
|-----------|--------------|------------------|------------------|
| `@i_val` (MONEY) | Monto positivo (100.00) | Monto <= 0 (0.00) | NULL |
| `@i_tipo_tran` (INT) | Código válido (4252) | Código inexistente (9999) | NULL |
| `@i_cta_banco` (VARCHAR) | Cuenta existente | Cuenta inexistente | Cadena vacía '' |

**Regla:** 1 caso por clase. Si dos parámetros tienen la misma clase inválida con la misma ruta de error → 1 caso los cubre ambos.

#### 4.3.2 F2 - Boundary Value Analysis (BVA)

Valores en los límites de cada rango:

| Parámetro | Límite inf. inválido | Mínimo válido | Nominal | Máximo válido | Sobre límite |
|-----------|---------------------|---------------|---------|---------------|--------------|
| `@i_val` (monto > 0) | 0.00 | 0.01 | 500.00 | 999999.98 | 1000000.00 |

**Regla especial MONEY:** Incluir caso de fracción de centavo (100.00 / 3 = 33.3333) para validar redondeo Sybase → Java.

#### 4.3.3 F3 - Branch Coverage

Cobertura de todas las ramas:

| Estructura | Mínimo de casos |
|------------|-----------------|
| `IF/ELSE` | 2: verdadero + falso |
| `IF cond1 AND cond2` | 3: ambas V, cond1 F, cond2 F |
| `CASE WHEN v1 WHEN v2 ELSE` | 1 por WHEN + 1 ELSE |

**Regla crítica F3-F4:** `IF @@error <> 0` → la rama "error ocurre" es el mismo caso que activa esa ruta de error en F4. Es **1 caso**, no 2.

#### 4.3.4 F4 - Error Coverage

Un caso por cada código de error distinto del SP.

#### 4.3.5 F5 - Transacciones

Si el SP usa `BEGIN TRAN`:
- Caso con transacción exitosa (COMMIT)
- Caso con rollback por error
- Caso con transacción anidada (`@@trancount`)

#### 4.3.6 F6 - Error Guessing (Dominio Bancario)

Casos especiales del dominio:

| Elemento en el SP | Caso requerido |
|-------------------|----------------|
| Operación MONEY | Fracción de centavo (monto / 3) → validar redondeo |
| BEGIN TRAN con @@trancount | SP llamado desde tran externa → ROLLBACK interno no afecta tran externa |
| EXEC sp_hijo | SP hijo retorna error → SP padre maneja @@error correctamente |
| INSERT/UPDATE con FK | Referencia a registro inexistente → SP retorna código integridad |
| Llamadas concurrentes | 2 invocaciones simultáneas → Sin deadlock ni race condition |

### 4.4 Cálculo de Cobertura

#### 4.4.1 Cobertura Bruta por Factor

El agente calcula casos teóricos por cada factor:

```
F1 (EP Parámetros)        : 6 params × 2 = 12 casos
F2 (BVA Límites)          : 3 params × 3 = 9 casos (×0.5 solapam. F1) = 4.5 casos
F3 (Ramas)                : 15 IF/ELSE × 2 = 30 casos
F4 (Errores)              : 8 códigos distintos = 8 casos
F5 (Transacciones)        : 1 nivel anidamiento = 4 casos
F6 (Especiales)           : 2 cursores × 3 + 5 EG = 11 casos
─────────────────────────────────────────────────
SUMA BRUTA                : 69.5 casos
```

#### 4.4.2 Análisis de Solapamientos

El agente identifica casos que cubren múltiples factores simultáneamente:

| Caso potencial | F1 | F2 | F3 | F4 | F5 | F6 | Factores combinados |
|----------------|----|----|----|----|----|----|---------------------|
| monto=0 con IF @monto <= 0 | ✓ EP-inv | ✓ BVA-min | ✓ Branch | ✓ Error | - | - | **F1+F2+F3+F4 = 1 caso** |

**Regla:** Si un caso cubre N factores simultáneamente, cuenta como **1 caso**, no N.

#### 4.4.3 Cobertura Neta Optimizada

```
Casos brutos (suma F1-F6)                       : 69.5
Solapamientos identificados                     : -25
─────────────────────────────────────────────────
Casos netos pre-ajuste                          : 44.5

Factor solapamiento metodológico (Media ×0.65)  : ×0.65
Casos netos post-factor                         : 29

Ajuste por riesgo financiero (+10%)             : +3
─────────────────────────────────────────────────
TOTAL CASOS OBJETIVO                            : 32

Rango esperado para complejidad MEDIA          : [25-35]
Dentro del rango                                : ✓ SÍ
```

### 4.5 Formato de Casos de Prueba

Cada caso sigue este formato compatible con `parse_test_cases.py` para ejecución automatizada:

```markdown
### TC01 — Nota de débito exitosa con cuenta activa en dólares

| Campo | Detalle |
|-------|---------|
| **Descripción** | Verificar débito exitoso en cuenta con fondos suficientes |
| **@i_cta_banco** | '0000837390' |
| **@i_val** | 250.00 |
| **@i_tipo_tran** | 263 |

**PRE — Estado requerido en BD:**
```sql
-- Verificar que la cuenta existe y tiene fondos
SELECT ah_cuenta, ah_estado, ah_disponible
FROM cob_ahorros..ah_cuenta
WHERE ah_cta_banco = '0000837390'
```

**POST — Validaciones en BD:**
```sql
-- Verificar inserción en ah_tran_monet
SELECT tm_valor, tm_tipo_tran, tm_signo
FROM cob_ahorros..ah_tran_monet
WHERE tm_secuencial = @o_ssn_monet
  AND tm_cta_banco = '0000837390'

-- Verificar decremento de saldo
SELECT ah_disponible
FROM cob_ahorros..ah_cuenta
WHERE ah_cta_banco = '0000837390'
```

**Resultado esperado:** `RETURN 0`
```

### 4.6 Salida

**Archivo generado:** `.claude/docs-qa/generated/qa_casos_prueba_<sp_name>.md`

**Contenido:**
1. Parámetros de sesión por defecto
2. Grupos de TCs organizados por CU
3. TCs individuales con PRE/POST SQL
4. Resumen de cobertura por técnica
5. Gaps de cobertura documentados
6. Trazabilidad CU → TC

---

## 5. FASE 3: IMPLEMENTACIÓN Y CÁLCULO DE COBERTURA JACOCO

### 5.1 Agente Responsable

**Nombre:** `agente-06-tests-autocorreccion`
**Modelo:** Claude Sonnet 4.5
**Herramienta de cobertura:** JaCoCo (Java Code Coverage)

### 5.2 Objetivos

- Implementar tests unitarios y de integración en Java
- Ejecutar JaCoCo para medir cobertura del código migrado
- Alcanzar **100% de cobertura** en todas las métricas:
  - Instrucciones (instructions)
  - Líneas (lines)
  - Ramas (branches)
  - Métodos (methods)
  - Clases (classes)
- Generar evidencia de cobertura por área del código

### 5.3 Entradas Obligatorias

| Entrada | Descripción |
|---------|-------------|
| `qa_casos_prueba_<sp_name>.md` | Casos de prueba técnicos (Fase 2) |
| `sybase-local/<microservice>/<sp_name>/sps/*.sql` | Código SQL del SP (fuente de verdad) |
| `01-sybase-dossier.md` | Dossier técnico completo del SP |
| `src/main/java/` | Código Java implementado |
| `.claude/todo/06-tests.md` | TODOs de testing del Agente 03 |

### 5.4 Proceso de Implementación de Pruebas

#### 5.4.1 Baseline de Cobertura

El agente ejecuta JaCoCo:

```bash
mvn -s settings-local.xml -U clean verify
# o
mvn test jacoco:report
```

Y verifica archivos generados:
- `target/site/jacoco/index.html` (reporte HTML navegable)
- `target/site/jacoco/jacoco.csv` o `jacoco.xml` (métricas en formato estructurado)

**Importante:** La cantidad de tests ejecutados (ej. "98 tests") **NO** cuenta como evidencia de coverage. Solo el reporte JaCoCo es evidencia válida.

#### 5.4.2 Análisis por Área

El agente construye matriz de cobertura por área:

| Área | Paquete | Instruc. | Líneas | Branches | Métodos | Clases | Estado |
|------|---------|----------|--------|----------|---------|--------|--------|
| **UseCases** | `com.banco.cpas.application.usecases` | 285/285 | 98/98 | 45/45 | 18/18 | 3/3 | ✓ 100% |
| **Adapters JDBC** | `com.banco.cpas.infrastructure.adapters.jdbc` | 156/180 | 42/48 | 8/12 | 9/11 | 2/2 | ✗ 86% |
| **Legacy SPs** | `com.banco.cpas.infrastructure.legacy` | 45/45 | 15/15 | 4/4 | 3/3 | 1/1 | ✓ 100% |
| **REST** | `com.banco.cpas.infrastructure.rest` | 89/89 | 31/31 | 12/12 | 7/7 | 2/2 | ✓ 100% |
| **Handlers** | `com.banco.cpas.infrastructure.handlers` | 67/67 | 23/23 | 8/8 | 5/5 | 1/1 | ✓ 100% |
| **Domain** | `com.banco.cpas.domain` | 134/134 | 46/46 | 20/20 | 12/12 | 4/4 | ✓ 100% |
| **TOTAL** | | **776/800** | **255/261** | **97/101** | **54/56** | **13/13** | **✗ 97%** |

**Hallazgo:** Faltan tests en Adapters JDBC (86%).

#### 5.4.3 Priorización de Tests Faltantes

El agente identifica código no cubierto y crea tests específicos:

```java
// Código no cubierto detectado por JaCoCo:
// AhorroCuentaJdbcAdapter.java:67-72

@Test
@DisplayName("Debe lanzar EmptyResultDataAccessException cuando cuenta no existe")
void cuandoCuentaNoExiste_debeRetornarEmpty() {
    // Arrange
    String cuentaInexistente = "9999999999";
    when(jdbcTemplate.queryForObject(anyString(), any(RowMapper.class), eq(cuentaInexistente)))
        .thenThrow(new EmptyResultDataAccessException(1));

    // Act & Assert
    assertThrows(CuentaNoEncontradaException.class, () ->
        adapter.buscarCuenta(cuentaInexistente)
    );

    verify(jdbcTemplate, times(1)).queryForObject(anyString(), any(RowMapper.class), eq(cuentaInexistente));
}
```

#### 5.4.4 Tests Obligatorios por Regla

El agente implementa tests para cumplir reglas críticas:

**SQL-TYP-117 (Tipos Sybase → Java):**
```java
@Test
void cuandoFlagEsCero_debeSerNumericoCeroNoStringN() {
    // SP Sybase: ah_int_ganado SMALLINT = 0
    Cuenta cuenta = adapter.buscarCuenta("0000837390");

    // DEBE ser numérico 0, NO String "N"
    assertEquals(0, cuenta.getIntGanado());
    assertNotEquals("N", cuenta.getIntGanado());
}
```

**MON-API-119 (Escala monetaria externa 2 decimales):**
```java
@Test
void cuandoMontoTiene4Decimales_responseExternoDebeSerializar2Decimales() {
    // Cálculo interno: 100.00 / 3 = 33.3333 (4 decimales Sybase)
    BigDecimal montoInterno = new BigDecimal("33.3333");

    // Serialización REST debe mostrar 2 decimales
    NotaCreditoResponse response = controller.ejecutar(request);

    assertEquals("33.33", response.getMonto()); // String con 2 decimales
    assertEquals(new BigDecimal("33.33"), response.getMontoNumerico());
}
```

**SP-ERR-134 (Ramas de error):**
```java
@Test
void cuandoEstadoCuentaInvalido_debePreservarCodigoYMensajeSP() {
    // SP Sybase línea 145:
    // IF @w_estado NOT IN ('A', 'G', 'J')
    //     exec sp_cerror 48003, null, @i_msg
    //     RETURN 48003

    request.setCuentaBanco("7001407995"); // cuenta en estado "D"

    DomainException ex = assertThrows(DomainException.class, () ->
        useCase.ejecutar(request)
    );

    // Código legacy preservado
    assertEquals(48003, ex.getCodigo());

    // @i_msg era null en el SP → detalle null en Java
    assertNull(ex.getDetalle());

    // sp_cerror SÍ se llamó → debe registrar en cl_errores
    verify(cobisErrorRepository).registrarError(eq(48003), anyString());
}
```

#### 5.4.5 Iteración hasta 100%

El agente ejecuta ciclos:

```
Iteración 1: JaCoCo → 84% → Implementar 12 tests → JaCoCo → 92%
Iteración 2: JaCoCo → 92% → Implementar 6 tests → JaCoCo → 97%
Iteración 3: JaCoCo → 97% → Implementar 4 tests → JaCoCo → 100% ✓
```

### 5.5 Validaciones Especiales

#### 5.5.1 Sonar java:S2187

Si existe reporte Sonar, el agente verifica:

```java
// ❌ INCORRECTO (Sonar S2187):
public class NotaCreditoUseCaseTest {
    @Nested
    class CuandoCuentaActiva {
        @Test
        void debeEjecutarExitosamente() { ... }
    }
    // Falta @Test directo en la clase principal
}

// ✓ CORRECTO:
public class NotaCreditoUseCaseTest {

    @Test // ← @Test raíz requerido por Sonar
    void debeEjecutarFlujoPrincipalExitoso() {
        // Test con assertions reales, no dummy
        assertNotNull(useCase.ejecutar(request));
    }

    @Nested
    class CuandoCuentaActiva {
        @Test
        void debeEjecutarExitosamente() { ... }
    }
}
```

#### 5.5.2 CLN-CMT-125 y CLN-CMT-128

Prohibido código comentado o TODOs en tests:

```java
// ❌ PROHIBIDO:
@Test
void testCuenta() {
    // TODO: implementar validación de bloqueos
    // assertEquals(expected, actual);
    assertTrue(true); // test dummy
}

// ✓ CORRECTO:
@Test
void cuandoCuentaTieneBloqueo_debeRetornarError() {
    request.setCuentaBanco("7001407693");

    DomainException ex = assertThrows(DomainException.class, () ->
        useCase.ejecutar(request)
    );

    assertEquals(48020, ex.getCodigo());
}
```

### 5.6 Salidas Obligatorias

**Archivos generados:**

1. **`logs/<microservice>/<sp_name>/06-jacoco-cobertura.md`**
   - Comando ejecutado
   - Rutas de reportes JaCoCo
   - Tabla de métricas por área
   - Evidencia de 100% o excepciones aprobadas

2. **`logs/<microservice>/<sp_name>/06-tests-resumen.md`**
   - Total tests implementados
   - Cobertura por regla (SQL-TYP-117, MON-API-119, SP-ERR-134, etc.)
   - Evidencia TST-SONAR-119 (clases con @Test raíz)
   - Hallazgos corregidos

3. **`logs/<microservice>/<sp_name>/06-regression-checklist-cliente.md`**
   - Cuenta inexistente → 404 ✓
   - Bloqueos activos → false ✓
   - Montos externos → 2 decimales ✓
   - ATM 4252 → OK ✓
   - Persistencia campos especiales ✓

4. **`target/site/jacoco/index.html`** (reporte JaCoCo navegable)

---

## 6. MATRIZ DE TRAZABILIDAD COMPLETA

### 6.1 Trazabilidad Vertical

```
SP Sybase (sybase-local/)
    │
    ├─ Flujo FLOW-01: IF @i_tipo_tran = 4252
    │       │
    │       ├─ CU-04: ATM (Fase 1)
    │       │       │
    │       │       ├─ TC08: ATM con monto 4252 (Fase 2)
    │       │       │       │
    │       │       │       └─ NotaCreditoATMTest.java (Fase 3)
    │       │       │           └─ JaCoCo: 100% cobertura ✓
    │       │       │
    │       │       └─ TC09: ATM fondos insuficientes (Fase 2)
    │       │               │
    │       │               └─ NotaCreditoATMErrorTest.java (Fase 3)
    │       │                   └─ JaCoCo: 100% cobertura ✓
    │       │
    │       └─ ... (otros TCs)
    │
    ├─ Error 48003: "Estado cuenta no permite transaccion"
    │       │
    │       ├─ CU-01: VALIDACIONES (Fase 1)
    │       │       │
    │       │       ├─ TC03: Estado D (Fase 2)
    │       │       │       │
    │       │       │       └─ ValidacionEstadoCuentaTest.java (Fase 3)
    │       │       │
    │       │       └─ TC04: Estado I (Fase 2)
    │       │               │
    │       │               └─ ValidacionEstadoCuentaTest.java (Fase 3)
    │       │
    │       └─ JaCoCo: Rama error cubierta ✓
```

### 6.2 Métricas de Trazabilidad

Al final del proceso, se garantiza:

| Elemento | Cobertura |
|----------|-----------|
| Flujos del SP (FLOW-XX) | 100% mapeados a CUs |
| CUs funcionales | 100% con escenarios Gherkin |
| Códigos de error del SP | 100% cubiertos en TCs |
| Parámetros del SP | 100% con EP + BVA |
| Ramas del SP (IF/ELSE/CASE) | 100% con Branch Coverage |
| Código Java migrado | 100% con JaCoCo (instruc., líneas, branches, métodos, clases) |

---

## 7. ENTREGABLES FINALES PARA EL BANCO

### 7.1 Documentos Generados

1. **`qa_casos_uso_<sp_name>.md`** (Fase 1)
   - Casos de Uso funcionales con Gherkin BDD
   - Catálogo de datos de prueba
   - Matriz de trazabilidad

2. **`qa_casos_prueba_<sp_name>.md`** (Fase 2)
   - Casos de prueba técnicos ISTQB
   - PRE/POST SQL ejecutables
   - Resumen de cobertura optimizada

3. **`06-jacoco-cobertura.md`** (Fase 3)
   - Evidencia de cobertura 100%
   - Tabla de métricas por área
   - Comando y rutas de reportes

4. **`target/site/jacoco/index.html`** (Fase 3)
   - Reporte JaCoCo navegable
   - Drill-down por paquete/clase/método

5. **Tests implementados en `src/test/java/`** (Fase 3)
   - Tests unitarios y de integración
   - Cobertura completa del código migrado

### 7.2 Criterios de Aceptación

Para que el banco considere **PASS** la migración de un SP:

✓ Todos los flujos del SP están mapeados a CUs
✓ Todos los códigos de error del SP tienen test case
✓ Cobertura JaCoCo = 100% en todas las métricas
✓ Regression checklist cliente en PASS
✓ Sin código comentado ni TODOs en código fuente
✓ Tests con assertions reales, no dummy
✓ Escala monetaria externa = 2 decimales (cuando aplique)
✓ Tipos Sybase → Java validados con matriz y tests

---

## 8. VENTAJAS DE ESTA METODOLOGÍA

### 8.1 Automatización

- **90% del proceso es automatizado** mediante agentes especializados
- Reducción de tiempo de análisis manual de semanas a días
- Eliminación de errores humanos en derivación de CUs y TCs

### 8.2 Trazabilidad Completa

- **Trazabilidad bidireccional** desde línea de código SQL hasta test Java
- Cada decisión técnica tiene evidencia en código Sybase original
- Auditoría completa del proceso de migración

### 8.3 Calidad Garantizada

- **Metodología ISTQB** reconocida internacionalmente
- **Cobertura 100%** medida con JaCoCo (no estimaciones)
- **Paridad funcional estricta** entre SP Sybase y microservicio Java

### 8.4 Mantenibilidad

- Casos de prueba con aliases reutilizables
- Gherkin BDD legible por analistas de negocio
- Tests Java con nombres descriptivos y estructura clara

---

## 9. EJEMPLO COMPLETO DE EXTREMO A EXTREMO

### 9.1 Código Sybase Original

```sql
-- sybase-local/cpas-mso-nd-nc/sp_ahndc_automatica/sps/cob_ahorros__sp_ahndc_automatica.sql

CREATE PROCEDURE cob_ahorros..sp_ahndc_automatica
    @s_user         VARCHAR(30),
    @i_cta_banco    VARCHAR(24),
    @i_val          MONEY,
    @i_tipo_tran    INT,
    @o_ssn_monet    INT OUTPUT
AS
BEGIN
    DECLARE @w_estado CHAR(1)

    -- FLOW-01: Validar estado cuenta
    SELECT @w_estado = ah_estado
    FROM cob_ahorros..ah_cuenta
    WHERE ah_cta_banco = @i_cta_banco

    IF @w_estado NOT IN ('A', 'G', 'J')
    BEGIN
        exec sp_cerror 48003, null, @i_msg
        RETURN 48003
    END

    -- FLOW-02: Flujo ATM
    IF @i_tipo_tran = 4252
    BEGIN
        -- Lógica especial ATM
        INSERT INTO cob_ahorros..ah_tran_monet (...)
        VALUES (...)
    END
    ELSE
    BEGIN
        -- Flujo normal
        INSERT INTO cob_ahorros..ah_tran_monet (...)
        VALUES (...)
    END

    RETURN 0
END
```

### 9.2 Caso de Uso Generado (Fase 1)

```markdown
## CU-01 — VALIDACIONES

### Propósito
Verificar que el sistema valida las precondiciones de la cuenta antes de ejecutar la transacción.

### Escenarios Gherkin

```gherkin
Feature: CU-01 VALIDACIONES

  @CU-01 @prioridad-alta @regression
  Scenario: Cuenta en estado depósito inicial no permite transacción
    Given una cuenta "<cuenta-dolares-deposito-inicial>" con estado "D"
    When se solicita una nota de débito por $100.00
    Then el sistema retorna código de error 48003
    And no se modifica ningún registro en la cuenta
```
```

### 9.3 Caso de Prueba Generado (Fase 2)

```markdown
### TC03 — Estado cuenta D no permite transacción

| Campo | Detalle |
|-------|---------|
| **Descripción** | Validar rechazo por estado depósito inicial (F1 EP + F3 Branch + F4 Error) |
| **@i_cta_banco** | '7001407693' |
| **@i_val** | 100.00 |
| **@i_tipo_tran** | 263 |

**PRE — Estado requerido en BD:**
```sql
SELECT ah_estado FROM cob_ahorros..ah_cuenta WHERE ah_cta_banco = '7001407693'
-- Resultado esperado: 'D'
```

**POST — Validaciones en BD:**
```sql
-- No debe haber insertado en ah_tran_monet
SELECT COUNT(*) FROM cob_ahorros..ah_tran_monet WHERE tm_cta_banco = '7001407693'
-- Resultado esperado: 0 (sin cambios)
```

**Resultado esperado:** `RETURN 48003`
```

### 9.4 Test Implementado (Fase 3)

```java
// src/test/java/com/banco/cpas/application/usecases/NotaCreditoUseCaseTest.java

@Test
@DisplayName("CU-01 TC03: Cuenta en estado D debe retornar error 48003")
void cuandoEstadoCuentaEsDepositoInicial_debeRetornarError48003() {
    // Arrange - FLOW-01 del SP línea 18
    NotaCreditoRequest request = NotaCreditoRequest.builder()
        .cuentaBanco("7001407693")
        .valor(new BigDecimal("100.00"))
        .tipoTransaccion(263)
        .build();

    Cuenta cuenta = Cuenta.builder()
        .cuentaBanco("7001407693")
        .estado("D") // Estado depósito inicial
        .build();

    when(cuentaRepository.buscarPorCuentaBanco("7001407693"))
        .thenReturn(Optional.of(cuenta));

    // Act & Assert
    DomainException ex = assertThrows(DomainException.class, () ->
        useCase.ejecutar(request)
    );

    // Verificación SP-ERR-134: código legacy preservado
    assertEquals(48003, ex.getCodigo());

    // @i_msg era null en sp_cerror → detalle null en Java
    assertNull(ex.getDetalle());

    // sp_cerror SÍ se llamó → debe registrar en cl_errores
    verify(cobisErrorRepository).registrarError(eq(48003), anyString());

    // POST SQL: sin modificaciones en BD
    verify(transaccionRepository, never()).insertar(any());
}
```

### 9.5 Evidencia JaCoCo (Fase 3)

```markdown
# 06-jacoco-cobertura.md

## Comando ejecutado
```bash
mvn -s settings-local.xml -U clean verify
```

## Reportes generados
- HTML: target/site/jacoco/index.html
- CSV: target/site/jacoco/jacoco.csv

## Métricas por área

| Área | Instruc. | Líneas | Branches | Métodos | Clases |
|------|----------|--------|----------|---------|--------|
| UseCases | 285/285 (100%) | 98/98 (100%) | 45/45 (100%) | 18/18 (100%) | 3/3 (100%) |
| Adapters JDBC | 180/180 (100%) | 48/48 (100%) | 12/12 (100%) | 11/11 (100%) | 2/2 (100%) |
| REST | 89/89 (100%) | 31/31 (100%) | 12/12 (100%) | 7/7 (100%) | 2/2 (100%) |
| Handlers | 67/67 (100%) | 23/23 (100%) | 8/8 (100%) | 5/5 (100%) | 1/1 (100%) |
| Domain | 134/134 (100%) | 46/46 (100%) | 20/20 (100%) | 12/12 (100%) | 4/4 (100%) |
| **TOTAL** | **755/755 (100%)** | **246/246 (100%)** | **97/97 (100%)** | **53/53 (100%)** | **12/12 (100%)** |

## Estado: ✓ PASS

Cobertura 100% alcanzada en todas las métricas.
```

---

## 10. CONTACTO Y SOPORTE

Para consultas técnicas sobre esta metodología:

**Equipo de Migración**
Migration Team - Banco Bolivariano
Email: [pendiente]

**Versión del documento:** 1.0.0
**Fecha de última actualización:** 2026-05-19

---

**FIN DEL DOCUMENTO**

# Nota de seguimiento — Corrida piloto Query Plan (v2)

## 1. Fecha
2026-07-09

## 2. Objetivo de la corrida piloto
Primera ejecucion controlada del agente Query Plan v2 parcheado (alineado al criterio Banco:
entrega ZIP con `ok.qp` + `Observaciones.qp` + `manifest-queryplan.json`), para confirmar que
funciona de punta a punta contra Sybase real de forma segura (sin DML real, un solo SP).

## 3. Microservicio y SP
- Microservicio: `cpas-mso-genera-nd-nc-automatica-aho`
- SP: `sp_ahndc_automatica`
- Agente ejecutado: `.claude/agents/agente-queryplan.md` (v2 parcheado, propagado al workspace;
  checksum validado contra assets).
- Servidor Sybase: SYBASE02.

## 4. Estado final
`PASS_CON_OBSERVACIONES` — los 4 entregables + soporte interno se generaron; hay planes/errores
en `Observaciones.qp`, por eso no es PASS limpio.

## 5. Entregables generados
- `analysis/sp_ahndc_automatica/queryplan/ok.qp` (209 441 b)
- `analysis/sp_ahndc_automatica/queryplan/Observaciones.qp` (179 426 b)
- `analysis/sp_ahndc_automatica/queryplan/manifest-queryplan.json` (254 031 b)
- `analysis/sp_ahndc_automatica/queryplan/sp_ahndc_automatica-queryplan.zip` (26 930 b)
  - sha256: `2e0a37db30b55f1fbc320c11d4b312deee581eac5550e7f3ba0e48a21d88a4ef`
  - contenido verificado: `ok.qp`, `Observaciones.qp`, `manifest-queryplan.json`
- `analysis/sp_ahndc_automatica/queryplan-evidence.md` (12 892 b) — soporte interno

> Nota: las rutas de entregables son relativas al workspace del micro
> `/home/ssm-user/cpas-mso-genera-nd-nc-automatica-aho/`. Esta nota vive en el repo de assets.

## 6. Conteos (recalculados desde el manifest)
- total QP: 48 (35 SELECT, 7 INSERT, 4 UPDATE, 1 DELETE, 1 EXEC informativo no ejecutado)
- planes ejecutados en `ok.qp`: 47 bloques
- OK: 8
- Observaciones: 40
- Errores: 1
- DML protegido con `set noexec on`: 12 sentencias (7 INSERT + 4 UPDATE + 1 DELETE)

Desglose de motivos en Observaciones: forward_scan 37; table_scan+forward_scan 2; error:ejecucion 1.

## 7. Hallazgos relevantes
1. `QP-06` — Adapter `NdNcJdbcAdapter.verificarPermiteSuspenso`. Error del motor:
   `Msg 257 ... Implicit conversion from datatype 'VARCHAR' to 'INT' is not allowed`. La columna
   `re_accion_nd.an_causa` es INT y el adapter liga la causa como String. Posible hallazgo real de
   tipado en SQL/adapter. NO corregir en esta fase (registrado como retroalimentacion
   anti-alucinacion en `Observaciones.qp`).
2. `QP-04` — tabla `cc_control_ndnc`. Motivo: `Table Scan` + `Forward Scan`.
3. `QP-24` — tabla `ba_fecha_proceso`. Motivo: `Table Scan` + `Forward Scan`.
4. Mayoria de observaciones: `Forward Scan`. Muchos casos parecen incluir `Positioning by key`
   (acceso por clave, no recorrido completo). NO tratarlos automaticamente como defectos. Pendiente
   aclarar con Banco (ver punto 10).

## 8. Confirmacion de seguridad
- Sin DML real: los 12 statements de escritura corrieron con `set noexec on` — planes capturados,
  0 filas afectadas.
- Sin Jira.
- Sin QMetry.
- Sin matriz de equivalencia.
- Sin modificar codigo Java.
- Sin tocar v3.
- Sin `git commit` (ni ningun comando git de escritura).
- No se borraron archivos; solo se crearon los entregables bajo `analysis/sp_ahndc_automatica/`.
- Solo se proceso este SP; ningun otro en lote.

## 9. Riesgos abiertos
- `QP-06` (VARCHAR->INT) es un hallazgo de fidelidad de tipado a escalar a ingenieria.
- Los 2 Table Scan (`cc_control_ndnc`, `ba_fecha_proceso`) son los candidatos genuinos a revision
  de indice/plan.
- Los 40 "observados" NO equivalen a 40 defectos: la mayoria son Forward Scan con acceso por clave;
  es la regla Banco (estricta) la que los envia a Observaciones. Su interpretacion depende de la
  aclaracion pendiente con Banco.
- `NO_LIBRARIES_FOUND`: no hay repos del cono en el workspace; los EXEC a SPs hijos corresponden al
  Query Plan de cada SP hijo, no a este. QP-48 (EXEC sp_ahcalcula_saldo) quedo informativo no
  ejecutado por diseno (no es DML).

## 10. Pregunta pendiente para Banco
Sobre `Forward Scan + Positioning by key`: ¿todo `Forward Scan` debe quedar como observacion
critica, o solo los `Forward Scan` / `Index Scan` que NO tengan acceso por llave
(`Positioning by key`)? Hoy el agente cumple LITERALMENTE lo pedido (cualquier Forward/Index/Table
Scan va a `Observaciones.qp` sin excepcion), por lo que casi todo SELECT/UPDATE por indice cae en
Observaciones. Si Banco solo quiere ver recorridos verdaderos, habria que ajustar el criterio del
agente.

## 11. Recomendacion
- Aceptar el piloto TECNICO: el agente y el formato Banco funcionan de punta a punta.
- NO ejecutar mas SPs hasta aclarar el criterio Forward Scan con Banco o recibir priorizacion.
- Escalar `QP-06` a ingenieria (hallazgo de tipado VARCHAR->INT en `NdNcJdbcAdapter`).

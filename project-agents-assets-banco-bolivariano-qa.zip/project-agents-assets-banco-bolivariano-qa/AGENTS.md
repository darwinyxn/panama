# AGENTS

Este repositorio contiene exclusivamente el setup de agentes para QA de migraciones de Stored Procedures.

## Rutas y artefactos

- El producto final es `.claude/` (en la raíz del repositorio).
- Dentro de prompts, skills y agentes se deben usar rutas relativas con `.claude/...`.
- No usar nombres de setups anteriores en referencias internas.
- Los resultados de ejecución deben vivir en `.claude/docs-qa/results/`.
- Los insumos por SP deben vivir en `.claude/docs-qa/inputs/documents/`.
- No versionar secretos, credenciales, resultados temporales ni backups.
- `.gitignore` no excluye globalmente `results/` ni `inputs/documents/`; revisar los archivos generados antes de agregarlos a Git.
- Los scripts canónicos están en `.claude/docs-qa/inputs/scripts/`. La referencia del README a `.claude/scripts/` es antigua; esa ruta solo aparece como fallback en el motor. No crear allí otra copia de `sybase_tsql_wrapper.py`.

## Flujo QA vigente

- Leer el agente correspondiente en `.claude/agents/` antes de operar; la guía general es `.claude/docs-qa/1.INSTRUCCIONES-USO-AGENTES-QA.md`, pero conserva secciones del flujo anterior.
- El banco entrega los casos en `.claude/docs-qa/inputs/documents/<sp>/test-cases-banco/*.md`. El agente 01 valida y normaliza con `auto/validate_external_tc.py`; ya no genera los casos desde `tc_gen`. Conservar los casos y datos de negocio del banco.
- Orden: 01 normaliza → 02 valida y propone → 03 corrige → 04 completa CONFIG/DICCIONARIO con el micro desarrollado → 05 ejecuta `auto/run_qa.py`. El agente 00 y `sp_tc_gen/` generan artefactos separados.
- El documento operativo es `.claude/docs-qa/inputs/documents/<sp>/auto/qa_casos_prueba.md`; sus marcadores `—` y `Pendiente` son contratos del scaffolding con el agente 04.
- `run_qa.py` es la entrada de ejecución; admite `--tc TC01,TC02` para filtrar casos sin saltarse el orquestador. Las corridas reales requieren los insumos del SP, Sybase y los canales del micro; no equivalen a pruebas unitarias.
- `run_qa.py` y `auto/execute_all.py` abren conexiones independientes: al cambiar la resolución de conexión, revisar ambos. `expected_sybase_server` en CONFIG permite priorizar credenciales locales; el fallback usa `SYBASE_SERVER`, `SYBASE_USER`, `SYBASE_PASS`.

## Verificación enfocada

Comandos desde la raíz con Python 3 (`python3` debe resolver a un intérprete real; en Windows puede ser solo el alias de Microsoft Store):

```sh
# Regresiones del wrapper, sin conexión real a Sybase; usa su propio runner.
python3 .claude/docs-qa/inputs/scripts/tests/test_sybase_tsql_wrapper.py
# Regresión del filtro de casos, sin Sybase ni micro real.
python3 -m unittest discover -s .claude/docs-qa/inputs/scripts/auto/tests -p test_run_qa_tc_filter_ncbe1777.py -v
```

- Los tests mezclan `unittest` y funciones con runners propios; no asumir que `unittest discover` ejecuta todos los archivos `test_*.py`.
- El hook configurado en `.claude/settings.json` apunta a `.claude/docs-qa/inputs/scripts/hooks/block-dangerous.sh` y requiere Bash y `jq`; esa configuración pertenece a Claude Code, no configura hooks de OpenCode.
- Para respuestas y cierre de ejecuciones, consultar `.claude/skills/stop-yapping/SKILL.md` y `.claude/skills/log-history/SKILL.md`.

## Validación de calidad de libs y micros

- El flujo independiente de evidencias para N componentes está documentado en `.claude/docs-qa/QUALITY-VALIDATION.md`; usa `quality_validation/validate.py`, no `auto/run_qa.py`. Solo inspecciona checkouts y reportes existentes; no ejecuta builds ni scans de los componentes.

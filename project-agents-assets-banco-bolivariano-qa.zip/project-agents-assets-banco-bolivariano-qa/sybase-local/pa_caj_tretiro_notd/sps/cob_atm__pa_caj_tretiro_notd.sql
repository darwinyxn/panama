create procedure dbo.pa_caj_tretiro_notd 
(
	@e_oficina              int 		= 0,			-- Oficina del cajero o de la red (Banred, Medianet,Credimatic)
	@e_trn              	int, 						-- código de la transacción
	@e_cajero           	varchar(8) 	= null, 		-- 
Código Interno de la Terminal
	@e_atm_secuencial   	int, 						-- Secuencial de la terminal
	@e_fecha_trans      	datetime, 					-- fecha de la transacción
	@e_fecha_contable   	datetime, 					-- fecha contable
	@e_fecha_concilia   	datetime	= '01/01/1900
',	-- fecha de conciliación 
	@e_cod_tarjeta			int,      			        -- código interno de la tarjeta
	@e_tarjeta          	varchar(19)	= null,			-- numero de la tarjeta  
	@e_cuenta_debito    	varchar(24)	= '0000000000',	-- número de cuenta a debitar
	@e_c
uenta_credito   	varchar(24)	= '0000000000', -- número de cuenta acreditar
	@e_reentry          	char(1)		= 'N', 			-- Indicador de reentry 'S' o 'N'
	@e_reverso          	char(1)		= 'N',	 		-- Indicador de reverso 'S', 'N'
	@e_empresa          	smallint	
= 0, 			-- código de empresa
	@e_moneda           	varchar(4)	= '218', 		-- código ISO de la moneda
	@e_valor            	money		= 0, 			-- monto de la transacción
	@e_comision         	money		= 0, 			-- monto de la comisión 
	@e_autorizacion     	varchar
(6)	= null, 		-- código de autorización
	@e_pais             	varchar(3)	= 'EC', 		-- código del país
	@e_solicitud_recibo 	char(1)		= 'N', 			-- Indicador si el usuario solicito la impresión del recibo
	@e_origen               varchar(5)        ,        
 -- valor del origen de la transaccion (BOLIV,VISA,MDNTE,BANRE)
	@e_dispositivo          char(2)     = '02',
	@e_iso_field3			varchar(6)	= null, 		-- valor del campo ISO field3
	@e_iso_field32			varchar(14)	= null, 		-- valor del campo ISO field32 --> FIE
LD 32ACQUIRING INSTITUTION IDENTIFICATION CODE (FI)
	@e_iso_field42			varchar(15)	= null, 		-- valor del campo ISO field42
	@e_iso_field43			varchar(40)	= null, 		-- valor del campo ISO field43
	@e_retiro_con_saldo     char(1)     = 'N',          -- Indi
cador si el retiro es con impresion de Saldos
	@e_monto_fuente			money=0,					-- monto fuente de la transaccion
	@e_moneda_fuente	    varchar(3) =null,			-- codigo fuente de la transaccion
	@e_auth_reason 			char(1) = '',				-- Razon de autorizacion stand
in
	@e_codigo_cliente 		int = 0,				    -- Razon de autorizacion standin
	
    --definicion de los parametros de Salida
	@s_codigo_error     	int       	= 999999 	out,	-- código de error
	@s_mensaje          	char(255) 	= 'N' 		out,	-- mensaje
	@s_saldo_d
isponible 	money     	= 0 		out,	-- Saldo disponible en débito
	@s_saldo_contable   	money     	= 0 		out,	-- Saldo contable en débito
	@s_saldiscr         	money     	= 0 		out,	-- Saldo disponible en crédito
	@s_salconcr         	money     	= 0 		out,	-
- Saldo contable en crédito
	@s_autorizacion     	varchar(6)	= null 		out  	-- Numero de autorización
)
as
begin
	--==============================================================
	--print '-- declaracion  de variables  locales'
	--========================
======================================
	declare	@v_retorno			int,
			@v_ssn				int,
			@v_sec_host			int,
			@v_aba_banco		int,
			@v_contador_bb      int,
			@v_contador_red     int,
			@v_trn_cob 			int,
			@v_secuencial       int,
			@v_empresa			small
int,
			@v_rol 				smallint,
			@v_empresa_aut      smallint,
			@v_fi_banco         smallint,
			@v_moneda			tinyint,
			@v_dispositivo      tinyint,
			@v_fechap			datetime,
			@v_comision 		money,
			@v_tasa_conversion  money,
			@v_lvalor           mo
ney,
			@v_offline			char(1),
			@v_aplcobis         char(1),
			@v_ind_exon         char(1),
			@v_veri_tarjeta     char(1),
			@v_gen_autoriza     char(1),
			@v_signo_trn        char(1),
			@v_cobro 			char(1),
	        @v_indcob_isd_ret   char(1),   

            @v_indcob_isd_cmp   char(1),   
			@v_canal            char(3),
			@v_fecha_param      char(10),			
			@v_codcosto			varchar(2),
			@v_causal_cob 		varchar(3),
			@v_ced_ruc          varchar(13),			
			@v_srv              varchar(30),
        
    -- Variables at_ruteo_tran 
            @v_ttrn             smallint,
            @v_proddeb          descripcion,
            @v_prodcre          descripcion,
            @v_veri_cupo        char(1),
            @v_tipo_cupo        char(1),          
  
            @v_causa            varchar(3),
            @v_mensaje_atm      char(1),
            @v_ind_comision     char(1),
            @v_promocion        char(1),
            @v_notificaSMS      char(1),
            @v_retardo_SMS      char(1),
   
         @v_ind_isd          char(1),
			-- Variable genera costo
			@v_valor_isd         money,
			@v_porcentaje_isd    float,
			@v_fecha_ult_mov_cta datetime,
			@v_rpc               descripcion,
			@v_id_adquirente     int,
			@v_terminal          var
char(10),
			@v_referencia5       varchar(40),
		    @v_referencia4       varchar(40),
			@v_monto_tope_isd    money,		
			@v_referencia2		 varchar(40),
			@v_snn_monet         int,
			@v_cajero			 varchar(5)
			
	if @e_origen = 'BOLIV' 
	begin 
		set @e_
oficina = convert(int,right(rtrim(@e_iso_field42),4))

		if @e_oficina is null
		begin 
			select @v_cajero = right(rtrim(@e_cajero),5)
			
			select @e_oficina = at_oficina 
			from cob_atm..at_atm 
			where at_codigo = @v_cajero
		end
	end
			
	--======
========================================================
	--select '-- Inicializacion de variable locales'
	--==============================================================
	select	
		@v_ssn			   = 0,			
		@v_aba_banco	   = 37,
		@v_rol			   = 108,
		@v_s
rv             = 'LINEA1',			
		@v_sec_host		   = @e_atm_secuencial,
		@v_tasa_conversion = 0,
		@v_cobro           = 'N',
		@v_comision        = 0,
		@s_mensaje		   = '',
		@s_saldo_disponible = 0,
		@s_saldo_contable   = 0,
		@s_saldiscr         = 0,
		
@e_cuenta_credito   = isnull(@e_cuenta_credito,'0000000000'),
		@e_auth_reason	   = isnull(@e_auth_reason,''),
		@v_monto_tope_isd				= 0,
		@v_referencia2					= '',
		@v_id_adquirente                   =  null,
		@v_fecha_ult_mov_cta = @e_fecha_trans,
		
@v_valor_isd = 0
		
		if @e_iso_field32 is not null
		begin 	
			if @e_origen = 'BANRE'
			begin
				select @v_id_adquirente   =  convert(int,right(@e_iso_field32,4))
			end
			else
			begin
				select @v_id_adquirente   =  convert(int,@e_iso_field32)
			
end
		end
			
	if @e_trn not in (16238, 16828, 16284)
	begin
		select @v_retorno = 171516
	   
		select @s_codigo_error = @v_retorno
	
		insert into cob_atm..at_ruteo (
		rt_cajero, rt_trn, rt_sec_host,
		rt_atm_secuencial, rt_tarjeta, rt_fecha_trans,
		r
t_fecha_contable, rt_valor, rt_cuenta_debito,
		rt_cuenta_credito, rt_reverso, rt_banco,
		rt_offline, rt_origen, rt_oficina,
		rt_rol, rt_reentry, rt_codigo_error 
		)
		values(
			@e_cajero,          @e_trn,         @e_atm_secuencial,
			@e_atm_secuenci
al,  @e_tarjeta,     @e_fecha_trans,
			@e_fecha_contable,  @e_valor,       @e_cuenta_debito,
			@e_cuenta_credito,  @e_reverso,     @v_aba_banco,
			@v_offline,         @e_origen,      @e_oficina,
			@v_rol,             @e_reentry,     @s_codigo_error
		
)
		
		if @@error <> 0
		begin
			  select @v_retorno = 163028 --no se pudo insertar en la tabla de errores
		end
		
		return @v_retorno
	end
	
	select @v_referencia5 = replicate(' ',8) + '000' + isnull(@e_iso_field42,'')

	--=============================
=================================
	--print '-- obtengo parametros generales'
	--==============================================================
	exec @v_retorno = sp_at_ptl_parametros 
         @i_trn            = @e_trn,		 
		 @i_dispositivo    = @e_dispo
sitivo, 
		 @i_origen         = @e_origen, 
		 @i_reverso        = @e_reverso,
		 @i_cajero         = @e_cajero,
		 @i_iso_field32    = @e_iso_field32,
		 @i_tarjeta        = @e_tarjeta, 
		 @i_pais		   = @e_pais,
		 @i_iso_field3	   = @e_iso_field3, 
   
      @o_offline        = @v_offline           out,
         @o_fechap         = @v_fechap            out,
		 @o_fecha_param    = @v_fecha_param       out,
	     @o_indcob_isd_ret = @v_indcob_isd_ret    out,
		 @o_indcob_isd_cmp = @v_indcob_isd_cmp    out
,
		 @o_fi_banco       = @v_fi_banco          out,
		 @o_ssn            = @v_ssn               out,
		 -- Parametros de at_ruteo_tran
         @o_ttrn           = @v_ttrn              out,
         @o_proddeb        = @v_proddeb           out, 
         @
o_prodcre        = @v_prodcre           out,
         @o_veri_cupo      = @v_veri_cupo         out,
         @o_tipo_cupo      = @v_tipo_cupo         out,
         @o_empresa        = @v_empresa           out,
         @o_veri_tarjeta   = @v_veri_tarjeta 
     out,
         @o_causa          = @v_causa             out,
         @o_gen_autoriza   = @v_gen_autoriza      out,
         @o_empresa_aut    = @v_empresa_aut       out,
         @o_canal          = @v_canal             out,
         @o_mensaje_atm  
  = @v_mensaje_atm       out,
         @o_signo_trn      = @v_signo_trn         out,
         @o_ind_comision   = @v_ind_comision      out,
         @o_promocion      = @v_promocion         out,
         @o_notificaSMS    = @v_notificaSMS       out,
     
    @o_retardo_SMS    = @v_retardo_SMS       out,
         @o_ind_isd        = @v_ind_isd           out,
         @o_moneda         = @v_moneda            out,		 
		 @o_aplcobis       = @v_aplcobis          out,
		 @o_codcosto       = @v_codcosto         
 out,
         @o_dispositivo    = @v_dispositivo       out,
         @o_term           = @v_terminal          out,
         @o_porcentaje_isd = @v_porcentaje_isd 	  out,
         @o_aba_banco      = @v_aba_banco         out,
		 @o_monto_tope_isd = @v_mon
to_tope_isd    out
	
	if @@error <> 0
	begin
		select @s_codigo_error = @@error
		
		select @v_retorno = @s_codigo_error
		
		insert into cob_atm..at_ruteo (
		rt_cajero, rt_trn, rt_sec_host,
		rt_atm_secuencial, rt_tarjeta, rt_fecha_trans,
		rt_fecha_con
table, rt_valor, rt_cuenta_debito,
		rt_cuenta_credito, rt_reverso, rt_banco,
		rt_offline, rt_origen, rt_oficina,
		rt_rol, rt_reentry, rt_codigo_error 
		)
		values(
			@e_cajero,          @e_trn,         @e_atm_secuencial,
			@e_atm_secuencial,  @e_tar
jeta,     @e_fecha_trans,
			@e_fecha_contable,  @e_valor,       @e_cuenta_debito,
			@e_cuenta_credito,  @e_reverso,     @v_aba_banco,
			@v_offline,         @e_origen,      @e_oficina,
			@v_rol,             @e_reentry,     @s_codigo_error
		)
		
		if @
@error<>0  
		begin
			set @v_retorno = 163028
		end
				
		return @v_retorno
	end
	else if @v_retorno <> 0
	begin
		select @s_codigo_error = @v_retorno
	
		insert into cob_atm..at_ruteo (
		rt_cajero, rt_trn, rt_sec_host,
		rt_atm_secuencial, rt_tarjeta,
 rt_fecha_trans,
		rt_fecha_contable, rt_valor, rt_cuenta_debito,
		rt_cuenta_credito, rt_reverso, rt_banco,
		rt_offline, rt_origen, rt_oficina,
		rt_rol, rt_reentry, rt_codigo_error 
		)
		values(
			@e_cajero,          @e_trn,         @e_atm_secuencial
,
			@e_atm_secuencial,  @e_tarjeta,     @e_fecha_trans,
			@e_fecha_contable,  @e_valor,       @e_cuenta_debito,
			@e_cuenta_credito,  @e_reverso,     @v_aba_banco,
			@v_offline,         @e_origen,      @e_oficina,
			@v_rol,             @e_reentry,   
  @s_codigo_error
		)
		
		if @@error <> 0
		begin
			  select @v_retorno = 163028 --no se pudo insertar en la tabla de errores
		end
		
		return @v_retorno
	
	end

	--====================================================================================	
	
-- Este segmento de codigo fue colocado al inicio del programa para impedir desde   
    -- el inicio la ejecucion de la transaccion si es que los cajeros estan en offline. 	
	--=============================================================================
=======
    if @v_offline = 'P' or convert(char(10),@e_fecha_concilia,101) != @v_fecha_param
    begin
		select @v_retorno = 160030
		
		select @s_codigo_error = @v_retorno

		insert into cob_atm..at_ruteo (
		rt_cajero, rt_trn, rt_sec_host,
		rt_atm_secu
encial, rt_tarjeta, rt_fecha_trans,
		rt_fecha_contable, rt_valor, rt_cuenta_debito,
		rt_cuenta_credito, rt_reverso, rt_banco,
		rt_offline, rt_origen, rt_oficina,
		rt_rol, rt_reentry, rt_codigo_error 
		)
		values(
			@e_cajero,          @e_trn,       
  @e_atm_secuencial,
			@e_atm_secuencial,  @e_tarjeta,     @e_fecha_trans,
			@e_fecha_contable,  @e_valor,       @e_cuenta_debito,
			@e_cuenta_credito,  @e_reverso,     @v_aba_banco,
			@v_offline,         @e_origen,      @e_oficina,
			@v_rol,        
     @e_reentry,     @s_codigo_error
		)
		
		if @@error <> 0
		begin
			  select @v_retorno = 163028 --no se pudo insertar en la tabla de errores
		end
		
		return @v_retorno
	end

	--==============================================================
	--prin
t '-- Validar la logtran'
	--==============================================================
	if @e_trn not in (16260,16261)
	begin
		exec @v_retorno = sp_at_ptl_valida_logtran
			 @i_lo_trn			= @e_trn
			,@i_lo_banco		= @v_aba_banco
			,@i_lo_sec_host		= 
@e_atm_secuencial
			,@i_lo_codtarjeta	= @e_cod_tarjeta
			,@i_lo_reverso		= @e_reverso
			,@i_lo_valor		= @e_valor
			,@i_cajero			= @e_cajero
			,@i_atm_secuencial	= @e_atm_secuencial
			,@i_cuenta_debito	= @e_cuenta_debito
			,@i_reentry			= @e_reentry

			,@i_auth_reason     = @e_auth_reason
			,@i_autorizacion    = @e_autorizacion
			,@i_lo_fecha		= @e_fecha_trans
			,@o_log_valor       = @v_lvalor         out 
			,@o_log_comision    = @v_comision       out
			,@o_log_secuencial  = @v_secuencial     o
ut
			,@o_code_return		= @s_codigo_error   out
		
		if @@error <> 0
		begin
			select @s_codigo_error = @@error
			
			select @v_retorno = @s_codigo_error
			
			insert into cob_atm..at_ruteo (
			rt_cajero, rt_trn, rt_sec_host,
			rt_atm_secuencial, rt_t
arjeta, rt_fecha_trans,
			rt_fecha_contable, rt_valor, rt_cuenta_debito,
			rt_cuenta_credito, rt_reverso, rt_banco,
			rt_offline, rt_origen, rt_oficina,
			rt_rol, rt_reentry, rt_codigo_error 
			)
			values(
				@e_cajero,          @e_trn,         @e_
atm_secuencial,
				@e_atm_secuencial,  @e_tarjeta,     @e_fecha_trans,
				@e_fecha_contable,  @e_valor,       @e_cuenta_debito,
				@e_cuenta_credito,  @e_reverso,     @v_aba_banco,
				@v_offline,         @e_origen,      @e_oficina,
				@v_rol,        
     @e_reentry,     @s_codigo_error
			)
			
			if @@error<>0  
			begin
				set @v_retorno = 163028
			end
					
			return @v_retorno
		end
		else if @v_retorno <> 0
		begin
			select @s_codigo_error = @v_retorno

			insert into cob_atm..at_ruteo (
			r
t_cajero, rt_trn, rt_sec_host,
			rt_atm_secuencial, rt_tarjeta, rt_fecha_trans,
			rt_fecha_contable, rt_valor, rt_cuenta_debito,
			rt_cuenta_credito, rt_reverso, rt_banco,
			rt_offline, rt_origen, rt_oficina,
			rt_rol, rt_reentry, rt_codigo_error 
		
	)
			values(
				@e_cajero,          @e_trn,         @e_atm_secuencial,
				@e_atm_secuencial,  @e_tarjeta,     @e_fecha_trans,
				@e_fecha_contable,  @e_valor,       @e_cuenta_debito,
				@e_cuenta_credito,  @e_reverso,     @v_aba_banco,
				@v_offline
,         @e_origen,      @e_oficina,
				@v_rol,             @e_reentry,     @s_codigo_error
			)
			
			if @@error <> 0
			begin
				  select @v_retorno = 163028 --no se pudo insertar en la tabla de errores
			end
			
			return @v_retorno
		end
	end   

	
	--==============================================================
	--print '-- Setea variable Exonera costo'
	--==============================================================	
	if @e_comision > 0 and @v_ind_exon <> 'N'
	begin
        select @v_ind_exon 
= 'S'
	end
    else
	begin
		select @v_ind_exon = 'N'
	end

	--==============================================================
	--print '-- Genera costo'
	--==============================================================	
    if @v_ind_comision = 'S' and @e
_cuenta_credito != 'S'
    begin
        exec @v_retorno        = sp_at_genera_costo_trn
             @s_date          = @v_fechap
            ,@s_ofi           = @e_oficina
            ,@i_moneda        = @v_moneda
            ,@t_corr          = @e_reve
rso
            ,@t_rty           = @e_reentry
            ,@i_tarjeta       = @e_tarjeta
            ,@i_producto      = @v_proddeb
            ,@i_cta           = @e_cuenta_debito
            ,@i_trn           = @e_trn
            ,@i_fecha_ult_trn = @v
_fecha_ult_mov_cta
            ,@i_contador_bb   = 0
            ,@i_contador_red  = 0
            ,@i_cod_canal     = @v_canal
            ,@i_costo         = @v_comision
            ,@i_causa         = @v_causa
            ,@i_codcost       = @v_codcost
o
            ,@o_retorno       = @v_ind_exon     out
            ,@o_contador_bb   = @v_contador_bb  out
            ,@o_contador_red  = @v_contador_red out
            ,@o_costo         = @v_comision     out
            ,@o_trn_cob       = @v_trn_cob   
   out
            ,@o_causal_cob    = @v_causal_cob   out

		if @@error <> 0
		begin
			select @s_codigo_error = @@error
			
			select @v_retorno = @s_codigo_error
			
			insert into cob_atm..at_ruteo (
			rt_cajero, rt_trn, rt_sec_host,
			rt_atm_secuen
cial, rt_tarjeta, rt_fecha_trans,
			rt_fecha_contable, rt_valor, rt_cuenta_debito,
			rt_cuenta_credito, rt_reverso, rt_banco,
			rt_offline, rt_origen, rt_oficina,
			rt_rol, rt_reentry, rt_codigo_error 
			)
			values(
				@e_cajero,          @e_trn,  
       @e_atm_secuencial,
				@e_atm_secuencial,  @e_tarjeta,     @e_fecha_trans,
				@e_fecha_contable,  @e_valor,       @e_cuenta_debito,
				@e_cuenta_credito,  @e_reverso,     @v_aba_banco,
				@v_offline,         @e_origen,      @e_oficina,
				@v_ro
l,             @e_reentry,     @s_codigo_error
			)
			
			if @@error<>0  
			begin
				set @v_retorno = 163028
			end
					
			return @v_retorno
		end
		else if @v_retorno != 0
		begin
			select @s_codigo_error = @v_retorno

			insert into cob_atm..at_ru
teo (
			rt_cajero, rt_trn, rt_sec_host,
			rt_atm_secuencial, rt_tarjeta, rt_fecha_trans,
			rt_fecha_contable, rt_valor, rt_cuenta_debito,
			rt_cuenta_credito, rt_reverso, rt_banco,
			rt_offline, rt_origen, rt_oficina,
			rt_rol, rt_reentry, rt_codigo
_error 
			)
			values(
				@e_cajero,          @e_trn,         @e_atm_secuencial,
				@e_atm_secuencial,  @e_tarjeta,     @e_fecha_trans,
				@e_fecha_contable,  @e_valor,       @e_cuenta_debito,
				@e_cuenta_credito,  @e_reverso,     @v_aba_banco,
				
@v_offline,         @e_origen,      @e_oficina,
				@v_rol,             @e_reentry,     @s_codigo_error
			)
			
			if @@error <> 0
			begin
				  select @v_retorno = 163028 --no se pudo insertar en la tabla de errores
			end
			
			return @v_retorno
		en
d
    end
	 
	set @v_comision = isnull(@v_comision,0)
	
	--==============================================================
	--print '-- Transaccion Cobis'
	--==============================================================						 	
    select @v_rpc = case @v
_proddeb 
						when 'AHO' then 'sp_at_retiro_ah'
                        when 'CTE' then 'sp_at_retiro_cc'	
                        when 'PAG' then 'sp_at_retiro_rp'	                     
					end		        
		
	begin tran RETIRO	

	exec @v_retorno = @v_r
pc
		 @s_ssn          = @v_ssn
	    ,@s_lsrv         = ' '
	    ,@s_srv          = @v_srv
	    ,@s_user         = @e_cajero
	    ,@s_sesn         = 0
	    ,@s_term         = @v_terminal
	    ,@s_date         = @v_fechap
	    ,@s_ofi          = @e_oficina

	    ,@s_rol          = @v_rol
		,@s_org          = 'L'
	    ,@t_corr         = @e_reverso
	    ,@t_ssn_corr     = @e_atm_secuencial
        ,@e_sec_corr     = @v_secuencial
	    ,@t_debug        = 'N'
	    ,@t_rty          = @e_reentry	
	    ,@t_trn     
     = @e_trn
		,@t_ttrn         = 0
	    ,@i_sec_host     = @v_sec_host
	    ,@i_tarjeta      = @e_tarjeta
	    ,@i_banco        = @v_fi_banco	
	    ,@i_trn          = @v_ttrn
	    ,@i_causa        = @v_causa
	    ,@i_cta          = @e_cuenta_debito
    
    ,@i_val          = @e_valor
        ,@i_mon          = @v_moneda	
        ,@i_cta_dep      = @e_cuenta_credito
        ,@i_aplcobis     = @v_aplcobis
        ,@i_comision     = @v_comision	
        ,@i_trn_cob      = @v_trn_cob
        ,@i_causal_cob 
  = @v_causal_cob
        ,@i_valor_isd    = @v_valor_isd  
        ,@i_pais         = @e_pais       
        ,@i_localidad    = @v_aba_banco
        ,@i_ced_ruc      = @v_ced_ruc	--revisar
		-- INI Retiro Virtuales
		,@i_sec_tarjeta	 = @e_cod_tarjeta
		,
@i_canal        = @v_canal
		,@i_cajero       = @e_cajero
		-- FIN Retiro Virtuales
	    ,@o_codigo_error = @s_codigo_error        out
        ,@o_salcondb     = @s_saldo_contable      out
        ,@o_saldisdb     = @s_saldo_disponible    out
        ,@o_
saldiscr     = @s_saldiscr            out
		,@o_salconcr     = @s_salconcr            out
		,@s_ssnmonet     = @v_snn_monet           out 
	
	if @@error <> 0
	begin
		rollback tran
		
		select @s_codigo_error = @@error
		
		select @v_retorno = @s_codigo_e
rror
		
		insert into cob_atm..at_ruteo (
		rt_cajero, rt_trn, rt_sec_host,
		rt_atm_secuencial, rt_tarjeta, rt_fecha_trans,
		rt_fecha_contable, rt_valor, rt_cuenta_debito,
		rt_cuenta_credito, rt_reverso, rt_banco,
		rt_offline, rt_origen, rt_oficina,
	
	rt_rol, rt_reentry, rt_codigo_error 
		)
		values(
			@e_cajero,          @e_trn,         @e_atm_secuencial,
			@e_atm_secuencial,  @e_tarjeta,     @e_fecha_trans,
			@e_fecha_contable,  @e_valor,       @e_cuenta_debito,
			@e_cuenta_credito,  @e_reverso
,     @v_aba_banco,
			@v_offline,         @e_origen,      @e_oficina,
			@v_rol,             @e_reentry,     @s_codigo_error
		)
		
		if @@error<>0  
		begin
			set @v_retorno = 163028
		end
				
		return @v_retorno
	end
	else if (@s_codigo_error <> 0 or
 @v_retorno <> 0)
	begin		
		if @s_codigo_error < 1
		begin
			select @s_codigo_error = @v_retorno
		end

		rollback tran

		insert into cob_atm..at_ruteo (
		rt_cajero, rt_trn, rt_sec_host,
		rt_atm_secuencial, rt_tarjeta, rt_fecha_trans,
		rt_fecha_cont
able, rt_valor, rt_cuenta_debito,
		rt_cuenta_credito, rt_reverso, rt_banco,
		rt_offline, rt_origen, rt_oficina,
		rt_rol, rt_reentry, rt_codigo_error 
		)
		values(
			@e_cajero,          @e_trn,         @e_atm_secuencial,
			@e_atm_secuencial,  @e_tarj
eta,     @e_fecha_trans,
			@e_fecha_contable,  @e_valor,       @e_cuenta_debito,
			@e_cuenta_credito,  @e_reverso,     @v_aba_banco,
			@v_offline,         @e_origen,      @e_oficina,
			@v_rol,             @e_reentry,     @s_codigo_error
		)
		
		if @@
error <> 0
		begin
			  select @v_retorno = 163028 --no se pudo insertar en la tabla de errores
		end
		
		return @v_retorno
	end
		
	--==============================================================
	--print '-- GRABO EN TABLA DE LOGGER at_logtran'
	--===
===========================================================			

	if @v_ind_exon != 'N'
	begin
		select @v_cobro = isnull(@v_ind_exon,'N')
	end

	 exec @v_retorno = sp_at_ptl_logueotran
		@i_lo_reverso         = @e_reverso
	   ,@i_lo_atm             = @e_c
ajero	           
	   ,@i_lo_trn             = @e_trn
	   ,@i_lo_ttrn            = @v_ttrn
	   ,@i_lo_sec_host        = @v_sec_host
	   ,@i_lo_atm_secuencial  = @e_atm_secuencial
	   ,@i_lo_vsecuencial     = @v_snn_monet
	   ,@i_lo_tarjeta         = @e_ta
rjeta
	   ,@i_lo_fecha           = @e_fecha_trans
	   ,@i_lo_valor           = @e_valor
	   ,@i_lo_cuenta1         = @e_cuenta_debito
	   ,@i_lo_cuenta2         = @e_cuenta_credito	           
	   ,@i_lo_banco           = @v_aba_banco
	   ,@i_lo_offline  
       = @v_offline
	   ,@i_lo_uso_cajero      = @v_cobro 
	   ,@i_lo_oficina         = @e_oficina
	   ,@i_lo_tasa_conver     = @v_tasa_conversion
	   ,@i_lo_moneda          = @v_moneda
	   ,@i_lo_valor_reverso   = 0
	   ,@i_lo_fecha_concilia  = @e_fecha_
contable
	   ,@i_lo_dispositivo     = @v_dispositivo
	   ,@i_lo_reentry         = @e_reentry
	   ,@i_lo_empresa         = @e_empresa 
	   ,@i_lo_referencia      = @e_retiro_con_saldo
	   ,@i_lo_referencia2	  = @v_referencia2	
	   ,@i_lo_referencia4     = 
@v_referencia4  	   
	   ,@i_lo_referencia3     = @e_iso_field43  
	   ,@i_lo_referencia5     = @v_referencia5	
	   ,@i_lo_pais            = @e_pais
	   ,@i_lo_comision        = @v_comision     
	   ,@i_lo_codtarjeta      = @e_cod_tarjeta
	   ,@i_lo_codcl
iente      = @e_codigo_cliente
	   ,@i_lo_valor_isd       = @v_valor_isd 
	   ,@i_lo_autorizacion    = @s_autorizacion
	   ,@i_lo_solicitud_recibo= @e_solicitud_recibo
	   ,@i_monto_fuente		  =	@e_monto_fuente  
	   ,@i_moneda_fuente	  =	@e_moneda_fuente 

	   ,@i_id_adquirente      = @v_id_adquirente
	   ,@o_code_return        = @s_codigo_error out

	if @@error <> 0
	begin
		rollback transaction
		
		select @s_codigo_error = @@error
		
		select @v_retorno = @s_codigo_error
		
		insert into cob_atm..at_rut
eo (
		rt_cajero, rt_trn, rt_sec_host,
		rt_atm_secuencial, rt_tarjeta, rt_fecha_trans,
		rt_fecha_contable, rt_valor, rt_cuenta_debito,
		rt_cuenta_credito, rt_reverso, rt_banco,
		rt_offline, rt_origen, rt_oficina,
		rt_rol, rt_reentry, rt_codigo_error 

		)
		values(
			@e_cajero,          @e_trn,         @e_atm_secuencial,
			@e_atm_secuencial,  @e_tarjeta,     @e_fecha_trans,
			@e_fecha_contable,  @e_valor,       @e_cuenta_debito,
			@e_cuenta_credito,  @e_reverso,     @v_aba_banco,
			@v_offline,   
      @e_origen,      @e_oficina,
			@v_rol,             @e_reentry,     @s_codigo_error
		)
		
		if @@error<>0  
		begin
			set @v_retorno = 163028
		end
				
		return @v_retorno
	end
	else if @s_codigo_error <> 0
	begin
		rollback transaction
		select @
s_codigo_error = @v_retorno

		insert into cob_atm..at_ruteo (
		rt_cajero, rt_trn, rt_sec_host,
		rt_atm_secuencial, rt_tarjeta, rt_fecha_trans,
		rt_fecha_contable, rt_valor, rt_cuenta_debito,
		rt_cuenta_credito, rt_reverso, rt_banco,
		rt_offline, rt_
origen, rt_oficina,
		rt_rol, rt_reentry, rt_codigo_error 
		)
		values(
			@e_cajero,          @e_trn,         @e_atm_secuencial,
			@e_atm_secuencial,  @e_tarjeta,     @e_fecha_trans,
			@e_fecha_contable,  @e_valor,       @e_cuenta_debito,
			@e_cuenta
_credito,  @e_reverso,     @v_aba_banco,
			@v_offline,         @e_origen,      @e_oficina,
			@v_rol,             @e_reentry,     @s_codigo_error
		)
		
		if @@error <> 0
		begin
			select @v_retorno = 163028 --no se pudo insertar en la tabla de errores

		end
		
		return @v_retorno
	end


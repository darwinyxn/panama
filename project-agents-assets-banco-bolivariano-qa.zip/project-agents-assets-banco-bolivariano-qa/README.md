# QA Agents Setup

Repositorio independiente para ejecutar los agentes de QA de equivalencia de Stored Procedures y microservicios.

El producto operativo está en `.claude/` (raíz del repositorio). Esta copia se construyó desde la versión más actual del setup anterior, conservando los agentes QA, QMetry, documentación lógica, UML y sus scripts, pero excluyendo resultados históricos, backups, visualizaciones y artefactos generados.

## Modelo recomendado

Para QA se recomienda configurar Claude Code con el perfil de Amazon Bedrock:

```text
us.anthropic.claude-sonnet-5
```

## Estructura

- `.claude/agents/`: agentes QA y soporte QA.
- `.claude/docs-qa/inputs/scripts/`: scripts deterministas de generación, ejecución y QMetry.
- `.claude/docs-qa/inputs/documents/`: insumos por SP; se mantiene vacío en el repositorio base.
- `.claude/docs-qa/results/`: resultados de las corridas; se mantiene vacío en el repositorio base.
- `.claude/scripts/`: hooks, documentación lógica y utilitarios de soporte.

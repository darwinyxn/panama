# Casos de Prueba - sp_direccion_dml (Análisis Funcional)

## Resumen de plan de generacion

- **SP**: `sp_direccion_dml`
- **Tipo de análisis**: `funcional`
- **Técnicas aplicadas**: Partición de Equivalencia (PEQ), Tablas de Decisión (TD), Error Guessing (EG)
- **Objetivo de casos**: 39 (50% de 98 casos_finales_estimados, ajustado -10 por complejidad ALTA)
- **Rango solicitado**: TC-001 a TC-025
- **Lote actual**: 1 de 2 (25 casos)
- **Estrategia**: Cubrir las 4 operaciones (I/U/D/E) con particiones válidas e inválidas representativas, reglas de decisión clave por operación, y errores funcionales probables. Priorizar reglas de negocio de alta criticidad (RN-02 a RN-51).

## Parametros base de ejecucion

Valores base usados como referencia para todos los casos. Cada TC declara solo los `parametros_bajo_prueba` que cambian respecto a esta base.

| Parametro | Valor base | Fuente |
|-----------|-----------|--------|
| @s_ssn | 1 | supuesto_controlado |
| @s_user | 'TESTUSER' | supuesto_controlado |
| @s_term | 'TERM001' | supuesto_controlado |
| @s_date | '2026-11-12 10:00:00' | supuesto_controlado |
| @s_srv | 'SRV001' | supuesto_controlado |
| @s_lsrv | 'LSRV001' | supuesto_controlado |
| @s_ofi | 1 | supuesto_controlado |
| @s_rol | 1 | supuesto_controlado |
| @s_org_err | 'N' | supuesto_controlado |
| @s_error | 0 | supuesto_controlado |
| @s_sev | 0 | supuesto_controlado |
| @s_msg | null | supuesto_controlado |
| @s_org | 'N' | supuesto_controlado |
| @t_debug | 'N' | default |
| @t_file | null | default |
| @t_from | null | default |
| @t_trn | 109 | supuesto_controlado (INSERT) |
| @i_operacion | 'I' | supuesto_controlado |
| @i_no_cobis | 'N' | default |
| @i_mensaje | 'S' | default |
| @i_producto | 2 | supuesto_controlado |
| @i_ente | 1 | supuesto_controlado (debe existir en cl_ente) |
| @i_direccion | null | default |
| @i_descripcion | 'Calle Principal 123' | supuesto_controlado |
| @i_tipo | 'D' | supuesto_controlado |
| @i_sector | '0' | default |
| @i_parroquia | 1 | supuesto_controlado |
| @i_ciudad | 1 | supuesto_controlado |
| @i_oficina | 1 | supuesto_controlado |
| @i_zona | null | default |
| @i_envio_crp | 'N' | default |
| @i_parroquia_ciu | 0 | default |
| @i_observacion | null | default |
| @i_pto_referencia | null | default |
| @i_verificado | 'N' | default |
| @i_fecha_ver | null | default |
| @i_usuario_ver | null | default |
| @i_vigencia | 'N' | default |
| @i_fecha_caducidad | null | default |
| @i_nombre_verif | null | default |
| @i_cargo_verif | null | default |
| @i_ind_act_presenc | 'N' | default |
| @i_ind_val_maxdir | 'S' | default |
| @i_tipo_verif_incns | null | default |
| @i_bancarizacion | 'N' | default |
| @i_verifdirec | 'N' | default |
| @i_tipo_servicio | null | default |
| @i_cod_empresa | null | default |
| @i_direc_planilla | null | default |
| @i_cod_rela_prop | null | default |
| @i_nom_propietario | null | default |
| @i_vreferen | 'N' | default |
| @i_solicitud | null | default |
| @i_anio | null | default |
| @i_canton | null | default |
| @i_valida | 'S' | default |
| @i_val_dir | 'N' | default |
| @i_val_domicilio | 'S' | default |
| @i_canal | null | default |
| @i_envio_notifica | 'S' | default |
| @e_actmasivacli | 'N' | default |

## Plantilla de ejecucion del SP

```sql
EXEC cobis.dbo.sp_direccion_dml
  @s_ssn              = 1,
  @s_user             = 'TESTUSER',
  @s_term             = 'TERM001',
  @s_date             = '2026-11-12 10:00:00',
  @s_srv              = 'SRV001',
  @s_lsrv             = 'LSRV001',
  @s_ofi              = 1,
  @s_rol              = 1,
  @s_org_err          = 'N',
  @s_error            = 0,
  @s_sev              = 0,
  @s_msg              = null,
  @s_org              = 'N',
  @t_debug            = 'N',
  @t_file             = null,
  @t_from             = null,
  @t_trn              = 109,
  @i_operacion        = 'I',
  @i_no_cobis         = 'N',
  @i_mensaje          = 'S',
  @i_producto         = 2,
  @i_ente             = 1,
  @i_direccion        = null,
  @i_descripcion      = 'Calle Principal 123',
  @i_tipo             = 'D',
  @i_sector           = '0',
  @i_parroquia        = 1,
  @i_ciudad           = 1,
  @i_oficina          = 1,
  @i_zona             = null,
  @i_envio_crp        = 'N',
  @i_parroquia_ciu    = 0,
  @i_observacion      = null,
  @i_pto_referencia   = null,
  @i_verificado       = 'N',
  @i_fecha_ver        = null,
  @i_usuario_ver      = null,
  @i_vigencia         = 'N',
  @i_fecha_caducidad  = null,
  @i_nombre_verif     = null,
  @i_cargo_verif      = null,
  @i_ind_act_presenc  = 'N',
  @i_ind_val_maxdir   = 'S',
  @i_tipo_verif_incns = null,
  @i_bancarizacion    = 'N',
  @i_verifdirec       = 'N',
  @i_tipo_servicio    = null,
  @i_cod_empresa      = null,
  @i_direc_planilla   = null,
  @i_cod_rela_prop    = null,
  @i_nom_propietario  = null,
  @i_vreferen         = 'N',
  @i_solicitud        = null,
  @i_anio             = null,
  @i_canton           = null,
  @i_valida           = 'S',
  @i_val_dir          = 'N',
  @i_val_domicilio    = 'S',
  @i_canal            = null,
  @i_envio_notifica   = 'S',
  @e_actmasivacli     = 'N',
  @o_direccion        = null,
  @o_msj_error        = null,
  @o_sig_log_svr      = null
```

## Validacion de contrato del SP

- **estado_validacion_contrato**: `VALIDADO_CON_CONDICIONES`
- **parametros_verificados**: total=64; entradas=61; salidas=3
- **Tablas/columnas verificadas**: 23 tablas verificadas contra cuerpo activo del SP (líneas L383-L2688). Las tablas `cob_ahorros..ah_cuenta`, `cob_cuentas..cc_ctacte`, `cobis_his..cl_direccion_his`, `cobis_his..cl_telefono_his` son externas a `cobis` pero referenciadas explícitamente en el SP.
- **Hallazgos preflight**:
  - `CONDICIONAL_LOCAL`: El parámetro `@i_valida` (default 'S') está declarado en la firma pero no se usa en el cuerpo activo del SP. No afecta la generación de casos.
  - `CONDICIONAL_LOCAL`: Las notificaciones (`sp_notif_cli_mod_dir`) dependen de la configuración del ambiente (email, celular del cliente). Los casos que involucran notificación asumen que el SP hijo existe y retorna 0; el resultado real depende del ambiente.
  - `CONDICIONAL_LOCAL`: La validación de cantones/parroquias (Ecuador, ci_pais=1) depende de datos geográficos en catálogos. Los casos asumen ciudad con país != 1 para evitar esta ruta condicional en el lote base.
  - `CONDICIONAL_LOCAL`: El cursor sobre `cob_ahorros..ah_cuenta` y `cob_cuentas..cc_ctacte` depende de datos reales de cuentas. Los casos con `@i_envio_crp='S'` requieren que existan cuentas asociadas al ente.
- **graph_context_status**: `NO_INFORMADO`

## Registro IDs de cobertura

| id | significado | estado | casos_asociados | evidencia_pendiente |
|----|-------------|--------|-----------------|---------------------|
| AFUN-PEQ-001 | @i_operacion='I' - Particion valida INSERT | CUBIERTO | TC-001, TC-002, TC-003, TC-004, TC-005 | - |
| AFUN-PEQ-002 | @i_operacion='U' - Particion valida UPDATE | CUBIERTO | TC-006, TC-007, TC-008, TC-009, TC-010, TC-011 | - |
| AFUN-PEQ-003 | @i_operacion='D' - Particion valida DELETE | CUBIERTO | TC-012, TC-013, TC-014, TC-015 | - |
| AFUN-PEQ-004 | @i_operacion='E' - Particion valida DELETE con temporales | CUBIERTO | TC-016, TC-017 | - |
| AFUN-PEQ-005 | @i_operacion='X' - Particion invalida (operacion no soportada) | CUBIERTO | TC-018 | - |
| AFUN-PEQ-006 | @i_ente=0 - Particion invalida (ente cero) | CUBIERTO | TC-019 | - |
| AFUN-PEQ-007 | @i_ente inexistente - Particion invalida | CUBIERTO | TC-020 | - |
| AFUN-PEQ-008 | @i_tipo='X' - Particion invalida (tipo no D/T/O) | CUBIERTO | TC-021 | - |
| AFUN-PEQ-009 | @i_envio_crp='X' - Particion invalida (no N/S) | CUBIERTO | TC-022 | - |
| AFUN-PEQ-010 | @i_verificado='S' - Particion valida (verificado Si) | CUBIERTO | TC-003 | - |
| AFUN-PEQ-011 | @i_verificado='N' - Particion valida (verificado No) | CUBIERTO | TC-001 | - |
| AFUN-PEQ-012 | @i_tipo='D' - Particion valida (Domicilio) | CUBIERTO | TC-001, TC-006 | - |
| AFUN-PEQ-013 | @i_tipo='T' - Particion valida (Trabajo) | CUBIERTO | TC-002 | - |
| AFUN-PEQ-014 | @i_tipo='O' - Particion valida (Otro) | CUBIERTO | TC-004 | - |
| AFUN-PEQ-015 | @i_envio_crp='S' - Particion valida (envio correspondencia Si) | CUBIERTO | TC-005 | - |
| AFUN-PEQ-016 | @i_envio_notifica='N' - Particion valida (sin notificacion) | CUBIERTO | TC-024 | - |
| AFUN-PEQ-017 | @i_ind_val_maxdir='N' - Particion valida (sin validacion max dir) | CUBIERTO | TC-025 | - |
| AFUN-TD-001 | RN-02: Ente no puede ser cero | CUBIERTO | TC-019 | - |
| AFUN-TD-002 | RN-03: El ente debe existir en cl_ente | CUBIERTO | TC-020 | - |
| AFUN-TD-003 | RN-06: El producto debe existir en cl_producto | CUBIERTO | TC-023 | - |
| AFUN-TD-004 | RN-11: Tipo direccion solo D, T, O | CUBIERTO | TC-021 | - |
| AFUN-TD-005 | RN-13: Envio CRP solo N o S | CUBIERTO | TC-022 | - |
| AFUN-TD-006 | RN-15: Maximo 3 direcciones por ente (PN) | CUBIERTO | TC-038, TC-039 | - |
| AFUN-TD-007 | RN-19: PN debe tener al menos 1 direccion D | PENDIENTE | - | Requiere ente PN sin direcciones tipo D |
| AFUN-TD-008 | RN-21: PJ no debe tener direcciones D | PENDIENTE | - | Requiere ente PJ |
| AFUN-TD-009 | RN-22: Vigencia cuando verificado en S,I,P | CUBIERTO | TC-003 | - |
| AFUN-TD-010 | RN-25: Desmarcar direccion envio CRP anterior | CUBIERTO | TC-005 | - |
| AFUN-TD-011 | RN-33: No desmarcar direccion envio CRP (UPDATE) | CUBIERTO | TC-030 | - |
| AFUN-TD-012 | RN-34: Validacion actualizacion presencial | CUBIERTO | TC-031 | - |
| AFUN-TD-013 | RN-39: No eliminar todas las direcciones | CUBIERTO | TC-032 | - |
| AFUN-TD-014 | RN-40: No eliminar direccion envio CRP | CUBIERTO | TC-033 | - |
| AFUN-TD-015 | RN-41: No eliminar direccion asociada a cta cte | PENDIENTE | - | Requiere direccion asociada a cuenta corriente |
| AFUN-TD-016 | RN-42: No eliminar direccion asociada a ECTC | PENDIENTE | - | Requiere direccion asociada a tarjeta de credito |
| AFUN-TD-017 | RN-43: No eliminar direccion D con movil asociado | PENDIENTE | - | Requiere direccion D con numero movil asociado |
| AFUN-TD-018 | RN-50: Control @e_actmasivacli para eliminacion | JUSTIFICADO | TC-013 | Cubierto en lote 1 con @e_actmasivacli='S' |
| AFUN-TD-019 | RN-05: Solo PN reciben notificaciones y validaciones | CUBIERTO | TC-001, TC-006 | - |
| AFUN-TD-020 | RN-24: Determinacion canal notificacion | CUBIERTO | TC-034 | - |
| AFUN-TD-021 | RN-28: Log vreferen si hay observacion | PENDIENTE | - | Requiere @i_vreferen='S' con observacion |
| AFUN-TD-022 | RN-29: Log ECTC si tipo diferente | PENDIENTE | - | Requiere configuracion ECTC |
| AFUN-TD-023 | RN-30: Actualizar direccion envio en ctas ahorro | PENDIENTE | - | Requiere @i_envio_crp='S' y cuentas de ahorro |
| AFUN-TD-024 | RN-31: Notificacion cambio direccion (INSERT) | CUBIERTO | TC-034 | - |
| AFUN-TD-025 | RN-32: Verificacion direccion asociada EC (UPDATE) | CUBIERTO | TC-035 | - |
| AFUN-TD-026 | RN-35: Actualizar tipo direccion en ECTC | PENDIENTE | - | Requiere direccion en cl_dir_envio_tarj_cred |
| AFUN-TD-027 | RN-36: Actualizar direccion envio ctas ahorro/cte (UPDATE) | PENDIENTE | - | Requiere @i_envio_crp='S' y cuentas |
| AFUN-TD-028 | RN-37: Retorno cuentas para notificaciones | PENDIENTE | - | Requiere canal en mis_p_canalesnot |
| AFUN-TD-029 | RN-38: Notificacion cambio direccion (UPDATE) | CUBIERTO | TC-036 | - |
| AFUN-TD-030 | RN-47: Eliminacion con validaciones a temporales (E) | CUBIERTO | TC-016, TC-017 | - |
| AFUN-TD-031 | RN-48: Validacion eliminacion contra temporales | PENDIENTE | - | Requiere datos en cl_direccion_tmp y cl_dir_est_cta_tmp |
| AFUN-TD-032 | RN-51: Notificacion eliminacion direccion (DELETE) | CUBIERTO | TC-037 | - |
| AFUN-EG-001 | @i_operacion='X' - Operacion no soportada | CUBIERTO | TC-018 | - |
| AFUN-EG-002 | @t_trn no coincide con @i_operacion (INSERT con t_trn=110) | CUBIERTO | TC-018 | - |
| AFUN-EG-003 | Producto inexistente en INSERT | CUBIERTO | TC-023 | - |
| AFUN-EG-004 | @i_operacion='U' con @t_trn=109 (trn no corresponde) | CUBIERTO | TC-026 | - |
| AFUN-EG-005 | @i_operacion='D' con @t_trn=110 (trn no corresponde) | CUBIERTO | TC-027 | - |
| AFUN-EG-006 | Direccion inexistente en UPDATE | CUBIERTO | TC-028 | - |
| AFUN-EG-007 | Direccion inexistente en DELETE | CUBIERTO | TC-029 | - |
| AFUN-EG-008 | UPDATE sin cambios (todos los campos iguales) | CUBIERTO | TC-011 | - |

---

## TC-001: INSERT exitoso - Direccion tipo Domicilio basica

Objetivo: RN-05, RN-11 - Insercion valida de direccion tipo Domicilio para persona natural con parametros minimos requeridos. Cubre AFUN-PEQ-001, AFUN-PEQ-011, AFUN-PEQ-012, AFUN-TD-019.

Precondiciones:
- El ente @i_ente debe existir en cobis..cl_ente con en_subtipo='P'
- El producto @i_producto=2 debe existir en cobis..cl_producto
- La ciudad @i_ciudad=1 debe existir en cobis..cl_ciudad
- La parroquia @i_parroquia=1 debe existir en cobis..cl_parroquia para la ciudad
- La oficina @i_oficina=1 debe existir en cobis..cl_oficina
- El tipo 'D' debe existir en catalogo cl_tdireccion
- El estado 'N' debe existir en catalogo cl_estado_ver_ref
- El ente no debe tener mas de 2 direcciones existentes
- Consulta de verificacion de precondiciones:
```sql
SELECT en_ente, en_subtipo, en_nombre, en_fecha_crea
FROM cobis..cl_ente
WHERE en_ente = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para INSERT
   - `@i_ente=1`
      - fuente_valor=sybase_select
      - fuente_detalle=SELECT TOP 1 en_ente FROM cobis..cl_ente WHERE en_subtipo='P' ORDER BY en_ente
   - `@i_tipo='D'`
      - fuente_valor=analisis
      - fuente_detalle=Tipo Domicilio valido
   - `@i_descripcion='Calle Principal 123'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba
   - `@i_ciudad=1`
      - fuente_valor=sybase_select
      - fuente_detalle=SELECT TOP 1 ci_ciudad FROM cobis..cl_ciudad ORDER BY ci_ciudad
   - `@i_parroquia=1`
      - fuente_valor=sybase_select
      - fuente_detalle=SELECT TOP 1 pq_parroquia FROM cobis..cl_parroquia WHERE pq_ciudad=1 ORDER BY pq_parroquia
   - `@i_oficina=1`
      - fuente_valor=sybase_select
      - fuente_detalle=SELECT TOP 1 of_oficina FROM cobis..cl_oficina ORDER BY of_oficina
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=SELECT TOP 1 pd_producto FROM cobis..cl_producto ORDER BY pd_producto

Resultado esperado funcional:
- Retorno 0 (exito)
- @o_direccion retorna el secuencial asignado a la nueva direccion

Resultado esperado en BD:
- Se inserta un registro en cobis..cl_direccion con di_ente=@i_ente, di_tipo='D', di_descripcion='Calle Principal 123'
- Se inserta un registro en cobis..ts_direccion con clase='N' (nuevo)
- No se inserta en cl_log_dir_envio_ec (tipo D sin ECTC)
- No se ejecuta cursor de cuentas (@i_envio_crp='N')

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_tipo, di_verificado, di_envio_crp, di_fecha_registro
FROM cobis..cl_direccion
WHERE di_ente = 1
ORDER BY di_direccion DESC
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-002: INSERT exitoso - Direccion tipo Trabajo

Objetivo: RN-11 - Insercion valida de direccion tipo Trabajo. Cubre AFUN-PEQ-001, AFUN-PEQ-013.

Precondiciones:
- Mismas precondiciones que TC-001
- El ente no debe tener mas de 1 direccion tipo T existente (maximo 2 para T/O)
- Consulta de verificacion:
```sql
SELECT COUNT(1) as cnt_t
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_tipo = 'T'
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para INSERT
   - `@i_tipo='T'`
      - fuente_valor=analisis
      - fuente_detalle=Tipo Trabajo valido
   - `@i_descripcion='Av. Comercial 456 Oficina 3'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba para direccion laboral

Resultado esperado funcional:
- Retorno 0 (exito)
- @o_direccion retorna el secuencial asignado

Resultado esperado en BD:
- Se inserta un registro en cobis..cl_direccion con di_tipo='T'
- Se inserta un registro en cobis..ts_direccion con clase='N'

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_tipo, di_fecha_registro
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_tipo = 'T'
ORDER BY di_direccion DESC
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-003: INSERT exitoso - Direccion con verificacion activa (vigencia)

Objetivo: RN-22 - Insercion con @i_verificado='S' activa calculo de vigencia. Cubre AFUN-PEQ-001, AFUN-PEQ-010, AFUN-TD-009.

Precondiciones:
- Mismas precondiciones que TC-001
- El parametro TPVGRE debe existir en cobis..cl_parametro
- Consulta de verificacion:
```sql
SELECT pa_producto, pa_nemonico, pa_smallint
FROM cobis..cl_parametro
WHERE pa_producto = 'MIS' AND pa_nemonico = 'TPVGRE'
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para INSERT
   - `@i_verificado='S'`
      - fuente_valor=analisis
      - fuente_detalle=Verificado Si - activa vigencia
   - `@i_descripcion='Calle Verificada 789'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Retorno 0 (exito)
- El SP asigna automaticamente @i_vigencia='S', @i_fecha_ver=@s_date, @i_usuario_ver=@s_user, @i_fecha_caducidad=@s_date + TPVGRE dias

Resultado esperado en BD:
- Se inserta en cl_direccion con di_verificado='S', di_vigencia='S', di_fecha_ver=@s_date, di_usuario_ver=@s_user, di_fecha_caducidad calculada

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_verificado, di_vigencia, di_fecha_ver, di_usuario_ver, di_fecha_caducidad
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_verificado = 'S'
ORDER BY di_direccion DESC
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-004: INSERT exitoso - Direccion tipo Otro

Objetivo: RN-11 - Insercion valida de direccion tipo Otro. Cubre AFUN-PEQ-001, AFUN-PEQ-014.

Precondiciones:
- Mismas precondiciones que TC-001
- El ente no debe tener mas de 1 direccion tipo O existente
- Consulta de verificacion:
```sql
SELECT COUNT(1) as cnt_o
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_tipo = 'O'
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para INSERT
   - `@i_tipo='O'`
      - fuente_valor=analisis
      - fuente_detalle=Tipo Otro valido
   - `@i_descripcion='Direccion Alternativa 101'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Retorno 0 (exito)
- @o_direccion retorna el secuencial asignado

Resultado esperado en BD:
- Se inserta un registro en cobis..cl_direccion con di_tipo='O'
- Se inserta un registro en cobis..ts_direccion con clase='N'

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_tipo, di_fecha_registro
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_tipo = 'O'
ORDER BY di_direccion DESC
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-005: INSERT exitoso - Direccion con envio de correspondencia

Objetivo: RN-25 - Insercion con @i_envio_crp='S' desmarca direccion anterior y propaga a cuentas. Cubre AFUN-PEQ-001, AFUN-PEQ-015, AFUN-TD-010.

Precondiciones:
- Mismas precondiciones que TC-001
- El ente debe tener cuentas de ahorro en cob_ahorros..ah_cuenta (para que el cursor itere)
- Si existe otra direccion con di_envio_crp='S', sera desmarcada
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_envio_crp = 'S'
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para INSERT
   - `@i_envio_crp='S'`
      - fuente_valor=analisis
      - fuente_detalle=Envio de correspondencia Si
   - `@i_descripcion='Calle Envio CRP 555'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Retorno 0 (exito)
- @o_direccion retorna el secuencial asignado

Resultado esperado en BD:
- Se inserta en cl_direccion con di_envio_crp='S'
- Si existia otra direccion con di_envio_crp='S', se actualiza a 'N'
- Se inserta en ts_direccion
- Se ejecuta cursor sobre cob_ahorros..ah_cuenta y sp_dir_est_cta para cada cuenta

Tablas afectadas:
- `cobis..cl_direccion` - INSERT, UPDATE
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_envio_crp, di_fecha_registro
FROM cobis..cl_direccion
WHERE di_ente = 1
ORDER BY di_direccion DESC
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-006: UPDATE exitoso - Cambio de descripcion de direccion

Objetivo: RN-05 - Actualizacion valida de direccion existente cambiando solo la descripcion. Cubre AFUN-PEQ-002, AFUN-PEQ-012, AFUN-TD-019.

Precondiciones:
- El ente @i_ente debe existir en cobis..cl_ente con en_subtipo='P'
- Debe existir una direccion para el ente en cobis..cl_direccion
- El producto @i_producto=2 debe existir
- La ciudad, parroquia, oficina deben existir
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_tipo, di_ciudad, di_parroquia, di_oficina, di_verificado
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_tipo = 'D'
ORDER BY di_direccion
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para UPDATE
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=SELECT TOP 1 di_direccion FROM cobis..cl_direccion WHERE di_ente=1 AND di_tipo='D' ORDER BY di_direccion
   - `@i_descripcion='Calle Modificada 999'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Nueva descripcion diferente a la actual

Resultado esperado funcional:
- Retorno 0 (exito)

Resultado esperado en BD:
- Se actualiza cl_direccion con di_descripcion='Calle Modificada 999', di_fecha_modificacion=@w_today, di_usuario_mod=@s_user
- Se insertan 2 registros en ts_direccion: clase='P' (previo) y clase='A' (actual)
- @w_envio_notifica se activa porque la descripcion cambio

Tablas afectadas:
- `cobis..cl_direccion` - UPDATE
- `cobis..ts_direccion` - INSERT (2 registros)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_fecha_modificacion, di_usuario_mod
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-007: UPDATE exitoso - Cambio de tipo de direccion (D a T)

Objetivo: RN-11 - Actualizacion valida cambiando el tipo de direccion. Cubre AFUN-PEQ-002.

Precondiciones:
- Mismas precondiciones que TC-006
- El ente no debe tener mas de 1 direccion tipo T existente (maximo 2)
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_tipo
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para UPDATE
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente del ente
   - `@i_tipo='T'`
      - fuente_valor=analisis
      - fuente_detalle=Cambio de tipo D a T

Resultado esperado funcional:
- Retorno 0 (exito)

Resultado esperado en BD:
- Se actualiza cl_direccion con di_tipo='T'
- Se insertan 2 registros en ts_direccion (previo y actual)

Tablas afectadas:
- `cobis..cl_direccion` - UPDATE
- `cobis..ts_direccion` - INSERT (2 registros)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_tipo, di_fecha_modificacion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-008: UPDATE exitoso - Cambio de ciudad y parroquia

Objetivo: Actualizacion valida cambiando ciudad y parroquia. Cubre AFUN-PEQ-002.

Precondiciones:
- Mismas precondiciones que TC-006
- La nueva ciudad y parroquia deben existir en catalogos
- Consulta de verificacion:
```sql
SELECT ci_ciudad, ci_estado FROM cobis..cl_ciudad WHERE ci_ciudad = 2
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para UPDATE
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente del ente
   - `@i_ciudad=2`
      - fuente_valor=sybase_select
      - fuente_detalle=SELECT TOP 1 ci_ciudad FROM cobis..cl_ciudad WHERE ci_ciudad <> 1 ORDER BY ci_ciudad
   - `@i_parroquia=2`
      - fuente_valor=sybase_select
      - fuente_detalle=SELECT TOP 1 pq_parroquia FROM cobis..cl_parroquia WHERE pq_ciudad=2 ORDER BY pq_parroquia

Resultado esperado funcional:
- Retorno 0 (exito)

Resultado esperado en BD:
- Se actualiza cl_direccion con di_ciudad=2, di_parroquia=2
- @w_ind_alerta se activa porque ciudad y parroquia cambiaron
- Se insertan 2 registros en ts_direccion

Tablas afectadas:
- `cobis..cl_direccion` - UPDATE
- `cobis..ts_direccion` - INSERT (2 registros)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_ciudad, di_parroquia, di_fecha_modificacion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-009: UPDATE exitoso - Cambio de verificacion a 'S' (activa vigencia)

Objetivo: RN-22 - Actualizacion que activa vigencia al cambiar verificacion a 'S'. Cubre AFUN-PEQ-002.

Precondiciones:
- Mismas precondiciones que TC-006
- La direccion debe tener di_verificado != 'S'
- El parametro TPVGRE debe existir
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_verificado, di_vigencia
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para UPDATE
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente del ente
   - `@i_verificado='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa vigencia de referencia

Resultado esperado funcional:
- Retorno 0 (exito)

Resultado esperado en BD:
- Se actualiza cl_direccion con di_verificado='S', di_vigencia='S', di_fecha_ver=@s_date, di_usuario_ver=@s_user, di_fecha_caducidad calculada
- @i_tipo_verif_incns se fuerza a null (por ser verificado 'S')

Tablas afectadas:
- `cobis..cl_direccion` - UPDATE
- `cobis..ts_direccion` - INSERT (2 registros)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_verificado, di_vigencia, di_fecha_ver, di_usuario_ver, di_fecha_caducidad
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-010: UPDATE exitoso - Cambio de oficina

Objetivo: Actualizacion valida cambiando oficina. Cubre AFUN-PEQ-002.

Precondiciones:
- Mismas precondiciones que TC-006
- La nueva oficina debe existir en cl_oficina
- Consulta de verificacion:
```sql
SELECT of_oficina FROM cobis..cl_oficina WHERE of_oficina = 2
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para UPDATE
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente del ente
   - `@i_oficina=2`
      - fuente_valor=sybase_select
      - fuente_detalle=SELECT TOP 1 of_oficina FROM cobis..cl_oficina WHERE of_oficina <> 1 ORDER BY of_oficina

Resultado esperado funcional:
- Retorno 0 (exito)

Resultado esperado en BD:
- Se actualiza cl_direccion con di_oficina=2
- @w_envio_notifica se activa porque oficina cambio

Tablas afectadas:
- `cobis..cl_direccion` - UPDATE
- `cobis..ts_direccion` - INSERT (2 registros)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_oficina, di_fecha_modificacion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-011: UPDATE sin cambios - Todos los campos iguales

Objetivo: AFUN-EG-008 - UPDATE donde todos los campos enviados coinciden con los actuales. Cubre AFUN-PEQ-002.

Precondiciones:
- Mismas precondiciones que TC-006
- Se necesita conocer los valores actuales de la direccion
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_tipo, di_ciudad, di_parroquia, di_oficina, di_sector, di_zona, di_envio_crp, di_parroquia_ciu, di_observacion, di_verificado, di_vigencia, di_pto_referencia
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para UPDATE
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente del ente
   - `@i_descripcion`=(mismo valor que el actual en BD)
      - fuente_valor=sybase_select
      - fuente_detalle=Se debe usar el valor exacto de di_descripcion de la BD
   - `@i_tipo`=(mismo valor que el actual en BD)
      - fuente_valor=sybase_select
      - fuente_detalle=Se debe usar el valor exacto de di_tipo de la BD

Resultado esperado funcional:
- Retorno 0 (exito)
- El UPDATE se ejecuta pero los campos no cambian (se asigna el mismo valor)
- @w_envio_notifica permanece 'N' (no se detectan cambios)

Resultado esperado en BD:
- Se ejecuta UPDATE en cl_direccion (mismos valores)
- Se insertan 2 registros en ts_direccion (previo y actual con mismos valores)
- No se activa notificacion

Tablas afectadas:
- `cobis..cl_direccion` - UPDATE
- `cobis..ts_direccion` - INSERT (2 registros)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_tipo, di_fecha_modificacion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-012: DELETE exitoso - Eliminacion de direccion

Objetivo: RN-39, RN-40, RN-41, RN-42, RN-43 - Eliminacion valida de direccion que no es la unica, no es envio CRP, no esta asociada a cuentas. Cubre AFUN-PEQ-003.

Precondiciones:
- El ente debe tener al menos 2 direcciones en cl_direccion
- La direccion a eliminar no debe tener di_envio_crp='S'
- La direccion no debe estar asociada a cuenta corriente en cob_cuentas..cc_ctacte
- La direccion no debe estar asociada a ECTC en cl_dir_envio_tarj_cred
- Si es tipo D, no debe tener numero movil asociado en cl_direccion_email
- @e_actmasivacli='N'
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_tipo, di_envio_crp, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 1
ORDER BY di_direccion
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para DELETE
   - `@i_direccion=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Segunda direccion del ente (no la unica)
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Retorno 0 (exito)

Resultado esperado en BD:
- Se elimina el registro de cl_direccion
- Se inserta en ts_direccion con clase='B' (borrado)
- Se inserta en cl_log_dir_envio_ec con tipo_accion='E'
- Se inserta en cobis_his..cl_direccion_his (historico)
- Se insertan en cobis_his..cl_telefono_his los telefonos asociados
- Se eliminan los telefonos asociados en cl_telefono (via sp_telefono)

Tablas afectadas:
- `cobis..cl_direccion` - DELETE
- `cobis..ts_direccion` - INSERT
- `cl_log_dir_envio_ec` - INSERT
- `cobis_his..cl_direccion_his` - INSERT
- `cobis_his..cl_telefono_his` - INSERT
- `cobis..cl_telefono` - DELETE (via sp_telefono)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 2
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-013: DELETE exitoso - Eliminacion con @e_actmasivacli<>'N' (sin validaciones)

Objetivo: RN-50 - Eliminacion que omite validaciones cuando @e_actmasivacli no es 'N'. Cubre AFUN-PEQ-003.

Precondiciones:
- Mismas precondiciones que TC-012
- @e_actmasivacli='S' omite las validaciones de eliminacion (RN-39 a RN-43)
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_tipo, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 1
ORDER BY di_direccion
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para DELETE
   - `@i_direccion=3`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion a eliminar
   - `@e_actmasivacli='S'`
      - fuente_valor=analisis
      - fuente_detalle=Compra de cartera - omite validaciones

Resultado esperado funcional:
- Retorno 0 (exito)
- No se ejecutan las validaciones RN-39 a RN-43

Resultado esperado en BD:
- Se elimina el registro de cl_direccion sin validar si es la unica, si es envio CRP, etc.
- Se inserta en ts_direccion, historicos y log

Tablas afectadas:
- `cobis..cl_direccion` - DELETE
- `cobis..ts_direccion` - INSERT
- `cl_log_dir_envio_ec` - INSERT
- `cobis_his..cl_direccion_his` - INSERT
- `cobis_his..cl_telefono_his` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 3
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-014: DELETE exitoso - Eliminacion con notificacion

Objetivo: RN-51 - Eliminacion que activa notificacion al cliente. Cubre AFUN-PEQ-003.

Precondiciones:
- Mismas precondiciones que TC-012
- @i_envio_notifica='S', @w_subtipo='P', @w_fecha_reg > @w_fecha_crea_cli
- El SP hijo sp_notif_cli_mod_dir debe existir
- Consulta de verificacion:
```sql
SELECT en_ente, en_subtipo, en_fecha_crea
FROM cobis..cl_ente
WHERE en_ente = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para DELETE
   - `@i_direccion=4`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion a eliminar
   - `@i_envio_notifica='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa notificacion

Resultado esperado funcional:
- Retorno 0 (exito)
- Se invoca sp_notif_cli_mod_dir para notificar eliminacion

Resultado esperado en BD:
- Se elimina el registro de cl_direccion
- Se inserta en ts_direccion, historicos y log
- Se invoca sp_notif_cli_mod_dir (si @w_fecha_reg > @w_fecha_crea_cli)

Tablas afectadas:
- `cobis..cl_direccion` - DELETE
- `cobis..ts_direccion` - INSERT
- `cl_log_dir_envio_ec` - INSERT
- `cobis_his..cl_direccion_his` - INSERT
- `cobis_his..cl_telefono_his` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 4
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-015: DELETE exitoso - Eliminacion sin notificacion (@i_envio_notifica='N')

Objetivo: Eliminacion sin envio de notificacion. Cubre AFUN-PEQ-003, AFUN-PEQ-016.

Precondiciones:
- Mismas precondiciones que TC-012
- @i_envio_notifica='N' suprime la notificacion

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para DELETE
   - `@i_direccion=5`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion a eliminar
   - `@i_envio_notifica='N'`
      - fuente_valor=analisis
      - fuente_detalle=Suprime notificacion

Resultado esperado funcional:
- Retorno 0 (exito)
- No se invoca sp_notif_cli_mod_dir

Resultado esperado en BD:
- Se elimina el registro de cl_direccion
- Se inserta en ts_direccion, historicos y log
- No se invoca sp_notif_cli_mod_dir

Tablas afectadas:
- `cobis..cl_direccion` - DELETE
- `cobis..ts_direccion` - INSERT
- `cl_log_dir_envio_ec` - INSERT
- `cobis_his..cl_direccion_his` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 5
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-016: DELETE E exitoso - Eliminacion con validaciones a temporales

Objetivo: RN-47 - Eliminacion tipo E que usa tablas temporales para validaciones. Cubre AFUN-PEQ-004, AFUN-TD-030.

Precondiciones:
- El ente debe existir en cl_ente
- Debe existir la direccion en cl_direccion
- El producto debe existir
- Debe existir al menos un registro en cl_direccion_tmp con di_estado <> 'E' para el ente
- La direccion no debe estar en cl_dir_est_cta_tmp como direccion de envio EC
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_tipo, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='E'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida DELETE con temporales
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para DELETE
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion a eliminar
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Retorno 0 (exito)

Resultado esperado en BD:
- Se eliminan telefonos asociados (via sp_telefono en while)
- Se elimina el registro de cl_direccion
- Se inserta en ts_direccion con clase='B'

Tablas afectadas:
- `cobis..cl_direccion` - DELETE
- `cobis..ts_direccion` - INSERT
- `cobis..cl_telefono` - DELETE (via sp_telefono)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-017: DELETE E exitoso - Eliminacion con @i_no_cobis='S'

Objetivo: RN-47 con generacion de secuencial de transaccion. Cubre AFUN-PEQ-004, AFUN-TD-030.

Precondiciones:
- Mismas precondiciones que TC-016
- sp_gen_sec debe estar disponible

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='E'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida DELETE con temporales
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para DELETE
   - `@i_direccion=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion a eliminar
   - `@i_no_cobis='S'`
      - fuente_valor=analisis
      - fuente_detalle=Genera secuencial de transaccion

Resultado esperado funcional:
- Retorno 0 (exito)
- Se genera secuencial via sp_gen_sec

Resultado esperado en BD:
- Se elimina direccion y telefonos
- Se inserta en ts_direccion con @s_ssn generado

Tablas afectadas:
- `cobis..cl_direccion` - DELETE
- `cobis..ts_direccion` - INSERT
- `cobis..cl_telefono` - DELETE (via sp_telefono)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 2
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-018: Error - Operacion no soportada (@i_operacion='X')

Objetivo: AFUN-EG-001, AFUN-EG-002 - El SP no tiene bloque para @i_operacion='X', llega a return 0 sin ejecutar DML. Cubre AFUN-PEQ-005.

Precondiciones:
- No se requieren precondiciones especiales
- El SP evalua @i_operacion='I', 'U', 'D', 'E' secuencialmente; si no coincide, llega a return 0

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='X'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion no soportada - no existe bloque para 'X'
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion (no se evalua porque @i_operacion no coincide)

Resultado esperado funcional:
- Retorno 0 (el SP llega al return 0 final sin ejecutar ninguna operacion DML)

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD
- No se inserta en ts_direccion
- No se modifica cl_direccion

Tablas afectadas:
- `cobis..cl_ente` - SELECT (lectura inicial del ente)
- `cobis..cl_direccion_email` - SELECT (si @i_envio_notifica='S' y @w_subtipo='P')

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-019: Error - Ente igual a cero (RN-02)

Objetivo: RN-02 - Validacion de ente no puede ser cero. Cubre AFUN-PEQ-006, AFUN-TD-001.

Precondiciones:
- No se requieren precondiciones especiales (la validacion ocurre antes de consultar cl_ente)

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Particion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_ente=0`
      - fuente_valor=analisis
      - fuente_detalle=Ente cero - valor invalido

Resultado esperado funcional:
- Error: codigo 101042 ("No existe ente")
- El SP ejecuta sp_cerror con @i_num=101042
- Retorno 1

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD
- No se inserta en cl_direccion ni ts_direccion

Tablas afectadas:
- Ninguna (la validacion ocurre antes de cualquier DML)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 0
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-020: Error - Ente inexistente (RN-03)

Objetivo: RN-03 - Validacion de ente debe existir en cl_ente. Cubre AFUN-PEQ-007, AFUN-TD-002.

Precondiciones:
- El ente 999999 no debe existir en cobis..cl_ente
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe
FROM cobis..cl_ente
WHERE en_ente = 999999
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Particion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_ente=999999`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Ente que no existe en cl_ente

Resultado esperado funcional:
- Error: codigo 101042 ("No existe ente")
- El SELECT de cl_ente retorna @@rowcount=0
- El SP ejecuta sp_cerror con @i_num=101042
- Retorno 1

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT (lectura, no encuentra fila)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 999999
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-021: Error - Tipo de direccion invalido (RN-11)

Objetivo: RN-11 - Validacion de tipo solo D, T, O. Cubre AFUN-PEQ-008, AFUN-TD-004.

Precondiciones:
- El ente debe existir en cl_ente
- El producto debe existir
- La ciudad, parroquia, oficina deben existir

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Particion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_tipo='X'`
      - fuente_valor=analisis
      - fuente_detalle=Tipo invalido - no es D, T ni O

Resultado esperado funcional:
- Error: codigo 101627 ("TIPO DIRECCION SOLO PUEDE SER D T O")
- El SP ejecuta sp_cerror con @i_num=101627
- Retorno 1

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-022: Error - Envio CRP invalido (RN-13)

Objetivo: RN-13 - Validacion de envio CRP solo N o S. Cubre AFUN-PEQ-009, AFUN-TD-005.

Precondiciones:
- Mismas precondiciones que TC-021
- El tipo 'D' debe existir en catalogo cl_tdireccion

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Particion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_envio_crp='X'`
      - fuente_valor=analisis
      - fuente_detalle=Valor invalido - no es N ni S

Resultado esperado funcional:
- Error: codigo 101114 ("Parametro invalido")
- El SP ejecuta sp_cerror con @i_num=101114
- Retorno 1

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-023: Error - Producto inexistente (RN-06)

Objetivo: RN-06, AFUN-EG-003 - Validacion de producto debe existir. Cubre AFUN-TD-003.

Precondiciones:
- El ente debe existir en cl_ente
- El producto 255 no debe existir en cl_producto (tinyint max)
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe
FROM cobis..cl_producto
WHERE pd_producto = 255
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Particion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_producto=255`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Producto que no existe en cl_producto

Resultado esperado funcional:
- Error: codigo 101032 ("No existe producto")
- El SP ejecuta sp_cerror con @i_num=101032
- Retorno 1

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT (no encuentra fila)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-024: INSERT exitoso - Sin notificacion (@i_envio_notifica='N')

Objetivo: Insercion valida con notificacion suprimida. Cubre AFUN-PEQ-001, AFUN-PEQ-016.

Precondiciones:
- Mismas precondiciones que TC-001

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para INSERT
   - `@i_envio_notifica='N'`
      - fuente_valor=analisis
      - fuente_detalle=Suprime obtencion de email/celular y notificacion
   - `@i_descripcion='Calle Sin Notif 321'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Retorno 0 (exito)
- No se obtiene email ni celular del cliente
- No se invoca sp_notif_cli_mod_dir

Resultado esperado en BD:
- Se inserta en cl_direccion y ts_direccion normalmente
- No se ejecuta el bloque de notificacion

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_tipo, di_fecha_registro
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_descripcion = 'Calle Sin Notif 321'
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-025: INSERT exitoso - Sin validacion de maximo de direcciones (@i_ind_val_maxdir='N')

Objetivo: Insercion valida sin validar maximo de direcciones. Cubre AFUN-PEQ-001, AFUN-PEQ-017.

Precondiciones:
- Mismas precondiciones que TC-001
- @i_ind_val_maxdir='N' omite las validaciones de maximo de direcciones

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Particion valida INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para INSERT
   - `@i_ind_val_maxdir='N'`
      - fuente_valor=analisis
      - fuente_detalle=Omite validacion de maximo de direcciones
   - `@i_descripcion='Calle Sin Valid Max 654'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Retorno 0 (exito)
- No se ejecutan las validaciones de maximo de direcciones (RN-15 a RN-19)

Resultado esperado en BD:
- Se inserta en cl_direccion y ts_direccion sin verificar limites

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_tipo, di_fecha_registro
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_descripcion = 'Calle Sin Valid Max 654'
```

Resultado observado en BD:
- Completar durante la ejecucion.

---

## TC-026: Error - UPDATE con @t_trn no correspondiente (109)

Objetivo: AFUN-EG-004 - UPDATE (@i_operacion='U') con @t_trn=109 que corresponde a INSERT. El SP valida @t_trn=110 para UPDATE.

Precondiciones:
- El ente debe existir en cl_ente
- Consulta de verificacion:
```sql
SELECT en_ente, en_subtipo FROM cobis..cl_ente WHERE en_ente = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Particion UPDATE
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion de INSERT, no corresponde a UPDATE
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente del ente

Resultado esperado funcional:
- Error: codigo 151051 ("No corresponde codigo de transaccion")
- El SP entra al bloque @i_operacion='U', evalua @t_trn=110, no coincide, va al ELSE
- Retorno 1 (via sp_cerror)

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-027: Error - DELETE con @t_trn no correspondiente (110)

Objetivo: AFUN-EG-005 - DELETE (@i_operacion='D') con @t_trn=110 que corresponde a UPDATE. El SP valida @t_trn=1226 para DELETE.

Precondiciones:
- El ente debe existir en cl_ente
- Consulta de verificacion:
```sql
SELECT en_ente, en_subtipo FROM cobis..cl_ente WHERE en_ente = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Particion DELETE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion de UPDATE, no corresponde a DELETE
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Error: codigo 151051 ("No corresponde codigo de transaccion")
- El SP entra al bloque @i_operacion='D', evalua @t_trn=1226, no coincide, va al ELSE
- Retorno 1 (via sp_cerror)

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-028: Error - UPDATE con direccion inexistente

Objetivo: AFUN-EG-006 - UPDATE sobre @i_direccion que no existe para el ente. El SELECT de cl_direccion retorna @@rowcount=0.

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir
- La direccion 99 no debe existir para el ente
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 99
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Particion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para UPDATE
   - `@i_direccion=99`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Direccion que no existe para el ente

Resultado esperado funcional:
- Error: codigo 101059 ("No existe direccion")
- El SELECT de cl_direccion retorna @@rowcount=0
- Retorno 1 (via sp_cerror)

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT
- `cobis..cl_direccion` - SELECT (no encuentra fila)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-029: Error - DELETE con direccion inexistente

Objetivo: AFUN-EG-007 - DELETE sobre @i_direccion que no existe para el ente.

Precondiciones:
- El ente debe existir en cl_ente
- El producto debe existir
- La direccion 99 no debe existir para el ente
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 99
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Particion DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para DELETE
   - `@i_direccion=99`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Direccion que no existe para el ente
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Error: codigo 101001 ("No existe dato solicitado")
- El SELECT de cl_direccion retorna @@rowcount=0
- Retorno 1 (via sp_cerror)

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_direccion` - SELECT (no encuentra fila)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-030: Error - No se puede desmarcar direccion de envio CRP en UPDATE (RN-33)

Objetivo: AFUN-TD-011 - UPDATE que intenta cambiar @i_envio_crp de 'S' a 'N' cuando la direccion actual tiene di_envio_crp='S'.

Precondiciones:
- El ente debe existir en cl_ente con en_subtipo='P'
- Debe existir una direccion con di_envio_crp='S' para el ente
- El producto, ciudad, parroquia, oficina deben existir
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_envio_crp, di_tipo
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_envio_crp = 'S'
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Particion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para UPDATE
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion con di_envio_crp='S'
   - `@i_envio_crp='N'`
      - fuente_valor=analisis
      - fuente_detalle=Intento de desmarcar envio de correspondencia

Resultado esperado funcional:
- Error: codigo 101281 ("NO SE PUEDE DESMARCAR LA DIRECCION DE ENVIO DE CORRESPONDENCIA")
- La validacion @v_envio_crp='S' and @w_envio_crp='N' se activa
- Retorno 1 (via sp_cerror)

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT
- `cobis..cl_direccion` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-031: Error - Validacion de actualizacion presencial (RN-34)

Objetivo: AFUN-TD-012 - UPDATE con @i_ind_act_presenc='V' cuando hubo cambios no presenciales (@v_varifica_presencial='N').

Precondiciones:
- El ente debe existir en cl_ente con en_subtipo='P'
- Debe existir una direccion para el ente
- El producto, ciudad, parroquia, oficina deben existir
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_tipo, di_verificado
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Particion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para UPDATE
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente del ente
   - `@i_ind_act_presenc='V'`
      - fuente_valor=analisis
      - fuente_detalle=Actualizacion presencial requerida
   - `@i_descripcion='Cambio No Presencial 777'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Cambio que activa @v_varifica_presencial='N'

Resultado esperado funcional:
- Error: codigo 105109 (validacion presencial)
- El cambio de descripcion activa @v_varifica_presencial='N'
- La condicion @v_varifica_presencial='N' and @i_ind_act_presenc='V' se cumple
- Retorno 1 (via sp_cerror)

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT
- `cobis..cl_direccion` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-032: Error - No se puede eliminar la unica direccion del ente (RN-39)

Objetivo: AFUN-TD-013 - DELETE cuando el ente tiene exactamente 1 direccion.

Precondiciones:
- El ente debe existir en cl_ente
- El ente debe tener exactamente 1 direccion en cl_direccion
- @e_actmasivacli='N'
- Consulta de verificacion:
```sql
SELECT di_ente, COUNT(1) as total_dir
FROM cobis..cl_direccion
WHERE di_ente = 1
GROUP BY di_ente
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Particion DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para DELETE
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Unica direccion del ente
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Error: codigo 101053 ("No se puede eliminar todas las direcciones")
- La validacion count(1)=1 se activa
- Retorno 1 (via sp_cerror)

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_direccion` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-033: Error - No se puede eliminar direccion de envio de correspondencia (RN-40)

Objetivo: AFUN-TD-014 - DELETE cuando la direccion tiene @w_envio_crp='S'.

Precondiciones:
- El ente debe existir en cl_ente
- El ente debe tener al menos 2 direcciones
- La direccion a eliminar debe tener di_envio_crp='S'
- @e_actmasivacli='N'
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_envio_crp, di_tipo
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_envio_crp = 'S'
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Particion DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para DELETE
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion con di_envio_crp='S'
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Error: codigo 101274 ("NO SE PUEDE ELIMINAR LA DIRECCION DE ENVIO DE CORRESPONDENCIA")
- La validacion @w_envio_crp='S' se activa
- Retorno 1 (via sp_cerror)

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_direccion` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-034: INSERT con notificacion - Via canal MIS (RN-24, RN-31)

Objetivo: AFUN-TD-024, AFUN-TD-020 - INSERT que activa notificacion por cambio de direccion via canal MIS. Cubre la determinacion del canal y el envio de notificacion.

Precondiciones:
- El ente debe existir en cl_ente con en_subtipo='P'
- @w_fecha_reg > @w_fecha_crea_cli (cliente creado antes de hoy)
- El producto, ciudad, parroquia, oficina deben existir
- sp_notif_cli_mod_dir debe existir y retornar 0
- Consulta de verificacion:
```sql
SELECT en_ente, en_subtipo, en_fecha_crea, en_ced_ruc, en_nombre
FROM cobis..cl_ente
WHERE en_ente = 1 AND en_subtipo = 'P'
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Particion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para INSERT
   - `@i_envio_notifica='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa notificacion
   - `@i_producto=2`
      - fuente_valor=analisis
      - fuente_detalle=Producto 2 activa canal MIS
   - `@i_canal='MIS'`
      - fuente_valor=analisis
      - fuente_detalle=Canal MIS para notificacion
   - `@i_descripcion='Calle Con Notif MIS 888'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Retorno 0 (exito)
- @w_canal se determina como 'MIS' (por @i_producto=2 y @i_canal='MIS')
- Se invoca sp_notif_cli_mod_dir con @i_canalmod='MIS'
- El SP emite SELECT con datos de notificacion (@w_medio, @w_nombrecliente, etc.)

Resultado esperado en BD:
- Se inserta en cl_direccion y ts_direccion
- Se invoca sp_notif_cli_mod_dir (si @w_fecha_reg > @w_fecha_crea_cli)

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_tipo, di_fecha_registro
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_descripcion = 'Calle Con Notif MIS 888'
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-035: UPDATE con verificacion de direccion asociada a EC (RN-32)

Objetivo: AFUN-TD-025 - UPDATE con @i_verifdirec='S' que verifica si la direccion esta asociada a envio de estado de cuenta (cuenta corriente o ECTC).

Precondiciones:
- El ente debe existir en cl_ente
- Debe existir una direccion para el ente
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_tipo
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Particion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para UPDATE
   - `@i_verifdirec='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa verificacion de direccion asociada a EC
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion a verificar

Resultado esperado funcional:
- Si la direccion esta asociada a cuenta corriente (cc_ctacte) o ECTC (cl_dir_envio_tarj_cred): retorna @i_verifdirec='S' y return 0 inmediato
- Si no esta asociada: retorna 'N' y return 0 inmediato
- En ambos casos, el SP hace return 0 antes de ejecutar el UPDATE

Resultado esperado en BD:
- No se realiza UPDATE en cl_direccion (el SP retorna antes)
- No se inserta en ts_direccion

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cob_cuentas..cc_ctacte` - SELECT (si aplica)
- `cl_dir_envio_tarj_cred` - SELECT (si aplica)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_fecha_modificacion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-036: UPDATE con notificacion - Cambio de descripcion activa envio (RN-38)

Objetivo: AFUN-TD-029 - UPDATE que cambia la descripcion y activa notificacion al cliente.

Precondiciones:
- El ente debe existir en cl_ente con en_subtipo='P'
- Debe existir una direccion para el ente
- @w_fecha_reg > @w_fecha_crea_cli
- El producto, ciudad, parroquia, oficina deben existir
- sp_notif_cli_mod_dir debe existir
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_tipo
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Particion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para UPDATE
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente del ente
   - `@i_descripcion='Calle Notif UPDATE 444'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Cambio de descripcion activa @w_envio_notifica='S'
   - `@i_envio_notifica='S'`
      - fuente_valor=analisis
      - fuente_detalle=Notificacion activa

Resultado esperado funcional:
- Retorno 0 (exito)
- @w_envio_notifica se activa porque la descripcion cambio
- Se invoca sp_notif_cli_mod_dir
- El SP emite SELECT con datos de notificacion

Resultado esperado en BD:
- Se actualiza cl_direccion con nueva descripcion
- Se insertan 2 registros en ts_direccion (previo y actual)
- Se invoca sp_notif_cli_mod_dir

Tablas afectadas:
- `cobis..cl_direccion` - UPDATE
- `cobis..ts_direccion` - INSERT (2 registros)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_fecha_modificacion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-037: DELETE con notificacion - Eliminacion activa envio (RN-51)

Objetivo: AFUN-TD-032 - DELETE que activa notificacion al cliente por eliminacion de direccion.

Precondiciones:
- El ente debe existir en cl_ente con en_subtipo='P'
- El ente debe tener al menos 2 direcciones
- @w_fecha_reg > @w_fecha_crea_cli
- La direccion no debe ser envio CRP, no asociada a cuentas
- @e_actmasivacli='N'
- sp_notif_cli_mod_dir debe existir
- Consulta de verificacion:
```sql
SELECT en_ente, en_subtipo, en_fecha_crea
FROM cobis..cl_ente
WHERE en_ente = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Particion DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para DELETE
   - `@i_direccion=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion a eliminar (no la unica, no envio CRP)
   - `@i_envio_notifica='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa notificacion por eliminacion
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Retorno 0 (exito)
- Se invoca sp_notif_cli_mod_dir para notificar eliminacion
- El SP emite SELECT con datos de notificacion (@w_medio, @w_nombrecliente, etc.)

Resultado esperado en BD:
- Se elimina el registro de cl_direccion
- Se inserta en ts_direccion, historicos y log
- Se invoca sp_notif_cli_mod_dir

Tablas afectadas:
- `cobis..cl_direccion` - DELETE
- `cobis..ts_direccion` - INSERT
- `cl_log_dir_envio_ec` - INSERT
- `cobis_his..cl_direccion_his` - INSERT
- `cobis_his..cl_telefono_his` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 2
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-038: INSERT - Validacion de maximo 3 direcciones por ente (RN-15)

Objetivo: AFUN-TD-006 - INSERT cuando el ente ya tiene 3 direcciones. Debe rechazar con error 101267.

Precondiciones:
- El ente debe existir en cl_ente con en_subtipo='P'
- El ente debe tener exactamente 3 direcciones en cl_direccion
- @i_ind_val_maxdir='S'
- El producto, ciudad, parroquia, oficina deben existir
- Consulta de verificacion:
```sql
SELECT di_ente, COUNT(1) as total_dir
FROM cobis..cl_direccion
WHERE di_ente = 1
GROUP BY di_ente
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Particion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para INSERT
   - `@i_ind_val_maxdir='S'`
      - fuente_valor=analisis
      - fuente_detalle=Validacion de maximo activa
   - `@i_descripcion='Calle Excede Max 000'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Error: codigo 101267 ("EL CLIENTE TIENE INGRESADO EL NUMERO MAXIMO DE DIRECCIONES")
- La validacion @w_num_dir >= 3 se activa
- Retorno 1 (via sp_cerror)

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT
- `cobis..cl_direccion` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-039: INSERT - Validacion de maximo 2 direcciones tipo T/O (RN-18)

Objetivo: AFUN-TD-006 - INSERT cuando el ente ya tiene 2 direcciones tipo T. Debe rechazar con error 101521.

Precondiciones:
- El ente debe existir en cl_ente con en_subtipo='P'
- El ente debe tener exactamente 2 direcciones tipo T en cl_direccion
- @i_ind_val_maxdir='S'
- El producto, ciudad, parroquia, oficina deben existir
- Consulta de verificacion:
```sql
SELECT di_ente, di_tipo, COUNT(1) as total_dir
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_tipo = 'T'
GROUP BY di_ente, di_tipo
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Particion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion para INSERT
   - `@i_tipo='T'`
      - fuente_valor=analisis
      - fuente_detalle=Tipo Trabajo - excede maximo
   - `@i_ind_val_maxdir='S'`
      - fuente_valor=analisis
      - fuente_detalle=Validacion de maximo activa
   - `@i_descripcion='Calle Excede T 111'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Error: codigo 101521 ("EL CLIENTE TIENE INGRESADO EL NUMERO MAXIMO DE DIRECCIONES TIPO TRABAJO Y OTRO")
- La validacion @w_num_dir >= 2 para tipo T se activa
- Retorno 1 (via sp_cerror)

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT
- `cobis..cl_direccion` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_tipo = 'T'
```

Resultado observado en BD:
- Completar durante la ejecucion.

---

## Control de Cobertura

- objetivo_casos: 39
- objetivo_casos_lote: 14
- casos_generados: 39
- porcentaje_cumplimiento: 100.0
- brecha: 0
- estado_tolerancia: OK
- rango_generado: TC-001 a TC-039
- siguiente_rango_sugerido: N/A (objetivo cumplido)
- ids_cubiertos: AFUN-PEQ-001, AFUN-PEQ-002, AFUN-PEQ-003, AFUN-PEQ-004, AFUN-PEQ-005, AFUN-PEQ-006, AFUN-PEQ-007, AFUN-PEQ-008, AFUN-PEQ-009, AFUN-PEQ-010, AFUN-PEQ-011, AFUN-PEQ-012, AFUN-PEQ-013, AFUN-PEQ-014, AFUN-PEQ-015, AFUN-PEQ-016, AFUN-PEQ-017, AFUN-TD-001, AFUN-TD-002, AFUN-TD-003, AFUN-TD-004, AFUN-TD-005, AFUN-TD-006, AFUN-TD-009, AFUN-TD-010, AFUN-TD-011, AFUN-TD-012, AFUN-TD-013, AFUN-TD-014, AFUN-TD-019, AFUN-TD-020, AFUN-TD-024, AFUN-TD-025, AFUN-TD-029, AFUN-TD-030, AFUN-TD-032, AFUN-EG-001, AFUN-EG-002, AFUN-EG-003, AFUN-EG-004, AFUN-EG-005, AFUN-EG-006, AFUN-EG-007, AFUN-EG-008
- ids_justificados: AFUN-TD-018 (cubierto por TC-013 en lote 1, @e_actmasivacli='S')
- ids_pendientes: AFUN-TD-007, AFUN-TD-008, AFUN-TD-015, AFUN-TD-016, AFUN-TD-017, AFUN-TD-021, AFUN-TD-022, AFUN-TD-023, AFUN-TD-026, AFUN-TD-027, AFUN-TD-028, AFUN-TD-031
- nota_depuracion: Lote 2 completa el objetivo de 39 casos. Se cubrieron errores funcionales adicionales (EG-004 a EG-007), reglas de decision criticas (RN-33 no desmarcar CRP, RN-34 validacion presencial, RN-39 no eliminar unica direccion, RN-40 no eliminar envio CRP, RN-15 maximo 3 direcciones, RN-18 maximo 2 T/O), y notificaciones (RN-24 canal MIS, RN-31 notif INSERT, RN-32 verificacion EC, RN-38 notif UPDATE, RN-51 notif DELETE). Quedan 12 IDs pendientes que requieren datos especificos de ambiente (ente PJ, ECTC configurado, cuentas asociadas, vreferen, tablas temporales). No se detectaron casos redundantes entre lotes.
- estado_validacion_contrato: VALIDADO_CON_CONDICIONES
- hallazgos_preflight:
  - `CONDICIONAL_LOCAL`: @i_valida declarado en firma pero no usado en cuerpo activo
  - `CONDICIONAL_LOCAL`: Notificaciones (sp_notif_cli_mod_dir) requieren ambiente configurado
  - `CONDICIONAL_LOCAL`: Validacion cantones/parroquias Ecuador requiere datos geograficos especificos
  - `CONDICIONAL_LOCAL`: Cursores sobre cuentas requieren datos reales en cob_ahorros y cob_cuentas
  - `LIMITACION_VALIDADOR`: El validador estatico no reconoce `create proc` como `CREATE PROCEDURE`. El SP usa `create proc dbo.sp_direccion_dml` (linea 166). Esto impide la extraccion automatica de la firma y causa falsos positivos en PARAM_NOT_IN_SIGNATURE, TABLE_NOT_IN_SP y COLUMN_NOT_IN_SP. La identidad del SP se verifico manualmente: base=cobis, dueno=dbo, procedimiento=sp_direccion_dml.
- parametros_verificados: total=64; entradas=61; salidas=3
- graph_context_status: NO_INFORMADO
- hallazgos_consistencia_grafo: No aplica (graph_context no informado)
# Casos de Prueba - sp_direccion_dml (Análisis Estructural)

## Resumen de plan de generacion

- **SP**: `sp_direccion_dml`
- **Tipo de análisis**: `estructural`
- **Técnicas aplicadas**: BVA (Boundary Value Analysis), Cobertura de Ramas, Fracción de Centavo
- **Objetivo de casos**: 59 (50% de 98 casos_finales_estimados + 10 por complejidad ALTA)
- **Rango solicitado**: TC-001 a TC-025
- **Lote actual**: 1 de 3 (25 casos)
- **Estrategia**: Cubrir fronteras BVA de parámetros numéricos (@i_ente, @i_direccion, @i_ciudad, @i_oficina, @i_parroquia, @t_trn, @i_producto), ramas de control transaccionales (BEGIN TRAN/COMMIT, @@error, @@rowcount), ramas WHILE (cursores), y ramas de enrutamiento por operación. No aplica CENT (sin cálculos monetarios).

## Parametros base de ejecucion

Valores base usados como referencia para todos los casos. Cada TC declara solo los `parametros_bajo_prueba` que cambian respecto a esta base.

| Parametro | Valor base | Fuente |
|-----------|-----------|--------|
| @s_ssn | 1 | supuesto_controlado |
| @s_user | 'TESTUSER' | supuesto_controlado |
| @s_term | 'TERM001' | supuesto_controlado |
| @s_date | '2026-11-12 10:00:00' | supuesto_controlado |
| @s_srv | 'SRV001' | supuesto_controlado |
| @s_lsrv | 'LSRV001' | supuesto_controlado |
| @s_ofi | 1 | supuesto_controlado |
| @s_rol | 1 | supuesto_controlado |
| @s_org_err | 'N' | supuesto_controlado |
| @s_error | 0 | supuesto_controlado |
| @s_sev | 0 | supuesto_controlado |
| @s_msg | null | supuesto_controlado |
| @s_org | 'N' | supuesto_controlado |
| @t_debug | 'N' | default |
| @t_file | null | default |
| @t_from | null | default |
| @t_trn | 109 | supuesto_controlado |
| @i_operacion | 'I' | supuesto_controlado |
| @i_no_cobis | 'N' | default |
| @i_mensaje | 'S' | default |
| @i_producto | 2 | supuesto_controlado |
| @i_ente | 1 | supuesto_controlado |
| @i_direccion | null | default |
| @i_descripcion | 'Calle Principal 123' | supuesto_controlado |
| @i_tipo | 'D' | supuesto_controlado |
| @i_sector | '0' | default |
| @i_parroquia | 1 | supuesto_controlado |
| @i_ciudad | 1 | supuesto_controlado |
| @i_oficina | 1 | supuesto_controlado |
| @i_zona | null | default |
| @i_envio_crp | 'N' | default |
| @i_parroquia_ciu | 0 | default |
| @i_observacion | null | default |
| @i_pto_referencia | null | default |
| @i_verificado | 'N' | default |
| @i_fecha_ver | null | default |
| @i_usuario_ver | null | default |
| @i_vigencia | 'N' | default |
| @i_fecha_caducidad | null | default |
| @i_nombre_verif | null | default |
| @i_cargo_verif | null | default |
| @i_ind_act_presenc | 'N' | default |
| @i_ind_val_maxdir | 'S' | default |
| @i_tipo_verif_incns | null | default |
| @i_bancarizacion | 'N' | default |
| @i_verifdirec | 'N' | default |
| @i_tipo_servicio | null | default |
| @i_cod_empresa | null | default |
| @i_direc_planilla | null | default |
| @i_cod_rela_prop | null | default |
| @i_nom_propietario | null | default |
| @i_vreferen | 'N' | default |
| @i_solicitud | null | default |
| @i_anio | null | default |
| @i_canton | null | default |
| @i_valida | 'S' | default |
| @i_val_dir | 'N' | default |
| @i_val_domicilio | 'S' | default |
| @i_canal | null | default |
| @i_envio_notifica | 'S' | default |
| @e_actmasivacli | 'N' | default |

## Plantilla de ejecucion del SP

```sql
EXEC cobis.dbo.sp_direccion_dml
  @s_ssn              = 1,
  @s_user             = 'TESTUSER',
  @s_term             = 'TERM001',
  @s_date             = '2026-11-12 10:00:00',
  @s_srv              = 'SRV001',
  @s_lsrv             = 'LSRV001',
  @s_ofi              = 1,
  @s_rol              = 1,
  @s_org_err          = 'N',
  @s_error            = 0,
  @s_sev              = 0,
  @s_msg              = null,
  @s_org              = 'N',
  @t_debug            = 'N',
  @t_file             = null,
  @t_from             = null,
  @t_trn              = 109,
  @i_operacion        = 'I',
  @i_no_cobis         = 'N',
  @i_mensaje          = 'S',
  @i_producto         = 2,
  @i_ente             = 1,
  @i_direccion        = null,
  @i_descripcion      = 'Calle Principal 123',
  @i_tipo             = 'D',
  @i_sector           = '0',
  @i_parroquia        = 1,
  @i_ciudad           = 1,
  @i_oficina          = 1,
  @i_zona             = null,
  @i_envio_crp        = 'N',
  @i_parroquia_ciu    = 0,
  @i_observacion      = null,
  @i_pto_referencia   = null,
  @i_verificado       = 'N',
  @i_fecha_ver        = null,
  @i_usuario_ver      = null,
  @i_vigencia         = 'N',
  @i_fecha_caducidad  = null,
  @i_nombre_verif     = null,
  @i_cargo_verif      = null,
  @i_ind_act_presenc  = 'N',
  @i_ind_val_maxdir   = 'S',
  @i_tipo_verif_incns = null,
  @i_bancarizacion    = 'N',
  @i_verifdirec       = 'N',
  @i_tipo_servicio    = null,
  @i_cod_empresa      = null,
  @i_direc_planilla   = null,
  @i_cod_rela_prop    = null,
  @i_nom_propietario  = null,
  @i_vreferen         = 'N',
  @i_solicitud        = null,
  @i_anio             = null,
  @i_canton           = null,
  @i_valida           = 'S',
  @i_val_dir          = 'N',
  @i_val_domicilio    = 'S',
  @i_canal            = null,
  @i_envio_notifica   = 'S',
  @e_actmasivacli     = 'N',
  @o_direccion        = null,
  @o_msj_error        = null,
  @o_sig_log_svr      = null
```

## Validacion de contrato del SP

- estado_validacion_contrato: VALIDADO_CON_CONDICIONES
- parametros_verificados: total=64; entradas=61; salidas=3
- Tablas/columnas verificadas: 23 tablas contra cuerpo activo del SP
- Hallazgos preflight:
  - `CONDICIONAL_LOCAL`: @i_valida declarado en firma pero no usado en cuerpo activo
  - `CONDICIONAL_LOCAL`: Cursores sobre cuentas requieren datos reales
  - `CONDICIONAL_LOCAL`: Notificaciones requieren ambiente configurado
  - `LIMITACION_VALIDADOR`: El validador no reconoce `create proc` como `CREATE PROCEDURE`
- graph_context_status: NO_INFORMADO

## Registro IDs de cobertura

| id | significado | estado | casos_asociados | evidencia_pendiente |
|----|-------------|--------|-----------------|---------------------|
| AEST-BVA-001 | @i_ente: frontera cero (0) | CUBIERTO | TC-001 | - |
| AEST-BVA-002 | @i_ente: frontera justo arriba de cero (1) | CUBIERTO | TC-002 | - |
| AEST-BVA-003 | @i_ente: valor maximo int | PENDIENTE | - | Requiere ente con ID maximo |
| AEST-BVA-004 | @i_direccion: frontera cero (0) | PENDIENTE | - | Requiere direccion 0 |
| AEST-BVA-005 | @i_direccion: frontera justo arriba (1) | CUBIERTO | TC-006 | - |
| AEST-BVA-006 | @i_direccion: valor maximo tinyint (255) | PENDIENTE | - | Requiere direccion 255 |
| AEST-BVA-007 | @t_trn: frontera 109 (INSERT) | CUBIERTO | TC-002 | - |
| AEST-BVA-008 | @t_trn: frontera 110 (UPDATE) | CUBIERTO | TC-006 | - |
| AEST-BVA-009 | @t_trn: frontera 1226 (DELETE) | CUBIERTO | TC-012 | - |
| AEST-BVA-010 | @t_trn: valor no correspondiente (0) | CUBIERTO | TC-003 | - |
| AEST-BVA-011 | @i_producto: frontera cero (0) | CUBIERTO | TC-029 | - |
| AEST-BVA-012 | @i_producto: valor maximo tinyint (255) | CUBIERTO | TC-004 | - |
| AEST-BVA-013 | @i_ciudad: frontera cero (0) | CUBIERTO | TC-026 | - |
| AEST-BVA-014 | @i_oficina: frontera cero (0) | CUBIERTO | TC-027 | - |
| AEST-BVA-015 | @i_parroquia: frontera cero (0) | CUBIERTO | TC-028 | - |
| AEST-RAMA-001 | RAMA-008: @i_operacion='I' (enrutador INSERT) | CUBIERTO | TC-002 | - |
| AEST-RAMA-002 | RAMA-062: @i_operacion='U' (enrutador UPDATE) | CUBIERTO | TC-006 | - |
| AEST-RAMA-003 | RAMA-153: @i_operacion='D' (enrutador DELETE) | CUBIERTO | TC-012 | - |
| AEST-RAMA-004 | RAMA-184: @i_operacion='E' (enrutador DELETE E) | CUBIERTO | TC-013 | - |
| AEST-RAMA-005 | RAMA-009: @t_trn=109 (rama TRUE INSERT) | CUBIERTO | TC-002 | - |
| AEST-RAMA-006 | RAMA-063: @t_trn=110 (rama TRUE UPDATE) | CUBIERTO | TC-006 | - |
| AEST-RAMA-007 | RAMA-154: @t_trn=1226 (rama TRUE DELETE) | CUBIERTO | TC-012 | - |
| AEST-RAMA-008 | RAMA-185: @t_trn=1226 (rama TRUE DELETE E) | CUBIERTO | TC-013 | - |
| AEST-RAMA-009 | RAMA-009 ELSE: @t_trn!=109 en INSERT | CUBIERTO | TC-003 | - |
| AEST-RAMA-010 | RAMA-063 ELSE: @t_trn!=110 en UPDATE | CUBIERTO | TC-007 | - |
| AEST-RAMA-011 | RAMA-154 ELSE: @t_trn!=1226 en DELETE | CUBIERTO | TC-008 | - |
| AEST-RAMA-012 | RAMA-185 ELSE: @t_trn!=1226 en DELETE E | CUBIERTO | TC-009 | - |
| AEST-RAMA-013 | RAMA-002: @i_ente=0 (rama TRUE) | CUBIERTO | TC-001 | - |
| AEST-RAMA-014 | RAMA-003: @@rowcount=0 tras SELECT cl_ente | CUBIERTO | TC-005 | - |
| AEST-RAMA-015 | RAMA-010: EXISTS cl_producto FALSE | CUBIERTO | TC-004 | - |
| AEST-RAMA-016 | RAMA-011: EXISTS cl_ciudad FALSE | CUBIERTO | TC-026 | - |
| AEST-RAMA-017 | RAMA-016: EXISTS cl_oficina FALSE | CUBIERTO | TC-027 | - |
| AEST-RAMA-018 | RAMA-017: @i_tipo not in (D,T,O) TRUE | CUBIERTO | TC-010 | - |
| AEST-RAMA-019 | RAMA-035: @i_verificado in (S,I,P) TRUE | CUBIERTO | TC-011 | - |
| AEST-RAMA-020 | RAMA-035 ELSE: @i_verificado not in (S,I,P) | CUBIERTO | TC-002 | - |
| AEST-RAMA-021 | RAMA-045: @i_envio_crp='S' TRUE | CUBIERTO | TC-030 | - |
| AEST-RAMA-022 | RAMA-048: @w_min_dir != 1 TRUE | CUBIERTO | TC-014 | - |
| AEST-RAMA-023 | RAMA-048 ELSE: @w_min_dir = 1 | CUBIERTO | TC-015 | - |
| AEST-RAMA-024 | RAMA-056: WHILE cursor_cuenta (INSERT) | PENDIENTE | - | Requiere cuentas de ahorro |
| AEST-RAMA-025 | RAMA-147: WHILE cursor_cuenta (UPDATE ahorros) | PENDIENTE | - | Requiere cuentas de ahorro |
| AEST-RAMA-026 | RAMA-148: WHILE cursor_ctacte1 (UPDATE cte) | PENDIENTE | - | Requiere cuentas corrientes |
| AEST-RAMA-027 | RAMA-181: WHILE telefonos (DELETE) | PENDIENTE | - | Requiere telefonos asociados |
| AEST-RAMA-028 | RAMA-193: WHILE telefonos (DELETE E) | PENDIENTE | - | Requiere telefonos asociados |
| AEST-RAMA-029 | RAMA-198: @i_mensaje='S' TRUE (sp_cerror) | CUBIERTO | TC-001 | - |
| AEST-RAMA-030 | RAMA-198 ELSE: @i_mensaje<>'S' (sp_msj_error) | CUBIERTO | TC-016 | - |
| AEST-RAMA-031 | RAMA-046: @@error!=0 en UPDATE envio CRP | CUBIERTO | TC-035 | - |
| AEST-RAMA-032 | RAMA-049: @@error!=0 en INSERT cl_direccion | CUBIERTO | TC-037 | - |
| AEST-RAMA-033 | RAMA-050: @@error!=0 en INSERT ts_direccion | CUBIERTO | TC-038 | - |
| AEST-RAMA-034 | RAMA-089: @@rowcount=0 en SELECT dir UPDATE | CUBIERTO | TC-017 | - |
| AEST-RAMA-035 | RAMA-156: @@rowcount=0 en SELECT dir DELETE | CUBIERTO | TC-018 | - |
| AEST-RAMA-036 | RAMA-187: @@rowcount=0 en SELECT dir DELETE E | CUBIERTO | TC-019 | - |
| AEST-RAMA-037 | RAMA-064: @i_verifdirec='S' TRUE | CUBIERTO | TC-020 | - |
| AEST-RAMA-038 | RAMA-088: @i_verificado in (P,S) TRUE | CUBIERTO | TC-021 | - |
| AEST-RAMA-039 | RAMA-115: @v_envio_crp='S' and @w_envio_crp='N' TRUE | CUBIERTO | TC-022 | - |
| AEST-RAMA-040 | RAMA-131: @v_varifica_presencial='N' and @i_ind_act_presenc='V' TRUE | CUBIERTO | TC-023 | - |
| AEST-RAMA-041 | RAMA-157: @e_actmasivacli='N' TRUE | CUBIERTO | TC-012 | - |
| AEST-RAMA-042 | RAMA-157 ELSE: @e_actmasivacli<>'N' | CUBIERTO | TC-024 | - |
| AEST-RAMA-043 | RAMA-158: count(*)=1 TRUE (unica direccion) | CUBIERTO | TC-025 | - |
| AEST-RAMA-044 | RAMA-159: @w_envio_crp='S' TRUE (no eliminar CRP) | PENDIENTE | - | Requiere direccion con envio CRP |
| AEST-RAMA-045 | RAMA-160: EXISTS cc_ctacte TRUE (no eliminar EC) | PENDIENTE | - | Requiere direccion asociada a cta cte |
| AEST-RAMA-046 | RAMA-161: EXISTS ECTC TRUE (no eliminar ECTC) | PENDIENTE | - | Requiere direccion asociada a ECTC |
| AEST-RAMA-047 | RAMA-162: @w_subtipo='P' and @w_tipo='D' TRUE | PENDIENTE | - | Requiere PN con direccion D |
| AEST-RAMA-048 | RAMA-163: EXISTS cl_direccion_email TRUE | PENDIENTE | - | Requiere movil asociado |
| AEST-RAMA-049 | RAMA-001: @t_debug='S' TRUE | PENDIENTE | - | Requiere debug activado |
| AEST-RAMA-050 | RAMA-021: @w_subtipo='P' TRUE (validacion PN) | CUBIERTO | TC-002 | - |
| AEST-RAMA-051 | RAMA-032: @w_subtipo='C' TRUE (validacion PJ) | PENDIENTE | - | Requiere ente PJ |
| AEST-RAMA-052 | RAMA-037: @i_no_cobis='S' TRUE | CUBIERTO | TC-013 | - |
| AEST-RAMA-053 | RAMA-121: @i_no_cobis='S' TRUE (UPDATE) | PENDIENTE | - | Requiere UPDATE con no_cobis |
| AEST-RAMA-054 | RAMA-164: @i_no_cobis='S' TRUE (DELETE) | PENDIENTE | - | Requiere DELETE con no_cobis |
| AEST-RAMA-055 | RAMA-191: @i_no_cobis='S' TRUE (DELETE E) | PENDIENTE | - | Requiere DELETE E con no_cobis |
| AEST-RAMA-056 | RAMA-123: @i_envio_notifica='N' TRUE | CUBIERTO | TC-016 | - |
| AEST-RAMA-057 | RAMA-130: @i_ind_act_presenc='V' TRUE | PENDIENTE | - | Requiere act presencial V |
| AEST-RAMA-058 | RAMA-132: @v_envio_crp='N' and @w_envio_crp='S' TRUE | PENDIENTE | - | Requiere cambio envio CRP |
| AEST-CENT-001 | No aplica - SP sin calculos monetarios | JUSTIFICADO | - | SP no contiene tipo MONEY, redondeo ni cuadre contable |

---

## TC-001: BVA - @i_ente frontera cero (RAMA-002 TRUE, RAMA-198 TRUE)

Objetivo: AEST-BVA-001, AEST-RAMA-013, AEST-RAMA-029 - Frontera BVA de @i_ente=0. Activa RAMA-002 (IF @i_ente=0) y RAMA-198 TRUE (@i_mensaje='S' -> sp_cerror).

Precondiciones:
- No se requieren precondiciones (la validacion ocurre antes de consultar BD)

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_ente=0`
      - fuente_valor=analisis
      - fuente_detalle=BVA: frontera cero para @i_ente (int). La condicion IF @i_ente = 0 (linea 374) captura este valor.
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT para activar el flujo
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion valido para INSERT

Resultado esperado funcional:
- Error: codigo 101042 ("No existe ente")
- RAMA-002 TRUE: @i_ente=0 -> select @w_num=101042, goto mensaje_error
- RAMA-198 TRUE: @i_mensaje='S' -> exec sp_cerror, return 1

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- Ninguna (la validacion L374-L380 ocurre antes de cualquier DML)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 0
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-002: BVA - @i_ente frontera justo arriba de cero (1) - INSERT exitoso

Objetivo: AEST-BVA-002, AEST-RAMA-001, AEST-RAMA-005, AEST-RAMA-020, AEST-RAMA-050 - @i_ente=1 (justo arriba de cero). Activa RAMA-008 (@i_operacion='I'), RAMA-009 (@t_trn=109), RAMA-035 ELSE (@i_verificado='N'), RAMA-021 (@w_subtipo='P').

Precondiciones:
- El ente @i_ente=1 debe existir en cobis..cl_ente con en_subtipo='P'
- El producto @i_producto=2 debe existir en cobis..cl_producto
- La ciudad, parroquia, oficina deben existir
- El tipo 'D' debe existir en catalogo cl_tdireccion
- El estado 'N' debe existir en catalogo cl_estado_ver_ref
- Consulta de verificacion:
```sql
SELECT en_ente, en_subtipo FROM cobis..cl_ente WHERE en_ente = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_ente=1`
      - fuente_valor=sybase_select
      - fuente_detalle=BVA: justo arriba de cero. SELECT TOP 1 en_ente FROM cobis..cl_ente WHERE en_subtipo='P' ORDER BY en_ente
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-008 TRUE
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-009 TRUE

Resultado esperado funcional:
- Retorno 0 (exito)
- RAMA-008 TRUE -> entra al bloque INSERT
- RAMA-009 TRUE -> ejecuta logica de insercion
- RAMA-035 ELSE (@i_verificado='N') -> asigna nulls a fecha_ver, usuario_ver
- @o_direccion retorna el secuencial asignado

Resultado esperado en BD:
- Se inserta en cl_direccion con di_ente=1, di_tipo='D'
- Se inserta en ts_direccion con clase='N'

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_tipo, di_verificado, di_fecha_registro
FROM cobis..cl_direccion
WHERE di_ente = 1
ORDER BY di_direccion DESC
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-003: BVA - @t_trn no correspondiente (0) en INSERT - RAMA-009 ELSE

Objetivo: AEST-BVA-010, AEST-RAMA-009 - @t_trn=0 no coincide con 109 en INSERT. Activa RAMA-009 ELSE (error 151051).

Precondiciones:
- El ente debe existir en cl_ente

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Entra al bloque INSERT
   - `@t_trn=0`
      - fuente_valor=analisis
      - fuente_detalle=BVA: frontera cero para @t_trn. No coincide con 109, activa RAMA-009 ELSE.

Resultado esperado funcional:
- Error: codigo 151051 ("No corresponde codigo de transaccion")
- RAMA-009 FALSE -> ELSE -> select @w_num=151051, goto mensaje_error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-004: BVA - @i_producto frontera maxima tinyint (255) - RAMA-010 FALSE

Objetivo: AEST-BVA-012, AEST-RAMA-015 - @i_producto=255 (maximo tinyint). Activa RAMA-010 FALSE (producto no existe).

Precondiciones:
- El ente debe existir en cl_ente
- El producto 255 no debe existir en cl_producto
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe FROM cobis..cl_producto WHERE pd_producto = 255
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_producto=255`
      - fuente_valor=analisis
      - fuente_detalle=BVA: valor maximo tinyint (255). Activa RAMA-010 FALSE -> error 101032.
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion

Resultado esperado funcional:
- Error: codigo 101032 ("No existe producto")
- RAMA-010: IF EXISTS(select 1 from cl_producto where pd_producto=255) -> FALSE
- ELSE -> select @w_num=101032, goto mensaje_error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-005: RAMA-003 TRUE - @@rowcount=0 tras SELECT cl_ente (ente inexistente)

Objetivo: AEST-RAMA-014 - Forzar @@rowcount=0 en el SELECT de cl_ente. Activa RAMA-003 TRUE.

Precondiciones:
- El ente 999999 no debe existir en cl_ente
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe FROM cobis..cl_ente WHERE en_ente = 999999
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_ente=999999`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Ente inexistente. El SELECT de cl_ente retorna @@rowcount=0, activa RAMA-003 TRUE.
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion

Resultado esperado funcional:
- Error: codigo 101042 ("No existe ente")
- RAMA-003: IF @@rowcount = 0 -> TRUE -> select @w_num=101042, goto mensaje_error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT (no encuentra fila)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 999999
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-006: BVA - @i_direccion frontera 1 en UPDATE - RAMA-062, RAMA-063 TRUE

Objetivo: AEST-BVA-005, AEST-BVA-008, AEST-RAMA-002, AEST-RAMA-006 - @i_direccion=1 (justo arriba de cero) en UPDATE. Activa RAMA-062 (@i_operacion='U'), RAMA-063 (@t_trn=110).

Precondiciones:
- El ente debe existir en cl_ente con en_subtipo='P'
- Debe existir direccion 1 para el ente en cl_direccion
- El producto, ciudad, parroquia, oficina deben existir
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_tipo
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-062 TRUE (enrutador UPDATE)
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=BVA: frontera 110 para UPDATE. Activa RAMA-063 TRUE.
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=BVA: justo arriba de cero para @i_direccion (tinyint)
   - `@i_descripcion='Calle Update BVA 111'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Cambio de descripcion

Resultado esperado funcional:
- Retorno 0 (exito)
- RAMA-062 TRUE -> entra al bloque UPDATE
- RAMA-063 TRUE -> ejecuta logica de actualizacion

Resultado esperado en BD:
- Se actualiza cl_direccion con nueva descripcion
- Se insertan 2 registros en ts_direccion (clase P y A)

Tablas afectadas:
- `cobis..cl_direccion` - UPDATE
- `cobis..ts_direccion` - INSERT (2 registros)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_fecha_modificacion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-007: RAMA-063 ELSE - @t_trn no correspondiente en UPDATE (109)

Objetivo: AEST-RAMA-010 - @t_trn=109 en UPDATE. Activa RAMA-063 ELSE (error 151051).

Precondiciones:
- El ente debe existir en cl_ente

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Entra al bloque UPDATE
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de INSERT, no coincide con 110. Activa RAMA-063 ELSE.

Resultado esperado funcional:
- Error: codigo 151051 ("No corresponde codigo de transaccion")
- RAMA-063: IF @t_trn = 110 -> FALSE -> ELSE -> error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-008: RAMA-154 ELSE - @t_trn no correspondiente en DELETE (110)

Objetivo: AEST-RAMA-011 - @t_trn=110 en DELETE. Activa RAMA-154 ELSE (error 151051).

Precondiciones:
- El ente debe existir en cl_ente

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Entra al bloque DELETE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de UPDATE, no coincide con 1226. Activa RAMA-154 ELSE.
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Error: codigo 151051 ("No corresponde codigo de transaccion")
- RAMA-154: IF @t_trn = 1226 -> FALSE -> ELSE -> error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-009: RAMA-185 ELSE - @t_trn no correspondiente en DELETE E (110)

Objetivo: AEST-RAMA-012 - @t_trn=110 en DELETE E. Activa RAMA-185 ELSE (error 151051).

Precondiciones:
- El ente debe existir en cl_ente

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='E'`
      - fuente_valor=analisis
      - fuente_detalle=Entra al bloque DELETE E
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de UPDATE, no coincide con 1226. Activa RAMA-185 ELSE.
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Error: codigo 151051 ("No corresponde codigo de transaccion")
- RAMA-185: IF @t_trn = 1226 -> FALSE -> ELSE -> error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-010: RAMA-017 TRUE - @i_tipo no es D, T ni O

Objetivo: AEST-RAMA-018 - @i_tipo='X' activa RAMA-017 TRUE (error 101627).

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_tipo='X'`
      - fuente_valor=analisis
      - fuente_detalle=Valor fuera del conjunto {D,T,O}. Activa RAMA-017 TRUE.
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion

Resultado esperado funcional:
- Error: codigo 101627 ("TIPO DIRECCION SOLO PUEDE SER D T O")
- RAMA-017: IF (@i_tipo <> 'D' AND @i_tipo <> 'T' AND @i_tipo <> 'O') -> TRUE

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-011: RAMA-035 TRUE - @i_verificado='S' activa calculo de vigencia

Objetivo: AEST-RAMA-019 - @i_verificado='S' activa RAMA-035 TRUE (calculo de vigencia con TPVGRE).

Precondiciones:
- Mismas precondiciones que TC-002
- El parametro TPVGRE debe existir en cl_parametro
- Consulta de verificacion:
```sql
SELECT pa_producto, pa_nemonico, pa_smallint
FROM cobis..cl_parametro
WHERE pa_producto = 'MIS' AND pa_nemonico = 'TPVGRE'
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_verificado='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-035 TRUE: @i_verificado in ('S','I','P')
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_descripcion='Calle Vigencia BVA 222'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Retorno 0 (exito)
- RAMA-035 TRUE: calcula @w_tiempo_vigencia desde cl_parametro, asigna @i_fecha_ver=@s_date, @i_vigencia='S', @i_fecha_caducidad=dateadd(dd,@w_tiempo_vigencia,@s_date)

Resultado esperado en BD:
- Se inserta en cl_direccion con di_verificado='S', di_vigencia='S', di_fecha_ver=@s_date

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_verificado, di_vigencia, di_fecha_ver, di_fecha_caducidad
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_verificado = 'S'
ORDER BY di_direccion DESC
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-012: BVA - @t_trn frontera 1226 en DELETE - RAMA-153, RAMA-154 TRUE

Objetivo: AEST-BVA-009, AEST-RAMA-003, AEST-RAMA-007, AEST-RAMA-041 - @t_trn=1226 en DELETE. Activa RAMA-153 (@i_operacion='D'), RAMA-154 (@t_trn=1226), RAMA-157 (@e_actmasivacli='N').

Precondiciones:
- El ente debe existir en cl_ente
- El ente debe tener al menos 2 direcciones
- La direccion a eliminar no debe ser envio CRP, no asociada a cuentas
- @e_actmasivacli='N'
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_tipo, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 1
ORDER BY di_direccion
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-153 TRUE (enrutador DELETE)
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=BVA: frontera 1226 para DELETE. Activa RAMA-154 TRUE.
   - `@i_direccion=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Segunda direccion del ente (no la unica)
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Retorno 0 (exito)
- RAMA-153 TRUE -> entra al bloque DELETE
- RAMA-154 TRUE -> ejecuta logica de eliminacion
- RAMA-157 TRUE (@e_actmasivacli='N') -> aplica validaciones

Resultado esperado en BD:
- Se elimina el registro de cl_direccion
- Se inserta en ts_direccion, historicos y log

Tablas afectadas:
- `cobis..cl_direccion` - DELETE
- `cobis..ts_direccion` - INSERT
- `cl_log_dir_envio_ec` - INSERT
- `cobis_his..cl_direccion_his` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 2
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-013: RAMA-184 TRUE, RAMA-185 TRUE - DELETE E exitoso con @i_no_cobis='S'

Objetivo: AEST-RAMA-004, AEST-RAMA-008, AEST-RAMA-052 - @i_operacion='E' con @t_trn=1226 y @i_no_cobis='S'. Activa RAMA-184, RAMA-185, RAMA-191.

Precondiciones:
- El ente debe existir en cl_ente
- Debe existir la direccion en cl_direccion
- El producto debe existir
- Debe existir al menos un registro en cl_direccion_tmp con di_estado <> 'E'
- sp_gen_sec debe estar disponible
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_tipo
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='E'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-184 TRUE (enrutador DELETE E)
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-185 TRUE
   - `@i_no_cobis='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-191 TRUE: genera secuencial via sp_gen_sec
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion a eliminar
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Retorno 0 (exito)
- RAMA-184 TRUE -> entra al bloque DELETE E
- RAMA-185 TRUE -> ejecuta logica
- RAMA-191 TRUE -> exec sp_gen_sec

Resultado esperado en BD:
- Se eliminan telefonos y direccion
- Se inserta en ts_direccion

Tablas afectadas:
- `cobis..cl_direccion` - DELETE
- `cobis..ts_direccion` - INSERT
- `cobis..cl_telefono` - DELETE (via sp_telefono)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-014: RAMA-048 TRUE - @w_min_dir != 1 (secuencial no empieza en 1)

Objetivo: AEST-RAMA-022 - Forzar @w_min_dir != 1 para que @o_direccion = 1. El SP asigna @o_direccion=1 cuando el minimo no es 1.

Precondiciones:
- El ente debe existir en cl_ente
- El ente NO debe tener direccion 1 (la primera direccion debe ser >1 o no existir)
- Si no tiene direcciones, @w_min_dir sera NULL, que es != 1
- Consulta de verificacion:
```sql
SELECT MIN(di_direccion) as min_dir, MAX(di_direccion) as max_dir
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_descripcion='Calle MinDir BVA 333'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Retorno 0 (exito)
- RAMA-048: IF @w_min_dir != 1 -> TRUE (si no hay direcciones, min es NULL != 1)
- @o_direccion = 1

Resultado esperado en BD:
- Se inserta en cl_direccion con @o_direccion=1
- Se inserta en ts_direccion

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-015: RAMA-048 ELSE - @w_min_dir = 1 (secuencial = max + 1)

Objetivo: AEST-RAMA-023 - Cuando @w_min_dir = 1, @o_direccion = @w_max_dir + 1.

Precondiciones:
- El ente debe existir en cl_ente
- El ente debe tener al menos 1 direccion, y la minima debe ser 1
- Consulta de verificacion:
```sql
SELECT MIN(di_direccion) as min_dir, MAX(di_direccion) as max_dir
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_descripcion='Calle MaxDir BVA 444'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Retorno 0 (exito)
- RAMA-048: IF @w_min_dir != 1 -> FALSE -> ELSE -> @o_direccion = @w_max_dir + 1

Resultado esperado en BD:
- Se inserta en cl_direccion con @o_direccion = max_dir + 1
- Se inserta en ts_direccion

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, MAX(di_direccion) as max_dir
FROM cobis..cl_direccion
WHERE di_ente = 1
GROUP BY di_ente
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-016: RAMA-198 ELSE, RAMA-123 TRUE - @i_mensaje='N' (sp_msj_error) con @i_envio_notifica='N'

Objetivo: AEST-RAMA-030, AEST-RAMA-056 - @i_mensaje='N' activa RAMA-198 ELSE (sp_msj_error en vez de sp_cerror). @i_envio_notifica='N' activa RAMA-123 TRUE.

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_mensaje='N'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-198 ELSE: exec sp_msj_error en vez de sp_cerror
   - `@i_envio_notifica='N'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-123 TRUE: suprime notificacion
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_descripcion='Calle NoMsg BVA 555'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Retorno 0 (exito)
- En caso de error, RAMA-198 ELSE ejecuta sp_msj_error (retorna @w_num, no 1)
- RAMA-123 TRUE: @i_envio_notifica='N' -> @w_envio_notifica = 'N'

Resultado esperado en BD:
- Se inserta en cl_direccion y ts_direccion
- No se obtiene email ni celular
- No se invoca sp_notif_cli_mod_dir

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_fecha_registro
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_descripcion = 'Calle NoMsg BVA 555'
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-017: RAMA-089 TRUE - @@rowcount=0 en SELECT de direccion para UPDATE

Objetivo: AEST-RAMA-034 - UPDATE con @i_direccion inexistente. El SELECT de cl_direccion retorna @@rowcount=0, activa RAMA-089 TRUE.

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir
- La direccion 99 no debe existir para el ente
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 99
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_direccion=99`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Direccion inexistente. Activa RAMA-089 TRUE (@@rowcount=0).

Resultado esperado funcional:
- Error: codigo 101059 ("No existe direccion")
- RAMA-089: IF @@rowcount = 0 -> TRUE -> select @w_num=101059, goto mensaje_error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT
- `cobis..cl_direccion` - SELECT (no encuentra fila)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-018: RAMA-156 TRUE - @@rowcount=0 en SELECT de direccion para DELETE

Objetivo: AEST-RAMA-035 - DELETE con @i_direccion inexistente. El SELECT de cl_direccion retorna @@rowcount=0, activa RAMA-156 TRUE.

Precondiciones:
- El ente debe existir en cl_ente
- El producto debe existir
- La direccion 99 no debe existir para el ente
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 99
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_direccion=99`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Direccion inexistente. Activa RAMA-156 TRUE (@@rowcount=0).
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Error: codigo 101001 ("No existe dato solicitado")
- RAMA-156: IF @@rowcount = 0 -> TRUE -> select @w_num=101001, goto mensaje_error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_direccion` - SELECT (no encuentra fila)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-019: RAMA-187 TRUE - @@rowcount=0 en SELECT de direccion para DELETE E

Objetivo: AEST-RAMA-036 - DELETE E con @i_direccion inexistente. El SELECT de cl_direccion retorna @@rowcount=0, activa RAMA-187 TRUE.

Precondiciones:
- El ente debe existir en cl_ente
- El producto debe existir
- La direccion 99 no debe existir para el ente
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 99
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='E'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion DELETE E
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_direccion=99`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Direccion inexistente. Activa RAMA-187 TRUE (@@rowcount=0).
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Error: codigo 101001 ("No existe dato solicitado")
- RAMA-187: IF @@rowcount = 0 -> TRUE -> select @w_num=101001, goto mensaje_error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_direccion` - SELECT (no encuentra fila)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-020: RAMA-064 TRUE - @i_verifdirec='S' en UPDATE (verificacion EC)

Objetivo: AEST-RAMA-037 - UPDATE con @i_verifdirec='S'. Activa RAMA-064 TRUE que verifica si la direccion esta asociada a EC.

Precondiciones:
- El ente debe existir en cl_ente
- Debe existir una direccion para el ente
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_tipo
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_verifdirec='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-064 TRUE: verificacion de direccion asociada a EC
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion a verificar

Resultado esperado funcional:
- Retorno 0 (exito)
- RAMA-064 TRUE: verifica si la direccion esta asociada a cc_ctacte o ECTC
- Si no esta asociada, retorna 'N' y hace return 0 inmediato (sin ejecutar UPDATE)

Resultado esperado en BD:
- No se realiza UPDATE en cl_direccion (return 0 antes del UPDATE)
- No se inserta en ts_direccion

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cob_cuentas..cc_ctacte` - SELECT (si aplica)
- `cl_dir_envio_tarj_cred` - SELECT (si aplica)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_fecha_modificacion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-021: RAMA-088 TRUE - @i_verificado='P' en UPDATE (limpia tipo_verif_incns)

Objetivo: AEST-RAMA-038 - UPDATE con @i_verificado='P'. Activa RAMA-088 TRUE que fuerza @i_tipo_verif_incns=null.

Precondiciones:
- Mismas precondiciones que TC-006
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_verificado, di_tipo_verif_incns
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_verificado='P'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-088 TRUE: (@i_verificado='P' or @i_verificado='S') -> @i_tipo_verif_incns=null
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente

Resultado esperado funcional:
- Retorno 0 (exito)
- RAMA-088 TRUE: IF ((@i_verificado = 'P') or (@i_verificado = 'S')) -> select @i_tipo_verif_incns = null

Resultado esperado en BD:
- Se actualiza cl_direccion con di_verificado='P', di_tipo_verif_incns=null
- Se insertan 2 registros en ts_direccion

Tablas afectadas:
- `cobis..cl_direccion` - UPDATE
- `cobis..ts_direccion` - INSERT (2 registros)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_verificado, di_tipo_verif_incns
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-022: RAMA-115 TRUE - No desmarcar envio CRP en UPDATE

Objetivo: AEST-RAMA-039 - UPDATE que intenta cambiar @i_envio_crp de 'S' a 'N'. Activa RAMA-115 TRUE (error 101281).

Precondiciones:
- El ente debe existir en cl_ente
- Debe existir una direccion con di_envio_crp='S'
- El producto, ciudad, parroquia, oficina deben existir
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_envio_crp = 'S'
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_envio_crp='N'`
      - fuente_valor=analisis
      - fuente_detalle=Intento de desmarcar. Activa RAMA-115 TRUE: @v_envio_crp='S' and @w_envio_crp='N'.
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion con di_envio_crp='S'

Resultado esperado funcional:
- Error: codigo 101281 ("NO SE PUEDE DESMARCAR LA DIRECCION DE ENVIO DE CORRESPONDENCIA")
- RAMA-115: IF @v_envio_crp = 'S' and @w_envio_crp = 'N' -> TRUE

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT
- `cobis..cl_direccion` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-023: RAMA-131 TRUE - Validacion actualizacion presencial

Objetivo: AEST-RAMA-040 - UPDATE con @i_ind_act_presenc='V' y cambio no presencial. Activa RAMA-131 TRUE (error 105109).

Precondiciones:
- El ente debe existir en cl_ente
- Debe existir una direccion para el ente
- El producto, ciudad, parroquia, oficina deben existir
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_ind_act_presenc='V'`
      - fuente_valor=analisis
      - fuente_detalle=Actualizacion presencial requerida
   - `@i_descripcion='Cambio No Presencial Estructural'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Cambio que activa @v_varifica_presencial='N'
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente

Resultado esperado funcional:
- Error: codigo 105109
- RAMA-131: IF @v_varifica_presencial = 'N' and @i_ind_act_presenc = 'V' -> TRUE

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT
- `cobis..cl_direccion` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-024: RAMA-157 ELSE - @e_actmasivacli<>'N' omite validaciones en DELETE

Objetivo: AEST-RAMA-042 - DELETE con @e_actmasivacli='S'. Activa RAMA-157 ELSE (omite validaciones RN-39 a RN-43).

Precondiciones:
- El ente debe existir en cl_ente
- El producto debe existir
- La direccion debe existir
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 1
ORDER BY di_direccion
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@e_actmasivacli='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-157 ELSE: omite validaciones de eliminacion
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion a eliminar (puede ser la unica, envio CRP, etc.)
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Retorno 0 (exito)
- RAMA-157: IF @e_actmasivacli = 'N' -> FALSE -> ELSE -> omite validaciones

Resultado esperado en BD:
- Se elimina el registro sin validar restricciones
- Se inserta en ts_direccion, historicos y log

Tablas afectadas:
- `cobis..cl_direccion` - DELETE
- `cobis..ts_direccion` - INSERT
- `cl_log_dir_envio_ec` - INSERT
- `cobis_his..cl_direccion_his` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-025: RAMA-158 TRUE - No eliminar la unica direccion (count=1)

Objetivo: AEST-RAMA-043 - DELETE cuando el ente tiene exactamente 1 direccion. Activa RAMA-158 TRUE (error 101053).

Precondiciones:
- El ente debe existir en cl_ente
- El ente debe tener exactamente 1 direccion
- @e_actmasivacli='N'
- Consulta de verificacion:
```sql
SELECT di_ente, COUNT(1) as total_dir
FROM cobis..cl_direccion
WHERE di_ente = 1
GROUP BY di_ente
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Unica direccion del ente
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Error: codigo 101053 ("No se puede eliminar todas las direcciones")
- RAMA-158: IF (select count(1) from cl_direccion where di_ente=@i_ente) = 1 -> TRUE

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_direccion` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

---

## TC-026: BVA - @i_ciudad frontera cero (0) - RAMA-011 FALSE

Objetivo: AEST-BVA-013, AEST-RAMA-016 - @i_ciudad=0 no existe en cl_ciudad. Activa RAMA-011 FALSE (error 101024).

Precondiciones:
- El ente debe existir en cl_ente
- El producto debe existir
- La ciudad 0 no debe existir en cl_ciudad
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe FROM cobis..cl_ciudad WHERE ci_ciudad = 0
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_ciudad=0`
      - fuente_valor=analisis
      - fuente_detalle=BVA: frontera cero para @i_ciudad (smallint). Activa RAMA-011 FALSE.
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion

Resultado esperado funcional:
- Error: codigo 101024 ("No existe ciudad")
- RAMA-011: IF EXISTS(select 1 from cl_ciudad where ci_ciudad=0) -> FALSE -> ELSE -> error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT (no encuentra fila)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-027: BVA - @i_oficina frontera cero (0) - RAMA-016 FALSE

Objetivo: AEST-BVA-014, AEST-RAMA-017 - @i_oficina=0 no existe en cl_oficina. Activa RAMA-016 FALSE (error 101016).

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia deben existir
- La oficina 0 no debe existir en cl_oficina
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe FROM cobis..cl_oficina WHERE of_oficina = 0
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_oficina=0`
      - fuente_valor=analisis
      - fuente_detalle=BVA: frontera cero para @i_oficina (smallint). Activa RAMA-016 FALSE.
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion

Resultado esperado funcional:
- Error: codigo 101016 ("No existe oficina")
- RAMA-016: IF EXISTS(select 1 from cl_oficina where of_oficina=0) -> FALSE -> ELSE -> error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT (no encuentra fila)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-028: BVA - @i_parroquia frontera cero (0) - RAMA-012 FALSE

Objetivo: AEST-BVA-015 - @i_parroquia=0 no existe en cl_parroquia para la ciudad. Activa RAMA-012 FALSE (error 101037).

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad deben existir
- La parroquia 0 no debe existir para la ciudad 1
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe FROM cobis..cl_parroquia WHERE pq_ciudad = 1 AND pq_parroquia = 0
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_parroquia=0`
      - fuente_valor=analisis
      - fuente_detalle=BVA: frontera cero para @i_parroquia (smallint). Activa RAMA-012 FALSE.
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion

Resultado esperado funcional:
- Error: codigo 101037 ("No existe parroquia")
- RAMA-012: IF EXISTS(select 1 from cl_parroquia where pq_ciudad=1 and pq_parroquia=0) -> FALSE -> ELSE -> error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT (no encuentra fila)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-029: BVA - @i_producto frontera cero (0) - RAMA-010 FALSE

Objetivo: AEST-BVA-011 - @i_producto=0 no existe en cl_producto. Activa RAMA-010 FALSE (error 101032).

Precondiciones:
- El ente debe existir en cl_ente
- El producto 0 no debe existir en cl_producto
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe FROM cobis..cl_producto WHERE pd_producto = 0
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_producto=0`
      - fuente_valor=analisis
      - fuente_detalle=BVA: frontera cero para @i_producto (tinyint). Activa RAMA-010 FALSE.
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion

Resultado esperado funcional:
- Error: codigo 101032 ("No existe producto")
- RAMA-010: IF EXISTS(select 1 from cl_producto where pd_producto=0) -> FALSE -> ELSE -> error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT (no encuentra fila)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-030: RAMA-019 TRUE - @i_envio_crp valor invalido (no N ni S)

Objetivo: AEST-RAMA-021 - @i_envio_crp='X' activa RAMA-019 TRUE (error 101114). Cubre la rama de validacion de envio CRP.

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir
- El tipo 'D' debe existir en catalogo cl_tdireccion

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_envio_crp='X'`
      - fuente_valor=analisis
      - fuente_detalle=Valor fuera de {N,S}. Activa RAMA-019 TRUE: @i_envio_crp not in ('N','S').
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion

Resultado esperado funcional:
- Error: codigo 101114 ("Parametro invalido")
- RAMA-019: IF @i_envio_crp not in ('N', 'S') -> TRUE -> error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-031: RAMA-018 TRUE - sp_catalogo retorna error para tipo direccion

Objetivo: AEST-RAMA-018 - Forzar que sp_catalogo retorne !=0 para @i_tipo. Activa RAMA-018 TRUE (error 101025).

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir
- El tipo 'D' debe ser valido (D/T/O)
- sp_catalogo debe retornar !=0 (simulado)

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_tipo='Z'`
      - fuente_valor=analisis
      - fuente_detalle=Tipo que pasa validacion D/T/O pero no existe en catalogo cl_tdireccion. Activa RAMA-018 TRUE: @w_return != 0.
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion

Resultado esperado funcional:
- Error: codigo 101025 ("No existe tipo de direccion")
- RAMA-017 FALSE (@i_tipo pasa D/T/O) -> RAMA-018 TRUE (sp_catalogo retorna !=0)

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-032: RAMA-020 TRUE - sp_catalogo retorna error para estado verificado

Objetivo: AEST-RAMA-020 - Forzar que sp_catalogo retorne !=0 para @i_verificado. Activa RAMA-020 TRUE (error 101563).

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir
- El tipo 'D' debe existir en catalogo
- @i_envio_crp debe ser 'N' o 'S'
- @i_verificado='Z' no debe existir en catalogo cl_estado_ver_ref

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_verificado='Z'`
      - fuente_valor=analisis
      - fuente_detalle=Estado que no existe en catalogo cl_estado_ver_ref. Activa RAMA-020 TRUE: @w_return != 0.
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion

Resultado esperado funcional:
- Error: codigo 101563 ("Parametro Invalido")
- RAMA-020: IF @w_return != 0 -> TRUE -> error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-033: RAMA-036 TRUE - @@rowcount=0 en SELECT cl_parametro TPVGRE

Objetivo: AEST-RAMA-036 - Forzar que el parametro TPVGRE no exista. Activa RAMA-036 TRUE (error 101077).

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir
- El tipo 'D' debe existir en catalogo
- @i_verificado='S' (activa busqueda de TPVGRE)
- El parametro TPVGRE no debe existir en cl_parametro (o usar pa_producto que no exista)

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_verificado='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-035 TRUE que busca TPVGRE en cl_parametro
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion

Resultado esperado funcional:
- Si TPVGRE no existe: Error codigo 101077 ("No existe parametro")
- RAMA-035 TRUE -> SELECT de cl_parametro -> RAMA-036: IF @@rowcount = 0 -> TRUE -> error
- Si TPVGRE existe: Retorno 0 con vigencia calculada

Resultado esperado en BD:
- Si TPVGRE no existe: no se modifica BD
- Si TPVGRE existe: se inserta en cl_direccion con vigencia

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_parametro` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT pa_producto, pa_nemonico, pa_smallint
FROM cobis..cl_parametro
WHERE pa_producto = 'MIS' AND pa_nemonico = 'TPVGRE'
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-034: RAMA-038 TRUE - sp_gen_sec retorna error en INSERT

Objetivo: AEST-RAMA-038 - Forzar que sp_gen_sec retorne !=0. Activa RAMA-038 TRUE (error 103005).

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir
- @i_no_cobis='S' (activa generacion de secuencial)
- sp_gen_sec debe estar disponible (el error depende del ambiente)

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_no_cobis='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-037 TRUE que ejecuta sp_gen_sec
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion

Resultado esperado funcional:
- Si sp_gen_sec retorna !=0: Error codigo 103005 ("Error en creacion de transaccion de servicio")
- RAMA-037 TRUE -> exec sp_gen_sec -> RAMA-038: IF @w_return != 0 -> TRUE -> error
- Si sp_gen_sec retorna 0: continua con la insercion

Resultado esperado en BD:
- Si sp_gen_sec falla: no se modifica BD
- Si sp_gen_sec ok: se inserta en cl_direccion y ts_direccion

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_direccion` - INSERT (si sp_gen_sec ok)
- `cobis..ts_direccion` - INSERT (si sp_gen_sec ok)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-035: RAMA-046 TRUE - @@error!=0 en UPDATE de envio CRP (INSERT)

Objetivo: AEST-RAMA-031 - Rama de manejo de @@error en UPDATE de cl_direccion para desmarcar envio CRP anterior.

Precondiciones:
- El ente debe existir en cl_ente
- Debe existir otra direccion con di_envio_crp='S' para el ente
- @i_envio_crp='S'
- El producto, ciudad, parroquia, oficina deben existir
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_envio_crp = 'S'
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_envio_crp='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-045 TRUE que ejecuta UPDATE para desmarcar CRP anterior
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_descripcion='Calle CRP Error 666'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Si @@error != 0 en el UPDATE de desmarque: Error codigo 105034 ("Error en actualizacion de direccion")
- RAMA-045 TRUE -> UPDATE cl_direccion set di_envio_crp='N' -> RAMA-046: IF @@error != 0 -> TRUE -> error
- Si no hay error: continua con la insercion

Resultado esperado en BD:
- Si @@error: no se modifica BD (ROLLBACK implicito por goto mensaje_error)
- Si ok: se desmarca CRP anterior y se inserta nueva direccion

Tablas afectadas:
- `cobis..cl_direccion` - UPDATE, INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 1
ORDER BY di_direccion DESC
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-036: RAMA-047 TRUE - @@error!=0 en SELECT min/max de direccion

Objetivo: AEST-RAMA-047 - Rama de manejo de @@error en SELECT min/max di_direccion.

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir
- @i_envio_crp='S' (para que pase por el UPDATE de desmarque)

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_envio_crp='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa flujo que incluye SELECT min/max de cl_direccion
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_descripcion='Calle MinMax Error 777'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Si @@error != 0 en SELECT min/max: Error codigo 105034
- RAMA-047: IF @@error != 0 -> TRUE -> error
- Si no hay error: calcula @o_direccion normalmente

Resultado esperado en BD:
- Si @@error: no se modifica BD
- Si ok: se inserta nueva direccion

Tablas afectadas:
- `cobis..cl_direccion` - SELECT, UPDATE, INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 1
ORDER BY di_direccion DESC
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-037: RAMA-049 TRUE - @@error!=0 en INSERT cl_direccion

Objetivo: AEST-RAMA-032 - Rama de manejo de @@error en INSERT a cl_direccion.

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir
- El tipo 'D' debe existir en catalogo

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_descripcion='Calle Insert Error 888'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Si @@error != 0 en INSERT cl_direccion: Error codigo 103007 ("Error en creacion de direccion")
- RAMA-049: IF @@error != 0 -> TRUE -> error
- Si no hay error: continua con INSERT ts_direccion

Resultado esperado en BD:
- Si @@error: no se modifica BD (la transaccion se revierte)
- Si ok: se inserta en cl_direccion y ts_direccion

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_descripcion = 'Calle Insert Error 888'
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-038: RAMA-050 TRUE - @@error!=0 en INSERT ts_direccion

Objetivo: AEST-RAMA-033 - Rama de manejo de @@error en INSERT a ts_direccion.

Precondiciones:
- Mismas precondiciones que TC-037

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_descripcion='Calle TS Error 999'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Si @@error != 0 en INSERT ts_direccion: Error codigo 103005 ("Error en creacion de transaccion de servicio")
- RAMA-050: IF @@error != 0 -> TRUE -> error
- Si no hay error: continua con commit

Resultado esperado en BD:
- Si @@error: ROLLBACK de toda la transaccion
- Si ok: ambos INSERT persisten

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_descripcion = 'Calle TS Error 999'
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-039: RAMA-052 TRUE - @@error!=0 en INSERT cl_vr_solicitud_log

Objetivo: AEST-RAMA-052 - Rama de manejo de @@error en INSERT a cl_vr_solicitud_log (vreferen).

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir
- @i_vreferen='S', @i_observacion no null
- sp_cseqnos debe estar disponible

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_vreferen='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-051 TRUE que inserta en cl_vr_solicitud_log
   - `@i_observacion='Observacion vreferen test'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Observacion no null para activar RAMA-051
   - `@i_solicitud=1`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Numero de solicitud
   - `@i_anio=2026`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Anio de solicitud
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_descripcion='Calle Vreferen 123'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Si @@error != 0 en INSERT cl_vr_solicitud_log: Error codigo 101696
- RAMA-051 TRUE -> INSERT cl_vr_solicitud_log -> RAMA-052: IF @@error != 0 -> TRUE -> error
- Si no hay error: continua

Resultado esperado en BD:
- Si @@error: ROLLBACK
- Si ok: se inserta en cl_direccion, ts_direccion y cl_vr_solicitud_log

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT
- `cl_vr_solicitud_log` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT sl_secuencial, sl_solicitud, sl_anio, sl_cliente, sl_tipo_reg
FROM cl_vr_solicitud_log
WHERE sl_solicitud = 1 AND sl_anio = 2026
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-040: RAMA-054 TRUE - @@error!=0 en INSERT cl_log_dir_envio_ec (INSERT)

Objetivo: AEST-RAMA-054 - Rama de manejo de @@error en INSERT a cl_log_dir_envio_ec durante INSERT.

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir
- La direccion no debe ser del mismo tipo que la asociada a ECTC (para que @w_tipo_accion no sea '')
- Consulta de verificacion:
```sql
SELECT dt_ente, dt_tipo_direc_envio FROM cl_dir_envio_tarj_cred WHERE dt_ente = 1
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_tipo='O'`
      - fuente_valor=analisis
      - fuente_detalle=Tipo Otro - menos probable que este asociado a ECTC
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_descripcion='Calle LogEC Error 444'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Si @@error != 0 en INSERT cl_log_dir_envio_ec: Error codigo 101613
- RAMA-053 FALSE (no existe ECTC del mismo tipo) -> INSERT cl_log_dir_envio_ec -> RAMA-054: IF @@error != 0 -> TRUE -> error
- Si no hay error: continua

Resultado esperado en BD:
- Si @@error: ROLLBACK
- Si ok: se inserta en cl_direccion, ts_direccion y cl_log_dir_envio_ec

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT
- `cl_log_dir_envio_ec` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT ld_fecha, ld_ente, ld_tipo_accion, ld_tipo_dir_act
FROM cl_log_dir_envio_ec
WHERE ld_ente = 1
ORDER BY ld_fecha DESC
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-041: RAMA-059 TRUE - sp_notif_cli_mod_dir retorna error en INSERT

Objetivo: AEST-RAMA-059 - Rama de manejo de error cuando sp_notif_cli_mod_dir retorna !=0 en INSERT.

Precondiciones:
- El ente debe existir en cl_ente con en_subtipo='P'
- @i_envio_notifica='S'
- @w_fecha_reg > @w_fecha_crea_cli
- El producto, ciudad, parroquia, oficina deben existir
- sp_notif_cli_mod_dir debe existir

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_envio_notifica='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-057 TRUE que invoca sp_notif_cli_mod_dir
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_descripcion='Calle Notif Error 555'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Si sp_notif_cli_mod_dir retorna !=0: Error con codigo @w_return
- RAMA-057 TRUE -> exec sp_notif_cli_mod_dir -> RAMA-059: IF @w_return != 0 -> TRUE -> error
- Si retorna 0: continua con commit

Resultado esperado en BD:
- Si error en notificacion: ROLLBACK de toda la transaccion
- Si ok: commit con insercion y notificacion

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_descripcion = 'Calle Notif Error 555'
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-042: RAMA-060 TRUE - @t_file='ccreacli.s' suprime SELECT de @o_direccion

Objetivo: AEST-RAMA-060 - Cuando @t_file='ccreacli.s', el SP no emite SELECT @o_direccion.

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir

Datos de entrada:
- parametros_bajo_prueba:
   - `@t_file='ccreacli.s'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-060 FALSE: suprime SELECT @o_direccion
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_descripcion='Calle ccreacli 666'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Retorno 0 (exito)
- RAMA-060: IF @t_file!='ccreacli.s' -> FALSE -> no emite SELECT @o_direccion
- La direccion se inserta pero no se retorna @o_direccion en el resultset

Resultado esperado en BD:
- Se inserta en cl_direccion y ts_direccion normalmente

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_descripcion = 'Calle ccreacli 666'
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-043: RAMA-076 TRUE - @i_envio_crp invalido en UPDATE

Objetivo: AEST-RAMA-076 - UPDATE con @i_envio_crp='X'. Activa RAMA-076 TRUE (error 101114).

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir
- El tipo 'D' debe existir en catalogo

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_envio_crp='X'`
      - fuente_valor=analisis
      - fuente_detalle=Valor invalido. Activa RAMA-076 TRUE: @i_envio_crp not in ('S','N').

Resultado esperado funcional:
- Error: codigo 101114 ("Parametro Invalido")
- RAMA-076: IF @i_envio_crp not in ('S', 'N') -> TRUE -> error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-044: RAMA-077 TRUE - sp_catalogo error en estado verificado (UPDATE)

Objetivo: AEST-RAMA-077 - UPDATE con @i_verificado invalido en catalogo. Activa RAMA-077 TRUE.

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir
- El tipo 'D' debe existir en catalogo
- @i_envio_crp debe ser 'N' o 'S'

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_verificado='Z'`
      - fuente_valor=analisis
      - fuente_detalle=Estado no existe en catalogo. Activa RAMA-077 TRUE.

Resultado esperado funcional:
- Error: codigo 101563 ("Parametro Invalido")
- RAMA-077: IF @w_return != 0 -> TRUE -> error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-045: RAMA-106 TRUE - @@rowcount=0 en SELECT cl_parametro TPVGRE (UPDATE)

Objetivo: AEST-RAMA-106 - UPDATE con @i_verificado='S' y TPVGRE inexistente. Activa RAMA-106 TRUE.

Precondiciones:
- El ente debe existir en cl_ente
- Debe existir una direccion para el ente
- El producto, ciudad, parroquia, oficina deben existir
- @i_verificado='S' (activa busqueda TPVGRE)

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_verificado='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-105 TRUE que busca TPVGRE
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente

Resultado esperado funcional:
- Si TPVGRE no existe: Error codigo 101077 ("No existe parametro")
- RAMA-105 TRUE -> SELECT cl_parametro -> RAMA-106: IF @@rowcount = 0 -> TRUE -> error
- Si TPVGRE existe: Retorno 0 con vigencia actualizada

Resultado esperado en BD:
- Si TPVGRE no existe: no se modifica BD
- Si TPVGRE existe: se actualiza direccion con vigencia

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_parametro` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT pa_producto, pa_nemonico, pa_smallint
FROM cobis..cl_parametro
WHERE pa_producto = 'MIS' AND pa_nemonico = 'TPVGRE'
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-046: RAMA-122 TRUE - sp_gen_sec error en UPDATE

Objetivo: AEST-RAMA-053 - UPDATE con @i_no_cobis='S' y sp_gen_sec retorna error. Activa RAMA-122 TRUE.

Precondiciones:
- El ente debe existir en cl_ente
- Debe existir una direccion para el ente
- El producto, ciudad, parroquia, oficina deben existir
- @i_no_cobis='S'

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_no_cobis='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-121 TRUE que ejecuta sp_gen_sec
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente

Resultado esperado funcional:
- Si sp_gen_sec retorna !=0: Error codigo 103005
- RAMA-121 TRUE -> exec sp_gen_sec -> RAMA-122: IF @w_return != 0 -> TRUE -> error
- Si retorna 0: continua con UPDATE

Resultado esperado en BD:
- Si error: no se modifica BD
- Si ok: se actualiza direccion

Tablas afectadas:
- `cobis..cl_direccion` - UPDATE (si ok)
- `cobis..ts_direccion` - INSERT (si ok)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_fecha_modificacion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-047: RAMA-133 TRUE - @@error!=0 en UPDATE cl_direccion (UPDATE)

Objetivo: AEST-RAMA-133 - Rama de manejo de @@error en UPDATE de cl_direccion durante operacion UPDATE.

Precondiciones:
- El ente debe existir en cl_ente
- Debe existir una direccion para el ente
- El producto, ciudad, parroquia, oficina deben existir

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente
   - `@i_descripcion='Calle Update Err 777'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Cambio de descripcion

Resultado esperado funcional:
- Si @@error != 0 en UPDATE cl_direccion: Error codigo 105034
- RAMA-133: IF @@error != 0 -> TRUE -> error
- Si no hay error: continua con INSERT ts_direccion

Resultado esperado en BD:
- Si @@error: ROLLBACK
- Si ok: UPDATE + 2 INSERT ts_direccion

Tablas afectadas:
- `cobis..cl_direccion` - UPDATE
- `cobis..ts_direccion` - INSERT (2 registros)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_fecha_modificacion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-048: RAMA-134 TRUE - @@error!=0 en INSERT ts_direccion clase P (UPDATE)

Objetivo: AEST-RAMA-134 - Rama de manejo de @@error en INSERT ts_direccion clase 'P' (previo).

Precondiciones:
- Mismas precondiciones que TC-047

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente
   - `@i_descripcion='Calle TS Prev Err 888'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Cambio de descripcion

Resultado esperado funcional:
- Si @@error != 0 en INSERT ts_direccion (clase P): Error codigo 103005
- RAMA-134: IF @@error != 0 -> TRUE -> error
- Si no hay error: continua con INSERT ts_direccion clase A

Resultado esperado en BD:
- Si @@error: ROLLBACK
- Si ok: UPDATE + 2 INSERT ts_direccion

Tablas afectadas:
- `cobis..cl_direccion` - UPDATE
- `cobis..ts_direccion` - INSERT (2 registros)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-049: RAMA-136 TRUE - @@error!=0 en INSERT ts_direccion clase A (UPDATE)

Objetivo: AEST-RAMA-136 - Rama de manejo de @@error en INSERT ts_direccion clase 'A' (actual).

Precondiciones:
- Mismas precondiciones que TC-047

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente
   - `@i_descripcion='Calle TS Act Err 999'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Cambio de descripcion

Resultado esperado funcional:
- Si @@error != 0 en INSERT ts_direccion (clase A): Error codigo 103005
- RAMA-136: IF @@error != 0 -> TRUE -> error
- Si no hay error: continua con commit

Resultado esperado en BD:
- Si @@error: ROLLBACK
- Si ok: commit

Tablas afectadas:
- `cobis..cl_direccion` - UPDATE
- `cobis..ts_direccion` - INSERT (2 registros)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-050: RAMA-152 TRUE - sp_notif_cli_mod_dir error en UPDATE

Objetivo: AEST-RAMA-152 - Rama de manejo de error cuando sp_notif_cli_mod_dir retorna !=0 en UPDATE.

Precondiciones:
- El ente debe existir en cl_ente con en_subtipo='P'
- Debe existir una direccion para el ente
- @i_envio_notifica='S'
- @w_fecha_reg > @w_fecha_crea_cli
- El producto, ciudad, parroquia, oficina deben existir
- sp_notif_cli_mod_dir debe existir

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion existente
   - `@i_descripcion='Calle Notif Upd Err 000'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Cambio que activa @w_envio_notifica='S'
   - `@i_envio_notifica='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa notificacion

Resultado esperado funcional:
- Si sp_notif_cli_mod_dir retorna !=0: Error con codigo @w_return
- RAMA-150 TRUE -> exec sp_notif_cli_mod_dir -> RAMA-152: IF @w_return != 0 -> TRUE -> error
- Si retorna 0: commit

Resultado esperado en BD:
- Si error: ROLLBACK
- Si ok: commit con UPDATE y notificacion

Tablas afectadas:
- `cobis..cl_direccion` - UPDATE
- `cobis..ts_direccion` - INSERT (2 registros)

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_fecha_modificacion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

---

## TC-051: BVA - @i_direccion frontera cero (0) en UPDATE

Objetivo: AEST-BVA-004 - @i_direccion=0 en UPDATE. El SELECT de cl_direccion busca di_direccion=0.

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir
- La direccion 0 no debe existir para el ente
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe FROM cobis..cl_direccion WHERE di_ente = 1 AND di_direccion = 0
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_direccion=0`
      - fuente_valor=analisis
      - fuente_detalle=BVA: frontera cero para @i_direccion (tinyint). Activa RAMA-089 TRUE (@@rowcount=0).

Resultado esperado funcional:
- Error: codigo 101059 ("No existe direccion")
- El SELECT de cl_direccion con di_direccion=0 retorna @@rowcount=0

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_ciudad` - SELECT
- `cobis..cl_parroquia` - SELECT
- `cobis..cl_oficina` - SELECT
- `cobis..cl_direccion` - SELECT (no encuentra fila)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-052: BVA - @i_direccion frontera maxima tinyint (255) en UPDATE

Objetivo: AEST-BVA-006 - @i_direccion=255 (maximo tinyint) en UPDATE.

Precondiciones:
- El ente debe existir en cl_ente
- El producto, ciudad, parroquia, oficina deben existir
- La direccion 255 no debe existir para el ente (o si existe, se actualizara)
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe FROM cobis..cl_direccion WHERE di_ente = 1 AND di_direccion = 255
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='U'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion UPDATE
   - `@t_trn=110`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_direccion=255`
      - fuente_valor=analisis
      - fuente_detalle=BVA: valor maximo tinyint (255) para @i_direccion

Resultado esperado funcional:
- Si direccion 255 no existe: Error codigo 101059
- Si direccion 255 existe: Retorno 0 con UPDATE exitoso
- RAMA-089: IF @@rowcount = 0 -> TRUE/FALSE segun existencia

Resultado esperado en BD:
- Si no existe: sin cambios
- Si existe: UPDATE en cl_direccion

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_direccion` - SELECT / UPDATE

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 255
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-053: BVA - @i_ente valor maximo int (2147483647)

Objetivo: AEST-BVA-003 - @i_ente con valor maximo de int. Activa RAMA-003 TRUE (@@rowcount=0).

Precondiciones:
- El ente 2147483647 no debe existir en cl_ente
- Consulta de verificacion:
```sql
SELECT COUNT(1) as existe FROM cobis..cl_ente WHERE en_ente = 2147483647
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_ente=2147483647`
      - fuente_valor=analisis
      - fuente_detalle=BVA: valor maximo int (2^31-1). Activa RAMA-003 TRUE (@@rowcount=0).
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion

Resultado esperado funcional:
- Error: codigo 101042 ("No existe ente")
- RAMA-002 FALSE (@i_ente != 0) -> SELECT cl_ente -> RAMA-003 TRUE (@@rowcount=0)

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT (no encuentra fila)

Validacion SQL post-ejecucion:
```sql
SELECT COUNT(1) as total_direcciones
FROM cobis..cl_direccion
WHERE di_ente = 2147483647
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-054: RAMA-159 TRUE - No eliminar direccion de envio CRP (DELETE)

Objetivo: AEST-RAMA-044 - DELETE con @w_envio_crp='S'. Activa RAMA-159 TRUE (error 101274).

Precondiciones:
- El ente debe existir en cl_ente
- El ente debe tener al menos 2 direcciones
- La direccion a eliminar debe tener di_envio_crp='S'
- @e_actmasivacli='N'
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_envio_crp = 'S'
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion con di_envio_crp='S'
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Error: codigo 101274 ("NO SE PUEDE ELIMINAR LA DIRECCION DE ENVIO DE CORRESPONDENCIA")
- RAMA-157 TRUE (@e_actmasivacli='N') -> RAMA-158 FALSE (count > 1) -> RAMA-159: IF @w_envio_crp = 'S' -> TRUE -> error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_direccion` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-055: RAMA-160 TRUE - No eliminar direccion asociada a cuenta corriente

Objetivo: AEST-RAMA-045 - DELETE con direccion asociada a cc_ctacte. Activa RAMA-160 TRUE (error 101273).

Precondiciones:
- El ente debe existir en cl_ente
- El ente debe tener al menos 2 direcciones
- La direccion debe estar asociada a una cuenta corriente en cob_cuentas..cc_ctacte
- @e_actmasivacli='N'
- Consulta de verificacion:
```sql
SELECT cc_cliente, cc_direccion_ec, cc_estado
FROM cob_cuentas..cc_ctacte
WHERE cc_cliente = 1 AND cc_tipo_dir = 'D' AND cc_estado NOT IN ('C', 'Q')
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion asociada a cuenta corriente
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Error: codigo 101273 ("NO SE PUEDE ELIMINAR UNA DIRECCION DE ENVIO DE ESTADO CUENTA")
- RAMA-159 FALSE (@w_envio_crp != 'S') -> RAMA-160: IF EXISTS(select 1 from cc_ctacte...) -> TRUE -> error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_direccion` - SELECT
- `cob_cuentas..cc_ctacte` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-056: RAMA-161 TRUE - No eliminar direccion asociada a ECTC

Objetivo: AEST-RAMA-046 - DELETE con direccion asociada a cl_dir_envio_tarj_cred. Activa RAMA-161 TRUE (error 101273).

Precondiciones:
- El ente debe existir en cl_ente
- El ente debe tener al menos 2 direcciones
- La direccion debe estar asociada a ECTC en cl_dir_envio_tarj_cred con dt_estado='A'
- @e_actmasivacli='N'
- Consulta de verificacion:
```sql
SELECT dt_ente, dt_sec_direc_envio, dt_estado
FROM cl_dir_envio_tarj_cred
WHERE dt_ente = 1 AND dt_estado = 'A'
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion asociada a ECTC
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Error: codigo 101273 ("NO SE PUEDE ELIMINAR UNA DIRECCION DE ENVIO DE ESTADO CUENTA")
- RAMA-160 FALSE -> RAMA-161: IF EXISTS(select 1 from cl_dir_envio_tarj_cred...) -> TRUE -> error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_direccion` - SELECT
- `cl_dir_envio_tarj_cred` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-057: RAMA-162 TRUE, RAMA-163 TRUE - No eliminar direccion D con movil asociado

Objetivo: AEST-RAMA-047, AEST-RAMA-048 - DELETE de direccion tipo Domicilio de PN con numero movil asociado. Activa RAMA-162 TRUE y RAMA-163 TRUE (error 101692).

Precondiciones:
- El ente debe existir en cl_ente con en_subtipo='P'
- El ente debe tener al menos 2 direcciones
- La direccion a eliminar debe ser tipo 'D'
- La direccion debe tener un numero movil asociado en cl_direccion_email con de_tipo='M'
- @e_actmasivacli='N'
- Consulta de verificacion:
```sql
SELECT de_ente, de_tipo, de_dir_domici
FROM cl_direccion_email
WHERE de_ente = 1 AND de_tipo = 'M'
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_direccion=1`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion tipo D con movil asociado
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Error: codigo 101692
- RAMA-161 FALSE -> RAMA-162: IF @w_subtipo='P' and @w_tipo='D' -> TRUE
- RAMA-163: IF EXISTS(select 1 from cl_direccion_email where de_tipo='M' and de_dir_domici=@i_direccion) -> TRUE -> error

Resultado esperado en BD:
- No se realiza ninguna modificacion en BD

Tablas afectadas:
- `cobis..cl_ente` - SELECT
- `cobis..cl_producto` - SELECT
- `cobis..cl_direccion` - SELECT
- `cl_direccion_email` - SELECT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_tipo
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 1
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-058: RAMA-001 TRUE - @t_debug='S' activa modo debug

Objetivo: AEST-RAMA-049 - Activar el modo debug con @t_debug='S'. Ejecuta sp_begin_debug y sp_end_debug.

Precondiciones:
- El ente debe existir en cl_ente
- sp_begin_debug y sp_end_debug deben existir en cobis

Datos de entrada:
- parametros_bajo_prueba:
   - `@t_debug='S'`
      - fuente_valor=analisis
      - fuente_detalle=Activa RAMA-001 TRUE: ejecuta sp_begin_debug, SELECT de parametros, sp_end_debug
   - `@i_operacion='I'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion INSERT
   - `@t_trn=109`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_descripcion='Calle Debug 111'`
      - fuente_valor=supuesto_controlado
      - fuente_detalle=Descripcion de prueba

Resultado esperado funcional:
- Retorno 0 (exito)
- RAMA-001 TRUE: exec sp_begin_debug, SELECT de todos los parametros, exec sp_end_debug
- Luego continua con el flujo normal de INSERT

Resultado esperado en BD:
- Se inserta en cl_direccion y ts_direccion normalmente
- El debug no afecta la logica de negocio

Tablas afectadas:
- `cobis..cl_direccion` - INSERT
- `cobis..ts_direccion` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion, di_descripcion, di_fecha_registro
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_descripcion = 'Calle Debug 111'
```

Resultado observado en BD:
- Completar durante la ejecucion.

## TC-059: RAMA-173 TRUE - @@error!=0 en DELETE cl_direccion

Objetivo: AEST-RAMA-173 - Rama de manejo de @@error en DELETE de cl_direccion. Cubre el bloque transaccional de DELETE.

Precondiciones:
- El ente debe existir en cl_ente
- El ente debe tener al menos 2 direcciones
- La direccion no debe ser envio CRP, no asociada a cuentas, no ECTC
- @e_actmasivacli='N'
- Consulta de verificacion:
```sql
SELECT di_ente, di_direccion, di_envio_crp, di_tipo
FROM cobis..cl_direccion
WHERE di_ente = 1
ORDER BY di_direccion
```

Datos de entrada:
- parametros_bajo_prueba:
   - `@i_operacion='D'`
      - fuente_valor=analisis
      - fuente_detalle=Operacion DELETE
   - `@t_trn=1226`
      - fuente_valor=analisis
      - fuente_detalle=Codigo de transaccion
   - `@i_direccion=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Direccion a eliminar (valida para eliminacion)
   - `@i_producto=2`
      - fuente_valor=sybase_select
      - fuente_detalle=Producto existente

Resultado esperado funcional:
- Si @@error != 0 en DELETE cl_direccion: Error codigo 107007 ("Error en eliminacion de direccion")
- RAMA-173: IF @@error != 0 -> TRUE -> error
- Si no hay error: continua con INSERT ts_direccion, log, historicos

Resultado esperado en BD:
- Si @@error: ROLLBACK
- Si ok: DELETE + INSERT ts_direccion + log + historicos

Tablas afectadas:
- `cobis..cl_direccion` - DELETE
- `cobis..ts_direccion` - INSERT
- `cl_log_dir_envio_ec` - INSERT
- `cobis_his..cl_direccion_his` - INSERT

Validacion SQL post-ejecucion:
```sql
SELECT di_ente, di_direccion
FROM cobis..cl_direccion
WHERE di_ente = 1 AND di_direccion = 2
```

Resultado observado en BD:
- Completar durante la ejecucion.

---

## Control de Cobertura

- objetivo_casos: 59
- objetivo_casos_lote: 9
- casos_generados: 59
- porcentaje_cumplimiento: 100.0
- brecha: 0
- estado_tolerancia: OK
- rango_generado: TC-001 a TC-059
- siguiente_rango_sugerido: N/A (objetivo cumplido)
- ids_cubiertos: AEST-BVA-001, AEST-BVA-002, AEST-BVA-003, AEST-BVA-004, AEST-BVA-005, AEST-BVA-006, AEST-BVA-007, AEST-BVA-008, AEST-BVA-009, AEST-BVA-010, AEST-BVA-011, AEST-BVA-012, AEST-BVA-013, AEST-BVA-014, AEST-BVA-015, AEST-RAMA-001, AEST-RAMA-002, AEST-RAMA-003, AEST-RAMA-004, AEST-RAMA-005, AEST-RAMA-006, AEST-RAMA-007, AEST-RAMA-008, AEST-RAMA-009, AEST-RAMA-010, AEST-RAMA-011, AEST-RAMA-012, AEST-RAMA-013, AEST-RAMA-014, AEST-RAMA-015, AEST-RAMA-016, AEST-RAMA-017, AEST-RAMA-018, AEST-RAMA-019, AEST-RAMA-020, AEST-RAMA-021, AEST-RAMA-022, AEST-RAMA-023, AEST-RAMA-029, AEST-RAMA-030, AEST-RAMA-031, AEST-RAMA-032, AEST-RAMA-033, AEST-RAMA-034, AEST-RAMA-035, AEST-RAMA-036, AEST-RAMA-037, AEST-RAMA-038, AEST-RAMA-039, AEST-RAMA-040, AEST-RAMA-041, AEST-RAMA-042, AEST-RAMA-043, AEST-RAMA-044, AEST-RAMA-045, AEST-RAMA-046, AEST-RAMA-047, AEST-RAMA-048, AEST-RAMA-049, AEST-RAMA-050, AEST-RAMA-052, AEST-RAMA-053, AEST-RAMA-056, AEST-RAMA-059, AEST-RAMA-060, AEST-RAMA-076, AEST-RAMA-077, AEST-RAMA-106, AEST-RAMA-122, AEST-RAMA-133, AEST-RAMA-134, AEST-RAMA-136, AEST-RAMA-152, AEST-RAMA-173
- ids_justificados: AEST-CENT-001 (SP sin calculos monetarios), AEST-RAMA-024 (WHILE cursor INSERT - requiere cuentas de ahorro reales, no testeable sin datos), AEST-RAMA-025 (WHILE cursor UPDATE ahorros - requiere cuentas de ahorro reales), AEST-RAMA-026 (WHILE cursor UPDATE cte - requiere cuentas corrientes reales), AEST-RAMA-027 (WHILE telefonos DELETE - requiere telefonos asociados), AEST-RAMA-028 (WHILE telefonos DELETE E - requiere telefonos asociados), AEST-RAMA-051 (PJ - requiere ente juridico en ambiente), AEST-RAMA-054 (no_cobis DELETE - requiere sp_gen_sec), AEST-RAMA-055 (no_cobis DELETE E - requiere sp_gen_sec), AEST-RAMA-057 (ind_act_presenc V - requiere configuracion), AEST-RAMA-058 (cambio envio CRP UPDATE - requiere datos especificos)
- ids_pendientes: Ninguno
- nota_depuracion: Lote 3 cierra el objetivo de 59 casos. Se completaron BVA de valores extremos (@i_direccion=0, @i_direccion=255, @i_ente=max int), ramas de eliminacion protegida (CRP, cuenta corriente, ECTC, movil asociado), rama de debug (@t_debug='S'), y rama @@error en DELETE. Las 11 ramas WHILE y condicionales restantes se justifican como no testeables sin datos reales de ambiente (cuentas de ahorro/corriente, telefonos, entes juridicos, configuracion de canales). Total acumulado: 59 casos, 74 IDs cubiertos, 12 IDs justificados, 0 pendientes.
- estado_validacion_contrato: VALIDADO_CON_CONDICIONES
- hallazgos_preflight:
  - `CONDICIONAL_LOCAL`: @i_valida declarado en firma pero no usado en cuerpo activo
  - `CONDICIONAL_LOCAL`: Cursores sobre cuentas requieren datos reales
  - `CONDICIONAL_LOCAL`: Notificaciones requieren ambiente configurado
  - `LIMITACION_VALIDADOR`: El validador no reconoce `create proc` como `CREATE PROCEDURE`
- parametros_verificados: total=64; entradas=61; salidas=3
- graph_context_status: NO_INFORMADO
- hallazgos_consistencia_grafo: No aplica (graph_context no informado)
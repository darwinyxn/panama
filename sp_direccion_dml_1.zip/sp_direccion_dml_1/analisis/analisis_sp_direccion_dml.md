================================================================================
ANALISIS ESTRUCTURAL  - SP: sp_direccion_dml
================================================================================
## Que hace este SP
OLTP - Procesa las transacciones DML (INSERT, UPDATE, DELETE) sobre direcciones de clientes (entes) en la base cobis. Soporta operaciones I (insercion), U (actualizacion), D (eliminacion) y E (eliminacion con validaciones a tablas temporales). Valida claves foraneas (producto, ciudad, parroquia, oficina, canton), tipos de direccion (D/T/O), limites maximos de direcciones por ente, vigencia de referencias, y propaga cambios a cuentas de ahorro/corriente y tarjetas de credito. Envia notificaciones al cliente por cambios de direccion via sp_notif_cli_mod_dir.

| Campo | Valor |
|-------|-------|
| Archivo fuente | insumos/sp_direccion_dml/sp/dir_dml.sp |
| analyzer_version | 2.0 |
| Fecha | 2026-11-12 |
| LOC efectivas | 1824 |
| loc_cuerpo_proc | 2530 |
| tipo_sp | ORQUESTADOR |
| complejidad_final | ALTA |
| casos_brutos | 485 |
| casos_finales_estimados | 98 |

================================================================================
INVENTARIO ESTRUCTURAL
================================================================================

--- PARAMETROS ---
| # | nombre | tipo | longitud | direccion | default | obligatorio | rol_en_sp |
|---|--------|------|----------|-----------|---------|-------------|-----------|
| 1 | @s_ssn | int | - | ENTRADA | null | No | CONTEXTO |
| 2 | @s_user | login | - | ENTRADA | null | No | CONTEXTO |
| 3 | @s_term | varchar | 30 | ENTRADA | null | No | CONTEXTO |
| 4 | @s_date | datetime | - | ENTRADA | null | No | CONTEXTO |
| 5 | @s_srv | varchar | 30 | ENTRADA | null | No | CONTEXTO |
| 6 | @s_lsrv | varchar | 30 | ENTRADA | null | No | CONTEXTO |
| 7 | @s_ofi | smallint | - | ENTRADA | null | No | CONTEXTO |
| 8 | @s_rol | smallint | - | ENTRADA | null | No | CONTEXTO |
| 9 | @s_org_err | char | 1 | ENTRADA | null | No | CONTEXTO |
| 10 | @s_error | int | - | ENTRADA | null | No | CONTEXTO |
| 11 | @s_sev | tinyint | - | ENTRADA | null | No | CONTEXTO |
| 12 | @s_msg | descripcion | - | ENTRADA | null | No | CONTEXTO |
| 13 | @s_org | char | 1 | ENTRADA | null | No | CONTEXTO |
| 14 | @t_debug | char | 1 | ENTRADA | 'N' | No | DISCRIMINADOR |
| 15 | @t_file | varchar | 10 | ENTRADA | null | No | DISCRIMINADOR |
| 16 | @t_from | varchar | 32 | ENTRADA | null | No | CONTEXTO |
| 17 | @t_trn | int | - | ENTRADA | null | No | DISCRIMINADOR |
| 18 | @i_operacion | char | 1 | ENTRADA | - | Si | DISCRIMINADOR |
| 19 | @i_no_cobis | char | 1 | ENTRADA | 'N' | No | DISCRIMINADOR |
| 20 | @i_mensaje | char | 1 | ENTRADA | 'S' | No | DISCRIMINADOR |
| 21 | @i_producto | tinyint | - | ENTRADA | null | No | DISCRIMINADOR |
| 22 | @i_ente | int | - | ENTRADA | null | No | DISCRIMINADOR |
| 23 | @i_direccion | tinyint | - | ENTRADA | null | No | DISCRIMINADOR |
| 24 | @i_descripcion | varchar | 255 | ENTRADA | null | No | PASANTE |
| 25 | @i_tipo | catalogo | - | ENTRADA | null | No | DISCRIMINADOR |
| 26 | @i_sector | catalogo | - | ENTRADA | '0' | No | PASANTE |
| 27 | @i_parroquia | smallint | - | ENTRADA | null | No | PASANTE |
| 28 | @i_ciudad | smallint | - | ENTRADA | null | No | DISCRIMINADOR |
| 29 | @i_oficina | smallint | - | ENTRADA | null | No | PASANTE |
| 30 | @i_zona | catalogo | - | ENTRADA | null | No | PASANTE |
| 31 | @i_envio_crp | char | 1 | ENTRADA | 'N' | No | DISCRIMINADOR |
| 32 | @i_parroquia_ciu | smallint | - | ENTRADA | 0 | No | PASANTE |
| 33 | @i_observacion | varchar | 255 | ENTRADA | null | No | PASANTE |
| 34 | @i_pto_referencia | varchar | 255 | ENTRADA | null | No | PASANTE |
| 35 | @i_verificado | char | 1 | ENTRADA | 'N' | No | DISCRIMINADOR |
| 36 | @i_fecha_ver | datetime | - | ENTRADA | null | No | PASANTE |
| 37 | @i_usuario_ver | login | - | ENTRADA | null | No | PASANTE |
| 38 | @i_vigencia | char | 1 | ENTRADA | 'N' | No | PASANTE |
| 39 | @i_fecha_caducidad | datetime | - | ENTRADA | null | No | PASANTE |
| 40 | @i_nombre_verif | descripcion | - | ENTRADA | null | No | PASANTE |
| 41 | @i_cargo_verif | varchar | 20 | ENTRADA | null | No | PASANTE |
| 42 | @i_ind_act_presenc | char | 1 | ENTRADA | 'N' | No | DISCRIMINADOR |
| 43 | @i_ind_val_maxdir | char | 1 | ENTRADA | 'S' | No | DISCRIMINADOR |
| 44 | @i_tipo_verif_incns | catalogo | - | ENTRADA | null | No | PASANTE |
| 45 | @i_bancarizacion | char | 1 | ENTRADA | 'N' | No | PASANTE |
| 46 | @i_verifdirec | char | 1 | ENTRADA | 'N' | No | DISCRIMINADOR |
| 47 | @i_tipo_servicio | catalogo | - | ENTRADA | null | No | PASANTE |
| 48 | @i_cod_empresa | tinyint | - | ENTRADA | null | No | PASANTE |
| 49 | @i_direc_planilla | varchar | 254 | ENTRADA | null | No | PASANTE |
| 50 | @i_cod_rela_prop | catalogo | - | ENTRADA | null | No | PASANTE |
| 51 | @i_nom_propietario | descripcion | - | ENTRADA | null | No | PASANTE |
| 52 | @i_vreferen | char | 1 | ENTRADA | 'N' | No | DISCRIMINADOR |
| 53 | @i_solicitud | int | - | ENTRADA | null | No | PASANTE |
| 54 | @i_anio | smallint | - | ENTRADA | null | No | PASANTE |
| 55 | @o_direccion | tinyint | - | SALIDA | null out | No | SALIDA |
| 56 | @o_msj_error | varchar | 132 | SALIDA | null out | No | SALIDA |
| 57 | @o_sig_log_svr | int | - | SALIDA | null out | No | SALIDA |
| 58 | @i_canton | catalogo | - | ENTRADA | null | No | PASANTE |
| 59 | @i_valida | char | 1 | ENTRADA | 'S' | No | DISCRIMINADOR |
| 60 | @i_val_dir | char | 1 | ENTRADA | 'N' | No | DISCRIMINADOR |
| 61 | @i_val_domicilio | char | 1 | ENTRADA | 'S' | No | DISCRIMINADOR |
| 62 | @i_canal | varchar | 10 | ENTRADA | null | No | DISCRIMINADOR |
| 63 | @i_envio_notifica | char | 1 | ENTRADA | 'S' | No | DISCRIMINADOR |
| 64 | @e_actmasivacli | char | 1 | ENTRADA | 'N' | No | DISCRIMINADOR |

--- RAMAS DE CONTROL (resumen) ---
Total: 198 ramas. 4 enrutadores principales (@i_operacion), 194 ramas de decision.
Tipos: IF=180, ELSE=8, WHILE=5, IF_EXISTS=5

--- TABLAS ACCEDIDAS ---
| # | tabla | operacion | es_catalogo |
|---|-------|-----------|-------------|
| 1 | cobis..cl_ente | R | NO |
| 2 | cobis..cl_direccion_email | R | NO |
| 3 | cobis..cl_producto | R | NO |
| 4 | cobis..cl_ciudad | R | SI |
| 5 | cobis..cl_parroquia | R | SI |
| 6 | cobis..cl_canton_ciudad | R | SI |
| 7 | cobis..cl_parroquia_ciudad | R | SI |
| 8 | cobis..cl_oficina | R | SI |
| 9 | cobis..cl_direccion | RW | NO |
| 10 | cobis..cl_parametro | R | SI |
| 11 | cobis..ts_direccion | W | NO |
| 12 | cl_vr_solicitud_log | W | NO |
| 13 | cl_log_dir_envio_ec | W | NO |
| 14 | cob_ahorros..ah_cuenta | R | NO |
| 15 | cl_dir_envio_tarj_cred | RW | NO |
| 16 | cob_cuentas..cc_ctacte | R | NO |
| 17 | cobis..cl_catalogo | R | SI |
| 18 | cobis..cl_tabla | R | SI |
| 19 | cobis_his..cl_direccion_his | W | NO |
| 20 | cobis..cl_telefono | RW | NO |
| 21 | cobis_his..cl_telefono_his | W | NO |
| 22 | cobis..cl_direccion_tmp | R | NO |
| 23 | cobis..cl_dir_est_cta_tmp | R | NO |

--- SPs DEPENDIENTES ---
| id | sp | clasificacion |
|----|-----|---------------|
| DEP-01 | cobis..sp_begin_debug | UTILITARIO |
| DEP-02 | cobis..sp_end_debug | UTILITARIO |
| DEP-03 | cobis..sp_catalogo | LIBRERIA_NEGOCIO |
| DEP-04 | cobis..sp_gen_sec | UTILITARIO |
| DEP-05 | sp_cseqnos | UTILITARIO |
| DEP-06 | sp_dir_est_cta | LIBRERIA_NEGOCIO |
| DEP-07 | cobis..sp_notif_cli_mod_dir | LIBRERIA_NEGOCIO |
| DEP-08 | cobis..sp_telefono | LIBRERIA_NEGOCIO |
| DEP-09 | cobis..sp_cerror | UTILITARIO |
| DEP-10 | cobis..sp_msj_error | UTILITARIO |

--- BLOQUES TRANSACCIONALES ---
| # | linea_begin | linea_commit | alcance |
|---|-------------|--------------|---------|
| 1 | L737 | L1001 | INSERT direccion + ts_direccion + log |
| 2 | L1599 | L2060 | UPDATE direccion + ts_direccion (P+A) + log |
| 3 | L2244 | L2482 | DELETE direccion + ts_direccion + historico + telefonos |
| 4 | L2578 | L2658 | DELETE E direccion + ts_direccion + telefonos |

================================================================================
CLASIFICACION DE COMPLEJIDAD
================================================================================

--- DIMENSIONES D1-D6 ---
| Dimension | Peso | Valor | Clasificacion | Justificacion |
|-----------|------|-------|---------------|---------------|
| D1: Volumen | 15% | 1824 LOC | ALTA | >800 LOC |
| D2: Estructuras | 20% | 105 puntos | ALTA | 198 ramas |
| D3: Dependencias | 15% | 23 tablas + 10 SPs | ALTA | >5 tablas |
| D4: Transaccional | 10% | 4 bloques | MEDIA | Sin anidamiento |
| D5: Financiera | 15% | 3 cursores | ALTA | Cursores sobre cuentas |
| D6: Negocio | 25% | 4 puntos | ALTA | Critico + propagacion + frecuente |

Complejidad final: **ALTA**

--- CALCULO DE CASOS ---
| Factor | Calculo | Resultado |
|--------|---------|-----------|
| F1a (Discriminadores EP) | 18 params x 2 | 36 |
| F1b (Pasantes contrato) | 22 params x 1 | 22 |
| F2 (Limites BVA) | 5 params con limite x 3 | 15 |
| F3 (Ramas) | 198 ramas x 2 - 36 | 360 |
| F4 (Codigos retorno) | 28 codigos | 28 |
| F5 (Transaccionales) | 4 bloques | 4 |
| F6 (Contrato libreria) | 5 x 4 SPs | 20 |
| **Casos Brutos** | suma | **485** |
| **Exclusiones** | redundancias | **-387** |
| **Casos Finales Estimados** | brutos - exclusiones | **98** |
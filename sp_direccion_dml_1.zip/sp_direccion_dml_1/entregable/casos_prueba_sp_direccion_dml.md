# Casos de Prueba - SP sp_direccion_dml

**Base de datos:** cobis (Sybase)
**Proposito:** OLTP - Procesa las transacciones DML (INSERT, UPDATE, DELETE) sobre direcciones de clientes (entes). Soporta operaciones I, U, D, E con validaciones de claves foraneas, limites maximos, vigencia y propagacion a cuentas.

**Destino:** QA_MANUAL

## CONFIGURACION COMPARTIDA DEL SP

- **Procedimiento**: dbo.sp_direccion_dml
- **Base de Datos**: cobis (con dependencias en cob_ahorros, cob_cuentas, cobis_his)
- **Tipo**: ORQUESTADOR
- **Criticidad**: ALTA
- **Complejidad Final**: ALTA

## CONVENCIONES

| Simbolo | Significado |
|---------|-------------|
| PRE | Precondicion: estado de BD antes de ejecutar |
| POST | Postcondicion: estado de BD despues de ejecutar |
| DOCUMENTADA | Procedimiento completo de preparacion/restauracion con literales |
| DATOS_EXISTENTES | Condicion comprobada, sin necesidad de DML para este escenario |
| PENDIENTE | Falta informacion, datos, metadata o recuperacion |

## PARAMETROS DE SESION POR DEFECTO

| Parametro | Valor por defecto | Descripcion |
|-----------|-------------------|-------------|
| **@s_ssn** | 1 | Secuencial de sesion |
| **@s_user** | 'TESTUSER' | Usuario de prueba |
| **@s_term** | 'TERM001' | Terminal |
| **@s_date** | '2026-11-12 10:00:00' | Fecha de operacion |
| **@s_srv** | 'SRV001' | Servidor |
| **@s_lsrv** | 'LSRV001' | Servidor local |
| **@s_ofi** | 1 | Oficina |
| **@s_rol** | 1 | Rol |
| **@s_org_err** | 'N' | Origen error |
| **@s_error** | 0 | Codigo error |
| **@s_sev** | 0 | Severidad |
| **@s_msg** | null | Mensaje |
| **@s_org** | 'N' | Origen |
| **@t_debug** | 'N' | Debug |
| **@t_file** | null | Archivo debug |
| **@t_from** | null | Origen debug |
| **@i_no_cobis** | 'N' | No genera transaccion cobis |
| **@i_mensaje** | 'S' | Usa sp_cerror |
| **@i_sector** | '0' | Sector |
| **@i_zona** | null | Zona |
| **@i_envio_crp** | 'N' | Envio correspondencia |
| **@i_parroquia_ciu** | 0 | Parroquia ciudad |
| **@i_observacion** | null | Observacion |
| **@i_pto_referencia** | null | Punto referencia |
| **@i_verificado** | 'N' | Verificado |
| **@i_fecha_ver** | null | Fecha verificacion |
| **@i_usuario_ver** | null | Usuario verificacion |
| **@i_vigencia** | 'N' | Vigencia |
| **@i_fecha_caducidad** | null | Fecha caducidad |
| **@i_nombre_verif** | null | Nombre verificador |
| **@i_cargo_verif** | null | Cargo verificador |
| **@i_ind_act_presenc** | 'N' | Indicador act. presencial |
| **@i_ind_val_maxdir** | 'S' | Valida maximo direcciones |
| **@i_tipo_verif_incns** | null | Tipo verificacion inconsistencia |
| **@i_bancarizacion** | 'N' | Bancarizacion |
| **@i_verifdirec** | 'N' | Verifica direccion EC |
| **@i_tipo_servicio** | null | Tipo servicio |
| **@i_cod_empresa** | null | Codigo empresa |
| **@i_direc_planilla** | null | Direccion planilla |
| **@i_cod_rela_prop** | null | Codigo relacion propietario |
| **@i_nom_propietario** | null | Nombre propietario |
| **@i_vreferen** | 'N' | Vreferen |
| **@i_solicitud** | null | Solicitud vreferen |
| **@i_anio** | null | Anio vreferen |
| **@i_canton** | null | Canton |
| **@i_valida** | 'S' | Valida canton/parroquia |
| **@i_val_dir** | 'N' | Valida tipo dir por tipo persona |
| **@i_val_domicilio** | 'S' | Valida domicilio unico |
| **@i_canal** | null | Canal |
| **@i_envio_notifica** | 'S' | Envio notificacion |
| **@e_actmasivacli** | 'N' | Actualizacion masiva clientes |

### Plantilla de Ejecucion

```sql
DECLARE @return_code int;
DECLARE @o_direccion tinyint;
DECLARE @o_msj_error varchar(132);
DECLARE @o_sig_log_svr int;

EXEC @return_code = cobis..sp_direccion_dml
    @s_ssn              = 1,
    @s_user             = 'TESTUSER',
    @s_term             = 'TERM001',
    @s_date             = '2026-11-12 10:00:00',
    @s_srv              = 'SRV001',
    @s_lsrv             = 'LSRV001',
    @s_ofi              = 1,
    @s_rol              = 1,
    @s_org_err          = 'N',
    @s_error            = 0,
    @s_sev              = 0,
    @s_msg              = null,
    @s_org              = 'N',
    @t_debug            = 'N',
    @t_file             = null,
    @t_from             = null,
    @t_trn              = 109,
    @i_operacion        = 'I',
    @i_no_cobis         = 'N',
    @i_mensaje          = 'S',
    @i_producto         = 2,
    @i_ente             = 3,
    @i_direccion        = null,
    @i_descripcion      = 'Calle Principal 123',
    @i_tipo             = 'D',
    @i_sector           = '0',
    @i_parroquia        = 0,
    @i_ciudad           = 1,
    @i_oficina          = 1,
    @i_zona             = null,
    @i_envio_crp        = 'N',
    @i_parroquia_ciu    = 0,
    @i_observacion      = null,
    @i_pto_referencia   = null,
    @i_verificado       = 'N',
    @i_fecha_ver        = null,
    @i_usuario_ver      = null,
    @i_vigencia         = 'N',
    @i_fecha_caducidad  = null,
    @i_nombre_verif     = null,
    @i_cargo_verif      = null,
    @i_ind_act_presenc  = 'N',
    @i_ind_val_maxdir   = 'S',
    @i_tipo_verif_incns = null,
    @i_bancarizacion    = 'N',
    @i_verifdirec       = 'N',
    @i_tipo_servicio    = null,
    @i_cod_empresa      = null,
    @i_direc_planilla   = null,
    @i_cod_rela_prop    = null,
    @i_nom_propietario  = null,
    @i_vreferen         = 'N',
    @i_solicitud        = null,
    @i_anio             = null,
    @i_canton           = null,
    @i_valida           = 'S',
    @i_val_dir          = 'N',
    @i_val_domicilio    = 'S',
    @i_canal            = null,
    @i_envio_notifica   = 'S',
    @e_actmasivacli     = 'N',
    @o_direccion        = @o_direccion OUT,
    @o_msj_error        = @o_msj_error OUT,
    @o_sig_log_svr      = @o_sig_log_svr OUT;

SELECT @return_code AS return_code, @o_direccion AS o_direccion;
GO
```

## Diagnostico de Ambiente

- **Servidor**: SYBASE02
- **Base**: cob_atm (conexion), cobis (SP y tablas)
- **Usuario**: dbo
- **Fecha diagnostico**: 2026-11-12 20:42
- **SP disponible**: SI (cobis..sp_direccion_dml)
- **Ente PN candidato**: 3 (subtipo P, 3 direcciones)
- **Ente PN alternativo**: 2 (subtipo P, 3 direcciones)
- **Oficinas disponibles**: 1, 2, 3
- **Ciudad**: 1, Parroquia: 0
- **Catalogo tipo D**: EXISTE
- **TPVGRE**: PENDIENTE (columna no encontrada en consulta directa)
- **Consultas ejecutadas**: 4
- **Reusos**: 0

---

## GRUPO 1 — Insercion de Direcciones (INSERT)

### TC01 — INSERT exitoso - Direccion tipo Domicilio basica

**Origen consolidado:** TCO-CON-001
**Objetivo:** Insercion valida de direccion tipo Domicilio para persona natural con parametros minimos requeridos. Cubre RN-05, RN-11, BVA-002.
**Datos de entrada:**

| Parametro | Valor efectivo | Fuente y evidencia |
|---|---|---|
| **@i_operacion** | 'I' | Diseno: particion valida INSERT |
| **@t_trn** | 109 | Diseno: codigo de transaccion INSERT |
| **@i_ente** | 3 | Diagnostico: ente PN con 3 direcciones (SELECT en_ente=3 FROM cobis..cl_ente WHERE en_subtipo='P') |
| **@i_tipo** | 'D' | Diseno: tipo Domicilio valido |
| **@i_descripcion** | 'Calle QA Test 001' | Diseno: descripcion de prueba |
| **@i_producto** | 2 | Diagnostico: producto existente (SELECT pd_producto=2 FROM cobis..cl_producto) |
| **@i_ciudad** | 1 | Diagnostico: ciudad existente (SELECT ci_ciudad=1 FROM cobis..cl_ciudad) |
| **@i_parroquia** | 0 | Diagnostico: parroquia 0 para ciudad 1 (SELECT pq_parroquia=0 FROM cobis..cl_parroquia WHERE pq_ciudad=1) |
| **@i_oficina** | 1 | Diagnostico: oficina existente (SELECT of_oficina=1 FROM cobis..cl_oficina) |

**Cobertura y procedencia:** AFUN-PEQ-001, AFUN-PEQ-011, AFUN-PEQ-012, AFUN-TD-019, AEST-BVA-002, AEST-RAMA-001, AEST-RAMA-005, AEST-RAMA-020, AEST-RAMA-050 | Particion valida / Frontera BVA | Riesgo MEDIO
**Tablas afectadas:** cobis..cl_direccion (INSERT), cobis..ts_direccion (INSERT)
**Estado de preparacion:** DOCUMENTADA
**Ejecucion funcional:** DISPONIBLE
**Condicion del SP:** @i_operacion='I' (RAMA-008 TRUE) → @t_trn=109 (RAMA-009 TRUE) → validaciones FK (producto, ciudad, parroquia, oficina, tipo, catalogo) → validacion maximo direcciones PN → INSERT cl_direccion → INSERT ts_direccion → COMMIT
**Diagnostico:** SELECT en_ente=3, en_subtipo='P' FROM cobis..cl_ente → 1 fila. SELECT COUNT(1) FROM cobis..cl_direccion WHERE di_ente=3 → 3 filas (maximo alcanzado). **ALERTA**: El ente 3 ya tiene 3 direcciones. Para INSERT exitoso se requiere @i_ind_val_maxdir='N' o usar ente con <3 direcciones.
**Estado original documentado:** Ente 3 tiene 3 direcciones (dir=1 tipo D crp=S verif=S, dir=2 tipo T crp=N verif=N, dir=3 tipo T crp=N verif=S). Para INSERT se requiere @i_ind_val_maxdir='N'.
**Aplicacion de preparacion:** Cambiar @i_ind_val_maxdir='N' en el EXEC para omitir validacion de maximo. No se requiere DML previo.
**Aplicacion de restitucion:** Eliminar la direccion insertada por el caso usando DELETE con @i_operacion='D', @t_trn=1226, @i_direccion=@o_direccion.
**Alcance de recuperacion:** Eliminar la fila insertada en cl_direccion. La fila en ts_direccion se conserva por diseno (auditoria). Si el caso falla antes del INSERT, no se requiere restitucion.
**Datos verificados:**

| Tabla | Columna | Tipo | Valor original | Parametro SP | Rol |
|---|---|---|---|---|---|
| cobis..cl_ente | en_ente | int | 3 | **@i_ente** | CLAVE |
| cobis..cl_ente | en_subtipo | char(1) | 'P' | - | DATO |
| cobis..cl_producto | pd_producto | tinyint | 2 | **@i_producto** | CLAVE |
| cobis..cl_ciudad | ci_ciudad | smallint | 1 | **@i_ciudad** | CLAVE |
| cobis..cl_parroquia | pq_ciudad | smallint | 1 | **@i_ciudad** | CLAVE |
| cobis..cl_parroquia | pq_parroquia | smallint | 0 | **@i_parroquia** | CLAVE |
| cobis..cl_oficina | of_oficina | smallint | 1 | **@i_oficina** | CLAVE |

**Resultado esperado:** `RETURN 0` — Insercion exitosa, @o_direccion retorna el nuevo secuencial.
**Resultado esperado en BD:** Nueva fila en cl_direccion con di_ente=3, di_tipo='D', di_descripcion='Calle QA Test 001'. Nueva fila en ts_direccion con clase='N'.
**Resultado observado:** Pendiente de corrida QA.
**Pendiente:** NO_APLICA

**PRE - Estado requerido en BD:**

```sql
-- PASO: ORIGINAL
SELECT di_ente, di_direccion, di_tipo, di_descripcion, di_envio_crp, di_verificado
FROM cobis..cl_direccion
WHERE di_ente = 3
ORDER BY di_direccion;
-- PASO: PREPARACION
-- NO_APLICA: El ente 3 ya existe con 3 direcciones. Se usa @i_ind_val_maxdir='N' en el EXEC.
-- PASO: PREPARADO
SELECT di_ente, di_direccion, di_tipo, di_descripcion, di_envio_crp, di_verificado
FROM cobis..cl_direccion
WHERE di_ente = 3
ORDER BY di_direccion;
```

**Ejecucion del SP:**

```sql
DECLARE @return_code int;
DECLARE @o_direccion tinyint;
DECLARE @o_msj_error varchar(132);
DECLARE @o_sig_log_svr int;

EXEC @return_code = cobis..sp_direccion_dml
    @s_ssn              = 1,
    @s_user             = 'TESTUSER',
    @s_term             = 'TERM001',
    @s_date             = '2026-11-12 10:00:00',
    @s_srv              = 'SRV001',
    @s_lsrv             = 'LSRV001',
    @s_ofi              = 1,
    @s_rol              = 1,
    @s_org_err          = 'N',
    @s_error            = 0,
    @s_sev              = 0,
    @s_msg              = null,
    @s_org              = 'N',
    @t_debug            = 'N',
    @t_file             = null,
    @t_from             = null,
    @t_trn              = 109,
    @i_operacion        = 'I',
    @i_no_cobis         = 'N',
    @i_mensaje          = 'S',
    @i_producto         = 2,
    @i_ente             = 3,
    @i_direccion        = null,
    @i_descripcion      = 'Calle QA Test 001',
    @i_tipo             = 'D',
    @i_sector           = '0',
    @i_parroquia        = 0,
    @i_ciudad           = 1,
    @i_oficina          = 1,
    @i_zona             = null,
    @i_envio_crp        = 'N',
    @i_parroquia_ciu    = 0,
    @i_observacion      = null,
    @i_pto_referencia   = null,
    @i_verificado       = 'N',
    @i_fecha_ver        = null,
    @i_usuario_ver      = null,
    @i_vigencia         = 'N',
    @i_fecha_caducidad  = null,
    @i_nombre_verif     = null,
    @i_cargo_verif      = null,
    @i_ind_act_presenc  = 'N',
    @i_ind_val_maxdir   = 'N',
    @i_tipo_verif_incns = null,
    @i_bancarizacion    = 'N',
    @i_verifdirec       = 'N',
    @i_tipo_servicio    = null,
    @i_cod_empresa      = null,
    @i_direc_planilla   = null,
    @i_cod_rela_prop    = null,
    @i_nom_propietario  = null,
    @i_vreferen         = 'N',
    @i_solicitud        = null,
    @i_anio             = null,
    @i_canton           = null,
    @i_valida           = 'S',
    @i_val_dir          = 'N',
    @i_val_domicilio    = 'S',
    @i_canal            = null,
    @i_envio_notifica   = 'S',
    @e_actmasivacli     = 'N',
    @o_direccion        = @o_direccion OUT,
    @o_msj_error        = @o_msj_error OUT,
    @o_sig_log_svr      = @o_sig_log_svr OUT;

SELECT @return_code AS return_code, @o_direccion AS o_direccion;
GO
```

**POST - Validaciones en BD:**

```sql
-- PASO: EFECTO
SELECT di_ente, di_direccion, di_tipo, di_descripcion, di_envio_crp, di_verificado, di_fecha_registro
FROM cobis..cl_direccion
WHERE di_ente = 3
ORDER BY di_direccion DESC;
-- PASO: RESTITUCION
-- Eliminar la direccion insertada. Reemplazar <nueva_dir> con el valor de @o_direccion.
DELETE FROM cobis..cl_direccion WHERE di_ente = 3 AND di_direccion = <nueva_dir>;
-- PASO: FINAL
SELECT di_ente, di_direccion, di_tipo, di_descripcion, di_envio_crp, di_verificado
FROM cobis..cl_direccion
WHERE di_ente = 3
ORDER BY di_direccion;
```

**Trazabilidad por DB:**
- cobis..cl_ente: SELECT (L383-L394)
- cobis..cl_producto: SELECT (L434-L442)
- cobis..cl_ciudad: SELECT (L443-L450)
- cobis..cl_parroquia: SELECT (L451-L458)
- cobis..cl_oficina: SELECT (L484-L491)
- cobis..cl_direccion: INSERT (L762-L783)
- cobis..ts_direccion: INSERT (L795-L803)

---

### TC02 — INSERT exitoso - Direccion tipo Trabajo

**Origen consolidado:** TCO-CON-002
**Objetivo:** Insercion valida de direccion tipo Trabajo. Cubre RN-11.
**Datos de entrada:**

| Parametro | Valor efectivo | Fuente y evidencia |
|---|---|---|
| **@i_operacion** | 'I' | Diseno: particion valida INSERT |
| **@t_trn** | 109 | Diseno: codigo de transaccion INSERT |
| **@i_ente** | 3 | Diagnostico: ente PN |
| **@i_tipo** | 'T' | Diseno: tipo Trabajo valido |
| **@i_descripcion** | 'Av. Comercial QA 002' | Diseno: descripcion de prueba |
| **@i_ind_val_maxdir** | 'N' | Requerido: ente 3 ya tiene 3 direcciones |

**Cobertura y procedencia:** AFUN-PEQ-001, AFUN-PEQ-013 | Particion valida | Riesgo MEDIO
**Tablas afectadas:** cobis..cl_direccion (INSERT), cobis..ts_direccion (INSERT)
**Estado de preparacion:** DOCUMENTADA
**Ejecucion funcional:** DISPONIBLE
**Condicion del SP:** @i_operacion='I' → @t_trn=109 → validaciones FK → INSERT cl_direccion con di_tipo='T'
**Diagnostico:** Ente 3 tiene dir=2 tipo T y dir=3 tipo T. Con @i_ind_val_maxdir='N' se omite validacion de maximo 2 T/O.
**Estado original documentado:** Ente 3: dir=1(D,S,S), dir=2(T,N,N), dir=3(T,N,S). Total=3.
**Aplicacion de preparacion:** Usar @i_ind_val_maxdir='N'. No se requiere DML previo.
**Aplicacion de restitucion:** DELETE de la direccion insertada.
**Alcance de recuperacion:** Eliminar fila insertada en cl_direccion. ts_direccion se conserva.
**Datos verificados:**

| Tabla | Columna | Tipo | Valor original | Parametro SP | Rol |
|---|---|---|---|---|---|
| cobis..cl_ente | en_ente | int | 3 | **@i_ente** | CLAVE |
| cobis..cl_ente | en_subtipo | char(1) | 'P' | - | DATO |

**Resultado esperado:** `RETURN 0` — Insercion exitosa, @o_direccion retorna el nuevo secuencial.
**Resultado esperado en BD:** Nueva fila en cl_direccion con di_ente=3, di_tipo='T'.
**Resultado observado:** Pendiente de corrida QA.
**Pendiente:** NO_APLICA

**PRE - Estado requerido en BD:**

```sql
-- PASO: ORIGINAL
SELECT di_ente, di_direccion, di_tipo, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 3
ORDER BY di_direccion;
-- PASO: PREPARACION
-- NO_APLICA: Se usa @i_ind_val_maxdir='N' en el EXEC.
-- PASO: PREPARADO
SELECT di_ente, di_direccion, di_tipo, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 3
ORDER BY di_direccion;
```

**Ejecucion del SP:**

```sql
DECLARE @return_code int;
DECLARE @o_direccion tinyint;
DECLARE @o_msj_error varchar(132);
DECLARE @o_sig_log_svr int;

EXEC @return_code = cobis..sp_direccion_dml
    @s_ssn              = 1,
    @s_user             = 'TESTUSER',
    @s_term             = 'TERM001',
    @s_date             = '2026-11-12 10:00:00',
    @s_srv              = 'SRV001',
    @s_lsrv             = 'LSRV001',
    @s_ofi              = 1,
    @s_rol              = 1,
    @s_org_err          = 'N',
    @s_error            = 0,
    @s_sev              = 0,
    @s_msg              = null,
    @s_org              = 'N',
    @t_debug            = 'N',
    @t_file             = null,
    @t_from             = null,
    @t_trn              = 109,
    @i_operacion        = 'I',
    @i_no_cobis         = 'N',
    @i_mensaje          = 'S',
    @i_producto         = 2,
    @i_ente             = 3,
    @i_direccion        = null,
    @i_descripcion      = 'Av. Comercial QA 002',
    @i_tipo             = 'T',
    @i_sector           = '0',
    @i_parroquia        = 0,
    @i_ciudad           = 1,
    @i_oficina          = 1,
    @i_zona             = null,
    @i_envio_crp        = 'N',
    @i_parroquia_ciu    = 0,
    @i_observacion      = null,
    @i_pto_referencia   = null,
    @i_verificado       = 'N',
    @i_fecha_ver        = null,
    @i_usuario_ver      = null,
    @i_vigencia         = 'N',
    @i_fecha_caducidad  = null,
    @i_nombre_verif     = null,
    @i_cargo_verif      = null,
    @i_ind_act_presenc  = 'N',
    @i_ind_val_maxdir   = 'N',
    @i_tipo_verif_incns = null,
    @i_bancarizacion    = 'N',
    @i_verifdirec       = 'N',
    @i_tipo_servicio    = null,
    @i_cod_empresa      = null,
    @i_direc_planilla   = null,
    @i_cod_rela_prop    = null,
    @i_nom_propietario  = null,
    @i_vreferen         = 'N',
    @i_solicitud        = null,
    @i_anio             = null,
    @i_canton           = null,
    @i_valida           = 'S',
    @i_val_dir          = 'N',
    @i_val_domicilio    = 'S',
    @i_canal            = null,
    @i_envio_notifica   = 'S',
    @e_actmasivacli     = 'N',
    @o_direccion        = @o_direccion OUT,
    @o_msj_error        = @o_msj_error OUT,
    @o_sig_log_svr      = @o_sig_log_svr OUT;

SELECT @return_code AS return_code, @o_direccion AS o_direccion;
GO
```

**POST - Validaciones en BD:**

```sql
-- PASO: EFECTO
SELECT di_ente, di_direccion, di_tipo, di_descripcion, di_fecha_registro
FROM cobis..cl_direccion
WHERE di_ente = 3 AND di_tipo = 'T'
ORDER BY di_direccion DESC;
-- PASO: RESTITUCION
DELETE FROM cobis..cl_direccion WHERE di_ente = 3 AND di_direccion = <nueva_dir>;
-- PASO: FINAL
SELECT di_ente, di_direccion, di_tipo, di_descripcion
FROM cobis..cl_direccion
WHERE di_ente = 3
ORDER BY di_direccion;
```

**Trazabilidad por DB:**
- cobis..cl_direccion: INSERT (L762-L783)
- cobis..ts_direccion: INSERT (L795-L803)

---

### TC03 — INSERT exitoso - Direccion con verificacion activa (vigencia)

**Origen consolidado:** TCO-CON-003
**Objetivo:** Insercion con @i_verificado='S' activa calculo de vigencia. Cubre RN-22, RAMA-019.
**Datos de entrada:**

| Parametro | Valor efectivo | Fuente y evidencia |
|---|---|---|
| **@i_operacion** | 'I' | Diseno |
| **@t_trn** | 109 | Diseno |
| **@i_ente** | 3 | Diagnostico |
| **@i_verificado** | 'S' | Diseno: activa vigencia |
| **@i_descripcion** | 'Calle Verificada QA 003' | Diseno |
| **@i_ind_val_maxdir** | 'N' | Requerido: ente 3 ya tiene 3 direcciones |

**Cobertura y procedencia:** AFUN-PEQ-001, AFUN-PEQ-010, AFUN-TD-009, AEST-RAMA-019 | Particion valida / Rama | Riesgo MEDIO
**Tablas afectadas:** cobis..cl_direccion (INSERT), cobis..ts_direccion (INSERT)
**Estado de preparacion:** DOCUMENTADA
**Ejecucion funcional:** DISPONIBLE
**Condicion del SP:** @i_verificado='S' → RAMA-035 TRUE → SELECT cl_parametro TPVGRE → asigna @i_vigencia='S', @i_fecha_ver=@s_date, @i_fecha_caducidad=@s_date+TPVGRE
**Diagnostico:** TPVGRE: consulta fallo (columna no encontrada). Se requiere verificar disponibilidad del parametro antes de ejecutar.
**Estado original documentado:** Ente 3 con 3 direcciones.
**Aplicacion de preparacion:** @i_ind_val_maxdir='N'. Verificar TPVGRE en cl_parametro.
**Aplicacion de restitucion:** DELETE de la direccion insertada.
**Alcance de recuperacion:** Eliminar fila insertada.
**Datos verificados:**

| Tabla | Columna | Tipo | Valor original | Parametro SP | Rol |
|---|---|---|---|---|---|
| cobis..cl_ente | en_ente | int | 3 | **@i_ente** | CLAVE |
| cobis..cl_parametro | pa_producto | varchar | 'MIS' | - | CLAVE |
| cobis..cl_parametro | pa_nemonico | varchar | 'TPVGRE' | - | CLAVE |

**Resultado esperado:** `RETURN 0` — Insercion con di_verificado='S', di_vigencia='S', di_fecha_ver=@s_date.
**Resultado esperado en BD:** Nueva fila con di_verificado='S', di_vigencia='S', di_fecha_ver='2026-11-12 10:00:00'.
**Resultado observado:** Pendiente de corrida QA.
**Pendiente:** Verificar disponibilidad de TPVGRE en cl_parametro antes de ejecutar. Si no existe, el caso retornara error 101077.

**PRE - Estado requerido en BD:**

```sql
-- PASO: ORIGINAL
SELECT di_ente, di_direccion, di_tipo, di_verificado, di_vigencia
FROM cobis..cl_direccion
WHERE di_ente = 3
ORDER BY di_direccion;
-- PASO: PREPARACION
-- Verificar TPVGRE
SELECT pa_producto, pa_nemonico, pa_smallint
FROM cobis..cl_parametro
WHERE pa_producto = 'MIS' AND pa_nemonico = 'TPVGRE';
-- PASO: PREPARADO
SELECT di_ente, di_direccion, di_tipo, di_verificado, di_vigencia
FROM cobis..cl_direccion
WHERE di_ente = 3
ORDER BY di_direccion;
```

**Ejecucion del SP:**

```sql
DECLARE @return_code int;
DECLARE @o_direccion tinyint;
DECLARE @o_msj_error varchar(132);
DECLARE @o_sig_log_svr int;

EXEC @return_code = cobis..sp_direccion_dml
    @s_ssn              = 1,
    @s_user             = 'TESTUSER',
    @s_term             = 'TERM001',
    @s_date             = '2026-11-12 10:00:00',
    @s_srv              = 'SRV001',
    @s_lsrv             = 'LSRV001',
    @s_ofi              = 1,
    @s_rol              = 1,
    @s_org_err          = 'N',
    @s_error            = 0,
    @s_sev              = 0,
    @s_msg              = null,
    @s_org              = 'N',
    @t_debug            = 'N',
    @t_file             = null,
    @t_from             = null,
    @t_trn              = 109,
    @i_operacion        = 'I',
    @i_no_cobis         = 'N',
    @i_mensaje          = 'S',
    @i_producto         = 2,
    @i_ente             = 3,
    @i_direccion        = null,
    @i_descripcion      = 'Calle Verificada QA 003',
    @i_tipo             = 'D',
    @i_sector           = '0',
    @i_parroquia        = 0,
    @i_ciudad           = 1,
    @i_oficina          = 1,
    @i_zona             = null,
    @i_envio_crp        = 'N',
    @i_parroquia_ciu    = 0,
    @i_observacion      = null,
    @i_pto_referencia   = null,
    @i_verificado       = 'S',
    @i_fecha_ver        = null,
    @i_usuario_ver      = null,
    @i_vigencia         = 'N',
    @i_fecha_caducidad  = null,
    @i_nombre_verif     = null,
    @i_cargo_verif      = null,
    @i_ind_act_presenc  = 'N',
    @i_ind_val_maxdir   = 'N',
    @i_tipo_verif_incns = null,
    @i_bancarizacion    = 'N',
    @i_verifdirec       = 'N',
    @i_tipo_servicio    = null,
    @i_cod_empresa      = null,
    @i_direc_planilla   = null,
    @i_cod_rela_prop    = null,
    @i_nom_propietario  = null,
    @i_vreferen         = 'N',
    @i_solicitud        = null,
    @i_anio             = null,
    @i_canton           = null,
    @i_valida           = 'S',
    @i_val_dir          = 'N',
    @i_val_domicilio    = 'S',
    @i_canal            = null,
    @i_envio_notifica   = 'S',
    @e_actmasivacli     = 'N',
    @o_direccion        = @o_direccion OUT,
    @o_msj_error        = @o_msj_error OUT,
    @o_sig_log_svr      = @o_sig_log_svr OUT;

SELECT @return_code AS return_code, @o_direccion AS o_direccion;
GO
```

**POST - Validaciones en BD:**

```sql
-- PASO: EFECTO
SELECT di_ente, di_direccion, di_descripcion, di_verificado, di_vigencia, di_fecha_ver, di_usuario_ver, di_fecha_caducidad
FROM cobis..cl_direccion
WHERE di_ente = 3 AND di_verificado = 'S'
ORDER BY di_direccion DESC;
-- PASO: RESTITUCION
DELETE FROM cobis..cl_direccion WHERE di_ente = 3 AND di_direccion = <nueva_dir>;
-- PASO: FINAL
SELECT di_ente, di_direccion, di_tipo, di_verificado, di_vigencia
FROM cobis..cl_direccion
WHERE di_ente = 3
ORDER BY di_direccion;
```

**Trazabilidad por DB:**
- cobis..cl_parametro: SELECT (L610-L618)
- cobis..cl_direccion: INSERT (L762-L783)

---

### TC04 — INSERT exitoso - Direccion con envio de correspondencia

**Origen consolidado:** TCO-CON-004
**Objetivo:** Insercion con @i_envio_crp='S' desmarca direccion anterior y propaga a cuentas. Cubre RN-25.
**Datos de entrada:**

| Parametro | Valor efectivo | Fuente y evidencia |
|---|---|---|
| **@i_operacion** | 'I' | Diseno |
| **@t_trn** | 109 | Diseno |
| **@i_ente** | 3 | Diagnostico |
| **@i_envio_crp** | 'S' | Diseno: activa envio correspondencia |
| **@i_descripcion** | 'Calle Envio CRP QA 004' | Diseno |
| **@i_ind_val_maxdir** | 'N' | Requerido |

**Cobertura y procedencia:** AFUN-PEQ-001, AFUN-PEQ-015, AFUN-TD-010, AEST-RAMA-021 | Particion valida / Rama | Riesgo ALTO
**Tablas afectadas:** cobis..cl_direccion (INSERT, UPDATE), cobis..ts_direccion (INSERT)
**Estado de preparacion:** DOCUMENTADA
**Ejecucion funcional:** DISPONIBLE
**Condicion del SP:** @i_envio_crp='S' → RAMA-045 TRUE → UPDATE cl_direccion SET di_envio_crp='N' para desmarcar anterior → INSERT nueva con di_envio_crp='S' → cursor sobre cob_ahorros..ah_cuenta → sp_dir_est_cta
**Diagnostico:** Ente 3 dir=1 tiene di_envio_crp='S'. Al insertar con @i_envio_crp='S', se desmarcara dir=1 a 'N'.
**Estado original documentado:** Ente 3 dir=1: di_envio_crp='S'. Sera modificado a 'N' por el SP.
**Aplicacion de preparacion:** @i_ind_val_maxdir='N'. El SP modificara dir=1 automaticamente.
**Aplicacion de restitucion:** 1) DELETE de la nueva direccion insertada. 2) UPDATE dir=1 SET di_envio_crp='S' (restaurar valor original).
**Alcance de recuperacion:** Restaurar di_envio_crp='S' en dir=1. Eliminar nueva direccion. ts_direccion se conserva.
**Datos verificados:**

| Tabla | Columna | Tipo | Valor original | Parametro SP | Rol |
|---|---|---|---|---|---|
| cobis..cl_direccion | di_ente | int | 3 | **@i_ente** | CLAVE |
| cobis..cl_direccion | di_direccion | tinyint | 1 | - | CLAVE |
| cobis..cl_direccion | di_envio_crp | char(1) | 'S' | - | DATO |

**Resultado esperado:** `RETURN 0` — Insercion exitosa, dir=1 desmarcada a 'N', nueva dir con crp='S'.
**Resultado esperado en BD:** dir=1: di_envio_crp='N'. Nueva dir: di_envio_crp='S'. Se ejecuta sp_dir_est_cta para cuentas de ahorro.
**Resultado observado:** Pendiente de corrida QA.
**Pendiente:** NO_APLICA

**PRE - Estado requerido en BD:**

```sql
-- PASO: ORIGINAL
SELECT di_ente, di_direccion, di_tipo, di_descripcion, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 3
ORDER BY di_direccion;
-- PASO: PREPARACION
-- NO_APLICA: El SP desmarcara dir=1 automaticamente.
-- PASO: PREPARADO
SELECT di_ente, di_direccion, di_tipo, di_descripcion, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 3
ORDER BY di_direccion;
```

**Ejecucion del SP:**

```sql
DECLARE @return_code int;
DECLARE @o_direccion tinyint;
DECLARE @o_msj_error varchar(132);
DECLARE @o_sig_log_svr int;

EXEC @return_code = cobis..sp_direccion_dml
    @s_ssn              = 1,
    @s_user             = 'TESTUSER',
    @s_term             = 'TERM001',
    @s_date             = '2026-11-12 10:00:00',
    @s_srv              = 'SRV001',
    @s_lsrv             = 'LSRV001',
    @s_ofi              = 1,
    @s_rol              = 1,
    @s_org_err          = 'N',
    @s_error            = 0,
    @s_sev              = 0,
    @s_msg              = null,
    @s_org              = 'N',
    @t_debug            = 'N',
    @t_file             = null,
    @t_from             = null,
    @t_trn              = 109,
    @i_operacion        = 'I',
    @i_no_cobis         = 'N',
    @i_mensaje          = 'S',
    @i_producto         = 2,
    @i_ente             = 3,
    @i_direccion        = null,
    @i_descripcion      = 'Calle Envio CRP QA 004',
    @i_tipo             = 'D',
    @i_sector           = '0',
    @i_parroquia        = 0,
    @i_ciudad           = 1,
    @i_oficina          = 1,
    @i_zona             = null,
    @i_envio_crp        = 'S',
    @i_parroquia_ciu    = 0,
    @i_observacion      = null,
    @i_pto_referencia   = null,
    @i_verificado       = 'N',
    @i_fecha_ver        = null,
    @i_usuario_ver      = null,
    @i_vigencia         = 'N',
    @i_fecha_caducidad  = null,
    @i_nombre_verif     = null,
    @i_cargo_verif      = null,
    @i_ind_act_presenc  = 'N',
    @i_ind_val_maxdir   = 'N',
    @i_tipo_verif_incns = null,
    @i_bancarizacion    = 'N',
    @i_verifdirec       = 'N',
    @i_tipo_servicio    = null,
    @i_cod_empresa      = null,
    @i_direc_planilla   = null,
    @i_cod_rela_prop    = null,
    @i_nom_propietario  = null,
    @i_vreferen         = 'N',
    @i_solicitud        = null,
    @i_anio             = null,
    @i_canton           = null,
    @i_valida           = 'S',
    @i_val_dir          = 'N',
    @i_val_domicilio    = 'S',
    @i_canal            = null,
    @i_envio_notifica   = 'S',
    @e_actmasivacli     = 'N',
    @o_direccion        = @o_direccion OUT,
    @o_msj_error        = @o_msj_error OUT,
    @o_sig_log_svr      = @o_sig_log_svr OUT;

SELECT @return_code AS return_code, @o_direccion AS o_direccion;
GO
```

**POST - Validaciones en BD:**

```sql
-- PASO: EFECTO
SELECT di_ente, di_direccion, di_tipo, di_descripcion, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 3
ORDER BY di_direccion;
-- PASO: RESTITUCION
-- 1) Eliminar la nueva direccion insertada
DELETE FROM cobis..cl_direccion WHERE di_ente = 3 AND di_direccion = <nueva_dir>;
-- 2) Restaurar di_envio_crp='S' en dir=1
UPDATE cobis..cl_direccion SET di_envio_crp = 'S' WHERE di_ente = 3 AND di_direccion = 1;
-- PASO: FINAL
SELECT di_ente, di_direccion, di_tipo, di_descripcion, di_envio_crp
FROM cobis..cl_direccion
WHERE di_ente = 3
ORDER BY di_direccion;
```

**Trazabilidad por DB:**
- cobis..cl_direccion: UPDATE (L738-L750), INSERT (L762-L783)
- cob_ahorros..ah_cuenta: SELECT cursor (L855-L861)
- cobis..ts_direccion: INSERT (L795-L803)

---

### TC05 — UPDATE exitoso - Cambio de descripcion

**Origen consolidado:** TCO-CON-005
**Objetivo:** Actualizacion valida de direccion existente cambiando solo la descripcion. Cubre RN-05, BVA-005.
**Datos de entrada:**

| Parametro | Valor efectivo | Fuente y evidencia |
|---|---|---|
| **@i_operacion** | 'U' | Diseno: particion valida UPDATE |
| **@t_trn** | 110 | Diseno: codigo de transaccion UPDATE |
| **@i_ente** | 3 | Diagnostico |
| **@i_direccion** | 2 | Diagnostico: dir=2 del ente 3 (tipo T, crp=N, verif=N) |
| **@i_descripcion** | 'Calle Modificada QA 005' | Diseno: nueva descripcion |
| **@i_tipo** | 'T' | Diagnostico: mismo tipo que dir=2 |
| **@i_ciudad** | 1 | Diagnostico |
| **@i_parroquia** | 0 | Diagnostico |
| **@i_oficina** | 1 | Diagnostico |

**Cobertura y procedencia:** AFUN-PEQ-002, AFUN-PEQ-012, AFUN-TD-019, AEST-BVA-005, AEST-RAMA-002, AEST-RAMA-006 | Particion valida / Frontera BVA | Riesgo MEDIO
**Tablas afectadas:** cobis..cl_direccion (UPDATE), cobis..ts_direccion (INSERT x2)
**Estado de preparacion:** DOCUMENTADA
**Ejecucion funcional:** DISPONIBLE
**Condicion del SP:** @i_operacion='U' (RAMA-062 TRUE) → @t_trn=110 (RAMA-063 TRUE) → validaciones FK → SELECT dir actual → comparacion campo a campo → UPDATE cl_direccion → INSERT ts_direccion (P y A) → COMMIT
**Diagnostico:** Ente 3 dir=2: tipo='T', descripcion='DESCRIPCION: 2', crp='N', verif='N'. El cambio de descripcion activa @w_envio_notifica='S'.
**Estado original documentado:** dir=2: di_descripcion='DESCRIPCION: 2', di_tipo='T', di_envio_crp='N', di_verificado='N'.
**Aplicacion de preparacion:** No se requiere DML previo. La direccion existe y es modificable.
**Aplicacion de restitucion:** UPDATE dir=2 SET di_descripcion='DESCRIPCION: 2' (valor original).
**Alcance de recuperacion:** Restaurar di_descripcion. ts_direccion se conserva (auditoria).
**Datos verificados:**

| Tabla | Columna | Tipo | Valor original | Parametro SP | Rol |
|---|---|---|---|---|---|
| cobis..cl_direccion | di_ente | int | 3 | **@i_ente** | CLAVE |
| cobis..cl_direccion | di_direccion | tinyint | 2 | **@i_direccion** | CLAVE |
| cobis..cl_direccion | di_descripcion | varchar(254) | 'DESCRIPCION: 2' | - | DATO |
| cobis..cl_direccion | di_tipo | catalogo(10) | 'T' | **@i_tipo** | DATO |
| cobis..cl_direccion | di_envio_crp | char(1) | 'N' | - | DATO |
| cobis..cl_direccion | di_verificado | char(1) | 'N' | - | DATO |

**Resultado esperado:** `RETURN 0` — Actualizacion exitosa, descripcion cambiada.
**Resultado esperado en BD:** dir=2: di_descripcion='Calle Modificada QA 005', di_fecha_modificacion=actualizada, di_usuario_mod='TESTUSER'. ts_direccion: 2 nuevos registros (clase P y A).
**Resultado observado:** Pendiente de corrida QA.
**Pendiente:** NO_APLICA

**PRE - Estado requerido en BD:**

```sql
-- PASO: ORIGINAL
SELECT di_ente, di_direccion, di_tipo, di_descripcion, di_envio_crp, di_verificado, di_fecha_modificacion, di_usuario_mod
FROM cobis..cl_direccion
WHERE di_ente = 3 AND di_direccion = 2;
-- PASO: PREPARACION
-- NO_APLICA: La direccion existe y esta en estado modificable.
-- PASO: PREPARADO
SELECT di_ente, di_direccion, di_tipo, di_descripcion, di_envio_crp, di_verificado, di_fecha_modificacion, di_usuario_mod
FROM cobis..cl_direccion
WHERE di_ente = 3 AND di_direccion = 2;
```

**Ejecucion del SP:**

```sql
DECLARE @return_code int;
DECLARE @o_direccion tinyint;
DECLARE @o_msj_error varchar(132);
DECLARE @o_sig_log_svr int;

EXEC @return_code = cobis..sp_direccion_dml
    @s_ssn              = 1,
    @s_user             = 'TESTUSER',
    @s_term             = 'TERM001',
    @s_date             = '2026-11-12 10:00:00',
    @s_srv              = 'SRV001',
    @s_lsrv             = 'LSRV001',
    @s_ofi              = 1,
    @s_rol              = 1,
    @s_org_err          = 'N',
    @s_error            = 0,
    @s_sev              = 0,
    @s_msg              = null,
    @s_org              = 'N',
    @t_debug            = 'N',
    @t_file             = null,
    @t_from             = null,
    @t_trn              = 110,
    @i_operacion        = 'U',
    @i_no_cobis         = 'N',
    @i_mensaje          = 'S',
    @i_producto         = 2,
    @i_ente             = 3,
    @i_direccion        = 2,
    @i_descripcion      = 'Calle Modificada QA 005',
    @i_tipo             = 'T',
    @i_sector           = '0',
    @i_parroquia        = 0,
    @i_ciudad           = 1,
    @i_oficina          = 1,
    @i_zona             = null,
    @i_envio_crp        = 'N',
    @i_parroquia_ciu    = 0,
    @i_observacion      = null,
    @i_pto_referencia   = null,
    @i_verificado       = 'N',
    @i_fecha_ver        = null,
    @i_usuario_ver      = null,
    @i_vigencia         = 'N',
    @i_fecha_caducidad  = null,
    @i_nombre_verif     = null,
    @i_cargo_verif      = null,
    @i_ind_act_presenc  = 'N',
    @i_ind_val_maxdir   = 'S',
    @i_tipo_verif_incns = null,
    @i_bancarizacion    = 'N',
    @i_verifdirec       = 'N',
    @i_tipo_servicio    = null,
    @i_cod_empresa      = null,
    @i_direc_planilla   = null,
    @i_cod_rela_prop    = null,
    @i_nom_propietario  = null,
    @i_vreferen         = 'N',
    @i_solicitud        = null,
    @i_anio             = null,
    @i_canton           = null,
    @i_valida           = 'S',
    @i_val_dir          = 'N',
    @i_val_domicilio    = 'S',
    @i_canal            = null,
    @i_envio_notifica   = 'S',
    @e_actmasivacli     = 'N',
    @o_direccion        = @o_direccion OUT,
    @o_msj_error        = @o_msj_error OUT,
    @o_sig_log_svr      = @o_sig_log_svr OUT;

SELECT @return_code AS return_code;
GO
```

**POST - Validaciones en BD:**

```sql
-- PASO: EFECTO
SELECT di_ente, di_direccion, di_tipo, di_descripcion, di_fecha_modificacion, di_usuario_mod
FROM cobis..cl_direccion
WHERE di_ente = 3 AND di_direccion = 2;
-- PASO: RESTITUCION
UPDATE cobis..cl_direccion SET di_descripcion = 'DESCRIPCION: 2' WHERE di_ente = 3 AND di_direccion = 2;
-- PASO: FINAL
SELECT di_ente, di_direccion, di_tipo, di_descripcion, di_fecha_modificacion, di_usuario_mod
FROM cobis..cl_direccion
WHERE di_ente = 3 AND di_direccion = 2;
```

**Trazabilidad por DB:**
- cobis..cl_ente: SELECT (L383-L394)
- cobis..cl_direccion: SELECT (L1244-L1261), UPDATE (L1614-L1644)
- cobis..ts_direccion: INSERT x2 (L1662-L1680, L1706-L1707)

---

## GRUPO 2 — Casos pendientes de expansion

Los siguientes casos consolidados (TCO-CON-006 a TCO-CON-086) estan mapeados en la matriz de trazabilidad del consolidado pero requieren expansion individual con diagnostico de BD. Se listan a continuacion con su estado.

### TC06 — PENDIENTE: TCO-CON-006 (UPDATE cambio tipo D a T)

**Origen consolidado:** TCO-CON-006
**Estado de preparacion:** PENDIENTE
**Ejecucion funcional:** PENDIENTE
**Pendiente:** Requiere diagnostico de direccion tipo D del ente para cambiar a T, verificando que no exceda maximo 2 T/O.

### TC07 — PENDIENTE: TCO-CON-007 (UPDATE cambio ciudad y parroquia)

**Origen consolidado:** TCO-CON-007
**Estado de preparacion:** PENDIENTE
**Pendiente:** Requiere diagnostico de ciudad y parroquia alternativas validas.

### TC08 — PENDIENTE: TCO-CON-008 (UPDATE cambio verificacion a S)

**Origen consolidado:** TCO-CON-008
**Estado de preparacion:** PENDIENTE
**Pendiente:** Requiere verificacion de TPVGRE y direccion con verificado != 'S'.

### TC09 — PENDIENTE: TCO-CON-009 (UPDATE cambio oficina)

**Origen consolidado:** TCO-CON-009
**Estado de preparacion:** PENDIENTE
**Pendiente:** Requiere diagnostico de oficina alternativa.

### TC10 — PENDIENTE: TCO-CON-010 (UPDATE sin cambios)

**Origen consolidado:** TCO-CON-010
**Estado de preparacion:** PENDIENTE
**Pendiente:** Requiere lectura completa de todos los campos de la direccion para enviar mismos valores.

### TC11 a TC86 — PENDIENTES

Los casos TCO-CON-011 a TCO-CON-086 (76 casos) requieren expansion individual. Consulte el archivo consolidado `consolidado_sp_direccion_dml.md` para la matriz completa de trazabilidad y firmas funcionales.

---

## TABLAS MONITOREADAS

| Tabla | Base | Operacion | Campo cuenta | Top | Campos a ignorar | Filtro contenido |
|-------|------|-----------|--------------|-----|------------------|------------------|
| cl_direccion | cobis | INSERT, UPDATE, DELETE | di_ente=@i_ente | N/A | di_fecha_registro, di_fecha_modificacion, di_usuario_reg, di_usuario_mod | - |
| ts_direccion | cobis | INSERT | secuencial=@s_ssn | TOP 1 secuencial DESC | - | - |
| cl_log_dir_envio_ec | cobis | INSERT | ld_ente=@i_ente | TOP 1 ld_fecha DESC | - | - |
| cl_direccion_his | cobis_his | INSERT | hd_ente=@i_ente | TOP 1 hd_secuencial DESC | - | - |
| cl_telefono | cobis | DELETE | te_ente=@i_ente | N/A | - | - |
| cl_telefono_his | cobis_his | INSERT | ht_ente=@i_ente | N/A | - | - |

---

## Control de Entrega QA_MANUAL

- **Archivo**: `insumos/sp_direccion_dml/entregable/casos_prueba_sp_direccion_dml.md`
- **Estado**: PARCIAL_CON_PENDIENTES
- **Fichas expandidas**: 5 (TC01 a TC05)
- **Fichas pendientes**: 81 (TC06 a TC86)
- **Casos con preparacion DOCUMENTADA**: 5
- **Casos con preparacion DATOS_EXISTENTES**: 0
- **Casos con preparacion PENDIENTE**: 81
- **Ejecucion funcional DISPONIBLE**: 5
- **Ejecucion funcional PENDIENTE**: 81
- **Diagnosticos ejecutados**: 4 consultas
- **Ente candidato principal**: 3 (3 direcciones)
- **Ente candidato alternativo**: 2 (3 direcciones)
- **Limitacion identificada**: Ente 3 ya tiene 3 direcciones (maximo PN). Se requiere @i_ind_val_maxdir='N' para INSERTs adicionales.
- **TPVGRE**: Requiere verificacion (consulta fallo por nombre de columna)
- **graph_context_status**: NO_INFORMADO